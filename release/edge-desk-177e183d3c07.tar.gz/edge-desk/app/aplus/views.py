"""The A+ block on Today (docs/APLUS_DESIGN.md sections 2 and 8), since 30 Oct 2026 the A22 pick `D4h 3m+5m`, buys and
sells: each pair's state in words (while scanning and on a no trade, each chart's own state), the checks of an order
on its own side, the guard, how far behind the prices are, the tested record line and the forward paper record of
this rule (rows written by its own runs, app/aplus/step.py). Every word on the block comes from here (the screens hold
no strategy words). Every time is on the 12-hour clock (trader review, 30 Oct), as in the alerts.

STATUS_WORDS covers every code the pinned rule can return (live.py phases, reasons and chart states; engine.py
statuses; A22's base and order-path codes); tests/test_aplus_views.py checks the list against the pinned sources.
"""
from __future__ import annotations

import json
from datetime import date, datetime, timedelta

from app.aplus import alerts as AA
from app.aplus import record
from app.aplus.book import alert_id
from app.aplus.step import FINAL, forward_rows, get_state, in_window, latest_day, lon, london_date, trading_weekday

# a pair-day that is not eligible (live.evaluate reasons)
REASON_WORDS = {
    "CLOCK": "Clock change day (not traded)",
    "WARMUP": "Not enough prices",
    "NO_DATA": "Not enough prices",
    "BLIND": "Day left out of the test",
    "HOLIDAY": "Holiday",
    "GAP": "Price gap over 16 minutes",
}
# one chart's state, final (live.chart_reason: the W1 row's status, the D4h base, the 8-pip floor)
CHART_WORDS = {
    "NO_SIGNAL": "No sweep and CHoCH by 10:00 am London",
    "BOTH_SIDES": "Both sides swept",
    "VOID": "Price went back past the sweep before the order",
    "NO_ZONE": "No FVG or order block",
    "S5": "Stop over a third of the 20-day range",
    "H_FILTER": "Daily or 4h bias against the trade",
    "NO_ORDER_BAR": f"No order by {AA.CANCEL_AT}",
    "D0_8_PIPS_OR_LESS": "Stop 8 pips or less",
    "APLUS": "An A+ order",
}
# one chart's state while it can still change (NO_SIGNAL to 10:00 am London, NO_ORDER_BAR to 11:00 am London)
SCANNING_WORDS = {"NO_SIGNAL": "Scanning to 10:00 am London",
                  "NO_ORDER_BAR": f"Waiting for the order bar, to {AA.CANCEL_AT}"}
OPEN_UNTIL = {"NO_SIGNAL": (10, 0), "NO_ORDER_BAR": (11, 0)}
END_WORDS = {"EXPIRED": f"Not filled by {AA.CANCEL_AT}",
             "CANCEL_TARGET": "Target reached before the entry",
             "CANCEL_FILLBAR": "Fill minute also reached the target (not counted)",
             "TARGET": "Target (3R)",
             "STOP": "Stop",
             "TIME": f"Closed {AA.CLOSE_AT}"}
PHASE_WORDS = {"WAIT": "Starts 7:00 am London"}
POOL_WORDS = AA.POOL_WORDS
ZONE_WORDS = {"FVG": "FVG middle", "OB": "order block middle"}
STATUS_WORDS = {**REASON_WORDS, **{f"CHART:{k}": v for k, v in CHART_WORDS.items()},
                **{f"SCANNING:{k}": v for k, v in SCANNING_WORDS.items()}, **END_WORDS, **PHASE_WORDS}
SIDE_WORDS = {"sell": ("Sell limit", "Short"), "buy": ("Buy limit", "Long"), None: ("Limit order", "Trade")}
TESTED = f"Tested: fixed stop, 3R, out {AA.CLOSE_AT}. From OANDA practice prices: check them on your chart."
UNITS_PER_PIP = AA.UNITS_PER_PIP


def _low(text: str) -> str:
    return text[:1].lower() + text[1:]


def _j(text):
    return None if text is None else json.loads(text)


_pips_units = AA.rule_pips


def _side(order: dict | None, book: dict | None) -> str | None:
    for src in (order or {}, book or {}):
        if src.get("side") in ("sell", "buy"):
            return src["side"]
    return None


def _plan_line(cfg, order: dict, book: dict, day: date, phase: str = "ARMED", filled: dict | None = None,
               fill: dict | None = None) -> str:
    """The order in one line; for a filled or closed trade the position itself (short or long), without the order's
    11:00 cancel, from the fill's own broker prices and lots (the child's FILLED facts: after a market fill the stop
    and target move)."""
    plan = (book or {}).get("plan") or {}
    limit, pos = SIDE_WORDS[_side(order, book)]
    traded = phase in ("FILLED", "CLOSED")
    word = pos if traded else limit
    src, rule = plan, (order or {}).get("d0")
    if traded and filled and filled.get("entry") is not None:
        src, rule = filled, (fill or {}).get("d")
    if src.get("entry") is None:
        return word
    e, s, t = int(src["entry"]), int(src["stop"]), int(src["target"])
    parts = [f"{word} {AA.px(e)}", f"stop {AA.px(s)} ({AA.stop_words(e, s, rule)})", f"target {AA.px(t)} (3R)"]
    lots = AA.lots_text(src.get("lots"))
    if lots is not None and cfg.account.currency == "USD":
        parts.append(f"{lots} lots")
    if not traded:
        parts.append(f"cancel {AA.CANCEL_AT} ({AA.mel(AA.cancel_ts(day), day)})")
    return " · ".join(parts)


def checks(order: dict, plan: dict | None = None) -> list[str]:
    """The order's checks in words (design section 2), from the pinned rule's order (side, chart, pool, zone, d0), on
    the order's own side. The stop is the rule's own (d0); when the broker's rounded stop of the plan reads
    differently, both are named."""
    if not order:
        return []
    rule = _pips_units(order["d0"])
    stop = f"Stop {rule} pips"
    if plan and plan.get("entry") is not None:
        broker = AA.pips(int(plan["stop"]) - int(plan["entry"]))
        if broker != rule:
            stop = f"Rule stop {rule} pips ({broker} pips at the broker)"
    buy = order.get("side") == "buy"
    chart = order.get("chart") or "3m or 5m"
    return [f"Swept the {POOL_WORDS.get(order.get('pool'), order.get('pool') or 'level')} by wick after 7:00 am London",
            f"CHoCH on the {chart} chart by 10:00 am London",
            "Daily bias bull and the last three 4h candles not bear (UTC 4h bars)" if buy else
            "Daily bias bear and the last three 4h candles not bull (UTC 4h bars)",
            f"{stop}: over 8 pips and at most a third of the 20-day range",
            f"Entry at the {ZONE_WORDS.get(order.get('zone'), order.get('zone') or 'zone')}",
            "Stop 1 pip below the sweep low" if buy else "Stop 1 pip above the sweep high",
            "Target 3R"]


def charts_words(reason: str, day: date, now: datetime, phase: str) -> str:
    """Each chart's state from the rule's reason ("3m NO_SIGNAL, 5m NO_ORDER_BAR"): a state that can still change in
    its scanning words, else its final words; one phrase when both charts read the same."""
    parts = []
    for item in (reason or "").split(", "):
        chart, _, code = item.partition(" ")
        if not code:
            return _low(CHART_WORDS.get(chart, chart.replace("_", " ").lower()))
        until = OPEN_UNTIL.get(code)
        still = phase == "SCANNING" and until is not None and now.timestamp() < lon(day, *until)
        parts.append((chart, _low(SCANNING_WORDS[code] if still else CHART_WORDS.get(code, code.replace("_", " ")
                                                                                       .lower()))))
    if len(parts) > 1 and len({w for _, w in parts}) == 1:
        return f"{parts[0][1]} ({' and '.join(c for c, _ in parts)} charts)"
    return "; ".join(f"{c} chart {w}" for c, w in parts)


def state_words(cfg, row: dict | None, day: date, now: datetime, filled: dict | None = None) -> tuple[str, list[str]]:
    """(the state in one line, detail lines) of one pair-day from its latest aplus_day row. filled: the facts of the
    day's FILLED alert (the fill's broker prices), when there is one."""
    if row is None:
        if now.timestamp() < lon(day, 7):
            return f"Starts 7:00 am London ({AA.mel(lon(day, 7), day)})", []
        return "Waiting for the first check", []
    phase, reason = row["phase"], row.get("reason") or ""
    order, fill, end, book = _j(row.get("order_json")), _j(row.get("fill_json")), _j(row.get("end_json")), \
        _j(row.get("guard_json"))
    if phase == "WAIT":
        return PHASE_WORDS["WAIT"], []
    if phase == "SCANNING":
        w = charts_words(reason, day, now, phase)
        return (w[:1].upper() + w[1:]) if " charts)" in w else f"Scanning: {w}", []
    if phase == "NOT_ELIGIBLE":
        return f"No trade: {REASON_WORDS.get(reason, reason.replace('_', ' ').lower())}", []
    if phase == "NO_TRADE":
        return f"No trade: {charts_words(reason, day, now, phase)}", []
    if book and book.get("action") != "PLACE":                  # the guard's words are the row's own guard field
        return f"Not placed: {AA.guard_short(book.get('rule'))}", []
    head = _plan_line(cfg, order or {}, book or {}, day, phase, filled, fill)
    lines = []
    if fill:
        lines.append(f"Filled {AA.london(fill['utc'])} ({AA.mel(fill['utc'], day)})"
                     + (", at market" if fill.get("market") else ""))
    if phase == "ARMED":
        return head, lines
    if phase == "FILLED":
        lines.append(f"Close at {AA.CLOSE_AT} ({AA.mel(AA.close_ts(day), day)}) if the stop or target has not hit")
        return head, lines
    if phase == "CANCELLED":
        return f"Cancelled: {_low(END_WORDS.get((end or {}).get('kind'), 'cancelled'))}", [head]
    # CLOSED: R after 2.0 pips first, as the record line, the card and the forward record
    r = row.get("r_owner")
    r20 = row.get("r_20")
    own = None if r is None else f"{r:+.2f}R after your costs"
    if r20 is not None:
        res = f", {r20:+.2f}R after 2.0 pips" + ("" if own is None else f" ({own})")
    else:
        res = "" if own is None else f", {own}"
    return f"Closed: {_low(END_WORDS.get((end or {}).get('kind'), 'closed'))}{res}", [head] + lines


def forward(conn, cfg) -> str:
    """The forward paper record of the current rule: placed A+ trades closed since its first check, R after 2.0 pips.
    A trade counts only when its order armed at or after that check's close (the first check rebuilds its week from
    Monday; a trade from before it was never checked live). Only the rule's own rows count (step.forward_rows: the
    v3 short's never do)."""
    first, rows = forward_rows(conn)
    if first is None:
        return "Paper record: starts with the first check."
    since = london_date(int(first))
    n, total = 0, 0.0
    from fractions import Fraction
    for r in rows:
        book = _j(r["guard_json"]) or {}
        if r["r_20"] is None:
            continue
        n += 1
        total += float(r["r_20"]) * float(Fraction(str(book.get("size") or "1")))
    need = cfg.analytics.min_trades
    head = f"Paper since {since.day} {since:%b}: "
    if n == 0:
        return head + f"no trades yet. Too early (under {need})."
    body = head + f"{n} trade{'s' if n != 1 else ''}, {total:+.2f}R after 2.0 pips"
    return body + (f". Too early (under {need})." if n < need else ".")


def _prices_note(conn, cfg, now: datetime) -> str | None:
    from app.feed.oanda import complete_through
    marker = complete_through(conn)
    if marker is None:
        return None
    if now.timestamp() - marker > cfg.aplus.stale_after_min * 60 and in_window(int(now.timestamp())):
        return f"Prices to {AA.london(marker)} ({AA.mel(marker, london_date(marker))})"
    return None


def failing_note(conn, now: datetime | None = None) -> str | None:
    """While the check itself fails (app/aplus/step.py _failed): since when (with the day when that is not today),
    how many M5 closes and why, in one line."""
    since = get_state(conn, "fail_since")
    if since is None:
        return None
    n = int(get_state(conn, "fail_n") or 0)
    what = "refused to run" if get_state(conn, "fail_status") == "refused" else "failing"
    why = (get_state(conn, "fail_detail") or "")[:160]
    at = None if now is None else int(now.timestamp())
    return (f"Check {what} since {AA.since_words(int(since), at)} ({AA.mel_of(int(since))}), {n} "
            f"run{'s' if n != 1 else ''}" + (f": {why}" if why else ""))


def filled_facts(conn, pair: str, day: date) -> dict | None:
    """The facts of the pair-day's FILLED alert as stored (the fill's broker prices and lots), unless withdrawn."""
    r = conn.execute("SELECT facts_json, withdrawn FROM aplus_alert WHERE alert_id = ? ORDER BY id DESC LIMIT 1",
                     (alert_id("FILLED", pair, day.isoformat()),)).fetchone()
    return None if r is None or r["withdrawn"] else json.loads(r["facts_json"])


def _next_day(day: date) -> date:
    d = day + timedelta(days=1)
    while not trading_weekday(d):
        d += timedelta(days=1)
    return d


def today_block(conn, cfg, now: datetime) -> dict:
    """The Today block: {'enabled', 'rows', 'prices', 'record', 'forward', 'tested', 'label', 'note'}."""
    out = {"enabled": bool(cfg.aplus.enabled), "rows": [], "prices": None, "record": record.record_line(),
           "forward": forward(conn, cfg), "tested": TESTED, "label": record.END, "note": None}
    if not cfg.aplus.enabled:
        out["note"] = "Off in config"
        return out
    if not cfg.feed.enabled:
        out["note"] = "Needs the OANDA feed"
    out["note"] = failing_note(conn, now) or out["note"]
    day = london_date(int(now.timestamp()))
    show = day if trading_weekday(day) else _next_day(day)
    hb = get_state(conn, "heartbeat_utc")
    for pair in cfg.aplus.pairs:
        row = latest_day(conn, pair, show.isoformat())
        if show != day:
            at = AA.mel(lon(show, 7), show)
            status, lines = f"Next check {show:%a} {show.day} {show:%b}, 7:00 am London ({at})", []
        else:
            status, lines = state_words(cfg, row, day, now, filled_facts(conn, pair, day) if row else None)
            from app.feed import health                     # say why, when the feed is the cause (11 Nov 2026)
            fp = health.problem(conn, cfg, now)
            if fp and row is None:
                status = fp
            elif fp:
                lines = [fp] + list(lines)
        order = _j(row["order_json"]) if row else None
        book = _j(row["guard_json"]) if row else None
        guard = AA.guard_words(book) if book else ""
        out["rows"].append({"pair": AA.pair_name(pair), "day": show.isoformat(), "phase": row["phase"] if row else None,
                            "final": bool(row and row["phase"] in FINAL), "status": status, "lines": lines,
                            "checks": checks(order, (book or {}).get("plan")) if order else [],
                            "guard": f"Guard: {guard[:1].upper()}{guard[1:]}" if guard else ""})
    out["prices"] = _prices_note(conn, cfg, now)
    out["checked"] = hb
    if any(r["phase"] in ("ARMED", "FILLED") for r in out["rows"]):
        from app.risk.day_guard import STATUS_WORDS as DAY_WORDS
        from app.risk.flags import guard_now
        g = guard_now(conn, cfg, now, "mt5")
        if g.status != "open":
            out["day_rule"] = f"Your day rules: {DAY_WORDS.get(g.status, g.status)} ({g.reason})"
    return out


__all__ = ["today_block", "STATUS_WORDS", "forward", "checks"]
