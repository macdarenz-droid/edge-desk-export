"""The EUR/USD price feed's health in plain words, for Today, the status command and one alert a day (11 Nov 2026:
the owner got no T1-M signal and every card read "Done for today" or "Waiting for the first check" while no price had
come; nothing said the feed was the cause). Read-only: it reads feed_state, feed_block and the marker.

  off       [feed] enabled false: Part B is off (said, not a problem)
  notoken   [feed] on but no EDGE_OANDA_TOKEN: the feed unit cannot start (a problem)
  stopped   a halt (3 failures that were not 5xx: a wrong token gives 401s) or a host block (403 or 429)
  paused    a short cool-down after failures, or a wait the server asked for (clears by itself)
  none      on, but no complete bar has ever been stored
  late      on a London weekday 07:00-21:00, the marker more than LATE_S behind
  ok        otherwise
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from app.timeutil import LONDON

LATE_S = 15 * 60
ALERT_LATE_S = 3600
HOST = "api-fxpractice.oanda.com"
RESET = "on the server console (root): edge-desk-install-status --reset-feed"
PROBLEMS = ("notoken", "stopped", "none", "late")


def _hm(ts: float) -> str:
    from app.timeutil import MELBOURNE
    t = datetime.fromtimestamp(ts, timezone.utc)
    m = t.astimezone(MELBOURNE)
    return f"{t.astimezone(LONDON):%a %H:%M} London ({m:%a} {m.strftime('%I:%M %p').lstrip('0').lower()} Melbourne)"


def status(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    """{"state": see above, "text": one line for Today, "marker": unix s or None}."""
    from app.feed import oanda as F
    if not cfg.feed.enabled:
        return {"state": "off", "text": "Price feed off ([feed] enabled = false)", "marker": None}
    if not cfg.secrets.oanda_token:
        return {"state": "notoken", "marker": None,
                "text": "Price feed cannot start: no OANDA practice token on the server (paste the install line again"
                        " and enter it)"}
    ts = now.timestamp()
    try:
        marker = F.complete_through(conn)
        halted = F.state(conn, "halted")
        blocked = F.blocked_until(conn, HOST, ts)
        stopped = F.state(conn, "stopped_until")
        stopped = float(stopped) if stopped is not None else None
        waits = F.not_before(conn, ts)
    except (sqlite3.Error, ValueError):
        return {"state": "none", "text": "Price feed state could not be read", "marker": None}
    since = f"; last price {_hm(marker)}" if marker is not None else ""
    if halted:
        return {"state": "stopped", "marker": marker,
                "text": f"Price feed stopped: {halted}{since}. Reset {RESET} (an HTTP 401 means the OANDA token is"
                        " wrong: paste the install line again with the right practice token first)"}
    if blocked:
        return {"state": "stopped", "marker": marker,
                "text": f"Price feed blocked by OANDA until {_hm(blocked)} (an HTTP 403 or 429){since}"}
    if stopped is not None and stopped > ts:
        return {"state": "paused", "marker": marker,
                "text": f"Price feed paused after failures until {_hm(stopped)}{since}"}
    if waits is not None:
        return {"state": "paused", "marker": marker, "text": f"Price feed waiting until {_hm(waits)}{since}"}
    if marker is None:
        return {"state": "none", "marker": None,
                "text": "No prices from the feed yet (is edge-desk-feed running? is the OANDA practice token right?)"}
    t = datetime.fromtimestamp(ts, LONDON)
    if t.weekday() < 5 and 7 <= t.hour < 21 and ts - marker > LATE_S:
        return {"state": "late", "marker": marker, "text": f"No prices from the feed since {_hm(marker)}"}
    return {"state": "ok", "marker": marker, "text": f"Price feed complete to {_hm(marker)}"}


def problem(conn: sqlite3.Connection, cfg, now: datetime) -> str | None:
    """The status line when signals cannot come (notoken, stopped, none, late; a short pause after 15 minutes behind
    shows as late), else None."""
    s = status(conn, cfg, now)
    if s["state"] in PROBLEMS:
        return s["text"]
    if s["state"] == "paused":
        t = datetime.fromtimestamp(now.timestamp(), LONDON)
        if s["marker"] is None or (t.weekday() < 5 and 7 <= t.hour < 21 and now.timestamp() - s["marker"] > LATE_S):
            return s["text"]
    return None


def alert(conn: sqlite3.Connection, cfg, now: datetime):
    """One feed_down alert a London day, on a weekday 07:00-21:00, while the feed has no token, is halted or blocked,
    has never delivered, or is more than an hour behind (a short pause alone never alerts)."""
    from app.notify.alerts import Alert
    t = now.astimezone(LONDON)
    if t.weekday() >= 5 or not 7 <= t.hour < 21:
        return None
    s = status(conn, cfg, now)
    if s["state"] in ("off", "ok"):
        return None
    behind = s["marker"] is None or now.timestamp() - s["marker"] >= ALERT_LATE_S
    if s["state"] in ("late", "paused", "none") and not behind:
        return None
    if s["state"] == "paused" and s["marker"] is None:
        return None                                  # the cool-down at a first start: the next poll tries again
    return Alert(f"feed_down:{t.date().isoformat()}", "feed_down", 4, "Price feed down: no EUR/USD signals can come",
                 s["text"] + ". T1-M and the A+ need these EUR/USD prices. One alert a day.")
