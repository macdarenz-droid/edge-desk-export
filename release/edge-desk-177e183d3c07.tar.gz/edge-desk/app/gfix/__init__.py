"""G-FIX paper stream: sell gold into the 10:30 London fix (docs/GFIX_DESIGN.md). Paper only: never an order."""
