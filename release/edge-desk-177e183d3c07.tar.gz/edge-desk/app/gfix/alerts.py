"""G-FIX phone alerts (queued once by key through app/notify/alerts.py; every title says paper; never an order).

  kind              pri  key                          when
  gfix_signal        4   gfix_signal:<day>            a rule day, as soon as 10:14 London is in the data (before 10:32)
  gfix_result        2   gfix_result:<day>            a rule day's 10:31 close is in the data (within 12 h)
  gfix_data_stale    3   gfix_data_stale:<day>        10:05-10:35 London: gold prices over 5 minutes behind, once a day
An alert made more than 3 minutes after its moment starts "Late".
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from app.gfix import rule
from app.notify.alerts import Alert
from app.timeutil import LONDON, MELBOURNE

KINDS = frozenset({"gfix_signal", "gfix_result", "gfix_data_stale"})
LATE_AFTER_S = 180
LABEL = "Paper only. Probable, not proven."


def _dt(ts: int) -> datetime:
    return datetime.fromtimestamp(int(ts), timezone.utc)


def london_hm(ts: int) -> str:
    return f"{_dt(ts).astimezone(LONDON):%H:%M}"


def melb_hm(ts: int) -> str:
    return _dt(ts).astimezone(MELBOURNE).strftime("%I:%M %p").lstrip("0").lower()


def both(ts: int) -> str:
    return f"{london_hm(ts)} London ({melb_hm(ts)} Melbourne)"


def usd(x: float) -> str:
    return f"{x:,.2f}"


def entry_ts(day: date) -> int:
    return rule.minute_ts(day, rule.ENTRY_FROM)             # 10:15:00 London


def exit_ts(day: date) -> int:
    return rule.minute_ts(day, rule.EXIT_MIN + 1)           # 10:32:00 London (the end of the 10:31 minute)


def signal_expires_ts(key: str) -> int | None:
    """A gfix_signal is no use once its day's 10:31 minute has ended (key gfix_signal:<day>)."""
    try:
        return exit_ts(date.fromisoformat(key.split(":", 1)[1]))
    except (IndexError, ValueError):
        return None


def size_line(m: dict, risk_usd: float, lot_oz: float) -> str:
    stop_usd = rule.STOP_ADR * float(m["adr"])
    return (f"Suggested size: {rule.lots(risk_usd, stop_usd, lot_oz):.2f} lots (${risk_usd:g} risk at a "
            f"${stop_usd:,.2f} stop, {lot_oz:g} oz a lot)")


def signal(day: date, m: dict, risk_usd: float, lot_oz: float, now_ts: int) -> Alert:
    """m: rule.measure() of a rule day, decided (10:14 known)."""
    at = entry_ts(day)
    late = now_ts - at > LATE_AFTER_S
    stop_usd = rule.STOP_ADR * float(m["adr"])
    lines = []
    if late:
        lines.append(f"Late: the card was due at {both(at)}, {max(1, (now_ts - at) // 60)} min ago.")
    lines += [f"Paper sell gold at {both(at)}; buy back inside the 10:31 London minute ({melb_hm(exit_ts(day) - 60)}"
              " Melbourne), not later: gold bounces in the 10:32 minute.",
              f"Reference {usd(m['c1014'])} (10:14 close). Stop {usd(stop_usd)} above your fill"
              f" ({usd(m['c1014'] + stop_usd)} from the reference): 0.3 x ADR20.",
              size_line(m, risk_usd, lot_oz) + ".",
              f"ADR20 ${usd(m['adr'])} = {100 * m['adr_pct']:.2f}% of price; gold below its 06:59 close"
              f" ({usd(m['c0659'])} to {usd(m['c1014'])}).",
              LABEL, rule.TESTED]
    title = ("Late: " if late else "") + "G-FIX SELL gold now (paper)"
    return Alert(f"gfix_signal:{day.isoformat()}", "gfix_signal", 4, title, "\n".join(lines))


def result(day: date, m: dict, now_ts: int) -> Alert:
    late = now_ts - exit_ts(day) > LATE_AFTER_S
    how = "stopped" if m["stopped"] else "out at the 10:31 close"
    title = ("Late: " if late else "") + f"G-FIX {day:%a %d %b}: {m['r']:+.2f}R (paper)"
    body = "\n".join([
        f"Paper sell {usd(m['entry_mid'])}, {how}: {m['net_usd']:+.2f} US$ an ounce after research cost"
        f" ({m['r']:+.2f}R).",
        f"At the feed's own bid and ask: {m['feed_net_usd']:+.2f} US$ an ounce ({m['feed_r']:+.2f}R).",
        LABEL])
    return Alert(f"gfix_result:{day.isoformat()}", "gfix_result", 2, title, body)


def no_trade(day: date, reason: str, now_ts: int) -> Alert:
    """A rule day's card was shown but no gold price came from 10:15 to 10:20 London: no paper trade."""
    return Alert(f"gfix_result:{day.isoformat()}", "gfix_result", 2, f"G-FIX {day:%a %d %b}: no paper trade",
                 f"No measurement: {reason}. {LABEL}")


def stale_exit(day: date, reason: str, now_ts: int) -> Alert:
    """A rule day's paper sell was in at 10:15 but no gold price came 10:26-10:31 London (gap guard): no result."""
    return Alert(f"gfix_result:{day.isoformat()}", "gfix_result", 2, f"G-FIX {day:%a %d %b}: no exit price (paper)",
                 "The paper sell was in from 10:15 London, but no gold price came 10:26-10:31, so there is no exit"
                 f" price and no result ({reason}). If you took it, check your own close. {LABEL}")


def data_stale(marker: int | None, now_ts: int, day: date, halted: str | None = None) -> Alert:
    what = ("No gold 1-minute prices are stored yet." if marker is None else
            f"Gold 1-minute prices are {(now_ts - int(marker)) // 60} min behind (complete to {both(int(marker))}).")
    fix = (f" The gold feed stopped ({halted}); EUR/USD goes on. After the cause is fixed: python -m app feed"
           " --reset-halt, then restart edge-desk-feed." if halted else " Check the feed (edge-desk-feed).")
    return Alert(f"gfix_data_stale:{day.isoformat()}", "gfix_data_stale", 3, "G-FIX: gold prices late",
                 what + " The G-FIX card cannot be made until they catch up." + fix)
