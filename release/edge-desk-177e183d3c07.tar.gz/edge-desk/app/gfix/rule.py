"""G-FIX v1, the rule (research/volume/round23/GFIX_PAPER_SPEC.md on the research branch). Pure code: no database, no
clock. The live step (app/gfix/step.py) and the parity replay (evidence/gfix/replay_parity.py) both call measure().

XAU/USD, London weekdays, mid = (bid + ask) / 2, US$ an ounce:
  ADR20   the mean of (high - low) over 00:00-20:59 London of the previous 20 weekdays that have prices in that window
          (at least 10 of them; today not included)
  c0659, c1014  the close of the 06:59 and 10:14 minutes (the last close at or before that minute, that day)
  entry   the first open from 10:15 to 10:20; exit: the close of the 10:31 minute
  stop    entry + 0.3 x ADR20, hit when the ask (mid high + half the research spread) reaches it from the entry minute
  cost    research: half of 0.0109% of the entry price off the entry and onto the exit, $0.05 commission, $0.10 more on a
          stop; feed: sell at the bid at entry, buy at the ask at exit, $0.05 (a stopped trade keeps the research result,
          as the research's bid/ask check does)
  rule day  ADR20 / c1014 >= 0.0147 and c1014 < c0659, both known before 10:15
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from app.timeutil import LONDON

RULE_ID = "GFIX-V1"
NAME = "G-FIX"
RANGE_TO = 20 * 60 + 59          # the range window 00:00-20:59 London
ADR_DAYS, ADR_MIN_DAYS = 20, 10
M0659, M1014 = 6 * 60 + 59, 10 * 60 + 14
ENTRY_FROM, ENTRY_TO = 10 * 60 + 15, 10 * 60 + 20
EXIT_MIN = 10 * 60 + 31
FRESH_MIN = 15                   # gap guard (10 Nov 2026): 06:59, 10:14 and the exit close must be a bar this recent
STOP_ADR = 0.3
RANGE_FLOOR = 0.0147
SHARE = 0.000109                 # the owner's gold spread: $0.45 at $4,128
COMM = 0.05                      # $5 a 100-ounce lot round trip
SLIP = 0.10                      # more on a stop
TESTED = ("Research 2021 - Nov 2026: 267 rule days, 61% winners, +0.041R a trade; built on 2006-2020, so not a clean "
          "test. Paper only. Probable, not proven.")


def london_midnight_ts(day: date) -> int:
    return int(datetime(day.year, day.month, day.day, tzinfo=LONDON).timestamp())


def minute_ts(day: date, minute: int) -> int:
    """Unix seconds of a London minute of the day (London's clock changes on Sundays only, never on a weekday)."""
    return int(datetime(day.year, day.month, day.day, minute // 60, minute % 60, tzinfo=LONDON).timestamp())


@dataclass
class Day:
    """One London weekday's bars by minute of the day: mid o/h/l/c and bid/ask o/c."""
    day: date
    o: dict = field(default_factory=dict)
    h: dict = field(default_factory=dict)
    lo: dict = field(default_factory=dict)
    c: dict = field(default_factory=dict)
    bid_o: dict = field(default_factory=dict)
    ask_c: dict = field(default_factory=dict)
    ask_o: dict = field(default_factory=dict)
    bid_c: dict = field(default_factory=dict)
    known_to: int = 0            # minutes below this are final


def day_of(day: date, rows, complete_through: int | None) -> Day:
    """rows: m1_bar_xau-like rows (ts, bid_/ask_ OHLC). Only that London day's rows below complete_through (None: the
    whole day is final)."""
    lo = london_midnight_ts(day)
    hi = london_midnight_ts(day + timedelta(days=1))
    end = hi if complete_through is None else min(hi, int(complete_through))
    d = Day(day)
    for r in rows:
        ts = int(r["ts"])
        if ts < lo or ts >= end:
            continue
        m = (ts - lo) // 60
        d.o[m] = (float(r["bid_o"]) + float(r["ask_o"])) / 2
        d.h[m] = (float(r["bid_h"]) + float(r["ask_h"])) / 2
        d.lo[m] = (float(r["bid_l"]) + float(r["ask_l"])) / 2
        d.c[m] = (float(r["bid_c"]) + float(r["ask_c"])) / 2
        d.bid_o[m], d.ask_o[m] = float(r["bid_o"]), float(r["ask_o"])
        d.bid_c[m], d.ask_c[m] = float(r["bid_c"]), float(r["ask_c"])
    d.known_to = 24 * 60 if end >= hi else max(0, (end - lo) // 60)
    return d


def day_range(d: Day) -> float | None:
    """High minus low of the mid over 00:00-20:59 London, or None without prices there."""
    hs = [v for m, v in d.h.items() if m <= RANGE_TO]
    ls = [v for m, v in d.lo.items() if m <= RANGE_TO]
    return (max(hs) - min(ls)) if hs and ls else None


def adr20(prev_ranges: list[float]) -> float | None:
    """prev_ranges: the ranges of earlier weekdays with prices, oldest first (today not included)."""
    last = [x for x in prev_ranges if x is not None][-ADR_DAYS:]
    return sum(last) / len(last) if len(last) >= ADR_MIN_DAYS else None


def close_at(d: Day, m: int, book=None) -> float | None:
    book = d.c if book is None else book
    for k in range(m, -1, -1):
        if k in book:
            return book[k]
    return None


def fresh_close(d: Day, m: int, back: int, book=None) -> float | None:
    """The last close at or before minute m, only from a bar in the `back` minutes up to m (else None)."""
    book = d.c if book is None else book
    return next((book[k] for k in range(m, m - back, -1) if k in book), None)


def measure(d: Day, adr: float | None) -> dict:
    """Everything the log row holds, as far as the known minutes show. phase: 'wait' (10:14 not known yet), 'decided'
    (conditions known, entry or exit not yet), 'final' (10:31 known: the row can be written), or 'no_measure'."""
    out = {"day": d.day.isoformat(), "adr": adr, "phase": "wait", "reason": "", "rule_day": 0}
    if d.known_to <= M1014:
        return out
    c0659, c1014 = fresh_close(d, M0659, FRESH_MIN), fresh_close(d, M1014, FRESH_MIN)
    out.update(c0659=c0659, c1014=c1014)
    if adr is None:
        out.update(phase="no_measure" if d.known_to > EXIT_MIN else "decided", reason="fewer than 10 earlier weekdays")
        return out
    if c1014 is None:
        out.update(phase="no_measure" if d.known_to > EXIT_MIN else "decided", reason="no price 10:00-10:14")
        return out
    out["adr_pct"] = adr / c1014
    out["cond_range"] = 1 if adr / c1014 >= RANGE_FLOOR else 0
    out["cond_down"] = 1 if (c0659 is not None and c1014 < c0659) else 0
    out["rule_day"] = out["cond_range"] * out["cond_down"]
    out["phase"] = "decided"
    j = next((m for m in range(ENTRY_FROM, ENTRY_TO + 1) if m in d.o), None)
    if j is None:
        if d.known_to > ENTRY_TO:
            out.update(phase="no_measure", reason="no price 10:15-10:20")
        return out
    o = d.o[j]
    hs = SHARE / 2 * o
    F = o - hs
    S = F + STOP_ADR * adr
    out.update(entry_ts=minute_ts(d.day, j), entry_mid=o, entry_bid=d.bid_o[j], entry_ask=d.ask_o[j], stop=S)
    if d.known_to <= EXIT_MIN:
        return out
    cexit = fresh_close(d, EXIT_MIN, 6)
    X, stopped = None, 0
    for k in range(j, EXIT_MIN + 1):
        if k in d.h and d.h[k] + hs >= S:
            X = max(S, d.o[k] + hs) if k > j else S
            stopped = 1
            break
    if X is None and cexit is None:          # no bar 10:26-10:31: no exit price, no result (gap guard)
        out.update(phase="no_measure", reason="stale exit price (no price 10:26-10:31)")
        return out
    if X is None:
        X = cexit + hs
    net = F - X - COMM - (SLIP if stopped else 0.0)
    risk = STOP_ADR * adr
    exit_bid, exit_ask = fresh_close(d, EXIT_MIN, 6, d.bid_c), fresh_close(d, EXIT_MIN, 6, d.ask_c)
    feed = net if stopped else d.bid_o[j] - exit_ask - COMM
    out.update(phase="final", exit_bid=exit_bid, exit_ask=exit_ask, stopped=stopped, net_usd=net, r=net / risk,
               feed_net_usd=feed, feed_r=feed / risk)
    return out


def lots(risk_usd: float, stop_usd: float, lot_oz: float) -> float:
    """Lots for a dollar risk at a stop distance in US$ an ounce, rounded DOWN to 0.01."""
    if stop_usd <= 0 or risk_usd <= 0 or lot_oz <= 0:
        return 0.0
    return int(round(risk_usd * 10000) // round(stop_usd * lot_oz * 100)) / 100.0
