"""G-FIX live step: run by the method worker every ~30 s after T1-M (app/suggest/service.py), in its own try. Paper only:
it never touches an order, the planner, the paper book or the day guard.

Each run, from the stored XAU_USD bars (m1_bar_xau) below the gold marker only (feed_state xau:complete_through):
  1. today (a London weekday) and up to 5 earlier weekdays since the first run that have no gfix_day row yet;
  2. ADR20 from the earlier weekdays' 00:00-20:59 ranges (worked out once a day), rule.measure() on the day's bars;
  3. a rule day: an offered suggestion (rule GFIX-V1) and the gfix_signal alert, while the 10:31 minute is ahead;
  4. once 10:31 is in the data: one gfix_day row (every weekday, rule day or not), and on a rule day the suggestion's
     own result and the gfix_result alert. A restart works the same days out again and writes nothing twice.
"""
from __future__ import annotations

import json
import logging
import sqlite3
from datetime import date, datetime, timedelta, timezone
from hashlib import sha256
from pathlib import Path

from app import db
from app.gfix import alerts as GA
from app.gfix import rule
from app.timeutil import LONDON, to_iso

log = logging.getLogger("app.gfix")
CATCH_UP_DAYS = 40                 # earlier weekdays (since the start) still logged after a stop or a gold gap; the
                                   # gold bars are kept 60 days, so a day without any is logged as no measurement
LOOK_BACK_DAYS = 45                # calendar days searched for 20 earlier weekdays with prices
STALE_AFTER_S = 5 * 60
STALE_FROM, STALE_TO = 10 * 60 + 5, 10 * 60 + 35
RESULT_ALERT_FOR_S = 12 * 3600
CODE_SHA256 = sha256(Path(rule.__file__).read_bytes()).hexdigest()
ROW_FIELDS = ("adr", "adr_pct", "c0659", "c1014", "cond_range", "cond_down", "rule_day", "entry_ts", "entry_mid",
              "entry_bid", "entry_ask", "exit_bid", "exit_ask", "stop", "stopped", "net_usd", "r", "feed_net_usd",
              "feed_r")


def get_state(conn: sqlite3.Connection, key: str) -> str | None:
    r = conn.execute("SELECT value FROM gfix_state WHERE key = ?", (key,)).fetchone()
    return None if r is None else r[0]


def set_state(conn: sqlite3.Connection, key: str, value) -> None:
    with db.transaction(conn):
        conn.execute("INSERT INTO gfix_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET"
                     " value = excluded.value", (key, str(value)))


def gold_marker(conn: sqlite3.Connection) -> int | None:
    from app.feed.oanda import GOLD, complete_through
    return complete_through(conn, GOLD)


def london_now(now: datetime) -> tuple[date, int]:
    t = now.astimezone(LONDON)
    return t.date(), t.hour * 60 + t.minute


def day_range_db(conn: sqlite3.Connection, day: date) -> float | None:
    """High minus low of the mid over 00:00-20:59 London of one day, from the stored bars."""
    lo, hi = rule.london_midnight_ts(day), rule.minute_ts(day, rule.RANGE_TO + 1)
    r = conn.execute("SELECT MAX((bid_h + ask_h) / 2), MIN((bid_l + ask_l) / 2) FROM m1_bar_xau WHERE ts >= ? AND ts < ?",
                     (lo, hi)).fetchone()
    return None if r is None or r[0] is None else float(r[0]) - float(r[1])


class GfixStep:
    def __init__(self, conn: sqlite3.Connection, cfg):
        self.conn, self.cfg = conn, cfg
        self._adr: dict = {}

    def adr_for(self, day: date, marker: int) -> float | None:
        """ADR20 of a day (its earlier weekdays' ranges), worked out once all of them are final."""
        if day in self._adr:
            return self._adr[day]
        if marker < rule.london_midnight_ts(day):
            return None                                     # yesterday's bars are not all in yet
        ranges, d = [], day - timedelta(days=1)
        while len(ranges) < rule.ADR_DAYS and (day - d).days <= LOOK_BACK_DAYS:
            if d.weekday() < 5:
                rg = day_range_db(self.conn, d)
                if rg is not None:
                    ranges.append(rg)
            d -= timedelta(days=1)
        adr = rule.adr20(list(reversed(ranges)))
        self._adr[day] = adr
        return adr

    def run(self, now: datetime) -> dict:
        c = self.cfg.gfix
        if not c.enabled:
            return {"status": "off"}
        conn = self.conn
        now_ts = int(now.timestamp())
        marker = gold_marker(conn)
        out = {"status": "ran", "marker": marker, "queued": [], "days": []}
        today, minute = london_now(now)
        self._stale(today, minute, marker, now, out)
        if marker is None or not self.cfg.feed.enabled:
            out["status"] = "no prices"
            return out
        if get_state(conn, "started_ts") is None:
            set_state(conn, "started_ts", now_ts)
        start_day = datetime.fromtimestamp(int(get_state(conn, "started_ts")), LONDON).date()
        for day in self._days(today, start_day):
            out["days"].append(self._day(day, today, marker, now, out))
        return out

    def _q(self, alert, now: datetime, out: dict) -> None:
        from app.notify.alerts import queue_alert
        if queue_alert(self.conn, alert, now):
            out["queued"].append(alert.key)

    def _stale(self, today: date, minute: int, marker: int | None, now: datetime, out: dict) -> None:
        if today.weekday() >= 5 or not (STALE_FROM <= minute < STALE_TO) or not self.cfg.feed.enabled:
            return
        now_ts = int(now.timestamp())
        if marker is None or now_ts - int(marker) > STALE_AFTER_S:      # one alert a day at most (red team, 10 Nov)
            from app.feed.oanda import state as feed_state
            self._q(GA.data_stale(marker, now_ts, today, feed_state(self.conn, "xau:halted")), now, out)

    def _days(self, today: date, start_day: date) -> list[date]:
        done = {r[0] for r in self.conn.execute("SELECT day FROM gfix_day WHERE stream = ? AND day >= ?",
                                                 (rule.RULE_ID, (today - timedelta(days=CATCH_UP_DAYS + 3)).isoformat()))}
        out, d, n = [], today, 0
        while d >= start_day and n <= CATCH_UP_DAYS:
            if d.weekday() < 5:
                if d.isoformat() not in done:
                    out.append(d)
                n += 1
            d -= timedelta(days=1)
        return sorted(out)

    def _day(self, day: date, today: date, marker: int, now: datetime, out: dict) -> dict:
        conn, c = self.conn, self.cfg.gfix
        now_ts = int(now.timestamp())
        lo = rule.london_midnight_ts(day)
        end = min(int(marker), rule.minute_ts(day, rule.EXIT_MIN + 1))
        if end <= rule.minute_ts(day, rule.M1014):
            return {"day": day.isoformat(), "phase": "wait"}
        rows = conn.execute("SELECT * FROM m1_bar_xau WHERE ts >= ? AND ts < ? ORDER BY ts", (lo, end)).fetchall()
        d = rule.day_of(day, rows, end)
        if int(marker) > rule.minute_ts(day, rule.EXIT_MIN + 1):
            d.known_to = 24 * 60                            # the rest of the day is not needed: 10:31 is final
        m = rule.measure(d, self.adr_for(day, int(marker)))
        if day == today:                                    # what Today shows before the row is written
            set_state(conn, "today", json.dumps({k: m.get(k) for k in ("day", "phase", "reason", "rule_day", "adr",
                                                                        "adr_pct", "c0659", "c1014", "cond_range",
                                                                        "cond_down", "entry_mid", "stop")}))
        if m["rule_day"] and m["phase"] == "decided" and now_ts < GA.exit_ts(day):
            self._suggest(day, m, now)                      # only a card he could see is a suggestion
            from app.paper2 import sizes           # % sizes per account, then the risk budget (owner, 10-11 Nov)
            self._q(sizes.card(self.conn, self.cfg, now, GA.signal(day, m, c.risk_usd, c.lot_oz, now_ts), "gfix",
                               rule.STOP_ADR * float(m["adr"]), c.risk_usd), now, out)
        if m["phase"] in ("final", "no_measure"):
            self._write(day, m, now)
            if m["rule_day"] and m["phase"] == "no_measure":     # a card was shown, but no price came 10:15-10:20
                entered = m.get("entry_ts") is not None             # or (gap guard) the exit price is stale
                self._no_trade(day, m, now, entered)
                if now_ts - GA.exit_ts(day) < RESULT_ALERT_FOR_S:
                    self._q((GA.stale_exit if entered else GA.no_trade)(day, m.get("reason") or "no price", now_ts),
                            now, out)
            if m["rule_day"] and m["phase"] == "final":
                self._settle(day, m, now)
                if now_ts - GA.exit_ts(day) < RESULT_ALERT_FOR_S:
                    self._q(GA.result(day, m, now_ts), now, out)
        return {"day": day.isoformat(), "phase": m["phase"], "rule_day": m["rule_day"]}

    def _write(self, day: date, m: dict, now: datetime) -> None:
        vals = [m.get(k) for k in ROW_FIELDS]
        with db.transaction(self.conn):
            self.conn.execute(
                f"INSERT INTO gfix_day (stream, day, status, reason, {', '.join(ROW_FIELDS)}, made_utc)"
                f" VALUES (?, ?, ?, ?, {', '.join('?' * len(ROW_FIELDS))}, ?) ON CONFLICT (stream, day) DO NOTHING",
                (rule.RULE_ID, day.isoformat(), "measured" if m["phase"] == "final" else "no_measure",
                 m.get("reason") or "", *vals, to_iso(now)))

    def _suggest(self, day: date, m: dict, now: datetime) -> int:
        from app.suggest import log as L
        at = GA.entry_ts(day)
        stop_usd = rule.STOP_ADR * float(m["adr"])
        sid, _ = L.add_suggestion(self.conn, {
            "key": f"lead:{rule.RULE_ID}:{at}:-1", "source": "lead", "rule_id": rule.RULE_ID,
            "code_sha256": CODE_SHA256, "offered": 1, "reason": None, "placed_ts": at, "side": -1,
            "entry": round(float(m["c1014"]), 3), "stop": round(float(m["c1014"]) + stop_usd, 3), "target": None,
            "expiry_ts": GA.exit_ts(day), "score": None, "tier": None, "w": 1.0, "ticks": {},
            "record_line": rule.TESTED, "late": 1 if int(now.timestamp()) - at > GA.LATE_AFTER_S else 0}, now=now)
        return sid

    def _no_trade(self, day: date, m: dict, now: datetime, entered: bool = False) -> None:
        from app.suggest import log as L
        row = L.by_key(self.conn, f"lead:{rule.RULE_ID}:{GA.entry_ts(day)}:-1")
        if row is not None and L.result(self.conn, row["id"]) is None:
            L.settle(self.conn, row["id"], {"outcome": "filled" if entered else "no_trade",
                                            "exit_reason": "stale exit price" if entered else m.get("reason") or "no price",
                                            "unit": "R"}, now=now)

    def _settle(self, day: date, m: dict, now: datetime) -> None:
        from app.suggest import log as L
        row = L.by_key(self.conn, f"lead:{rule.RULE_ID}:{GA.entry_ts(day)}:-1")
        if row is not None and L.result(self.conn, row["id"]) is None:
            L.settle(self.conn, row["id"], {"outcome": "filled", "exit_reason": "stop" if m["stopped"] else "time",
                                      "R_20": float(m["r"]), "unit": "R"}, now=now)


def step(conn: sqlite3.Connection, cfg, now: datetime, s: GfixStep | None = None) -> dict | None:
    """One G-FIX run for the method worker: an exception is logged and never leaves (the loop goes on)."""
    try:
        r = (s or GfixStep(conn, cfg)).run(now)
    except Exception:                                       # noqa: BLE001  (logged; the loop goes on)
        log.exception("G-FIX step failed")
        return None
    if r.get("queued"):
        log.info("G-FIX: %s alerts queued (%s)", len(r["queued"]), ", ".join(r["queued"]))
    return r
