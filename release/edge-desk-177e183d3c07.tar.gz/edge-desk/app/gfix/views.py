"""G-FIX on Today: one block in "Paper streams" (app/t1m/views.py lists it after T1-M). Every word is made here."""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime

from app.gfix import alerts as GA
from app.gfix import rule
from app.gfix.step import get_state, london_now

FALL_FLOOR = 0.0002              # health: the 10:15-10:31 fall on all weekdays, last 60, under 0.02% of price
SPREAD_CEIL = 0.0002             # health: a spread at 10:15 above 0.02% of price


def _rows(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute("SELECT * FROM gfix_day WHERE stream = ? AND status = 'measured'"
                                          " ORDER BY day", (rule.RULE_ID,))]


def _avg(xs):
    return sum(xs) / len(xs) if xs else None


def totals(rows: list[dict]) -> dict:
    rd = [r for r in rows if r["rule_day"]]
    last60 = rows[-60:]
    falls = [(r["entry_mid"] - (r["exit_bid"] + r["exit_ask"]) / 2) / r["entry_mid"] for r in last60
             if r["exit_bid"] is not None and r["exit_ask"] is not None]
    spreads = [(r["entry_ask"] - r["entry_bid"]) / r["entry_mid"] for r in rows if r["entry_ask"] is not None]
    return {"rule_n": len(rd), "rule_R": _avg([r["r"] for r in rd]), "rule_feed_R": _avg([r["feed_r"] for r in rd]),
            "rule_win": _avg([1.0 if r["net_usd"] > 0 else 0.0 for r in rd]),
            "first40_R": _avg([r["r"] for r in rd[:40]]) if len(rd) >= 40 else None,
            "all_n": len(rows), "all_R": _avg([r["r"] for r in rows]), "all_feed_R": _avg([r["feed_r"] for r in rows]),
            "fall60": _avg(falls) if len(falls) >= 60 else None, "fall60_n": len(falls),
            "last_spread": spreads[-1] if spreads else None}


def health(t: dict) -> list[str]:
    out = []
    if t["rule_n"] >= 60 and t["rule_R"] >= 0.03:
        out.append(f"Better: {t['rule_n']} rule-day trades averaging {t['rule_R']:+.3f}R (60 or more at +0.03R or more).")
    else:
        out.append(f"Better when 60 or more rule-day trades average +0.03R or more ({t['rule_n']} so far).")
    if t["first40_R"] is not None and t["first40_R"] <= 0:
        out.append(f"Worse: the first 40 rule-day trades average {t['first40_R']:+.3f}R (at or below zero).")
    if t["fall60"] is not None and t["fall60"] < FALL_FLOOR:
        out.append(f"Worse: the 10:15-10:31 fall over the last 60 weekdays is {100 * t['fall60']:.3f}% of price"
                   " (under 0.02%).")
    if t["last_spread"] is not None and t["last_spread"] > SPREAD_CEIL:
        out.append(f"Worse: the last 10:15 spread was {100 * t['last_spread']:.3f}% of price (above 0.02%).")
    return out


def _status(conn: sqlite3.Connection, cfg, now: datetime) -> tuple[str, list[str]]:
    day, minute = london_now(now)
    if day.weekday() >= 5:
        return "Weekend: no G-FIX", []
    if not cfg.feed.enabled:
        return "Off: no price feed", []
    from app.feed.oanda import state as feed_state
    from app.gfix.step import gold_marker
    halted, marker = feed_state(conn, "xau:halted"), gold_marker(conn)
    if halted:
        return (f"Gold feed stopped: {halted}", ["EUR/USD goes on. After the cause is fixed: python -m app feed"
                                                " --reset-halt, then restart edge-desk-feed."])
    if marker is None:
        return "No gold prices yet", []
    if now.timestamp() - marker > 15 * 60 and 7 * 60 <= minute <= 21 * 60 and day.weekday() < 5:
        return f"Gold prices late: complete to {GA.both(marker)}", []
    row = conn.execute("SELECT * FROM gfix_day WHERE stream = ? AND day = ?", (rule.RULE_ID, day.isoformat())).fetchone()
    try:
        t = json.loads(get_state(conn, "today") or "{}")
    except ValueError:
        t = {}
    if t.get("day") != day.isoformat():
        t = {}
    at = GA.entry_ts(day)
    if row is not None:
        r = dict(row)
        if r["status"] != "measured":
            return f"No measurement today: {r['reason']}", []
        what = "Rule day" if r["rule_day"] else "Not a rule day"
        return (f"{what}: the 10:15-10:31 paper sell made {r['r']:+.2f}R ({r['net_usd']:+.2f} US$ an ounce)",
                [f"At the feed's bid and ask: {r['feed_r']:+.2f}R."])
    if minute < rule.ENTRY_FROM or not t or t.get("phase") == "wait":
        return f"Waiting: the 10:15 London check ({GA.melb_hm(at)} Melbourne)", []
    if not t.get("rule_day"):
        why = []
        if t.get("adr_pct") is not None:
            why.append(f"range {100 * t['adr_pct']:.2f}% of price ({'at least' if t.get('cond_range') else 'under'}"
                       " 1.47%)")
        if t.get("cond_down") is not None:
            why.append("gold below its 06:59 close" if t.get("cond_down") else "gold not below its 06:59 close")
        return "Not a rule day today: logged only", ["; ".join(why).capitalize() + "." if why else ""]
    return (f"Rule day: paper sell from 10:15, buy back inside the 10:31 London minute ({GA.melb_hm(GA.exit_ts(day) - 60)}"
            " Melbourne)", [f"Reference {GA.usd(t['c1014'])}; stop {GA.usd(rule.STOP_ADR * t['adr'])} above the fill."])


def _size(conn: sqlite3.Connection, cfg, now: datetime) -> str:
    """% of each account; lots once today's stop (0.3 x ADR20) is known (owner, 11 Nov 2026)."""
    from app.paper2 import sizes
    try:
        t = json.loads(get_state(conn, "today") or "{}")
    except ValueError:
        t = {}
    adr = t.get("adr") if t.get("day") == london_now(now)[0].isoformat() else None
    return sizes.today(conn, cfg, "gfix", rule.STOP_ADR * float(adr) if adr else None) + " Stop 0.3 x ADR20."


def stream_block(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    c = cfg.gfix
    status, lines = _status(conn, cfg, now)
    t = totals(_rows(conn))
    if t["all_n"]:
        rd = (f"Rule days: {t['rule_n']} paper trades" + (
            f", {t['rule_R']:+.3f}R a trade, {100 * t['rule_win']:.0f}% winners (feed's bid and ask"
            f" {t['rule_feed_R']:+.3f}R)" if t["rule_n"] else ""))
        alld = (f"All weekdays: {t['all_n']} measured, {t['all_R']:+.3f}R a trade (feed's bid and ask"
                f" {t['all_feed_R']:+.3f}R).")
        fwd = rd + ". " + alld
    else:
        fwd = "Paper log: starts with the first weekday measured."
    return {"id": rule.RULE_ID, "title": f"{rule.NAME} gold (paper)", "label": "Paper", "status": status,
            "lines": [x for x in lines if x] + health(t),
            "size": _size(conn, cfg, now),
            "forward": fwd, "tested": GA.LABEL + " " + rule.TESTED.replace(" Paper only. Probable, not proven.", "")}
