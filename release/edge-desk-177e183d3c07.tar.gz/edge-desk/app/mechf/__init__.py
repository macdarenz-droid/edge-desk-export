"""ME-CHF paper stream: USD/CHF month-end 16:00 London fix fade. Paper only: never an order."""
