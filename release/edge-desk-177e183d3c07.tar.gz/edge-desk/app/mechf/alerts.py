"""ME-CHF phone alerts (queued once by key; every title says paper; never an order).

  kind            pri  key                     when
  me_signal        4   me_signal:<day>         16:00 London on the month-end day, once 15:59 is in the data (to 16:07)
  me_result        2   me_result:<day>         the 17:00 London exit, within 12 h
  me_data_stale    3   me_data_stale:<day>     15:55-17:05 London on the month-end day: USD/CHF over 5 minutes behind
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from app.gfix.rule import minute_ts
from app.mechf import rule
from app.notify.alerts import Alert
from app.timeutil import LONDON, MELBOURNE

KINDS = frozenset({"me_signal", "me_result", "me_data_stale"})
SIDE = {1: "buy", -1: "sell"}


def _dt(ts: int) -> datetime:
    return datetime.fromtimestamp(int(ts), timezone.utc)


def melb(ts: int) -> str:
    return _dt(ts).astimezone(MELBOURNE).strftime("%I:%M %p").lstrip("0").lower()


def entry_expires_ts(d: date) -> int:
    return minute_ts(d, rule.ENTRY + rule.SEARCH)               # 16:07 London


def signal_expires_ts(key: str) -> int | None:
    try:
        return entry_expires_ts(date.fromisoformat(key.split(":", 1)[1]))
    except (IndexError, ValueError):
        return None


def signal(d: date, m: dict, risk_usd: float, price: float, now_ts: int) -> Alert:
    side = int(m["side"])
    at = minute_ts(d, rule.C1559 + 1)
    late = now_ts - at > 180
    lines = []
    if late:
        lines.append(f"Late: the signal was at 16:00 London ({melb(at)} Melbourne), {max(1, (now_ts - at) // 60)} min"
                     " ago.")
    lines += [f"Month-end fix: USD/CHF {'up' if m['move'] > 0 else 'down'} {abs(m['move']):.1f} pips from 15:00 to 15:59"
              " London; fade it.",
              f"{SIDE[side].capitalize()} at the 16:01 London open ({melb(minute_ts(d, rule.ENTRY))} Melbourne), out at"
              f" 17:00 London ({melb(minute_ts(d, rule.C1659 + 1))} Melbourne).",
              f"Safety stop {m['adr']:.1f} pips (1 x ADR20).",
              f"Suggested size: {rule.lots(risk_usd, m['adr'], price):.2f} lots (${risk_usd:g} risk; 1 lot = 10 CHF a"
              f" pip, about ${10 / price:.2f} at {price:.4f}).", rule.TESTED]
    title = ("Late: " if late else "") + f"ME-CHF {SIDE[side].upper()} USD/CHF at 16:01 London (paper)"
    return Alert(f"me_signal:{d.isoformat()}", "me_signal", 4, title, "\n".join(lines))


def result(d: date, m: dict, now_ts: int) -> Alert:
    how = "stopped" if m["stopped"] else "out at 17:00 London"
    title = f"ME-CHF {d:%a %d %b}: {m['net']:+.1f} pips (paper)"
    body = "\n".join([
        f"Paper {SIDE[int(m['side'])]} {m['entry'] * rule.PIP:.5f}, {how} at {m['exit'] * rule.PIP:.5f}: {m['net']:+.1f}"
        " pips after the research's 0.95 pip (an estimate).",
        f"At the feed's own quotes: {m['feed_net']:+.1f} pips (spread {m['spread_entry']:.1f} pips at entry,"
        f" {m['spread_exit']:.1f} at exit).",
        "Paper only. Probable, not proven."])
    return Alert(f"me_result:{d.isoformat()}", "me_result", 2, title, body)


def data_stale(mk: int | None, now_ts: int, d: date, halted: str | None) -> Alert:
    what = ("No USD/CHF 1-minute prices are stored yet." if mk is None else
            f"USD/CHF 1-minute prices are {(now_ts - int(mk)) // 60} min behind.")
    fix = (f" The USD/CHF feed stopped ({halted}); EUR/USD goes on. After the cause is fixed: python -m app feed"
           " --reset-halt, then restart edge-desk-feed." if halted else " Check the feed (edge-desk-feed).")
    return Alert(f"me_data_stale:{d.isoformat()}", "me_data_stale", 3, "ME-CHF: USD/CHF prices late",
                 what + " Today's month-end signal cannot be made until they catch up." + fix)
