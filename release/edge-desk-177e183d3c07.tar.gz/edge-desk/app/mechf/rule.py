"""ME-CHF v1: USD/CHF month-end 16:00 London fix fade (research/volume/PAPER_STREAMS_2_SPEC.md part 2; frozen rule
research/volume/round16/FREEZE_monthend.md; research code research/volume/code/r16_monthend.py). Pure code.

Rows are London weekdays with at least one 1-minute bar. Prices: mid, in pips (price / 0.0001).
  day      the last London business day of the month; Good Friday, or the last-Monday bank holiday of May or August,
           moves it one business day back
  move     close at 15:59 (the last close 15:49-15:59) minus the first open 15:00-15:05; up -> SELL, down -> BUY
  entry    the first open 16:01-16:06 (mid); exit: the close at 16:59 (the last close 16:49-16:59)
  stop     1 x ADR20 (mean of the full-day mid range of the 20 rows before; at least 15) from the entry, on the mid;
           a stop exits at the stop less 0.5 pip
  pips     side x (exit - entry) - 0.95 (the research's cost, an estimate: USD/CHF was never measured on his account)
"""
from __future__ import annotations

from datetime import date, timedelta

RULE_ID = "MECHF-V1"
NAME = "ME-CHF"
PIP = 0.0001
O15, C1559, ENTRY, C1659 = 15 * 60, 15 * 60 + 59, 16 * 60 + 1, 16 * 60 + 59
SEARCH, FFILL = 6, 10
COST, SLIP = 0.95, 0.5
ADR_N, ADR_MIN = 20, 15
TESTED = "Paper only. Probable, not proven. 2021 - Oct 2026: 70 trades, 60% winners, +1.90 pips a trade."


def easter(year: int) -> date:
    """Western Easter Sunday (the anonymous Gregorian algorithm)."""
    a, b, c = year % 19, year // 100, year % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return date(year, month, day)


def monthend_day(year: int, month: int) -> date:
    nxt = date(year + (month == 12), month % 12 + 1, 1)
    d = nxt - timedelta(days=1)
    while d.weekday() >= 5:
        d -= timedelta(days=1)
    if d == easter(d.year) - timedelta(days=2) or (d.month in (5, 8) and d.weekday() == 0):
        d -= timedelta(days=1)
        while d.weekday() >= 5:
            d -= timedelta(days=1)
    return d


def day_range(d) -> float | None:
    """The full-day mid range in pips (an app.gfix.rule.Day)."""
    return (max(d.h.values()) - min(d.lo.values())) / PIP if d.h else None


def adr20(prev_ranges: list[float]) -> float | None:
    last = [x for x in prev_ranges[-ADR_N:] if x is not None]
    return sum(last) / len(last) if len(last) >= ADR_MIN else None


def _close(d, m: int) -> float | None:
    for k in range(m, m - FFILL - 1, -1):
        if k in d.c:
            return d.c[k]
    return None


def measure(d, adr: float | None) -> dict:
    """phase: 'wait' (15:59 not known), 'decided' (side known), 'final' (16:59 known), or 'skip' (with a reason)."""
    out = {"day": d.day.isoformat(), "phase": "wait", "side": 0, "adr": adr}
    if d.known_to <= C1559:
        return out
    o15 = next((d.o[O15 + j] for j in range(SEARCH) if O15 + j in d.o), None)
    c1559 = _close(d, C1559)
    if o15 is None or c1559 is None or c1559 == o15:
        out.update(phase="skip", reason="no move 15:00-15:59")
        return out
    move = (c1559 - o15) / PIP
    side = -1 if move > 0 else 1
    out.update(phase="decided", side=side, move=move)
    if adr is None:
        out.update(phase="skip", reason="no ADR20")
        return out
    em = next((ENTRY + j for j in range(SEARCH) if ENTRY + j in d.o), None)
    if em is None:
        if d.known_to > ENTRY + SEARCH - 1:
            out.update(phase="skip", reason="no price 16:01-16:06")
        return out
    ent = d.o[em] / PIP
    stop = ent - side * adr
    out.update(entry_min=em, entry=ent, stop=stop, entry_bid=d.bid_o[em], entry_ask=d.ask_o[em])
    if d.known_to <= C1659:
        return out
    cx = _close(d, C1659)
    if cx is None:
        out.update(phase="skip", reason="no price 16:49-16:59")
        return out
    hs = [d.h[m] / PIP for m in range(em, C1659 + 1) if m in d.h]
    ls = [d.lo[m] / PIP for m in range(em, C1659 + 1) if m in d.lo]
    ex, stopped = cx / PIP, False
    if (side > 0 and min(ls) <= stop) or (side < 0 and max(hs) >= stop):
        ex, stopped = stop - side * SLIP, True
    gross = side * (ex - ent)
    xm = max(k for k in range(C1659 - FFILL, C1659 + 1) if k in d.c)
    feed = gross - COST if stopped else side * ((d.bid_c[xm] if side > 0 else d.ask_c[xm])
                                                 - (d.ask_o[em] if side > 0 else d.bid_o[em])) / PIP
    out.update(phase="final", exit=ex, stopped=stopped, gross=gross, net=gross - COST, r=(gross - COST) / adr,
               exit_bid=d.bid_c[xm], exit_ask=d.ask_c[xm], feed_net=feed, feed_r=feed / adr,
               spread_entry=(d.ask_o[em] - d.bid_o[em]) / PIP, spread_exit=(d.ask_c[xm] - d.bid_c[xm]) / PIP)
    return out


def lots(risk_usd: float, stop_pips: float, usdchf: float) -> float:
    """1 lot of USD/CHF: 10 CHF a pip, so about 10 / USDCHF US$ a pip (an assumption: check the broker's contract)."""
    if risk_usd <= 0 or stop_pips <= 0 or usdchf <= 0:
        return 0.0
    usd_per_pip = 10.0 / usdchf                 # rounded to whole cents first, so a float never drops a lot step
    return int(round(risk_usd * 10000) // round(stop_pips * usd_per_pip * 100)) / 100.0
