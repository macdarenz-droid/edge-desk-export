"""ME-CHF live step: run by the method worker every ~30 s after PB-GBP, in its own try. Paper only. From the stored
USD_CHF bars (m1_bar_chf) below the feed's CHF marker only:
  1. fx_day summaries for every complete London weekday (ADR20 is the mean of the last 20 full-day ranges);
  2. on the month-end day (rule.monthend_day), once 15:59 London is in the data: the side ('signal', a suggestion and
     me_signal while 16:07 is ahead); once 16:59 is in: the result ('closed', me_result), or 'skipped' with the reason;
  3. a month-end day before today (this month's or the two before, since the first run) is finished after a stop.
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import date, datetime, timedelta
from hashlib import sha256
from pathlib import Path

from app.gfix.rule import minute_ts
from app.mechf import alerts as MA
from app.mechf import rule
from app.paper2 import common as C
from app.timeutil import LONDON

log = logging.getLogger("app.mechf")
INSTRUMENT = "USD_CHF"
STALE_FROM, STALE_TO, STALE_AFTER_S = 15 * 60 + 55, 17 * 60 + 5, 5 * 60
CODE_SHA256 = sha256(Path(rule.__file__).read_bytes()).hexdigest()
K = "mechf:"


def london_now(now: datetime) -> tuple[date, int]:
    t = now.astimezone(LONDON)
    return t.date(), t.hour * 60 + t.minute


def month_ends_near(today: date) -> list[date]:
    """The month-end days of this month and the two before, those not after today (a worker down across a whole
    month still finishes the one it missed; pair bars are kept 60 days)."""
    out = []
    for back in (2, 1, 0):
        y, m = today.year, today.month - back
        while m < 1:
            y, m = y - 1, m + 12
        d = rule.monthend_day(y, m)
        if d <= today:
            out.append(d)
    return out


class MeStep:
    def __init__(self, conn: sqlite3.Connection, cfg):
        self.conn, self.cfg = conn, cfg

    def run(self, now: datetime) -> dict:
        if not self.cfg.mechf.enabled:
            return {"status": "off"}
        conn = self.conn
        mk = C.marker(conn, INSTRUMENT)
        out = {"status": "ran", "marker": mk, "queued": [], "days": []}
        today, minute = london_now(now)
        if today in month_ends_near(today):
            self._stale(today, minute, mk, now, out)
        if mk is None or not self.cfg.feed.enabled:
            out["status"] = "no prices"
            return out
        C.summarize(conn, INSTRUMENT, mk, now)
        if C.get_state(conn, K + "started") is None:
            C.set_state(conn, K + "started", today.isoformat())
        start = date.fromisoformat(C.get_state(conn, K + "started"))
        for d in month_ends_near(today):
            if d >= start:
                out["days"].append(self._day(d, int(mk), now, out))
        return out

    def _stale(self, today: date, minute: int, mk: int | None, now: datetime, out: dict) -> None:
        if not (STALE_FROM <= minute < STALE_TO) or not self.cfg.feed.enabled:
            return
        if mk is None or now.timestamp() - int(mk) > STALE_AFTER_S:
            from app.feed.oanda import state as feed_state
            C.queue(self.conn, MA.data_stale(mk, int(now.timestamp()), today, feed_state(self.conn, "chf:halted")),
                    now, out)

    def _day(self, d: date, mk: int, now: datetime, out: dict) -> dict:
        conn = self.conn
        ev = C.events(conn, rule.RULE_ID, d)
        if "closed" in ev or "skipped" in ev:
            return {"day": d.isoformat(), "phase": "done"}
        if mk <= minute_ts(d, rule.C1559):
            return {"day": d.isoformat(), "phase": "wait"}
        prev = C.summaries(conn, INSTRUMENT, before=d, limit=rule.ADR_N)
        adr = rule.adr20([r["hi"] - r["lo"] for r in prev])
        day = C.day_bars(conn, INSTRUMENT, d, min(mk, minute_ts(d, rule.C1659 + 1)))
        if mk > minute_ts(d, rule.C1659 + 1):
            day.known_to = 24 * 60
        m = rule.measure(day, adr)
        now_ts = int(now.timestamp())
        if m["phase"] in ("decided", "final") and m["side"]:
            if C.event(conn, rule.RULE_ID, d, "signal", minute_ts(d, rule.C1559 + 1),
                       {k: m.get(k) for k in ("side", "move", "adr")}, now) and now_ts < MA.entry_expires_ts(d):
                price = (day.c[max(day.c)] if day.c else 1.0)
                self._suggest(d, m, price, now)
                from app.paper2 import sizes       # % sizes per account, then the risk budget (owner, 10-11 Nov)
                a = MA.signal(d, m, self.cfg.mechf.risk_usd, price, now_ts)
                C.queue(conn, sizes.card(conn, self.cfg, now, a, "mechf", float(m["adr"]) * rule.PIP,
                                         self.cfg.mechf.risk_usd), now, out)
        if m["phase"] == "final":
            data = {k: m[k] for k in ("side", "move", "adr", "entry", "exit", "stopped", "gross", "net", "r", "feed_net",
                                      "feed_r", "spread_entry", "spread_exit", "entry_min")}
            if C.event(conn, rule.RULE_ID, d, "closed", minute_ts(d, rule.C1659 + 1), data, now):
                self._settle(d, m, now)
                if now_ts - minute_ts(d, rule.C1659 + 1) < 12 * 3600:
                    C.queue(conn, MA.result(d, m, now_ts), now, out)
        elif m["phase"] == "skip":
            C.event(conn, rule.RULE_ID, d, "skipped", now_ts, {"reason": m.get("reason", "")}, now)
            self._settle(d, m, now, no_trade=True)
        return {"day": d.isoformat(), "phase": m["phase"]}

    def _key(self, d: date, side: int) -> str:
        return f"lead:{rule.RULE_ID}:{minute_ts(d, rule.C1559 + 1)}:{side}"

    def _suggest(self, d: date, m: dict, price: float, now: datetime) -> None:
        from app.suggest import log as L
        at = minute_ts(d, rule.C1559 + 1)
        L.add_suggestion(self.conn, {
            "key": self._key(d, int(m["side"])), "source": "lead", "rule_id": rule.RULE_ID,
            "code_sha256": CODE_SHA256, "offered": 1, "reason": None, "placed_ts": at, "side": int(m["side"]),
            "entry": round(price, 5), "stop": round(price - m["side"] * m["adr"] * rule.PIP, 5), "target": None,
            "expiry_ts": minute_ts(d, rule.C1659 + 1), "score": None, "tier": None, "w": 1.0, "ticks": {},
            "record_line": rule.TESTED, "late": 1 if now.timestamp() - at > 180 else 0}, now=now)

    def _settle(self, d: date, m: dict, now: datetime, no_trade: bool = False) -> None:
        from app.suggest import log as L
        if not m.get("side"):
            return
        row = L.by_key(self.conn, self._key(d, int(m["side"])))
        if row is None or L.result(self.conn, row["id"]) is not None:
            return
        res = ({"outcome": "no_trade", "exit_reason": m.get("reason") or "", "unit": "pips"} if no_trade else
               {"outcome": "filled", "exit_reason": "stop" if m["stopped"] else "time", "R_20": float(m["net"]),
                "unit": "pips"})
        L.settle(self.conn, row["id"], res, now=now)


def step(conn: sqlite3.Connection, cfg, now: datetime, s: MeStep | None = None) -> dict | None:
    try:
        r = (s or MeStep(conn, cfg)).run(now)
    except Exception:                                       # noqa: BLE001  (logged; the loop goes on)
        log.exception("ME-CHF step failed")
        return None
    if r.get("queued"):
        log.info("ME-CHF: %s alerts queued (%s)", len(r["queued"]), ", ".join(r["queued"]))
    return r
