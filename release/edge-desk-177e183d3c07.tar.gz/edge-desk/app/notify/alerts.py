"""Alerts for the owner's phone: built from ingest events and app state, queued once by key, sent by drain.

Kinds and priorities (1-5; Web Push urgency: 4-5 high, 3 normal, 1-2 low):
  orders_to_place 3   the day's plan at plan time: order cards, or "No trade today: <reason>"
  filled          3   position_opened
  closed          3   position_closed (5 when the broker stopped the account out)
  stop_moved      3   stop_changed (stop at entry, stop moved, target moved)
  daily_summary   2   once a day after notify.daily_summary_ny
  clock_mismatch  3   the broker clock rule disagrees with the clock the EA measured
  rule_break      3   a new trade_flag (no_stop is left to the hard incident below; size_above_risk is
                      shown but not alerted, app.risk.flags.INFO_FLAGS)
  move_stop_to_entry, close_or_trail  3   management reminders, once per position per level
  hard incidents  5   no_stop (also a stop removed later), bridge_silent, terminal_can_trade
  push_test       3   "Send test alert" on Settings (POST /api/push/test), sent at once
  news_soon       3   high-impact EUR or USD releases in news.alert_before_min, one per currency and minute; the
                      "in N min" title is set again when sent, and a send after the release is dropped
  news_result     3   the first number of a currency's release minute, with the read and no size (app/news/alerts.py)
  headline_policy 3   a Fed statement or ECB decision headline, at most 4 a day (app/news/headlines.py)
  headlines_halted 2  a headline feed stopped (a 404, a bad body or a wrong type), or failing for 6 hours (a 406
                      or a 5xx that never clears), once a day per feed
  aplus_order, aplus_filled, aplus_cancel, aplus_close_soon, aplus_closed, aplus_update, aplus_data_stale,
  aplus_silent, aplus_failing 3; aplus_skip, aplus_gap, aplus_data_back, aplus_check_back 2   the A+ on paper
                      (app/aplus/alerts.py): every title says paper, the order body carries its tested record and every
                      other body ends "Paper. Not proven."; a queued aplus_order is dropped once its 11:00 London
                      cancel has passed, and its push lives no longer than that cancel
  t1m_signal, t1m_close_now 4; t1m_data_stale, t1m_silent 3; t1m_day_result 2   T1-M on paper (app/t1m/alerts.py): every
                      title says paper; a sell signal, the 12:58 London "close at 13:00", stale prices, the day's
                      result; a queued t1m_signal is dropped once its day's 13:00 London exit has passed
  gfix_signal 4; gfix_data_stale 3; gfix_result 2   G-FIX gold on paper (app/gfix/alerts.py): the rule day's card at
                      10:15 London and its 10:32 result; a queued gfix_signal is dropped once its 10:31 minute has ended
  pb_signal, me_signal 4; pb_data_stale, me_data_stale 3; pb_result, me_result 2   PB-GBP and ME-CHF on paper
                      (app/pbgbp/alerts.py, app/mechf/alerts.py): the signal card and its result; a queued signal is
                      dropped once its entry has passed (22:15 London, Monday 00:15 for a Friday; 16:07 London)
  feed_down 4         the EUR/USD price feed stopped, never delivered or over an hour behind, 07:00-21:00 London on a
                      weekday, once a day (app/feed/health.py): no paper signal can come
  paper_overdue 4     a real MT5 position on a paper card's pair still open after that card's exit (app/paper2/budget.py);
                      every paper signal card also carries the risk-budget line (warning only)
Only hard incidents are loud (5: high urgency, kept a day for a phone that is offline, and the phone keeps
the notification on screen until it is touched); reminders and rule breaks are 3.
Text is detailed (prices, sides, sizes), names the account alias only and shows Melbourne time.
Results read R first, then % of the account, then money. A trade's R shows 2 decimals in the title and the
body; the day's R in the closed alert is EUR/USD only, as on Today and in the daily summary (the day guard
still counts every symbol). Guard states read as words ("Day done", "One more trade").

order_placed and order_removed raise no alert: the owner placed or removed the order himself.
"""
from __future__ import annotations

import sqlite3
import threading
from dataclasses import asdict, dataclass, is_dataclass
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal
from typing import Iterable

from app import db
from app.events import Event
from app.risk.day_guard import STATUS_WORDS, classify_trade
from app.risk.flags import guard_now
from app.timeutil import LONDON, MELBOURNE, fmt_melbourne, from_iso, london_open_utc, now_utc, to_iso

HARD = frozenset({"no_stop", "bridge_silent", "terminal_can_trade"})
KINDS = frozenset({"export_public", "orders_to_place", "filled", "closed", "stop_moved", "daily_summary", "clock_mismatch",
                   "rule_break", "move_stop_to_entry", "close_or_trail", "push_test",
                   # Part A: funded limits (A5) and no stop to entry (A6); Part B (B7): app/suggest/alerts.py
                   "funded_50", "funded_80", "risk_cap", "no_stop_to_entry",
                   # FundedNext account (30 Oct 2026): maximum loss used, open stops past a limit, inactivity
                   "funded_max_80", "funded_room", "funded_idle",
                   "suggestion", "suggestion_cancel", "suggestion_expiry", "lead_entry", "lead_exit",
                   "suggestion_result",
                   # News (app/news/alerts.py): a high-impact EUR or USD release in news.alert_before_min, and
                   # its first number; headlines (app/news/headlines.py)
                   "news_soon", "news_result", "headline_policy", "headlines_halted",
                   # The A+ on paper (app/aplus/alerts.py KINDS; tests/test_aplus_alerts.py keeps them equal)
                   "aplus_order", "aplus_filled", "aplus_cancel", "aplus_close_soon", "aplus_closed", "aplus_update",
                   "aplus_skip", "aplus_gap", "aplus_data_stale", "aplus_data_back", "aplus_silent", "aplus_failing",
                   "aplus_check_back",
                   # T1-M on paper (app/t1m/alerts.py KINDS; tests/test_t1m.py keeps them known here)
                   "t1m_signal", "t1m_close_now", "t1m_day_result", "t1m_data_stale", "t1m_silent",
                   # G-FIX gold on paper (app/gfix/alerts.py KINDS; tests/test_gfix.py keeps them known here)
                   "gfix_signal", "gfix_result", "gfix_data_stale",
                   # PB-GBP and ME-CHF on paper (app/pbgbp, app/mechf alerts.py KINDS; their tests keep them known here)
                   "pb_signal", "pb_result", "pb_data_stale", "me_signal", "me_result", "me_data_stale",
                   # a real position still open after its paper card's exit (app/paper2/budget.py)
                   "paper_overdue",
                   # the EUR/USD price feed down on a weekday (app/feed/health.py)
                   "feed_down"}) | HARD
# Paper-stream signal cards: a queued one is dropped once app/notify/push.expires_ts has passed.
SIGNAL_KINDS = frozenset({"t1m_signal", "gfix_signal", "pb_signal", "me_signal"})
FLAG_LABELS = {
    "after_max_losses": "trade after the loss limit",
    "after_loss_after_win": "trade after a loss that followed a win",
    "over_trades_after_win": "too many trades after a win",
    "over_open_risk": "too much open risk",
    "no_stop": "no stop",
    "early_close": "closed by hand before the target",
    "size_above_risk": "size above the risk limit",
    "stop_moved_away": "stop moved away",
    "no_checklist": "no setup check",
    "below_tier": "trade on a no-trade setup check",
    "over_tier_risk": "more risk than the setup check's tier",
    "no_stop_to_entry": "stop never moved to entry",
}
TITLE_MAX = 200
BODY_MAX = 4000
_EPS = 1e-9
# A hard incident whose send failed stays queued and is tried again after a back-off that doubles with its
# age (at least 1 min, at most 15 min), for up to a day; other alerts are marked failed (SEC-03).
HARD_RETRY_MIN_S = 60
HARD_RETRY_MAX_S = 15 * 60
HARD_GIVE_UP_S = 24 * 3600
# One drain at a time (the monitor every few seconds, "Send test alert" on demand): an alert is never sent twice.
_DRAIN_LOCK = threading.Lock()


@dataclass(frozen=True)
class Alert:
    key: str
    kind: str
    priority: int
    title: str
    body: str


# ---------------------------------------------------------------- formatting


def _num(x: float, places: int, sign: bool = True, sep: bool = False) -> str:
    """Round half up on the shown decimal value (3.965 -> 3.97), never "-0.0"."""
    q = Decimal(repr(float(x))).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP)
    if q.is_zero():
        q = abs(q)
    spec = ("+" if sign else "") + ("," if sep else "") + f".{places}f"
    return format(q, spec)


def _r(x: float, places: int = 1) -> str:
    return _num(x, places) + "R"


def _pct(x: float) -> str:
    return _num(x, 2) + "%"


def _money(cfg, x: float) -> str:
    return f"{_num(x, 2, sep=True)} {cfg.account.currency}"


def _sym(cfg, symbol: str) -> str:
    return "EUR/USD" if cfg.is_eurusd(symbol) else symbol


def _px(cfg, symbol: str, p: float | None) -> str:
    if p is None:
        return "none"
    return f"{p:.5f}" if cfg.is_eurusd(symbol) else f"{p:.6g}"


def _vol(v: float) -> str:
    return f"{v:g}"


def _mel(iso: str | None) -> str:
    return f"{fmt_melbourne(from_iso(iso))} Melbourne" if iso else "unknown time"


def _pip(cfg, symbol: str) -> float | None:
    return cfg.instrument.pip_size if cfg.is_eurusd(symbol) else None


def _differs(a: float | None, b: float | None) -> bool:
    if a is None or b is None:
        return (a is None) != (b is None)
    return abs(a - b) > _EPS


def _cap(text: str, n: int) -> str:
    return text if len(text) <= n else text[: n - 3] + "..."


def _as_dict(x) -> dict:
    if x is None:
        return {}
    if is_dataclass(x):
        return asdict(x)
    return dict(x)


def _guard_text(guard) -> str:
    g = _as_dict(guard)
    if not g:
        return ""
    status = g.get("status", "?")
    return f"Guard: {STATUS_WORDS.get(status, status)} ({g.get('reason', '')})"


def _streak_text(streak) -> str:
    s = _as_dict(streak)
    if not s:
        return ""
    if s.get("active"):
        floor = s.get("floor_r")
        return f"Streak: on, {_r(s.get('streak_r') or 0.0)}" + (f", floor {_r(floor)}" if floor is not None else "")
    return "Streak: off"


def _position_line(cfg, d: dict) -> str:
    return f"{_sym(cfg, d['symbol'])} {d['side']} {_vol(d['volume'])}"


# ---------------------------------------------------------------- events -> alerts


def filled(cfg, event: Event) -> Alert:
    d = event.data
    sym, open_price, sl, tp = d["symbol"], d["open_price"], d.get("sl"), d.get("tp")
    parts = [f"Entry {_px(cfg, sym, open_price)}"]
    pip = _pip(cfg, sym)
    if sl is None:
        parts.append("no stop")
    else:
        stop = f"stop {_px(cfg, sym, sl)}"
        if pip:
            stop += f" ({_num(abs(open_price - sl) / pip, 1, sign=False)} pips)"
        parts.append(stop)
    if tp is not None:
        tgt = f"target {_px(cfg, sym, tp)}"
        if sl is not None and abs(open_price - sl) > _EPS:
            tgt += f" ({_num(abs(tp - open_price) / abs(open_price - sl), 1, sign=False)}R)"
        parts.append(tgt)
    lines = [" · ".join(parts), f"Opened {_mel(d.get('open_utc'))} · {d['alias']}"]
    if not cfg.is_eurusd(sym):
        lines.append("Not EUR/USD: it still counts toward the day rules")
    return Alert(event.key, "filled", 3, f"Filled: {d['side']} {_sym(cfg, sym)} {_vol(d['volume'])} lots",
                 "\n".join(lines))


def stop_moved(cfg, event: Event) -> Alert | None:
    d = event.data
    sym, side, open_price = d["symbol"], d["side"], d["open_price"]
    old_sl, new_sl, old_tp, new_tp = d.get("old_sl"), d.get("new_sl"), d.get("old_tp"), d.get("new_tp")
    head = _position_line(cfg, d)
    if d.get("removed"):
        return Alert(event.key, "no_stop", 5, "Stop removed",
                     f"{head} at {_px(cfg, sym, open_price)} has no stop now (was {_px(cfg, sym, old_sl)})"
                     f" · {d['alias']}")
    if _differs(old_sl, new_sl):
        if d.get("to_entry"):
            return Alert(event.key, "stop_moved", 3, "Stop at entry",
                         f"{head} · stop {_px(cfg, sym, new_sl)} (was {_px(cfg, sym, old_sl)})"
                         f" · entry {_px(cfg, sym, open_price)} · {d['alias']}")
        line = f"{head} · stop {_px(cfg, sym, new_sl)} (was {_px(cfg, sym, old_sl)})"
        init = d.get("initial_sl")
        if init is not None and abs(open_price - init) > _EPS and new_sl is not None:
            direction = 1.0 if side == "buy" else -1.0
            line += f" · stop at {_r((new_sl - open_price) * direction / abs(open_price - init))}"
        return Alert(event.key, "stop_moved", 3, "Stop moved", f"{line} · {d['alias']}")
    if _differs(old_tp, new_tp):
        return Alert(event.key, "stop_moved", 3, "Target moved",
                     f"{head} · target {_px(cfg, sym, new_tp)} (was {_px(cfg, sym, old_tp)}) · {d['alias']}")
    return None


_CLOSE_TITLES = {"tp": "Target hit", "sl": "Stopped out", "be": "Stopped at entry", "manual": "Closed by hand",
                 "so": "Stop out by the broker"}


def closed(cfg, event: Event, day_r: float | None = None, guard=None) -> Alert:
    d = event.data
    sym = d["symbol"]
    reason = d.get("close_reason")
    r = d.get("r_net")
    word = _CLOSE_TITLES.get(reason, "Closed")
    title = f"{word} {_r(r, 2)}" if r is not None else f"{word}, R unknown"
    result = [_r(r, 2) if r is not None else "R unknown (no stop)"]
    if d.get("pct_of_balance") is not None:
        result.append(_pct(d["pct_of_balance"]))
    if d.get("net_profit") is not None:
        result.append(_money(cfg, d["net_profit"]))
    lines = [f"{_position_line(cfg, d)} · {_px(cfg, sym, d.get('open_price'))} -> {_px(cfg, sym, d.get('close_price'))}",
             " · ".join(result)]
    day = []
    if day_r is not None:
        day.append(f"Day: {_r(day_r, 2)}")
    if guard:
        day.append(_guard_text(guard))
    if day:
        lines.append(" · ".join(day))
    lines.append(f"Closed {_mel(d.get('close_utc'))} · {d['alias']}")
    return Alert(event.key, "closed", 5 if reason == "so" else 3, title, "\n".join(lines))


def no_stop(cfg, event: Event) -> Alert:
    d = event.data
    sym = d["symbol"]
    return Alert(event.key, "no_stop", 5, f"No stop: {d['side']} {_sym(cfg, sym)} {_vol(d['volume'])}",
                 f"Position open at {_px(cfg, sym, d['open_price'])} with no stop\n"
                 f"Opened {_mel(d.get('open_utc'))} · {d['alias']}")


def terminal_can_trade(cfg, event: Event) -> Alert:
    d = event.data
    return Alert(event.key, "terminal_can_trade", 5, "Bridge terminal can trade",
                 f"The terminal sending data for {d['alias']} has trading rights ({d.get('trade_mode', '?')}).\n"
                 "Log it in with the investor (read-only) password.")


def _offset(seconds: int) -> str:
    sign = "+" if seconds >= 0 else "-"
    s = abs(int(seconds))
    return f"{sign}{s // 3600:02d}:{s % 3600 // 60:02d}"


def clock_mismatch(cfg, event: Event) -> Alert:
    d = event.data
    return Alert(event.key, "clock_mismatch", 3, "Broker clock check",
                 f"Broker server clock measured at UTC{_offset(d['measured_offset_s'])}; the broker clock setting"
                 f" says UTC{_offset(d['rule_offset_s'])}. Trade times use the measured clock for now.\n"
                 f"If this comes back every day, the broker clock setting needs a check · {d['alias']}")


_BUILDERS = {"position_opened": filled, "stop_changed": stop_moved, "no_stop": no_stop,
             "terminal_can_trade": terminal_can_trade, "clock_mismatch": clock_mismatch}


def _day_r(conn: sqlite3.Connection, cfg, close_day: str | None) -> float | None:
    if conn is None or not close_day:
        return None
    with db._LOCK:   # one shared connection: reads take the same lock as writes
        syms = list(cfg.instrument.broker_symbols)            # EUR/USD only, as Today and the daily summary
        row = conn.execute("SELECT SUM(r_net) FROM trade WHERE book = 'mt5' AND account_alias = ? AND status = 'closed'"
                           f" AND close_trading_day = ? AND r_net IS NOT NULL AND symbol IN ({','.join('?' * len(syms))})",
                           (cfg.account.alias, close_day, *syms)).fetchone()
    return float(row[0]) if row and row[0] is not None else 0.0


def alerts_for_events(conn: sqlite3.Connection | None, cfg, events: Iterable[Event], now: datetime) -> list[Alert]:
    """Alerts for one snapshot's events, in event order. A stop removed in the same batch as the
    position's no_stop incident gives one alert (the incident)."""
    events = list(events)
    no_stop_ids = {e.data.get("position_id") for e in events if e.kind == "no_stop"}
    out: list[Alert] = []
    for e in events:
        if e.kind == "position_closed":
            guard = None
            if conn is not None:
                with db._LOCK:
                    guard = guard_now(conn, cfg, now, "mt5").to_dict()
            out.append(closed(cfg, e, _day_r(conn, cfg, e.data.get("close_trading_day")), guard))
            continue
        if e.kind == "stop_changed" and e.data.get("removed") and e.data.get("position_id") in no_stop_ids:
            continue
        builder = _BUILDERS.get(e.kind)
        a = builder(cfg, e) if builder else None
        if a is not None:
            out.append(a)
    return out


# ---------------------------------------------------------------- app state -> alerts


def _hhmm(iso: str, tz) -> str:
    return from_iso(iso).astimezone(tz).strftime("%H:%M")


def cost_pct_of_risk(cfg, entry: float, stop: float) -> float | None:
    """paper.cost_pips (spread and slippage) as % of the stop distance: what costs take from 1R."""
    dist = abs(float(entry) - float(stop))
    return cfg.paper.cost_pips * cfg.instrument.pip_size / dist * 100 if dist > 0 else None


def _late_note(cfg, plan: dict) -> str | None:
    """'Made 13:00 London, after the London open' when the plan was made at or after the London open."""
    run = plan.get("run_utc")
    if not run:
        return None
    day = date.fromisoformat(plan["trading_day"])
    if from_iso(run) < london_open_utc(day, cfg.day.london_open):
        return None
    return f"Made {_hhmm(run, LONDON)} London ({_hhmm(run, MELBOURNE)} Melbourne), after the London open"


def orders_to_place(cfg, plan: dict) -> Alert | None:
    """The plan of a trading day. None for a no-trade day when notify.alert_no_trade_day is off. A plan made
    at or after the London open (the server started late) says so in the title (orders) and the body."""
    day = plan["trading_day"]
    key = f"orders_to_place:{day}"
    day_word = f"{date.fromisoformat(day):%a} {date.fromisoformat(day).day} {date.fromisoformat(day):%b}"
    late = _late_note(cfg, plan)
    cards = [c for c in plan.get("cards", []) if c.get("offered")]
    if plan.get("result") == "orders" and cards:
        blocks = []
        for c in cards:
            sym = c["symbol"]
            lots = f"{_vol(c['lots'])} lots" if c.get("lots") else "size: see card"
            lines = [
                f"{c['side'].capitalize()} {_sym(cfg, sym)} {lots}",
                f"Entry {_px(cfg, sym, c['entry'])} · stop {_px(cfg, sym, c['stop'])} · target "
                f"{_px(cfg, sym, c['target'])} ({_num(c['target_r'], 1, sign=False)}R)",
            ]
            facts = []
            if c.get("swept_level"):
                facts.append(f"Swept {c['swept_level']}")          # the liquidity level the setup names (text)
            cost = cost_pct_of_risk(cfg, c["entry"], c["stop"])
            if cost is not None:
                facts.append(f"Cost {_num(cost, 0, sign=False)}% of risk")
            if facts:
                lines.append(" · ".join(facts))
            lines += [f"Expires {_hhmm(c['expiry_utc'], LONDON)} London ({_hhmm(c['expiry_utc'], MELBOURNE)} Melbourne)",
                      f"Setup: {c.get('setup', '')}"]
            blocks.append("\n".join(lines))
        body = "\n\n".join(blocks) + (f"\n\n{late}" if late else "") + \
            f"\n\nTrading day {day_word} · {cfg.planner.mode} mode · {cfg.account.alias}"
        mode = f"{cfg.planner.mode}, late" if late else cfg.planner.mode
        return Alert(key, "orders_to_place", 3, f"Orders to place ({mode}): {len(cards)}", body)
    if not cfg.notify.alert_no_trade_day:
        return None
    reason = (plan.get("reason") or "no trade today").strip()
    reason = reason[:1].upper() + reason[1:]
    return Alert(key, "orders_to_place", 3, "No trade today",
                 f"{reason}\n" + (f"{late}\n" if late else "") + f"Trading day {day_word} · {cfg.account.alias}")


# One line on what to do (owner, 30 Oct 2026; wording from the trader review): a passed phase gives a new account
# number, a reset or a breach can change the login; each needs the install line and the account number typed again.
# Anything else is the terminal on the server.
SILENT_FIX = ("To fix: passed a phase, reset or breached? Paste the install line and type the account number."
              " Otherwise, in the server console: systemctl restart edge-desk-mt5")


def bridge_silent(cfg, state: dict, now: datetime) -> Alert:
    alias = state.get("alias") or cfg.account.alias
    last = state.get("last_seen_utc")
    if not last:
        return Alert(f"bridge_silent:{alias}:never", "bridge_silent", 5, "Bridge silent",
                     f"No MT5 data from {alias} yet while the market is open.\n{SILENT_FIX}")
    minutes = max(1, int((now - from_iso(last)).total_seconds() // 60))
    return Alert(f"bridge_silent:{alias}:{last}", "bridge_silent", 5, "Bridge silent",
                 f"No MT5 data from {alias} for {minutes} min while the market is open.\n"
                 f"Last one {_mel(last)}.\n{SILENT_FIX}")


def management_reminders(cfg, view: dict) -> list[Alert]:
    """From live_view: EUR/USD positions that reached a management level. Key per position per level."""
    if not cfg.notify.management_alerts:
        return []
    m = cfg.management
    out = []
    for p in view.get("positions") or []:
        level = p.get("management")
        if level not in ("move_stop_to_entry", "close_or_trail") or not p.get("is_eurusd"):
            continue
        sym = p["symbol"]
        if level == "move_stop_to_entry":
            title = f"{_r(m.breakeven_from_r)}: move stop to entry"
        else:
            title = f"{_r(m.take_or_trail_r)}: close or trail stop to {_r(m.trail_stop_r)}"
        r_now = p.get("r_now")
        body = (f"{_position_line(cfg, p)} at {_px(cfg, sym, p.get('open_price'))}"
                f" · now {_r(r_now) if r_now is not None else 'R unknown'} · stop {_px(cfg, sym, p.get('sl'))}"
                f" · {cfg.account.alias}")
        out.append(Alert(f"management:{cfg.account.alias}:{p['position_id']}:{level}", level, 3, title, body))
    return out


def rule_break(cfg, trade: dict, flag: str, detail: str) -> Alert:
    label = FLAG_LABELS.get(flag, flag.replace("_", " "))
    sym = trade["symbol"]
    lines = [f"{_sym(cfg, sym)} {trade['side']} {_vol(trade['volume'])} opened {_mel(trade.get('open_utc'))}"]
    if detail:
        lines.append(detail)
    lines.append(f"Book: {trade.get('book', 'mt5')} · {cfg.account.alias}")
    return Alert(f"rule_break:{trade['id']}:{flag}", "rule_break", 3, f"Rule break: {label}", "\n".join(lines))


def _results(cfg, closed_trades: list[dict]) -> tuple[str, int, int, int, int]:
    band = cfg.risk.breakeven_band_r
    known_t = [t for t in closed_trades if t.get("r_net") is not None]
    known = [float(t["r_net"]) for t in known_t]
    unknown = len(closed_trades) - len(known)
    kinds = [classify_trade(t, band) for t in known_t]
    pct = sum(float(t["pct_of_balance"]) for t in closed_trades if t.get("pct_of_balance") is not None)
    money = [float(t["net_profit"]) for t in closed_trades if t.get("net_profit") is not None]
    parts = [_r(sum(known, 0.0), 2), _pct(pct)]
    if money:
        parts.append(_money(cfg, sum(money)))
    return (" · ".join(parts), kinds.count("win"), kinds.count("loss"), kinds.count("breakeven"), unknown)


def _plural(n: int, one: str, many: str) -> str:
    return f"{n} {one if n == 1 else many}"


def daily_summary(cfg, day: date, trades: list[dict], guard, streak, other_symbols: int = 0,
                  paper_trades: Iterable[dict] = (), open_trades: Iterable[dict] = ()) -> Alert:
    """EUR/USD trades closed on the trading day (MT5), positions still open (any symbol; dicts with
    'no_stop'), the guard and streak state, paper and other symbols."""
    d = day.isoformat()
    closed_t = [t for t in trades if t.get("status") == "closed" and t.get("close_trading_day") == d]
    result, wins, losses, bes, unknown = _results(cfg, closed_t)
    lines = [f"Trades {len(closed_t)} · {result}",
             f"{_plural(wins, 'win', 'wins')} · {_plural(losses, 'loss', 'losses')} · "
             f"{_plural(bes, 'breakeven', 'breakevens')}"]
    if unknown:
        lines.append(f"{_plural(unknown, 'trade', 'trades')} R unknown (no stop)")
    still_open = list(open_trades)
    if still_open:
        bare = sum(1 for t in still_open if t.get("no_stop"))
        lines.append(f"Open: {len(still_open)}" + (f" (no stop on {bare})" if bare else ""))
    for text in (_guard_text(guard), _streak_text(streak)):
        if text:
            lines.append(text)
    paper = [t for t in paper_trades if t.get("status") == "closed" and t.get("close_trading_day") == d]
    if paper:
        p_result = _results(cfg, paper)[0]
        lines.append(f"Paper: {_plural(len(paper), 'trade', 'trades')} · {p_result}")
    if other_symbols:
        lines.append(f"Other symbols: {_plural(other_symbols, 'trade', 'trades')}")
    lines.append(cfg.account.alias)
    return Alert(f"daily_summary:{d}", "daily_summary", 2, f"Daily summary {day:%a} {day.day} {day:%b}",
                 "\n".join(lines))


def push_test(now: datetime) -> Alert:
    """The alert "Send test alert" queues on Settings: one per second at most (the key)."""
    return Alert(f"push_test:{to_iso(now)}", "push_test", 3, "Alerts on",
                 f"Test alert from Edge Desk · {fmt_melbourne(now)} Melbourne")


# ---------------------------------------------------------------- queue and drain


def tags_for(kind: str) -> tuple[str, ...]:
    if kind in HARD:
        return ("warning",)
    if kind == "rule_break":
        return ("triangular_flag_on_post",)
    return ()


def queue_alert(conn: sqlite3.Connection, alert: Alert, now: datetime | None = None) -> bool:
    """Queue an alert once: INSERT OR IGNORE by key. False when that key was queued before."""
    if not isinstance(alert.key, str) or not alert.key or not isinstance(alert.kind, str) or not alert.kind:
        raise ValueError("an alert needs a key and a kind")
    if isinstance(alert.priority, bool) or not isinstance(alert.priority, int) or not 1 <= alert.priority <= 5:
        raise ValueError("alert priority must be 1 to 5")
    with db.transaction(conn):
        cur = conn.execute(
            "INSERT OR IGNORE INTO alert (key, kind, priority, title, body, created_utc, status, attempts)"
            " VALUES (?, ?, ?, ?, ?, ?, 'queued', 0)",
            (alert.key, alert.kind, alert.priority, _cap(alert.title, TITLE_MAX), _cap(alert.body, BODY_MAX),
             to_iso(now or now_utc())))
        return cur.rowcount == 1


def _hard_retry(row, now: datetime) -> str | None:
    """When a failed hard incident is tried again (ISO), or None when it has waited a day (give up)."""
    age = (now - from_iso(row["created_utc"])).total_seconds()
    if age >= HARD_GIVE_UP_S:
        return None
    return to_iso(now + timedelta(seconds=min(max(HARD_RETRY_MIN_S, age), HARD_RETRY_MAX_S)))


def drain(conn: sqlite3.Connection, client, now: datetime, limit: int | None = None) -> int:
    """Send queued alerts oldest first; returns how many were sent. One drain runs at a time.

    No client, no push key or no phone saved: queued alerts are marked skipped (never sent later in a
    burst). A send the client defers (it would have to wait too long) stays queued and ends this drain. A
    hard incident (no_stop, bridge_silent, terminal_can_trade) whose send fails stays queued and waits
    next_try_utc (back-off, see HARD_RETRY_*), so a network or push service outage never loses it; after a
    day it is marked failed. Other alerts that fail are marked failed. The database lock is never held while
    an alert is on its way.
    """
    with _DRAIN_LOCK:
        return _drain(conn, client, now, limit)


def _skip_reason(client) -> str:
    return (getattr(client, "skip_reason", None) or "push not configured") if client is not None \
        else "push not configured"


def _drain(conn: sqlite3.Connection, client, now: datetime, limit: int | None) -> int:
    with db._LOCK:
        rows = conn.execute("SELECT id, key, kind, priority, title, body, created_utc FROM alert"
                            " WHERE status = 'queued' AND (next_try_utc IS NULL OR next_try_utc <= ?) ORDER BY id",
                            (to_iso(now),)).fetchall()
    if not rows:
        return 0
    if client is None or not getattr(client, "configured", False):
        with db.transaction(conn):
            conn.execute("UPDATE alert SET status = 'skipped', last_error = ? WHERE status = 'queued' AND id <= ?",
                         (_skip_reason(client), rows[-1]["id"]))
        return 0
    sent = 0
    for row in rows if limit is None else rows[:limit]:
        title = row["title"]
        if row["kind"] == "news_soon":            # "in N min" as it is when sent; none once the release is out
            from app.news.alerts import send_title
            title = send_title(row["key"], title, now)
            if title is None:
                with db.transaction(conn):
                    conn.execute("UPDATE alert SET status = 'skipped', last_error = 'release time passed'"
                                 " WHERE id = ? AND status = 'queued'", (row["id"],))
                continue
        if row["kind"] == "aplus_order":           # no use after its 11:00 London cancel (app/aplus/alerts.py)
            from app.aplus.alerts import order_still_valid
            if not order_still_valid(row["key"], now):
                with db.transaction(conn):
                    conn.execute("UPDATE alert SET status = 'skipped', last_error = 'order time passed'"
                                 " WHERE id = ? AND status = 'queued'", (row["id"],))
                continue
        if row["kind"] in SIGNAL_KINDS:             # no use after its exit or entry (app/t1m, gfix, pbgbp, mechf)
            from app.notify.push import expires_ts
            exp = expires_ts(row["kind"], row["key"])
            if exp is not None and now.timestamp() >= exp:
                with db.transaction(conn):
                    conn.execute("UPDATE alert SET status = 'skipped', last_error = 'exit time passed'"
                                 " WHERE id = ? AND status = 'queued'", (row["id"],))
                continue
        ok = bool(client.send(title, row["body"], row["priority"], tags_for(row["kind"]),
                              kind=row["kind"], key=row["key"]))
        if not ok and getattr(client, "deferred", False):
            break
        if not ok and getattr(client, "skipped", False):
            # the last phone went away during this drain (404 / 410): nothing to send to, as above
            with db.transaction(conn):
                conn.execute("UPDATE alert SET status = 'skipped', last_error = ? WHERE id = ? AND status = 'queued'",
                             (_skip_reason(client), row["id"]))
            continue
        retry_at = None if ok or row["kind"] not in HARD else _hard_retry(row, now)
        if retry_at is not None:
            with db.transaction(conn):
                conn.execute("UPDATE alert SET attempts = attempts + ?, last_error = ?, next_try_utc = ?"
                             " WHERE id = ? AND status = 'queued'",
                             (int(getattr(client, "last_attempts", 1) or 0), client.last_error or "send failed",
                              retry_at, row["id"]))
            continue
        with db.transaction(conn):
            conn.execute("UPDATE alert SET status = ?, attempts = attempts + ?, sent_utc = ?, last_error = ?"
                         " WHERE id = ? AND status = 'queued'",
                         ("sent" if ok else "failed", int(getattr(client, "last_attempts", 1) or 0),
                          to_iso(now) if ok else None, None if ok else (client.last_error or "send failed"),
                          row["id"]))
        sent += ok
    return sent
