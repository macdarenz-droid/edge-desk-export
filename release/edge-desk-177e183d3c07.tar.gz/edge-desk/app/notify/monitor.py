"""The schedule the server runs every few seconds. One tick, in order:

  1. bridge   no snapshot for bridge.silent_alert_after_s while the market is open -> bridge_silent
              (key per silence episode: the last snapshot time, or "never")
  2. management  with a live bridge and notify.management_alerts: +2R / +4R reminders from live_view
  3. plan     ensure_plan at or after planner.plan_time_london -> orders_to_place, once per trading day
              (a plan made at or after the London open says so: the server started late)
  4. summary  once per trading day (Mon-Fri) at or after notify.daily_summary_ny, New York time, with the
              positions still open (and how many have no stop)
  5. flags    compute_flags on both books; flags not yet alerted on recent trades -> rule_break
              (recent: still open, or opened or closed in the last 24 h; old history stays quiet;
              no_stop is left to the hard incident raised at ingest; size_above_risk is shown, not alerted
              (app.risk.flags.INFO_FLAGS); an MT5 trade opened and closed before the bridge's first data
              arrived is history from the first sync, never alerted, except a stop moved away, which the
              bridge can only see while it runs)
  6. news     queued news_soon alerts whose release time has passed -> skipped (and news_result over 30 min);
              then one news_soon per currency and release minute due in news.alert_before_min, and one news_result
              per currency and release minute whose first number is out (app/news/alerts.py)
     headlines  one headline_policy push for a Fed statement or ECB decision first seen within 20 min of its
              publication, at most 4 a day; queued ones over 15 min old -> skipped (app/news/headlines.py)
     aplus    the A+ step's heartbeat (aplus_state heartbeat_utc, written by the method worker every 30 s) more than
              15 min old, inside the A+ window (07:00 London to 17:00 New York + 10 min, a traded London weekday),
              while [feed] and [aplus] are on -> aplus_silent, once a stall (key: the last heartbeat, or "never" after
              one 15-min grace from the monitor's start)
     t1m      the T1-M step's heartbeat (t1m_state heartbeat_utc, written after each good run, every ~30 s) more than
              5 min old, 09:55-13:05 London on a weekday, while [t1m] and [feed] are on -> t1m_silent, once a stall
              (key: the last heartbeat; a worker that never ran is left to the method worker's own checks)
  7. backup   once a day after notify.daily_summary_ny: a copy of the journal file (sqlite backup) in
              the storage check and its storage_low alert (app/storage.py, A10); the daily backup is the hourly
              `python -m app maintain` job's
  8. drain    send what is queued
A step that fails is logged and reported as "error:<step>"; the other steps still run.
Returns what happened: the keys of alerts queued this tick, "sent:<n>" and any "error:<step>".
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable

from app import db
from app.ingest.live import live_view
from app.ingest.status import bridge_state
from app.journal.store import list_trades
from app.notify import alerts
from app.notify.alerts import queue_alert
from app.planner.service import ensure_plan
from app.checklist.store import resolve_links
from app.funded.limits import funded_alerts, funded_state
from app.risk.flags import INFO_FLAGS, compute_flags, guard_now, streak_now
from app.timeutil import NEW_YORK, day_bounds, market_open, to_iso

log = logging.getLogger("edge.monitor")
RECENT = timedelta(hours=24)


def _bridge(conn, cfg, now: datetime, started_utc: datetime | None, q: Callable) -> None:
    if not market_open(now):
        return
    st = bridge_state(conn, cfg, now)
    if st["state"] == "never":
        # A brand-new journal: give the bridge one full silence window after the monitor starts.
        if started_utc is None or (now - started_utc).total_seconds() >= cfg.bridge.silent_alert_after_s:
            q(alerts.bridge_silent(cfg, st, now))
        return
    if st["age_s"] is not None and st["age_s"] >= cfg.bridge.silent_alert_after_s:
        q(alerts.bridge_silent(cfg, st, now))


def _management(conn, cfg, now: datetime, q: Callable) -> None:
    if not cfg.notify.management_alerts:
        return
    if bridge_state(conn, cfg, now)["state"] != "live":
        return   # prices from an old snapshot are no reason to act
    for a in alerts.management_reminders(cfg, live_view(conn, cfg, now)):
        q(a)


def _plan(conn, cfg, now: datetime, q: Callable) -> None:
    plan = ensure_plan(conn, cfg, now)
    if plan is not None:
        q(alerts.orders_to_place(cfg, plan))


def _summary(conn, cfg, now: datetime, q: Callable) -> None:
    ny = now.astimezone(NEW_YORK)
    if ny.weekday() >= 5 or ny.time() < cfg.notify.daily_summary_ny:
        return
    day = ny.date()
    key = f"daily_summary:{day.isoformat()}"
    if conn.execute("SELECT 1 FROM alert WHERE key = ?", (key,)).fetchone():
        return
    _, end = day_bounds(day, cfg.day.boundary_tz, cfg.day.boundary_hour)
    at = min(now, end - timedelta(seconds=1))          # the guard and streak as the day ended
    trades = list_trades(conn, cfg, "mt5", day, day)
    paper = list_trades(conn, cfg, "paper", day, day)
    syms = list(cfg.instrument.broker_symbols)
    other = conn.execute(
        f"SELECT COUNT(*) FROM trade WHERE book = 'mt5' AND status = 'closed' AND close_trading_day = ?"
        f" AND symbol NOT IN ({','.join('?' * len(syms))})", (day.isoformat(), *syms)).fetchone()[0]
    still_open = [{"no_stop": (r["last_sl"] if r["seen"] is not None else r["initial_sl"]) is None} for r in conn.execute(
        "SELECT t.initial_sl, ps.last_sl, ps.position_id AS seen FROM trade t LEFT JOIN position_seen ps"
        " ON ps.account_alias = t.account_alias AND ps.position_id = t.broker_position_id"
        " WHERE t.book = 'mt5' AND t.status = 'open' AND t.account_alias = ?", (cfg.account.alias,))]
    q(alerts.daily_summary(cfg, day, trades, guard_now(conn, cfg, at, "mt5"), streak_now(conn, cfg, at, "mt5"),
                           other_symbols=other, paper_trades=paper, open_trades=still_open))


def _first_data(conn, alias: str) -> str | None:
    """When the bridge's first data arrived (the first sync): the earliest deal or position it sent."""
    row = conn.execute("SELECT MIN(t) FROM (SELECT MIN(received_utc) AS t FROM deal WHERE account_alias = ?"
                       " UNION ALL SELECT MIN(first_seen_utc) FROM position_seen WHERE account_alias = ?)",
                       (alias, alias)).fetchone()
    return row[0] if row else None


def _flags(conn, cfg, now: datetime, q: Callable) -> None:
    resolve_links(conn, cfg, now=now)            # setup check links first: the A3 flags read them
    for book in ("mt5", "paper"):
        compute_flags(conn, cfg, book, now)
    cutoff = to_iso(now - RECENT)
    quiet = ("no_stop", *sorted(INFO_FLAGS))
    first = _first_data(conn, cfg.account.alias) or ""
    rows = conn.execute(
        "SELECT f.flag AS flag, f.detail AS detail, t.id AS id, t.book AS book, t.symbol AS symbol, t.side AS side,"
        " t.volume AS volume, t.open_utc AS open_utc FROM trade_flag f JOIN trade t ON t.id = f.trade_id"
        f" WHERE f.flag NOT IN ({','.join('?' * len(quiet))}) AND (t.status = 'open' OR t.open_utc >= ? OR t.close_utc >= ?)"
        " AND (t.book != 'mt5' OR t.open_utc >= ? OR t.close_utc >= ? OR f.flag = 'stop_moved_away')"
        " AND NOT EXISTS (SELECT 1 FROM alert a WHERE a.key = 'rule_break:' || f.trade_id || ':' || f.flag)"
        " ORDER BY t.open_utc, t.id, f.flag", (*quiet, cutoff, cutoff, first, first)).fetchall()
    for r in rows:
        q(alerts.rule_break(cfg, dict(r), r["flag"], r["detail"]))


def _funded(conn, cfg, now: datetime, q: Callable) -> None:
    """Funded limits (A5): 50% and 80% of the daily limit used, open risk at the cap; once per server day."""
    if not cfg.funded.enabled:
        return
    state = funded_state(conn, cfg, now)
    for a in funded_alerts(cfg, state, state.get("reset_utc")):
        q(a)


def _headlines(conn, cfg, now: datetime, q: Callable) -> None:
    """Headlines (app/news/headlines.py): one push for a fresh Fed statement or ECB decision."""
    from app.news import headlines
    headlines.alert_step(conn, cfg, now, q)


def _news(conn, cfg, now: datetime, q: Callable) -> None:
    """News (app/news): skip queued alerts for releases already out, then queue the releases due soon."""
    from app.news import alerts as news_alerts
    news_alerts.step(conn, cfg, now, q)


def _t1m(conn, cfg, now: datetime, q: Callable) -> None:
    """T1-M runs inside the method worker: no heartbeat for 5 min in its window means no signal can come."""
    from app.t1m.step import streams
    if not streams(cfg) or not cfg.feed.enabled:
        return
    from app.t1m import alerts as t1m_alerts
    from app.t1m.step import STALE_FROM, STALE_TO, get_state, london_now
    from app.timeutil import from_iso
    day, minute = london_now(now)
    if day.weekday() >= 5 or not STALE_FROM <= minute < STALE_TO:
        return
    try:
        hb = get_state(conn, "heartbeat_utc")
    except sqlite3.Error:
        return
    if hb is not None and (now - from_iso(hb)).total_seconds() > t1m_alerts.SILENT_AFTER_S:
        q(t1m_alerts.silent(hb, now))


def _feed(conn, cfg, now: datetime, q: Callable) -> None:
    """The EUR/USD price feed stopped, never delivered, or over an hour behind on a weekday 07:00-21:00 London: one
    feed_down alert a day (app/feed/health.py), whatever else is running (11 Nov 2026)."""
    from app.feed import health
    q(health.alert(conn, cfg, now))


APLUS_SILENT_AFTER_S = 15 * 60


def _aplus(conn, cfg, now: datetime, started_utc: datetime | None, q: Callable) -> None:
    """The A+ step (app/aplus/step.py) runs in the method worker, or alone in edge-desk-aplus with [aplus] run_in =
    "own"; no heartbeat for 15 min in its window: one alert, naming that unit."""
    if not cfg.aplus.enabled or not cfg.feed.enabled:
        return
    from app.aplus import alerts as aplus_alerts
    from app.aplus.step import get_state, in_window, london_date
    from app.timeutil import from_iso
    ts = int(now.timestamp())
    if not in_window(ts):
        return
    hb = get_state(conn, "heartbeat_utc")
    if hb is None:
        if started_utc is None or (now - started_utc).total_seconds() >= APLUS_SILENT_AFTER_S:
            q(aplus_alerts.silent(london_date(ts), None, now, unit=aplus_alerts.unit_of(cfg)))
        return
    last = int(from_iso(hb).timestamp())
    if ts - last > APLUS_SILENT_AFTER_S:
        q(aplus_alerts.silent(london_date(ts), last, now, unit=aplus_alerts.unit_of(cfg)))


def _backup(conn, cfg, now: datetime, out: list) -> None:
    """A10: the storage check and its one storage_low alert. The daily backup is made only by the hourly
    `python -m app maintain` job (app/storage.py), so serve never holds the journal lock through a backup and two
    processes never write one."""
    from app import storage
    if storage._db_path(conn) is None:
        return
    state = storage.check(conn, cfg, now)
    if state["alert"] is not None and alerts.queue_alert(conn, state["alert"], now):
        out.append(state["alert"].key)


def tick(conn: sqlite3.Connection, cfg, now: datetime, client, drain_limit: int | None = None,
         started_utc: datetime | None = None) -> list[str]:
    """Run one pass of the schedule at `now` (UTC, with a zone). See the module docstring."""
    if not isinstance(now, datetime) or now.tzinfo is None:
        raise ValueError("now must be a time with a zone (UTC)")
    out: list[str] = []

    def q(alert) -> None:
        if alert is not None and queue_alert(conn, alert, now):
            out.append(alert.key)

    steps = (("bridge", lambda: _bridge(conn, cfg, now, started_utc, q)),
             ("management", lambda: _management(conn, cfg, now, q)),
             ("plan", lambda: _plan(conn, cfg, now, q)),
             ("summary", lambda: _summary(conn, cfg, now, q)),
             ("flags", lambda: _flags(conn, cfg, now, q)),
             ("funded", lambda: _funded(conn, cfg, now, q)),
             ("news", lambda: _news(conn, cfg, now, q)),
             ("headlines", lambda: _headlines(conn, cfg, now, q)),
             ("aplus", lambda: _aplus(conn, cfg, now, started_utc, q)),
             ("t1m", lambda: _t1m(conn, cfg, now, q)),
             ("feed", lambda: _feed(conn, cfg, now, q)),
             ("backup", lambda: _backup(conn, cfg, now, out)))
    for name, fn in steps:
        try:
            with db._LOCK:   # one shared connection: each step reads and writes under the journal lock
                fn()
        except Exception as exc:  # noqa: BLE001 - one broken step must not stop the alerts
            log.error("monitor step %s failed: %s", name, type(exc).__name__)
            out.append(f"error:{name}")
    try:
        sent = alerts.drain(conn, client, now, drain_limit)   # takes the lock itself, never while sending
        if sent:
            out.append(f"sent:{sent}")
    except Exception as exc:  # noqa: BLE001
        log.error("monitor step drain failed: %s", type(exc).__name__)
        out.append("error:drain")
    return out
