"""Shared parts of the PB-GBP and ME-CHF paper streams."""
