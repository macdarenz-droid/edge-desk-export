"""Risk budget on the paper cards (owner, 10 Nov 2026: "yes", relayed by the research session). Warning only: the app
reads his real open positions from the latest MT5 bridge snapshot (read-only) and never sends an order, a close or a
change.

  cap        [funded] risk_cap_pct (3 when not set) % of [funded] initial_balance ($750 on $25K)
  used       every real open position and pending order in the latest snapshot: the larger of its stop risk and its
             floating loss (app/funded/limits.py open_risk_detail, the funded panel's own figure)
  unknown    no snapshot, a snapshot older than [bridge] stale_after_s, a symbol without its value data, or any
             position or order with no stop: the line says "unknown", never "OK" (fail closed)
  card line  "Risk budget: $X used of $750; this signal $Y." and, when X + Y is over the cap, "Over the 3% rule: skip,
             or reduce to $Z." (a warning or "unknown" is the card's first line). Amounts are in the account currency
             (USD on his FundedNext accounts); the sizes are US dollars.
  overdue    a real position on a card's pair (broker suffixes allowed), opened between the card and its exit, still open in a snapshot taken
             after the exit (T1-M 13:00, G-FIX 10:32, ME-CHF 17:00 London, PB-GBP 21:55 of its exit day): one alert a
             position, "close it" (the app cannot tell a card's trade from his own on the same pair); its risk stays counted until the bridge shows it closed. A scheduled exit never frees risk.
"""
from __future__ import annotations

import json
import re
import sqlite3
from dataclasses import replace
from datetime import date, datetime, timedelta

from app.gfix.rule import minute_ts
from app.notify.alerts import Alert
from app.timeutil import LONDON, from_iso, to_iso

DEFAULT_CAP_PCT = 3.0
OVERDUE_LOOKBACK_DAYS = 4
OVERDUE_GRACE_S = 60
PAIRS = {"t1m_signal": ("EURUSD", "T1-M", "13:00 London"), "gfix_signal": ("XAUUSD", "G-FIX", "10:32 London"),
         "pb_signal": ("GBPUSD", "PB-GBP", "21:55 London"), "me_signal": ("USDCHF", "ME-CHF", "17:00 London")}


def _norm(symbol: str) -> str:
    s = re.sub(r"[^A-Z]", "", str(symbol).upper())
    return "XAUUSD" + s[4:] if s.startswith("GOLD") else s


def is_pair(cfg, symbol: str, pair: str) -> bool:
    """A broker symbol of the pair, suffixes allowed (EURUSD.r, EURUSDm, XAUUSD.s, GOLD): EUR/USD also by the config's
    own broker_symbols."""
    return (pair == "EURUSD" and cfg.is_eurusd(symbol)) or _norm(symbol).startswith(pair)


def cap(cfg) -> tuple[float | None, float]:
    f = cfg.funded
    pct = DEFAULT_CAP_PCT if f.risk_cap_pct is None else float(f.risk_cap_pct)
    return (None if f.initial_balance is None else float(f.initial_balance) * pct / 100.0), pct


def _snapshot(conn: sqlite3.Connection, cfg, now: datetime) -> tuple[dict | None, str, object]:
    row = conn.execute("SELECT * FROM bridge_status WHERE account_alias = ?", (cfg.account.alias,)).fetchone()
    if row is None:
        return None, "no MT5 snapshot yet", None
    age = (now - from_iso(row["last_seen_utc"])).total_seconds()
    if age > cfg.bridge.stale_after_s:
        return None, f"the MT5 link is {int(age // 60)} min behind", row
    return json.loads(row["snapshot_json"]), "", row


def state(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    """{"known", "used", "cap", "pct", "reason"}: used is None whenever it is not known."""
    from app.funded.limits import open_risk_detail
    c, pct = cap(cfg)
    out = {"known": False, "used": None, "cap": c, "pct": pct, "reason": ""}
    if c is None:
        out["reason"] = "no initial balance in the [funded] settings"
        return out
    snap, why, _ = _snapshot(conn, cfg, now)
    if snap is None:
        out["reason"] = why
        return out
    used, no_stop = open_risk_detail(snap)
    if no_stop:
        out["reason"] = f"{no_stop} open position{'s' if no_stop > 1 else ''} or order{'s' if no_stop > 1 else ''}" \
                        " with no stop loss"
        return out
    if used is None:
        out["reason"] = "a symbol's value per point is missing in the MT5 snapshot"
        return out
    out.update(known=True, used=round(used, 2))
    return out


def line(st: dict, this_usd: float, label: str | None = None) -> str:
    name = f" ({label})" if label else ""
    if not st["known"]:
        return f"Risk budget{name} unknown: {st['reason']}. Check your open risk before taking this."
    used, c = st["used"], st["cap"]
    text = f"Risk budget{name}: ${used:,.0f} used of ${c:,.0f}; this signal ${this_usd:,.0f}."
    if used + this_usd > c + 1e-9:
        room = max(0.0, c - used)
        text += (f" Over the {st['pct']:g}% rule: skip" + (f", or reduce to ${room:,.0f}." if room >= 1 else "."))
    return text


def with_line(conn: sqlite3.Connection, cfg, now: datetime, alert: Alert, this_usd: float,
              label: str | None = None) -> Alert:
    """The card with its risk-budget line (named for the MT5-linked account when `label`); a failure to read the
    budget never stops the card (it says unknown)."""
    try:
        text = line(state(conn, cfg, now), this_usd, label)
    except Exception:                                       # noqa: BLE001  (the card still goes, marked unknown)
        text = "Risk budget unknown: it could not be read. Check your open risk before taking this."
    if "unknown" in text or "Over the" in text:             # a warning leads, so a folded notification shows it
        return replace(alert, body=text + "\n" + alert.body)
    return replace(alert, body=alert.body + "\n" + text)


# ---------------------------------------------------------------- overdue

def _window(kind: str, key: str) -> tuple[int, int] | None:
    """(card time, exit) in unix s of a signal card key."""
    parts = key.split(":")
    try:
        if kind == "t1m_signal":
            from app.t1m.alerts import exit_ts as t1m_exit
            sig = int(parts[2])
            day = datetime.fromtimestamp(sig, LONDON).date()
            return sig, t1m_exit(day)
        d = date.fromisoformat(parts[1])
    except (IndexError, ValueError):
        return None
    if kind == "gfix_signal":
        from app.gfix.alerts import exit_ts as gx
        return minute_ts(d, 10 * 60 + 14), gx(d)
    if kind == "pb_signal":
        from app.pbgbp.alerts import exit_ts as px
        return minute_ts(d, 22 * 60), px(d)
    if kind == "me_signal":
        return minute_ts(d, 15 * 60 + 59), minute_ts(d, 17 * 60)
    return None


def overdue(conn: sqlite3.Connection, cfg, now: datetime) -> list[Alert]:
    """One alert per real position still open after its card's exit (only from a fresh snapshot taken after it)."""
    snap, _, row = _snapshot(conn, cfg, now)
    if snap is None or not snap.get("positions"):
        return []
    from app.ingest.live import _clock
    clock = _clock(cfg, row)
    snap_ts = from_iso(row["last_seen_utc"]).timestamp()
    since = to_iso(now - timedelta(days=OVERDUE_LOOKBACK_DAYS))
    out = []
    for r in conn.execute("SELECT key, kind FROM alert WHERE kind IN (?, ?, ?, ?) AND created_utc >= ?",
                          (*PAIRS, since)):
        w = _window(r["kind"], r["key"])
        if w is None:
            continue
        start, end = w
        if now.timestamp() < end + OVERDUE_GRACE_S or snap_ts < end + OVERDUE_GRACE_S:
            continue
        pair, name, exit_at = PAIRS[r["kind"]]
        for p in snap["positions"]:
            if not is_pair(cfg, p["symbol"], pair):
                continue
            opened = clock.to_utc(int(p["open_time"])).timestamp()
            if not start - 300 <= opened < end:
                continue
            out.append(Alert(f"paper_overdue:{p['position_id']}", "paper_overdue", 4,      # once a position
                             f"Overdue: close your {p['symbol']} {p['side']} ({name} card)",
                             f"Your {p['symbol']} {p['side']} {p['volume']:g} lots, opened"
                             f" {datetime.fromtimestamp(opened, LONDON):%H:%M} London, is still open after the {name}"
                             f" exit ({exit_at}). Its stop risk stays in the risk budget until the MT5 link shows it"
                             " closed. The app never closes a trade."))
    return out


def overdue_step(conn: sqlite3.Connection, cfg, now: datetime) -> list[str]:
    """Queue the overdue alerts (each once by key); returns the keys queued now."""
    from app.notify.alerts import queue_alert
    return [a.key for a in overdue(conn, cfg, now) if queue_alert(conn, a, now)]
