"""What PB-GBP (app/pbgbp) and ME-CHF (app/mechf) share: the pair's bars from the feed's own table, the per-day
summaries in fx_day (written once a day is complete, so the 1-minute bars can be pruned), the append-only event log
(paper_event) and a small key/value state (paper_state)."""
from __future__ import annotations

import json
import sqlite3
from datetime import date, datetime, timedelta, timezone

from app import db
from app.gfix.rule import day_of, london_midnight_ts
from app.timeutil import LONDON, to_iso

PIP = 0.0001


def marker(conn: sqlite3.Connection, instrument: str) -> int | None:
    from app.feed.oanda import complete_through
    return complete_through(conn, instrument)


def table_of(instrument: str) -> str:
    from app.feed.oanda import INSTRUMENTS
    return INSTRUMENTS[instrument][1]


def get_state(conn: sqlite3.Connection, key: str) -> str | None:
    r = conn.execute("SELECT value FROM paper_state WHERE key = ?", (key,)).fetchone()
    return None if r is None else r[0]


def set_state(conn: sqlite3.Connection, key: str, value) -> None:
    with db.transaction(conn):
        conn.execute("INSERT INTO paper_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET"
                     " value = excluded.value", (key, str(value)))


def day_bars(conn: sqlite3.Connection, instrument: str, day: date, upto: int | None):
    """An app.gfix.rule.Day of one London day from the pair's table, below `upto` (None: the whole day)."""
    lo, hi = london_midnight_ts(day), london_midnight_ts(day + timedelta(days=1))
    end = hi if upto is None else min(hi, int(upto))
    rows = conn.execute(f"SELECT * FROM {table_of(instrument)} WHERE ts >= ? AND ts < ? ORDER BY ts", (lo, end))
    return day_of(day, rows.fetchall(), end)


def summarize(conn: sqlite3.Connection, instrument: str, mk: int, now: datetime) -> int:
    """fx_day rows for every complete London weekday (its end at or below the marker) that has bars and no row yet,
    from the last summarised day (or the first stored bar) on. Returns how many were written."""
    last = conn.execute("SELECT MAX(day) FROM fx_day WHERE instrument = ?", (instrument,)).fetchone()[0]
    if last is not None:
        d = date.fromisoformat(last) + timedelta(days=1)
    else:
        first = conn.execute(f"SELECT MIN(ts) FROM {table_of(instrument)}").fetchone()[0]
        if first is None:
            return 0
        d = datetime.fromtimestamp(int(first), LONDON).date()
    n = 0
    while london_midnight_ts(d + timedelta(days=1)) <= int(mk):
        if d.weekday() < 5:
            day = day_bars(conn, instrument, d, None)
            if day.c:
                close = [day.c[m] for m in sorted(day.c) if m < 22 * 60]
                with db.transaction(conn):
                    conn.execute("INSERT INTO fx_day (instrument, day, close22, hi, lo, nbars, made_utc)"
                                 " VALUES (?,?,?,?,?,?,?) ON CONFLICT (instrument, day) DO NOTHING",
                                 (instrument, d.isoformat(), close[-1] / PIP if close else None,
                                  max(day.h.values()) / PIP, min(day.lo.values()) / PIP, len(day.c), to_iso(now)))
                n += 1
        d += timedelta(days=1)
    return n


def summaries(conn: sqlite3.Connection, instrument: str, before: date | None = None, limit: int = 450) -> list[dict]:
    """fx_day rows of a pair, oldest first (the last `limit` before `before`)."""
    q = "SELECT * FROM fx_day WHERE instrument = ?" + (" AND day < ?" if before else "") + " ORDER BY day DESC LIMIT ?"
    args = (instrument, before.isoformat(), limit) if before else (instrument, limit)
    return [dict(r) for r in reversed(conn.execute(q, args).fetchall())]


def event(conn: sqlite3.Connection, stream: str, day: date, stage: str, at_ts: int, data: dict, now: datetime) -> bool:
    with db.transaction(conn):
        cur = conn.execute("INSERT INTO paper_event (stream, day, stage, at_ts, data_json, made_utc) VALUES"
                           " (?,?,?,?,?,?) ON CONFLICT (stream, day, stage) DO NOTHING",
                           (stream, day.isoformat(), stage, int(at_ts), json.dumps(data, default=str, sort_keys=True),
                            to_iso(now)))
        return cur.rowcount == 1


def events(conn: sqlite3.Connection, stream: str, day: date) -> dict:
    return {r["stage"]: json.loads(r["data_json"]) for r in
            conn.execute("SELECT stage, data_json FROM paper_event WHERE stream = ? AND day = ?", (stream, day.isoformat()))}


def closed(conn: sqlite3.Connection, stream: str) -> list[dict]:
    return [dict(json.loads(r["data_json"]), day=r["day"]) for r in
            conn.execute("SELECT day, data_json FROM paper_event WHERE stream = ? AND stage = 'closed' ORDER BY day",
                         (stream,))]


def queue(conn: sqlite3.Connection, alert, now: datetime, out: dict) -> None:
    from app.notify.alerts import queue_alert
    if queue_alert(conn, alert, now):
        out["queued"].append(alert.key)


def utc(ts: int) -> datetime:
    return datetime.fromtimestamp(int(ts), timezone.utc)
