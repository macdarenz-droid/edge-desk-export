"""Paper card sizes as % of each account (owner, 11 Nov 2026: "to avoid confusion put risk size in terms of
percentage. since i have 6k and 25k both"). Display only: the app never places an order.

  target   [sizes] t1m_pct (T1-M) or stream_pct (G-FIX, PB-GBP, ME-CHF) of each account's balance, lost at the stop
  accounts the MT5-linked one ([funded] initial_balance), then [sizes] accounts (set on his server only)
  lots     target / (stop distance x value of a 1.0 price move for 1 lot), rounded DOWN to the symbol's volume step;
           the value, volume step and minimum come from MT5's own symbol data (the latest snapshot, else the last one
           the bridge sent for that symbol); with none, "lots unknown" (nothing is assumed, gold's contract included)
  shown    "Risk 0.46% a trade." then a line per account: "$6K: 0.04 lots = 0.40% after rounding ($24)", or
           "below the minimum lot on this account: the minimum 0.01 lots is 0.49% (target 0.23%)" (a warning, never a
           silent skip)
"""
from __future__ import annotations

import json
import math
import sqlite3

STREAMS = {"t1m": "EURUSD", "gfix": "XAUUSD", "pbgbp": "GBPUSD", "mechf": "USDCHF"}
NEEDED = ("tick_size", "tick_value", "volume_step", "volume_min")


def pct(cfg, stream: str) -> float:
    return cfg.sizes.t1m_pct if stream == "t1m" else cfg.sizes.stream_pct


def label(balance: float) -> str:
    return f"${balance / 1000:g}K" if balance >= 1000 else f"${balance:g}"


def accounts(cfg) -> list[tuple[str, float, bool]]:
    """(label, balance, linked to MT5) of every account the cards size for: the linked one first."""
    out = []
    if cfg.funded.initial_balance is not None:
        out.append((label(float(cfg.funded.initial_balance)), float(cfg.funded.initial_balance), True))
    out += [(lb, float(b), False) for lb, b in cfg.sizes.accounts]
    return out


def risk_usd(cfg, stream: str, fallback: float) -> float:
    """Dollars at the stop on the MT5-linked account (records and the risk budget); `fallback` (the section's
    risk_usd) when no balance is set."""
    b = cfg.funded.initial_balance
    return round(float(b) * pct(cfg, stream) / 100.0, 2) if b is not None else float(fallback)


def symbol_info(conn: sqlite3.Connection, cfg, pair: str) -> tuple[str, dict] | None:
    """(broker symbol, its MT5 data) for a pair: the latest snapshot first, then the symbols the bridge sent before."""
    from app.paper2.budget import is_pair
    blocks = []
    row = conn.execute("SELECT snapshot_json FROM bridge_status WHERE account_alias = ?", (cfg.account.alias,)).fetchone()
    if row is not None:
        try:
            blocks.append(json.loads(row[0]).get("symbols") or {})
        except ValueError:
            pass
    try:
        from app.ingest.state import known_symbols
        blocks.append(known_symbols(conn, cfg.account.alias))
    except (sqlite3.Error, ValueError):
        pass
    for syms in blocks:
        for name, info in syms.items():
            if is_pair(cfg, name, pair) and all(float((info or {}).get(k) or 0) > 0 for k in NEEDED):
                return name, info
    return None


def _places(step: float) -> int:
    return max(0, -int(math.floor(math.log10(step) + 1e-9)))


def lots(target: float, dist: float, info: dict) -> tuple[float, float, bool]:
    """(lots rounded down, money lost at the stop with those lots, below the minimum). dist: stop distance in price.
    Capped at MT5's volume_max when it is sent."""
    per_lot = dist * float(info["tick_value"]) / float(info["tick_size"])
    step, vmin = float(info["volume_step"]), float(info["volume_min"])
    vmax = float(info.get("volume_max") or 0)
    raw = target / per_lot if per_lot > 0 else 0.0
    n = math.floor(raw / step + 1e-9) * step
    if vmax > 0:
        n = min(n, math.floor(vmax / step + 1e-9) * step)
    if n < vmin - 1e-12:
        return vmin, vmin * per_lot, True
    return round(n, _places(step)), round(n, _places(step)) * per_lot, False


def _block(conn: sqlite3.Connection, cfg, stream: str, dist: float | None, factor: float = 1.0,
           note: str = "") -> tuple[list[str], float | None]:
    """(the card's size lines, the money at the stop on the MT5-linked account as rounded; None when not known).
    factor: T1-M's W sizing that day (0.625 Mon/Tue, 1.25 Wed-Fri), 1 otherwise."""
    p = round(pct(cfg, stream) * factor, 4)
    out = [f"Risk {p:g}% a trade{note}."]
    accts = accounts(cfg)
    if not accts:
        return out + ["Lots unknown: no account balance set ([funded] initial_balance on the server)."], None
    found = symbol_info(conn, cfg, STREAMS[stream]) if dist else None
    if found is None:
        why = ("the stop is not known yet" if not dist else
               f"no {STREAMS[stream]} data from MT5 yet: it comes with your first {STREAMS[stream]} trade or order on"
               " the linked account")
        return out + [f"{lb}: ${bal * p / 100:,.2f} at the stop; lots unknown ({why})." for lb, bal, _ in accts], None
    name, info = found
    places, linked_money = _places(float(info["volume_step"])), None
    for lb, bal, linked in accts:
        n, money, below = lots(bal * p / 100.0, dist, info)
        if linked:
            linked_money = money
        if below:
            out.append(f"{lb}: below the minimum lot on this account: the minimum {n:.{places}f} lots is"
                       f" {money / bal * 100:.2f}% (target {p:g}%).")
        else:
            out.append(f"{lb}: {n:.{places}f} lots = {money / bal * 100:.2f}% after rounding (${money:,.0f}).")
    if any(not linked for _, _, linked in accts):
        src = "the linked account" if any(linked for _, _, linked in accts) else "the MT5 link"
        out.append(f"Lots from MT5's {name} data on {src} (same broker assumed for the others).")
    return out, linked_money


def block(conn: sqlite3.Connection, cfg, stream: str, dist: float | None, factor: float = 1.0,
          note: str = "") -> list[str]:
    return _block(conn, cfg, stream, dist, factor, note)[0]


def on_card(alert, lines: list[str]):
    """The card with its size lines near the top (after a "Late:" line), in place of the old "Suggested size" line."""
    from dataclasses import replace
    rest = [x for x in alert.body.split("\n") if not x.startswith("Suggested size:")]
    head = [rest.pop(0)] if rest and rest[0].startswith("Late:") else []
    return replace(alert, body="\n".join(head + lines + rest))


def today(conn: sqlite3.Connection, cfg, stream: str, dist: float | None) -> str:
    try:
        return " ".join(block(conn, cfg, stream, dist))
    except Exception:                                       # noqa: BLE001  (Today still shows; sizes marked unknown)
        return f"Risk {pct(cfg, stream):g}% a trade. Lots unknown: they could not be worked out."


def card(conn: sqlite3.Connection, cfg, now, alert, stream: str, dist: float | None, fallback_usd: float,
         factor: float = 1.0, note: str = ""):
    """Sizes first, then the risk budget of the MT5-linked account, named (app/paper2/budget.py, whose warning leads),
    and "unknown (no MT5 link)" for every other account (never pooled); never raises."""
    from dataclasses import replace
    from app.paper2 import budget
    money = None
    try:
        lines, money = _block(conn, cfg, stream, dist, factor, note)
        alert = on_card(alert, lines)
    except Exception:                                       # noqa: BLE001  (the card still goes)
        alert = on_card(alert, [f"Risk {pct(cfg, stream):g}% a trade.", "Lots unknown: they could not be worked out."])
    this = money if money is not None else risk_usd(cfg, stream, fallback_usd) * factor
    linked = next((lb for lb, _, ln in accounts(cfg) if ln), None)
    alert = budget.with_line(conn, cfg, now, alert, this, linked)
    others = [lb for lb, _, ln in accounts(cfg) if not ln]
    if others:
        alert = replace(alert, body=alert.body + "\n" + " ".join(f"Risk budget ({lb}): unknown (no MT5 link)."
                                                                  for lb in others))
    return alert


def basis(cfg, stream: str) -> str:
    """What a dollar record is measured at: "0.46% of the $6K account", or the section's dollars with no balance set."""
    if cfg.funded.initial_balance is None:
        return "the configured dollars (no account balance set)"
    return f"{pct(cfg, stream):g}% of the {label(float(cfg.funded.initial_balance))} account"
