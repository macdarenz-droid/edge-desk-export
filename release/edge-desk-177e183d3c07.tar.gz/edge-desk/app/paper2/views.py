"""PB-GBP and ME-CHF on Today: one block each in "Paper streams" (app/t1m/views.py lists them after G-FIX). Every word
is made here; each block has the keys the screen reads (id, title, label, status, lines, size, forward, tested)."""
from __future__ import annotations

import sqlite3
from datetime import date, datetime, timedelta

from app.gfix.rule import minute_ts
from app.mechf import alerts as MA
from app.mechf import rule as ME
from app.paper2 import common as C
from app.pbgbp import alerts as PA
from app.pbgbp import rule as PB
from app.timeutil import LONDON

LATE_S = 15 * 60
SIDE = {1: "buy", -1: "sell"}


def _london(now: datetime) -> tuple[date, int]:
    t = now.astimezone(LONDON)
    return t.date(), t.hour * 60 + t.minute


def _feed(conn: sqlite3.Connection, cfg, instrument: str, prefix: str, name: str, now: datetime) -> str | None:
    """A status when the pair's prices cannot be used, else None."""
    if not cfg.feed.enabled:
        return "Off: no price feed"
    from app.feed.oanda import state as feed_state
    halted = feed_state(conn, prefix + "halted")
    if halted:
        return f"{name} feed stopped: {halted}"
    mk = C.marker(conn, instrument)
    if mk is None:
        return f"No {name} prices yet"
    day, _ = _london(now)
    if day.weekday() < 5 and now.timestamp() - int(mk) > LATE_S:
        return f"{name} prices late: complete to {PA.london_hm(int(mk))} London ({PA.melb(int(mk))} Melbourne)"
    return None


def record(conn: sqlite3.Connection, stream: str, pips_key: str, r_key: str, risk_usd: float) -> dict:
    rows = C.closed(conn, stream)
    n = len(rows)
    pips = [float(r[pips_key]) for r in rows]
    return {"n": n, "pips": sum(pips), "win": sum(1 for p in pips if p > 0),
            "usd": sum(float(r[r_key]) for r in rows) * risk_usd, "since": rows[0]["day"] if rows else None}


def _forward(rec: dict, started: str | None, basis: str = "the suggested size") -> str:
    if rec["n"]:
        return (f"Paper record since {date.fromisoformat(rec['since']):%d %b %Y}: {rec['n']} trades,"
                f" {100 * rec['win'] / rec['n']:.0f}% winners, {rec['pips'] / rec['n']:+.1f} pips a trade;"
                f" {'+' if rec['usd'] >= 0 else '-'}${abs(rec['usd']):,.0f} at {basis}.")
    if started:
        return f"Paper record since {date.fromisoformat(started):%d %b %Y}: no trades yet."
    return "Paper record: starts with the first run."


# ------------------------------------------------------------------ PB-GBP
def _pb_open(conn: sqlite3.Connection) -> tuple[str, dict] | None:
    r = conn.execute("SELECT day FROM paper_event WHERE stream = ? AND stage = 'signal' AND day NOT IN (SELECT day FROM"
                     " paper_event WHERE stream = ? AND stage IN ('closed','skipped')) ORDER BY day DESC LIMIT 1",
                     (PB.RULE_ID, PB.RULE_ID)).fetchone()
    return None if r is None else (r[0], C.events(conn, PB.RULE_ID, date.fromisoformat(r[0])))


def _pb_status(conn: sqlite3.Connection, cfg, now: datetime) -> tuple[str, list[str]]:
    bad = _feed(conn, cfg, "GBP_USD", "gbp:", "GBP/USD", now)
    if bad:
        return bad, []
    day, minute = _london(now)
    op = _pb_open(conn)
    if op is not None:
        d, ev = date.fromisoformat(op[0]), op[1]
        side = int(ev["signal"]["side"])
        out = (f"Out at 21:55 London {PA.next_weekday(d):%a} ({PA.melb(minute_ts(PA.next_weekday(d), PB.EXIT))}"
               " Melbourne)")
        if "filled" in ev:
            f = ev["filled"]
            return (f"Paper {SIDE[side]} open from {PA.px(f['fill'])}, stop {PA.px(f['stop'])}", [out + "."])
        return (f"Signal: paper {SIDE[side]} at the next price after 22:05 London ({PA.melb(minute_ts(d, PB.ENT))}"
                " Melbourne)", [out + "."])
    t = (C.get_state(conn, "pbgbp:today") or "").split("|")
    if day.weekday() >= 5:
        return "Weekend: the next check is Monday 22:00 London", []
    if len(t) == 6 and t[0] == day.isoformat():
        ev = C.events(conn, PB.RULE_ID, day)
        if "skipped" in ev:
            return f"Signal skipped: {ev['skipped'].get('reason', '')}", []
        if t[1] == "gap":
            return "No decision today: the last GBP/USD price before 22:00 is older than 21:45 (a data gap)", []
        if "closed" in ev:
            c = ev["closed"]
            return (f"Today's paper trade made {c['pips_quoted']:+.1f} pips ({c['r_quoted']:+.2f}R) at the quoted"
                    " spread", [f"At the research's cost: {c['pips_flat']:+.1f} pips."])
        sma = "-" if t[3] == "None" else PA.px(float(t[3]))
        rsi = "-" if t[4] == "None" else f"{float(t[4]):.1f}"
        return "No signal today", [f"Close {PA.px(float(t[2]))}, 200-day average {sma}, RSI(2) {rsi}."]
    if minute < PB.CUT:
        return f"Waiting: the 22:00 London check ({PA.melb(minute_ts(day, PB.CUT))} Melbourne)", []
    return "Checking the 22:00 London close", []


def pb_block(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    c = cfg.pbgbp
    status, lines = _pb_status(conn, cfg, now)
    t = (C.get_state(conn, "pbgbp:today") or "").split("|")
    adr = float(t[5]) if len(t) == 6 and t[5] not in ("None", "") else None
    from app.paper2 import sizes                    # % of each account (owner, 11 Nov 2026)
    size = sizes.today(conn, cfg, "pbgbp", adr * PB.PIP if adr else None) + (
        f" Stop 1 x ADR20 ({adr:.1f} pips)." if adr else " Stop 1 x ADR20.")
    return {"id": PB.RULE_ID, "title": f"{PB.NAME} GBP/USD (paper)", "label": "Paper", "status": status,
            "lines": lines, "size": size,
            "forward": _forward(record(conn, PB.RULE_ID, "pips_quoted", "r_quoted",
                                    sizes.risk_usd(cfg, "pbgbp", c.risk_usd)), C.get_state(conn, "pbgbp:started"),
                                sizes.basis(cfg, "pbgbp")),
            "tested": PB.TESTED}


# ------------------------------------------------------------------ ME-CHF
def next_monthend(today: date) -> date:
    d = ME.monthend_day(today.year, today.month)
    if d < today:
        n = today.replace(day=1) + timedelta(days=32)
        d = ME.monthend_day(n.year, n.month)
    return d


def _me_status(conn: sqlite3.Connection, cfg, now: datetime) -> tuple[str, list[str]]:
    day, minute = _london(now)
    d = next_monthend(day)
    at = minute_ts(d, ME.C1559 + 1)
    if d != day:
        return f"Next: {d:%a %d %b}, 16:00 London ({MA.melb(at)} Melbourne)", []
    bad = _feed(conn, cfg, "USD_CHF", "chf:", "USD/CHF", now)
    if bad:
        return bad, ["Today is the month-end day: the 16:00 London signal needs these prices."]
    ev = C.events(conn, ME.RULE_ID, d)
    if "closed" in ev:
        x = ev["closed"]
        return (f"Today's paper {SIDE[int(x['side'])]} made {x['net']:+.1f} pips ({x['r']:+.2f}R)",
                [f"At the feed's own quotes: {x['feed_net']:+.1f} pips."])
    if "skipped" in ev:
        return f"No trade today: {ev['skipped'].get('reason', '')}", []
    if "signal" in ev:
        s = ev["signal"]
        return (f"Paper {SIDE[int(s['side'])]} from 16:01 London, out at 17:00 London"
                f" ({MA.melb(minute_ts(d, ME.C1659 + 1))} Melbourne)",
                [f"USD/CHF {'up' if s['move'] > 0 else 'down'} {abs(s['move']):.1f} pips 15:00-15:59 London; stop"
                 f" {s['adr']:.1f} pips (1 x ADR20)."])
    return f"Month-end today: the 16:00 London check ({MA.melb(at)} Melbourne)", []


def me_block(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    from app.paper2 import sizes                    # % of each account (owner, 11 Nov 2026)
    c = cfg.mechf
    status, lines = _me_status(conn, cfg, now)
    return {"id": ME.RULE_ID, "title": f"{ME.NAME} USD/CHF (paper)", "label": "Paper", "status": status,
            "lines": lines,
            "size": sizes.today(conn, cfg, "mechf", None) + " Lots on the card, once the month-end's ADR20 is known.",
            "forward": _forward(record(conn, ME.RULE_ID, "net", "r", sizes.risk_usd(cfg, "mechf", c.risk_usd)),
                                C.get_state(conn, "mechf:started"), sizes.basis(cfg, "mechf")),
            "tested": ME.TESTED}
