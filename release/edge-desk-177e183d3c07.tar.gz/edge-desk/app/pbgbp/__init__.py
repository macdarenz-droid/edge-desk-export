"""PB-GBP paper stream: GBP/USD daily pull-back in the 200-day trend. Paper only: never an order."""
