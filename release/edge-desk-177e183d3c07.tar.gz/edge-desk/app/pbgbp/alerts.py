"""PB-GBP phone alerts (queued once by key; every title says paper; never an order).

  kind            pri  key                     when
  pb_signal        4   pb_signal:<day>         22:00 London, a signal (while its entry is still ahead)
  pb_result        2   pb_result:<day>         the trade's exit (21:55 London the next weekday) or stop, within 12 h
  pb_data_stale    3   pb_data_stale:<day>     21:55-22:20 London on a weekday: GBP/USD prices over 5 minutes behind
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from app.gfix.rule import minute_ts
from app.notify.alerts import Alert
from app.pbgbp import rule
from app.timeutil import LONDON, MELBOURNE

KINDS = frozenset({"pb_signal", "pb_result", "pb_data_stale"})
SIDE = {1: "buy", -1: "sell"}


def _dt(ts: int) -> datetime:
    return datetime.fromtimestamp(int(ts), timezone.utc)


def london_hm(ts: int) -> str:
    return f"{_dt(ts).astimezone(LONDON):%H:%M}"


def melb(ts: int) -> str:
    m = _dt(ts).astimezone(MELBOURNE)
    return f"{m:%a} " + m.strftime("%I:%M %p").lstrip("0").lower()


def next_weekday(d: date) -> date:
    d += timedelta(days=1)
    while d.weekday() >= 5:
        d += timedelta(days=1)
    return d


def exit_ts(d: date) -> int:
    return minute_ts(next_weekday(d), rule.EXIT + 1)          # end of the 21:55 bar of the next weekday


def entry_expires_ts(d: date) -> int:
    """The card is no use after the entry: 22:15 London that evening, or (a Friday) Monday 00:15 London."""
    return minute_ts(next_weekday(d), 15) if d.weekday() == 4 else minute_ts(d, rule.ENT + rule.ENT_SEARCH)


def signal_expires_ts(key: str) -> int | None:
    try:
        return entry_expires_ts(date.fromisoformat(key.split(":", 1)[1]))
    except (IndexError, ValueError):
        return None


def px(pips: float | None) -> str:
    return "-" if pips is None else f"{pips * rule.PIP:.5f}"


def signal(d: date, dec: dict, risk_usd: float, now_ts: int) -> Alert:
    side = int(dec["side"])
    at = minute_ts(d, rule.CUT)
    late = now_ts - at > 180
    ent = minute_ts(d, rule.ENT)
    rel = "above" if side > 0 else "below"
    lines = []
    if late:
        lines.append(f"Late: the signal was at 22:00 London ({melb(at)} Melbourne), {max(1, (now_ts - at) // 60)} min"
                     " ago.")
    lines.append(f"Daily close {px(dec['close'])} (before 22:00 London) {rel} its 200-day average {px(dec['sma200'])};"
                 f" RSI(2) {dec['rsi2']:.1f}.")
    if d.weekday() == 4:
        lines.append(f"Friday: the market is shut at 22:05, so the paper fill is Monday's first price (00:00 London,"
                     f" {melb(minute_ts(next_weekday(d), 0))} Melbourne).")
    else:
        lines.append(f"{SIDE[side].capitalize()} at 22:05 London ({melb(ent)} Melbourne).")
    lines += [f"Stop {dec['adr20']:.1f} pips from your fill (1 x ADR20). Out at 21:55 London on"
              f" {next_weekday(d):%a} ({melb(minute_ts(next_weekday(d), rule.EXIT))} Melbourne).",
              f"Suggested size: {rule.lots(risk_usd, dec['adr20']):.2f} lots (${risk_usd:g} risk, at $10 a pip for 1"
              " lot).", rule.TESTED]
    title = ("Late: " if late else "") + f"PB-GBP {SIDE[side].upper()} GBP/USD at 22:05 London (paper)"
    return Alert(f"pb_signal:{d.isoformat()}", "pb_signal", 4, title, "\n".join(lines))


def result(d: date, t: dict, now_ts: int) -> Alert:
    """The headline is at the feed's own quotes (spec: 0.5 pip commission and the spread quoted at entry and exit);
    the research's flat cost is the second line."""
    stopped = t["state"] == "stopped"
    how = "stopped" if stopped else "out at 21:55 London"
    title = f"PB-GBP {d:%a %d %b}: {t['pips_quoted']:+.1f} pips ({t['r_quoted']:+.2f}R) (paper)"
    body = "\n".join([
        f"Paper {SIDE[int(t['side'])]} {px(t['fill'])}, {how} at {px(t['exit'])}: {t['pips_quoted']:+.1f} pips after"
        f" 0.5 pip commission and the quoted spread ({t['spread_entry']:.1f} pips at entry, {t['spread_exit']:.1f} at"
        " exit)" + (", the stop level less 0.5 pip slip." if stopped else "."),
        f"At the research's cost: {t['pips_flat']:+.1f} pips (0.5 pip commission, 0.1 pip each side"
        + (", 0.5 pip slip)." if stopped else ")."),
        "Paper only. Probable, not proven."])
    return Alert(f"pb_result:{d.isoformat()}", "pb_result", 2, title, body)


def data_stale(mk: int | None, now_ts: int, d: date, halted: str | None) -> Alert:
    what = ("No GBP/USD 1-minute prices are stored yet." if mk is None else
            f"GBP/USD 1-minute prices are {(now_ts - int(mk)) // 60} min behind (complete to {london_hm(mk)} London).")
    fix = (f" The GBP/USD feed stopped ({halted}); EUR/USD goes on. After the cause is fixed: python -m app feed"
           " --reset-halt, then restart edge-desk-feed." if halted else " Check the feed (edge-desk-feed).")
    return Alert(f"pb_data_stale:{d.isoformat()}", "pb_data_stale", 3, "PB-GBP: GBP/USD prices late",
                 what + " The 22:00 London signal cannot be made until they catch up." + fix)
