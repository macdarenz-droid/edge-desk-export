"""PB-GBP v1: GBP/USD daily pull-back in the 200-day trend (research/volume/PAPER_STREAMS_2_SPEC.md part 1; frozen
function research/volume/round27/sleeve_C/sleeve.py; spec research/volume/round27/sleeve_C/SPEC.md). Pure code: no
database, no clock. The live step and the parity replay both call these functions.

Rows are London weekdays with at least one 1-minute bar (the research grid's rows). Prices: mid = (bid + ask) / 2, in
pips (price / 0.0001).
  close(k)   the close of the last bar starting before 22:00 London (no bar: no close, left out of the series)
  SMA200     mean of the last 200 closes (today's included); RSI2: Wilder's RSI over 2 days, from the first difference
  signal     BUY if close > SMA200 and RSI2 < 10; SELL if close < SMA200 and RSI2 > 90
  ADR20      mean of (day high - day low, 00:00-23:59) over the 20 rows before k; missing if any of them has < 50 bars
  entry      the first bar 22:05-22:14 of row k, else the first bar of row k+1; fill = mid open + side x 0.1 pip
  stop       1 x ADR20 from the fill, watched on the closing side (mid high + 0.1 / mid low - 0.1) from the entry bar
  exit       the close of the last bar at or before 21:55 of row k+1 (mid - side x 0.1); one position at a time
  pips       flat: side x (exit - fill) - 0.5, less 0.5 more on a stop (the research's flat 0.7 a round trip)
"""
from __future__ import annotations

from dataclasses import dataclass

RULE_ID = "PBGBP-V1"
NAME = "PB-GBP"
PIP = 0.0001
CUT = 22 * 60                    # the daily close: the last bar before 22:00
ENT, ENT_SEARCH = 22 * 60 + 5, 10
EXIT = 21 * 60 + 55
SMA_N, ADR_N, MIN_BARS = 200, 20, 50
RSI_LO, RSI_HI = 10.0, 90.0
HS, COMM, SLIP = 0.1, 0.5, 0.5   # pips
FRESH_MIN = 15                   # gap guard (10 Nov 2026): the 22:00 close and the 21:55 exit from a bar this recent
TESTED = ("Paper only. Probable, not proven. 2021 - Nov 2026: 132 trades, 54% winners, +9.7 pips a trade; last 16 "
          "months flat. Your spread at 22:05 London is not measured.")


@dataclass
class Summary:
    """One row: its date, close before 22:00 (pips or None), the day's mid high and low (pips) and bar count."""
    day: object
    close: float | None
    hi: float | None
    lo: float | None
    nbars: int


def summary_of(d) -> Summary:
    """From an app.gfix.rule.Day of the whole London day (mid prices)."""
    before = [m for m in d.c if m < CUT]
    close = d.c[max(before)] / PIP if before else None
    hi = max(d.h.values()) / PIP if d.h else None
    lo = min(d.lo.values()) / PIP if d.lo else None
    return Summary(d.day, close, hi, lo, len(d.c))


def rsi2(closes: list[float]) -> float | None:
    """Wilder's RSI(2) of the last close, from the first difference on (as pandas ewm(alpha=1/2, adjust=False))."""
    au = ad = None
    for a, b in zip(closes, closes[1:]):
        d = b - a
        up, dn = max(d, 0.0), max(-d, 0.0)
        au = up if au is None else au / 2 + up / 2
        ad = dn if ad is None else ad / 2 + dn / 2
    if au is None:
        return None
    return 100 - 100 / (1 + au / (ad if ad != 0 else 1e-12))


def adr20(prev: list[Summary]) -> float | None:
    """prev: the rows before k, oldest first."""
    last = prev[-ADR_N:]
    if len(last) < ADR_N or any(s.nbars < MIN_BARS or s.hi is None for s in last):
        return None
    return sum(s.hi - s.lo for s in last) / ADR_N


def decide(rows: list[Summary], pre_closes: list[float] = ()) -> dict:
    """The decision of the last row of `rows` (all rows up to and including it, oldest first)."""
    k = rows[-1]
    closes = list(pre_closes) + [s.close for s in rows if s.close is not None]
    out = {"day": k.day, "close": k.close, "sma200": None, "rsi2": None, "adr20": adr20(rows[:-1]), "side": 0}
    if k.close is None or len(closes) < SMA_N:
        return out
    sma = sum(closes[-SMA_N:]) / SMA_N
    r = rsi2(closes)
    out.update(sma200=sma, rsi2=r)
    if k.close > sma and r is not None and r < RSI_LO:
        out["side"] = 1
    elif k.close < sma and r is not None and r > RSI_HI:
        out["side"] = -1
    return out


FRIDAY_SHUT = 21 * 60           # on a Friday the market can shut at 21:00 London (US clocks changed, UK not yet)


def _clocks_differ(day) -> bool:
    """New York and London not 5 hours apart that day (US clocks changed, UK not yet): New York's 17:00 close is 21:00
    London."""
    from datetime import datetime
    from zoneinfo import ZoneInfo
    t = datetime(day.year, day.month, day.day, 12)
    ny, ldn = t.replace(tzinfo=ZoneInfo("America/New_York")), t.replace(tzinfo=ZoneInfo("Europe/London"))
    return (ldn.utcoffset() - ny.utcoffset()).total_seconds() != 5 * 3600


def _fresh_from(day, last: int) -> int:
    """The earliest last-bar minute that is not stale: 15 minutes before `last`, or before 21:00 on a Friday when the
    market shuts at 21:00 London."""
    return min(last, FRIDAY_SHUT) - FRESH_MIN if day.weekday() == 4 and _clocks_differ(day) else last - FRESH_MIN


def close_is_fresh(d) -> bool:
    """Gap guard: the day's last bar before 22:00 starts 21:45 or later (a Friday: 20:45) (else no decision)."""
    before = [m for m in d.c if m < CUT]
    return bool(before) and max(before) >= _fresh_from(d.day, CUT)


def entry(dk, dk1) -> tuple[object, int] | None:
    """(day object, minute) of the entry bar: the first bar 22:05-22:14 of row k, else the first bar of row k+1 (None
    when neither is known yet). dk, dk1: app.gfix.rule.Day of rows k and k+1 (dk1 may be None)."""
    m = next((x for x in range(ENT, ENT + ENT_SEARCH) if x in dk.o), None)
    if m is not None:
        return dk, m
    if dk1 is None or not dk1.o:
        return None
    return dk1, min(dk1.o)


def trade(side: int, adr: float, dk, dk1) -> dict | None:
    """The paper trade of a signal on row k, as far as the bars show. dk1 must be the whole next row for a final
    result (its known_to > 21:55). Returns None when the entry is not known yet."""
    e = entry(dk, dk1)
    if e is None:
        return None
    de, em = e
    F = de.o[em] / PIP + side * HS
    S = adr
    stop = F - side * S
    out = {"side": side, "entry_day": de.day, "entry_min": em, "fill": F, "stop_pips": S, "stop": stop,
           "entry_bid": de.bid_o[em], "entry_ask": de.ask_o[em], "state": "open"}
    path = [(de, em, 1440 if de is dk else EXIT + 1)] + ([(dk1, 0, EXIT + 1)] if de is dk and dk1 is not None else [])
    for d, a, b in path:
        for m in range(a, min(b, d.known_to)):
            if m not in d.h:
                continue
            hit = (d.h[m] / PIP + HS >= stop) if side < 0 else (d.lo[m] / PIP - HS <= stop)
            if hit:
                o = d.o[m] / PIP
                X = max(stop, o + HS) if side < 0 else min(stop, o - HS)
                out.update(state="stopped", exit_day=d.day, exit_min=m, exit=X, exit_bid=d.bid_c[m],
                           exit_ask=d.ask_c[m])
                return _result(out)
    if dk1 is None or dk1.known_to <= EXIT:
        return out
    ms = [m for m in dk1.c if m <= EXIT]
    if not ms:
        out["state"] = "dropped"
        return out
    xm = max(ms)
    if xm < _fresh_from(dk1.day, EXIT):          # gap guard: no bar 21:40-21:55 (a Friday: 20:45), no exit price
        out["state"] = "stale"
        return out
    out.update(state="closed", exit_day=dk1.day, exit_min=xm, exit=dk1.c[xm] / PIP - side * HS,
               exit_bid=dk1.bid_c[xm], exit_ask=dk1.ask_c[xm])
    return _result(out)


def _result(t: dict) -> dict:
    side, stopped = t["side"], t["state"] == "stopped"
    t["pips_flat"] = side * (t["exit"] - t["fill"]) - COMM - (SLIP if stopped else 0.0)
    t["r_flat"] = t["pips_flat"] / t["stop_pips"]
    # at the feed's own quotes: buy at the ask, sell at the bid, at entry and exit (stop: the stop level as filled)
    if stopped:
        t["pips_quoted"] = t["pips_flat"]
    else:
        ein = t["entry_ask"] if side > 0 else t["entry_bid"]
        xout = t["exit_bid"] if side > 0 else t["exit_ask"]
        t["pips_quoted"] = side * (xout - ein) / PIP - COMM
    t["r_quoted"] = t["pips_quoted"] / t["stop_pips"]
    t["spread_entry"] = (t["entry_ask"] - t["entry_bid"]) / PIP
    t["spread_exit"] = (t["exit_ask"] - t["exit_bid"]) / PIP
    return t


def lots(risk_usd: float, stop_pips: float, usd_per_pip_per_lot: float = 10.0) -> float:
    if risk_usd <= 0 or stop_pips <= 0:
        return 0.0
    return int(round(risk_usd * 10000) // round(stop_pips * usd_per_pip_per_lot * 100)) / 100.0
