"""PB-GBP live step: run by the method worker every ~30 s after G-FIX (app/suggest/service.py), in its own try. Paper
only: it never touches an order. From the stored GBP_USD bars (m1_bar_gbp) below the feed's GBP marker only:
  1. fx_day summaries for every complete London weekday (the 200-day average needs about 300 of them);
  2. at 22:00 London of each weekday since the first run: the decision (rule.decide); a signal is logged (paper_event
     'signal'), offered as a suggestion and pushed (pb_signal), while its entry is still ahead;
  3. each open signal (whatever its age, before each new 22:00 check) followed to its fill ('filled') and its 21:55 London exit or stop ('closed', pb_result), with the
     suggestion's own result. A restart works the same out again and writes nothing twice.
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import date, datetime, timedelta
from hashlib import sha256
from pathlib import Path

from app.gfix.rule import minute_ts
from app.paper2 import common as C
from app.pbgbp import alerts as PA
from app.pbgbp import rule
from app.timeutil import LONDON

log = logging.getLogger("app.pbgbp")
INSTRUMENT = "GBP_USD"
CATCH_UP_DAYS = 5
PRUNED_AFTER_DAYS = 55           # app/storage.py prunes pair bars after 60 days (once summarised)
STALE_FROM, STALE_TO, STALE_AFTER_S = 21 * 60 + 55, 22 * 60 + 20, 5 * 60
CODE_SHA256 = sha256(Path(rule.__file__).read_bytes()).hexdigest()
K = "pbgbp:"


def london_now(now: datetime) -> tuple[date, int]:
    t = now.astimezone(LONDON)
    return t.date(), t.hour * 60 + t.minute


def next_weekday(d: date) -> date:
    d += timedelta(days=1)
    while d.weekday() >= 5:
        d += timedelta(days=1)
    return d


def to_summary(r: dict) -> rule.Summary:
    return rule.Summary(r["day"], r["close22"], r["hi"], r["lo"], r["nbars"])


class PbStep:
    def __init__(self, conn: sqlite3.Connection, cfg):
        self.conn, self.cfg = conn, cfg

    def run(self, now: datetime) -> dict:
        if not self.cfg.pbgbp.enabled:
            return {"status": "off"}
        conn = self.conn
        mk = C.marker(conn, INSTRUMENT)
        out = {"status": "ran", "marker": mk, "queued": [], "days": []}
        today, minute = london_now(now)
        self._stale(today, minute, mk, now, out)
        if mk is None or not self.cfg.feed.enabled:
            out["status"] = "no prices"
            return out
        C.summarize(conn, INSTRUMENT, mk, now)
        if C.get_state(conn, K + "started") is None:
            C.set_state(conn, K + "started", today.isoformat())
        start = date.fromisoformat(C.get_state(conn, K + "started"))
        self._follow_open(int(mk), now, out)
        last = C.get_state(conn, K + "decided")
        d = max(start, today - timedelta(days=CATCH_UP_DAYS + 2)) if last is None else \
            date.fromisoformat(last) + timedelta(days=1)
        while d <= today and int(mk) >= minute_ts(d, rule.CUT):
            if d.weekday() < 5:
                self._follow_open(int(mk), now, out)    # an earlier signal's 21:55 exit, before this 22:00 check
                self._decide(d, int(mk), now, out)
            C.set_state(conn, K + "decided", d.isoformat())
            d += timedelta(days=1)
        self._follow_open(int(mk), now, out)            # a signal just made: its fill may be known
        return out

    # -------------------------------------------------------------- parts
    def _open(self) -> list[date]:
        """Every signal day not closed or skipped, whatever its age (one left open would block the stream)."""
        return [date.fromisoformat(r[0]) for r in self.conn.execute(
            "SELECT day FROM paper_event WHERE stream = ? AND stage = 'signal' AND day NOT IN (SELECT day FROM"
            " paper_event WHERE stream = ? AND stage IN ('closed','skipped')) ORDER BY day", (rule.RULE_ID, rule.RULE_ID))]

    def _follow_open(self, mk: int, now: datetime, out: dict) -> None:
        for d in self._open():
            r = self._follow(d, mk, now, out)
            if r not in out["days"]:
                out["days"].append(r)

    def _stale(self, today: date, minute: int, mk: int | None, now: datetime, out: dict) -> None:
        if today.weekday() >= 5 or not (STALE_FROM <= minute < STALE_TO) or not self.cfg.feed.enabled:
            return
        if mk is None or now.timestamp() - int(mk) > STALE_AFTER_S:
            from app.feed.oanda import state as feed_state
            C.queue(self.conn, PA.data_stale(mk, int(now.timestamp()), today, feed_state(self.conn, "gbp:halted")),
                    now, out)

    def _decide(self, d: date, mk: int, now: datetime, out: dict) -> None:
        conn = self.conn
        rows = [to_summary(r) for r in C.summaries(conn, INSTRUMENT, before=d)]
        day = C.day_bars(conn, INSTRUMENT, d, minute_ts(d, rule.CUT))
        if not day.c:
            return
        rows.append(rule.summary_of(day))
        dec = rule.decide(rows)
        if dec["side"] and not rule.close_is_fresh(day):      # gap guard: the close is older than 21:45
            C.set_state(conn, K + "today", f"{d.isoformat()}|gap|{dec['close']}|{dec['sma200']}|{dec['rsi2']}"
                                           f"|{dec['adr20']}")
            return
        C.set_state(conn, K + "today", f"{d.isoformat()}|{dec['side']}|{dec['close']}|{dec['sma200']}|{dec['rsi2']}"
                                       f"|{dec['adr20']}")
        if not dec["side"]:
            return
        data = {k: dec[k] for k in ("side", "close", "sma200", "rsi2", "adr20")}
        if dec["adr20"] is None:
            C.event(conn, rule.RULE_ID, d, "skipped", minute_ts(d, rule.CUT), {"reason": "no ADR20 (a thin day in"
                                                                                         " the last 20)"}, now)
            C.event(conn, rule.RULE_ID, d, "signal", minute_ts(d, rule.CUT), data, now)     # the skip first: a kill
            return                                                                          # never leaves it open
        busy = conn.execute("SELECT COUNT(*) FROM paper_event WHERE stream = ? AND stage = 'signal' AND day < ? AND day"
                            " NOT IN (SELECT day FROM paper_event WHERE stream = ? AND stage IN ('closed','skipped'))",
                            (rule.RULE_ID, d.isoformat(), rule.RULE_ID)).fetchone()[0]
        if busy:
            C.event(conn, rule.RULE_ID, d, "skipped", minute_ts(d, rule.CUT), {"reason": "one position at a time"}, now)
            C.event(conn, rule.RULE_ID, d, "signal", minute_ts(d, rule.CUT), data, now)
            return
        C.event(conn, rule.RULE_ID, d, "signal", minute_ts(d, rule.CUT), data, now)
        if now.timestamp() < PA.entry_expires_ts(d):
            self._suggest(d, dec, now)
            from app.paper2 import sizes           # % sizes per account, then the risk budget (owner, 10-11 Nov)
            a = PA.signal(d, dec, self.cfg.pbgbp.risk_usd, int(now.timestamp()))
            C.queue(conn, sizes.card(conn, self.cfg, now, a, "pbgbp", float(dec["adr20"]) * rule.PIP,
                                     self.cfg.pbgbp.risk_usd), now, out)

    def _next_row(self, d: date, mk: int):
        """The next London weekday with bars after d, as far as known (None while not started)."""
        nd = next_weekday(d)
        for _ in range(5):
            if mk <= minute_ts(nd, 0):
                return None
            day = C.day_bars(self.conn, INSTRUMENT, nd, mk)
            if day.c or day.known_to < 24 * 60:
                return day
            nd = next_weekday(nd)                           # a complete weekday with no bars: a holiday
        return None

    def _follow(self, d: date, mk: int, now: datetime, out: dict) -> dict:
        conn = self.conn
        ev = C.events(conn, rule.RULE_ID, d)
        sig = ev["signal"]
        if sig.get("adr20") is None:                    # a signal left by an older run without its skip
            C.event(conn, rule.RULE_ID, d, "skipped", int(now.timestamp()), {"reason": "no ADR20 (a thin day in the"
                                                                                       " last 20)"}, now)
            return {"day": d.isoformat(), "state": "skipped"}
        dk = C.day_bars(conn, INSTRUMENT, d, mk)
        if not dk.c and (now.date() - d).days > PRUNED_AFTER_DAYS:
            C.event(conn, rule.RULE_ID, d, "skipped", int(now.timestamp()), {"reason": "bars pruned before it could be"
                                                                                       " followed"}, now)
            return {"day": d.isoformat(), "state": "skipped"}
        dk1 = self._next_row(d, mk)
        t = rule.trade(int(sig["side"]), float(sig["adr20"]), dk, dk1)
        if t is None:
            return {"day": d.isoformat(), "state": "waiting"}
        if "filled" not in ev:
            C.event(conn, rule.RULE_ID, d, "filled", minute_ts(t["entry_day"], t["entry_min"]),
                    {k: t[k] for k in ("side", "fill", "stop", "stop_pips", "entry_bid", "entry_ask")}
                    | {"entry_day": t["entry_day"].isoformat(), "entry_min": t["entry_min"]}, now)
        if t["state"] in ("closed", "stopped"):
            data = {k: t[k] for k in ("side", "fill", "stop", "stop_pips", "exit", "pips_flat", "r_flat", "pips_quoted",
                                      "r_quoted", "spread_entry", "spread_exit", "entry_min", "exit_min", "state")}
            data |= {"entry_day": t["entry_day"].isoformat(), "exit_day": t["exit_day"].isoformat()}
            if C.event(conn, rule.RULE_ID, d, "closed", minute_ts(t["exit_day"], t["exit_min"]), data, now):
                self._settle(d, t, now)
                if now.timestamp() - minute_ts(t["exit_day"], t["exit_min"]) < 12 * 3600:
                    C.queue(conn, PA.result(d, data, int(now.timestamp())), now, out)
        elif t["state"] == "stale":
            C.event(conn, rule.RULE_ID, d, "skipped", int(now.timestamp()), {"reason": "stale exit price (no price"
                                                                                       " 21:40-21:55)"}, now)
            self._settle(d, t, now, stale=True)
        elif t["state"] == "dropped":
            C.event(conn, rule.RULE_ID, d, "skipped", int(now.timestamp()), {"reason": "no price by 21:55 next day"}, now)
        return {"day": d.isoformat(), "state": t["state"]}

    def _suggest(self, d: date, dec: dict, now: datetime) -> None:
        from app.suggest import log as L
        at = minute_ts(d, rule.CUT)
        ref = dec["close"] * rule.PIP
        L.add_suggestion(self.conn, {
            "key": f"lead:{rule.RULE_ID}:{at}:{dec['side']}", "source": "lead", "rule_id": rule.RULE_ID,
            "code_sha256": CODE_SHA256, "offered": 1, "reason": None, "placed_ts": at, "side": int(dec["side"]),
            "entry": round(ref, 5), "stop": round(ref - dec["side"] * dec["adr20"] * rule.PIP, 5), "target": None,
            "expiry_ts": PA.exit_ts(d), "score": None, "tier": None, "w": 1.0, "ticks": {},
            "record_line": rule.TESTED, "late": 1 if now.timestamp() - at > 180 else 0}, now=now)

    def _settle(self, d: date, t: dict, now: datetime, stale: bool = False) -> None:
        from app.suggest import log as L
        row = L.by_key(self.conn, f"lead:{rule.RULE_ID}:{minute_ts(d, rule.CUT)}:{t['side']}")
        if row is not None and L.result(self.conn, row["id"]) is None and stale:
            L.settle(self.conn, row["id"], {"outcome": "filled", "exit_reason": "stale exit price", "unit": "pips"},
                     now=now)
        elif row is not None and L.result(self.conn, row["id"]) is None:
            L.settle(self.conn, row["id"], {"outcome": "filled", "exit_reason": "stop" if t["state"] == "stopped"
                                            else "time", "R_20": float(t["pips_quoted"]), "unit": "pips"}, now=now)


def step(conn: sqlite3.Connection, cfg, now: datetime, s: PbStep | None = None) -> dict | None:
    try:
        r = (s or PbStep(conn, cfg)).run(now)
    except Exception:                                       # noqa: BLE001  (logged; the loop goes on)
        log.exception("PB-GBP step failed")
        return None
    if r.get("queued"):
        log.info("PB-GBP: %s alerts queued (%s)", len(r["queued"]), ", ".join(r["queued"]))
    return r
