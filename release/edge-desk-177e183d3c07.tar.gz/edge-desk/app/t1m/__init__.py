"""T1-M paper signals (EUR/USD sell on a late-London 1-minute rally; docs/T1M_DESIGN.md). Paper only: never an order."""
