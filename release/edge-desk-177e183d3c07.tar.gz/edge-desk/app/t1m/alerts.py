"""Paper-stream phone alerts, T1-M first (app/notify/alerts.py queues and sends them; queue_alert keeps one per key,
so each is sent once across loops and restarts). Every title says paper; no alert ever places an order. A stream's
alerts carry its id in the key (rule.Stream; T1M-V1 now); the stale and silent alerts are for the step as a whole.

  kind            pri  key                              when
  t1m_signal       4   t1m_signal:<stream>:<signal ts>  a signal candle closed (sent while the day's exit is ahead)
  t1m_close_now    4   t1m_close_now:<stream>:<day>     2 minutes before the exit, while a paper trade is open
  t1m_day_result   2   t1m_day_result:<stream>:<day>    after the exit, on a day with at least one trade
  t1m_data_stale   3   t1m_data_stale:<stall>    09:55-13:05 London: the 1-minute prices over 5 minutes behind
                                                 (once a stall: the key is when the stall was first seen)
  t1m_silent       3   t1m_silent:<heartbeat>    09:55-13:05 London: no good T1-M run (in the method worker) for
                                                 over 5 minutes (raised by the server's monitor; a run that fails
                                                 does not move the heartbeat)
An alert made more than 3 minutes after its moment starts "Late".
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from app.notify.alerts import Alert
from app.t1m import rule
from app.timeutil import LONDON, MELBOURNE

KINDS = frozenset({"t1m_signal", "t1m_close_now", "t1m_day_result", "t1m_data_stale", "t1m_silent"})
SILENT_AFTER_S = 5 * 60
LATE_AFTER_S = 180
TESTED = rule.T1M_V1.tested
ECB_BEFORE = "ECB decision at {t} today, before the {x} exit: bigger moves both ways."
ECB_AFTER = "ECB decision at {t} today, after the {x} exit: close on time."
SIDE_WORD = {-1: "sell", 1: "buy"}


def _dt(ts: int) -> datetime:
    return datetime.fromtimestamp(int(ts), timezone.utc)


def london_hm(ts: int) -> str:
    return f"{_dt(ts).astimezone(LONDON):%H:%M}"


def melb_hm(ts: int) -> str:
    """'9:51 pm' in Melbourne (12-hour clock)."""
    return _dt(ts).astimezone(MELBOURNE).strftime("%I:%M %p").lstrip("0").lower()


def both(ts: int) -> str:
    return f"{london_hm(ts)} London ({melb_hm(ts)} Melbourne)"


def px(p: float) -> str:
    return f"{p:.5f}"


def _late(made_ts: int, at_ts: int) -> bool:
    return made_ts - at_ts > LATE_AFTER_S


def exit_ts(day: date, st: rule.Stream = rule.T1M_V1) -> int:
    return rule.minute_ts(day, st.exit_min + 1)          # the exit candle's close (T1-M: 13:00:00 London)


def exit_hm(st: rule.Stream = rule.T1M_V1) -> str:
    m = st.exit_min + 1
    return f"{m // 60:02d}:{m % 60:02d}"


def ecb_line(day: date, ecb_ts: int | None, st: rule.Stream = rule.T1M_V1) -> str | None:
    """The ECB line from the stored calendar row's own time (the decision moved from 13:45 to 14:15 Frankfurt time;
    app/news/families.py), never a fixed time."""
    if ecb_ts is None:
        return None
    return (ECB_BEFORE if ecb_ts < exit_ts(day, st) else ECB_AFTER).format(t=both(ecb_ts), x=exit_hm(st))


def signal_expires_ts(key: str) -> int | None:
    """A signal is no use after its day's exit (key t1m_signal:<stream>:<signal ts>); None for an unknown stream."""
    try:
        _, sid, sig = key.split(":")
        st = rule.STREAMS[sid]
        return exit_ts(datetime.fromtimestamp(int(sig), LONDON).date(), st)
    except (KeyError, ValueError):
        return None


def signal(day: date, t: dict, size: str, now_ts: int, ecb_ts: int | None, st: rule.Stream = rule.T1M_V1) -> Alert:
    """t: rule.Trade.as_dict; size: rule.size_line. The reference is the signal candle's mid close; the owner trades
    at market."""
    at = int(t["signal_ts"]) + 60                       # the signal candle's close
    late = _late(now_ts, at)
    ref = float(t["ref"])
    side = SIDE_WORD[st.side]
    stop = ref - st.side * st.stop_pips * st.pip
    title = ("Late: " if late else "") + f"{st.name} {side.upper()} {st.pair_label} now (paper)"
    above = "above" if st.side == -1 else "below"
    lines = []
    if late:
        lines.append(f"Late: the signal was at {both(at)}, {max(1, (now_ts - at) // 60)} min ago.")
    lines += [f"Signal candle {london_hm(int(t['signal_ts']))} London closed at {px(ref)} (reference price).",
              f"{side.capitalize()} at market. Stop {px(stop)}: {st.stop_pips:g} pips {above} the reference; set it"
              f" {st.stop_pips:g} pips {above} your own fill.",
              f"{size}. Lots at $10 a pip for 1 lot.",
              f"Close all {st.name} {side}s at {both(exit_ts(day, st))}."]
    if ecb_line(day, ecb_ts, st):
        lines.append(ecb_line(day, ecb_ts, st))
    lines.append(st.tested)
    return Alert(f"t1m_signal:{st.id}:{int(t['signal_ts'])}", "t1m_signal", 4, title, "\n".join(lines))


def close_now(day: date, n_open: int, now_ts: int, st: rule.Stream = rule.T1M_V1) -> Alert:
    x = exit_ts(day, st)
    side = SIDE_WORD[st.side]
    title = f"Close {st.name} {side}s at {exit_hm(st)} London (paper)"
    body = (f"{n_open} {st.name} paper {side}{'s' if n_open != 1 else ''} open. Close all at {both(x)} sharp: earlier"
            " or later hurt in the tests.\nPaper. Not proven live.")
    return Alert(f"t1m_close_now:{st.id}:{day.isoformat()}", "t1m_close_now", 4, title, body)


def day_result(day: date, trades: list[dict], now_ts: int, st: rule.Stream = rule.T1M_V1) -> Alert:
    """trades: the day's settled trades (rule.Trade.as_dict with pips)."""
    total = sum(float(t["pips"]) for t in trades)
    late = _late(now_ts, exit_ts(day, st))
    side = SIDE_WORD[st.side]
    title = ("Late: " if late else "") + f"{st.name} {day:%a %d %b}: {total:+.1f} pips (paper)"
    lines = [f"{len(trades)} paper {side}{'s' if len(trades) != 1 else ''}, {total:+.1f} pips after costs."]
    for t in trades:
        how = "stop" if t["state"] == "stopped" else exit_hm(st)
        lines.append(f"{london_hm(int(t['fill_ts']))} {side} {px(t['entry'])}, out {px(t['exit'])} ({how}):"
                     f" {float(t['pips']):+.2f}")
    lines.append("Paper. Not proven live.")
    return Alert(f"t1m_day_result:{st.id}:{day.isoformat()}", "t1m_day_result", 2, title, "\n".join(lines))


def data_stale(marker: int | None, now_ts: int, stall: int) -> Alert:
    """stall: when this stall was first seen (unix s): the key, so one stall gives one alert."""
    if marker is None:
        what = "No EUR/USD 1-minute prices are stored yet."
    else:
        what = (f"EUR/USD 1-minute prices are {(now_ts - int(marker)) // 60} min behind (complete to "
                f"{both(int(marker))}).")
    body = what + " T1-M signals cannot be seen until they catch up. Check the feed (edge-desk-feed)."
    return Alert(f"t1m_data_stale:{stall}", "t1m_data_stale", 3, "T1-M: prices late", body)


def silent(heartbeat_iso: str, now: datetime) -> Alert:
    hb = int(datetime.fromisoformat(heartbeat_iso.replace("Z", "+00:00")).timestamp())
    body = (f"The T1-M check has not run cleanly since {both(hb)}, so no T1-M signal can reach you. It runs in the method "
            "worker: restart it with: sudo systemctl restart edge-desk-method")
    return Alert(f"t1m_silent:{heartbeat_iso}", "t1m_silent", 3, "T1-M: not running", body)
