"""T1-M live step: run by the method worker every ~30 s (app/suggest/service.py run_method_forever), in its own try,
so it can never stop the method step or the other way round. Paper only: it never touches an order, the planner,
the paper book or the day guard.

Each run, from the app's own stored EUR/USD M1 bid/ask bars (m1_bar) below the feed's complete_through marker only:
  1. today's London weekday (and up to 5 earlier weekdays not finished yet, after a stop) through rule.evaluate_day,
     the same code the parity replay checks;
  2. each stage of each paper trade written once to t1m_trade (signal, filled or nofill, closed), and a finished day
     to t1m_day; a restart recomputes the same trades from the same bars and writes nothing twice;
  3. alerts (app/t1m/alerts.py), each once by its key;
  4. each counted signal logged as an offered suggestion (rule T1M-V1) for Take, Skip or Changed, settled with its
     own paper pips.
"Counted": a signal at or after the module's first run (t1m_state started_ts); the record starts there.
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import date, datetime, timedelta, timezone
from hashlib import sha256
from pathlib import Path

from app import db
from app.t1m import alerts as TA
from app.t1m import rule
from app.timeutil import LONDON, to_iso

log = logging.getLogger("app.t1m")
CATCH_UP_DAYS = 5                  # earlier weekdays still finished after a stop (a restart, a weekend)
STALE_AFTER_S = 5 * 60
# The stale and silent checks cover every stream's window, from 5 minutes before its first signal minute to 5 minutes
# after its exit (T1-M: 09:55-13:05 London).
STALE_FROM = min(s.signal_from for s in rule.STREAMS.values()) - 5
STALE_TO = max(s.exit_min + 1 for s in rule.STREAMS.values()) + 5
CLOSE_NOW_BEFORE = 2               # the "close now" alert: from 2 minutes before the exit (T1-M: 12:58 London)
RESULT_ALERT_FOR_S = 12 * 3600     # a day result is pushed only within 12 h of 13:00 London
CODE_SHA256 = sha256(Path(rule.__file__).read_bytes()).hexdigest()


def streams(cfg) -> list[tuple[rule.Stream, object]]:
    """The enabled streams with their config section ([t1m] for T1M-V1). A second stream adds its Stream to
    rule.STREAMS, a config section, and a line here."""
    out = []
    if cfg.t1m.enabled:
        out.append((rule.T1M_V1, cfg.t1m))
    return out


# ---------------------------------------------------------------- state

def get_state(conn: sqlite3.Connection, key: str) -> str | None:
    r = conn.execute("SELECT value FROM t1m_state WHERE key = ?", (key,)).fetchone()
    return None if r is None else r[0]


def set_state(conn: sqlite3.Connection, key: str, value) -> None:
    with db.transaction(conn):
        conn.execute("INSERT INTO t1m_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET"
                     " value = excluded.value", (key, str(value)))


def started_ts(conn: sqlite3.Connection, now_ts: int) -> int:
    """The module's first run (set once, never moved)."""
    v = get_state(conn, "started_ts")
    if v is None:
        with db.transaction(conn):
            conn.execute("INSERT OR IGNORE INTO t1m_state (key, value) VALUES ('started_ts', ?)", (str(now_ts),))
        v = get_state(conn, "started_ts")
    return int(v)


def london_now(now: datetime) -> tuple[date, int]:
    t = now.astimezone(LONDON)
    return t.date(), t.hour * 60 + t.minute


def ecb_today(conn: sqlite3.Connection, day: date) -> int | None:
    """The time (unix s) of an ECB rate decision on that London day in the stored MT5 calendar (app/news), or None."""
    try:
        from app.news.families import family_of
        lo, hi = rule.london_midnight_ts(day), rule.london_midnight_ts(day + timedelta(days=1))
        lo_iso = datetime.fromtimestamp(lo, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        hi_iso = datetime.fromtimestamp(hi, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        for r in conn.execute("SELECT country, name, event_utc, time_mode FROM news_event WHERE currency = 'EUR'"
                              " AND event_utc >= ? AND event_utc < ? ORDER BY event_utc", (lo_iso, hi_iso)):
            f = family_of(r["country"] or "EU", r["name"])
            if f is not None and f.key == "EU_ECB_MRO" and r["time_mode"] == "exact":
                return int(datetime.strptime(r["event_utc"], "%Y-%m-%dT%H:%M:%SZ")
                           .replace(tzinfo=timezone.utc).timestamp())
    except (sqlite3.Error, ValueError):
        return None
    return None


def bars_of(conn: sqlite3.Connection, day: date, marker: int | None) -> rule.DayBars:
    lo, hi = rule.london_midnight_ts(day), rule.london_midnight_ts(day + timedelta(days=1))
    end = hi if marker is None else min(hi, int(marker))
    rows = conn.execute("SELECT * FROM m1_bar WHERE ts >= ? AND ts < ? ORDER BY ts", (lo, end)).fetchall()
    return rule.day_bars(day, rows, end)


def complete_through(conn: sqlite3.Connection) -> int | None:
    from app.feed.oanda import complete_through as ct
    return ct(conn)


# ---------------------------------------------------------------- the step

class T1mStep:
    def __init__(self, conn: sqlite3.Connection, cfg):
        self.conn, self.cfg = conn, cfg

    def run(self, now: datetime) -> dict:
        on = streams(self.cfg)
        if not on:
            return {"status": "off"}
        conn = self.conn
        now_ts = int(now.timestamp())
        marker = complete_through(conn)
        out = {"status": "ran", "marker": marker, "queued": [], "days": []}
        today, minute = london_now(now)
        self._stale(today, minute, marker, now, out)
        if marker is None or not self.cfg.feed.enabled:
            out["status"] = "no prices"
        else:
            start = started_ts(conn, now_ts)        # the record starts once prices flow
            for st, sc in on:
                for day in self._days(st, today, start):
                    out["days"].append(self._day(st, sc, day, today, marker, start, now, out))
        set_state(conn, "heartbeat_utc", to_iso(now))     # only after a run that did not fail (the silent check)
        return out

    # -------------------------------------------------------------- parts
    def _q(self, alert, now: datetime, out: dict) -> None:
        from app.notify.alerts import queue_alert
        if queue_alert(self.conn, alert, now):
            out["queued"].append(alert.key)

    def _stale(self, today: date, minute: int, marker: int | None, now: datetime, out: dict) -> None:
        """09:55-13:05 London on a weekday, with the feed on: prices more than 5 minutes behind, once a stall."""
        if today.weekday() >= 5 or not (STALE_FROM <= minute < STALE_TO) or not self.cfg.feed.enabled:
            return
        now_ts = int(now.timestamp())
        if marker is None or now_ts - int(marker) > STALE_AFTER_S:
            stall = get_state(self.conn, "stall_ts")
            if stall is None:
                stall = str(now_ts)
                set_state(self.conn, "stall_ts", stall)
            self._q(TA.data_stale(marker, now_ts, int(stall)), now, out)
        elif get_state(self.conn, "stall_ts") is not None:
            with db.transaction(self.conn):
                self.conn.execute("DELETE FROM t1m_state WHERE key = 'stall_ts'")

    def _days(self, st: rule.Stream, today: date, start: int) -> list[date]:
        """Today (a weekday) and the earlier weekdays since the start, at most CATCH_UP_DAYS back, not finished."""
        start_day = datetime.fromtimestamp(start, LONDON).date()
        done = {r[0] for r in self.conn.execute("SELECT day FROM t1m_day WHERE stream = ? AND day >= ?",
                                                 (st.id, (today - timedelta(days=CATCH_UP_DAYS + 3)).isoformat()))}
        out, d, n = [], today, 0
        while d >= start_day and n <= CATCH_UP_DAYS:
            if d.weekday() < 5:
                if d.isoformat() not in done:
                    out.append(d)
                n += 1
            d -= timedelta(days=1)
        return sorted(out)

    def _day(self, st: rule.Stream, cfg, day: date, today: date, marker: int, start: int, now: datetime,
             out: dict) -> dict:
        conn = self.conn
        now_ts = int(now.timestamp())
        b = bars_of(conn, day, marker)
        trades = [t.as_dict(day) for t in rule.evaluate_day(b, st)]
        final = rule.day_final(b, st)
        size = rule.size_line(day, cfg.risk_usd, cfg.sizing, st.stop_pips)
        from app.paper2 import sizes
        risk = rule.risk_for(day, sizes.risk_usd(self.cfg, "t1m", cfg.risk_usd), cfg.sizing)
        x = TA.exit_ts(day, st)
        ecb, ecb_read = None, False
        made = to_iso(now)
        for t in trades:
            counted = 1 if int(t["signal_ts"]) >= start else 0
            self._stages(st, day, t, counted, made, risk)
            if not counted:
                continue
            self._suggest(st, day, t, now)
            if now_ts < x and t["state"] in ("pending", "open"):
                if not ecb_read:
                    ecb, ecb_read = ecb_today(conn, day), True
                from app.paper2 import sizes           # % sizes per account, then the risk budget (owner, 10-11 Nov)
                w = cfg.sizing == "W"
                self._q(sizes.card(conn, self.cfg, now, TA.signal(day, t, size, now_ts, ecb, st), "t1m",
                                   st.stop_pips * st.pip, cfg.risk_usd,
                                   rule.W_FACTOR.get(day.weekday(), 1.25) if w else 1.0,
                                   ", Mon/Tue half size" if w and day.weekday() in (0, 1) else ""), now, out)
        counted_trades = [t for t in trades if int(t["signal_ts"]) >= start]
        if day == today:
            _, minute = london_now(now)
            n_open = sum(1 for t in counted_trades if t["state"] in ("open", "pending"))
            if n_open and st.exit_min + 1 - CLOSE_NOW_BEFORE <= minute < st.exit_min + 1:
                self._q(TA.close_now(day, n_open, now_ts, st), now, out)
        if final:
            settled = [t for t in counted_trades if t["state"] in ("closed", "stopped")]
            with db.transaction(conn):
                pips = round(sum(float(t["pips"]) for t in settled), 2)
                conn.execute("INSERT INTO t1m_day (stream, day, trades, stops, pips, usd, made_utc)"
                             " VALUES (?,?,?,?,?,?,?) ON CONFLICT (stream, day) DO NOTHING",
                             (st.id, day.isoformat(), len(settled), sum(1 for t in settled if t["state"] == "stopped"),
                              pips, round(sum(float(t["pips"]) for t in settled) * risk / st.stop_pips, 2), made))
            if settled and now_ts - x < RESULT_ALERT_FOR_S:
                self._q(TA.day_result(day, settled, now_ts, st), now, out)
        return {"stream": st.id, "day": day.isoformat(), "trades": len(trades), "final": final}

    def _stages(self, st: rule.Stream, day: date, t: dict, counted: int, made: str, risk: float) -> None:
        """risk: the sized dollars at the stop for that day (config sizing); a closed row stores the flat pips and
        those dollars (pips x risk / stop pips)."""
        rows = [("signal", int(t["signal_ts"]) + 60, None, None, None, None, None)]
        if t.get("fill_m") is not None:
            rows.append(("filled", int(t["fill_ts"]), t["entry"], t["stop"], None, None, None))
        if t["state"] == "nofill":
            rows.append(("nofill", int(t["signal_ts"]) + 60 * (st.fill_within + 1), None, None, None, None, None))
        if t["state"] in ("closed", "stopped"):
            rows.append(("closed", int(t["exit_ts"]), t["entry"], t["stop"], t["exit"],
                         "stop" if t["state"] == "stopped" else "time", t["pips"]))
        elif t["state"] == "stale":                      # 13:00 passed with no real close in 12:54-12:59 (gap guard)
            rows.append(("closed", rule.minute_ts(day, st.exit_min) + 60, t["entry"], t["stop"], None, None, None))
        with db.transaction(self.conn):
            for stage, at, entry, stop, ex, kind, pips in rows:
                self.conn.execute(
                    "INSERT INTO t1m_trade (stream, day, signal_ts, stage, at_ts, ref, entry, stop, exit, exit_type, pips,"
                    " risk_usd, usd, counted, made_utc) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    " ON CONFLICT (stream, signal_ts, stage) DO NOTHING",
                    (st.id, day.isoformat(), int(t["signal_ts"]), stage, at, t["ref"], entry, stop, ex, kind, pips,
                     risk if pips is not None else None,
                     round(pips * risk / st.stop_pips, 2) if pips is not None else None, counted, made))

    def _suggest(self, st: rule.Stream, day: date, t: dict, now: datetime) -> None:
        """The suggestion log (app/suggest/log.py): an offered trade at the reference price, settled in pips."""
        from app.suggest import log as L
        at = int(t["signal_ts"]) + 60
        ref = float(t["ref"])
        sid, _ = L.add_suggestion(self.conn, {
            "key": f"lead:{st.id}:{at}:{st.side}", "source": "lead", "rule_id": st.id,
            "code_sha256": CODE_SHA256, "offered": 1, "reason": None, "placed_ts": at, "side": st.side,
            "entry": round(ref, 6), "stop": round(ref - st.side * st.stop_pips * st.pip, 6), "target": None,
            "expiry_ts": TA.exit_ts(day, st), "score": None, "tier": None, "w": 1.0, "ticks": {},
            "record_line": st.tested, "late": 1 if int(now.timestamp()) - at > TA.LATE_AFTER_S else 0}, now=now)
        if t["state"] in ("closed", "stopped"):
            if L.result(self.conn, sid) is None:
                L.settle(self.conn, sid, {"outcome": "filled", "exit_reason": "stop" if t["state"] == "stopped"
                                          else "time", "R_20": float(t["pips"]), "unit": "pips"}, now=now)
        elif t["state"] == "stale" and L.result(self.conn, sid) is None:
            L.settle(self.conn, sid, {"outcome": "filled", "exit_reason": "stale exit price", "unit": "pips"}, now=now)
        elif t["state"] == "nofill" and L.result(self.conn, sid) is None:
            L.settle(self.conn, sid, {"outcome": "no_trade", "exit_reason": f"no price within {st.fill_within} minutes",
                                      "unit": "pips"}, now=now)


def step(conn: sqlite3.Connection, cfg, now: datetime, s: T1mStep | None = None) -> dict | None:
    """One T1-M run for the method worker: an exception is logged and never leaves (the loop goes on)."""
    try:
        r = (s or T1mStep(conn, cfg)).run(now)
    except Exception:                                       # noqa: BLE001  (logged; the loop goes on)
        log.exception("T1-M step failed")
        return None
    if r.get("queued"):
        log.info("T1-M: %s alerts queued (%s)", len(r["queued"]), ", ".join(r["queued"]))
    return r
