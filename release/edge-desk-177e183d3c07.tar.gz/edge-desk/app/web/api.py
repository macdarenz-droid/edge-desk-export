"""JSON API for the screens and the bridge. Each handler takes (ctx, path groups, query, body) and returns a
dict (200) or (status, dict). The server (server.py) does the HTTP side: auth, CSRF header, size limits,
JSON parsing and the journal lock (except for UNLOCKED handlers, which take it themselves). EUR/USD only, as
the journal store returns it; no secret value is ever returned (settings shows yes/no only, never the VAPID
private key, and never a saved phone's endpoint or keys).

Web Push (the browser side is app/web/static/app.js and sw.js):
  GET  /api/push/key           {"configured", "public_key"}: the applicationServerKey for
                               PushManager.subscribe (null until EDGE_VAPID_PRIVATE_KEY and EDGE_VAPID_SUBJECT
                               are both set)
  POST /api/push/subscribe     PushSubscription.toJSON() -> {"ok", "devices"}; 400 bad input, 503 not configured
  POST /api/push/unsubscribe   {"endpoint"} -> {"ok", "removed", "devices"}
  POST /api/push/test          queues a push_test alert and sends it at once -> {"ok", "devices", "sent"}

Journal accounts (30 Oct 2026, docs/JOURNAL_DESIGN.md section 16; with pictures on only):
  GET  /api/journal/accounts               {"accounts": [{id, name, currency, start_fund, balance, trades, ...}]}
  POST /api/journal/accounts               {"name", "start_fund", "server_clock"?} -> {"ok", "account"} (his "New
                                           account"; server_clock: ny+7 (the default), gmt+2, gmt+3 or gmt+0)
  POST /api/journal/accounts/<id>/edit     {"name"?, "start_fund"?, "server_clock"?} -> {"ok", "account"} (each
                                           change kept; a new clock applies to readings made after it)
  GET  /api/journal?account=<id>           that account's trades and figures (account=mt5 or none: as before)
  GET  /api/calendar?account=<id>&month=   that account's days and month; no day rules (kept apart)
  GET  /api/photos?state=waiting&account=  that account's pictures waiting (none or mt5: the MT5 account's)
"""
from __future__ import annotations

import calendar as _cal
import json
import logging
import re
from pathlib import Path
from dataclasses import asdict, dataclass
from typing import Callable
from datetime import date, datetime, timedelta

from app.analytics.metrics import breakdown, by_symbol, calendar, edge_leak, equity_curve, summarize
from app.aplus import views as aplus_views
from app.ingest.live import live_view
from app.ingest.schema import PayloadError
from app.ingest.service import StaleSeqError, apply_snapshot
from app.ingest.state import latest_snapshot
from app.ingest.status import bridge_state
from app import db
from app.journal import accounts as journal_accounts
from app.journal import store
from app.journal.overlay import views as picture_views
from app.notify import alerts as alert_texts
from app.notify import push
from app.notify.alerts import alerts_for_events, cost_pct_of_risk, drain, queue_alert
from app.paper import log as paper
from app.checklist import store as checks
from app.checklist.form import FORM as CHECK_FORM
from app.costs.split import month_costs
from app.funded.limits import funded_state
from app.photos import claude as photo_claude
from app.photos import reader as photo_reader
from app.photos import store as photo_store
from app.photos import trades as photo_trades
from app.news import headlines as headline_views
from app.news import views as news_views
from app.news.store import StaleCalSeq, apply_calendar
from app.planner.service import latest_plan
from app.suggest import log as suggest_log
from app.suggest import views as suggest_views
from app.t1m import views as t1m_views
from app.risk.flags import INFO_FLAGS, guard_now, streak_now
from app.timeutil import LONDON, NEW_YORK, UTC, day_bounds, london_open_utc, market_open, ny_open_utc, to_iso, \
    trading_day

log = logging.getLogger("edge.api")
BRIDGE_PATH = "/api/bridge/v1/snapshot"
CALENDAR_PATH = "/api/bridge/v1/calendar"      # edge-calendar/2 (or /1) from the same EA (app/news); not in ROUTES
_MONTH = re.compile(r"\d{4}-(0[1-9]|1[0-2])")
_NOT_FOUND = (store.NotFoundError, paper.NotFoundError, checks.NotFoundError, picture_views.NotFound,
              journal_accounts.NotFound)


@dataclass(frozen=True)
class Raw:
    """A response that is not JSON (the trade picture): the server answers 304 when If-None-Match names the ETag,
    else calls body() and sends it as ctype with its own ETag and Cache-Control; if body() fails, a 500 with the
    fixed short text `fail` (never the error's own text)."""
    body: Callable[[], bytes]
    ctype: str
    etag: str
    cache: str
    fail: str


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def _keys(body: dict | None, allowed: set[str], required: set[str] = frozenset()) -> dict:
    body = body or {}
    extra = set(body) - allowed
    if extra:
        raise ApiError(400, f"unknown fields: {', '.join(sorted(extra))}")
    missing = set(required) - set(body)
    if missing:
        raise ApiError(400, f"missing fields: {', '.join(sorted(missing))}")
    return body


def _book(query: dict) -> str:
    book = query.get("book") or "mt5"
    if book not in ("mt5", "paper"):
        raise ApiError(400, "book must be mt5 or paper")
    return book


def _now(ctx) -> datetime:
    return ctx.clock()


# ---------------------------------------------------------------- rules shown on Today and Rules


def rule_list(cfg) -> list[dict]:
    """The owner's rules with their limits, from config (never constants here)."""
    r, m, s = cfg.risk, cfg.management, cfg.streak
    k = r.trades_after_first_win
    rules = [
        {"id": "max_losses", "label": f"Max {r.max_losses_per_day} losses a day", "limit": r.max_losses_per_day},
        {"id": "after_win", "label": f"After a win: {k} more trade{'s' if k != 1 else ''}", "limit": k},
        {"id": "loss_after_win", "label": "A loss after a win ends the day", "limit": r.loss_after_win_ends_day},
        {"id": "open_risk", "label": f"Losses + open + pending below {r.max_losses_per_day}",
         "limit": r.max_losses_per_day},
        {"id": "risk_pct", "label": f"Risk {r.risk_pct_per_trade:.2f}% per trade", "limit": r.risk_pct_per_trade},
        {"id": "stop", "label": "Every trade has a stop", "limit": True},
        {"id": "breakeven", "label": f"Stop to entry from +{m.breakeven_from_r:g}R to +{m.breakeven_to_r:g}R",
         "limit": m.breakeven_from_r},
        {"id": "take_or_trail", "label": f"At +{m.take_or_trail_r:g}R: close, or trail the stop to "
                                         f"+{m.trail_stop_r:g}R", "limit": m.take_or_trail_r},
        {"id": "order_expiry", "label": f"Orders expire {cfg.planner.order_expiry_london:%H:%M} London",
         "limit": f"{cfg.planner.order_expiry_london:%H:%M}"},
    ]
    if s.enabled:
        rules.append({"id": "streak", "label": f"Streak mode after {s.green_days_to_start} green days: targets "
                                               f"{s.target_min_r:g}R to {s.target_max_r:g}R; floor "
                                               f"{s.floor_fraction:.0%} of the peak",
                      "limit": s.green_days_to_start})
    return rules


# ---------------------------------------------------------------- GET


def _next_trading_day(cfg, now: datetime) -> date:
    """The trading day now, or while the market is shut (weekend) the one the next open starts."""
    d = cfg.day
    at = now
    for _ in range(4 * 24 * 4):                     # at most four days ahead, in 15-minute steps
        if market_open(at):
            return trading_day(at, d.boundary_tz, d.boundary_hour)
        at += timedelta(minutes=15)
    return trading_day(now, d.boundary_tz, d.boundary_hour)


def _card_extras(cfg, c: dict) -> dict:
    """Display fields for an order card: paper.cost_pips as % of the stop distance (what costs take from 1R)
    and the level the planner named, worded here so the screens hold no strategy words."""
    cost = cost_pct_of_risk(cfg, c["entry"], c["stop"]) if c.get("entry") is not None and c.get("stop") is not None \
        else None
    return dict(c, cost_pct_of_risk=cost, level_note=f"Swept {c['swept_level']}" if c.get("swept_level") else None)


def _with_card_costs(cfg, plan: dict) -> dict:
    cards = plan.get("cards")
    if isinstance(cards, list):
        plan = dict(plan, cards=[_card_extras(cfg, c) for c in cards])
    return plan


def today(ctx, groups, query, body):
    cfg, conn, now = ctx.cfg, ctx.conn, _now(ctx)
    d = cfg.day
    day = trading_day(now, d.boundary_tz, d.boundary_hour)
    start, end = day_bounds(day, d.boundary_tz, d.boundary_hour)
    lo, ny = london_open_utc(day, d.london_open), ny_open_utc(day, d.ny_open)
    plan = latest_plan(conn, day)
    if plan is None:
        at = datetime.combine(day, cfg.planner.plan_time_london, LONDON).astimezone(UTC)
        plan = {"pending": True, "plan_time_utc": to_iso(at), "market_closed": not market_open(at)}
    else:
        plan = _with_card_costs(cfg, plan)
    return {
        "now_utc": to_iso(now),
        "clocks": {"melbourne": now.astimezone(cfg.app.display_tz).isoformat(timespec="seconds"),
                   "london": now.astimezone(LONDON).isoformat(timespec="seconds"),
                   "new_york": now.astimezone(NEW_YORK).isoformat(timespec="seconds")},
        "trading_day": day.isoformat(),
        "market_open": market_open(now),
        "next_trading_day": _next_trading_day(cfg, now).isoformat(),
        "sessions": [{"name": "asia", "start_utc": to_iso(start), "end_utc": to_iso(lo)},
                     {"name": "london", "start_utc": to_iso(lo), "end_utc": to_iso(ny)},
                     {"name": "new_york", "start_utc": to_iso(ny), "end_utc": to_iso(end)}],
        "plan": plan,
        "guard": guard_now(conn, cfg, now, "mt5").to_dict(),
        "paper_guard": guard_now(conn, cfg, now, "paper").to_dict(),
        "streak": streak_now(conn, cfg, now, "mt5").to_dict(),
        "funded": funded_state(conn, cfg, now),
        "bridge": bridge_state(conn, cfg, now),
        "checklist": [r["label"] for r in rule_list(cfg)],
        "suggestions": suggest_views.cards(conn, cfg, now),
        "news": news_views.today_block(conn, cfg, now),
        "headlines": headline_views.today_block(conn, cfg, now),
        "aplus": aplus_views.today_block(conn, cfg, now),
        "t1m": t1m_views.today_block(conn, cfg, now),
        "mode": cfg.planner.mode,
    }


def live(ctx, groups, query, body):
    return live_view(ctx.conn, ctx.cfg, _now(ctx))


def journal_tags(ctx, groups, query, body):
    """The trade picture's page text (app/journal/overlay/views.py, docs/JOURNAL_DESIGN.md D11)."""
    return picture_views.tags(ctx.conn, ctx.cfg, groups["ref"], _now(ctx))


def journal_chart(ctx, groups, query, body):
    """The trade picture itself: a server-made SVG (docs/JOURNAL_DESIGN.md section 7.4)."""
    rep = picture_views.chart(ctx.conn, groups["ref"], query.get("view"), query.get("theme"))
    return Raw(rep.render, rep.ctype, rep.etag, rep.cache, picture_views.UNDRAWABLE)


def _account(ctx, query) -> int | None:
    """The account a screen asks for (?account=): None for the MT5 account (none, or "mt5"), else a journal account
    that exists (404 otherwise; journal accounts need pictures on)."""
    try:
        aid = journal_accounts.parse(query.get("account"))
    except ValueError as exc:
        raise ApiError(400, str(exc)) from None
    if aid is None:
        return None
    _photos_dir(ctx)
    if not journal_accounts.exists(ctx.conn, aid):
        raise ApiError(404, "no such account")
    return aid


def journal(ctx, groups, query, body):
    aid = _account(ctx, query)
    if aid is not None:          # a journal account: its picture trades only, with its own figures
        return {"book": "journal", "account": journal_accounts.public(ctx.conn, ctx.cfg, aid),
                "trades": store.list_account_trades(ctx.conn, ctx.cfg, aid, query.get("from") or None,
                                                    query.get("to") or None)}
    book = _book(query)
    trades = store.list_trades(ctx.conn, ctx.cfg, book, query.get("from") or None, query.get("to") or None,
                               include_photo=ctx.cfg.photos.enabled)
    if book == "paper":     # A2: paper R at the pass case (2.0 pips) with the 1.6-pip line beside it
        for t in trades:
            t.update(cost_pips=ctx.cfg.paper.cost_pips, cost_pips_info=ctx.cfg.paper.cost_pips_info,
                     r_net_info=paper.r_at_cost(t, ctx.cfg, ctx.cfg.paper.cost_pips_info))
    return {"book": book, "trades": trades}


def _month(ctx, query) -> str:
    month = query.get("month")
    if month is None:
        d = ctx.cfg.day
        month = trading_day(_now(ctx), d.boundary_tz, d.boundary_hour).strftime("%Y-%m")
    if not _MONTH.fullmatch(month):
        raise ApiError(400, "month must look like 2026-10")
    return month


def calendar_view(ctx, groups, query, body):
    aid = _account(ctx, query)
    if aid is not None:
        return _account_calendar(ctx, query, aid)
    cfg, book, month = ctx.cfg, _book(query), _month(ctx, query)
    y, m = (int(x) for x in month.split("-"))
    first, last = date(y, m, 1), date(y, m, _cal.monthrange(y, m)[1])
    trades = store.list_trades(ctx.conn, cfg, book, first, last, include_photo=cfg.photos.enabled)
    every_symbol = store.list_trades(ctx.conn, cfg, book, first, last, eurusd_only=False)   # the day rules
    in_month = [t for t in trades if (t.get("close_trading_day") or "").startswith(month + "-")
                and photo_trades.counts_in_r_stats(t)]          # picture trades without exact R are listed apart
    return {"book": book, "month": month, "days": calendar(trades, month, cfg.risk, day_rule_trades=every_symbol),
            "summary": summarize(in_month, cfg.analytics.min_trades, cfg.risk.breakeven_band_r,
                                 risk_pct=cfg.risk.risk_pct_per_trade),
            "news": news_views.calendar_block(ctx.conn, cfg, month, _now(ctx))}


def _account_calendar(ctx, query, aid: int) -> dict:
    """A journal account's month: its own trades, R and %; the day rules (the loss limit) are the MT5 account's and
    never applied here (kept apart), and its summary has no estimate at his MT5 risk %."""
    cfg, month = ctx.cfg, _month(ctx, query)
    y, m = (int(x) for x in month.split("-"))
    first, last = date(y, m, 1), date(y, m, _cal.monthrange(y, m)[1])
    trades = store.list_account_trades(ctx.conn, cfg, aid, first, last)
    days = calendar(trades, month, cfg.risk, day_rule_trades=[])
    for cell in days:
        cell["hit_loss_limit"] = False
    in_month = [t for t in trades if (t.get("close_trading_day") or "").startswith(month + "-")
                and photo_trades.counts_in_r_stats(t)]
    return {"book": "journal", "month": month, "account": journal_accounts.public(ctx.conn, cfg, aid), "days": days,
            "summary": summarize(in_month, cfg.analytics.min_trades, cfg.risk.breakeven_band_r, risk_pct=None),
            "news": news_views.calendar_block(ctx.conn, cfg, month, _now(ctx))}


def edge(ctx, groups, query, body):
    cfg, book = ctx.cfg, _book(query)
    trades = store.list_trades(ctx.conn, cfg, book)
    n, band = cfg.analytics.min_trades, cfg.risk.breakeven_band_r
    return {"book": book, "summary": summarize(trades, n, band, risk_pct=cfg.risk.risk_pct_per_trade),
            "equity": equity_curve(trades),
            "leak": edge_leak(trades, n, band), "by_session": breakdown(trades, "session", n, band),
            "by_stop": breakdown(trades, "stop_bucket", n, band), "by_weekday": breakdown(trades, "weekday", n, band),
            "by_management": breakdown(trades, "management", n, band, management=cfg.management), "min_trades": n,
            "by_symbol": by_symbol(store.list_trades(ctx.conn, cfg, book, eurusd_only=False), n, band, cfg.is_eurusd),
            "month_costs": month_costs(ctx.conn, cfg, book), "by_tick": checks.results_by_tick(ctx.conn, cfg),
            "hand_check": suggest_views.hand_check(ctx.conn, cfg)}


def _week(ctx) -> str:
    iso = _now(ctx).astimezone(ctx.cfg.app.display_tz).isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


def rules(ctx, groups, query, body):
    cfg, book = ctx.cfg, _book(query)
    trades = store.list_trades(ctx.conn, cfg, book)
    n = len(trades)
    clean = sum(1 for t in trades if not set(t.get("flags") or ()) - INFO_FLAGS and t.get("tag") != "rule_break")
    enough = n >= cfg.analytics.min_trades
    week = _week(ctx)
    note = store.get_review_note(ctx.conn, week)
    return {"rules": rule_list(cfg),
            "adherence": {"n": n, "clean": clean, "pct": clean / n * 100 if n else None,
                          "label": None if enough else "too early"},
            "review": {"week": week, "action_item": note["action_item"] if note else ""}}


def settings(ctx, groups, query, body):
    cfg = ctx.cfg
    state = bridge_state(ctx.conn, cfg, _now(ctx))
    snap = latest_snapshot(ctx.conn, cfg.account.alias)
    broker = None
    if snap:
        broker = next((dict(v) for k, v in sorted(snap.get("symbols", {}).items()) if cfg.is_eurusd(k)), None)
    mode = ((snap or {}).get("account") or {}).get("trade_mode")
    return {
        "account_alias": cfg.account.alias,
        "account_mode": mode if mode in ("demo", "contest", "real") else None,   # what MT5 reports for the account
        "currency": cfg.account.currency,
        "instrument": {"symbol": cfg.instrument.symbol, "broker_symbols": list(cfg.instrument.broker_symbols),
                       "pip_size": cfg.instrument.pip_size},
        "risk": asdict(cfg.risk), "streak": asdict(cfg.streak), "management": asdict(cfg.management),
        "day": {"boundary_tz": str(cfg.day.boundary_tz), "boundary_hour": cfg.day.boundary_hour,
                "london_open": f"{cfg.day.london_open:%H:%M}", "ny_open": f"{cfg.day.ny_open:%H:%M}"},
        "planner": {"mode": cfg.planner.mode, "strategy": cfg.planner.strategy,
                    "order_expiry_london": f"{cfg.planner.order_expiry_london:%H:%M}",
                    "plan_time_london": f"{cfg.planner.plan_time_london:%H:%M}"},
        "analytics": {"min_trades": cfg.analytics.min_trades},
        "funded": {"enabled": cfg.funded.enabled, "initial_balance": cfg.funded.initial_balance,
                   "daily_loss_pct": cfg.funded.daily_loss_pct, "max_loss_pct": cfg.funded.max_loss_pct,
                   "risk_cap_pct": cfg.funded.risk_cap_pct, "alert_at": list(cfg.funded.alert_at)},
        "paper": {"balance": cfg.paper.balance, "cost_pips": cfg.paper.cost_pips,
                  "cost_pips_info": cfg.paper.cost_pips_info},
        "bridge": {"contract": cfg.bridge.contract, "url_path": BRIDGE_PATH, "state": state["state"],
                   "last_seen_utc": state["last_seen_utc"], "seq": state["seq"],
                   "trade_allowed": state["trade_allowed"], "stale_after_s": cfg.bridge.stale_after_s,
                   "offline_after_s": cfg.bridge.offline_after_s, "broker_clock": cfg.bridge.broker_clock},
        "broker": broker,
        # the picture reader's key is never in serve's environment: its state is in "photos" below (app/photos/reader.py)
        "secrets": {k: v for k, v in cfg.secrets.present().items() if k != "anthropic_key"},
        "push": {"configured": _push_key(ctx) is not None, "devices": push.count_subscriptions(ctx.conn),
                 "public_key": _push_key(ctx)},
        "news": news_views.settings_block(ctx.conn, cfg),
        "headlines": headline_views.settings_block(ctx.conn, cfg),
        "photos": {"enabled": cfg.photos.enabled, "keep_days": cfg.photos.keep_days,
                   "max_bytes": cfg.photos.max_bytes, "reader": cfg.photos.reader,
                   "key": photo_reader.key_state(ctx.conn),        # set / not_set / not_working, never the key
                   "month_usd": round(photo_claude.month_spend(ctx.conn, _now(ctx)), 2),
                   "cap_usd": cfg.photos.monthly_usd_cap},
    }


def paper_list(ctx, groups, query, body):
    return {"orders": paper.list_orders(ctx.conn, query.get("status") or None)}


# ---------------------------------------------------------------- POST


def choice(ctx, groups, query, body):
    b = _keys(body, {"tag", "decision", "would_take", "management", "note"}, {"tag"})
    tid = int(groups["id"])
    trade = store.get_trade(ctx.conn, tid)
    if trade is None or not ctx.cfg.is_eurusd(trade["symbol"]):
        raise ApiError(404, "trade not found")
    wt = b.get("would_take")
    if wt is not None and not isinstance(wt, bool):
        raise ApiError(400, "would_take must be true, false or null")
    return store.set_choice(ctx.conn, tid, b["tag"], b.get("decision"), wt, b.get("management"), b.get("note", ""),
                            now=_now(ctx))


def rules_review(ctx, groups, query, body):
    b = _keys(body, {"week", "action_item"}, {"week", "action_item"})
    note = store.set_review_note(ctx.conn, b["week"], b["action_item"], now=_now(ctx))
    return {"week": note["week"], "action_item": note["action_item"]}


def _order(ctx, oid: int) -> dict:
    row = ctx.conn.execute("SELECT * FROM paper_order WHERE id = ?", (oid,)).fetchone()
    if row is None:
        raise ApiError(404, "paper order not found")
    return dict(row)


_PAPER_FIELDS = {"side", "order_type", "entry", "stop", "target", "expiry_utc", "risk_pct", "lots", "opportunity_id",
                 "note", "symbol", "rule_break"}


def _rule_break(b: dict) -> bool:
    """Log a paper order or fill the day guard would refuse, on purpose (it is then flagged)."""
    value = b.get("rule_break", False)
    if not isinstance(value, bool):
        raise ApiError(400, "rule_break must be true or false")
    return value


def paper_create(ctx, groups, query, body):
    b = _keys(body, _PAPER_FIELDS, {"side", "order_type", "entry", "stop", "target"})
    oid = paper.create_order(ctx.conn, ctx.cfg, side=b["side"], order_type=b["order_type"], entry=b["entry"],
                             stop=b["stop"], target=b["target"], expiry_utc=b.get("expiry_utc"),
                             risk_pct=b.get("risk_pct"), lots=b.get("lots"), opportunity_id=b.get("opportunity_id"),
                             note=b.get("note", ""), now=_now(ctx), symbol=b.get("symbol"),
                             rule_break=_rule_break(b))
    return {"order": _order(ctx, oid)}


def paper_action(ctx, groups, query, body):
    oid, action = int(groups["id"]), groups["action"]
    now = _now(ctx)
    if action == "fill":
        b = _keys(body, {"fill_price", "filled_utc", "rule_break"}, {"fill_price"})
        return {"order": paper.fill(ctx.conn, ctx.cfg, oid, b["fill_price"], b.get("filled_utc") or now, now=now,
                                    rule_break=_rule_break(b))}
    if action == "close":
        b = _keys(body, {"exit_price", "closed_utc", "reason"}, {"exit_price", "reason"})
        tid = paper.close(ctx.conn, ctx.cfg, oid, b["exit_price"], b.get("closed_utc") or now, b["reason"], now=now)
        return {"order": _order(ctx, oid), "trade": store.get_trade(ctx.conn, tid)}
    b = _keys(body, {"at_utc"})
    fn = paper.cancel if action == "cancel" else paper.expire
    return {"order": fn(ctx.conn, ctx.cfg, oid, b.get("at_utc") or now, now=now)}


# ---------------------------------------------------------------- Web Push


def _push_key(ctx) -> str | None:
    """The VAPID public key when push is configured (both env values), else None."""
    return getattr(ctx, "push_public_key", None) if ctx.cfg.secrets.push_configured else None


def push_key(ctx, groups, query, body):
    key = _push_key(ctx)
    return {"configured": key is not None, "public_key": key}


def push_subscribe(ctx, groups, query, body, user_agent: str = ""):
    if _push_key(ctx) is None:
        raise ApiError(503, "push not configured")
    b = _keys(body, {"endpoint", "keys", "expirationTime"}, {"endpoint", "keys"})   # expirationTime is ignored
    push.save_subscription(ctx.conn, {"endpoint": b["endpoint"], "keys": b["keys"]}, user_agent, _now(ctx))
    return {"ok": True, "devices": push.count_subscriptions(ctx.conn)}


def push_unsubscribe(ctx, groups, query, body):
    b = _keys(body, {"endpoint"}, {"endpoint"})
    if not isinstance(b["endpoint"], str):
        raise ApiError(400, "endpoint must be text")
    removed = push.delete_subscription(ctx.conn, b["endpoint"])
    return {"ok": True, "removed": removed, "devices": push.count_subscriptions(ctx.conn)}


def push_test(ctx, groups, query, body):
    """Runs without the server's journal lock: queue_alert and drain take it only for their reads and writes,
    never while an alert is on its way."""
    _keys(body, set())
    if _push_key(ctx) is None or ctx.client is None:
        raise ApiError(503, "push not configured")
    now = _now(ctx)
    alert = alert_texts.push_test(now)
    queue_alert(ctx.conn, alert, now)
    drain(ctx.conn, ctx.client, now)
    with db._LOCK:
        row = ctx.conn.execute("SELECT status FROM alert WHERE key = ?", (alert.key,)).fetchone()
    return {"ok": True, "devices": push.count_subscriptions(ctx.conn),
            "sent": row is not None and row["status"] == "sent"}


# ---------------------------------------------------------------- bridge


def bridge_snapshot(ctx, payload: dict) -> tuple[int, dict]:
    """Store one edge-bridge/1 snapshot, then queue the alerts its events raise."""
    now = _now(ctx)
    try:
        res = apply_snapshot(ctx.conn, ctx.cfg, payload, now)
    except StaleSeqError:
        return 409, {"ok": False, "error": "stale seq"}
    except PayloadError as exc:
        return 400, {"ok": False, "error": str(exc)}
    try:
        for a in alerts_for_events(ctx.conn, ctx.cfg, res.events, now):
            queue_alert(ctx.conn, a, now)
    except Exception as exc:  # noqa: BLE001 - the snapshot is stored; a broken alert must not refuse it
        log.error("alerts for snapshot seq %s failed: %s", res.seq, type(exc).__name__)
    return 200, {"ok": True, "seq": res.seq, "stored_deals": res.stored_deals}


def bridge_calendar(ctx, payload: dict) -> tuple[int, dict]:
    """Store one edge-calendar/2 (or /1) post (app/news). The EA matches its own `"cal_seq":n,` in the reply, so the key
    order is as written; 404 tells it news is off in config (it stops calendar sends until it restarts)."""
    if not ctx.cfg.news.enabled:
        return 404, {"ok": False, "error": "news is off"}
    try:
        r = apply_calendar(ctx.conn, ctx.cfg, payload, _now(ctx))
    except StaleCalSeq:
        return 409, {"ok": False, "error": "stale cal_seq"}
    except PayloadError as exc:
        return 400, {"ok": False, "error": str(exc)}
    out = {"ok": True, "cal_seq": r.cal_seq, "stored": r.stored}
    if r.ignored:
        out["ignored"] = r.ignored               # the post's clock disagreed with the snapshot's: nothing stored
    return 200, out


# ---------------------------------------------------------------- setup checks (A3)

_TESTED_PATH = Path(__file__).resolve().parent.parent / "checklist" / "tested.json"


def _tested() -> dict:
    return json.loads(_TESTED_PATH.read_text(encoding="utf-8"))["lines"]


def checks_list(ctx, groups, query, body):
    return {"checks": checks.list_checks(ctx.conn, ctx.cfg), "tested": _tested(), "form": CHECK_FORM,
            "by_tick": checks.results_by_tick(ctx.conn, ctx.cfg)}


def checks_create(ctx, groups, query, body):
    b = _keys(body, {"fields"}, {"fields"})
    return {"check": checks.create_check(ctx.conn, ctx.cfg, b["fields"], now=_now(ctx))}


def checks_action(ctx, groups, query, body):
    cid, action, now = int(groups["id"]), groups["action"], _now(ctx)
    if action == "edit":
        b = _keys(body, {"fields"}, {"fields"})
        return {"check": checks.edit_check(ctx.conn, ctx.cfg, cid, b["fields"], now=now)}
    b = _keys(body, {"order_ticket", "trade_id"})
    if ("order_ticket" in b) == ("trade_id" in b):
        raise ApiError(400, "give order_ticket or trade_id")
    if "order_ticket" in b:
        return {"link": checks.tap_link(ctx.conn, ctx.cfg, cid, b["order_ticket"], now=now)}
    if isinstance(b["trade_id"], bool) or not isinstance(b["trade_id"], int):
        raise ApiError(400, "trade_id must be a whole number")
    return {"link": checks.tap_trade(ctx.conn, ctx.cfg, cid, b["trade_id"], now=now)}


def checks_link_action(ctx, groups, query, body):
    _keys(body, set())
    fn = checks.confirm_link if groups["action"] == "confirm" else checks.reject_link
    return {"link": fn(ctx.conn, int(groups["id"]), now=_now(ctx))}


# ---------------------------------------------------------------- routing

def leads_view(ctx, groups, query, body):
    return suggest_views.leads_panel(ctx.conn, ctx.cfg, _now(ctx))


def suggestion_decision(ctx, groups, query, body):
    """B9: Take, Skip or Changed on a suggestion card (Skip and Changed need a reason); a second tap writes a
    correction row. Never an order."""
    b = _keys(body, {"decision", "reason"}, {"decision"})
    if not isinstance(b["decision"], str) or not isinstance(b.get("reason", ""), str):
        raise ApiError(400, "decision and reason are text")
    sid = int(groups["id"])
    try:
        d = suggest_log.add_decision(ctx.conn, sid, b["decision"], b.get("reason", ""), now=_now(ctx))
    except LookupError:
        raise ApiError(404, "no such suggestion") from None
    except ValueError as exc:
        raise ApiError(400, str(exc)) from None
    return {"ok": True, "decision": d, "card": suggest_views.card(ctx.conn, suggest_log.get(ctx.conn, sid))}


# ---------------------------------------------------------------- the photo journal (app/photos; upload and image
# bytes are handled in server.py, outside these JSON routes)

def _photos_dir(ctx):
    if not ctx.cfg.photos.enabled or getattr(ctx, "photos_dir", None) is None:
        raise ApiError(404, "pictures are off")
    return ctx.photos_dir


def photos_list(ctx, groups, query, body):
    _photos_dir(ctx)
    trade = query.get("trade")
    if trade is not None:
        return {"photos": photo_store.list_for_trade(ctx.conn, trade)}
    if query.get("state") == "queued":
        return {"photos": photo_store.list_waiting(ctx.conn)}
    if query.get("state") == "waiting":       # one account's pictures with no trade yet: reading, ready or not read
        return {"photos": photo_reader.waiting(ctx.conn, ctx.cfg, _now(ctx), account=_account(ctx, query))}
    raise ApiError(400, "give trade=mt5:<id>, state=queued or state=waiting")


def photo_get(ctx, groups, query, body):
    _photos_dir(ctx)
    try:
        out = photo_store.get(ctx.conn, int(groups["id"]))
    except photo_store.NotFound:
        raise ApiError(404, "not found") from None
    out["reading"] = photo_reader.view(ctx.conn, ctx.cfg, out["id"])
    if out["reading"] is None and not out.get("links"):           # not read (the reader off): link it by hand
        out["link_choices"] = photo_reader.link_choices(ctx.conn, ctx.cfg, out["id"])
    return out


# ---------------------------------------------------------------- the picture reader's cards (phases 2-4)

_CONFIRM_KEYS = {"pick", "trade", "fields", "fixed", "dont_know", "first_stop", "labels", "close", "row",
                 "stop_side_ok", "line_prices"}


def photo_reading_action(ctx, groups, query, body):
    """confirm: his "Looks right" (app/photos/trades.py); read: "Read it" on an MT5 picture with no trade lines;
    keep: keep a look (linked to that trading day's trade when there is exactly one)."""
    _photos_dir(ctx)
    pid, now, action = int(groups["id"]), _now(ctx), groups["action"]
    try:
        if action == "confirm":
            b = _keys(body, _CONFIRM_KEYS)
            try:
                return {"ok": True, **photo_trades.confirm(ctx.conn, ctx.cfg, pid, b, now)}
            except photo_trades.Question as q:              # asked before it is taken (item 10; same_trade)
                out = {"ok": False, "error": str(q), "question": q.key}
                if q.choices:
                    out["choices"] = q.choices
                return 409, out
        _keys(body, set())
        row = ctx.conn.execute("SELECT * FROM photo WHERE id = ?", (pid,)).fetchone()
        if row is None or row["state"] in ("deleted", "receiving", "queued", "failed"):
            raise ApiError(404, "not found")
        if action == "read":
            if row["state"] not in ("read", "needs_taps") or row["kind"] not in ("look_mt5", "chart"):
                raise ApiError(400, "only an MT5 picture can be read again")
            with db.transaction(ctx.conn):
                ctx.conn.execute("UPDATE photo SET kind = 'chart', state = 'reading', next_try_utc = ? WHERE id = ?",
                                 (to_iso(now), pid))
            return {"ok": True}
        if row["state"] not in ("read", "rejected", "needs_taps"):
            raise ApiError(400, "this picture is already kept")
        day = trading_day(datetime.fromisoformat((row["picture_utc"] or row["received_utc"]).replace("Z", "+00:00")))
        acct = row["account_id"]                      # a journal account's look joins its own trades only
        refs = [] if acct is not None else [f"mt5:{r[0]}" for r in ctx.conn.execute(
            "SELECT id FROM trade WHERE book = 'mt5' AND trading_day = ?", (day.isoformat(),))]
        refs += [f"photo:{r[0]}" for r in ctx.conn.execute(
            "SELECT id FROM photo_trade WHERE state IN ('confirmed','closed') AND linked_trade_id IS NULL"
            " AND trading_day = ? AND account_id IS ?", (day.isoformat(), acct))]
        with db.transaction(ctx.conn):
            if len(refs) == 1:
                ctx.conn.execute("INSERT OR IGNORE INTO photo_link (photo_id, trade_ref, role, at_utc)"
                                 " VALUES (?, ?, 'look', ?)", (pid, refs[0], to_iso(now)))
            ctx.conn.execute("UPDATE photo SET state = 'confirmed', confirmed_utc = ? WHERE id = ?",
                             (to_iso(now), pid))
        return {"ok": True, "linked": refs[0] if len(refs) == 1 else None}
    except photo_store.NotFound as exc:
        raise ApiError(404, str(exc)) from None


def photo_trade_get(ctx, groups, query, body):
    _photos_dir(ctx)
    try:
        return photo_trades.get(ctx.conn, ctx.cfg, int(groups["id"]))
    except photo_store.NotFound:
        raise ApiError(404, "not found") from None


def photo_trade_action(ctx, groups, query, body):
    """close: he confirms the close the prices show (an estimate: no R until a History picture or the bridge);
    bridge: his answer to "Which trade is this?" (mt5:<id> or none); first_stop: his first stop, set later."""
    _photos_dir(ctx)
    tid, now, action = int(groups["id"]), _now(ctx), groups["action"]
    try:
        if action == "bridge":
            b = _keys(body, {"trade"}, {"trade"})
            return {"ok": True, **photo_trades.answer_bridge(ctx.conn, ctx.cfg, tid, str(b["trade"]), now)}
        if action == "first_stop":
            b = _keys(body, {"price"}, {"price"})
            return {"ok": True, **photo_trades.set_first_stop(ctx.conn, ctx.cfg, tid, b["price"], now)}
        _keys(body, set())
        return {"ok": True, **photo_trades.close_from_prices(ctx.conn, ctx.cfg, tid, now)}
    except photo_store.NotFound as exc:
        raise ApiError(404, str(exc)) from None


# ---------------------------------------------------------------- journal accounts (docs/JOURNAL_DESIGN.md section 16)

def journal_accounts_list(ctx, groups, query, body):
    _photos_dir(ctx)
    return {"accounts": journal_accounts.listing(ctx.conn, ctx.cfg)}


def journal_accounts_create(ctx, groups, query, body):
    """His "New account" in Journal: a name and the starting fund he types."""
    _photos_dir(ctx)
    b = _keys(body, {"name", "start_fund", "server_clock"}, {"name", "start_fund"})
    a = journal_accounts.create(ctx.conn, b["name"], b["start_fund"], _now(ctx),
                                server_clock=b.get("server_clock", journal_accounts.DEFAULT_CLOCK))
    return {"ok": True, "account": journal_accounts.public(ctx.conn, ctx.cfg, a["id"])}


def journal_account_edit(ctx, groups, query, body):
    """A new name, starting fund or server clock; the old value is kept beside it (journal_account_edit)."""
    _photos_dir(ctx)
    b = _keys(body, {"name", "start_fund", "server_clock"})
    aid = int(groups["id"])
    journal_accounts.edit(ctx.conn, aid, _now(ctx), name=b.get("name"), start_fund=b.get("start_fund"),
                          server_clock=b.get("server_clock"))
    return {"ok": True, "account": journal_accounts.public(ctx.conn, ctx.cfg, aid)}


def photo_action(ctx, groups, query, body):
    folder = _photos_dir(ctx)
    pid, now = int(groups["id"]), _now(ctx)
    try:
        if groups["action"] == "delete":
            photo_store.delete(ctx.conn, folder, pid, now)
            return {"ok": True}
        b = body or {}
        if set(b) - {"trade_ref", "role"} or not isinstance(b.get("trade_ref"), str):
            raise ApiError(400, 'send {"trade_ref": "mt5:<id>", "role": "look"}')
        return {"ok": True, "photo": photo_store.link(ctx.conn, ctx.cfg, folder, pid, b["trade_ref"],
                                                      b.get("role", "look"), now)}
    except photo_store.NotFound as exc:
        raise ApiError(404, str(exc)) from None


ROUTES = [
    ("GET", re.compile(r"/api/today"), today),
    ("GET", re.compile(r"/api/live"), live),
    ("GET", re.compile(r"/api/journal"), journal),
    ("GET", re.compile(r"/api/journal/accounts"), journal_accounts_list),
    ("POST", re.compile(r"/api/journal/accounts"), journal_accounts_create),
    ("POST", re.compile(r"/api/journal/accounts/(?P<id>[0-9]{1,12})/edit"), journal_account_edit),
    ("POST", re.compile(r"/api/journal/trades/(?P<id>[0-9]{1,12})/choice"), choice),
    ("GET", re.compile(r"/api/journal/(?P<ref>" + picture_views.REF + r")/tags"), journal_tags),
    ("GET", re.compile(r"/api/journal/(?P<ref>" + picture_views.REF + r")/chart\.svg"), journal_chart),
    ("GET", re.compile(r"/api/calendar"), calendar_view),
    ("GET", re.compile(r"/api/edge"), edge),
    ("GET", re.compile(r"/api/rules"), rules),
    ("POST", re.compile(r"/api/rules/review"), rules_review),
    ("GET", re.compile(r"/api/settings"), settings),
    ("GET", re.compile(r"/api/paper"), paper_list),
    ("POST", re.compile(r"/api/paper"), paper_create),
    ("POST", re.compile(r"/api/paper/(?P<id>[0-9]{1,12})/(?P<action>fill|close|cancel|expire)"), paper_action),
    ("GET", re.compile(r"/api/checks"), checks_list),
    ("POST", re.compile(r"/api/checks"), checks_create),
    ("POST", re.compile(r"/api/checks/(?P<id>[0-9]{1,12})/(?P<action>edit|link)"), checks_action),
    ("POST", re.compile(r"/api/checks/links/(?P<id>[0-9]{1,12})/(?P<action>confirm|reject)"), checks_link_action),
    ("GET", re.compile(r"/api/leads"), leads_view),
    ("POST", re.compile(r"/api/suggestions/(?P<id>[0-9]{1,12})/decision"), suggestion_decision),
    ("GET", re.compile(r"/api/push/key"), push_key),
    ("POST", re.compile(r"/api/push/subscribe"), push_subscribe),
    ("POST", re.compile(r"/api/push/unsubscribe"), push_unsubscribe),
    ("POST", re.compile(r"/api/push/test"), push_test),
    ("GET", re.compile(r"/api/photos"), photos_list),
    ("GET", re.compile(r"/api/photos/(?P<id>[0-9]{1,12})"), photo_get),
    ("POST", re.compile(r"/api/photos/(?P<id>[0-9]{1,12})/(?P<action>link|delete)"), photo_action),
    ("POST", re.compile(r"/api/photos/(?P<id>[0-9]{1,12})/(?P<action>confirm|read|keep)"), photo_reading_action),
    ("GET", re.compile(r"/api/photos/trades/(?P<id>[0-9]{1,12})"), photo_trade_get),
    ("POST", re.compile(r"/api/photos/trades/(?P<id>[0-9]{1,12})/(?P<action>close|bridge|first_stop)"),
     photo_trade_action),
]
# Handlers the server calls without holding the journal lock (they send alerts, which can take seconds).
UNLOCKED = frozenset({push_test})
# Handlers that also get the request's User-Agent (a label for the saved phone).
WITH_USER_AGENT = frozenset({push_subscribe})


def match(method: str, path: str):
    """(handler, groups, None) or (None, None, allowed methods for that path)."""
    allowed = []
    for m, rx, fn in ROUTES:
        mo = rx.fullmatch(path)
        if mo:
            if m == method:
                return fn, mo.groupdict(), None
            allowed.append(m)
    return None, None, allowed


def call(fn, ctx, groups: dict, query: dict, body: dict | None, user_agent: str = "") -> tuple[int, dict]:
    try:
        res = fn(ctx, groups, query, body, user_agent) if fn in WITH_USER_AGENT else fn(ctx, groups, query, body)
    except ApiError as exc:
        return exc.status, {"ok": False, "error": exc.message}
    except _NOT_FOUND as exc:
        return 404, {"ok": False, "error": str(exc) or "not found"}
    except ValueError as exc:
        return 400, {"ok": False, "error": str(exc)}
    return res if isinstance(res, tuple) else (200, res)
