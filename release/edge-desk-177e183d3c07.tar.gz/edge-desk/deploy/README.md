# Server install

For the owner's server only: the old `zeroed` Vultr server, upgraded to 2 GB, Ubuntu 24.04 (CLAUDE.md "Server for
the app"). Install the app here, never on the meme bot's signer host. Builders never log in to the server: the owner,
or whoever he gives access, runs these steps, and the output of `python3 deploy/check.py report` is the evidence.

Before step 1: the meme bot's data on `zeroed` is copied off and checked with the meme repo's runbook, then the plan
is upgraded and Ubuntu 24.04 reinstalled (the owner's order, CLAUDE.md). Nothing below runs before that.

Every command here comes from the official page named beside it. Lines marked **not verified** were not run on a
real server by the builder.

## One-paste install (phone only, Vultr web console)

The steps below in one installer, for a phone with no computer (coordinator, 17 Oct 2026). The research repo never
goes on the server: the coordinator runs `python3 desk/deploy/make_release.py --out <dir>` in a research checkout and
puts the tarball and `install.sh` in the private export repo's `release/` folder. The server reads them with
`EDGE_EXPORT_TOKEN`, the fine-grained token Part B already uses (that repo only, Contents read and write).
Held since fix round 2: `make_release.py` builds nothing without `--oanda-figures-ok <ruling>` until the
coordinator rules on the figures from OANDA prices the release carries (section 12, "Release hold").

Before: in the Tailscale admin console (https://login.tailscale.com/admin/dns) turn on MagicDNS and HTTPS
Certificates, and make an auth key (https://login.tailscale.com/admin/settings/keys), not an ephemeral one. After the
install, turn off key expiry for `edge-desk` in the Machines list, or the app becomes unreachable when its node key
expires (180 days by default; worth checking in Tailscale's docs, which change).

1. Vultr, the server's page: copy the password, open **View Console**. Log in as `linuxuser` (paste the password with
   the console's Clipboard, Paste), then `sudo -i`.
2. Paste `read -rs T`, press Enter, paste the export token, press Enter (nothing shows).
3. Paste the install line `make_release.py` printed, press Enter. It downloads `install.sh` with the token, checks its
   sha256 (`sha256sum -c`) and runs it.
4. Answer the questions: the MT5 login, server and INVESTOR password, then the FundedNext account (1 = Stellar 2-Step,
   2 = Stellar 1-Step, 3 = not FundedNext), its stage (1 = Phase 1, 2 = Phase 2, 3 = FundedNext Account) and its size in USD
   (digits, for example 6000); the Tailscale auth key; the OANDA practice token (Enter skips: suggestions stay off); a
   dashboard password (paste 32+ characters, or Enter makes one, shown once); pictures in the journal (1 = on: his MT5
   screenshots and the trade pictures kept on this server, 180 days; 2 = off; Enter keeps the saved choice, off at
   first); with pictures on, the picture reading key from his Claude Console (hidden; Enter skips: pictures are read
   from the lines only; Enter keeps a saved one), written only to `/etc/edge-desk/reader.env` (root, 0600).

The rest runs as the transient unit `edge-desk-install` with "step k of 16" lines, so a dropped console stops nothing;
`edge-desk-install-status` shows it again. It ends with `deploy/check.py report` and one `missing:` line per open item.
Pasting the install line again is safe: what is done is kept, and Enter keeps every saved answer.

### Changing the MT5 account (owner, 30 Oct 2026: the paid FundedNext $6K account replaces the trial)

One paste of the install line: at "MT5 is set up. Enter keeps it, or type an account number to log in again" type the
new account number, then its server name (as MT5 or FundedNext's dashboard shows it, for example `FundedNext-Server 2`)
and its INVESTOR password, then the three FundedNext answers. Press Enter at every other question. What happens:

- **Its own alias.** `deploy/install/account.py` gives each MT5 account its own alias, `acct-` and 8 letters (a-p) of
  an HMAC-SHA256 of the account number with a key made once on this server (`/etc/edge-desk/account-key`, root, 0600;
  it never leaves the server, so the alias cannot be turned back into the number; letters only, so the daily export
  never takes it for a number). The same account typed again keeps its alias and its journal, whatever the server
  name; another account gets another alias. If an account's trades are already in the journal under another alias
  (the old "main" typed again), the app refuses its snapshots rather than count them twice, and the install says so. The
  alias goes into `/etc/edge-desk/account` (root, 0600, nothing secret) and from there into the config's `[account]
  alias` (rendered at every install) and the EA's preset (`mt5_setup.py --alias`), so both ends always agree. The app
  refuses another account under the same alias (`bridge/CONTRACT.md` "Account"), so without its own alias a new account
  would either be refused (another broker name or account type) or merged into the old one's journal.
- **The old account's rows stay** under their own alias ("main" on a server set up before this release). Its closed
  trades stay in the journal, the results and the day guard (they are his trades and his day). A trade it still showed
  open when its bridge went quiet (an expired trial with a position on) is no longer counted as open risk: nothing will
  ever close it. The journal marks such trades `account_linked: false`.
- **FundedNext's server list** (30 Oct 2026: on his server MT5 never tried `FundedNext-Server 2`, no Network line in
  its journal, because the generic MT5 knows no FundedNext server; FundedNext's help, article 10725745, has the user
  search "FundedNext" in File > Open an Account). For a server name containing "FundedNext" the setup installs
  FundedNext's own MT5 installer (MetaQuotes' CDN, `fundednext.ltd`, pinned as `FNSETUP_SHA256`; the owner's OK the
  same day) into the prefix, copies its `Config/servers.dat` over the generic one (kept as `servers.dat.metaquotes`),
  removes the FundedNext folder and writes `C:\edge\servers.done`. A typed FundedNext login loads it again when the
  installer could be fetched; a plain paste loads it only when it is not in (no marker, the file missing or under 1 KB,
  or MetaQuotes' list put back), never because MT5 updated it. In the lab its terminal64.exe was the same file as the
  generic build 6295 one (his terminal is 6281: not shown there). A set-up terminal without the list (Enter at the MT5
  question) gets it too, with edge-desk-mt5 stopped for the step and started again if the step fails. Lab: mt5lab FN_SERVERS_RESULTS.md (copy
  made the generic terminal try FundedNext-Server 2); whether a login then authorizes shows only on the server.
- **The EA follows the release** (30 Oct 2026, EA-17: his EA 1.12 matched each reply against the next seq, so Live read
  Stale between sends a minute apart). The EA was compiled only on a typed login; now a set-up terminal (Enter at the
  MT5 question) compiles it again when `C:\edge\ea.done` does not hold this release's `bridge/EdgeBridge.mq5` sha256 or
  the Experts folder has no EdgeBridge.ex5, with edge-desk-mt5 stopped for the step; a failed compile starts it again
  with the EA it had and fails the step. Lab: `evidence/account_switch/EA_SEQ_RESULTS.md`.
- **MT5 itself stays installed**: only the login start runs again (the investor login, kept by the terminal), the
  Options are already saved (no clicks), and `run.ini` names the new account. A fresh prefix runs the whole setup.
  From the new login until the setup is done, the terminal's unit is stopped and disabled and the old `run.ini` is
  gone, so a restart in between can never log the old account in under the new alias.
- **The snapshot wait counts only the new account's snapshots after the restart**; the server check's `bridge` line
  reads the config's alias only.
- **The FundedNext limits** (`[funded]`, Today's Funded panel and its alerts) are rendered from the three answers
  (product; stage: Phase 1, Phase 2 or FundedNext Account; size): Stellar 2-Step 5% a day and 10% maximum, Stellar
  1-Step 3% and 6%, of the size typed; the phase's profit target and minimum trading days; the 3% open-risk cap only
  in the FundedNext Account stage (sources and quotes in `deploy/install/render_config.py`). The installer says back
  what it will use ("Stellar 2-Step, Phase 1, 6000 USD: daily loss limit 300 USD, floor 5400 USD, target 6480 USD").
  Answer 3 turns them off and blanks them. They are asked at every paste: to change the stage, paste the install line,
  press Enter at the MT5 question and answer them again (Enter there keeps the saved answers). After an account number
  is typed, Enter keeps the saved answers if it is the same account; another account number starts with no loss limits
  (a passed phase on FundedNext comes with a new account number, so he answers them again then).

**Before connecting a FundedNext account, check its rules (read 30 Oct 2026, help.fundednext.com and fundednext.com):**
- **Which add-on he bought.** "EAs and VPS each require their own paid add-on to enable usage" (what-is-allowed), and
  "Using a VPS or Expert Advisor (EAs) without prior approval through official FundedNext add-ons" is forbidden. The
  bridge is an EA on his own VPS, so the order must show the "VPS & EA" add-on, not "EA" alone. Check the order first.
- **The VPS rule.** Article 8223809: "if the EA being used on the VPS does not execute trades (i.e., it is not a
  trade-taking EA) ... this constitutes a violation of FundedNext's VPS usage policy", and "VPS usage for manual
  trading is strictly prohibited". The EdgeBridge EA reads and never trades, on this server, while he trades by hand
  from his phone. That fits those words badly, so he asks FundedNext support **in writing**, before the paste, whether
  a read-only EA on a VPS, logged in with the investor password, is allowed on his account, and keeps the answer.
  Precedent to cite: article 8019804 allows adding an account to Myfxbook "using only your investor password" or "by
  using the Myfxbook EA", a reporting EA that places no trade.
- **What is at stake.** The same article: "the account may be terminated", and FundedNext Account issuance or the
  Performance Reward "may be suspended, adjusted, or declined"; a review after a passed phase can find it late.
- **If FundedNext says no,** the bridge stays off (Enter at the MT5 question keeps the old login; type no account),
  and the photo journal's History-picture close carries every trade (docs/JOURNAL_DESIGN.md D14).
- **Before the paste,** close or note any trade still open on the old account: once the app links the new account, the
  old one's later closes are never seen.

A fix reaches the server only through a new release. The install line pins the sha256 of `install.sh`, and
`install.sh` pins the release tarball, so an old install line installs the old code again, whatever was fixed since.
After a change is merged, the coordinator runs `make_release.py`, puts the new files in the export repo and gives the
owner the new install line, saying plainly that the old one will not pick up the fix.

What it does, in order (`deploy/install/stage2.sh`): refuses the meme bot's server (any `zeroed-*` unit,
`/var/lib/zeroed`, the `zeroed-signer` or `zeroed-worker` user) and servers under 1.5 GiB; Ubuntu packages; the
firewall (`deploy/nftables.conf`: inbound closed except Tailscale) and SSH off; unattended security updates; steps 1-9
below, with the ingest token and VAPID key made on the server; WineHQ devel 11.20 (held), Xvfb and MT5 with the EA
(`deploy/install/mt5_setup.py`, the bridge demo's method); Tailscale from its signed repository as `edge-desk`, then
`tailscale serve --bg --https=443 http://127.0.0.1:8787`. Downloads are pinned by sha256 in `deploy/install/pins.env`
(Python 3.13.16 was Sigstore-checked when pinned). The Part B units are installed, and run only with the OANDA token.
`edge-desk-headlines.service` (the Fed and ECB headline feeds, section 13) is installed and started always: it needs
no secret, and stops by itself when `[headlines] enabled = false`.

**Not verified on a real server:** all of it. Built and tested in a container with stub commands (no systemd);
running its system steps there was refused by the session's safety check. The MT5 setup alone ran on a real terminal
in a container (`evidence/part-b/installer/MT5_SETUP.md`, runs 1 to 5, with a dummy account that could not reach a
broker; run 4 ran the checks added after run 3, failed its first setup on the checkbox read-back and passed with the
pointer moved off each box before it is read; run 5 ran the code with the two small changes after run 4, ea2e076f, on
one CPU with Python 3.12 and passed a fresh setup, three service-style starts, the restart and a re-run). Known
open points: the WebRequest allow-list is set by clicks at fixed screen points (MT5 has no start-file key for it; the
setup reads `Config/common.ini` back and stops without `setup.done` when the list was not saved); a real investor login
and the terminal keeping it between starts; MetaQuotes' installer downloads the terminal itself, which cannot be pinned,
so run the container check on the release day to see which build the owner will get (MT5_SETUP.md, "Before the owner
gets a new install line"); the broker's EUR/USD symbol name (`EURUSD` assumed; a suffix needs a code change); whether
the server's own request to its `*.ts.net` name reaches `tailscale serve` (if not, the https line fails on the server
and the phone check decides). Settled 30 Oct 2026: `#` and `;` in an investor password do not break MT5's start file
(real MT5 build 6295 under Wine 11.20: MT5 reads `[Common]` with GetPrivateProfileStringW, which keeps `#`, `;` and `=`
as written but trims outer spaces and removes one pair of matching quotes); the setup writes `Password="<pw>"`, which
round-tripped every case tried, and refuses a non-ASCII password (`evidence/account_switch/MT5_PASSWORD_START_FILE.md`).
That run got MT5 build 6295 from MetaQuotes' installer: its Options click points were never measured (6266 and 6272
were), so a fresh install clicks it behind the same checks; a server that already has MT5 set up needs no clicks.
A real account switch with `mt5_setup.py` at 23a6c090 passed on build 6295 (made-up logins; no broker reachable, so
not the login itself or the first snapshot): a fresh prefix with account A (exit 0, the Options clicks passed behind
their checks), then account B on the same prefix (exit 0, A's run.ini removed before B's login start, no clicks, the
service-style start opened B under B's alias, both passwords kept exactly; `evidence/account_switch/MT5_SWITCH_RUN.md`).

## Paper card sizes for a second account (owner, 11 Nov 2026)

The paper cards size every trade as a % of each account (`[sizes]` in config/app.toml: T1-M 0.46%, G-FIX, PB-GBP and
ME-CHF 0.23% each). The MT5-linked account's balance comes from the install line's FundedNext answers. For an account
without the MT5 link, put one `label=balance` line in a root-only file on the server, then paste the install line
again (each install renders it into `[sizes] accounts`; the public release never holds a balance):

    echo '25K=25000' | sudo tee /etc/edge-desk/sizes && sudo chmod 600 /etc/edge-desk/sizes

Its cards then show its own lots and real %; its risk budget reads "unknown: no MT5 link", never OK.

## 1. Users and folders

```
sudo adduser --system --group --home /opt/edge-desk edge
sudo adduser --disabled-password --gecos "" mt5        # MT5 and Wine run as their own user
sudo mkdir -p /etc/edge-desk /opt/edge-desk/var
```

## 2. Python 3.13 from python.org (Ubuntu 24.04 ships 3.12; believed, not verified here)

The app's `requirements.txt` is hash-pinned for Python 3.13. Build it from the python.org source release and check
its Sigstore signature first (https://www.python.org/downloads/metadata/sigstore/; the 3.13 release manager's
identity is `thomas@python.org`, issuer `https://accounts.google.com`). Use the newest 3.13.x on
https://www.python.org/downloads/source/ as `V`.

```
sudo apt update && sudo apt install -y build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev \
  libsqlite3-dev libffi-dev liblzma-dev uuid-dev python3-venv python3-pip pipx
V=3.13.X          # the newest 3.13 source release
wget https://www.python.org/ftp/python/$V/Python-$V.tgz https://www.python.org/ftp/python/$V/Python-$V.tgz.sigstore
pipx run sigstore verify identity --bundle Python-$V.tgz.sigstore --cert-identity thomas@python.org \
  --cert-oidc-issuer https://accounts.google.com Python-$V.tgz
tar xzf Python-$V.tgz && cd Python-$V && ./configure --prefix=/usr/local && make -j1 && sudo make altinstall
python3.13 --version
```

**Not verified:** the apt package names and the build on a 1-vCPU, 2 GB server (expect tens of minutes).

## 3. The app and its hash-checked environment

```
sudo -u edge git clone <this repo, read-only> /opt/edge-desk/src      # or copy a checked-out tree
cd /opt/edge-desk && sudo -u edge ln -s src/desk/app app && sudo -u edge ln -s src/desk/config config \
  && sudo -u edge ln -s src/desk/deploy deploy
sudo -u edge python3.13 -m venv /opt/edge-desk/.venv
cd /opt/edge-desk/src/desk && sudo -u edge ../../.venv/bin/pip install --require-hashes -r requirements.txt
```

The app lives under `desk/` in the repo; the symlinks keep `python -m app` working from `/opt/edge-desk`. **Not
verified:** the layout on the server.

## 4. Secrets

```
sudo cp /opt/edge-desk/src/desk/deploy/edge-desk.env.example /etc/edge-desk/env
sudo chown root:edge /etc/edge-desk/env && sudo chmod 0640 /etc/edge-desk/env
sudo -u edge /opt/edge-desk/.venv/bin/python -m app vapid-keygen --out /tmp/vapid.key   # paste, then delete
sudo nano /etc/edge-desk/env
```

Values are typed on the server only. Never in the repo, a log or chat.

## 5. The app as a service

Systemd directives: https://www.freedesktop.org/software/systemd/man/latest/systemd.exec.html and
https://www.freedesktop.org/software/systemd/man/latest/systemd.service.html (index:
https://www.freedesktop.org/software/systemd/man/).

```
sudo cp /opt/edge-desk/src/desk/deploy/edge-desk.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now edge-desk
sudo -u edge /opt/edge-desk/.venv/bin/python -m app check
```

The app binds `127.0.0.1:8787` (config `app.host`), so it is not reachable from the internet; HTTPS comes from
Tailscale.

## 6. HTTPS for the phone through Tailscale

From https://tailscale.com/kb/1242/tailscale-serve (syntax `tailscale serve --https=<port> <target>`, `--bg` runs it
in the background; only `http://127.0.0.1` targets are proxied; the certificate is provisioned automatically). Install
Tailscale from https://tailscale.com/download/linux and log in as the owner (only he holds that login).

```
sudo tailscale serve --bg --https=443 http://127.0.0.1:8787
tailscale serve status
# off again:  sudo tailscale serve --https=443 http://127.0.0.1:8787 off
```

**Not verified:** whether HTTPS certificates must first be enabled in the tailnet's admin console (the page says the
certificate is provisioned automatically and does not list a console step). The phone joins the same tailnet and
opens `https://<server name>.<tailnet>.ts.net`, then adds it to the Home Screen (Web Push needs HTTPS).

## 7. MT5 under Wine, read-only

From https://www.metatrader5.com/en/terminal/help/start_advanced/install_linux (MetaQuotes' script `mt5linux.sh`
installs Wine and the terminal):

```
sudo -iu mt5
wget https://download.terminal.free/cdn/web/metaquotes.software.corp/mt5/mt5linux.sh ; chmod +x mt5linux.sh ; ./mt5linux.sh
```

From the bridge demo run (`desk/bridge/demo/EVIDENCE.md`, 16 Oct): Ubuntu's Wine 9.0 could not run MT5 build 6266 and
WineHQ stable 11.0 (`winehq-stable`, from dl.winehq.org) could; `WINEDLLOVERRIDES="mscoree=;mshtml="` skips the
wine-mono prompt; a headless server needs a virtual display (`Xvfb`). `desk/bridge/demo/run_demo.py` holds the commands
that run worked out.

**18 Oct 2026 (Melbourne): WineHQ devel 11.20, not stable 11.0.** On the owner's server, and again in a container with
the server's versions, `winehq-stable` 11.0 no longer installs MT5: MetaQuotes' protected `mt5setup.exe` (5.0.0.4816,
the pinned file) makes raw syscalls, stable 11.0 has no syscall user dispatch, and the installer stops on a false "A
debugger has been found running in your system" (WineHQ bug 58043, fixed after 11.0; the WineHQ noble repository
offers stable only as 10.0 and 11.0). `winehq-devel` 11.20 installed MT5 build 6272, compiled the EA with 0 errors and
0 warnings and ran it for 90 s with no such message. `deploy/install/stage2.sh` swaps stable for devel in one apt call
and holds devel; a Wine prefix with no finished MT5 install in it is rebuilt, and the MT5 step waits for the pinned
Wine. Details: `evidence/part-b/installer/WINE.md`.

**18 Oct 2026 (Melbourne): the setup's two starts** (`deploy/install/mt5_setup.py`; real-path run with build 6272,
`evidence/part-b/installer/MT5_SETUP.md`). MT5 6272 saves Tools > Options to `Config/common.ini` only in a terminal
started without `/config`, so the setup logs in with the start file, closes the terminal with `wine taskkill` (no
`/f`), starts it again with no start file for the clicks, closes it again, and writes `setup.done` only when
`common.ini` holds `[Experts]` with `WebRequest=1`, a listed URL, `Enabled=0` and DLL imports not on. The keys go to
the terminal's main window by its id, and no click runs until the Options window shows where the points were
measured; both checkbox points must read as checkboxes and each clicked box its new state, read with the pointer moved
off it (under the pointer Wine draws a box in hover colours, which stopped run 4's first setup), otherwise the window
closes without saving. Login and LiveUpdate windows get Escape first, until none has shown for a few seconds (a Login
window is expected there: `common.ini` keeps `Login=0`, so a start with no start file never logs in). The build is
printed (and shown in the progress lines as "MT5 build N at its setup"); one whose click points were not measured (only
6266 and 6272 were) goes through the same checks instead of being refused. Each failure closes the terminal and says
whether pasting the line again can help. Real runs 1 to 4 in a container (MT5_SETUP.md), the second and fourth on one
CPU with 1.5 GiB, passed with a dummy account (run 4 after the pointer fix); WebRequest to `http://127.0.0.1:8787` works
with algorithmic trading off (run 3). The service's `run.ini` (0600, owner `mt5`) names the account number and server,
no password: without them the terminal waited on a modal Login window and never tried to connect (seen with a dummy
account that never logged in; with them it tried at once; a real investor login was not tried). Every start file sets
`Enabled=0` (algorithmic trading off; a start file's value applies at each start). The unit restarts always (60 s
later) when it ends, also with exit 0 after the terminal closes itself.

**20 Oct 2026 (Melbourne): the start script, so an MT5 update can finish.** The unit's ExecStart is
`/usr/local/bin/edge-desk-mt5-run` (`deploy/edge-desk-mt5-run`; `stage2.sh` installs it with the unit files, owner
root, mode 0755, so the `mt5` user it runs as cannot change it). It starts the terminal exactly as the unit did before
(`/usr/bin/wine terminal64.exe /portable /config:C:\edge\run.ini`, in the unit's folder and environment). When wine
returns, it writes one line to the unit's journal and execs `/usr/bin/wineserver -w`, which returns only when no Wine
process of the prefix is left; that wait is then the unit's main process. Why: once MT5 has downloaded an update, the
next start hands over to its updater and wine exits 0 within about a second; the updater replaces the files and
starts the terminal again with the same arguments about 5 s later. With wine as the main process, systemd took that
exit as the end of the service, ran `wineserver -k` and killed the rest, so the updater died every time: on the
owner's server on 20 Oct the unit restarted 175 times until a run outside systemd let build 6274 install
(docs/HANDOFF.md). The wait has no time limit on purpose: after an update the relaunched terminal runs under it, and a
limit would end the unit and kill that terminal. The script never loops (systemd restarts the unit), `systemctl stop`
still runs `wineserver -k` first (the wait then returns at once), and a SIGTERM ends the script before or during the
wait. Proof: `tests/test_mt5_run.py` (fake Wine) and `evidence/part-b/installer/MT5_UPDATE.md` (real Wine 11.20 with a
stand-in terminal that hands over the same way; the container has no systemd, so the unit itself has not run yet).

What an MT5 update looks like now (the unit's part is expected, not yet seen on the server):

- `journalctl -u edge-desk-mt5`: one line, `edge-desk-mt5: terminal64.exe returned (wine exit 0): an update hand-off,
  a stop, a crash or File > Exit; waiting on Wine to finish (wineserver -w) before the unit ends`, and no stop or
  restart line after it. `systemctl status
  edge-desk-mt5` stays `active (running)`, its main process now `wineserver`, with the relaunched terminal in its
  process list.
- The terminal's own journal (`logs/YYYYMMDD.log` in the MetaTrader 5 folder, UTF-16: `iconv -f UTF-16 -t UTF-8`):
  `LiveUpdate start "C:\users\mt5\AppData\Roaming\MetaQuotes\Terminal\<id>\liveupdate\terminal64.exe" /update
  /path:"C:\Program Files\MetaTrader 5" /portable /config:"C:\edge\run.ini"`, then about 5 s later
  `MetaTrader 5 x64 build N started` with the new build.
- The same "returned" line appears whenever wine returns: on File > Exit (the unit then ends a few seconds later,
  Wine's own linger, 4 s in the proof run, and restarts 60 s after that), on every `systemctl stop` or `restart`
  (ExecStop's `wineserver -k` ends wine first, so the code is not 0) and after a crash. It alone does not mean an
  update happened: the terminal's own journal says so (`LiveUpdate start ...`).
- Before this script, an update showed as a restart every minute (restart counter 175 on the server on 20 Oct) with
  only libEGL warnings in the unit's journal.
- If an update ever left a Wine process hanging with no terminal, the unit would stay active without one; the check's
  `bridge` line shows it (no snapshot for 60 s), and `systemctl restart edge-desk-mt5` clears it. The same holds for a
  terminal crash: Wine's crash dialog (its debugger, set to start automatically in the prefix) waits on Xvfb for a
  click nobody gives, so the unit stays active with no terminal. This was so before the start script too; the
  bridge-silent alert reaches the phone, and `systemctl restart edge-desk-mt5` clears it.
- `deploy/check.py`'s memory sampler counts the script with MT5 while it runs the terminal and as Wine once it waits.

- Log in with the **investor (read-only) password** only. The app raises a hard incident if the terminal can trade.
- MT5 6272 also starts an MCP server at every start: 127.0.0.1:22346 for the terminal and 22345 for MetaEditor, with
  their API keys in plain text in `Config/assistant.ini` (Options > MCP "Enable internal server" is ticked by
  default; real run 1). The bridge does not need it, so the setup sets `Enable=0` in both `[MCP.*]` sections while the
  terminal is closed, and the read-back requires it off. In real run 2 the next start logged no "MCP started" line and
  nothing listened on either port. The AI Assistant (endpoint `api.inferdeck.net`) has no settings file and no on/off
  switch; it cannot trade with an investor login and starts only when opened. Its outbound traffic was not checked.
- A "Welcome to LiveUpdate" window (Restart / Later) can appear about a minute after a start (LiveUpdate offered build
  6230 on 18 Oct); the setup sends it Escape, never Return. In real run 2, Escape and then the setup's taskkill left the
  terminal on build 6272 (the update was not applied); whether Escape alone closes the window is not shown.
- Each start writes about 16 ALSA lines (no sound device) to the unit's journal; harmless.
- When no snapshot arrives within 3 minutes, the install reads the EA's log and says which cause it names. If it says
  the allow-list is wrong (MT5 keeps it encrypted, so a new paste cannot change it): `systemctl stop edge-desk-mt5 &&
  rm -rf /home/mt5/edge/wine /home/mt5/edge/setup.done`, then paste the install line again and type the account number.
- Disk: the MT5 home is about 2.5 GB after the setup (LiveUpdate adds about 230 MB of ML files the bridge never uses)
  and MT5's own logs and price history grow; count about 3 GB. No job prunes them yet.
- Tools > Options > Expert Advisors: algorithmic trading off; "Allow WebRequest for listed URL" with
  `http://127.0.0.1:8787` (the list is required by https://www.mql5.com/en/docs/network/webrequest).
- Put the ingest token in the terminal's `Common\Files\edge_bridge_token.txt` (bridge/CONTRACT.md "EA inputs"),
  attach `desk/bridge/EdgeBridge.mq5` to a EURUSD chart with `InpUrl = http://127.0.0.1:8787/api/bridge/v1/snapshot`.
- Plain http is allowed only to 127.0.0.1 (bridge/CONTRACT.md; coordinator ruling 7, 16 Oct).

**Not verified:** that WebRequest posts to a non-default port in the URL (`:8787`). The MQL5 page names only ports 80
and 443 ("Server port is automatically selected on the basis of the specified protocol") and says nothing about
127.0.0.1. The demo run added the URL to the allow-list but never connected to a broker, so no snapshot was sent. If
the port is refused, the check's `bridge` line fails and the coordinator is told; the app is not changed to work
around it.

## 8. Storage: prune, backups and the disk floor (A10)

The owner's condition (16 Oct): "As long server never gets populatred. Saved, refresh delete, backup." The hourly
timer runs `python -m app maintain`: the storage check, the prune of raw price samples and log rotation, and once a
New York day a gzipped online backup in `var/backup/` (7 daily and 4 weekly copies, config `[storage]`). Below 3 GB
free, or with the journal and backups over 5 GB, new raw samples stop, trades are still saved, nothing is deleted
and one phone alert is sent. These backups stay on this server; an off-server copy is your choice.

```
sudo cp /opt/edge-desk/src/desk/deploy/edge-desk-maintain.service /opt/edge-desk/src/desk/deploy/edge-desk-maintain.timer \
  /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now edge-desk-maintain.timer
sudo mkdir -p /etc/systemd/journald.conf.d
sudo cp /opt/edge-desk/src/desk/deploy/journald-edge-desk.conf /etc/systemd/journald.conf.d/edge-desk.conf
sudo systemctl restart systemd-journald
systemctl list-timers edge-desk-maintain.timer
```

Timer keys: https://www.freedesktop.org/software/systemd/man/latest/systemd.timer.html; journald keys:
https://www.freedesktop.org/software/systemd/man/latest/journald.conf.html. **Not verified** on the server.

## 9. Part B: the price feed and the two workers

Only after the owner's tokens are on the server (blueprint "Your questions" 4) and his OK on the export.

1. **The pinned lead code** (STATS 77ed1b42, forward tree 1ee7c81b; STATS ruling on app items 2 and 3): build it on
   any machine with a checkout of this repo and git, then copy the folder to the server. No credential for this
   repo goes to the server.
   ```
   python3 desk/deploy/make_lead_bundle.py --out /tmp/lead-bundle          # in the research checkout
   # copy /tmp/lead-bundle to the server as /opt/edge-desk/lead-bundle (root-owned, read-only for edge)
   sudo chown -R root:edge /opt/edge-desk/lead-bundle && sudo chmod -R a-w,g+rX /opt/edge-desk/lead-bundle
   ```
   The worker checks every file's sha256, the file list and STATS's forward tree sha256 at each start
   (`app/suggest/bundle.py`), and runs `fwd_core.compute_run` in its own `python -I -B` process.
2. **Tokens and switches:** `EDGE_OANDA_TOKEN` (the owner's OANDA practice token) and `EDGE_EXPORT_TOKEN` (a
   fine-grained GitHub token for the separate private export repo only, Contents read and write) in
   `/etc/edge-desk/env`; in `config/app.toml` set `[feed] enabled = true`, and `[export] enabled = true` with
   `repo = "<owner>/<export repo>"`. The research repo is refused there.
3. **The calendar pin:** the coordinator puts the checked `FORWARD_EVENTS.csv` and `.json` into the export repo's
   `calendar/` folder; the lead worker takes it once a day (its CSV's sha256 must equal the pin's).
4. **The units:**
   ```
   sudo cp /opt/edge-desk/src/desk/deploy/edge-desk-feed.service /opt/edge-desk/src/desk/deploy/edge-desk-method.service \
     /opt/edge-desk/src/desk/deploy/edge-desk-leads.service /etc/systemd/system/
   sudo systemctl daemon-reload && sudo systemctl enable --now edge-desk-feed edge-desk-method edge-desk-leads
   ```
   The feed backfills 120 days on its first start (about 35 requests, one every 2 s), then polls every 20 s. Each
   unit has a hard `MemoryMax`; the memory check below measures the real peak with every process running.
   Between two polls the feed also builds the past move record once (section 12, "Move record"), through the same
   client and limiter, so OANDA never sees more than one request every 2 s from this server.
   **The A+** (paper only, `app/aplus`, docs/APLUS_DESIGN.md; since 30 Oct 2026 the A22 pick `D4h 3m+5m`, buys and
   sells, desk/evidence/a22/NOTES.md) runs inside `edge-desk-method`: after each method step (every 30 s) it checks
   the newest 1-minute close of the feed's EUR/USD bars with the pinned rule code in its own
   `python -I -B app/aplus/child.py` process. No unit of its own; it needs the feed (and so the OANDA practice
   token). `deploy/check.py report` prints its `aplus` line. One step by hand, always as the app's user (run as root,
   it would leave root-owned files beside the journal; the command refuses that):
   ```
   cd /opt/edge-desk && sudo -u edge env "$(grep '^EDGE_DB_PATH=' /etc/edge-desk/env)" .venv/bin/python -m app aplus --once
   ```
   If the method unit's memory peak with the A+ child ever passes 450 MB (design D5), set `[aplus] run_in = "own"`
   and run the step in its own unit (the unit text is in docs/APLUS_DESIGN.md section 14); the `aplus` line of the
   check then follows that unit's heartbeat, the `units` line needs `edge-desk-aplus.service` active, and the A+
   failure alerts name that unit.
5. **The headlines unit** (section 13; it loads no env file and holds no secret, only the journal's path, so the
   installer starts it whatever Part B does):
   ```
   sudo cp /opt/edge-desk/src/desk/deploy/edge-desk-headlines.service /etc/systemd/system/
   sudo systemctl daemon-reload && sudo systemctl enable --now edge-desk-headlines
   ```

## 10. Memory over one London and New York day

```
sudo cp /opt/edge-desk/src/desk/deploy/memwatch.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl start memwatch
# after a full weekday from 07:00 London to 17:00 New York:
sudo systemctl stop memwatch
```

The sampler sums the resident memory of MT5, Wine, Xvfb and the app every 30 s, matched by process name and command
line. The ceiling is 1.6 GB of the 2 GB (blueprint "Server setup").

## 11. The check (the evidence)

```
cd /opt/edge-desk && sudo -u edge .venv/bin/python deploy/check.py report \
  --https-url https://<server name>.<tailnet>.ts.net
```

The host line looks for the meme bot's own markers (the installer's guard uses the same); `--forbid-host` and
`--forbid-machine-id` still add to them. (The same as `python3 deploy/check.py report` with the app's own Python.)
Paste the whole output into the PR or
HANDOFF. Expected: `PASS` on host, loopback, app, https, units, bridge, news, headlines and memory.
The phone check is the owner's: the installed app opens over HTTPS and "Send test alert" arrives.

## 12. News (MT5 calendar)

Today shows the EUR and USD high- and medium-impact releases of the next 48 hours (Melbourne 12-hour times, grouped
by trading day, with the actual, forecast and previous values and an impact pill), Calendar marks the days with news
(a news-only day opens its sheet), and Settings shows the `[news]` values.

- **Source:** the MT5 terminal's own economic calendar (MetaQuotes'). The EdgeBridge EA (1.13) reads it and posts it
  every 60 s (never more often: `InpCalendarSec` takes 0 or 60-3600) over loopback to `http://127.0.0.1:8787/api/bridge/v1/calendar` with the same ingest token as the
  snapshots (contract `edge-calendar/2`, `bridge/CONTRACT.md`; an EA 1.10 post, `edge-calendar/1`, is still read).
  The app makes no request of its own for numbers; the WebRequest allow-list entry `http://127.0.0.1:8787` already
  covers the path. Every actual, forecast and previous value on the screens and in the alerts comes from this
  calendar only (the move record's figures are measured on this server from OANDA prices, below).
- **The read:** once a release's actual is out, the row says how it came in against the forecast (above, below or
  in line) and which way it reads for the currency and then EUR/USD: MetaQuotes' own label when MT5 gives one
  ("MT5's read, untested"), else the textbook reading of the pinned sign table in `app/news/families.py` ("untested
  textbook read"). Neither is measured on past prices (the list's footnote says so), and no alert carries both a read and a
  size figure.
- **Move record:** beside a mapped release, one line of how far EUR/USD moved in the 15 and 60 minutes after the
  same release in 2016-2021, either way (size only, never a direction), against a quiet day at the same clock time.
  OANDA's terms do not clearly allow publishing figures made from its prices (coordinator ruling R7), so no release
  carries the move record: for it the release ships only the public event list (`app/news/move_events.json`: event
  types, dates and times, rebuilt by `research/news_reaction/make_move_events.py`) and the measurement code
  (`app/news/moverecord.py`, the research method of `research/news_reaction/reaction.py`, with the 16 public Eurex
  closure days as its skip days in place of the research's 24 days taken from OANDA's own bars, so its quiet-day
  figures can differ a little from the research table's). The feed process builds
  the record once on this server from the owner's OANDA practice prices (`[news] show_record = true` and the OANDA
  feed on): one request a window, release minute -1 to +61 of M1 bars, 4,603 windows for the 9 event types a
  release row can show, so about 3.2 hours (an estimate: one request every 2 s in the slots between the feed's own
  polls, about 8 job requests every 20 s at `[feed] poll_s = 20`). The feed and the job share one
  gate for the OANDA host: a Retry-After or back-off either of them gets holds both, and after any 3 failures in a
  row at the host both wait `[feed] cooldown_s` or the Retry-After if longer. The job also waits while the feed is
  halted. It resumes after a restart, pauses on a block or after 3 failures of its own in a row (5xx or network:
  the cool-down; anything else stops it until `python -m app feed --reset-record`), and keeps only four numbers a
  window in `var/news_record/` (mode 0600). A deleted or changed record is measured again. That folder is never in
  the journal, a backup, the export or a release (`make_release.py` refuses a `move_record.json` or
  `reaction_table.json` anywhere in it, and any JSON file holding a record's keys). Settings shows its progress.
  No US jobs, CPI, PPI or JOLTS record: their 2016-21 release dates were read from BLS pages after a refused
  request, which the data-source rule does not allow, so they stay out until a source that allows it gives them.
- **Release hold (figures from OANDA prices, fix round 2):** the release carries no move record, but it does carry
  figures computed earlier on OANDA practice prices, from before the news build: `app/checklist/tested.json` and
  `app/suggest/records.json` (the tested lines beside the checklist and on the suggestion cards: results in R and
  pips with trade counts, research rounds 49-59), `app/aplus/record.json` (the A+ tested record: the A22 pick's
  orders, trades, total and mean R on 2010-2012, from its parity replay on OANDA bid/ask), and the lead bundle
  (`lead-bundle/`, STATS's pinned research files that the lead worker runs), for example `lead-bundle/research/round53/FROZEN.json` (stop and target totals in R),
  `lead-bundle/research/departments/COST/COST_MODEL.json` (spreads per hour measured from OANDA practice bid/ask)
  and the round 47-55 declarations, which quote results. The same reading of OANDA's terms covers them, and the
  export repo that holds the release is public. Whether they may stay in the public release is the coordinator's
  ruling, with the owner told (open). Until then `make_release.py` builds nothing without
  `--oanda-figures-ok <ruling>` and leaves nothing to publish, and no release is made from this build. A release
  built with a ruling carries it in `OANDA_FIGURES_RULING.txt` next to `install.sh` (the ruling, the tarball's name
  and sha256, and how many such files it holds), listed in `SHA256SUMS`, so a published release shows which ruling
  allowed it. The app shows these tested lines because the owner asked to see each suggestion's tested record;
  nothing is dropped meanwhile.
- **Alerts:** `news_soon`, one per currency and release minute, `[news] alert_before_min` (15) before each
  high-impact EUR or USD release, listing the releases of that minute, the lead release's forecast and previous,
  and its hour move either way when the record has it (after its name when the minute has several releases, and
  "often shares its hour" when it does); the "in N min" title is set when the alert is sent, and one
  still queued at the release time is dropped. `news_result` (`[news] result_alerts`), one per currency and release
  minute once the first number is out (up to 15 minutes after the release): the number, forecast, previous and the
  read, never a size. The push service keeps a news alert for 10 (`news_soon`) or 15 minutes (`news_result`).
- **Check:** `deploy/check.py report` prints a `news` line: PASS with the last calendar's age and row count; FAIL when
  none has arrived (the bridge line must pass first: the EA sends only from a connected terminal), when the last one
  is older than `[news] stale_after_min` (30), when the server's clock change moved the stored release times (the
  coordinator then switches the conversion), or when the move record file was changed after it was built. Suffixes:
  how many seconds after its release the last high-impact number arrived (only rows the app held before their
  release), how many high-impact rows have no family in the table and their names (up to 5), and the move
  record's state (paused times in Melbourne).
- **Clock guard:** a calendar post whose measured server offset differs from the latest snapshot's is not stored
  (the reply says `"ignored"`), so a terminal that is not connected never moves the stored times.
- **Off:** set `[news] enabled = false` in `config/app.toml`, then `systemctl restart edge-desk`. The app answers the
  EA's calendar posts with 404 and the EA stops them until it restarts. `show_record = false` stops the move record
  job; `result_alerts = false` stops the result alerts.
- **Kept:** calendar rows only (no personal or account data), 14 days (`[news] keep_days`) and at most 5,000 rows,
  pruned by the hourly maintain job; nothing is stored below the disk floor; never in the daily export.
- **Not shown:** low-importance releases (the EA does not send them). Names come in the terminal's language.
- **Why not ForexFactory:** its terms forbid copying its calendar without the written consent of its owner (Fair
  Economy, Inc.), and storing the rows here would be a copy.

## 13. Headlines (Federal Reserve and ECB)

Today lists the last 72 hours of headlines from three official feeds, with Melbourne 12-hour times and a link to the
source; one phone alert goes when a Fed statement or ECB decision is out (at most 4 a day, only while it is fresh).

- **Sources (the only ones allowed):** the Federal Reserve Board's monetary policy press releases
  (`https://www.federalreserve.gov/feeds/press_monetary.xml`) and speeches and testimony
  (`https://www.federalreserve.gov/feeds/speeches_and_testimony.xml`), and the European Central Bank's press releases
  (`https://www.ecb.europa.eu/rss/press.html`). Credit: Federal Reserve Board; European Central Bank. No market news
  site is used: none of those checked allows it without written consent, or its terms could not be read
  (HEADLINES.md 3.4).
- **Limits:** at most one request every 10 s per host (the ECB's robots.txt asks for a 5 s crawl delay), every 5
  minutes (`poll_s`) and 15 minutes for speeches (`speeches_poll_s`), every 30 s around a Fed decision and 60 s
  around an ECB decision (the decision times come from the MT5 calendar rows). The Fed feeds are fetched with
  conditional GET; an unchanged ECB body saves nothing. A 403 or 429 blocks that host for 24 hours or its Retry-After
  if longer. One gate per host (the two Fed feeds share www.federalreserve.gov): a Retry-After or a back-off that one
  feed gets holds every feed of that host, and 3 failures in a row at a host, from any of its feeds, pause them all
  for 30 minutes or the Retry-After if longer; each feed also backs off on its own 5xx and network errors (an
  answer that is not HTTP or a body cut short counts as a network error). A 404, a redirect, a body over 1 MiB, a
  wrong content type, a DOCTYPE or ENTITY, or a body that is not plain UTF-8 RSS 2.0 (an unknown or multi-byte
  encoding in its XML declaration among them) stops it (Today names the stopped feed, and a paused one with the time it resumes), with one `headlines_halted`
  alert a day, until `python -m app headlines --reset-halt` (it clears the stop only, never a wait a server asked
  for).
- **Kept:** titles, times and links only (never an article), 14 days (`keep_days`) and at most 1,000 rows, in the
  journal's `news_headline` table; pruned by the hourly maintain job; nothing fetched below the disk floor; never in
  the daily export.
- **Check:** `deploy/check.py report` prints a `headlines` line: PASS when each feed fetched within
  `[headlines] stale_after_min` (30) and none is stopped (PASS when `[headlines]` is off); a late feed says until
  when it waits; it names the decision windows of the next 30 days (Melbourne 12-hour times). The `units` line
  includes `edge-desk-headlines` when `[headlines]` is on.
- **Off:** set `[headlines] enabled = false` (or `push = false` for no alerts), then
  `systemctl restart edge-desk edge-desk-headlines`.
- **Not verified from this server:** each feed was fetched once from the build container (19 Oct 2026 UTC,
  `tests/fixtures/headlines/SOURCES.md`); whether the feeds answer the server's own address shows on the `headlines`
  line of the check after install.

## 14. The picture reader (photo journal phases 2-4; off until evaluated)

docs/JOURNAL_DESIGN.md D5, §4, §11.3. Installed by stage 2's step "the picture reader" only with pictures on:
- `tesseract-ocr` from Ubuntu 24.04's archive at `TESSERACT_VERSION` (`install/pins.env`), checked with
  `tesseract --version` after the install (not held: Ubuntu's security updates may replace it, and the check then
  fails the step until the pin is moved).
- Its own virtualenv `/opt/edge-desk/.venv-reader`:
  `pip install --require-hashes --no-deps -r requirements-reader.txt` (the API client anthropic 1.15.0 and what it pulls
  in, Pillow 12.3.0, numpy 2.5.3; each pin at least 14 days on PyPI when chosen, its upload date beside it). `serve`
  and the other workers never load these.
- Two units, so the key never meets a picture decoder or the journal (fix rounds D-b and E):
  - `edge-desk-reader-local.service` (user `edge`, `python -m app reader --local`): decodes, reads the lines,
    sorts, crops, and writes the exact bytes to send into `/opt/edge-desk/reader/outbox`; it imports the sender's
    answers and ledger from `/opt/edge-desk/reader/results` into the journal and removes each job once imported. No
    key (it refuses to run with one in its environment), no network (`PrivateNetwork=yes`, `AF_UNIX` only),
    `/etc/edge-desk` hidden, MemoryMax=400M.
  - `edge-desk-reader.service` (its own user and group `edge-reader`, not in group `edge`;
    `python -m app reader --send`): the only unit that loads `/etc/edge-desk/reader.env`. It never imports Pillow and
    never opens the journal; `var` (the journal, its backups, the pictures) and the app's env file are hidden from it,
    and its user could not open them anyway (`var` is 0750 edge, the env file root:edge 0640). It reads the outbox and
    never deletes from it, calls `https://api.anthropic.com` with `max_retries=0`, and writes only the results folder:
    each answer, its key's state and its spend ledger (`spend-YYYY-MM.jsonl`: "reserved" with the call's ceiling,
    fsynced before each call; "actual" with its cost after). `serve` (user `edge`) cannot read its environment or
    `reader.env` (root 0600). The local pass reads everything in the results folder as untrusted input: no link is
    followed, a FIFO never blocks it, a file must be plain and under its limit (an answer 256 KB, a month's ledger
    4 MB, key.json 4 KB), every field is checked, and an "ok" answer is checked against mt5shot/2 again.
  - **Its network is unrestricted:** the send pass may connect to any address on the internet (outbound limits by IP
    were not set up: the API's addresses change). Everything else it can reach is closed as above.
  - Both: `LimitCORE=0`, `SystemCallFilter=@system-service`, `ProtectKernelTunables/Modules/Logs`,
    `RestrictNamespaces`, `LockPersonality`, `ProtectProc=invisible`, `NoNewPrivileges`, no capabilities.
  - `edge-desk-reader.timer` runs the local pass every 30 seconds, which pulls in the send pass after it (every time:
    with nothing to send it only records whether the key is set or working). No path unit: a picture that cannot be
    read never restarts a unit. The sender starts no call later than 11 minutes into its pass (two call timeouts
    and a minute before its `TimeoutStartSec=15min`).
  - The folders: `/opt/edge-desk/reader` (root, 0755), `outbox` (edge:edge-reader, 2750, files 0640: the local pass
    writes, the sender reads), `results` (edge-reader:edge, 2750, files 0640: the sender writes, the local pass
    reads). The journal keeps its modes (`var` 0750, `edge.db` the app user's only).
- `/etc/edge-desk/reader.env` (root, 0600): `EDGE_ANTHROPIC_KEY=...` from the installer's question, or empty. It is
  never in `/etc/edge-desk/env`, the backup, the export or a log. Settings shows "Picture reading key: Set / Not set /
  Not working" (a 401 or 403 stops paid reads until the key changes) and this month's spend ("This month $x of $10").
  He also sets a monthly spend limit in his Console (suggested $10); the app stops paid reads at `[photos]
  monthly_usd_cap` (default 10, ceiling 50): the sender's ledger counts each call at its actual cost, every attempt at
  its own price, or at its ceiling when no usage came back (an error, an answer that cannot be parsed, a kill).
- **What Anthropic keeps** (read 30 Oct 2026 from Anthropic's Privacy Center, "How long do you store my organization's
  data?", https://privacy.claude.com/en/articles/7996866-how-long-do-you-store-my-organization-s-data, page dated
  1 Jul 2026): "For Anthropic API users, we automatically delete inputs and outputs on our backend within 30 days of
  receipt or generation, except:" (a service with longer retention under your control, such as the Files API; a zero
  data retention agreement; "If we need to retain them for longer to enforce our Usage Policy (UP)"; "In compliance
  with the law"). Its "Usage Policy Violations" paragraph: "We retain inputs and outputs for up to 2 years and trust
  and safety classification scores for up to 7 years if your chat is flagged by our automated trust and safety systems
  as violating our Usage Policy. In all cases, we may retain your chats or sessions as required by law or as necessary
  to combat violations of our Usage Policy. If permitted in your contract with us, we may anonymize your
  organization's data for research or statistical purposes, in which case we may retain this information for longer."
  The same page: "Additionally, for Covered Models, we require limited data retention and review as a part of our
  safety work." These terms change: read the page again before switching the reader on.
- **Off until evaluated:** `[photos] reader = "off"` ships. "local" reads the lines only (he taps each one: entry,
  stop, target or not mine); "claude" adds the paid read of the cropped picture (only an MT5 chart with all three MT5
  signs; never a TradingView picture or another app's). Switching on needs the evaluation of §11.2-§11.3 first, then:
  `sudo sed -i 's/^reader = "off"/reader = "local"/' /opt/edge-desk/config/app.toml` (the timer already runs; not
  verified on the server).
- **The evaluation** (`deploy/reader_eval.py`, about 50 of his MT5 pictures and his labels): two steps, each as its
  unit's user with its unit's hardening, never by loading the key into a shell (not verified on the server). First, as
  root: `sudo install -d -m 2750 -o edge -g edge-reader /opt/edge-desk/reader/eval` and
  `sudo install -d -m 2750 -o edge-reader -g edge /opt/edge-desk/reader/eval/out` (the paid step's report; never in
  `results`, where only the sender's own files belong), then copy his pictures and `labels.json` into
  `/opt/edge-desk/reader/eval/pics` (owned by edge).
  1. the decoding step, no key and no network:
     `sudo systemd-run --pty --wait --collect -p User=edge -p Group=edge -p PrivateNetwork=yes
     -p RestrictAddressFamilies=AF_UNIX -p InaccessiblePaths=-/etc/edge-desk -p UMask=0027
     -p ProtectSystem=strict -p ProtectHome=yes -p PrivateTmp=yes -p PrivateDevices=yes -p NoNewPrivileges=yes
     -p LimitCORE=0 -p CapabilityBoundingSet= -p SystemCallFilter=@system-service -p SystemCallArchitectures=native
     -p ProtectKernelTunables=yes -p ProtectKernelModules=yes -p ProtectKernelLogs=yes -p ProtectControlGroups=yes
     -p RestrictNamespaces=yes -p LockPersonality=yes -p ProtectProc=invisible -p RestrictRealtime=yes
     -p RestrictSUIDSGID=yes -p ProtectClock=yes -p ProtectHostname=yes -p MemoryMax=400M
     -p ReadWritePaths=/opt/edge-desk/reader/eval -p WorkingDirectory=/opt/edge-desk
     /opt/edge-desk/.venv-reader/bin/python deploy/reader_eval.py --labels /opt/edge-desk/reader/eval/pics/labels.json
     --prepare /opt/edge-desk/reader/eval/prepared`
  2. the paid step, after his OK for about $25, with a running stop:
     `sudo systemd-run --pty --wait --collect -p User=edge-reader -p Group=edge-reader -p EnvironmentFile=/etc/edge-desk/reader.env
     -p RestrictAddressFamilies="AF_UNIX AF_INET AF_INET6" -p InaccessiblePaths=-/etc/edge-desk/env
     -p InaccessiblePaths=-/opt/edge-desk/var -p UMask=0027
     -p ProtectSystem=strict -p ProtectHome=yes -p PrivateTmp=yes -p PrivateDevices=yes -p NoNewPrivileges=yes
     -p LimitCORE=0 -p CapabilityBoundingSet= -p SystemCallFilter=@system-service -p SystemCallArchitectures=native
     -p ProtectKernelTunables=yes -p ProtectKernelModules=yes -p ProtectKernelLogs=yes -p ProtectControlGroups=yes
     -p RestrictNamespaces=yes -p LockPersonality=yes -p ProtectProc=invisible -p RestrictRealtime=yes
     -p RestrictSUIDSGID=yes -p ProtectClock=yes -p ProtectHostname=yes -p MemoryMax=200M
     -p ReadWritePaths=/opt/edge-desk/reader/eval/out -p WorkingDirectory=/opt/edge-desk
     /opt/edge-desk/.venv-reader/bin/python deploy/reader_eval.py --from /opt/edge-desk/reader/eval/prepared --live
     --paid-run-ok --max-usd 25 --out /opt/edge-desk/reader/eval/out/report.json`
- One local pass by hand, as the app's user (no key): `sudo -u edge env "$(grep '^EDGE_DB_PATH=' /etc/edge-desk/env)"
  /opt/edge-desk/.venv-reader/bin/python -m app reader --local`; the send pass only through its unit:
  `sudo systemctl start edge-desk-reader.service`.
