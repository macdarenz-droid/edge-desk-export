#!/usr/bin/env bash
# Edge Desk installer, stage 2: everything after the owner's answers. install.sh starts it as the transient unit
# edge-desk-install (systemd-run), so a dropped console never stops it; `edge-desk-install-status` (or
# `journalctl -u edge-desk-install`) shows the progress lines again. Safe to run again: every step checks what is
# already there. Every download is pinned by sha256 (pins.env); apt packages come from signed repositories.
# The steps follow deploy/README.md 1-9. Lines marked "not verified" in README.md were not run on a real server.
#
# Never prints a secret and never uses set -x: secrets reach programs only through files (mode 0600) or stdin.
set -euo pipefail
umask 022

REL="${EDGE_RELEASE_DIR:?}"            # /opt/edge-desk/releases/<id>/edge-desk (set by install.sh)
EXPORT_REPO="${EDGE_EXPORT_REPO:?}"
HERE="$REL/deploy/install"
. "$HERE/lib.sh"
. "$HERE/guard.sh"
# pins.env holds KEY=value lines only (tests check it); read them without running anything
while IFS='=' read -r k v; do
  [[ "$k" =~ ^[A-Z0-9_]+$ ]] && printf -v "$k" '%s' "$v"
done < <(grep -E '^[A-Z0-9_]+=' "$HERE/pins.env")

SECRETS=/etc/edge-desk/install         # root-only (0700): the answers install.sh saved for this run
CACHE=/var/cache/edge-desk-install
OPT=/opt/edge-desk
VENV="$OPT/.venv"
PY=/usr/local/bin/python3.13
MT5_HOME=/home/mt5/edge
ACCOUNT_FILE=/etc/edge-desk/account      # deploy/install/account.py: the alias and the FundedNext answers (root, 0600)
ACCOUNT_KEY=/etc/edge-desk/account-key   # made once on this server; never leaves it
CHOICES=/etc/edge-desk/choices           # his choices from install.sh (the photo journal on or off)
SIZES=/etc/edge-desk/sizes               # his accounts without the MT5 link, label=balance lines (render_config.py)
VENV_READER="$OPT/.venv-reader"          # the picture reader's own packages (requirements-reader.txt)
READER_ENV=/etc/edge-desk/reader.env     # the picture reading key (root, 0600): edge-desk-reader.service only
mkdir -p "$LOG_DIR" "$STATE" "$CACHE"
chmod 0700 "$LOG_DIR" "$STATE"
TOTAL=16

part_b_on() { env_has EDGE_OANDA_TOKEN; }

# account_alias: the alias of this server's MT5 account ("main" on a server set up before account.py existed)
account_alias() {
  python3 -I "$HERE/account.py" --account "$ACCOUNT_FILE" --alias
}

s_host() {
  edge_guard
  . /etc/os-release
  [ "${ID:-}" = ubuntu ] && [ "${VERSION_ID:-}" = 24.04 ] || { echo "needs Ubuntu 24.04 (found ${PRETTY_NAME:-?})"; exit 1; }
  [ "$(uname -m)" = x86_64 ] || { echo "needs an x86_64 server"; exit 1; }
}

s_packages() {
  apt_get update
  apt_get install --no-install-recommends build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev \
    libsqlite3-dev libffi-dev liblzma-dev uuid-dev libgdbm-dev ca-certificates curl gnupg jq nftables sqlite3 \
    unattended-upgrades xvfb xdotool imagemagick xz-utils
}

s_firewall() {
  # Vultr's image may come with ufw on; two firewalls at boot would give a ruleset nobody tested
  if command -v ufw >/dev/null; then
    ufw --force disable
    systemctl disable --now ufw
  fi
  install -m 0644 -o root -g root "$REL/deploy/nftables.conf" /etc/nftables.conf
  nft -c -f /etc/nftables.conf
  nft -f /etc/nftables.conf
  systemctl enable nftables
  # SSH off (the way in is Vultr's web console); the firewall also refuses port 22
  for u in ssh.socket ssh.service; do
    if systemctl list-unit-files "$u" --no-legend 2>/dev/null | grep . >/dev/null; then
      systemctl disable --now "$u"
    fi
  done
}

s_updates() {
  cat > /etc/apt/apt.conf.d/20auto-upgrades <<'EOF'
// Edge Desk: security updates every day, unattended, never an automatic reboot.
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
EOF
  cat > /etc/apt/apt.conf.d/52edge-desk-unattended-upgrades <<'EOF'
// Edge Desk: Ubuntu's security origins, plus Tailscale's own repository (it publishes fixes there). WineHQ is not
// listed: MT5 is tested with one Wine version, which apt-mark hold keeps.
Unattended-Upgrade::Allowed-Origins {
        "${distro_id}:${distro_codename}-security";
        "${distro_id}ESMApps:${distro_codename}-apps-security";
        "${distro_id}ESM:${distro_codename}-infra-security";
};
Unattended-Upgrade::Origins-Pattern {
        "origin=Tailscale,label=Tailscale,codename=${distro_codename}";
};
Unattended-Upgrade::Automatic-Reboot "false";
EOF
  systemctl enable --now unattended-upgrades
}

s_users() {
  getent passwd edge >/dev/null || adduser --system --group --home /opt/edge-desk edge
  getent passwd mt5 >/dev/null || adduser --disabled-password --gecos "" mt5
  install -d -m 0755 -o root -g root "$OPT" "$OPT/releases" /etc/edge-desk
  install -d -m 0750 -o edge -g edge "$OPT/var"
  install -d -m 0700 -o mt5 -g mt5 "$MT5_HOME"
  chown root:edge "$ENV_FILE"
  chmod 0640 "$ENV_FILE"
}

s_python() {
  if [ -x "$PY" ] && [ "$("$PY" -c 'import platform; print(platform.python_version())')" = "$PY_VERSION" ]; then
    echo "Python $PY_VERSION is already installed"
    "$PY" -c 'import ssl, sqlite3, lzma, bz2, zlib, ctypes; print("python modules ok")'
    return 0
  fi
  local tgz="$CACHE/Python-$PY_VERSION.tgz" b="$CACHE/build"
  fetch_pinned "https://www.python.org/ftp/python/$PY_VERSION/Python-$PY_VERSION.tgz" "$PY_SHA256" "$tgz"
  rm -rf "$b"
  mkdir -p "$b"
  tar -xzf "$tgz" -C "$b"
  cd "$b/Python-$PY_VERSION"
  ./configure --prefix=/usr/local --with-ensurepip=install
  make -j"$(nproc)"
  make altinstall
  cd /
  rm -rf "$b"
  "$PY" -c 'import ssl, sqlite3, lzma, bz2, zlib, ctypes; print("python modules ok")'
}

s_app() {
  local flag=off
  part_b_on && flag=on
  # a new MT5 login (install.sh "ask") gets its own alias; the FundedNext answers set the [funded] limits
  python3 -I "$HERE/account.py" --secrets "$SECRETS" --key "$ACCOUNT_KEY" --account "$ACCOUNT_FILE"
  python3 -I "$HERE/render_config.py" "$REL/config/app.toml" --part-b "$flag" --export-repo "$EXPORT_REPO" \
    --account-file "$ACCOUNT_FILE" --choices-file "$CHOICES" --sizes-file "$SIZES"
  local prev keep
  prev="$(readlink -f "$OPT/current" 2>/dev/null || true)"
  ln -sfn "$REL" "$OPT/current"
  # the disk budget: keep this release and the one before it, delete older ones
  for keep in "$OPT"/releases/*/; do
    keep="${keep%/}"
    case "$REL" in "$keep"/*) continue ;; esac
    case "$prev" in "$keep"/*) continue ;; esac
    rm -rf "$keep"
  done
  for x in app config deploy bridge lead-bundle requirements.txt requirements-reader.txt; do
    ln -sfn "current/$x" "$OPT/$x"
  done
  if ! env_has EDGE_DB_PATH; then VALUE="$OPT/var/edge.db" set_env EDGE_DB_PATH; fi
}

s_venv() {
  [ -x "$VENV/bin/python" ] || "$PY" -m venv "$VENV"
  "$VENV/bin/python" -m pip install --no-input --require-hashes --no-deps -r "$REL/requirements.txt"
  chown -R root:root "$VENV"
  chmod -R a+rX "$VENV"
}

s_secrets() {
  if ! env_has EDGE_VAPID_PRIVATE_KEY; then
    local d
    d="$(mktemp -d "$SECRETS/vapid.XXXXXX")"
    (cd "$OPT" && "$VENV/bin/python" -m app vapid-keygen --out "$d/key" >/dev/null)
    VALUE="$(cat "$d/key")" set_env EDGE_VAPID_PRIVATE_KEY
    shred -u "$d/key"
    rm -rf "$d"
  fi
  env_has EDGE_INGEST_TOKEN && env_has EDGE_DASHBOARD_TOKEN && env_has EDGE_EXPORT_TOKEN
}

s_bundle() {
  (cd "$OPT" && "$VENV/bin/python" -I -c 'import sys; sys.path.insert(0, "."); from pathlib import Path
from app.suggest import bundle; bundle.verify(Path("/opt/edge-desk/lead-bundle")); print("lead-bundle verified")')
}

s_services() {
  local u
  for u in edge-desk.service edge-desk-maintain.service edge-desk-maintain.timer memwatch.service \
           edge-desk-feed.service edge-desk-method.service edge-desk-leads.service \
           edge-desk-headlines.service edge-desk-xvfb.service edge-desk-mt5.service; do
    install -m 0644 -o root -g root "$REL/deploy/$u" "/etc/systemd/system/$u"
  done
  # the MT5 unit's ExecStart: root-owned, so the mt5 user it runs as cannot change it (deploy/edge-desk-mt5-run)
  install -m 0755 -o root -g root "$REL/deploy/edge-desk-mt5-run" /usr/local/bin/edge-desk-mt5-run
  install -d -m 0755 /etc/systemd/journald.conf.d
  install -m 0644 "$REL/deploy/journald-edge-desk.conf" /etc/systemd/journald.conf.d/edge-desk.conf
  systemctl restart systemd-journald
  install -m 0755 "$HERE/status.sh" /usr/local/sbin/edge-desk-install-status
  systemctl daemon-reload
  systemctl enable edge-desk.service
  systemctl restart edge-desk.service
  systemctl enable --now edge-desk-maintain.timer memwatch.service
  local i
  for i in $(seq 1 30); do
    if "$VENV/bin/python" -I -c 'import urllib.request as u; u.urlopen("http://127.0.0.1:8787/api/health", timeout=3)' 2>/dev/null; then
      echo "app answers on 127.0.0.1:8787"
      break
    fi
    [ "$i" = 30 ] && { journalctl -u edge-desk -n 30 --no-pager -o cat; exit 1; }
    sleep 2
  done
  # Fed and ECB headlines: no secret; the worker itself stops when [headlines] is off in config
  systemctl enable edge-desk-headlines.service
  systemctl restart edge-desk-headlines.service
  # Part B: installed always; running only with the owner's OANDA practice token (Enter skipped it otherwise)
  HAS_OANDA="$(part_b_on && echo 1 || true)"
  if [ -n "${HAS_OANDA}" ]; then
    systemctl enable edge-desk-feed edge-desk-method edge-desk-leads
    systemctl restart edge-desk-feed edge-desk-method edge-desk-leads
  else
    systemctl disable --now edge-desk-feed edge-desk-method edge-desk-leads
  fi
}

s_wine() {
  local key=/etc/apt/keyrings/winehq-archive.key
  install -d -m 0755 /etc/apt/keyrings
  fetch_pinned https://dl.winehq.org/wine-builds/winehq.key "$WINEHQ_KEY_SHA256" "$key"
  chmod 0644 "$key"
  cat > /etc/apt/sources.list.d/winehq-noble.sources <<'EOF'
Types: deb
URIs: https://dl.winehq.org/wine-builds/ubuntu
Suites: noble
Components: main
Architectures: amd64 i386
Signed-By: /etc/apt/keyrings/winehq-archive.key
EOF
  dpkg --print-foreign-architectures | grep -qx i386 || dpkg --add-architecture i386
  apt_get update
  # WineHQ devel, not stable: stable 11.0 has no syscall user dispatch, and MT5's protected installer then shows a
  # false "debugger" message and never installs (WineHQ bug 58043; evidence/part-b/installer/WINE.md).
  # A held package blocks any change to it, so first release the stable hold an earlier run left, and our own devel
  # hold (for a later pin change). After the update: apt-mark refuses its whole list when one name is unknown to apt.
  apt-mark unhold winehq-stable wine-stable wine-stable-amd64 wine-stable-i386:i386 >/dev/null 2>&1 || true
  apt-mark unhold winehq-devel wine-devel wine-devel-amd64 wine-devel-i386:i386 >/dev/null 2>&1 || true
  # winehq-devel conflicts with winehq-stable, so the swap is one apt call; on a server without stable, apt only says
  # "not installed, so not removed" (exit 0, checked with apt-get -s)
  apt_get install --install-recommends "winehq-devel=$WINEHQ_VERSION" "wine-devel=$WINEHQ_VERSION" \
    "wine-devel-amd64=$WINEHQ_VERSION" "wine-devel-i386:i386=$WINEHQ_VERSION" \
    winehq-stable- wine-stable- wine-stable-amd64- wine-stable-i386:i386-
  apt-mark hold winehq-devel wine-devel wine-devel-amd64 wine-devel-i386:i386
  # The check fits devel and staging pins only: 11.20~noble-1 prints "wine-11.20", but a stable-style pin such as
  # 11.0.0.0~noble-1 prints "wine-11.0". Moving the pin to an older version also needs a deliberate
  # --allow-downgrades on the install line (apt-get -s: "Packages were downgraded and -y was used without ...").
  local want="wine-${WINEHQ_VERSION%%~*}" got
  got="$(/usr/bin/wine --version)"
  [ "$got" = "$want" ] || { echo "/usr/bin/wine is '$got', not $want"; exit 1; }
  echo "$got"
  systemctl enable --now edge-desk-xvfb.service
}

s_mt5() {
  local FN_URL=https://download.mql5.com/cdn/web/fundednext.ltd/mt5/fundednext5setup.exe
  local fn="$MT5_HOME/fundednext5setup.exe"
  if [ -s "$SECRETS/mt5-login" ]; then
    # s_wine is a soft step: when it did not finish, the setup must not run on another Wine (stable 11.0 would wait
    # 15 minutes on its false debugger message); the saved login stays for the next paste
    local want="wine-${WINEHQ_VERSION%%~*}" got
    local t5="$MT5_HOME/wine/drive_c/Program Files/MetaTrader 5"
    got="$(/usr/bin/wine --version 2>/dev/null || true)"
    [ "$got" = "$want" ] || {
      echo "/usr/bin/wine is '$got', not $want: the Wine step did not finish, so MT5 is not set up yet"
      echo "paste the install line again (Enter keeps the saved MT5 login)"
      exit 1
    }
    install -d -m 0700 -o mt5 -g mt5 "$MT5_HOME"
    local url=https://download.mql5.com/cdn/web/metaquotes.software.corp/mt5/mt5setup.exe
    fetch_pinned "$url" "$MT5SETUP_SHA256" "$CACHE/mt5setup.exe"
    install -m 0644 -o mt5 -g mt5 "$CACHE/mt5setup.exe" "$MT5_HOME/mt5setup.exe"
    # a FundedNext server: its server list comes from FundedNext's own installer (the setup's FN_SERVER)
    if grep -qi '^MT5_SERVER=.*fundednext' "$SECRETS/mt5-login"; then
      # not fatal: with the list already in, a stale pin must not block an account change (the setup refuses when
      # the list is needed and the installer is missing)
      fetch_pinned "$FN_URL" "$FNSETUP_SHA256" "$CACHE/fundednext5setup.exe" \
        && install -m 0644 -o mt5 -g mt5 "$CACHE/fundednext5setup.exe" "$fn" || rm -f "$fn"
    fi
    # stopped AND disabled until this setup is done: a restart or a reboot in between must not start the terminal
    # with the old account's run.ini under the new alias (the setup removes run.ini first; enabled again below)
    systemctl disable --now edge-desk-mt5.service 2>/dev/null || true
    # a prefix with no finished MT5 install in it (such as the failed stable 11.0 run's: no terminal64.exe) is rebuilt
    # fresh; one with MT5 installed is kept, as run_demo.install_mt5 keeps it (a new login does not reinstall MT5)
    [ -f "$t5/terminal64.exe" ] && [ -d "$t5/MQL5/Experts" ] || rm -rf "$MT5_HOME/wine"
    systemctl start edge-desk-xvfb.service
    local rc=0
    { cat "$SECRETS/mt5-login"; grep '^EDGE_INGEST_TOKEN=' "$ENV_FILE"; } \
      | runuser -u mt5 -- env DISPLAY=:99 HOME=/home/mt5 USER=mt5 python3 -I "$HERE/mt5_setup.py" --base "$MT5_HOME" \
        --alias "$(account_alias)" --fundednext-installer "$fn" || rc=$?
    # the start file holds the investor password: gone however the setup ended (removed as mt5, in mt5's own folder)
    runuser -u mt5 -- rm -f "$MT5_HOME/wine/drive_c/edge/start.ini"
    [ "$rc" = 0 ] || exit "$rc"
    shred -u "$SECRETS/mt5-login"
  fi
  [ -f "$MT5_HOME/setup.done" ] || { echo "MT5 is not set up yet: paste the install line again; it asks for the MT5 login again (Enter keeps the saved one)"; exit 1; }
  # read before any stop below: a failure here must leave the terminal as it is
  local i n=0 alias since
  alias="$(account_alias)"
  [[ "$alias" =~ ^[A-Za-z0-9_-]{1,32}$ ]] || { echo "the account alias is not a short label"; exit 1; }
  # a set-up terminal on a FundedNext server whose list was never loaded (his server after 44bef44e: no Network line in
  # its journal): loaded now, with the terminal stopped; then the restart below connects
  local need=0
  runuser -u mt5 -- env HOME=/home/mt5 USER=mt5 python3 -I "$HERE/mt5_setup.py" --base "$MT5_HOME" \
    --fundednext-installer "$fn" --servers-needed </dev/null || need=$?
  case "$need" in
    0)
      fetch_pinned "$FN_URL" "$FNSETUP_SHA256" "$CACHE/fundednext5setup.exe" || exit 1
      install -m 0644 -o mt5 -g mt5 "$CACHE/fundednext5setup.exe" "$fn"
      systemctl start edge-desk-xvfb.service      # before the stop: a failure here leaves the terminal running
      systemctl disable --now edge-desk-mt5.service 2>/dev/null || true
      runuser -u mt5 -- env DISPLAY=:99 HOME=/home/mt5 USER=mt5 python3 -I "$HERE/mt5_setup.py" --base "$MT5_HOME" \
        --fundednext-installer "$fn" --servers-only </dev/null || {
        echo "FundedNext's server list did not load; MT5 is started again as it was"
        systemctl enable edge-desk-mt5.service
        systemctl restart edge-desk-mt5.service
        exit 1
      } ;;
    3) ;;
    *)
      echo "the check for FundedNext's server list failed (exit $need); MT5 is started with what it had"
      systemctl enable edge-desk-mt5.service
      systemctl restart edge-desk-mt5.service
      exit 1 ;;
  esac
  # a set-up terminal whose EA was not compiled from this release (his server after b7d4bf4a: EA 1.12 matched each
  # reply against the next seq, so every stored snapshot counted as failed): compiled now, with the terminal stopped
  need=0
  runuser -u mt5 -- env HOME=/home/mt5 USER=mt5 python3 -I "$HERE/mt5_setup.py" --base "$MT5_HOME" \
    --ea-needed </dev/null || need=$?
  case "$need" in
    0)
      systemctl start edge-desk-xvfb.service      # before the stop, as above
      systemctl disable --now edge-desk-mt5.service 2>/dev/null || true
      runuser -u mt5 -- env DISPLAY=:99 HOME=/home/mt5 USER=mt5 python3 -I "$HERE/mt5_setup.py" --base "$MT5_HOME" \
        --ea-only </dev/null || {
        echo "the EA did not compile; MT5 is started again with the EA it had (if it had one)"
        systemctl enable edge-desk-mt5.service
        systemctl restart edge-desk-mt5.service
        exit 1
      } ;;
    3) ;;
    *)
      echo "the check for the EA failed (exit $need); MT5 is started with what it had"
      systemctl enable edge-desk-mt5.service
      systemctl restart edge-desk-mt5.service
      exit 1 ;;
  esac
  # only a snapshot of this account, stored after this restart, counts: a server that held another account (the old
  # trial) already has rows under that account's alias
  since="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  systemctl enable edge-desk-mt5.service
  systemctl restart edge-desk-mt5.service
  # past init: the EA says init until the app's reply to it matched, so a snapshot past init proves the EA reads the
  # replies (EA-17: EA 1.12 never matched one, so every snapshot said init and arrived once a minute)
  local q="SELECT count(*) FROM bridge_status WHERE account_alias = '$alias' AND last_seen_utc >= '$since'"
  for i in $(seq 1 42); do
    n="$(sqlite3 "file:$OPT/var/edge.db?mode=ro" "$q AND last_reason <> 'init'" 2>/dev/null || echo 0)"
    [ "${n:-0}" -gt 0 ] && { echo "the EA's snapshots arrive"; return 0; }
    sleep 5
    # 3 minutes; 30 s more only when a snapshot came (a late first one's next follows about 5 s after it)
    if [ "$i" -ge 36 ]; then
      n="$(sqlite3 "file:$OPT/var/edge.db?mode=ro" "$q" 2>/dev/null || echo 0)"
      [ "${n:-0}" -gt 0 ] || break
    fi
  done
  # init with a rising seq: every reply counted as failed (deploy/check.py bridge_ok: the same rule)
  n="$(sqlite3 "file:$OPT/var/edge.db?mode=ro" "$q AND last_seq > 0" 2>/dev/null || echo 0)"
  if [ "${n:-0}" -gt 0 ]; then
    echo "snapshots from the EA arrive, but each still says reason init: the EA counts every reply as failed (an EA"
    echo "older than this release still runs): paste the install line again; if it stops here again, send this line"
    exit 1
  fi
  n="$(sqlite3 "file:$OPT/var/edge.db?mode=ro" "$q" 2>/dev/null || echo 0)"
  if [ "${n:-0}" -gt 0 ]; then
    echo "the EA's first snapshot arrived, then no other: the terminal may have lost the broker, or the app refused"
    echo "the next one"
    mt5_why
    exit 1
  fi
  echo "no snapshot from the EA within 3 minutes: the terminal may not reach the broker, may wait on its Login window"
  echo "(it did not keep the investor login), or WebRequest was refused. If the MT5 login or server was wrong: paste the"
  echo "install line again and type the account number again (Enter would keep the old one)"
  mt5_why
  exit 1
}

# mt5_why: what the EA's own log says since its last stop (its fixed messages in bridge/EdgeBridge.mq5). The log is
# UTF-16 (MQL5/logs, lower case in the real runs) and is read as mt5; only fixed advice is printed, never a log line.
# MT5 writes this log to disk only about 60-70 s after a start (real run 4: lines stamped 22:35:45 were in the file at
# 22:36:43), so it is read only after the 3-minute snapshot wait above, never sooner; on a stopped terminal it shows
# no start of the EA, since only lines after its last stop count.
mt5_why() {
  local t5="$MT5_HOME/wine/drive_c/Program Files/MetaTrader 5" f log="" ea last
  for f in "$t5"/MQL5/[Ll]ogs/*.log; do if [ -f "$f" ]; then log="$f"; fi; done   # names sort by date
  ea="$( { [ -z "$log" ] || runuser -u mt5 -- cat "$log"; } 2>/dev/null | iconv -f UTF-16 -t UTF-8 2>/dev/null \
        | awk '/EdgeBridge stopped \(reason /{s=""; next} {s=s $0 "\n"} END{printf "%s", s}' || true)"
  if grep -qF 'is not known yet; set InpSymbol' <<<"$ea"; then
    echo "the EA's log: the symbol EURUSD was not known when the EA started. If this broker names EUR/USD otherwise"
    echo "(some add a suffix, such as EURUSD.r), the setup needs that name; a new paste does not change it"
  fi
  if ! grep -qE 'EdgeBridge edge-bridge/[^ ]+ started: ' <<<"$ea"; then
    if grep -qE 'EdgeBridge: (cannot open the token file|the token in )' <<<"$ea"; then
      echo "the EA's log: it could not read its token. Paste the install line again and type the account number"
      echo "again (the setup writes the token file again)"
    else
      echo "the EA's log shows no start of the EA: systemctl restart edge-desk-mt5, then check again"
    fi
    return 0
  fi
  last="$(grep -oF -e 'WebRequest is not allowed for this URL' -e 'the app refused the token (401)' \
          -e 'the terminal is not connected to the broker' -e 'connected again; sending.' \
          -e 'account.alias: unknown account alias' -e 'not the account this alias sent before' \
          -e 'already in the journal under another alias' <<<"$ea" \
          | tail -n 1 || true)"
  case "$last" in
    "WebRequest is not allowed for this URL")
      echo "the EA's log: WebRequest is not allowed for http://127.0.0.1:8787, so the saved allow-list is wrong (MT5"
      echo "keeps it encrypted; a new paste does not change it). To set MT5 up from the start, run this line, then"
      echo "paste the install line again and type the account number again:"
      echo "  systemctl stop edge-desk-mt5 && rm -rf $MT5_HOME/wine $MT5_HOME/setup.done" ;;
    "the app refused the token (401)")
      echo "the EA's log: the app refused its token. Paste the install line again and type the account number again"
      echo "(the setup writes the token file again)" ;;
    "the terminal is not connected to the broker")
      echo "the EA's log: the terminal is not connected to the broker (a wrong account number, server or investor"
      echo "password, or the broker cannot be reached)" ;;
    "account.alias: unknown account alias")
      echo "the EA's log: the EA's account alias is not the app's. Paste the install line again and type the account"
      echo "number again (the setup gives the EA the app's alias again)" ;;
    "already in the journal under another alias")
      echo "the EA's log: the app refused this account: its trades are already in the journal under another name"
      echo "(the same account typed again). Nothing was counted twice. Type the new account's number, or ask in"
      echo "your Claude chat to join the two names" ;;
    "not the account this alias sent before")
      echo "the EA's log: the app refused this account: its broker name or account type is not what this alias sent"
      echo "before, so it is kept apart. Paste the install line again and type the account number again; if this"
      echo "line comes back, say so in your Claude chat" ;;
  esac
}

# mt5_build_line: the MT5 build the setup checked (setup.done holds "ok build N"), shown with the progress lines:
# MetaQuotes' web installer gives whatever build is current, so the build is worth seeing.
mt5_build_line() {
  local b
  b="$(sed -n 's/^ok build \([0-9][0-9]*\)$/\1/p' "$MT5_HOME/setup.done" 2>/dev/null || true)"
  [ -z "$b" ] || say "  MT5 build $b at its setup"
}

s_tailscale() {
  local kr=/usr/share/keyrings/tailscale-archive-keyring.gpg st name
  if ! command -v tailscale >/dev/null; then
    echo "$TS_KEYRING_SHA256  $HERE/tailscale-archive-keyring.gpg" | sha256sum -c --quiet -
    [ "$(gpg --show-keys --with-colons "$HERE/tailscale-archive-keyring.gpg" | awk -F: '$1 == "fpr" { print $10; exit }')" = "$TS_FPR" ]
    install -m 0644 "$HERE/tailscale-archive-keyring.gpg" "$kr"
    printf 'deb [signed-by=%s] https://pkgs.tailscale.com/stable/ubuntu noble main\n' "$kr" \
      > /etc/apt/sources.list.d/tailscale.list
    apt_get update
    apt_get install --no-install-recommends tailscale
  fi
  systemctl enable --now tailscaled
  st="$(timeout 30 tailscale status --json 2>/dev/null | jq -r '.BackendState // "NoState"' || echo NoState)"
  if [ "$st" != Running ]; then
    [ -s "$SECRETS/tailscale-authkey" ] || { echo "no Tailscale auth key: paste the install line again and give one"; exit 1; }
    # the key is read from its root-only file, never from argv (tailscale up: --auth-key=file:<path>).
    # accept-dns: the server resolves its own *.ts.net name for the check's https line (on Ubuntu, systemd-resolved
    # sends only the tailnet's names to Tailscale; not verified on the server). No Tailscale SSH, no routes.
    timeout 150 tailscale up --auth-key="file:$SECRETS/tailscale-authkey" --hostname=edge-desk --ssh=false \
      --accept-routes=false --accept-dns=true --timeout=120s
    shred -u "$SECRETS/tailscale-authkey"
  fi
  st="$(timeout 30 tailscale status --json)"
  jq -e '.CurrentTailnet.MagicDNSEnabled == true' <<<"$st" >/dev/null \
    || { echo "turn on MagicDNS at https://login.tailscale.com/admin/dns, then paste the install line again"; exit 1; }
  jq -e '((.Self.CapMap // {}) | has("https")) and ((.CertDomains // []) | length > 0)' <<<"$st" >/dev/null \
    || { echo "turn on HTTPS Certificates at https://login.tailscale.com/admin/dns, then paste the install line again"; exit 1; }
  timeout 60 tailscale serve --bg --https=443 http://127.0.0.1:8787
  # exactly the loopback app on 443, Funnel off (AllowFunnel empty); anything else is taken down
  if ! timeout 30 tailscale serve status --json | jq -e '
      ((.AllowFunnel // {}) | length == 0)
      and ([.Web[]?.Handlers[]?.Proxy] | length > 0 and all(. == "http://127.0.0.1:8787"))' >/dev/null; then
    timeout 30 tailscale serve reset || true
    echo "tailscale serve did not publish only the app with Funnel off; it was taken down"
    exit 1
  fi
  name="$(jq -r '.Self.DNSName // empty' <<<"$st" | sed 's/\.$//')"
  [[ "$name" =~ ^[A-Za-z0-9.-]+$ ]]
  printf '%s\n' "$name" > "$STATE/ts_name"
  VALUE="https://$name" set_env EDGE_VAPID_SUBJECT
  systemctl restart edge-desk.service
  echo "the app: https://$name"
}

s_check() {
  local url="" ts=no oanda=no
  [ -s "$STATE/ts_name" ] && { url="https://$(cat "$STATE/ts_name")"; ts=yes; }
  part_b_on && oanda=yes
  sleep 5
  (cd "$OPT" && runuser -u edge -- "$VENV/bin/python" -I deploy/check.py report --https-url "$url" --todo \
     --oanda "$oanda" --tailscale "$ts") > "$STATE/report.txt" 2>&1 || true
}

# s_reader: the picture reader (docs/JOURNAL_DESIGN.md D5, §4; fix rounds D-b and E), only with pictures on (his
# choice): tesseract-ocr from Ubuntu's archive at the pinned version, checked like Wine; its own virtualenv from
# requirements-reader.txt (hash-checked); the sender's own user and group edge-reader, not in group edge (it cannot
# read the app's env file, the journal or its backups; its environment is unreadable to `serve`, user edge);
# /etc/edge-desk/reader.env (root, 0600; install.sh writes the key there, or it stays empty: pictures are then read
# from the lines only); the reader folders /opt/edge-desk/reader/outbox (edge:edge-reader, 2750: the local pass writes,
# the sender reads) and /opt/edge-desk/reader/results (edge-reader:edge, 2750: the sender writes, the local pass reads);
# its two units and the 30-second timer. The journal keeps its modes (var 0750, edge.db the app user's only). The timer
# runs whatever [photos] reader says: the local pass also links picture trades to the bridge (D-c). A path unit of an
# earlier release is removed (a picture waiting in the inbox started it over and over).
s_reader() {
  local u want got
  if ! grep -qx 'PHOTOS=on' "$CHOICES" 2>/dev/null; then
    systemctl disable --now edge-desk-reader.timer edge-desk-reader-local.service edge-desk-reader.service \
      edge-desk-reader.path 2>/dev/null || true
    echo "pictures are off: the reader stays off"
    return 0
  fi
  apt_get install --no-install-recommends "tesseract-ocr=$TESSERACT_VERSION"
  want="tesseract ${TESSERACT_VERSION%%-*}"
  got="$(tesseract --version 2>&1 | head -n 1 || true)"
  [ "$got" = "$want" ] || { echo "tesseract is '$got', not $want"; exit 1; }
  [ -x "$VENV_READER/bin/python" ] || "$PY" -m venv "$VENV_READER"
  "$VENV_READER/bin/python" -m pip install --no-input --require-hashes --no-deps -r "$REL/requirements-reader.txt"
  chown -R root:root "$VENV_READER"
  chmod -R a+rX "$VENV_READER"
  getent passwd edge-reader >/dev/null || adduser --system --no-create-home --home /nonexistent --group edge-reader
  gpasswd -d edge-reader edge >/dev/null 2>&1 || true
  [ -f "$READER_ENV" ] || install -m 0600 -o root -g root /dev/null "$READER_ENV"
  chown root:root "$READER_ENV"
  chmod 0600 "$READER_ENV"
  install -d -m 0700 -o edge -g edge "$OPT/var/photos" "$OPT/var/photos/inbox"
  install -d -m 0755 -o root -g root "$OPT/reader"
  install -d -m 2750 -o edge -g edge-reader "$OPT/reader/outbox"
  install -d -m 2750 -o edge-reader -g edge "$OPT/reader/results"
  systemctl disable --now edge-desk-reader.path 2>/dev/null || true
  rm -f /etc/systemd/system/edge-desk-reader.path
  for u in edge-desk-reader-local.service edge-desk-reader.service edge-desk-reader.timer; do
    install -m 0644 -o root -g root "$REL/deploy/$u" "/etc/systemd/system/$u"
  done
  systemctl daemon-reload
  systemctl enable --now edge-desk-reader.timer
}

# The tests (and a dry run) load the functions without running the steps.
[ -z "${EDGE_STAGE2_SOURCE_ONLY:-}" ] || return 0

printf 'running\n' > "$STATE/result"
say "Edge Desk install: release $(basename "$(dirname "$REL")"), $(date -u '+%Y-%m-%d %H:%M') UTC"
step "checking this server" s_host
step "Ubuntu packages" s_packages
step "firewall: inbound closed except Tailscale, SSH off" s_firewall
step "unattended security updates" s_updates
step "users and folders" s_users
step "Python $PY_VERSION (pinned, built here: about 20-40 minutes)" s_python
step "the app's files" s_app
step "the app's Python packages (hash-checked)" s_venv
step "keys made on this server (VAPID)" s_secrets
step "the pinned lead code" s_bundle
step "systemd units, the storage timer and journald" s_services
soft_step "the picture reader (tesseract and its own Python packages)" s_reader
soft_step "Wine $WINEHQ_VERSION and the virtual display (Xvfb)" s_wine
soft_step "MT5 and the read-only EA" s_mt5
mt5_build_line
soft_step "Tailscale and HTTPS" s_tailscale
soft_step "the server check" s_check

say ""
say "Server check:"
sed 's/^/  /' "$STATE/report.txt" 2>/dev/null || say "  (no report)"
for t in "${SOFT_FAILED[@]}"; do say "missing: $t did not finish (log in $LOG_DIR)"; done
printf 'done\n' > "$STATE/result"
say "Install finished."
