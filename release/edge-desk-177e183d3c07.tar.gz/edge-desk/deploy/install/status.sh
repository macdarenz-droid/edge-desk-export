#!/usr/bin/env bash
# edge-desk-install-status: where the Edge Desk install stands (installed by stage2.sh). Root only. Prints the
# install unit's progress lines and the last server check; never a secret (none is ever written to that journal).
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "run as root (sudo -i first)"; exit 1; }
STATE=/var/lib/edge-desk-install
printf 'install: %s (%s)\n' "$(cat "$STATE/result" 2>/dev/null || echo 'not started')" \
  "$(systemctl is-active edge-desk-install 2>/dev/null || true)"
journalctl -u edge-desk-install -o cat --no-pager -n 200 2>/dev/null | grep -E '^(step|  |missing|Install|Server)' || true
DB=/opt/edge-desk/var/edge.db
# --reset-feed: clear a price-feed halt (the same keys as python -m app feed --reset-halt) as the app user, so no
# root-owned journal file appears, then restart the feed. No price, trade or journal row is touched.
if [ "${1:-}" = --reset-feed ]; then
  systemctl stop edge-desk-feed
  runuser -u edge -- sqlite3 "$DB" "DELETE FROM feed_state WHERE key IN ('halted','stopped_until','failures');"
  systemctl start edge-desk-feed
  echo "feed: halt cleared and edge-desk-feed restarted (an OANDA block, if any, still runs to its end)"
fi
# the price feed in one line (app/feed/health.py; never a token or a price): why no signal came, without the logs.
# The env file is read line by line (KEY=value, as systemd reads it), never run as shell code.
if [ -x /opt/edge-desk/.venv/bin/python ] && [ -r /etc/edge-desk/env ]; then
  ( while IFS= read -r line || [ -n "$line" ]; do
      case "$line" in ''|'#'*) ;; [A-Z_]*=*) export "${line%%=*}=${line#*=}" ;; esac
    done < /etc/edge-desk/env
    cd /opt/edge-desk && runuser -u edge -p -- /opt/edge-desk/.venv/bin/python -m app feed --status ) 2>/dev/null \
    || echo "feed: status not available"
fi
if [ "${1:-}" = --login ]; then
  # the dashboard login, shown only on this console when asked for
  grep '^EDGE_DASHBOARD_TOKEN=' /etc/edge-desk/env | cut -d= -f2-
fi
