"""Journal storage: one SQLite file (Python standard library, no server, no new dependency).

The saved data shape below is a PROPOSAL waiting for the owner's approval (AGENTS.md: new kinds of
saved data need the owner's approval first). All times are UTC ISO-8601 strings ("...Z").
Money is in the account currency. R is the trade's result divided by its planned risk.

Ledgers (blueprint "Keep the records separate"):
  1. opportunity  every setup the planner found, offered or not (plus planner_run: one row per plan,
                  including "no trade today: <reason>")
  2. choice       the owner's decision on an opportunity, or an own idea with no opportunity
  3. trade        the actual trade: MT5 (read from the bridge) or paper, never mixed (column `book`)
Supporting tables: bridge_status, deal (raw MT5 deals, append-only), position_seen, sl_change,
trade_flag, paper_order, alert, review_note, push_subscription (the owner's phones for Web Push alerts;
added in schema 2, also a proposal waiting for the owner's approval), news_event (EUR and USD economic calendar rows
from the MT5 terminal, app/news) and news_headline (Fed and ECB headline titles, times and links); schema 5, a
proposal waiting for the owner's approval. The A+ short's aplus_run, aplus_alert, aplus_day (append-only) and
aplus_state (app/aplus), added to schema 5 without a version step so an older release still opens the file: also a
proposal waiting for the owner's approval. The photo journal's photo, photo_link, photo_read, photo_trade and
photo_trade_edit (app/photos), the same way; the trade picture's order_seen (the placement time of each pending MT5
order) and journal_analysis (append-only), added the same way (docs/JOURNAL_DESIGN.md section 8.1): a proposal
waiting for the owner's approval too. Journal accounts (30 Oct 2026, the owner's OK in his request: CLAUDE.md "Journal
account for his 2nd account"): journal_account, journal_account_edit (append-only) and an account_id on photo and
photo_trade, the same way (docs/JOURNAL_DESIGN.md section 16). T1-M's t1m_trade, t1m_day (append-only) and t1m_state
(app/t1m), the same way.
"""
from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

SCHEMA_VERSION = 5

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Latest state of each bridge (one row per account alias). The raw snapshot is kept for the Live screen.
CREATE TABLE IF NOT EXISTS bridge_status (
    account_alias   TEXT PRIMARY KEY,
    bridge_session  TEXT NOT NULL,
    last_seq        INTEGER NOT NULL,
    last_seen_utc   TEXT NOT NULL,
    last_reason     TEXT NOT NULL,
    trade_allowed   INTEGER NOT NULL,          -- 1 = terminal could trade (not an investor login)
    server_offset_s INTEGER NOT NULL,          -- trade server clock minus UTC, measured by the EA
    clock_offset_s  INTEGER NOT NULL,          -- offset the app used to turn server times into UTC
    snapshot_json   TEXT NOT NULL              -- the validated payload as received
);

-- Raw closed deals from MT5, append-only, one row per deal ticket. Balance operations included.
CREATE TABLE IF NOT EXISTS deal (
    account_alias TEXT NOT NULL,
    deal_id       TEXT NOT NULL,
    order_id      TEXT,
    position_id   TEXT,
    symbol        TEXT NOT NULL,
    type          TEXT NOT NULL CHECK (type IN ('buy','sell','balance','credit','charge','correction',
                                                'bonus','commission','interest','other')),
    entry         TEXT NOT NULL CHECK (entry IN ('in','out','inout','out_by','none')),
    volume        REAL NOT NULL,
    price         REAL NOT NULL,
    time_utc      TEXT NOT NULL,
    profit        REAL NOT NULL,
    commission    REAL NOT NULL,
    swap          REAL NOT NULL,
    fee           REAL NOT NULL,
    reason        TEXT NOT NULL,               -- tp, sl, so, client, mobile, web, expert, other
    sl            REAL,                        -- stop on the deal (entry: the order's stop; exit: the stop at exit)
    tp            REAL,
    received_utc  TEXT NOT NULL,
    PRIMARY KEY (account_alias, deal_id)
);
CREATE INDEX IF NOT EXISTS deal_position ON deal (account_alias, position_id);

-- Every MT5 position the bridge has seen, with its first-seen stop (the planned risk).
CREATE TABLE IF NOT EXISTS position_seen (
    account_alias  TEXT NOT NULL,
    position_id    TEXT NOT NULL,
    symbol         TEXT NOT NULL,
    side           TEXT NOT NULL CHECK (side IN ('buy','sell')),
    volume         REAL NOT NULL,
    open_price     REAL NOT NULL,
    open_utc       TEXT NOT NULL,
    initial_sl     REAL,                       -- NULL while the position has no stop (hard incident)
    initial_tp     REAL,
    last_sl        REAL,
    last_tp        REAL,
    first_seen_utc TEXT NOT NULL,
    last_seen_utc  TEXT NOT NULL,
    closed_utc     TEXT,
    no_stop_seen   INTEGER NOT NULL DEFAULT 0 CHECK (no_stop_seen IN (0,1)),  -- 1 once seen with no stop:
                                               -- the no_stop incident is raised once per position
    max_fav_r      REAL,                       -- schema 3 (A6): highest R seen from snapshot prices (approximate)
    PRIMARY KEY (account_alias, position_id)
);

-- Stop and target changes on open positions (breakeven moves are detected from here).
CREATE TABLE IF NOT EXISTS sl_change (
    id            INTEGER PRIMARY KEY,
    account_alias TEXT NOT NULL,
    position_id   TEXT NOT NULL,
    at_utc        TEXT NOT NULL,
    old_sl        REAL,
    new_sl        REAL,
    old_tp        REAL,
    new_tp        REAL
);

-- One row per planner run: the plan for a trading day, or "no trade today: <reason>".
CREATE TABLE IF NOT EXISTS planner_run (
    id               INTEGER PRIMARY KEY,
    run_utc          TEXT NOT NULL,
    trading_day      TEXT NOT NULL,            -- YYYY-MM-DD, day ending 17:00 New York
    strategy         TEXT NOT NULL,
    strategy_version TEXT NOT NULL,
    result           TEXT NOT NULL CHECK (result IN ('orders','no_trade')),
    reason           TEXT,                     -- set when result = 'no_trade'
    n_cards          INTEGER NOT NULL DEFAULT 0,
    guard_json       TEXT NOT NULL             -- day guard and streak state at plan time
);
CREATE INDEX IF NOT EXISTS planner_run_day ON planner_run (trading_day);

-- Ledger 1: every opportunity the planner found, offered or not.
CREATE TABLE IF NOT EXISTS opportunity (
    id                 INTEGER PRIMARY KEY,
    planner_run_id     INTEGER NOT NULL REFERENCES planner_run(id),
    created_utc        TEXT NOT NULL,
    trading_day        TEXT NOT NULL,
    symbol             TEXT NOT NULL,
    setup              TEXT NOT NULL,
    side               TEXT NOT NULL CHECK (side IN ('buy','sell')),
    entry              REAL NOT NULL,
    stop               REAL NOT NULL,
    target             REAL NOT NULL,
    target_r           REAL NOT NULL,
    expiry_utc         TEXT NOT NULL,
    swept_level        TEXT,                   -- the liquidity level the setup names
    risk_pct           REAL NOT NULL,
    lots               REAL,
    offered            INTEGER NOT NULL CHECK (offered IN (0,1)),
    not_offered_reason TEXT,
    checklist_json     TEXT NOT NULL DEFAULT '[]'
);

-- Ledger 2: the owner's choice on an opportunity, or an own idea (opportunity_id NULL).
CREATE TABLE IF NOT EXISTS choice (
    id              INTEGER PRIMARY KEY,
    created_utc     TEXT NOT NULL,
    opportunity_id  INTEGER REFERENCES opportunity(id),
    trade_id        INTEGER REFERENCES trade(id),
    decision        TEXT NOT NULL CHECK (decision IN ('take','skip','modify','own_idea')),
    tag             TEXT NOT NULL CHECK (tag IN ('planned','own_idea','rule_break')),
    would_take      INTEGER CHECK (would_take IN (0,1)),
    management      TEXT CHECK (management IN ('close_at_4r','trail_to_2r')),
    note            TEXT NOT NULL DEFAULT ''
);
CREATE UNIQUE INDEX IF NOT EXISTS choice_trade ON choice (trade_id) WHERE trade_id IS NOT NULL;

-- Ledger 3: the actual trade. book = 'mt5' (read from the bridge) or 'paper'. Never mixed in results.
CREATE TABLE IF NOT EXISTS trade (
    id                 INTEGER PRIMARY KEY,
    book               TEXT NOT NULL CHECK (book IN ('mt5','paper')),
    account_alias      TEXT NOT NULL,
    broker_position_id TEXT,                   -- MT5 position ticket (kept on the owner's server only)
    paper_order_id     INTEGER REFERENCES paper_order(id),
    symbol             TEXT NOT NULL,
    side               TEXT NOT NULL CHECK (side IN ('buy','sell')),
    volume             REAL NOT NULL,
    status             TEXT NOT NULL CHECK (status IN ('open','closed')),
    open_utc           TEXT NOT NULL,
    open_price         REAL NOT NULL,
    initial_sl         REAL,
    initial_tp         REAL,
    close_utc          TEXT,
    close_price        REAL,
    close_reason       TEXT CHECK (close_reason IN ('tp','sl','be','manual','so','expired','other')),
    sl_at_exit         REAL,
    profit             REAL NOT NULL DEFAULT 0,
    commission         REAL NOT NULL DEFAULT 0,
    swap               REAL NOT NULL DEFAULT 0,
    fee                REAL NOT NULL DEFAULT 0,
    net_profit         REAL NOT NULL DEFAULT 0,
    risk_money         REAL,                   -- money lost if the first stop had been hit
    stop_pips          REAL,
    r_net              REAL,                   -- net_profit / risk_money (costs included)
    r_gross            REAL,                   -- price move / stop distance (costs excluded)
    balance_at_open    REAL,
    pct_of_balance     REAL,                   -- net_profit / balance_at_open * 100
    trading_day        TEXT NOT NULL,          -- of the open; day ending 17:00 New York
    close_trading_day  TEXT,
    session            TEXT NOT NULL CHECK (session IN ('asia','london','new_york')),
    near_miss          INTEGER CHECK (near_miss IN (0,1)),
    -- schema 3 (A4), MT5 trades: the cost split. Pips on the fill side; NULL where the quote is unknown.
    mid_in               REAL,                 -- mid price at the entry (volume-weighted over entry deals)
    mid_out              REAL,
    spread_in_pips       REAL,
    spread_out_pips      REAL,
    quote_drift_in_pips  REAL,                 -- the fill minus the snapshot's ask or bid on the fill side
    quote_drift_out_pips REAL,
    spread_source        TEXT,                 -- snapshot, own_median or unknown (the weakest of the deals)
    quote_lag_s          INTEGER,              -- the longest snapshot lag behind the trade's deals
    slip_exit_pips       REAL,                 -- a stop exit's fill past the stop (positive = worse)
    gross_mid_pips       REAL,                 -- chart move: mid to mid, before every cost
    net_pips             REAL,                 -- price result plus commission, swap and fee, in pips
    UNIQUE (book, account_alias, broker_position_id)
);
CREATE INDEX IF NOT EXISTS trade_day ON trade (book, trading_day);

-- Automatic flags on trades: rule breaks and incidents found by the app.
CREATE TABLE IF NOT EXISTS trade_flag (
    trade_id   INTEGER NOT NULL REFERENCES trade(id),
    flag       TEXT NOT NULL CHECK (flag IN ('after_max_losses','after_loss_after_win','over_trades_after_win',
                                             'over_open_risk','no_stop','early_close','size_above_risk',
                                             'stop_moved_away','no_checklist','below_tier','over_tier_risk',
                                             'no_stop_to_entry')),
    detail     TEXT NOT NULL DEFAULT '',
    created_utc TEXT NOT NULL,
    PRIMARY KEY (trade_id, flag)
);

-- Paper-trade log: an order card followed exactly as if real money were at stake.
CREATE TABLE IF NOT EXISTS paper_order (
    id             INTEGER PRIMARY KEY,
    created_utc    TEXT NOT NULL,
    opportunity_id INTEGER REFERENCES opportunity(id),
    symbol         TEXT NOT NULL,
    side           TEXT NOT NULL CHECK (side IN ('buy','sell')),
    order_type     TEXT NOT NULL CHECK (order_type IN ('limit','stop','market')),
    entry          REAL NOT NULL,
    stop           REAL NOT NULL,
    target         REAL NOT NULL,
    expiry_utc     TEXT,
    risk_pct       REAL NOT NULL,
    lots           REAL NOT NULL,
    status         TEXT NOT NULL CHECK (status IN ('pending','filled','closed','expired','cancelled')),
    filled_utc     TEXT,
    fill_price     REAL,
    closed_utc     TEXT,
    exit_price     REAL,
    exit_reason    TEXT CHECK (exit_reason IN ('tp','sl','be','manual','expired','cancelled')),
    note           TEXT NOT NULL DEFAULT ''
);

-- Alerts: every message the app sends, with a unique key so nothing is sent twice.
CREATE TABLE IF NOT EXISTS alert (
    id          INTEGER PRIMARY KEY,
    key         TEXT NOT NULL UNIQUE,
    kind        TEXT NOT NULL,
    priority    INTEGER NOT NULL CHECK (priority BETWEEN 1 AND 5),
    title       TEXT NOT NULL,
    body        TEXT NOT NULL,
    created_utc TEXT NOT NULL,
    status      TEXT NOT NULL CHECK (status IN ('queued','sent','failed','skipped')),
    attempts    INTEGER NOT NULL DEFAULT 0,
    sent_utc    TEXT,
    last_error  TEXT,
    next_try_utc TEXT                          -- a hard incident that failed waits until then (back-off)
);

-- The one action item from the weekly review (Rules screen).
CREATE TABLE IF NOT EXISTS review_note (
    id          INTEGER PRIMARY KEY,
    week        TEXT NOT NULL UNIQUE,          -- ISO week, e.g. 2026-W41
    action_item TEXT NOT NULL,
    created_utc TEXT NOT NULL
);

-- Phones that get the alerts by Web Push (schema 2): one row per browser push subscription, saved when the
-- owner taps "Turn on alerts on this phone". The endpoint and keys stay on the owner's server and are never
-- returned by the API. A row is deleted when the push service says the subscription is gone (404 / 410).
CREATE TABLE IF NOT EXISTS push_subscription (
    id          INTEGER PRIMARY KEY,
    endpoint    TEXT NOT NULL UNIQUE,          -- the push service URL for this phone (https)
    p256dh      TEXT NOT NULL,                 -- the phone's P-256 public key, base64url (encrypts the alert)
    auth        TEXT NOT NULL,                 -- the phone's 16-byte auth secret, base64url
    user_agent  TEXT NOT NULL DEFAULT '',      -- browser label, to tell the phones apart (at most 200 chars)
    created_utc TEXT NOT NULL,
    last_ok_utc TEXT,                          -- last time the push service accepted an alert for it
    failures    INTEGER NOT NULL DEFAULT 0,    -- pushes refused other than "gone"
    last_error  TEXT                           -- short reason, never the endpoint or keys
);

-- Setup checks (schema 3): the owner's top-down checklist filled before a trade, or a coded suggestion's
-- checklist. Versioned: an edit adds a row (check_id = the first version's id). A check locks at its first
-- link; an edit after that is an 'after_entry' version, which results by tick leave out.
CREATE TABLE IF NOT EXISTS checklist (
    id            INTEGER PRIMARY KEY,
    check_id      INTEGER NOT NULL,            -- id of version 1 of this check
    version       INTEGER NOT NULL,
    created_utc   TEXT NOT NULL,
    source        TEXT NOT NULL CHECK (source IN ('owner','code')),
    suggestion_id INTEGER,                     -- the suggestion it came from (Phase 3), else NULL
    account_alias TEXT NOT NULL,
    symbol        TEXT NOT NULL,
    side          TEXT NOT NULL CHECK (side IN ('buy','sell')),
    fields_json   TEXT NOT NULL,               -- every field as typed or ticked
    entry         REAL NOT NULL,
    zone_low      REAL NOT NULL,               -- the entry zone (the entry itself when no zone was typed)
    zone_high     REAL NOT NULL,
    stop          REAL NOT NULL,               -- stop reference -/+ cushion
    stop_pips     REAL NOT NULL,
    target        REAL NOT NULL,
    target_r      REAL NOT NULL,
    cost_r        REAL NOT NULL,               -- 2.0 pips in R (the pass case)
    cost_r_info   REAL NOT NULL,               -- 1.6 pips in R
    m1 INTEGER NOT NULL, m2 INTEGER NOT NULL, m3 INTEGER NOT NULL, m4 INTEGER NOT NULL,
    c1 INTEGER NOT NULL, c2 INTEGER NOT NULL, c3 INTEGER NOT NULL, c4 INTEGER NOT NULL, c5 INTEGER NOT NULL,
    score         INTEGER NOT NULL CHECK (score BETWEEN 0 AND 5),
    tier          TEXT NOT NULL CHECK (tier IN ('full','half','none')),
    risk_share    REAL NOT NULL,               -- share of the owner's configured risk: 1, 0.5 or 0
    after_entry   INTEGER NOT NULL DEFAULT 0 CHECK (after_entry IN (0,1)),
    status        TEXT NOT NULL CHECK (status IN ('open','locked','superseded','after_entry','expired')),
    expiry_utc    TEXT NOT NULL,
    locked_utc    TEXT,
    UNIQUE (check_id, version)
);

-- Links from a setup check to the owner's MT5 order and trade (schema 3).
CREATE TABLE IF NOT EXISTS checklist_link (
    id            INTEGER PRIMARY KEY,
    check_id      INTEGER NOT NULL,
    checklist_row INTEGER NOT NULL REFERENCES checklist(id),   -- the version current when the link was made
    created_utc   TEXT NOT NULL,
    account_alias TEXT NOT NULL,
    order_ticket  TEXT,
    position_id   TEXT,
    trade_id      INTEGER REFERENCES trade(id),
    method        TEXT NOT NULL CHECK (method IN ('owner_tap','auto_exact_ticket','auto_match')),
    confirmed     INTEGER NOT NULL CHECK (confirmed IN (0,1)),   -- an auto_match is offered (0) until confirmed
    rejected_utc  TEXT                         -- the owner said it is not this check's trade: ignored from then on
);
CREATE INDEX IF NOT EXISTS checklist_link_check ON checklist_link (check_id);
CREATE UNIQUE INDEX IF NOT EXISTS checklist_link_trade ON checklist_link (check_id, trade_id) WHERE trade_id IS NOT NULL;

-- Quote samples (schema 3): each snapshot's bid and ask per symbol, at the snapshot's own time, for the spread
-- at a fill and the account's own median spread per New York hour (A4).
CREATE TABLE IF NOT EXISTS quote_sample (
    account_alias TEXT NOT NULL,
    symbol        TEXT NOT NULL,
    at_utc        TEXT NOT NULL,
    bid           REAL NOT NULL,
    ask           REAL NOT NULL,
    spread_pips   REAL NOT NULL,
    ny_hour       INTEGER NOT NULL CHECK (ny_hour BETWEEN 0 AND 23),
    PRIMARY KEY (account_alias, symbol, at_utc)
);
CREATE INDEX IF NOT EXISTS quote_sample_hour ON quote_sample (account_alias, symbol, ny_hour);

-- The quote fixed for each buy or sell deal when it was first stored (schema 3, A4): the first snapshot within
-- 10 s after the fill ('snapshot'), else the account's own median spread for that symbol and New York hour from
-- at least 30 earlier samples ('own_median'), else 'unknown'. Never changed afterwards.
CREATE TABLE IF NOT EXISTS deal_quote (
    account_alias TEXT NOT NULL,
    deal_id       TEXT NOT NULL,
    source        TEXT NOT NULL CHECK (source IN ('snapshot','own_median','unknown')),
    bid           REAL,
    ask           REAL,
    mid           REAL,
    spread_pips   REAL,
    drift_pips    REAL,                        -- the fill minus the snapshot's ask (buy) or bid (sell); NULL unless snapshot
    lag_s         INTEGER,                     -- snapshot time minus fill time
    samples       INTEGER,                     -- samples behind an own median
    stored_utc    TEXT NOT NULL,
    PRIMARY KEY (account_alias, deal_id)
);

-- Schema 4 (Part B). EUR/USD 1-minute bid/ask candles from the B1 feed (OANDA practice), complete candles only,
-- one row per minute that traded (ts = the minute's open, unix seconds UTC). They stay on the server: never exported.
CREATE TABLE IF NOT EXISTS m1_bar (
    ts     INTEGER PRIMARY KEY CHECK (ts % 60 = 0),
    bid_o  REAL NOT NULL,
    bid_h  REAL NOT NULL,
    bid_l  REAL NOT NULL,
    bid_c  REAL NOT NULL,
    ask_o  REAL NOT NULL,
    ask_h  REAL NOT NULL,
    ask_l  REAL NOT NULL,
    ask_c  REAL NOT NULL,
    volume INTEGER NOT NULL
);

-- The feed's own state: last_request_ts (the 2 s gap across restarts), complete_through (the marker), failures,
-- stopped_until. No token, no response body.
CREATE TABLE IF NOT EXISTS feed_state (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Every 403 or 429: the host is blocked until until_utc (24 h, or Retry-After if longer), across restarts.
CREATE TABLE IF NOT EXISTS feed_block (
    id          INTEGER PRIMARY KEY,
    host        TEXT NOT NULL,
    code        INTEGER NOT NULL,
    blocked_utc TEXT NOT NULL,
    until_utc   TEXT NOT NULL,
    retry_after TEXT
);

-- Schema 4 (B4): the suggestion log. Append-only: triggers refuse every UPDATE and DELETE; a correction is a new row
-- whose supersedes_id points to the row it corrects. Suggestions come from the coded method (source 'method',
-- R57-1H-NEAR) and the three STATS leads (source 'lead'); a setup below the tier is a row with offered = 0.
CREATE TABLE IF NOT EXISTS suggestion (
    id            INTEGER PRIMARY KEY,
    key           TEXT NOT NULL,               -- source:rule:placement time:side (one per worker output)
    source        TEXT NOT NULL CHECK (source IN ('method','lead')),
    rule_id       TEXT NOT NULL,
    code_sha256   TEXT NOT NULL,
    offered       INTEGER NOT NULL CHECK (offered IN (0,1)),
    reason        TEXT,                        -- why not offered
    made_utc      TEXT NOT NULL,
    placed_ts     INTEGER NOT NULL,            -- when the rule placed it (unix s UTC)
    side          INTEGER NOT NULL CHECK (side IN (-1,1)),
    entry         REAL,                        -- NULL for a lead's market entry at its decision time
    stop          REAL,
    target        REAL,
    expiry_ts     INTEGER,
    score         INTEGER,
    tier          TEXT,
    w             REAL,
    ticks_json    TEXT NOT NULL DEFAULT '{}',
    record_line   TEXT NOT NULL,
    late          INTEGER NOT NULL DEFAULT 0 CHECK (late IN (0,1)),
    supersedes_id INTEGER REFERENCES suggestion(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS suggestion_key ON suggestion (key) WHERE supersedes_id IS NULL;

CREATE TABLE IF NOT EXISTS suggestion_decision (
    id            INTEGER PRIMARY KEY,
    suggestion_id INTEGER NOT NULL REFERENCES suggestion(id),
    decision      TEXT NOT NULL CHECK (decision IN ('take','skip','changed')),
    reason        TEXT NOT NULL DEFAULT '',
    decided_utc   TEXT NOT NULL,
    supersedes_id INTEGER REFERENCES suggestion_decision(id)
);

CREATE TABLE IF NOT EXISTS suggestion_link (
    id            INTEGER PRIMARY KEY,
    suggestion_id INTEGER NOT NULL REFERENCES suggestion(id),
    created_utc   TEXT NOT NULL,
    account_alias TEXT NOT NULL,
    order_ticket  TEXT,
    position_id   TEXT,
    trade_id      INTEGER REFERENCES trade(id),
    method        TEXT NOT NULL CHECK (method IN ('owner_tap','auto_exact_ticket','auto_match')),
    confirmed     INTEGER NOT NULL CHECK (confirmed IN (0,1)),
    rejected      INTEGER NOT NULL DEFAULT 0 CHECK (rejected IN (0,1)),
    supersedes_id INTEGER REFERENCES suggestion_link(id)
);

CREATE TABLE IF NOT EXISTS suggestion_result (
    id            INTEGER PRIMARY KEY,
    suggestion_id INTEGER NOT NULL UNIQUE REFERENCES suggestion(id),
    outcome       TEXT NOT NULL CHECK (outcome IN ('filled','expired','cancelled','no_trade')),
    exit_reason   TEXT,
    R_20          REAL,                        -- R after 2.0 pips (method) or the lead's own unit
    R_16          REAL,
    R_before      REAL,                        -- before costs
    unit          TEXT NOT NULL DEFAULT 'R' CHECK (unit IN ('R','pips')),
    settled_utc   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS suggestion_event (
    id            INTEGER PRIMARY KEY,
    suggestion_id INTEGER NOT NULL REFERENCES suggestion(id),
    kind          TEXT NOT NULL CHECK (kind IN ('cancel','expiry','lead_exit')),
    at_ts         INTEGER NOT NULL,
    made_utc      TEXT NOT NULL,
    detail        TEXT NOT NULL DEFAULT '',
    UNIQUE (suggestion_id, kind)
);

-- Each worker run (the method worker at each 1h close; the lead worker), including late and skipped runs.
CREATE TABLE IF NOT EXISTS worker_run (
    id         INTEGER PRIMARY KEY,
    worker     TEXT NOT NULL CHECK (worker IN ('method','lead','export')),
    close_ts   INTEGER NOT NULL,
    status     TEXT NOT NULL,
    detail     TEXT NOT NULL DEFAULT '',
    made_utc   TEXT NOT NULL
);

-- The lead worker (B3): one row per run of STATS's pinned compute_run, and its lines (kept on the server only).
CREATE TABLE IF NOT EXISTS lead_run (
    id              INTEGER PRIMARY KEY,
    run_utc         TEXT NOT NULL,
    data_end_ts     INTEGER NOT NULL,
    status          TEXT NOT NULL,
    calendar_sha256 TEXT,
    tree_sha256     TEXT,
    versions_json   TEXT NOT NULL DEFAULT '{}',
    state_json      TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS lead_line (
    id          INTEGER PRIMARY KEY,
    run_id      INTEGER NOT NULL REFERENCES lead_run(id),
    pick_id     TEXT NOT NULL,
    position_id TEXT,
    kind        TEXT NOT NULL,
    line_json   TEXT NOT NULL,
    line_sha256 TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS lead_line_position ON lead_line (position_id) WHERE position_id IS NOT NULL;

-- Schema 5 (news): EUR and USD economic calendar rows (app/news). Third-party data: kept news.keep_days, never
-- exported, not append-only (the source revises times and values; rows are pruned). MT5 rows only: the owner ruled on
-- 20 Oct 2026 that ForexFactory is not a source (nothing from it is fetched, stored or shown), so the CHECK that once
-- kept it open for Appendix F is closed (fix round 2; schema 5 had not shipped, so no table rebuild).
CREATE TABLE IF NOT EXISTS news_event (
    id             INTEGER PRIMARY KEY,
    source         TEXT NOT NULL CHECK (source IN ('mt5')),
    source_id      TEXT NOT NULL CHECK (length(source_id) BETWEEN 1 AND 64),
    currency       TEXT NOT NULL CHECK (length(currency) = 3),
    country        TEXT NOT NULL DEFAULT '',
    name           TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 128),
    kind           TEXT NOT NULL CHECK (kind IN ('indicator','event','holiday')),
    impact         TEXT NOT NULL CHECK (impact IN ('high','medium','low','none')),
    time_mode      TEXT NOT NULL CHECK (time_mode IN ('exact','all_day','no_time','tentative')),
    event_utc      TEXT NOT NULL,              -- UTC ...Z; a placeholder time unless time_mode = 'exact'
    day            TEXT NOT NULL,              -- YYYY-MM-DD: trading day (exact) or the source's own date (others)
    actual         TEXT,                       -- display strings as shown, NULL when not set
    forecast       TEXT,
    previous       TEXT,
    revised        TEXT,
    first_seen_utc TEXT NOT NULL,
    updated_utc    TEXT NOT NULL,
    digits         INTEGER NOT NULL DEFAULT 0 CHECK (digits BETWEEN 0 AND 10),
    actual_num     REAL,                       -- the numbers behind the strings, in the event's own units
    forecast_num   REAL,
    previous_num   REAL,                       -- the revised previous when set, else the previous
    actual_first_utc TEXT,                     -- when an actual was first stored (set once: the latency record)
    mt5_impact     TEXT CHECK (mt5_impact IS NULL OR mt5_impact IN ('positive','negative')),  -- MetaQuotes' label
    UNIQUE (source, source_id)
);
CREATE INDEX IF NOT EXISTS news_event_time ON news_event (event_utc);
CREATE INDEX IF NOT EXISTS news_event_day ON news_event (day);

-- Schema 5 (headlines, app/news/headlines.py): titles, times and links of the Federal Reserve's and the ECB's own
-- feeds (public domain, or free reuse with the source named). Never an article body. Kept headlines.keep_days, at
-- most HEADLINE_MAX_ROWS, never exported.
CREATE TABLE IF NOT EXISTS news_headline (
    id             TEXT PRIMARY KEY CHECK (length(id) = 20),
    source         TEXT NOT NULL CHECK (source IN ('fed_policy','fed_speeches','ecb_press')),
    kind           TEXT NOT NULL CHECK (kind IN ('statement','minutes','policy','speech','testimony','decision',
                                                 'release','interview','accounts','other')),
    title          TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 500),
    link           TEXT CHECK (link IS NULL OR (link LIKE 'https://%' AND length(link) <= 500)),
    published_utc  TEXT NOT NULL,
    first_seen_utc TEXT NOT NULL,
    alerted        INTEGER NOT NULL DEFAULT 0 CHECK (alerted IN (0,1))
);
CREATE INDEX IF NOT EXISTS news_headline_time ON news_headline (published_utc);

-- The A+ short, paper only (app/aplus, docs/APLUS_DESIGN.md section 6). Added in schema 5 without a version step:
-- CREATE TABLE IF NOT EXISTS only, no existing table changed, so an older release opens the same file and ignores
-- them. A proposal waiting for the owner's OK. Kept on the server: never exported, never pruned, in the backup.
-- aplus_run, aplus_alert and aplus_day are append-only (triggers below); aplus_state is the step's key/value state.
CREATE TABLE IF NOT EXISTS aplus_run (
    id            INTEGER PRIMARY KEY,
    run_utc       TEXT NOT NULL,
    now_ts        INTEGER NOT NULL,            -- T: the M5 close evaluated, from bars with ts < T only
    marker_ts     INTEGER,                     -- the feed's complete_through marker at the run
    status        TEXT NOT NULL CHECK (status IN ('ran','late','error','refused')),
    seconds       REAL NOT NULL DEFAULT 0,
    engine_runs   INTEGER NOT NULL DEFAULT 0,
    versions_json TEXT NOT NULL DEFAULT '{}',
    detail        TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS aplus_alert (
    id            INTEGER PRIMARY KEY,
    alert_id      TEXT NOT NULL,               -- the pinned code's id, e.g. ORDER:EUR_USD:2026-10-28
    kind          TEXT NOT NULL CHECK (kind IN ('ORDER','SKIPPED','RESIZE','FILLED','CANCELLED','CLOSE_SOON','CLOSED',
                                                'NO_TRADE_GAP','GAP_WARNING')),
    pair          TEXT NOT NULL,
    day           TEXT NOT NULL,               -- London date YYYY-MM-DD
    at_ts         INTEGER NOT NULL,            -- the M5 close the alert is stamped with
    facts_json    TEXT NOT NULL,               -- the values acted on (entry, stop, target, lots, times, R)
    text          TEXT NOT NULL,               -- the pinned code's own text, for the record
    pushed        INTEGER NOT NULL CHECK (pushed IN (0,1)),
    withdrawn     INTEGER NOT NULL DEFAULT 0 CHECK (withdrawn IN (0,1)),
    made_utc      TEXT NOT NULL,
    run_id        INTEGER REFERENCES aplus_run(id),
    supersedes_id INTEGER REFERENCES aplus_alert(id)   -- a correction, a withdrawal or "holds again"
);
CREATE UNIQUE INDEX IF NOT EXISTS aplus_alert_first ON aplus_alert (alert_id) WHERE supersedes_id IS NULL;
CREATE TABLE IF NOT EXISTS aplus_day (
    id         INTEGER PRIMARY KEY,
    pair       TEXT NOT NULL,
    day        TEXT NOT NULL,                  -- London date; the latest row of a pair-day is its state
    phase      TEXT NOT NULL CHECK (phase IN ('WAIT','SCANNING','NOT_ELIGIBLE','NO_TRADE','ARMED','FILLED',
                                              'CANCELLED','CLOSED')),
    reason     TEXT NOT NULL DEFAULT '',
    order_json TEXT,
    fill_json  TEXT,
    end_json   TEXT,
    guard_json TEXT,                           -- the BK3 decision, size and broker plan
    r_owner    REAL,                           -- R after the owner's costs (the research's owner-cost path)
    r_20       REAL,                           -- R after 2.0 pips on the same path
    made_utc   TEXT NOT NULL,
    run_id     INTEGER REFERENCES aplus_run(id)
);
CREATE INDEX IF NOT EXISTS aplus_day_pair_day ON aplus_day (pair, day);
CREATE TABLE IF NOT EXISTS aplus_state (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Journal accounts (owner, 30 Oct 2026; docs/JOURNAL_DESIGN.md section 16; app/journal/accounts.py): an account with no
-- MT5 link and no live tracking, kept from his MT5 phone pictures only. His request is the owner's OK for this saved
-- data: each account's name, currency and starting fund, and which account each picture and picture trade belongs to
-- (photo.account_id and photo_trade.account_id below; NULL there is the MT5-linked account). Added in schema 5 without
-- a version step, as the photo tables: an older release opens the same file and ignores them. Never exported, never
-- pruned, in the backup. A change of a name, a starting fund or a server clock is kept in journal_account_edit, written
-- by a trigger, so no path overwrites one silently; the rows are never deleted. server_clock: how its broker's MT5
-- server prints times (History rows): New York + 7 h (most MT5 brokers; the default until he names his broker), or a
-- fixed GMT+2, GMT+3 or GMT+0 (app/photos/clocks.py SERVER_CLOCKS); each reading keeps the clock it was made with.
CREATE TABLE IF NOT EXISTS journal_account (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(name)) BETWEEN 1 AND 40),
    currency    TEXT NOT NULL DEFAULT 'USD' CHECK (currency = 'USD'),
    start_fund  REAL NOT NULL CHECK (start_fund > 0),
    server_clock TEXT NOT NULL DEFAULT 'ny+7' CHECK (server_clock IN ('ny+7','gmt+2','gmt+3','gmt+0')),
    created_utc TEXT NOT NULL,
    changed_utc TEXT                              -- when it last changed (journal_account_edit says what)
);
CREATE TABLE IF NOT EXISTS journal_account_edit (
    id          INTEGER PRIMARY KEY,
    account_id  INTEGER NOT NULL REFERENCES journal_account(id),
    at_utc      TEXT NOT NULL,
    field       TEXT NOT NULL CHECK (field IN ('name','start_fund','server_clock')),
    old         TEXT,
    new         TEXT
);
CREATE INDEX IF NOT EXISTS journal_account_edit_account ON journal_account_edit (account_id, id);
CREATE TRIGGER IF NOT EXISTS journal_account_fund_kept AFTER UPDATE OF start_fund ON journal_account
WHEN NEW.start_fund IS NOT OLD.start_fund
BEGIN INSERT INTO journal_account_edit (account_id, at_utc, field, old, new) VALUES (OLD.id,
    CASE WHEN NEW.changed_utc IS NOT OLD.changed_utc THEN NEW.changed_utc ELSE strftime('%Y-%m-%dT%H:%M:%SZ', 'now') END,
    'start_fund', OLD.start_fund, NEW.start_fund); END;
CREATE TRIGGER IF NOT EXISTS journal_account_name_kept AFTER UPDATE OF name ON journal_account
WHEN NEW.name IS NOT OLD.name
BEGIN INSERT INTO journal_account_edit (account_id, at_utc, field, old, new) VALUES (OLD.id,
    CASE WHEN NEW.changed_utc IS NOT OLD.changed_utc THEN NEW.changed_utc ELSE strftime('%Y-%m-%dT%H:%M:%SZ', 'now') END,
    'name', OLD.name, NEW.name); END;
CREATE TRIGGER IF NOT EXISTS journal_account_clock_kept AFTER UPDATE OF server_clock ON journal_account
WHEN NEW.server_clock IS NOT OLD.server_clock
BEGIN INSERT INTO journal_account_edit (account_id, at_utc, field, old, new) VALUES (OLD.id,
    CASE WHEN NEW.changed_utc IS NOT OLD.changed_utc THEN NEW.changed_utc ELSE strftime('%Y-%m-%dT%H:%M:%SZ', 'now') END,
    'server_clock', OLD.server_clock, NEW.server_clock); END;
CREATE TRIGGER IF NOT EXISTS journal_account_no_delete BEFORE DELETE ON journal_account
BEGIN SELECT RAISE(ABORT, 'journal_account rows are kept'); END;
CREATE TRIGGER IF NOT EXISTS journal_account_edit_no_update BEFORE UPDATE ON journal_account_edit
BEGIN SELECT RAISE(ABORT, 'journal_account_edit is append-only'); END;
CREATE TRIGGER IF NOT EXISTS journal_account_edit_no_delete BEFORE DELETE ON journal_account_edit
BEGIN SELECT RAISE(ABORT, 'journal_account_edit is append-only'); END;

-- The photo journal (docs/JOURNAL_DESIGN.md §8.1; app/photos), phase 1: his pictures and their links to journal trades.
-- Added in schema 5 without a version step, as the A+ tables: CREATE TABLE IF NOT EXISTS only, so an older release
-- opens the same file and ignores them. No path column: a file's path is derived from sha256, ext, received_utc and
-- state (app/photos/store.py). The rows stay when a file is pruned or deleted (state 'deleted'); never exported.
CREATE TABLE IF NOT EXISTS photo (
    id               INTEGER PRIMARY KEY,
    sha256           TEXT NOT NULL UNIQUE CHECK (length(sha256) = 64),   -- of the stripped file
    received_utc     TEXT NOT NULL,
    file_mtime_utc   TEXT,                       -- the phone's File.lastModified, when sent
    bytes            INTEGER NOT NULL,
    width            INTEGER NOT NULL,
    height           INTEGER NOT NULL,
    mime             TEXT NOT NULL CHECK (mime IN ('image/jpeg','image/png')),
    ext              TEXT NOT NULL CHECK (ext IN ('jpg','png')),
    via              TEXT NOT NULL CHECK (via IN ('upload','share')),
    account_id       INTEGER REFERENCES journal_account(id),   -- NULL: the MT5-linked account; fixed at upload
    state            TEXT NOT NULL CHECK (state IN ('receiving','queued','reading','read','needs_taps','failed',
                                                   'rejected','confirmed','deleted')),
    kind             TEXT CHECK (kind IN ('chart','history','order','look_mt5','look_tradingview','other')),
    attempts         INTEGER NOT NULL DEFAULT 0,
    next_try_utc     TEXT,
    picture_utc      TEXT,                       -- when the picture was taken, once worked out (the reader)
    picture_time_how TEXT,
    confirmed_utc    TEXT,
    deleted_utc      TEXT
);
CREATE INDEX IF NOT EXISTS photo_state ON photo (state, received_utc);
CREATE TABLE IF NOT EXISTS photo_link (
    photo_id   INTEGER NOT NULL REFERENCES photo(id),
    trade_ref  TEXT NOT NULL,                    -- 'mt5:<trade id>' or 'paper:<trade id>' ('photo:<id>' later)
    role       TEXT NOT NULL CHECK (role IN ('order','open','close','look')),
    at_utc     TEXT NOT NULL,
    PRIMARY KEY (photo_id, trade_ref)
);
CREATE INDEX IF NOT EXISTS photo_link_trade ON photo_link (trade_ref);

-- The photo journal, phases 2-4 (docs/JOURNAL_DESIGN.md §8.1; app/photos/reader.py, trades.py): each reading of a
-- picture, the picture trades he confirmed and every value's origin. Schema 5, no version step, as the tables above;
-- never exported, never pruned (storage.KEEP_TABLES), in the backup. A proposal waiting for the owner's OK.
-- photo_read and photo_trade_edit are append-only; photo_trade keeps current values, refuses any change to a set
-- initial_sl (D15) and holds R only from initial_sl and an exact exit (History or bridge).
CREATE TABLE IF NOT EXISTS photo_read (
    id             INTEGER PRIMARY KEY,
    photo_id       INTEGER NOT NULL REFERENCES photo(id),
    made_utc       TEXT NOT NULL,
    reader_version TEXT NOT NULL,
    kind           TEXT NOT NULL CHECK (kind IN ('chart','history','order','look_mt5','look_tradingview','other')),
    outcome        TEXT NOT NULL CHECK (outcome IN ('draft','needs_taps','look','not_read','retry','failed')),
    message        TEXT NOT NULL DEFAULT '',     -- what he sees on the card
    prompt_sha     TEXT,                         -- sha256 of the fixed system text; NULL when no paid read ran
    schema_id      TEXT,                         -- mt5shot/2 when a paid read ran
    model_served   TEXT,                         -- who answered the paid read (a fallback may have served it)
    effort         TEXT,
    local_json_gz  BLOB,                         -- the local pass (gzip JSON)
    vision_json_gz BLOB,                         -- the paid reading as returned (gzip JSON)
    merged_json    TEXT NOT NULL DEFAULT '{}',   -- fields with value, state (green, amber, red) and source; lines
    checks_json    TEXT NOT NULL DEFAULT '[]',   -- V1-V15
    usage_json     TEXT NOT NULL DEFAULT '[]',   -- every attempt in usage.iterations: name, tokens in and out, usd
    tokens_in      INTEGER NOT NULL DEFAULT 0,
    tokens_out     INTEGER NOT NULL DEFAULT 0,
    usd_est        REAL NOT NULL DEFAULT 0,      -- summed over the attempts, each at its own price; the cap sums it
    ms             INTEGER NOT NULL DEFAULT 0,
    error          TEXT NOT NULL DEFAULT '',
    job            TEXT                          -- the outbox job ("<photo id>-<claim>") this reading came from
);
CREATE INDEX IF NOT EXISTS photo_read_photo ON photo_read (photo_id, id);
CREATE INDEX IF NOT EXISTS photo_read_made ON photo_read (made_utc);
CREATE TRIGGER IF NOT EXISTS photo_read_no_update BEFORE UPDATE ON photo_read
BEGIN SELECT RAISE(ABORT, 'photo_read is append-only'); END;
CREATE TRIGGER IF NOT EXISTS photo_read_no_delete BEFORE DELETE ON photo_read
BEGIN SELECT RAISE(ABORT, 'photo_read is append-only'); END;
-- Each paid call, imported by the local pass from the sender's ledger (app/photos/sender.py) once it has finished:
-- its actual cost, or its ceiling when no usage came back (an error, an answer that could not be parsed, a sender
-- stopped mid-call). The ledger is the cap; these rows are the journal's copy (Settings, the history), each call
-- once. A picture with a spend row whose job has no reading is never paid for again. Append-only; never exported,
-- never pruned, in the backup.
CREATE TABLE IF NOT EXISTS photo_spend (
    id          INTEGER PRIMARY KEY,
    photo_id    INTEGER NOT NULL REFERENCES photo(id),
    job         TEXT NOT NULL,                   -- the outbox job, as photo_read.job
    call        TEXT NOT NULL UNIQUE,            -- the ledger's call ("<job>.<n>")
    made_utc    TEXT NOT NULL,
    max_tokens  INTEGER NOT NULL,
    usage_json  TEXT NOT NULL DEFAULT '[]',      -- the call's attempts (a call with no usage: its ceiling)
    usd_est     REAL NOT NULL,
    error       TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS photo_spend_made ON photo_spend (made_utc);
CREATE INDEX IF NOT EXISTS photo_spend_photo ON photo_spend (photo_id, job);
CREATE TRIGGER IF NOT EXISTS photo_spend_no_update BEFORE UPDATE ON photo_spend
BEGIN SELECT RAISE(ABORT, 'photo_spend is append-only'); END;
CREATE TRIGGER IF NOT EXISTS photo_spend_no_delete BEFORE DELETE ON photo_spend
BEGIN SELECT RAISE(ABORT, 'photo_spend is append-only'); END;
CREATE TABLE IF NOT EXISTS photo_trade (
    id                INTEGER PRIMARY KEY,
    created_utc       TEXT NOT NULL,
    account_id        INTEGER REFERENCES journal_account(id),   -- NULL: the MT5-linked account; its photo's
    symbol            TEXT NOT NULL,
    side              TEXT CHECK (side IN ('buy','sell')),
    order_kind        TEXT CHECK (order_kind IN ('market','buy_limit','sell_limit','buy_stop','sell_stop')),
    lots              REAL,
    entry             REAL,                      -- the fill (a position) or the order price (a pending order)
    initial_sl        REAL,                      -- set once (trigger below): R and risk use it only (D15)
    initial_sl_how    TEXT CHECK (initial_sl_how IN ('order','bridge','confirmed')),
    sl                REAL,                      -- the current stop
    tp                REAL,
    placed_utc        TEXT,
    placed_how        TEXT CHECK (placed_how IN ('bridge','confirmed','owner_time','unknown')),
    fill_utc          TEXT,
    fill_how          TEXT CHECK (fill_how IN ('bridge','history','prices','picture','confirmed')),
    exit_utc_from     TEXT,                      -- a range when estimated from prices; the same time when exact
    exit_utc_to       TEXT,
    exit_price        REAL,
    exit_kind         TEXT CHECK (exit_kind IN ('sl','tp','manual','unknown')),
    exit_how          TEXT CHECK (exit_how IN ('history','bridge','prices')),
    profit            REAL,
    commission        REAL,                      -- signed as MT5 shows it (negative)
    swap              REAL,
    r_before_costs    REAL CHECK (r_before_costs IS NULL OR (initial_sl IS NOT NULL AND exit_how IN ('history','bridge'))),
    r_net             REAL CHECK (r_net IS NULL OR (initial_sl IS NOT NULL AND exit_how IN ('history','bridge'))),
    trading_day       TEXT,                      -- of the fill or the placing (17:00 New York)
    close_trading_day TEXT,
    session           TEXT CHECK (session IN ('asia','london','new_york')),
    linked_trade_id   INTEGER REFERENCES trade(id),   -- the bridge trade this is (the bridge row is the record)
    state             TEXT NOT NULL CHECK (state IN ('draft','confirmed','closed','void')),
    note              TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS photo_trade_state ON photo_trade (state, symbol);
CREATE TRIGGER IF NOT EXISTS photo_trade_initial_sl_once BEFORE UPDATE OF initial_sl, initial_sl_how ON photo_trade
WHEN OLD.initial_sl IS NOT NULL AND (NEW.initial_sl IS NOT OLD.initial_sl OR NEW.initial_sl_how IS NOT OLD.initial_sl_how)
BEGIN SELECT RAISE(ABORT, 'photo_trade.initial_sl is set once'); END;
CREATE TRIGGER IF NOT EXISTS photo_trade_no_delete BEFORE DELETE ON photo_trade
BEGIN SELECT RAISE(ABORT, 'photo_trade rows are kept (state void)'); END;
CREATE TABLE IF NOT EXISTS photo_trade_edit (
    id             INTEGER PRIMARY KEY,
    photo_trade_id INTEGER NOT NULL REFERENCES photo_trade(id),
    at_utc         TEXT NOT NULL,
    field          TEXT NOT NULL,
    old            TEXT,
    new            TEXT,
    by             TEXT NOT NULL CHECK (by IN ('reader','owner','bridge','prices')),
    reason         TEXT NOT NULL CHECK (reason IN ('read','fix','moved','close','answer')),
    photo_read_id  INTEGER REFERENCES photo_read(id)
);
CREATE INDEX IF NOT EXISTS photo_trade_edit_trade ON photo_trade_edit (photo_trade_id, id);
CREATE TRIGGER IF NOT EXISTS photo_trade_edit_no_update BEFORE UPDATE ON photo_trade_edit
BEGIN SELECT RAISE(ABORT, 'photo_trade_edit is append-only'); END;
CREATE TRIGGER IF NOT EXISTS photo_trade_edit_no_delete BEFORE DELETE ON photo_trade_edit
BEGIN SELECT RAISE(ABORT, 'photo_trade_edit is append-only'); END;

-- Paper streams, T1-M first (app/t1m, docs/T1M_DESIGN.md); every row carries its stream id. Added in schema 5 without
-- a version step: CREATE TABLE IF NOT
-- EXISTS only, no existing table changed, so an older release opens the same file and ignores them. Kept on the
-- server: never pruned, in the backup. t1m_trade and t1m_day are append-only (triggers below).
-- t1m_trade: one row per stage of a paper trade, written once: 'signal' (the signal candle closed), 'filled' (the
-- paper sell's fill), 'nofill' (no bar within 6 minutes), 'closed' (13:00 London exit or the stop).
CREATE TABLE IF NOT EXISTS t1m_trade (
    id         INTEGER PRIMARY KEY,
    stream     TEXT NOT NULL,                  -- the paper stream's rule id (app/t1m/rule.py STREAMS), e.g. T1M-V1
    day        TEXT NOT NULL,                  -- London date YYYY-MM-DD
    signal_ts  INTEGER NOT NULL,               -- the signal candle's open (unix s UTC)
    stage      TEXT NOT NULL CHECK (stage IN ('signal','filled','nofill','closed')),
    at_ts      INTEGER NOT NULL,               -- when the stage happened in the market (unix s UTC)
    ref        REAL,                           -- the signal candle's mid close
    entry      REAL,                           -- the paper sell price (mid open - 0.1 pip)
    stop       REAL,
    exit       REAL,
    exit_type  TEXT CHECK (exit_type IS NULL OR exit_type IN ('time','stop')),
    pips       REAL,                           -- after 0.5 pip commission (and 0.5 slippage on a stop), 1 unit
    risk_usd   REAL,                           -- closed rows: the sized dollars at the stop ([t1m] sizing, W or flat)
    usd        REAL,                           -- closed rows: pips x risk_usd / stop pips
    counted    INTEGER NOT NULL CHECK (counted IN (0,1)),   -- 1: signal at or after the module's start (the record)
    made_utc   TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS t1m_trade_stage ON t1m_trade (stream, signal_ts, stage);
CREATE INDEX IF NOT EXISTS t1m_trade_day ON t1m_trade (stream, day);
-- t1m_day: one row per stream and London weekday once the stream's exit time is in the data.
CREATE TABLE IF NOT EXISTS t1m_day (
    id        INTEGER PRIMARY KEY,
    stream    TEXT NOT NULL,
    day       TEXT NOT NULL,
    trades    INTEGER NOT NULL,
    stops     INTEGER NOT NULL,
    pips      REAL NOT NULL,
    usd       REAL NOT NULL,                  -- the sized dollars of the day ([t1m] sizing)
    made_utc  TEXT NOT NULL,
    UNIQUE (stream, day)
);
CREATE TABLE IF NOT EXISTS t1m_state (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


APPEND_ONLY_TABLES = ("suggestion", "suggestion_decision", "suggestion_link", "suggestion_result", "suggestion_event",
                      "worker_run", "lead_run", "lead_line", "aplus_run", "aplus_alert", "aplus_day", "t1m_trade",
                      "t1m_day")
for _t in APPEND_ONLY_TABLES:
    SCHEMA += (f"CREATE TRIGGER IF NOT EXISTS {_t}_no_update BEFORE UPDATE ON {_t} "
               f"BEGIN SELECT RAISE(ABORT, '{_t} is append-only'); END;\n"
               f"CREATE TRIGGER IF NOT EXISTS {_t}_no_delete BEFORE DELETE ON {_t} "
               f"BEGIN SELECT RAISE(ABORT, '{_t} is append-only'); END;\n")

# The trade picture (app/journal/overlay; docs/JOURNAL_DESIGN.md sections 7.3 and 8.1). Added in schema 5 without a
# version step, as the A+ tables were: CREATE TABLE IF NOT EXISTS only, no existing table changed, so an older release
# opens the same file and ignores them. A proposal waiting for the owner's OK. Kept on the server: never exported,
# never pruned, in the backup.
JOURNAL_SCHEMA = """
-- order_seen: each pending MT5 order the first time a bridge snapshot shows it, written by the ingest in the
-- snapshot's own transaction. setup_utc is the order's setup_time (trade-server time) turned into UTC by that
-- snapshot's clock (app/ingest/clock.py). The bridge keeps only the latest snapshot, so this is the one record of
-- when a limit or stop order was placed: the decision time of the trade it fills (section 7.3 item 1).
CREATE TABLE IF NOT EXISTS order_seen (
    account_alias  TEXT NOT NULL,
    ticket         TEXT NOT NULL,              -- the order ticket (the entry deal's order_id once it fills)
    symbol         TEXT NOT NULL,
    type           TEXT NOT NULL,              -- buy_limit, sell_limit, buy_stop, ... as bridge/CONTRACT.md sends it
    price          REAL NOT NULL,
    sl             REAL,
    tp             REAL,
    setup_utc      TEXT NOT NULL,
    first_seen_utc TEXT NOT NULL,              -- when the snapshot that first held it was received
    PRIMARY KEY (account_alias, ticket)
);
-- journal_analysis: the trade picture's data (marks, tags as data, bars), append-only; a newer row of the same
-- trade supersedes the older one, which is kept. trade_ref is mt5:<trade id>, paper:<trade id> or photo:<id>.
CREATE TABLE IF NOT EXISTS journal_analysis (
    id               INTEGER PRIMARY KEY,
    trade_ref        TEXT NOT NULL CHECK (trade_ref GLOB 'mt5:[1-9]*' OR trade_ref GLOB 'paper:[1-9]*'
                                          OR trade_ref GLOB 'photo:[1-9]*'),
    tau              INTEGER NOT NULL CHECK (tau % 300 = 0),   -- the last 5m close at or before the decision
    inputs_sha       TEXT NOT NULL,            -- sha256 of the trade fields and price window it was made from
    pins_sha         TEXT NOT NULL,            -- the pinned engine's version (app/journal/overlay/pins.py)
    analysis_json_gz BLOB NOT NULL,
    final            INTEGER NOT NULL CHECK (final IN (0,1)),  -- 1: made after the trading day ended
    closed           INTEGER NOT NULL DEFAULT 0 CHECK (closed IN (0,1)),  -- 1: made from the trade's closed inputs
    made_utc         TEXT NOT NULL,
    supersedes_id    INTEGER REFERENCES journal_analysis(id)
);
CREATE INDEX IF NOT EXISTS journal_analysis_ref ON journal_analysis (trade_ref, id);
"""
JOURNAL_APPEND_ONLY = ("journal_analysis",)
for _t in JOURNAL_APPEND_ONLY:
    JOURNAL_SCHEMA += (f"CREATE TRIGGER IF NOT EXISTS {_t}_no_update BEFORE UPDATE ON {_t} "
                       f"BEGIN SELECT RAISE(ABORT, '{_t} is append-only'); END;\n"
                       f"CREATE TRIGGER IF NOT EXISTS {_t}_no_delete BEFORE DELETE ON {_t} "
                       f"BEGIN SELECT RAISE(ABORT, '{_t} is append-only'); END;\n")
SCHEMA += JOURNAL_SCHEMA
APPEND_ONLY_TABLES = APPEND_ONLY_TABLES + JOURNAL_APPEND_ONLY


def connect(path: Path | str) -> sqlite3.Connection:
    """Open (and create or migrate) the journal. Use ':memory:' in tests."""
    if str(path) != ":memory:":
        Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    if str(path) != ":memory:":
        conn.execute("PRAGMA journal_mode = WAL")
    migrate(conn)
    return conn


# Columns appended to a table after it was first created: CREATE TABLE IF NOT EXISTS leaves an existing
# table alone, so an older journal file gets them here (append-only, same definition as in SCHEMA).
_APPENDED_COLUMNS = (
    ("position_seen", "no_stop_seen", "INTEGER NOT NULL DEFAULT 0 CHECK (no_stop_seen IN (0,1))"),
    ("alert", "next_try_utc", "TEXT"),
    ("position_seen", "max_fav_r", "REAL"),
    # schema 3 (A4): the cost split of each MT5 trade
    ("trade", "mid_in", "REAL"),
    ("trade", "mid_out", "REAL"),
    ("trade", "spread_in_pips", "REAL"),
    ("trade", "spread_out_pips", "REAL"),
    ("trade", "quote_drift_in_pips", "REAL"),
    ("trade", "quote_drift_out_pips", "REAL"),
    ("trade", "spread_source", "TEXT"),
    ("trade", "quote_lag_s", "INTEGER"),
    ("trade", "slip_exit_pips", "REAL"),
    ("trade", "gross_mid_pips", "REAL"),
    ("trade", "net_pips", "REAL"),
    # schema 5, part 2 (news numbers, the latency record, MetaQuotes' impact label): a part 1 schema 5 file
    ("news_event", "digits", "INTEGER NOT NULL DEFAULT 0 CHECK (digits BETWEEN 0 AND 10)"),
    ("news_event", "actual_num", "REAL"),
    ("news_event", "forecast_num", "REAL"),
    ("news_event", "previous_num", "REAL"),
    ("news_event", "actual_first_utc", "TEXT"),
    ("news_event", "mt5_impact", "TEXT CHECK (mt5_impact IS NULL OR mt5_impact IN ('positive','negative'))"),
    # journal accounts (30 Oct 2026): which account a picture and a picture trade belong to (NULL: the MT5 account)
    ("photo", "account_id", "INTEGER REFERENCES journal_account(id)"),
    ("photo_trade", "account_id", "INTEGER REFERENCES journal_account(id)"),
)

# Made after the appended columns, which they name (an older file gets account_id above first): a picture's account is
# fixed at upload (a picture deleted, failed or never received may be sent again to another account), and a picture
# trade's account never changes. Kept apart in the file itself, whatever code opens it (a rollback to the previous
# install, whose code knows no accounts: review finding 1): a journal account's trade never gets a bridge trade
# (linked_trade_id), and its picture never gets a link to an MT5 or paper trade.
ACCOUNT_TRIGGERS = """
CREATE TRIGGER IF NOT EXISTS photo_account_fixed BEFORE UPDATE OF account_id ON photo
WHEN NEW.account_id IS NOT OLD.account_id AND OLD.state NOT IN ('deleted','failed','receiving')
BEGIN SELECT RAISE(ABORT, 'a picture''s account is fixed at upload'); END;
CREATE TRIGGER IF NOT EXISTS photo_trade_account_fixed BEFORE UPDATE OF account_id ON photo_trade
WHEN NEW.account_id IS NOT OLD.account_id
BEGIN SELECT RAISE(ABORT, 'a picture trade''s account is fixed'); END;
CREATE TRIGGER IF NOT EXISTS photo_trade_journal_never_linked BEFORE UPDATE OF linked_trade_id ON photo_trade
WHEN OLD.account_id IS NOT NULL AND NEW.linked_trade_id IS NOT OLD.linked_trade_id
BEGIN SELECT RAISE(ABORT, 'a journal account''s trade is never a bridge trade''s'); END;
CREATE TRIGGER IF NOT EXISTS photo_link_journal_apart BEFORE INSERT ON photo_link
WHEN (NEW.trade_ref GLOB 'mt5:*' OR NEW.trade_ref GLOB 'paper:*')
 AND (SELECT account_id FROM photo WHERE id = NEW.photo_id) IS NOT NULL
BEGIN SELECT RAISE(ABORT, 'a journal account''s picture is never linked to an MT5 or paper trade'); END;
"""


# 2 -> 3: trade_flag's CHECK lists the flags, and SQLite cannot change a CHECK in place, so the table is rebuilt
# with the full list: copy the rows into a new table, drop the old one, rename, in one transaction with foreign
# keys on (A3).
_TRADE_FLAG_COPY = "INSERT INTO trade_flag_new (trade_id, flag, detail, created_utc)" \
                   " SELECT trade_id, flag, detail, created_utc FROM trade_flag"


def _trade_flag_sql() -> str:
    start = SCHEMA.index("CREATE TABLE IF NOT EXISTS trade_flag (")
    return SCHEMA[start:SCHEMA.index(");", start) + 2]


def _rebuild_trade_flag(conn: sqlite3.Connection) -> None:
    sql = conn.execute("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'trade_flag'").fetchone()
    if sql is None or "no_stop_to_entry" in sql[0]:
        return
    conn.execute(_trade_flag_sql().replace("IF NOT EXISTS trade_flag (", "trade_flag_new (", 1))
    conn.execute(_TRADE_FLAG_COPY)
    conn.execute("DROP TABLE trade_flag")
    conn.execute("ALTER TABLE trade_flag_new RENAME TO trade_flag")


def migrate(conn: sqlite3.Connection) -> None:
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("BEGIN IMMEDIATE")
    try:
        _migrate(conn)
        bad = conn.execute("PRAGMA foreign_key_check").fetchall()
        if bad:
            raise sqlite3.IntegrityError(f"foreign key check failed after migration: {len(bad)} rows")
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    conn.execute("COMMIT")


def _migrate(conn: sqlite3.Connection) -> None:
    for statement in _statements(SCHEMA):
        conn.execute(statement)
    _rebuild_trade_flag(conn)
    for table, column, definition in _APPENDED_COLUMNS:
        if column not in [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
    for statement in _statements(ACCOUNT_TRIGGERS):
        conn.execute(statement)
    row = conn.execute("SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
    if row is None:
        conn.execute("INSERT INTO meta (key, value) VALUES ('schema_version', ?)", (str(SCHEMA_VERSION),))
    elif int(row["value"]) > SCHEMA_VERSION:
        raise RuntimeError(f"journal schema {row['value']} is newer than this app ({SCHEMA_VERSION})")
    elif int(row["value"]) < SCHEMA_VERSION:
        # The tables added since (push_subscription in 2; checklist and checklist_link in 3; news_event and
        # news_headline in 5) were
        # created above, and trade_flag was rebuilt with the schema 3 flags.
        conn.execute("UPDATE meta SET value = ? WHERE key = 'schema_version'", (str(SCHEMA_VERSION),))


def _statements(script: str) -> list[str]:
    """The script's statements one by one (executescript would COMMIT the open migration transaction)."""
    out, buf = [], ""
    for line in script.splitlines(keepends=True):
        buf += line
        if sqlite3.complete_statement(buf):
            if buf.strip():
                out.append(buf.strip())
            buf = ""
    return out


# One connection is shared by the server threads; every write goes through this lock.
_LOCK = threading.RLock()


@contextmanager
def transaction(conn: sqlite3.Connection):
    """Serialise writers and run the block as one transaction (rolled back on error)."""
    with _LOCK:
        if conn.in_transaction:  # nested use joins the outer transaction
            yield conn
            return
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        conn.execute("COMMIT")
