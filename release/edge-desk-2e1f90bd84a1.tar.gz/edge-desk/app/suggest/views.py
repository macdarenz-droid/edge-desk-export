"""B6 what the screens show of Part B, built on the server (the screens hold no strategy words): today's suggestion
and lead cards with their record lines, the Leads screen, and the Edge Lab row "your hand check against the coded
rule", which is information only (STATS ruling, 16 Oct 2026: not declared as a forward test).

The A+ orders (app/aplus: rule APLUS-A22, the A22 pick, buys and sells, since 30 Oct 2026; the v3 short's APLUS-V3
rows logged before then stay A+ cards with their own title) are logged as paper-lead suggestions and get the Take,
Skip and Changed buttons like your method's (owner, 16 Oct: every signal logged with your decision and the MT5
trade). An A+ card reads "withdrawn" while its latest row says the order no longer holds, gives its expiry (the 11:00
London cancel) in London time, and stays on Today until its own result is settled, then until 07:00 London of the next
weekday, so a 17:00 New York time exit's result shows beside his Take, Skip or Changed."""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta
from statistics import mean

from app.aplus.alerts import POOL_WORDS
from app.aplus.record import LEGACY_RULE_IDS
from app.aplus.record import RULE_ID as APLUS_RULE
from app.suggest import log as L
from app.t1m.rule import STREAMS as PAPER_STREAMS
from app.suggest.records import lead_ids, record_line
from app.timeutil import LONDON, day_bounds, from_iso, to_iso, trading_day

TICK_LABELS = {"M1": "Body-close break", "M2": "Untouched gap to enter", "M3": "Daily or 4h with it",
               "M4": "Target inside the zone", "C1": "Daily wick", "C2": "4h gap filled", "C3": "1h lower highs",
               "C4": "Pool past the target", "C5": "Small block inside",
               **{f"SWEEP_{k}": f"Swept the {v}" for k, v in POOL_WORDS.items()}}     # the A+ order's swept level
HAND_CHECK_TITLE = "Your hand check against the coded rule"
HAND_CHECK_NOTE = "Information. Not a test."
NEEDED_TEXT = "Not set: no forward test of this lead is declared yet."
STATE_NOTE = "Paper only. A lead's line settles when every calendar row it depends on is final."
APLUS_KEEP_S = 14 * 86400        # an unsettled A+ card of an earlier day stays this long at most (2 weeks: D14's carry)
APLUS_RULES = (APLUS_RULE, *LEGACY_RULE_IDS)
APLUS_TITLES = {APLUS_RULE: "A+ 3m+5m (paper)", "APLUS-V3": "A+ short (paper)"}


def _iso(ts) -> str | None:
    return None if ts is None else to_iso(datetime.fromtimestamp(int(ts)).astimezone())


def _side(v: int) -> str:
    return "buy" if v == 1 else "sell"


def card(conn: sqlite3.Connection, s: dict) -> dict:
    cur = L.current(conn, s["id"])
    ev = L.events(conn, s["id"])
    res = L.result(conn, s["id"])
    dec = L.current_decision(conn, s["id"])
    state = "open"
    if "cancel" in ev:
        state = "cancelled"
    elif "expiry" in ev:
        state = "expired"
    elif "lead_exit" in ev:
        state = "closed"
    aplus = cur["rule_id"] in APLUS_RULES
    if aplus and cur["offered"] and cur["reason"]:      # the latest row: the order no longer holds (until it holds again)
        state = "withdrawn"
    if res is not None:
        state = res["outcome"] if res["outcome"] != "no_trade" else "no trade"
        if res["exit_reason"] == "RULE_REPLACED":       # a v3 suggestion settled at the switch: no R, in no record
            state = "not followed: rule replaced 30 Oct"
        elif res["exit_reason"] == "SIDE_CHANGED":      # withdrawn when its order changed side
            state = "withdrawn"
    ticks = json.loads(cur["ticks_json"] or "{}")
    out = {"id": cur["id"] if cur["supersedes_id"] is None else L.root_of(conn, cur["id"]),
           "kind": cur["source"], "rule_id": cur["rule_id"],
           "title": "Your method" if cur["source"] == "method" else
           APLUS_TITLES[cur["rule_id"]] if aplus else
           f"{PAPER_STREAMS[cur['rule_id']].name} {_side(cur['side'])} (paper)" if cur["rule_id"] in PAPER_STREAMS
           else f"Paper lead {cur['rule_id']}",
           "record_line": cur["record_line"], "side": _side(cur["side"]), "placed_utc": _iso(cur["placed_ts"]),
           "expiry_utc": _iso(cur["expiry_ts"]), "expiry_city": "London" if aplus or cur["rule_id"] in PAPER_STREAMS else "New York",
           "result_note": "after costs" if cur["rule_id"] in PAPER_STREAMS else None,
           "entry": cur["entry"], "stop": cur["stop"], "target": cur["target"],
           "score": cur["score"], "tier": cur["tier"], "late": bool(cur["late"]), "state": state,
           "ticks": [{"label": TICK_LABELS.get(k, k), "ticked": v} for k, v in ticks.items() if v is not None],
           "decision": None if dec is None else {"decision": dec["decision"], "reason": dec["reason"],
                                                 "decided_utc": dec["decided_utc"]},
           "result": None if res is None else {k: res[k] for k in ("outcome", "exit_reason", "R_20", "R_16",
                                                                   "R_before", "unit")},
           "actions": ["take", "skip", "changed"] if cur["source"] == "method" or aplus or cur["rule_id"] in PAPER_STREAMS
           else [],
           "london_day": None}
    return out


def _shown_until(settled_utc: str) -> int:
    """07:00 London of the next London weekday after a result was settled (unix s)."""
    t = from_iso(settled_utc).astimezone(LONDON)
    d = t.date() if t.hour < 7 else t.date() + timedelta(days=1)
    while d.weekday() >= 5:
        d += timedelta(days=1)
    return int(datetime(d.year, d.month, d.day, 7, tzinfo=LONDON).timestamp())


def cards(conn: sqlite3.Connection, cfg, now: datetime) -> list[dict]:
    """Today's offered suggestions (the method's and the leads'), newest first; then the A+ cards of earlier trading
    days whose own result is not settled yet, or was settled less than a night ago (to 07:00 London of the next
    weekday): the trading day ends at 17:00 New York, the moment a time exit settles."""
    d = cfg.day
    lo, hi = day_bounds(trading_day(now, d.boundary_tz, d.boundary_hour), d.boundary_tz, d.boundary_hour)
    rows = [dict(r) for r in conn.execute(
        "SELECT * FROM suggestion WHERE supersedes_id IS NULL AND offered = 1 AND placed_ts >= ? AND placed_ts < ?"
        " ORDER BY placed_ts DESC, id DESC", (int(lo.timestamp()), int(hi.timestamp())))]
    t = now.timestamp()
    marks = ",".join("?" * len(APLUS_RULES))
    for r in conn.execute("SELECT * FROM suggestion WHERE supersedes_id IS NULL AND offered = 1 AND rule_id IN"
                          f" ({marks}) AND placed_ts < ? AND placed_ts >= ? ORDER BY placed_ts DESC, id DESC",
                          (*APLUS_RULES, int(lo.timestamp()), int(lo.timestamp()) - APLUS_KEEP_S)):
        res = L.result(conn, r["id"])
        if res is None or t < _shown_until(res["settled_utc"]):
            rows.append(dict(r, carried=True))
    out = []
    for r in rows:
        c = card(conn, r)
        if r.get("carried"):                            # a card from an earlier trading day names its London date
            d = datetime.fromtimestamp(int(r["placed_ts"]), LONDON).date()
            c["london_day"] = f"{d:%a} {d.day} {d:%b}"
        out.append(c)
    return out


def _mean(xs: list):
    xs = [x for x in xs if x is not None]
    return None if not xs else mean(xs)


def leads_panel(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    last = conn.execute("SELECT * FROM lead_run ORDER BY id DESC LIMIT 1").fetchone()
    st = json.loads(last["state_json"]).get("states") or {} if last is not None else {}
    out = []
    for pid in lead_ids():
        trades = []
        for r in conn.execute("SELECT line_json FROM lead_line WHERE pick_id = ? AND kind = 'trade' ORDER BY id",
                              (pid,)):
            x = json.loads(r[0])
            div = x["r_pips"] if x.get("unit") == "R" and x.get("r_pips") else 1.0
            n = x["net"]["long"]
            trades.append({"decision_utc": _iso(x["decision_ts"]), "exit_utc": _iso(x.get("exit_ts")),
                           "exit_reason": x.get("exit_reason"), "after_20": n["floor_2p0"] / div,
                           "after_16": n["floor_1p6"] / div, "before": x["recost"]["long"]["move_mid_pips"] / div})
        unit = "R" if pid == "R53-S3X3" else "pips"
        s = st.get(pid) or {}
        out.append({"rule_id": pid, "title": f"Paper lead {pid}", "record_line": record_line(pid),
                    "label": "Paper. Not proven.", "state": s.get("state", "waiting"), "state_text": s.get("text", ""),
                    "next_entry_utc": _iso(s.get("next_entry_ts")), "trades": trades,
                    "totals": {"trades": len(trades), "unit": unit,
                               "after_20": _mean([t["after_20"] for t in trades]),
                               "after_16": _mean([t["after_16"] for t in trades]),
                               "before": _mean([t["before"] for t in trades])},
                    "needed": {"count": None, "text": NEEDED_TEXT}})
    problem = None
    if last is not None and last["status"] == "mismatch":
        ids = json.loads(last["state_json"]).get("mismatch") or []
        problem = ("A recomputed line differs from the one logged: " + ", ".join(map(str, ids[:5])) +
                   ". The logged line is kept; the coordinator is told.")
    elif last is not None and last["status"] not in ("done",):
        problem = f"Last run: {last['status']}."
    return {"leads": out, "problem": problem, "run_utc": None if last is None else last["run_utc"],
            "calendar_sha256": None if last is None else last["calendar_sha256"], "state_note": STATE_NOTE}


def hand_check(conn: sqlite3.Connection, cfg) -> dict:
    """Your decisions on the coded method's suggestions beside the rule's own paper result. Information only."""
    roots = [dict(r) for r in conn.execute("SELECT * FROM suggestion WHERE source = 'method' AND offered = 1"
                                           " AND supersedes_id IS NULL")]
    counts = {"take": 0, "skip": 0, "changed": 0}
    coded, yours = [], []
    for s in roots:
        d = L.current_decision(conn, s["id"])
        if d is not None:
            counts[d["decision"]] += 1
        res = L.result(conn, s["id"])
        if res is not None and res["outcome"] == "filled":
            coded.append(res["R_20"])
        t = L.linked_trade(conn, s["id"])
        if t is not None and t["status"] == "closed":
            yours.append(t["r_net"])
    return {"title": HAND_CHECK_TITLE, "note": HAND_CHECK_NOTE, "offered": len(roots), "taken": counts["take"],
            "skipped": counts["skip"], "changed": counts["changed"],
            "coded_trades": len(coded), "coded_r_after_20": _mean(coded),
            "your_trades": len(yours), "your_r": _mean(yours), "min_trades": cfg.analytics.min_trades}
