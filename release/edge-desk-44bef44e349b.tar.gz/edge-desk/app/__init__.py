"""Edge Desk: a personal EUR/USD trading journal, read-only MT5 bridge, analytics in R and a day-rule guard.

Personal use only. The app never sends, changes or closes orders, and never shares signals.
"""
