"""`python3 -m app serve | check | bridge-status` (see app/main.py)."""
from app.main import main

raise SystemExit(main())
