"""Analytics: results in R first, then % of the account; every number carries how many trades it rests on."""
