"""Pure functions over trade dicts (as app.journal.store.list_trades returns them).

Readings:
  - Closed trades only. A trade with unknown R (r_net None: no stop) is left out of every R figure and
    counted in `unknown_r`; its % of the account still counts in total_pct, because the money moved.
  - n = closed trades with a known R (what the R figures rest on). Under `min_trades` the summary says
    "too early".
  - win / loss / breakeven by app.risk.day_guard.classify_trade with the breakeven band (a stop-at-entry
    exit inside the band before costs is a breakeven).
  - win_rate = wins / (wins + losses): breakevens are left out so it compares directly with
    breakeven_win_rate = |avg loss| / (avg win + |avg loss|). Breakevens still count in expectancy.
  - avg_loss_r is signed (negative). max_drawdown_r is the largest fall from a peak of cumulative R,
    as a positive size. profit_factor = sum of positive R / |sum of negative R| (None with no losses).
  - max_drawdown_pct: the same over cumulative % of the account, every closed trade included (a no-stop
    trade's money counts). max_drawdown_r_est (only with risk_pct): the R drawdown with each unknown-R
    trade estimated as streak mode does, min(-1R, its % / risk_pct), so a no-stop loss cannot vanish.
  - In the calendar a no-stop trade counts as a loss toward the day's loss limit (the guard's reading).
    hit_loss_limit counts every symbol when `day_rule_trades` is given (the guard does); R, %, trades,
    wins and losses stay EUR/USD.
  - Rule breaks (edge leak): any flag except the information flags (app.risk.flags.INFO_FLAGS: size
    above the configured risk, until the owner sets his real risk %) or the tag rule_break.
  - By exit choice: the owner's tag when set; otherwise, with the management levels given, trail_to_2r
    when the stop at exit sat at or beyond +trail_stop_r, close_at_4r when the trade closed at or beyond
    +take_or_trail_r; else none.
"""
from __future__ import annotations

import calendar as _cal
from datetime import date
from typing import Iterable

from app.config import ManagementSection, RiskSection
from app.risk.day_guard import classify_trade
from app.risk.flags import INFO_FLAGS

TOO_EARLY = "too early"
TAG_GROUPS = ("planned", "own_idea", "rule_break", "untagged")
SESSIONS = ("asia", "london", "new_york")
STOP_BUCKETS = ("<5", "5-10", "10-15", "15+")
WEEKDAYS = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
MANAGEMENT_GROUPS = ("close_at_4r", "trail_to_2r", "none")
BREAKDOWN_KEYS = ("session", "stop_bucket", "weekday", "management")


def _closed(trades: Iterable[dict]) -> list[dict]:
    out = [t for t in trades if t.get("status") == "closed"]
    out.sort(key=lambda t: (t.get("close_utc") or "", t.get("id") or 0))
    return out


def _mean(xs: list[float]) -> float | None:
    return sum(xs) / len(xs) if xs else None


def _drawdown(values: Iterable[float]) -> float:
    cum = peak = dd = 0.0
    for v in values:
        cum += v
        peak = max(peak, cum)
        dd = max(dd, peak - cum)
    return dd


def _r_est(t: dict, risk_pct: float) -> float:
    if t.get("r_net") is not None:
        return float(t["r_net"])
    pct = t.get("pct_of_balance")
    return min(-1.0, float(pct) / risk_pct if pct is not None else -1.0)


def summarize(trades: Iterable[dict], min_trades: int, band: float, risk_pct: float | None = None) -> dict:
    closed = _closed(trades)
    known_t = [t for t in closed if t.get("r_net") is not None]
    known = [float(t["r_net"]) for t in known_t]
    unknown = len(closed) - len(known)
    kinds = [classify_trade(t, band) for t in known_t]
    win_r = [r for r, k in zip(known, kinds) if k == "win"]
    loss_r = [r for r, k in zip(known, kinds) if k == "loss"]
    n = len(known)
    wins, losses = len(win_r), len(loss_r)
    avg_win, avg_loss = _mean(win_r), _mean(loss_r)
    bwr = None
    if avg_win is not None and avg_loss is not None:
        bwr = abs(avg_loss) / (avg_win + abs(avg_loss))
    dd = _drawdown(known)
    pcts = [float(t["pct_of_balance"]) for t in closed if t.get("pct_of_balance") is not None]
    gains = sum(r for r in known if r > 0)
    pains = -sum(r for r in known if r < 0)
    enough = n >= min_trades
    return {
        "n": n,
        "wins": wins,
        "losses": losses,
        "breakevens": n - wins - losses,
        "unknown_r": unknown,
        "win_rate": wins / (wins + losses) if wins + losses else None,
        "avg_win_r": avg_win,
        "avg_loss_r": avg_loss,
        "breakeven_win_rate": bwr,
        "expectancy_r": _mean(known),
        "total_r": sum(known, 0.0),
        "total_pct": sum((float(t["pct_of_balance"]) for t in closed if t.get("pct_of_balance") is not None), 0.0),
        "max_drawdown_r": dd,
        "max_drawdown_pct": _drawdown(pcts),
        "max_drawdown_r_est": _drawdown(_r_est(t, risk_pct) for t in closed) if risk_pct else None,
        "profit_factor": gains / pains if pains > 0 else None,
        "enough": enough,
        "label": None if enough else TOO_EARLY,
    }


def equity_curve(trades: Iterable[dict]) -> list[dict]:
    """One point per closed trade by close time. A trade with unknown R adds 0 to cum_r, its % to cum_pct."""
    out, cum_r, cum_pct = [], 0.0, 0.0
    for t in _closed(trades):
        r, pct = t.get("r_net"), t.get("pct_of_balance")
        if r is not None:
            cum_r += float(r)
        if pct is not None:
            cum_pct += float(pct)
        out.append({"t": t.get("close_utc"), "trade_id": t.get("id"), "r": r, "cum_r": cum_r, "pct": pct,
                    "cum_pct": cum_pct})
    return out


def calendar(trades: Iterable[dict], month: str, risk: RiskSection,
             day_rule_trades: Iterable[dict] | None = None) -> list[dict]:
    """Every day of `month` ("YYYY-MM") by close trading day: R, %, trades, wins, losses, hit_loss_limit.
    hit_loss_limit comes from `day_rule_trades` (every symbol) when given, else from `trades`."""
    try:
        y, m = (int(x) for x in month.split("-"))
        n_days = _cal.monthrange(y, m)[1]
    except (ValueError, AttributeError, _cal.IllegalMonthError) as exc:
        raise ValueError("month must look like 2026-10") from exc
    days = {date(y, m, d).isoformat(): {"day": date(y, m, d).isoformat(), "r": 0.0, "pct": 0.0, "trades": 0,
                                        "wins": 0, "losses": 0, "hit_loss_limit": False}
            for d in range(1, n_days + 1)}
    for t in _closed(trades):
        cell = days.get(t.get("close_trading_day") or "")
        if cell is None:
            continue
        r = t.get("r_net")
        kind = classify_trade(t, risk.breakeven_band_r)
        cell["trades"] += 1
        cell["wins"] += kind == "win"
        cell["losses"] += kind == "loss"
        if r is not None:
            cell["r"] += float(r)
        if t.get("pct_of_balance") is not None:
            cell["pct"] += float(t["pct_of_balance"])
    rule_losses = {d: cell["losses"] for d, cell in days.items()}
    if day_rule_trades is not None:
        rule_losses = dict.fromkeys(days, 0)
        for t in _closed(day_rule_trades):
            day = t.get("close_trading_day") or ""
            if day in rule_losses and classify_trade(t, risk.breakeven_band_r) == "loss":
                rule_losses[day] += 1
    for day, cell in days.items():
        cell["hit_loss_limit"] = rule_losses[day] >= risk.max_losses_per_day
    return list(days.values())


def _is_rule_break(t: dict) -> bool:
    return any(f not in INFO_FLAGS for f in (t.get("flags") or ())) or t.get("tag") == "rule_break"


def edge_leak(trades: Iterable[dict], min_trades: int, band: float) -> dict:
    """What rule breaks cost. A rule break is any flagged trade or one tagged rule_break."""
    closed = _closed(trades)
    clean = [t for t in closed if not _is_rule_break(t)]
    broken = [t for t in closed if _is_rule_break(t)]
    clean_s, broken_s = summarize(clean, min_trades, band), summarize(broken, min_trades, band)
    flags = sorted({f for t in closed for f in (t.get("flags") or [])})
    return {
        "clean": clean_s,
        "rule_break": broken_s,
        "cost_r": broken_s["total_r"],
        "without_breaks_total_r": clean_s["total_r"],
        "by_flag": {f: summarize([t for t in closed if f in (t.get("flags") or [])], min_trades, band)
                    for f in flags},
        "by_tag": {g: summarize([t for t in closed if (t.get("tag") or "untagged") == g], min_trades, band)
                   for g in TAG_GROUPS},
    }


def _stop_bucket(pips) -> str:
    if pips is None:
        return "unknown"
    p = float(pips)
    if p < 5:
        return "<5"
    if p < 10:
        return "5-10"
    if p < 15:
        return "10-15"
    return "15+"


def _weekday(t: dict) -> str:
    d = t.get("trading_day")
    return WEEKDAYS[date.fromisoformat(d).weekday()] if d else "unknown"


def exit_choice(t: dict, management: ManagementSection | None = None) -> str:
    """The +4R choice of a closed trade: the owner's tag, else inferred from the trade (see the module notes)."""
    if t.get("management"):
        return t["management"]
    if management is None:
        return "none"
    try:
        entry, first = float(t["open_price"]), float(t["initial_sl"])
    except (KeyError, TypeError, ValueError):
        return "none"
    dist = abs(entry - first)
    if dist <= 0:
        return "none"
    direction = 1.0 if t.get("side") == "buy" else -1.0
    sl = t.get("sl_at_exit")
    if sl is not None and (float(sl) - entry) * direction / dist >= management.trail_stop_r - 1e-9:
        return "trail_to_2r"
    g = t.get("r_gross")
    if g is not None and float(g) >= management.take_or_trail_r - 1e-9:
        return "close_at_4r"
    return "none"


def breakdown(trades: Iterable[dict], key: str, min_trades: int, band: float,
              management: ManagementSection | None = None) -> dict:
    """Summaries by session | stop_bucket | weekday (of the trading day) | management (+4R choice; inferred
    for untagged trades when the management levels are given)."""
    if key == "session":
        groups, of = SESSIONS, (lambda t: t.get("session") or "unknown")
    elif key == "stop_bucket":
        groups, of = STOP_BUCKETS, (lambda t: _stop_bucket(t.get("stop_pips")))
    elif key == "weekday":
        groups, of = WEEKDAYS[:5], _weekday
    elif key == "management":
        groups, of = MANAGEMENT_GROUPS, (lambda t: exit_choice(t, management))
    else:
        raise ValueError(f"key must be one of {BREAKDOWN_KEYS}")
    closed = _closed(trades)
    buckets: dict[str, list[dict]] = {g: [] for g in groups}
    for t in closed:
        buckets.setdefault(of(t), []).append(t)
    return {g: summarize(ts, min_trades, band) for g, ts in buckets.items()}


def by_symbol(trades: Iterable[dict], min_trades: int, band: float, is_eurusd, eurusd_label: str = "EUR/USD") -> list[dict]:
    """A7: one row per symbol, EUR/USD first (every broker name for it in one row), the others by name."""
    groups: dict[str, list[dict]] = {}
    for t in trades:
        key = "EURUSD" if is_eurusd(t["symbol"]) else t["symbol"]
        groups.setdefault(key, []).append(t)
    keys = sorted(groups, key=lambda k: (k != "EURUSD", k))
    return [{"symbol": k, "label": eurusd_label if k == "EURUSD" else k,
             "summary": summarize(groups[k], min_trades, band)} for k in keys]
