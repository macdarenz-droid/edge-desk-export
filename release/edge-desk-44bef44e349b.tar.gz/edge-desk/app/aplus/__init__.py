"""The A+ short (v3), paper only (docs/APLUS_DESIGN.md). Its decision code is not written here: pinned byte copies of
the verified bot (app/aplus/pinned, checked by pins.py) run in their own `python -I -B` process (child.py). The app
adds bars in (step.py), alert texts (alerts.py), the Today block (views.py) and the tested record (record.py).
Never an order card, never the planner slot, never an order."""
