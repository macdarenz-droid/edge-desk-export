"""Phone alerts for the A+ short (docs/APLUS_DESIGN.md sections 2 and 7). Paper only: every title names it, the order
alert carries the tested record line, every other body ends "Paper. Not proven.". No title starts with "Orders to
place" (that kind is the planner's).

Kinds and priorities (Web Push urgency: 3 normal, 2 low; design D10: 2 may be held by a push service until the phone
is on power and Wi-Fi, so everything time-critical is 3):
  aplus_order 3        the order arms (its M5 close); its push lives at most to its 11:00 London cancel (3 h at most),
                       and the drain drops it after the cancel
  aplus_filled 3       the first M5 close after the fill minute
  aplus_cancel 3       11:00 London unfilled, target first, or the fill minute also reached the target
  aplus_close_soon 3   16:55 New York, the trade still open: close at 17:00 New York
  aplus_closed 3       target, stop, or the 17:00 New York time exit ("close now at market")
  aplus_update 3       the rebuilt data changed a sent alert, it no longer holds or holds again; a guard resize
  aplus_skip 2         the BK3 guard skipped or blocked an order
  aplus_gap 2          a price gap over 16 minutes (no trade that day, or a gap after the order)
  aplus_data_stale 3, aplus_data_back 2   prices over [aplus] stale_after_min behind in the window, once a stall
  aplus_silent 3       serve's monitor: no A+ step heartbeat for 15 min in the window while the feed is on
  aplus_failing 3, aplus_check_back 2   the check itself failed at FAIL_ALERT_AFTER M5 closes in a row in the window
                       (the pinned code refused, the child crashed or timed out, too few prices), once a stall; back
                       once a check runs again. Both end "Paper. Not proven."; they, and aplus_silent, name the unit the
                       step runs in ([aplus] run_in: edge-desk-method or edge-desk-aplus)
Times: Melbourne on the 12-hour clock; the rule's own times (07:00, 10:00, 11:00 London, 17:00 New York) by name. An
alert is late when it goes out more than [aplus] late_after_min after the M5 close at which the check could first tell
it; a late alert then gives the event's own time (a fill, a cancel or an end minute; an order's arm; else that M5
close), the day when that is not today, and how long ago that was in minutes, hours or days.
Prices and lots are the pinned code's facts: the entry to the nearest broker point, stop and target rounded up. When
the broker's rounded stop reads differently from the rule's own stop (K1 units), both are named.
A closed trade leads with R after 2.0 pips, as the record line does, with the owner-cost R beside it.
"""
from __future__ import annotations

from datetime import date, datetime

from app.aplus import record
from app.notify.alerts import Alert
from app.timeutil import LONDON, MELBOURNE, NEW_YORK

KIND_MAP = {"ORDER": "aplus_order", "FILLED": "aplus_filled", "CANCELLED": "aplus_cancel",
            "CLOSE_SOON": "aplus_close_soon", "CLOSED": "aplus_closed", "SKIPPED": "aplus_skip",
            "RESIZE": "aplus_update", "GAP_WARNING": "aplus_gap", "NO_TRADE_GAP": "aplus_gap"}
PRIORITY = {"aplus_order": 3, "aplus_filled": 3, "aplus_cancel": 3, "aplus_close_soon": 3, "aplus_closed": 3,
            "aplus_update": 3, "aplus_data_stale": 3, "aplus_silent": 3, "aplus_failing": 3,
            "aplus_skip": 2, "aplus_gap": 2, "aplus_data_back": 2, "aplus_check_back": 2}
KINDS = frozenset(PRIORITY)
ORDER_TTL_S = 10800            # 3 h at most: most orders arm 08:00-10:05 London and cancel at 11:00 London; the push
                               # of one order lives only to its cancel (order_expires_ts, app/notify/push.py)
END = record.END               # "Paper. Not proven."
WHAT = {"ORDER": "order", "FILLED": "fill", "CANCELLED": "cancel", "CLOSE_SOON": "close reminder", "CLOSED": "close",
        "SKIPPED": "skip", "RESIZE": "size", "GAP_WARNING": "data gap", "NO_TRADE_GAP": "data gap"}
CANCEL_WHY = {"EXPIRED": "not filled by 11:00 London", "CANCEL_TARGET": "price reached the target before the entry",
              "CANCEL_FILLBAR": "the fill minute also reached the target, so the tested rule does not count it"}
GUARD_SHORT = (("weekly brake", "weekly brake"), ("day stop", "day stop"), ("one open short", "one short per pair"),
               ("both pairs", "both pairs"), ("dollar cap", "risk cap"))


# ---------------------------------------------------------------- formatting


def pair_name(pair: str) -> str:
    return pair.replace("_", "/")


def px(points: int) -> str:
    """Broker price from whole points (0.00001)."""
    p = int(points)
    return "%d.%05d" % (p // 100000, p % 100000)


def pips(points: int) -> str:
    return f"{abs(int(points)) / 10:.1f}"


UNITS_PER_PIP = 40                     # K1: 1 pip = 10 points = 40 units


def rule_pips(units) -> str:
    """Pips from K1 units: one decimal when that is exact, else two, rounded half up, so a stop just over 8 pips
    (321 units = 8.025 pips) reads 8.03, never 8.0 beside "over 8 pips"."""
    from fractions import Fraction
    x = Fraction(str(units)) / UNITS_PER_PIP
    if (x * 10).denominator == 1:
        return f"{float(x):.1f}"
    hundredths = int(x * 100 + Fraction(1, 2))
    return f"{hundredths // 100}.{hundredths % 100:02d}"


def stop_words(entry: int, stop: int, rule_units=None) -> str:
    """'15.5 pips', or '8.0 pips at the broker; rule stop 8.03 pips' when the broker's stop (whole points, rounded up)
    reads differently from the rule's own stop (K1 units: d0 of an order, d of a fill)."""
    broker = pips(int(stop) - int(entry))
    if rule_units in (None, ""):
        return f"{broker} pips"
    rule = rule_pips(rule_units)
    return f"{broker} pips" if rule == broker else f"{broker} pips at the broker; rule stop {rule} pips"


def unit_of(cfg) -> str:
    """The systemd unit the A+ step runs in: the method worker's, or its own with [aplus] run_in = "own" (D5)."""
    return "edge-desk-aplus" if cfg.aplus.run_in == "own" else "edge-desk-method"


def _clock(ts: int, tz) -> datetime:
    return datetime.fromtimestamp(int(ts), tz)


def hm12(ts: int, tz) -> str:
    t = _clock(ts, tz)
    return t.strftime("%I:%M %p").lstrip("0").lower()


def mel(ts: int, day: date | None = None) -> str:
    """'10:00 pm Melbourne', with the weekday when the Melbourne date is not the London day (e.g. 'Thu')."""
    m = _clock(ts, MELBOURNE)
    wd = "" if day is not None and m.date() == day else f" {m:%a}"
    return f"{hm12(ts, MELBOURNE)}{wd} Melbourne"


def london(ts: int) -> str:
    return f"{hm12(ts, LONDON)} London"


def mel_of(ts: int) -> str:
    """Melbourne time, with the weekday only when Melbourne is on another date than London."""
    return mel(ts, _clock(ts, LONDON).date())


def day_word(day: date) -> str:
    return f"{day:%a} {day.day} {day:%b}"


def since_words(since: int, at: int | None) -> str:
    """'2:00 pm London', with ' on Fri 30 Oct' when that London day is not the London day of `at`."""
    d = _clock(since, LONDON).date()
    same = at is None or _clock(at, LONDON).date() == d
    return london(since) + ("" if same else f" on {day_word(d)}")


def cancel_ts(day: date) -> int:
    return int(datetime(day.year, day.month, day.day, 11, 0, tzinfo=LONDON).timestamp())


def close_ts(day: date) -> int:
    return int(datetime(day.year, day.month, day.day, 17, 0, tzinfo=NEW_YORK).timestamp())


def lots_text(lots) -> str | None:
    """'0.06' from the pinned code's lots text ('3/50'), None when no size."""
    if lots in (None, "", "None"):
        return None
    from fractions import Fraction
    return f"{float(Fraction(str(lots))):.2f}"


def order_expires_ts(key: str) -> int | None:
    """When an aplus_order alert (key aplus:ORDER:<pair>:<London date>) is no use any more: its 11:00 London cancel
    (unix s). None for any other key."""
    parts = key.split(":")
    if len(parts) != 4 or parts[0] != "aplus" or parts[1] != "ORDER":
        return None
    try:
        day = date.fromisoformat(parts[3])
    except ValueError:
        return None
    return cancel_ts(day)


def order_still_valid(key: str, now: datetime) -> bool:
    """An aplus_order alert is worth sending only before its 11:00 London cancel. Any other key: True."""
    exp = order_expires_ts(key)
    return exp is None or now.timestamp() < exp


# ---------------------------------------------------------------- late alerts


def late_advice(kind: str, also: set) -> str:
    """What to do with an alert that comes late (bot/alert.py late_advice, the same cases)."""
    if kind == "ORDER":
        if also & {"FILLED", "CLOSED"}:
            return ("The tested trade has already filled. If you are not in it, skip it: a late entry is not the "
                    "tested trade.")
        if "CANCELLED" in also:
            return "This order is already cancelled: nothing to place."
        return ("Still unfilled on the prices so far: place it now, unless the bid is already at or above the entry. "
                "Then skip it: the tested rule sells at market only in the first minute after the order arms.")
    if kind == "FILLED":
        return "If you are not in this trade, skip it: never chase a fill."
    if kind == "CANCELLED":
        return ("Delete the order now if it is still open. If it filled at your broker after the cancel time, that "
                "trade is outside the plan: close it.")
    if kind == "CLOSE_SOON":
        return "Close it now at market if it is still open."
    if kind == "CLOSED":
        return "Check the position is closed at your broker; if not, close it now."
    if kind == "RESIZE":
        return "If the order has filled meanwhile, leave it as it is."
    return ""


def late_span(lag_s: int) -> str:
    """How late, readable on a phone: minutes under 90 minutes, then hours, then days (from 48 hours)."""
    if lag_s < 90 * 60:
        return f"{lag_s // 60} min"
    if lag_s < 48 * 3600:
        return f"about {round(lag_s / 3600)} hours"
    return f"about {round(lag_s / 86400)} days"


def event_ts(a: dict) -> int:
    """When the event itself happened, as the alert's own lines give it: a fill, cancel, close reminder or end
    (facts t), an order (its arm); else (an update, a guard skip or resize, a data gap) the M5 close that saw it."""
    f = a.get("facts") or {}
    if a["kind"] != "UPDATE":
        for k in ("t", "arm"):
            if f.get(k) is not None:
                return int(f[k])
    return int(a["at"])


def _wrap(a: dict, kind: str, title: str, lines: list[str], wall: datetime, late_after_s: int, also: set,
          key: str | None = None) -> Alert:
    now = int(wall.timestamp())
    if now - int(a["at"]) > late_after_s:          # late: counted from the M5 close at which the check could tell it
        ev = event_ts(a)                           # said in the event's own time (verify2): one clock in the alert
        title = f"Late: {title}"
        advice = late_advice(a["kind"], also)
        lines = [f"Late by {late_span(now - ev)}: this happened at {since_words(ev, now)} "
                 f"({mel(ev, date.fromisoformat(a['date']))})."
                 + (f" {advice}" if advice else "")] + lines
    return Alert(key or f"aplus:{a['id']}", kind, PRIORITY[kind], title, "\n".join(lines))


# ---------------------------------------------------------------- one alert per pinned-code alert


def order_lines(cfg, a: dict, ctx: dict) -> list[str]:
    f = a["facts"]
    d = date.fromisoformat(a["date"])
    e, s, t = int(f["entry"]), int(f["stop"]), int(f["target"])
    book = ctx.get("book") or {}
    size = str(f.get("size") or book.get("size") or "1")
    part = "" if size == "1" else (" at 1/2 of a full trade" if size == "1/2" else f" at {size} of a full trade")
    d0 = (((ctx.get("state") or {}).get("order")) or {}).get("d0")
    lines = [f"Sell limit {px(e)} · stop {px(s)} ({stop_words(e, s, d0)}) · target {px(t)} (3R, {pips(e - t)} pips)",
             f"Armed {london(f['arm'])} ({mel(f['arm'], d)})."]
    lots = lots_text(f.get("lots"))
    if cfg.account.currency != "USD":
        lines.append(f"Size not shown: the pinned sizing is for a USD account. Size your own from the {pips(s - e)}-pip"
                     " stop.")
    elif lots is not None:
        full = book.get("full_usd")
        lines.append(f"Paper size {lots} lots{part} (1 full = {cfg.risk.risk_pct_per_trade:.2f}% of the "
                     f"{cfg.paper.balance:,.0f} USD paper balance" + (f" = ${float(_frac(full)):,.2f}" if full else "")
                     + f"). Size your own account from the {pips(s - e)}-pip stop.")
    else:
        why = ((book.get("plan") or {}).get("why") or book.get("why") or "no size").rstrip(".")
        lines.append(f"Paper size: none ({why}). Size your own account from the {pips(s - e)}-pip stop.")
    lines += [f"Cancel if not filled by 11:00 London ({mel(cancel_ts(d), d)}), or at once if price reaches the target "
              "first.",
              f"If still open, close at 17:00 New York ({mel(close_ts(d), d)}).",
              "If the bid is already at or above the entry, sell at market; the fill alert then gives the new stop and"
              " target."]
    guard = guard_words(book)
    if guard:
        lines.append(f"Guard: {guard}.")
    if ctx.get("day_rule"):
        lines.append(f"Your day rules: {ctx['day_rule']}.")
    lines.append("From OANDA practice prices: check them on your chart. Tested: fixed stop, 3R, out 17:00 New York.")
    lines.append(record.record_line())
    return lines


def _frac(x):
    from fractions import Fraction
    return Fraction(str(x))


def guard_words(book: dict) -> str:
    """The BK3 decision in words: 'placed, full size', 'placed at 1/2 (both pairs ...)', 'not placed (...)'."""
    if not book:
        return ""
    if book.get("action") == "PLACE":
        size = str(book.get("size") or "1")
        head = "placed, full size" if size == "1" else f"placed at {size} of a full trade"
        return head + (f" ({book['rule']})" if book.get("rule") else "")
    return f"not placed ({book.get('rule') or book.get('action', '').lower()})"


def guard_short(rule: str) -> str:
    low = (rule or "").lower()
    for needle, word in GUARD_SHORT:
        if needle in low:
            return word
    return "guard"


def build(cfg, a: dict, ctx: dict, wall: datetime, late_after_s: int, also: set = frozenset()) -> Alert:
    """The phone alert for one pinned-code alert a (id, at, pair, date, kind, facts). ctx: the pair-day's state and
    book from the child, and the owner's day-rule words when his day guard is not open."""
    kind = KIND_MAP[a["kind"]]
    f, p = a["facts"] or {}, pair_name(a["pair"])
    d = date.fromisoformat(a["date"])
    order = (ctx.get("state") or {}).get("order") or {}
    if a["kind"] == "ORDER":
        return _wrap(a, kind, f"A+ sell limit {p} {px(f['entry'])} (paper)", order_lines(cfg, a, ctx), wall,
                     late_after_s, also)
    if a["kind"] == "FILLED":
        e, s, t = int(f["entry"]), int(f["stop"]), int(f["target"])
        fill_d = (((ctx.get("state") or {}).get("fill")) or {}).get("d")
        lines = [f"Filled {london(f['t'])} ({mel(f['t'], d)}){', at market' if f.get('market') else ''}.",
                 f"Stop {px(s)} ({stop_words(e, s, fill_d)}) · target {px(t)}."]
        if f.get("market"):
            lines.append(f"Market fill: move the stop to {px(s)} and the target to {px(t)}.")
        lots = lots_text(f.get("lots"))
        if lots is not None and cfg.account.currency == "USD":
            lines.append(f"Paper size {lots} lots.")
        lines += [f"Close at 17:00 New York ({mel(close_ts(d), d)}) if neither is hit.", END]
        return _wrap(a, kind, f"A+ filled: {p} short {px(e)} (paper)", lines, wall, late_after_s, also)
    if a["kind"] == "CANCELLED":
        entry = _order_entry(order, ctx)
        why = CANCEL_WHY.get(f.get("kind"), f.get("kind") or "cancelled")
        when = (f"({mel(f['t'], d)})" if f.get("kind") == "EXPIRED"          # "not filled by 11:00 London" says when
                else f"({london(f['t'])}, {mel(f['t'], d)})")
        lines = [f"The sell limit of {day_word(d)}: {why} {when}. Delete the order if it is still open."]
        if f.get("kind") == "CANCEL_FILLBAR":
            lines.append(f"If it filled at your broker, that trade is outside the plan: leave its stop and target and "
                         f"close it at 17:00 New York ({mel(close_ts(d), d)}) if neither has hit.")
        lines.append(END)
        return _wrap(a, kind, f"A+ cancel: {p} sell limit {entry} (paper)", lines, wall, late_after_s, also)
    if a["kind"] == "CLOSE_SOON":
        lots = lots_text(((ctx.get("book") or {}).get("fill_lots")))
        size = f" ({lots} lots)" if lots and cfg.account.currency == "USD" else ""
        lines = [f"The {p} short of {day_word(d)}{size} is still open. Close it at market at 17:00 New York "
                 f"({mel(close_ts(d), d)}), in 5 minutes, if the stop or target has not closed it first.", END]
        return _wrap(a, kind, f"A+ close at 17:00 New York: {p} short (paper)", lines, wall, late_after_s, also)
    if a["kind"] == "CLOSED":
        end = (ctx.get("state") or {}).get("end") or {}
        r20 = end.get("R_20_float")
        own = f"{f.get('R')}R after your costs"
        head = own if r20 is None else f"{r20:+.2f}R after 2.0 pips"           # the record line's pass case first
        res = own if r20 is None else f"{head} ({own})"
        if f.get("kind") == "TIME":
            lines = [f"The 17:00 New York time exit ({mel(f['t'], d)}): close the {p} short of {day_word(d)} at market "
                     "now if your stop or target has not closed it.",
                     f"Tested result about {res}, for information only.", END]
            title = f"A+ close now at market: {p} short (paper)"
        else:
            word = {"TARGET": "target hit (3R)", "STOP": "stopped out"}.get(f.get("kind"), f.get("kind") or "closed")
            lines = [f"The {p} short of {day_word(d)}: {word}, {london(f['t'])} ({mel(f['t'], d)}).",
                     f"Result {res}.", END]
            title = f"A+ closed: {p} {head} (paper)"
        return _wrap(a, kind, title, lines, wall, late_after_s, also)
    if a["kind"] == "SKIPPED":
        what = "blocked" if f.get("action") == "BLOCK" else "skipped"
        lines = [f"The A+ order of {day_word(d)} on {p} came, but the guard {what} it ({f.get('rule')}). Nothing to "
                 "place.", END]
        return _wrap(a, kind, f"A+ not placed: {guard_short(f.get('rule'))} (paper)", lines, wall, late_after_s, also)
    if a["kind"] == "RESIZE":
        lots = lots_text(f.get("lots"))
        lines = [f"Guard rule 2: the {p} sell limit of {day_word(d)} is now {f.get('size')} of a full trade"
                 + (f", {lots} lots" if lots and cfg.account.currency == "USD" else "")
                 + ". If it has already filled at your broker, leave it as it is.", END]
        return _wrap(a, kind, f"A+ update: {p} order of {day_word(d)} (paper)", lines, wall, late_after_s, also)
    if a["kind"] == "GAP_WARNING":
        lines = [f"The price feed has a gap of more than 16 minutes after the {p} order of {day_word(d)} armed (the "
                 "tested rule would have skipped this day). The order stays; check your chart.", END]
        return _wrap(a, kind, f"A+ data gap: {p} (paper)", lines, wall, late_after_s, also)
    # NO_TRADE_GAP
    lines = [f"No A+ trade on {p} on {day_word(d)}: the price feed has a gap of more than 16 minutes between 00:00 "
             f"London and {london(a['at'])} (the tested rule skips such a day).", END]
    return _wrap(a, kind, f"A+ data gap: {p} (paper)", lines, wall, late_after_s, also)


def _order_entry(order: dict, ctx: dict) -> str:
    plan = (ctx.get("book") or {}).get("plan") or {}
    if plan.get("entry") is not None:
        return px(plan["entry"])
    return "order"


# ---------------------------------------------------------------- corrections


def _fact(k: str, v) -> str:
    if v is None:
        return "none"
    if k in ("entry", "stop", "target"):
        return px(v)
    if k in ("t", "arm"):
        return london(v)
    if k == "lots":
        return lots_text(v) or "none"
    return str(v)


def changes(old: dict, new: dict) -> list[str]:
    keys = sorted(set(old) | set(new))
    return [f"{k} {_fact(k, old.get(k))} -> {_fact(k, new.get(k))}" for k in keys if old.get(k) != new.get(k)]


def update(cfg, a: dict, n: int, why: str, now_alert: Alert | None, at: int, wall: datetime,
           late_after_s: int) -> Alert:
    """aplus_update for a sent alert whose facts changed, that holds again (now_alert: what it reads now) or that no
    longer holds (now_alert None). Key aplus:UPDATE:<id>:<n>."""
    d = date.fromisoformat(a["date"])
    p = pair_name(a["pair"])
    head = f"The {WHAT.get(a['kind'], 'alert')} alert for {p} of {day_word(d)}"
    if now_alert is None:
        what = ("If you placed that order and it has not filled, cancel it. If it filled, keep its stop and target and "
                "close it by 17:00 New York." if a["kind"] == "ORDER" else "Check your chart and your broker.")
        lines = [f"{head} no longer holds on the rebuilt prices. {what}", END]
    else:
        lines = [f"{head}: {why}. It now reads:", now_alert.title, now_alert.body]
        if not now_alert.body.endswith(END):
            lines.append(END)
    stamp = dict(a, at=at, kind="UPDATE")
    title = f"A+ update: {p} {WHAT.get(a['kind'], 'alert')} of {day_word(d)} (paper)"
    return _wrap(stamp, "aplus_update", title, lines, wall, late_after_s, set(), key=f"aplus:UPDATE:{a['id']}:{n}")


# ---------------------------------------------------------------- data and silence


def data_stale(day: date, marker: int, wall: datetime) -> Alert:
    behind = max(0, int(wall.timestamp()) - int(marker)) // 60
    return Alert(f"aplus_data_stale:{day.isoformat()}:{int(marker)}", "aplus_data_stale", PRIORITY["aplus_data_stale"],
                 f"A+ prices stale since {london(marker)}",
                 f"Prices to {london(marker)} ({mel(marker)}), {behind} min behind. New A+ orders, fills and exits "
                 "after then are not checked until the price feed recovers. Check your chart.")


def data_back(day: date, since: int, marker: int) -> Alert:
    return Alert(f"aplus_data_back:{day.isoformat()}:{int(since)}", "aplus_data_back", PRIORITY["aplus_data_back"],
                 "A+ prices back", f"The price feed is up to date again (prices to {london(marker)}, {mel(marker)}).")


def silent(day: date, last: int | None, now: datetime, unit: str = "edge-desk-method") -> Alert:
    """serve's monitor: no A+ step heartbeat for 15 min in the window. unit: unit_of(cfg)."""
    if last is None:
        return Alert(f"aplus_silent:{day.isoformat()}:never", "aplus_silent", PRIORITY["aplus_silent"],
                     "A+ check not running",
                     f"No A+ check has run yet while the price feed is on. Check the {unit} service on the server.")
    mins = max(1, (int(now.timestamp()) - int(last)) // 60)
    return Alert(f"aplus_silent:{day.isoformat()}:{int(last)}", "aplus_silent", PRIORITY["aplus_silent"],
                 "A+ check not running",
                 f"No A+ check for {mins} min (last {london(last)}, {mel(last)}) while the price feed is on. New A+ "
                 f"orders, fills and exits are not checked. Check the {unit} service on the server.")


def failing(since: int, n: int, status: str, detail: str, unit: str = "edge-desk-method",
            at: int | None = None) -> Alert:
    """The check itself fails (design D13): once a stall, keyed by when the stall began. unit: unit_of(cfg); at: when
    it is sent (the stall's first day is named when it is not that day)."""
    what = "refused to run" if status == "refused" else "failed"
    why = " ".join((detail or "").split())[:160]
    return Alert(f"aplus_failing:{int(since)}", "aplus_failing", PRIORITY["aplus_failing"], "A+ check failing",
                 f"The A+ check {what} {n} times in a row since {since_words(since, at)} ({mel_of(since)}): {why}. New "
                 f"A+ orders, fills and exits are not checked until it runs again. Check the {unit} service on the "
                 f"server (deploy/check.py report).\n{END}")


def check_back(since: int, n: int, at: int) -> Alert:
    return Alert(f"aplus_check_back:{int(since)}", "aplus_check_back", PRIORITY["aplus_check_back"],
                 "A+ check running again",
                 f"The A+ check ran at {london(at)} ({mel_of(at)}) after {n} failed runs since "
                 f"{since_words(since, at)}. Alerts it missed in the meantime come now if they still matter.\n{END}")


__all__ = ["KINDS", "KIND_MAP", "PRIORITY", "ORDER_TTL_S", "build", "update", "changes", "data_stale", "data_back",
           "silent", "failing", "check_back", "order_still_valid", "order_expires_ts", "unit_of", "stop_words",
           "rule_pips", "late_span", "since_words", "event_ts"]
