"""Plain alert texts, one per event: new order, filled, cancelled, close soon, closed (plus resized and skipped by the
guard, data warnings and updates). `delivered()` adds the send time, and what to do when an alert comes late.

Prices: the rule's prices are exact K1 units (price x 400,000), and can fall between broker points. The alert gives
5-decimal broker prices: the sell-limit entry to the nearest point (a tie goes up), the stop and the target rounded
up (the stop is never tighter than the rule, the target never further). Lots come from the broker stop distance.
Times: London and Melbourne, through zoneinfo, so each place's own daylight-saving dates apply.
"""
import datetime as dt
from fractions import Fraction
import math
from zoneinfo import ZoneInfo

import sizing as SZ

LON = ZoneInfo('Europe/London')
NYZ = ZoneInfo('America/New_York')
MEL = ZoneInfo('Australia/Melbourne')
UNITS_PER_POINT = 4            # K1: 1 point = 0.00001 = 4 units; 1 pip = 10 points = 40 units


def pair_name(pair):
    return pair.replace('_', '/')


def _points(units):
    return Fraction(units) / UNITS_PER_POINT


def round_entry(units):
    """nearest whole point, a tie goes up (a sell limit a hair higher fills a hair later)"""
    p = _points(units)
    return math.floor(p + Fraction(1, 2))


def round_up(units):
    return math.ceil(_points(units))


def price_text(points):
    return '%d.%05d' % (points // 100000, points % 100000)


def broker_plan(pair, E, S, T, risk_usd, no_size=None):
    """Broker prices (points), stop and target distances (pips) and lots for risk_usd. lots is None with a reason
    when the size would be under 0.01 lots, or when risk_usd is None (no_size gives the reason)."""
    e, s, t = round_entry(E), round_up(S), round_up(T)
    stop_pips = Fraction(s - e, 10)
    tgt_pips = Fraction(e - t, 10)
    if risk_usd is None:
        lots, why = None, no_size or 'no size'
    else:
        try:
            lots, why = SZ.lots(pair, risk_usd, stop_pips), None
        except SZ.SizeError as err:
            lots, why = None, str(err)
    return dict(entry=e, stop=s, target=t, stop_pips=stop_pips, target_pips=tgt_pips, lots=lots, why=why)


def when(ts, tz):
    return dt.datetime.fromtimestamp(int(ts), tz)


def london_hm(ts):
    return when(ts, LON).strftime('%H:%M')


def clock_pair(ts):
    """'11:00 London = 22:00 Melbourne (Tue 27 Oct)' for unix time ts"""
    lo, me = when(ts, LON), when(ts, MEL)
    return '%s London = %s Melbourne (%s)' % (lo.strftime('%H:%M'), me.strftime('%H:%M'), me.strftime('%a %d %b'))


def cancel_ts(D):
    return int(dt.datetime(D.year, D.month, D.day, 11, 0, tzinfo=LON).timestamp())


def close_ts(D):
    return int(dt.datetime(D.year, D.month, D.day, 17, 0, tzinfo=NYZ).timestamp())


def _size_line(pair, plan, risk_usd, size, balance, risk_pct, D):
    part = '' if size == 1 else ', %s of a full trade' % ('1/2' if size == Fraction(1, 2) else str(size))
    if plan['lots'] is None and risk_usd is None:
        return 'Size: NOT SET. %s.' % plan['why']
    base = '1 full = %s%% of $%s, the opening balance recorded for %s%s' % (
        SZ.fmt_pips(risk_pct), SZ.fmt_usd(balance), D.strftime('%a %d %b'), part)
    if plan['lots'] is None:
        return 'Size: NONE. %s. Risk would be $%s (%s).' % (plan['why'], SZ.fmt_usd(risk_usd), base)
    at_risk = SZ.money_at_risk(pair, plan['lots'], plan['stop_pips'])
    return ('Size %s lots = $%s at risk (%s); commission about $%s.'
            % (SZ.fmt_lots(plan['lots']), SZ.fmt_usd(at_risk), base, SZ.fmt_usd(plan['lots'] * SZ.COMMISSION_PER_LOT)))


def new_order(pair, D, E, S, T, size, full_usd, balance, risk_pct, note=None, arm_ts=None, no_size=None):
    """full_usd None: no size (no_size says why: no balance recorded for D, or guard rule 7)."""
    risk = None if full_usd is None else Fraction(size) * full_usd
    plan = broker_plan(pair, E, S, T, risk, no_size)
    lines = [
        'NEW ORDER %s SELL LIMIT (A+ short, v3), London day %s' % (pair_name(pair), D.strftime('%a %d %b %Y')),
        'Entry %s  Stop %s (%s pips)  Target %s (3R, %s pips)'
        % (price_text(plan['entry']), price_text(plan['stop']), SZ.fmt_pips(plan['stop_pips']),
           price_text(plan['target']), SZ.fmt_pips(plan['target_pips'])),
        _size_line(pair, plan, risk, size, balance, risk_pct, D),
        'Cancel if not filled by %s, or at once if price reaches the target first.' % clock_pair(cancel_ts(D)),
        'If still open, close at 17:00 New York = %s.' % clock_pair(close_ts(D)),
        'If the bid is already at or above the entry, sell at market; the bot then sends the new stop and target.',
    ]
    if arm_ts is not None:
        lines.insert(1, 'Armed at %s (the order bar closed then).' % clock_pair(arm_ts))
    if note:
        lines.insert(1, 'Guard: %s.' % note)
    return '\n'.join(lines), plan


def filled(pair, D, fill_ts, F, S, T, market, lots):
    e, s, t = round_entry(F), round_up(S), round_up(T)
    how = 'at market (price was already above the entry)' if market else 'limit filled'
    lines = ['FILLED %s SHORT %s at %s, %s' % (pair_name(pair), how, price_text(e), clock_pair(fill_ts)),
             'Stop %s (%s pips)  Target %s.' % (price_text(s), SZ.fmt_pips(Fraction(s - e, 10)), price_text(t))]
    if lots is not None:
        lines.append('Size %s lots.' % SZ.fmt_lots(lots))
    if market:
        lines.append('Market fill: move the stop to %s and the target to %s.' % (price_text(s), price_text(t)))
    lines.append('Close at 17:00 New York = %s if neither is hit.' % clock_pair(close_ts(D)))
    return '\n'.join(lines)


CANCEL_WHY = {'EXPIRED': 'not filled by 11:00 London',
              'CANCEL_TARGET': 'price reached the target before the entry',
              'CANCEL_FILLBAR': 'the fill minute also reached the target, so the research does not count this trade'}


def cancelled(pair, D, kind, ts):
    head = 'CANCEL %s sell limit of %s: %s (%s). Delete the order if it is still open.' % (
        pair_name(pair), D.strftime('%a %d %b'), CANCEL_WHY.get(kind, kind), clock_pair(ts))
    if kind == 'CANCEL_FILLBAR':
        head += ('\nIf it filled at your broker, that trade is outside the plan: leave its stop and target as they '
                 'are and close it at 17:00 New York = %s if neither has hit.' % clock_pair(close_ts(D)))
    return head


EXIT_WHY = {'STOP': 'stopped out', 'TARGET': 'target hit (3R)'}


def close_soon(pair, D, ts, lots=None):
    """Sent at the 16:55 New York step for a trade that is still open: the time exit is the one exit done by hand."""
    size = ' (%s lots)' % SZ.fmt_lots(lots) if lots is not None else ''
    return ('CLOSE AT 17:00 NEW YORK: %s short of %s%s is still open. Close it at market at 17:00 New York = %s, '
            'in 5 minutes, if the stop or target has not closed it first.'
            % (pair_name(pair), D.strftime('%a %d %b'), size, clock_pair(close_ts(D))))


def closed(pair, D, kind, ts, R, lots, stop_pips):
    if kind == 'TIME':
        first = ('CLOSE NOW %s short of %s at market: the 17:00 New York time exit (%s). Do it now if your stop or '
                 'target has not closed it.' % (pair_name(pair), D.strftime('%a %d %b'), clock_pair(ts)))
        info = 'For information only: '
    else:
        first = 'CLOSED %s short of %s: %s, %s.' % (pair_name(pair), D.strftime('%a %d %b'), EXIT_WHY.get(kind, kind),
                                                  clock_pair(ts))
        info = ''
    lines = [first, '%sresult about %+.2f R after owner costs (0.1 pip spread each side, $5 a lot, 0.5 pip on stops).'
             % (info, float(R))]
    if not info:
        lines[1] = lines[1][0].upper() + lines[1][1:]
    if lots is not None:
        usd = Fraction(R) * lots * stop_pips * SZ.USD_PER_PIP_PER_LOT[pair]
        lines.append('About %s$%s on %s lots (estimate; your broker statement is the truth).'
                     % ('+' if usd >= 0 else '-', SZ.fmt_usd(abs(usd)), SZ.fmt_lots(lots)))
    return '\n'.join(lines)


def resized(pair, D, old_lots, new_lots, why):
    def lt(x):
        return SZ.fmt_lots(x) if x is not None else 'not set'
    return ('RESIZE %s sell limit of %s: %s -> %s lots (%s). If it has already filled at your broker, leave it as '
            'it is.' % (pair_name(pair), D.strftime('%a %d %b'), lt(old_lots), lt(new_lots), why))


def skipped(pair, D, action, rule):
    return 'NO ORDER %s on %s: the A+ signal came, but the guard %s it (%s).' % (
        pair_name(pair), D.strftime('%a %d %b'), 'blocked' if action == 'BLOCK' else 'skipped', rule)


def gap_day(pair, D, ts):
    return ('NO TRADE %s on %s: the price feed has a gap of more than 16 minutes between 00:00 London and %s London '
            '(the research skips such a day).' % (pair_name(pair), D.strftime('%a %d %b'), london_hm(ts)))


# ---------------------------------------------------------------- delivery: send time and late handling
LATE_AFTER_S = 300          # an alert sent more than 5 minutes after its stamp means at least one run was missed


def late_advice(kind, also):
    """What to do with an alert that comes late. also: the other alert kinds of the same pair-day in this batch."""
    if kind == 'ORDER':
        if 'FILLED' in also or 'CLOSED' in also:
            return ('The research trade has already filled (see below). If you are not in it, skip it: a late entry '
                    'is not the tested trade.')
        if 'CANCELLED' in also:
            return 'This order has already been cancelled (see below): nothing to place.'
        return ('Still unfilled on the data so far: place it now. If the bid is already at or above the entry, skip '
                'it: the research sells at market only in the first minute after the order arms.')
    if kind == 'FILLED':
        return 'If you are not in this trade, skip it: a late entry is not the tested trade.'
    if kind == 'CANCELLED':
        return ('Delete the order now if it is still open. If it filled at your broker after the cancel time, that '
                'trade is outside the plan: close it.')
    if kind == 'CLOSE_SOON':
        return 'Close it now at market if it is still open.'
    if kind == 'CLOSED':
        return 'Check that the position is closed at your broker; if not, close it now.'
    if kind == 'RESIZE':
        return 'If the order has filled meanwhile, leave it as it is.'
    return ''


def delivered(a, wall, today_iso, also=()):
    """The alert text as sent: a first line with the send time (and how late it is), then the alert, then what to
    do if it is late. a: the alert dict (kind, date, at = the M5 close the bot stamped it with)."""
    late = int(wall) - int(a['at'])
    head = 'Sent %s' % clock_pair(wall)
    tail = ''
    if a['date'] < today_iso:
        head += '. FROM AN EARLIER DAY (%s): for the record; check that nothing from it is still open.' % a['date']
    elif late > LATE_AFTER_S:
        head += '. LATE by %d min: the bot saw this at %s London.' % (late // 60, london_hm(a['at']))
        tail = late_advice(a['kind'], also)
    return head + '\n' + a['text'] + ('\n' + 'LATE: ' + tail if tail else '')
