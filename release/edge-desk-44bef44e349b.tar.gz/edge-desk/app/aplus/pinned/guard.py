"""BK3, the money-book guard (sandbox/work/short_book/PLAN.md section N3), as a causal event processor.

Sizes are in "full" units (1 full = the $ risk of one A+ trade, see sizing.full_risk_usd). Every book trade is long
the US dollar (a short of EUR/USD or GBP/USD), as PLAN N3 says. Checks run when an order is placed (its arm time T), in the order the research book
used (book/book.py run_book), with only what is known at T:

  5. weekly brake: the week's closed net (exits in [Monday 00:00 London, Friday 17:00 New York]) <= -2.0 full:
     no new order until Monday;
  4. day stop: the London day's closed net <= -1.5 full, or 2 losing A+ trades closed that day: no new order that day;
  3. at most one open short per pair;
  2. A+ on both pairs (causal): the day's first A+ order is placed at full size; if the other pair arms an A+ order
     later that day: skipped if the first has filled by then, otherwise placed at 1/2 and the first resized to 1/2
     (a filled trade is never resized; a first order already cancelled by then is not resized either, as it no
     longer exists);
  1. dollar cap: open risk (size of open trades, whose stops never move, plus every live order counted as filled,
     the first of rule 2 already at 1/2) + the new order <= 1.5 full, else the order is not placed.

Rule 6 (size from the London-day opening balance, never larger after a loss) is in sizing.full_risk_usd and the
per-day balance record of live.py. Rule 7 (1.5 full at most half the funded firm's daily loss limit) is
check_firm_limit(), enforced by live.py (--firm-daily-loss-usd). Rule 8: the thresholds are fixed here and only ever
tightened.

Reading kept from the research book (RESULT.md readings, item 4): rule 2 halves the second order whenever the first
has not filled, even if the first was already cancelled. On a tie of arm times EUR/USD counts as first (the caller
feeds EUR/USD first).
"""
import datetime as dt
from fractions import Fraction

from vendored import DA

CAP = Fraction(3, 2)
DAY_STOP = Fraction(-3, 2)
DAY_LOSSES = 2
WEEK_BRAKE = Fraction(-2)
FULL = Fraction(1)
HALF = Fraction(1, 2)


def week_window(D):
    """[Monday 00:00 London, Friday 17:00 New York] of the week holding London date D (unix seconds)."""
    mon = D - dt.timedelta(days=D.weekday())
    return DA.lon(mon, 0), DA.nyt(mon + dt.timedelta(days=4), 17)


def check_firm_limit(daily_loss_limit_usd, full_usd):
    """N3 rule 7: 1.5 full must be at most half the firm's daily loss limit."""
    return CAP * Fraction(full_usd) <= Fraction(daily_loss_limit_usd) / 2


class Guard:
    def __init__(self, on=True):
        self.on = on
        self.orders = {}          # key (pair, date iso) -> placed order: pair, date, arm, size, fill, end, exit, R
        self.trips = {'brake_block': [], 'day_stop_block': [], 'rule3_skip': [], 'rule2_skip': [],
                      'rule2_half': [], 'cap_block': []}

    # -------------------------------------------------------------- state as known at time T
    def _closed(self, T):
        return [o for o in self.orders.values() if o['exit'] is not None and o['exit'] <= T]

    def _open_trades(self, T):
        return [o for o in self.orders.values()
                if o['fill'] is not None and o['fill'] <= T and (o['exit'] is None or T < o['exit'])]

    def _live_orders(self, T):
        return [o for o in self.orders.values()
                if o['arm'] <= T and (o['fill'] is None or o['fill'] > T) and (o['end'] is None or o['end'] > T)]

    # -------------------------------------------------------------- events
    def on_order(self, pair, D, T):
        """A new A+ order armed at T on London date D. Returns dict(action PLACE|SKIP|BLOCK, rule, size,
        resize=[(key, old size, new size)])."""
        key = (pair, D.isoformat())
        assert key not in self.orders, key
        if not self.on:
            self.orders[key] = dict(pair=pair, date=D, arm=T, size=FULL, fill=None, end=None, exit=None, R=None)
            return dict(action='PLACE', rule=None, size=FULL, resize=[])
        tag = (pair, D.isoformat())
        closed = self._closed(T)
        w0, w1 = week_window(D)
        wnet = sum((o['size'] * o['R'] for o in closed if w0 <= o['exit'] <= w1), Fraction(0))
        if wnet <= WEEK_BRAKE:
            self.trips['brake_block'].append(tag)
            return dict(action='BLOCK', rule='weekly brake (rule 5): week closed net %.2f full' % float(wnet),
                        size=Fraction(0), resize=[])
        today = [o for o in closed if o['date'] == D]
        dnet = sum((o['size'] * o['R'] for o in today), Fraction(0))
        nloss = sum(1 for o in today if o['R'] < 0)
        if dnet <= DAY_STOP or nloss >= DAY_LOSSES:
            self.trips['day_stop_block'].append(tag)
            return dict(action='BLOCK', rule='day stop (rule 4): day closed net %.2f full, %d losses'
                        % (float(dnet), nloss), size=Fraction(0), resize=[])
        if any(o['pair'] == pair for o in self._open_trades(T)):
            self.trips['rule3_skip'].append(tag)
            return dict(action='SKIP', rule='one open short per pair (rule 3)', size=Fraction(0), resize=[])
        size, first, note = FULL, None, None
        others = sorted((o for o in self.orders.values() if o['date'] == D and o['pair'] != pair),
                        key=lambda o: o['arm'])
        if others:
            first = others[0]
            if first['fill'] is not None and first['fill'] <= T:
                self.trips['rule2_skip'].append(tag)
                return dict(action='SKIP', rule='both pairs (rule 2): the %s short already filled today'
                            % first['pair'].replace('_', '/'), size=Fraction(0), resize=[])
            size = HALF * size
            note = 'both pairs (rule 2): %s order not filled yet, both at 1/2' % first['pair'].replace('_', '/')
        live = sum((o['size'] for o in self._open_trades(T)), Fraction(0))
        live += sum(((o['size'] * HALF if o is first else o['size']) for o in self._live_orders(T)), Fraction(0))
        if live + size > CAP:
            self.trips['cap_block'].append(tag)
            return dict(action='BLOCK', rule='dollar cap (rule 1): open risk %.2f + %.2f > 1.5 full'
                        % (float(live), float(size)), size=Fraction(0), resize=[])
        resize = []
        if first is not None:
            first_gone = first['end'] is not None and first['end'] <= T
            if first['size'] > HALF * FULL and not first_gone:
                old = first['size']
                first['size'] = HALF * old
                resize.append(((first['pair'], first['date'].isoformat()), old, first['size']))
            self.trips['rule2_half'].append(tag)
        self.orders[key] = dict(pair=pair, date=D, arm=T, size=size, fill=None, end=None, exit=None, R=None)
        return dict(action='PLACE', rule=note, size=size, resize=resize)

    def placed(self, key):
        return key in self.orders

    def size(self, key):
        return self.orders[key]['size']

    def on_fill(self, key, t):
        if key in self.orders:
            self.orders[key]['fill'] = t

    def on_cancel(self, key, t):
        if key in self.orders:
            self.orders[key]['end'] = t

    def on_close(self, key, t, R):
        if key in self.orders:
            o = self.orders[key]
            o['exit'], o['R'] = t, Fraction(R)

    def trades(self):
        """placed orders that filled: (key, size, R or None)"""
        return [(k, o['size'], o['R']) for k, o in self.orders.items() if o['fill'] is not None]
