"""The live decision loop for v3-inv, the A+ short (sandbox/work/short_book/PLAN.md section 2.1 K1).

v3 = W1+H4 (marc_rules/V2X_SPEC.md amendment A1: RULES_v1 base + W1 wick-only sweep + W3 daily bias + A1 4h bias on
UTC 4h bars), SELLS ONLY, EUR/USD and GBP/USD; skip a natural stop d0 <= 8.0 pips (320 K1 units) or d0 > ADR20/3;
sell limit at the FVG middle, else the OB; stop 1 pip above the sweep high; target 3R; cancel unfilled at 11:00 London
or if the target trades first; exit at 17:00 New York.

Nothing of the signal is re-implemented here. At each M5 close `now` the unchanged research engine (vendor/, checked
by sha256) runs the w1h4 rule for the current London day on the M1 bars that opened before `now` (cut at 11:00 London,
after which the rule can no longer change), and the research order path (outcomes.order_path) runs the order on the
bars so far, with the owner-cost quotes (mid +/- 0.1 pip) by default.

    evaluate(pdat, pair, D, now)  -> the pair-day state at now (pure: the same inputs always give the same state)
    Runner                        -> steps every M5 close, turns state changes into events, applies the BK3 guard
                                     (guard.py) and sizing (sizing.py), and writes one alert per event (alert.py)

Command line (needs the OANDA feed; NOT run in this build, which makes one connectivity check only):
    python3 -I -B live.py balance 25700                                  each London day, before 07:00 London
    python3 -I -B live.py run --risk-pct 0.65 --firm-daily-loss-usd <the firm's daily loss limit in USD>
"""
import argparse
import datetime as dt
import fcntl
import json
import os
import sys
import tempfile
import time
from fractions import Fraction

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import numpy as np  # noqa: E402

from vendored import EN, DA, OC  # noqa: E402
import alert as AL  # noqa: E402
import guard as GD  # noqa: E402
import sizing as SZ  # noqa: E402

PAIRS = ('EUR_USD', 'GBP_USD')
RULE = EN.RULE_BY_NAME['w1h4']
V3_D0_MIN = EN.FLOOR                 # v3 skips d0 <= 320 units (8.0 pips); the 8-pip floor then never applies
WINDOW_DAYS = 60                     # the K14-verified window: 00:00 London 60 days before D
OWNER_COSTS = dict(comm=20, stop_slip=20, mkt_entry=0, time_exit=0, stress=False)   # 0.5 pip commission, 0.5 pip slip
OWNER_HALF_SPREAD = 4                # 0.1 pip (K1 units)
FINAL_AT_DECISION = ('ARMED', 'VOID', 'NO_ZONE', 'S5', 'H_FILTER', 'BOTH_SIDES')
FINAL_PHASES = ('NOT_ELIGIBLE', 'NO_TRADE', 'CANCELLED', 'CLOSED')
STATE_DIR = os.path.join(HERE, 'state')
STATS = {'engine_runs': 0}


class InconsistentState(RuntimeError):
    """A later evaluation contradicted an earlier one (a final decision changed). Must never happen."""


# ---------------------------------------------------------------- clocks
def clocks(D):
    return dict(L00=DA.lon(D, 0), L0705=DA.lon(D, 7, 5), Ldl=DA.lon(D, *RULE.deadline), Lexp=DA.lon(D, *RULE.expiry),
                ny_end=DA.nyt(D, 17))


def london_clock(D, t):
    """(hh, mm) of unix time t on London date D; asserts the round trip (no DST ambiguity after 07:00)"""
    lt = dt.datetime.fromtimestamp(int(t), DA.LON)
    assert lt.date() == D and DA.lon(D, lt.hour, lt.minute) == t, (D, t)
    return lt.hour, lt.minute


def gap_ok_until(pdat, D, t_end):
    """The engine's K4 gap test (data.gap_ok) over [00:00 London, t_end): gap_ok reads only .t1."""
    return DA.gap_ok(pdat, D, upto=london_clock(D, t_end))


# ---------------------------------------------------------------- quotes for the order path
def owner_quotes(q):
    """Owner-cost quotes (PLAN 'owner costs'): per field, mid -/+ 0.1 pip, built exactly as the inventory did:
    bid = (bid + ask - 8) // 2, ask = (bid + ask + 9) // 2 in K1 units."""
    out = {}
    for f in 'ohlc':
        m2 = q['bid_' + f] + q['ask_' + f]
        out['bid_' + f] = (m2 - 2 * OWNER_HALF_SPREAD) // 2
        out['ask_' + f] = (m2 + 2 * OWNER_HALF_SPREAD + 1) // 2
    return out


def quote_slice(pdat, j0, j1, model):
    q = {k: pdat.u[k][j0:j1] for k in DA.QFIELDS}
    if model == 'owner':
        return owner_quotes(q)
    if model == 'feed':
        return q
    raise ValueError(model)


# ---------------------------------------------------------------- the engine stage
def _engine_entry(pdat, pair, D, cut, excluded):
    """Run the vendored engine for London day D on M1 bars opening in [00:00 London D-60, cut)."""
    c = clocks(D)
    a, b = pdat.rows(DA.lon(D - dt.timedelta(days=WINDOW_DAYS), 0), cut)
    if b <= a:            # no bar at all: the gap test fails too, so the day can never be traded
        return dict(status='NO_DATA', final=True, decision=None, warm=None, row=None)
    STATS['engine_runs'] += 1
    S = pdat.series(a, b)
    table = DA.DayTable(S)
    ctx = DA.make_ctx(D, table)
    ent = dict(warm=len(table.before(D)) >= 20, blind=D in excluded, holiday=(D.month, D.day) in DA.HOLIDAY_MD,
               cut=cut, A=ctx.A)
    if not ent['warm'] or ent['blind'] or ent['holiday']:
        ent.update(status='NOT_ELIGIBLE', final=True, decision=None, row=None)
        return ent
    row = EN.eval_day(S, ctx, [RULE])[RULE.name]
    st = row['status']
    if st in FINAL_AT_DECISION:
        final, decision = True, int(row['_decision'])
        assert decision <= cut, (pair, D, st, decision, cut)
    elif st == 'NO_SIGNAL':
        final, decision = cut >= c['Ldl'], c['Ldl']
    elif st == 'NO_ORDER_BAR':
        final, decision = cut >= c['Lexp'], c['Lexp']
    else:
        raise InconsistentState('unexpected w1h4 status %s' % st)
    ent.update(status=st, final=final, decision=decision if final else None,
               row=dict(text=EN.row_values_v2x(row), side=row['side'], E=row['E'], S0=row['S0'], S=row['S'],
                        T=row['T'], d0=row['d0'], d=row['d'], live_from=row['live_from_utc'], zone=row['zone'],
                        pool=row['pool']))
    return ent


def engine_status(pdat, pair, D, cut, excluded=frozenset(), cache=None):
    """The w1h4 row of (pair, D) at cut (<= 11:00 London) with live eligibility: WARMUP, GAP, BLIND, HOLIDAY in the
    engine's order, the gap test run up to the decision time once the row is final (else up to cut). A final entry
    can be cached: it never changes (K14 truncation test)."""
    key = (pair, D.isoformat())
    ent = cache.get(key) if cache is not None else None
    if ent is None:
        ent = _engine_entry(pdat, pair, D, cut, excluded)
        if cache is not None and ent['final']:
            cache[key] = ent
    if ent['status'] == 'NO_DATA':
        return dict(ent, eligible=False, reason='NO_DATA', late_gap=False)
    gap_end = ent['decision'] if (ent['final'] and ent['decision'] is not None) else cut
    gap_end = min(gap_end, cut)
    # A permanent reason (WARMUP, BLIND, HOLIDAY, in the engine's order) is reported first, so a final reason never
    # changes later; the research reports a GAP before BLIND and HOLIDAY when a day has both (both: no trade).
    static = [r for r, bad in (('WARMUP', not ent['warm']), ('BLIND', ent['blind']), ('HOLIDAY', ent['holiday'])) if bad]
    reasons = static[:1] if static else ([] if gap_ok_until(pdat, D, gap_end) else ['GAP'])
    late_gap = (not reasons) and gap_end < cut and not gap_ok_until(pdat, D, cut)
    out = dict(ent, eligible=not reasons, reason=reasons[0] if reasons else '', late_gap=late_gap)
    if reasons:
        out['final'] = True                  # every reason is permanent (a gap never closes again)
    return out


# ---------------------------------------------------------------- the order path
def _fx(v):
    return None if v is None else EN.fmt(v)


def path_state(pdat, order, now, quotes='owner'):
    """The order on the M1 bars opening in [arm, now) through outcomes.order_path (the research path).
    Returns (phase, fill, end): phase ARMED | FILLED | CANCELLED | CLOSED."""
    j0 = int(np.searchsorted(pdat.t1, order['live_from']))
    j1 = int(np.searchsorted(pdat.t1, now))
    t1 = pdat.t1[j0:j1]
    Q = quote_slice(pdat, j0, j1, quotes)
    r = OC.order_path(t1, Q, order, OWNER_COSTS)
    if not r['filled']:
        if r['exit'] == 'EXPIRED':
            if now >= order['expiry']:
                return 'CANCELLED', None, dict(kind='EXPIRED', t=int(order['expiry']))
            return 'ARMED', None, None
        return 'CANCELLED', None, dict(kind=r['exit'], t=int(t1[r['exit_i']]))
    fill = dict(t=int(t1[r['fill_i']]), F=r['fill_px'], d=r['d'], S=r['S'], T=r['T'], market=bool(r['market']))
    kind = r['exit']
    if kind == 'TIME' and now < order['ny_end']:
        return 'FILLED', fill, None
    t_exit = int(t1[r['exit_i']]) + (60 if kind == 'TIME' else 0)
    R = OC.net_units(True, r['fill_px'], r['exit_px'], kind, r['market'], OWNER_COSTS) / r['d']
    return 'CLOSED', fill, dict(kind=kind, t=t_exit, px=Fraction(r['exit_px']), R=Fraction(R))


def evaluate(pdat, pair, D, now, excluded=frozenset(), quotes='owner', cache=None):
    """State of the v3 short for (pair, London date D) at the M5 close `now`, from M1 bars opening before now only.
    Pure: the same data, now and settings always give the same state (the cache holds only final engine rows)."""
    if now % 300:
        raise ValueError('now must be an M5 close (a multiple of 300 s)')
    c = clocks(D)
    st = dict(pair=pair, date=D.isoformat(), now=int(now), phase='WAIT', reason='', final=False, late_gap=False,
              engine=None, order=None, fill=None, end=None)
    if now < c['L0705']:
        return st
    eng = engine_status(pdat, pair, D, min(now, c['Lexp']), excluded, cache)
    if not eng['eligible']:
        st.update(phase='NOT_ELIGIBLE', reason=eng['reason'], final=True)
        return st
    st['engine'] = dict(status=eng['status'], final=eng['final'], decision=eng['decision'])
    if not eng['final']:
        st.update(phase='SCANNING', reason=eng['status'])
        return st
    row = eng['row']
    if eng['status'] != 'ARMED':
        st.update(phase='NO_TRADE', reason=eng['status'], final=True)
        return st
    if row['side'] != 'sell':
        st.update(phase='NO_TRADE', reason='BUY_SIGNAL', final=True)
        return st
    if not row['d0'] > V3_D0_MIN:
        st.update(phase='NO_TRADE', reason='STOP_8_PIPS_OR_LESS', final=True)
        return st
    assert eng['A'] is not None and 60 * row['d0'] <= eng['A'], 'S5 (d0 <= ADR20/3) must already hold'
    order = dict(side='sell', kind='limit', E=row['E'], S0=row['S0'], d=row['d'], S=row['S'], T=row['T'],
                 live_from=int(row['live_from']), expiry=c['Lexp'], ny_end=c['ny_end'], floor=EN.FLOOR)
    phase, fill, end = path_state(pdat, order, now, quotes)
    st.update(phase=phase, final=phase in FINAL_PHASES, late_gap=bool(eng['late_gap']) and phase in ('ARMED', 'FILLED'),
              order=dict(E=_fx(row['E']), S0=_fx(row['S0']), S=_fx(row['S']), T=_fx(row['T']), d0=_fx(row['d0']),
                         d=_fx(row['d']), arm=int(row['live_from']), expiry=c['Lexp'], ny_end=c['ny_end'],
                         zone=row['zone'], pool=row['pool']))
    if fill is not None:
        st['fill'] = dict(t=fill['t'], F=_fx(fill['F']), d=_fx(fill['d']), S=_fx(fill['S']), T=_fx(fill['T']),
                          market=fill['market'])
    if end is not None:
        e = dict(kind=end['kind'], t=end['t'])
        if 'R' in end:
            e.update(px=_fx(end['px']), R='%d/%d' % (end['R'].numerator, end['R'].denominator), R_float=float(end['R']))
        st['end'] = e
    return st


def without_now(st):
    return {k: v for k, v in st.items() if k != 'now'}


def diff(prev, cur):
    """Events from one state to the next, in order ORDER, FILLED, CANCELLED / CLOSED, GAP_WARNING. Raises
    InconsistentState if an earlier final fact changed."""
    if prev is not None:
        if prev['final'] and without_now(prev) != without_now(cur):
            raise InconsistentState('final state changed: %s %s' % (cur['pair'], cur['date']))
        for k in ('order', 'fill', 'end'):
            if prev[k] is not None and prev[k] != cur[k]:
                raise InconsistentState('%s changed: %s %s' % (k, cur['pair'], cur['date']))
    pv = prev or {'order': None, 'fill': None, 'end': None, 'late_gap': False}
    base = dict(pair=cur['pair'], date=cur['date'])
    out = []
    if cur['order'] is not None and pv['order'] is None:
        out.append(dict(base, kind='ORDER', t=cur['order']['arm']))
    if cur['fill'] is not None and pv['fill'] is None:
        out.append(dict(base, kind='FILLED', t=cur['fill']['t']))
    if cur['end'] is not None and pv['end'] is None:
        out.append(dict(base, kind='CLOSED' if cur['phase'] == 'CLOSED' else 'CANCELLED', t=cur['end']['t']))
    if cur['late_gap'] and not pv['late_gap']:
        out.append(dict(base, kind='GAP_WARNING', t=cur['now']))
    if cur['phase'] == 'NOT_ELIGIBLE' and cur['reason'] == 'GAP' and (prev is None or prev['phase'] != 'NOT_ELIGIBLE'):
        out.append(dict(base, kind='NO_TRADE_GAP', t=cur['now']))
    return out


# ---------------------------------------------------------------- the runner (incremental loop)
_RANK = {'FILLED': 0, 'CANCELLED': 0, 'CLOSED': 0, 'GAP_WARNING': 0, 'NO_TRADE_GAP': 0, 'CLOSE_SOON': 0, 'ORDER': 1}


def _s(x):
    return None if x is None else str(x)


class Runner:
    """Steps the London day at every M5 close from 07:05 London while anything can still change, up to 17:00 New
    York. Feeds the events to the guard in time order (fills, cancels and closes before a new order at the same time;
    EUR/USD before GBP/USD) and writes one alert per event. Each alert carries `facts`: the values the owner acts on,
    which run_live compares with what an earlier run sent.

    balance_for(D): the opening balance recorded for London day D, or None (then orders come without a size).
    firm_daily_loss_usd: BK3 rule 7; a day whose 1.5 full is more than half of it gets no size."""

    def __init__(self, data, excluded=frozenset(), guard=None, quotes='owner', balance_for=None, risk_pct=0.5,
                 aplus_trades_done=0, use_cache=True, last_loss_full_usd=None, firm_daily_loss_usd=None):
        SZ.check_risk(risk_pct, aplus_trades_done)            # bad settings stop here, before any step
        self.firm = None if firm_daily_loss_usd is None else SZ.check_usd(firm_daily_loss_usd,
                                                                            'firm daily loss limit')
        self.data = data
        self.excluded = frozenset(excluded)
        self.guard = guard if guard is not None else GD.Guard(on=True)
        self.quotes = quotes
        self.balance_for = balance_for or (lambda D: 10000)
        self.risk_pct = risk_pct
        self.aplus_done = aplus_trades_done
        self.cache = {} if use_cache else None
        self.states = {}           # (pair, date iso) -> latest state
        self.book = {}             # (pair, date iso) -> guard decision, sizes and lots of a v3 order
        self.full_usd = {}         # London date iso -> ($ of 1 full that day or None, why None)
        self.last_loss_full_usd = last_loss_full_usd
        self.alerts = []           # dict(id, at, pair, date, kind, text, facts)
        self.events = []
        self.steps = 0

    # -------------------------------------------------------------- stepping
    def step(self, D, T):
        self.steps += 1
        evs = []
        for pair in PAIRS:
            if pair not in self.data:
                continue
            key = (pair, D.isoformat())
            prev = self.states.get(key)
            if prev is not None and prev['final']:
                continue                       # a final state never changes (checked by replay)
            cur = evaluate(self.data[pair], pair, D, T, self.excluded, self.quotes, self.cache)
            evs.extend(diff(prev, cur))
            self.states[key] = cur
        if T == clocks(D)['ny_end'] - 300:     # 16:55 New York: remind to close what is still open at 17:00
            for pair in PAIRS:
                st = self.states.get((pair, D.isoformat()))
                if st is not None and st['phase'] == 'FILLED' and st['now'] == T:
                    evs.append(dict(pair=pair, date=D.isoformat(), kind='CLOSE_SOON', t=T))
        evs.sort(key=lambda e: (e['t'], _RANK[e['kind']], PAIRS.index(e['pair'])))
        for e in evs:
            e['at'] = T
            self._apply(D, e)
        self.events.extend(evs)
        return evs

    def busy(self, D):
        ds = D.isoformat()
        return any(self.states.get((p, ds)) is None or not self.states[(p, ds)]['final']
                   for p in PAIRS if p in self.data)

    def run_day(self, D, until=None):
        """Step every M5 close of London day D from 07:05 London to 17:00 New York (or until), stopping once both
        pairs are final (later steps cannot change anything)."""
        if D.weekday() >= 5:
            return
        c = clocks(D)
        end = c['ny_end'] if until is None else min(c['ny_end'], until)
        T = c['L0705']
        while T <= end:
            self.step(D, T)
            if not self.busy(D):
                break
            T += 300

    # -------------------------------------------------------------- events -> guard, sizing, alerts
    def _day_full(self, D):
        """($ of 1 full on London day D, None) or (None, why): no balance recorded for D, or BK3 rule 7 refuses."""
        ds = D.isoformat()
        if ds not in self.full_usd:
            bal = self.balance_for(D)
            if bal is None:
                self.full_usd[ds] = (None, 'no opening balance recorded for %s. Record it with: python3 -I -B live.py '
                                           'balance <usd>; the next run sends the size as an UPDATE'
                                     % D.strftime('%a %d %b'))
            else:
                full = SZ.full_risk_usd(bal, self.risk_pct, self.last_loss_full_usd, self.aplus_done)
                if self.firm is not None and not GD.check_firm_limit(self.firm, full):
                    self.full_usd[ds] = (None, 'guard rule 7 refuses it: 1.5 full = $%s is more than half the firm\'s '
                                               'daily loss limit of $%s; lower --risk-pct'
                                         % (SZ.fmt_usd(GD.CAP * full), SZ.fmt_usd(self.firm)))
                else:
                    self.full_usd[ds] = (full, None)
        return self.full_usd[ds]

    def _alert(self, e, kind, text, facts, suffix=''):
        self.alerts.append(dict(id='%s%s:%s:%s' % (kind, suffix, e['pair'], e['date']), at=e['at'], pair=e['pair'],
                                date=e['date'], kind=kind, text=text, facts=facts))

    def _apply(self, D, e):
        key = (e['pair'], e['date'])
        st = self.states[key]
        if e['kind'] == 'ORDER':
            dec = self.guard.on_order(e['pair'], D, e['t'])
            o = st['order']
            full, why = self._day_full(D)
            b = dict(action=dec['action'], rule=dec['rule'], size=dec['size'], full_usd=full, why=why, plan=None)
            self.book[key] = b
            if dec['action'] != 'PLACE':
                self._alert(e, 'SKIPPED', AL.skipped(e['pair'], D, dec['action'], dec['rule']),
                            dict(action=dec['action'], rule=dec['rule']))
                return
            text, plan = AL.new_order(e['pair'], D, Fraction(o['E']), Fraction(o['S']), Fraction(o['T']), dec['size'],
                                      full, self.balance_for(D), self.risk_pct, dec['rule'], arm_ts=o['arm'],
                                      no_size=why)
            b['plan'] = plan
            self._alert(e, 'ORDER', text, dict(arm=o['arm'], entry=plan['entry'], stop=plan['stop'],
                                               target=plan['target'], size=str(dec['size']), lots=_s(plan['lots'])))
            for (k2, old, new) in dec['resize']:
                b2 = self.book.get(k2)
                if b2 is None or b2.get('plan') is None:
                    continue
                o2 = self.states[k2]['order']
                old_lots = b2['plan']['lots']
                b2['size'] = new
                risk2 = None if b2['full_usd'] is None else new * b2['full_usd']
                b2['plan'] = AL.broker_plan(k2[0], Fraction(o2['E']), Fraction(o2['S']), Fraction(o2['T']), risk2,
                                            b2.get('why'))
                if self.states[k2]['phase'] in ('CANCELLED', 'CLOSED'):
                    continue                   # already deleted (or done): no resize to send
                self.alerts.append(dict(id='RESIZE:%s:%s' % k2, at=e['at'], pair=k2[0], date=k2[1], kind='RESIZE',
                                        text=AL.resized(k2[0], D, old_lots, b2['plan']['lots'],
                                                        'guard rule 2: both pairs armed, neither filled; now %s of a '
                                                        'full trade' % ('1/2' if new == GD.HALF else str(new))),
                                        facts=dict(size=str(new), lots=_s(b2['plan']['lots']))))
            return
        if e['kind'] == 'NO_TRADE_GAP':
            self._alert(e, 'NO_TRADE_GAP', AL.gap_day(e['pair'], D, e['t']), {})
            return
        b = self.book.get(key)
        placed = b is not None and b['action'] == 'PLACE'
        if e['kind'] == 'FILLED':
            self.guard.on_fill(key, e['t'])
            if placed:
                f = st['fill']
                lots = b['plan']['lots'] if b['plan'] else None
                if f['market']:
                    risk = None if b['full_usd'] is None else b['size'] * b['full_usd']
                    p2 = AL.broker_plan(e['pair'], Fraction(f['F']), Fraction(f['S']), Fraction(f['T']), risk,
                                        b.get('why'))
                    lots = p2['lots']
                b['fill_lots'] = lots
                self._alert(e, 'FILLED', AL.filled(e['pair'], D, f['t'], Fraction(f['F']), Fraction(f['S']),
                                                   Fraction(f['T']), f['market'], lots),
                            dict(t=f['t'], entry=AL.round_entry(Fraction(f['F'])), stop=AL.round_up(Fraction(f['S'])),
                                 target=AL.round_up(Fraction(f['T'])), market=f['market'], lots=_s(lots)))
        elif e['kind'] == 'CANCELLED':
            self.guard.on_cancel(key, e['t'])
            if placed:
                self._alert(e, 'CANCELLED', AL.cancelled(e['pair'], D, st['end']['kind'], e['t']),
                            dict(kind=st['end']['kind'], t=e['t']))
        elif e['kind'] == 'CLOSE_SOON':
            if placed:
                self._alert(e, 'CLOSE_SOON', AL.close_soon(e['pair'], D, e['t'], b.get('fill_lots')), dict(t=e['t']))
        elif e['kind'] == 'CLOSED':
            R = Fraction(st['end']['R'])
            self.guard.on_close(key, e['t'], R)
            if placed:
                f = st['fill']
                lots = b.get('fill_lots')
                stop_pips = Fraction(Fraction(f['d']), 40)
                self._alert(e, 'CLOSED', AL.closed(e['pair'], D, st['end']['kind'], e['t'], R, lots, stop_pips),
                            dict(kind=st['end']['kind'], t=e['t'], R='%+.2f' % float(R)))
                if R >= 0:
                    self.last_loss_full_usd = None
                elif b['full_usd'] is not None:      # a loss caps 1 full at that trade's 1 full (rule 6)
                    self.last_loss_full_usd = b['full_usd']
        elif e['kind'] == 'GAP_WARNING':
            self._alert(e, 'GAP_WARNING', 'DATA GAP %s %s: the feed has a gap of more than 16 minutes after the order '
                        'was armed (research would have skipped this day). The order stays; check your chart.'
                        % (AL.pair_name(e['pair']), D.strftime('%a %d %b')), {})


# ---------------------------------------------------------------- command line (live; not run in this build)
STALE_AFTER_S = 600            # newest final minute more than 10 minutes behind the wall clock: DATA STALE
KEEP_SENT_DAYS = 21            # sent-alert records older than this are dropped from the state file
_NOT_COMPARED = ('UPDATE', 'DATA_STALE', 'DATA_BACK')


def london_weekdays_of_week(now):
    D = dt.datetime.fromtimestamp(int(now), DA.LON).date()
    mon = D - dt.timedelta(days=D.weekday())
    return [mon + dt.timedelta(days=i) for i in range(5) if mon + dt.timedelta(days=i) <= D]


def load_state(state_path):
    state = {'sent': {}, 'balances': {}, 'last_loss_full_usd': None}
    if os.path.exists(state_path):
        with open(state_path) as f:
            state = json.load(f)
    if isinstance(state.get('sent'), list):                 # older form: ids only, no facts to compare
        state['sent'] = {i: dict(facts=None, at=None, date=i.rsplit(':', 1)[-1], kind=i.split(':', 1)[0])
                         for i in state['sent']}
    state.setdefault('sent', {})
    state.setdefault('balances', {})
    state.setdefault('stale', {})
    state.setdefault('corrections', [])
    return state


def save_state(state_path, state):
    """Write the state file atomically (a unique temp file, then rename)."""
    d = os.path.dirname(os.path.abspath(state_path))
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.state.', suffix='.tmp', dir=d)
    try:
        with os.fdopen(fd, 'w') as f:
            json.dump(state, f, indent=1, sort_keys=True)
        os.replace(tmp, state_path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def record_balance(state, D, usd, replace=False):
    """Record the opening balance (USD) of London day D. Refuses to overwrite unless replace."""
    v = SZ.check_usd(usd)
    ds = D.isoformat()
    if ds in state['balances'] and not replace:
        raise SZ.SizeError('a balance is already recorded for %s ($%s); use --replace to change it'
                           % (ds, state['balances'][ds]))
    state['balances'][ds] = str(usd)
    return v


def _fmt_fact(k, v):
    if v is None:
        return 'none'
    if k in ('entry', 'stop', 'target'):
        return AL.price_text(int(v))
    if k in ('t', 'arm'):
        return AL.london_hm(v) + ' London'
    return str(v)


def _changes(old, new):
    keys = sorted(set(old) | set(new))
    return ['%s %s -> %s' % (k, _fmt_fact(k, old.get(k)), _fmt_fact(k, new.get(k))) for k in keys
            if old.get(k) != new.get(k)]


def _update_alert(a, at, n, text):
    return dict(id='UPDATE:%s:%d' % (a['id'], n), at=at, pair=a['pair'], date=a['date'], kind='UPDATE', text=text,
                facts={})


def run_live(now_wall, balance, risk_pct, state_path, http=None, cache_dir=None, aplus_done=0, quotes='owner',
             firm_daily_loss_usd=None, commit=True):
    """Rebuild this London week from Monday 07:05 to the last final M5 close, deterministically, and return
    (new alerts, runner, now). New alerts: alerts not sent before (by id), UPDATE alerts for alerts already sent
    whose facts now differ (or that no longer hold), and DATA STALE / DATA BACK alerts. Each new alert has
    'delivered', the text to send (send time and late handling added).

    balance: if not None, recorded as today's opening balance when none is recorded yet (API and tests; the command
    line records balances only with `live.py balance`). commit False: the state is not written; the caller writes
    runner.live_state with save_state() after the alerts are delivered (so an alert is never marked sent unsent)."""
    import feed_oanda as FO
    SZ.check_risk(risk_pct, aplus_done)                     # settings are checked before any fetch
    if firm_daily_loss_usd is not None:
        SZ.check_usd(firm_daily_loss_usd, 'firm daily loss limit')
    http = http or FO.http_get
    cache_dir = cache_dir or FO.CACHE
    wall = int(now_wall)
    now = (wall // 300) * 300
    days = london_weekdays_of_week(now)
    state = load_state(state_path)
    today_D = dt.datetime.fromtimestamp(now, DA.LON).date()
    today = today_D.isoformat()
    if balance is not None and today not in state['balances']:
        record_balance(state, today_D, balance)
    week = days[0].isoformat() if days else today
    if state.get('week') != week:                           # "never larger after a loss" carries over the weekend
        state['week'] = week
        state['week_start_last_loss'] = state.get('last_loss_full_usd')
    t_from = DA.lon(days[0] - dt.timedelta(days=WINDOW_DAYS), 0) if days else now
    data, fu_by = {}, {}
    for p in PAIRS:
        pdat, fu = FO.load_oanda(p, t_from, now, http=http, cache_dir=cache_dir, wall=wall)
        data[p], fu_by[p] = pdat, fu
    final_until = min([now] + list(fu_by.values()))
    now = (final_until // 300) * 300                        # only bars that can no longer change
    bal = state['balances']
    runner = Runner(data, quotes=quotes, risk_pct=risk_pct, aplus_trades_done=aplus_done,
                    balance_for=lambda D: (Fraction(bal[D.isoformat()]) if D.isoformat() in bal else None),
                    last_loss_full_usd=(None if state.get('week_start_last_loss') is None
                                        else Fraction(state['week_start_last_loss'])),
                    firm_daily_loss_usd=firm_daily_loss_usd)
    for D in days:
        runner.run_day(D, until=now)

    # ------------------------------------------------ data warnings (07:00 London to 17:00 New York, weekdays)
    data_alerts = []
    in_window = (today_D.weekday() < 5 and (today_D.month, today_D.day) not in DA.HOLIDAY_MD
                 and DA.lon(today_D, 7) <= wall <= DA.nyt(today_D, 17))
    for p in PAIRS:
        lag = wall - fu_by[p]
        if in_window and lag > STALE_AFTER_S:
            data_alerts.append(dict(
                id='DATA_STALE:%s:%s:%d' % (p, today, fu_by[p]), at=wall, pair=p, date=today, kind='DATA_STALE',
                facts={}, text='DATA STALE %s: the newest final price minute ends %s London, %d min behind. The bot '
                               'cannot see this pair, so new signals, fills and exits after then are not checked until '
                               'the feed recovers. Check your chart.' % (AL.pair_name(p), AL.london_hm(fu_by[p]),
                                                                        lag // 60)))
            state['stale'][p] = fu_by[p]
        elif state['stale'].get(p) is not None and lag <= STALE_AFTER_S:
            data_alerts.append(dict(
                id='DATA_BACK:%s:%s:%d' % (p, today, state['stale'][p]), at=wall, pair=p, date=today,
                kind='DATA_BACK', facts={},
                text='DATA BACK %s: the feed is up to date again (data to %s London).' % (AL.pair_name(p),
                                                                                       AL.london_hm(fu_by[p]))))
            state['stale'][p] = None

    # ------------------------------------------------ new alerts, and updates to alerts already sent
    sent = state['sent']
    new, updates = [], []
    rebuilt = {a['id']: a for a in runner.alerts}
    for a in runner.alerts:
        old = sent.get(a['id'])
        if old is None:
            new.append(a)
            continue
        if old.get('facts') is None:
            continue                                        # an old record without facts: nothing to compare
        if old.get('withdrawn') or old['facts'] != a['facts']:
            n = old.get('updates', 0) + 1
            ch = _changes(old['facts'], a['facts'])
            why = ('it holds again on the rebuilt data' if old.get('withdrawn')
                   else 'the rebuilt data changed: ' + '; '.join(ch))
            updates.append(_update_alert(a, now, n, 'UPDATE to the %s alert for %s %s: %s. The alert now reads:\n%s'
                                         % (a['kind'], AL.pair_name(a['pair']), a['date'], why, a['text'])))
            state['corrections'].append(dict(utc=wall, id=a['id'], changes=ch, back=bool(old.get('withdrawn'))))
            old.update(facts=a['facts'], updates=n, withdrawn=False)
    rebuilt_days = {D.isoformat() for D in days}
    for i, old in sorted(sent.items()):
        if (old.get('kind') in _NOT_COMPARED or old.get('facts') is None or old.get('withdrawn')
                or old.get('date') not in rebuilt_days or old.get('at') is None or old['at'] > now or i in rebuilt):
            continue
        n = old.get('updates', 0) + 1
        kind, pair = old['kind'], i.split(':')[1]
        what = ('If you placed that order and it has not filled, cancel it. If it filled, keep its stop and target and '
                'close it by 17:00 New York.' if kind == 'ORDER' else 'Check your chart and your broker.')
        a = dict(id=i, pair=pair, date=old['date'])
        updates.append(_update_alert(a, now, n, 'UPDATE: the %s alert for %s %s no longer holds on the rebuilt data. '
                                     '%s' % (kind, AL.pair_name(pair), old['date'], what)))
        state['corrections'].append(dict(utc=wall, id=i, changes=['withdrawn']))
        old.update(updates=n, withdrawn=True)
    new = [a for a in data_alerts if a['id'] not in sent] + new + updates
    by_day = {}
    for a in new:
        by_day.setdefault((a['pair'], a['date']), set()).add(a['kind'])
    for a in new:
        a['delivered'] = AL.delivered(a, wall, today, by_day[(a['pair'], a['date'])] - {a['kind']})
        if a['id'] not in sent:
            sent[a['id']] = dict(facts=a['facts'], at=a['at'], date=a['date'], kind=a['kind'])
    keep_from = (today_D - dt.timedelta(days=KEEP_SENT_DAYS)).isoformat()
    state['sent'] = {i: v for i, v in sent.items() if (v.get('date') or '') >= keep_from}
    state['corrections'] = state['corrections'][-200:]
    state['last_run_utc'] = now
    state['last_loss_full_usd'] = None if runner.last_loss_full_usd is None else str(runner.last_loss_full_usd)
    today_view = {}
    for p in PAIRS:
        st = runner.states.get((p, today), {})
        b = runner.book.get((p, today))
        today_view[p] = dict(phase=st.get('phase'), reason=st.get('reason'),
                             guard=None if b is None else b['action'],
                             guard_rule=None if b is None else b['rule'],
                             size=None if b is None or b['action'] != 'PLACE' else str(b['size']))
    state['today'] = today_view
    runner.live_state = state
    if commit:
        save_state(state_path, state)
    return new, runner, now


def _lock(state_path):
    """An exclusive, non-blocking lock beside the state file: one run at a time. Returns the open lock file or None."""
    d = os.path.dirname(os.path.abspath(state_path))
    os.makedirs(d, exist_ok=True)
    f = open(os.path.join(d, '.run.lock'), 'w')
    try:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        return None
    return f


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest='cmd', required=True)
    b = sub.add_parser('balance', help="record today's London-day opening balance (USD), before 07:00 London")
    b.add_argument('usd')
    b.add_argument('--replace', action='store_true', help="change a balance already recorded for today")
    b.add_argument('--state', default=os.path.join(STATE_DIR, 'state.json'))
    r = sub.add_parser('run', help='one run: rebuild the week to the last final M5 close and print new alerts')
    r.add_argument('--risk-pct', default='0.5', help='1 full = this %% of the London-day opening balance')
    r.add_argument('--firm-daily-loss-usd', required=True,
                   help="the funded firm's daily loss limit in USD (BK3 rule 7: 1.5 full <= half of it)")
    r.add_argument('--aplus-done', type=int, default=0, help='forward A+ trades so far (1%% ceiling until 25)')
    r.add_argument('--quotes', choices=['owner', 'feed'], default='owner')
    r.add_argument('--state', default=os.path.join(STATE_DIR, 'state.json'))
    args = ap.parse_args(argv)
    lock = _lock(args.state)
    if lock is None:
        print('another run is still going: this one is skipped')
        return 3
    try:
        wall = time.time()
        today_D = dt.datetime.fromtimestamp(int(wall), DA.LON).date()
        if args.cmd == 'balance':
            state = load_state(args.state)
            try:
                record_balance(state, today_D, args.usd, args.replace)
            except SZ.SizeError as err:
                print('refused: %s' % err)
                return 2
            save_state(args.state, state)
            print('recorded: opening balance of London day %s = $%s' % (today_D.strftime('%a %d %b %Y'),
                                                                       SZ.fmt_usd(Fraction(args.usd))))
            return 0
        # run: every setting is checked before any fetch
        try:
            SZ.check_risk(args.risk_pct, args.aplus_done)
            firm = SZ.check_usd(args.firm_daily_loss_usd, 'firm daily loss limit')
            state = load_state(args.state)
            bal = state['balances'].get(today_D.isoformat())
            if bal is None:
                print('note: no opening balance recorded for %s; orders come without a size until you run: '
                      'python3 -I -B live.py balance <usd>' % today_D.strftime('%a %d %b'))
            else:
                last = state.get('last_loss_full_usd')
                full = SZ.full_risk_usd(bal, args.risk_pct, None if last is None else Fraction(last), args.aplus_done)
                if not GD.check_firm_limit(firm, full):
                    raise SZ.SizeError('guard rule 7: 1.5 full = $%s is more than half the firm daily loss limit '
                                       '($%s); lower --risk-pct' % (SZ.fmt_usd(GD.CAP * full), SZ.fmt_usd(firm)))
        except SZ.SizeError as err:
            print('refused: %s' % err)
            return 2
        new, runner, now = run_live(wall, None, args.risk_pct, args.state, aplus_done=args.aplus_done,
                                    quotes=args.quotes, firm_daily_loss_usd=args.firm_daily_loss_usd, commit=False)
        print('data final up to %s UTC' % dt.datetime.fromtimestamp(now, dt.timezone.utc).strftime('%Y-%m-%d %H:%M'))
        for a in new:                                       # delivery (the terminal for now) ...
            print('\n' + a['delivered'], flush=True)
        if not new:
            print('no new alerts')
        save_state(args.state, runner.live_state)           # ... and only then marked sent
        return 0
    finally:
        lock.close()


if __name__ == '__main__':
    sys.exit(main())
