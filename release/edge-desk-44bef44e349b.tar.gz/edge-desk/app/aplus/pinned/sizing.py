"""Lot size for one order (PLAN.md N2/N3 sizing; EUR/USD and GBP/USD in a USD account).

    lots = risk $ / (stop pips x $10 per pip per lot), rounded DOWN to 0.01 lots; refused if under 0.01.

Exact arithmetic (Fraction from decimal text), so 0.29 never becomes 0.28 through float error. The $5 a lot
round-trip commission is not in the formula (as specified); the alert shows it beside the size.
"""
from decimal import Decimal
from fractions import Fraction
import math

USD_PER_PIP_PER_LOT = {'EUR_USD': 10, 'GBP_USD': 10}     # quote currency USD: 100,000 x 0.0001 = $10
MIN_LOTS = Fraction(1, 100)
COMMISSION_PER_LOT = Fraction(5)                         # owner's MT5 raw account, round trip (26 Oct)
MAX_RISK_PCT_BEFORE_25 = Fraction(1)                     # N2: the ceiling is 1% until 25 forward A+ trades


class SizeError(ValueError):
    pass


def exact(x):
    """int, Fraction, Decimal or decimal text/float -> Fraction (floats go through their shortest text)."""
    if isinstance(x, Fraction):
        return x
    if isinstance(x, int):
        return Fraction(x)
    return Fraction(Decimal(str(x)))


def _exact_input(x, what):
    try:
        return exact(x)
    except (ArithmeticError, ValueError, TypeError):
        raise SizeError('%s %r is not a number' % (what, x)) from None


def check_risk(risk_pct, aplus_trades_done=0):
    """N2: risk % above 0, and at most 1% until 25 forward A+ trades. Returns the % as a Fraction."""
    if not isinstance(aplus_trades_done, int) or aplus_trades_done < 0:
        raise SizeError('forward A+ trades done must be a whole number of 0 or more (got %r)' % (aplus_trades_done,))
    pct = _exact_input(risk_pct, 'risk %')
    if pct <= 0:
        raise SizeError('risk %% must be above 0 (got %s)' % risk_pct)
    if pct > MAX_RISK_PCT_BEFORE_25 and aplus_trades_done < 25:
        raise SizeError('risk %s%% is over the 1%% ceiling that holds until 25 forward A+ trades (PLAN N2)' % risk_pct)
    return pct


def check_usd(x, what='balance'):
    """A positive dollar amount (decimal text), as a Fraction."""
    v = _exact_input(x, what)
    if v <= 0:
        raise SizeError('%s must be above 0 (got %s)' % (what, x))
    return v


def full_risk_usd(opening_balance, risk_pct, last_loss_full_usd=None, aplus_trades_done=0):
    """$ of 1 full: risk_pct % of the London-day opening balance; never larger after a loss (capped at the full $
    of the last trade when that trade lost); risk_pct over 1% is refused until 25 forward A+ trades (N2)."""
    pct = check_risk(risk_pct, aplus_trades_done)
    usd = check_usd(opening_balance) * pct / 100
    if last_loss_full_usd is not None:
        usd = min(usd, exact(last_loss_full_usd))
    return usd


def lots(pair, risk_usd, stop_pips):
    """Lots for risk_usd over a stop of stop_pips, rounded down to 0.01. Returns a Fraction (hundredths).
    Raises SizeError if the result is under 0.01 lots or the pair is not a USD-quoted pair handled here."""
    if pair not in USD_PER_PIP_PER_LOT:
        raise SizeError('no pip value for %s' % pair)
    r, sp = exact(risk_usd), exact(stop_pips)
    if sp <= 0:
        raise SizeError('stop distance must be above 0 pips')
    raw = r / (sp * USD_PER_PIP_PER_LOT[pair])
    hundredths = math.floor(raw * 100)
    out = Fraction(hundredths, 100)
    if out < MIN_LOTS:
        raise SizeError('size %.4f lots is under the 0.01 minimum: risk $%s over %s pips is too small'
                        % (float(raw), fmt_usd(r), fmt_pips(sp)))
    return out


def money_at_risk(pair, lot, stop_pips):
    """$ lost at the stop for this size (before commission)."""
    return exact(lot) * exact(stop_pips) * USD_PER_PIP_PER_LOT[pair]


def fmt_lots(x):
    return '%.2f' % float(x)


def fmt_usd(x):
    return '{:,.2f}'.format(float(x))


def fmt_pips(x):
    return ('%.2f' % float(x)).rstrip('0').rstrip('.')
