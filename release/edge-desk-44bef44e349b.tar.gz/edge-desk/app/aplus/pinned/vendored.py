"""Load the unchanged copies of the verified v2x research engine (bot/vendor/) after checking their sha256.

The three files are byte copies of marc_test/v2x/{engine,data,outcomes}.py as of 26 Oct 2026 10:55 UTC (the engine
that passed the K14 truncation and scrambled-future tests). They are never edited. Every bot module gets the engine
through this file:

    from vendored import EN, DA, OC      # engine, data, outcomes

The check runs once, at import: vendor/SHA256SUMS must list exactly the pinned hashes below, and each file's bytes
must hash to them. Any difference stops the bot.
"""
import hashlib
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
VENDOR = os.path.join(HERE, 'vendor')

# sha256 of the original research files (marc_test/v2x), recorded when they were copied (27 Oct 2026 04:43 UTC)
PINNED = {
    'engine.py': 'eb6740763ab683c6be95af9a6a09106806b4211592249c46593ca772ea388909',
    'data.py': '25e3f5bb5399bc7439e88237eb64a06a1070cbd68d2b867ab12ce459c41a9e2a',
    'outcomes.py': '829ed19e48c0153b3cde7e9ce24f5ae6e8ba6234f164a35398774a8679aadf74',
}


class VendorError(RuntimeError):
    pass


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def check(vendor_dir=VENDOR, pinned=PINNED):
    """Raise VendorError unless SHA256SUMS equals the pins and every file hashes to its pin."""
    sums = {}
    with open(os.path.join(vendor_dir, 'SHA256SUMS')) as f:
        for line in f:
            if line.strip():
                h, name = line.split()
                sums[name.lstrip('*')] = h
    if sums != pinned:
        raise VendorError('vendor/SHA256SUMS differs from the pinned hashes')
    for name, want in pinned.items():
        got = file_sha256(os.path.join(vendor_dir, name))
        if got != want:
            raise VendorError('vendor/%s sha256 %s differs from the pin %s' % (name, got, want))
    return True


check()
if VENDOR not in sys.path:
    sys.path.insert(0, VENDOR)

import engine as EN      # noqa: E402
import data as DA        # noqa: E402
import outcomes as OC    # noqa: E402

for _m in (EN, DA, OC):
    if os.path.dirname(os.path.abspath(_m.__file__)) != VENDOR:
        raise VendorError('module %s was not loaded from bot/vendor (%s)' % (_m.__name__, _m.__file__))
