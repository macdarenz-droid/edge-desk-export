"""The pinned A+ code (app/aplus/pinned): byte copies of the verified bot at research commit SOURCE_COMMIT
(/home/user/Forex-signal bot/, replay parity 65/65 orders and 46/46 fills, 80 unit tests; docs/APLUS_DESIGN.md D3).

Standard library only: verify() runs in the child before anything is imported from the copy. It refuses (Refused)
unless pinned/ holds exactly the pinned files and its vendor/ folder (no other file or folder that a bare-name import
could pick up, and no __pycache__: cached bytecode would be run in place of the checked source) and each file's sha256
is its pin.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

SOURCE_COMMIT = "f52dfb2839b1d1918464bee7a26393af38f3e091"
PINNED_DIR = Path(__file__).resolve().with_name("pinned")
PINS = {
    "live.py": "7cb6ac6c3780984931f16b0ca67ecdda2d1bd7c508b86abc604c279b6bb8a24d",
    "vendored.py": "d257532a5f21905bff183179ec91f9c39c93f3383f9784e0afd64ef0cbaf1fb2",
    "guard.py": "5b1b6475033aa36524c5755c60fa59778e3da3532b62f35cba6e0ed915e8e3cc",
    "sizing.py": "5cce681f591859b3ddc667ed9b50652851d6cc88b6182f5c9df094956e996986",
    "alert.py": "ca0dbfb4713ea852f6613bb01f4970d7794202493d24fa52a2994704164defd3",
    "vendor/engine.py": "eb6740763ab683c6be95af9a6a09106806b4211592249c46593ca772ea388909",
    "vendor/data.py": "25e3f5bb5399bc7439e88237eb64a06a1070cbd68d2b867ab12ce459c41a9e2a",
    "vendor/outcomes.py": "829ed19e48c0153b3cde7e9ce24f5ae6e8ba6234f164a35398774a8679aadf74",
    "vendor/SHA256SUMS": "3328526abf538a1a754705a8f9ce067523be8a71fea83e7e654fc524801b8178",
}
# The code version of an A+ suggestion in the suggestion log (its code_sha256): one sha256 over the pin table, one
# "<sha256>  <path>" line per file in path order, as sha256sum prints them.
CODE_SHA256 = hashlib.sha256("".join(f"{h}  {f}\n" for f, h in sorted(PINS.items())).encode()).hexdigest()
# The modules the child loads by bare name, and the folder each must come from.
MODULE_DIRS = {"live": "", "vendored": "", "guard": "", "sizing": "", "alert": "",
               "engine": "vendor", "data": "vendor", "outcomes": "vendor"}


class Refused(RuntimeError):
    pass


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


FOLDERS = {"vendor"}


def files_on_disk(root: Path) -> set[str]:
    """Every entry under root (relative, "/"-separated) except the vendor folder itself: a file, a link or any other
    folder (a __pycache__ too) is listed, so it fails the comparison with PINS."""
    out = set()
    for p in root.rglob("*"):
        rel = p.relative_to(root)
        if p.is_dir() and not p.is_symlink() and rel.as_posix() in FOLDERS:
            continue
        out.add(rel.as_posix())
    return out


def verify(root: Path | str = PINNED_DIR) -> None:
    """Refused unless root holds exactly PINS, every file a regular file (no link) with its pinned sha256."""
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise Refused(f"{root} is not a folder")
    got = files_on_disk(root)
    if got != set(PINS):
        raise Refused(f"files differ from the pins: extra {sorted(got - set(PINS))}, missing {sorted(set(PINS) - got)}")
    for rel, want in sorted(PINS.items()):
        p = root / rel
        if p.is_symlink() or not p.is_file():
            raise Refused(f"{rel} is not a plain file")
        have = sha256_file(p)
        if have != want:
            raise Refused(f"{rel} sha256 {have} differs from the pin {want}")
