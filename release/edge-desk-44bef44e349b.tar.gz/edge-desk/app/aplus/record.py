"""The A+ short's tested record line (rule APLUS-V3), from record.json: every card and order alert carries it.

recompute() rebuilds the figures from the bot's replay CSV (bot/out/replay_v3_orders.csv), so the test can check
record.json against a byte copy of it. Standard library only."""
from __future__ import annotations

import csv
import io
import json
from fractions import Fraction
from functools import lru_cache
from pathlib import Path

PATH = Path(__file__).with_name("record.json")
RULE_ID = "APLUS-V3"
END = "Paper. Not proven."
COMM_20 = 80                  # 2.0 pips in K1 units (1 pip = 40)
OWNER_COMM, OWNER_SLIP = 20, 20


@lru_cache(maxsize=1)
def data() -> dict:
    return json.loads(PATH.read_text())


def _r(x: float) -> str:
    return f"{x:+.2f}R"


def record_line() -> str:
    d = data()
    e, b = d["figures"]["eur_usd"], d["figures"]["both"]
    return d["template"].format(years=d["years"], eur_trades=e["trades"], eur_owner=_r(e["r_owner"]),
                                eur_20=_r(e["r_20"]), all_trades=b["trades"], all_owner=_r(b["r_owner"]),
                                all_20=_r(b["r_20"]))


def r_after_20(row: dict) -> Fraction:
    """R after 2.0 pips of one filled order from its owner-cost R: the same fill and exit, 2.0 pips the only charge."""
    d = Fraction(row["S"]) - Fraction(row["F"])
    slip = OWNER_SLIP if row["end_kind"] == "STOP" else 0
    return Fraction(row["R_owner"]) + Fraction(OWNER_COMM + slip - COMM_20) / d


def recompute(csv_text: str) -> dict:
    """{'eur_usd': {...}, 'both': {...}}: orders, trades (phase CLOSED) and the exact mean R (owner costs, 2.0 pips)."""
    rows = list(csv.DictReader(io.StringIO(csv_text)))
    out = {}
    for key, pick in (("eur_usd", lambda r: r["pair"] == "EUR_USD"), ("both", lambda r: True)):
        sel = [r for r in rows if pick(r)]
        fills = [r for r in sel if r["phase"] == "CLOSED"]
        n = len(fills)
        out[key] = {"orders": len(sel), "trades": n,
                    "r_owner": sum((Fraction(r["R_owner"]) for r in fills), Fraction(0)) / n if n else None,
                    "r_20": sum((r_after_20(r) for r in fills), Fraction(0)) / n if n else None}
    return out
