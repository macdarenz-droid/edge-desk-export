"""Setup checks: the owner's top-down checklist as a form (A3)."""
