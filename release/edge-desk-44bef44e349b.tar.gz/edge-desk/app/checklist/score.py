"""The setup check's computed fields: stop, target, cost in R, must-haves, checks, score and tier.

Round 57's coded reading of the owner's 12 Oct words ("The more checks, the more reason to go into. Less checks,
less risk capital. Or half"), as the blueprint "Setup check" lists it:
  must-haves  M1 a body-close break, CHoCH or BOS (break_type)
              M2 an untouched FVG or order block to enter at (entry_zone_type and zone_untouched)
              M3 a daily or 4h reason on the trade's side (daily_candle or h4_state)
              M4 the target not past the demand or supply zone's far side (no zone typed counts as met)
  checks      C1 daily wick rejection, C2 4h FVG filled, C3 1h structure on the side (h1_state),
              C4 liquidity beyond the target, C5 a 5m or 3m order block inside the FVG (ob_inside_fvg, or an
              entry zone typed as fvg_ob)
  tier        every must-have and 4-5 checks: full; every must-have and 3: half; else none.
A tier is a share of the owner's configured risk (1, 0.5 or 0); the app never sets or raises size.
stop = stop reference -/+ cushion (default 1.5 pips); target = entry +/- target_r x the stop distance; cost in R =
cost pips / stop pips at paper.cost_pips (2.0) and paper.cost_pips_info (1.6). Recorded fields are kept, never
scored. EUR/USD pips (cfg.instrument.pip_size).
"""
from __future__ import annotations

import math

from app.config import Config

SIDES = ("buy", "sell")
TIMEFRAMES = ("d1", "h4", "h2", "h1", "m30", "m15", "m5", "m3", "m1")
TARGETS = (2, 3, 4, 5)
STREAK_TARGETS = (6, 7, 8)
DEFAULT_CUSHION_PIPS = 1.5
NOTES_MAX = 2000
TEXT_MAX = 120

_ENUMS = {
    "side": SIDES,
    "daily_candle": ("bullish", "bearish", "indecisive"),
    "h4_state": ("up", "down", "range", "breakout_up", "breakout_down"),
    "h1_state": ("up", "down", "range", "choch_up", "choch_down"),
    "side_set_by": ("daily", "h4", "h1"),
    "sync": ("all", "partly", "none"),
    "pool_tf": TIMEFRAMES,
    "pool_type": ("bsl", "ssl", "equal_highs", "equal_lows", "swing_high", "swing_low", "session_high",
                  "session_low", "previous_day_high", "previous_day_low"),
    "pool_where": ("above", "below"),
    "sweep": ("swept", "not_swept", "resting_beyond"),
    "zone_type": ("demand", "supply"),
    "break_type": ("body_close", "choch", "bos", "sweep_reaction", "resting_order"),
    "break_tf": TIMEFRAMES,
    "entry_zone_type": ("fvg", "order_block", "fvg_ob", "retest", "liquidity_area"),
    "entry_tf": TIMEFRAMES,
    "entry_style": ("market", "near_edge", "fifty", "far_edge", "half_near_half_far", "second_limit_half"),
    "stop_ref_type": ("swing_wick", "momentum_wick", "sweep_wick", "zone_far_edge"),
    "stop_ref_tf": TIMEFRAMES,
    "management": ("fixed", "stop_to_entry_2r", "unsure_ladder", "close_or_trail_4r", "streak_target"),
}
_PRICES = ("entry", "stop_ref", "daily_prev_high", "daily_prev_low", "ny_open", "pool_price", "floor_price",
           "zone_near", "zone_far", "zone_top", "zone_bottom")
_BOOLS = ("zone_untouched", "momentum", "staircase", "daily_wick_rejection", "h4_fvg_filled",
          "liquidity_beyond_target", "ob_inside_fvg", "target_reached_before", "cancel_if_target_first",
          "confirmation_entry", "placed_before_9_london", "gallery_daily_open_side", "gallery_session_sweep",
          "gallery_timing")
_TEXTS = ("swept_level", "break_utc", "expiry_utc")
_NUMBERS = ("cushion_pips", "target_r")
ALLOWED = frozenset(_ENUMS) | frozenset(_PRICES) | frozenset(_BOOLS) | frozenset(_TEXTS) | frozenset(_NUMBERS) \
    | {"notes"}
REQUIRED = ("side", "entry", "stop_ref", "swept_level")   # "every order card names the swept level"


def _num(name: str, value) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be a number")
    return float(value)


def clean(fields: dict) -> dict:
    """The fields checked against the form's list: known names, right types, enums from their lists."""
    if not isinstance(fields, dict):
        raise ValueError("fields must be an object")
    unknown = set(fields) - ALLOWED
    if unknown:
        raise ValueError(f"unknown fields: {sorted(unknown)}")
    for name in REQUIRED:
        if fields.get(name) is None:
            raise ValueError(f"{name} is required")
    out: dict = {}
    for name, value in fields.items():
        if value is None:
            continue
        if name in _ENUMS:
            if value not in _ENUMS[name]:
                raise ValueError(f"{name} must be one of {_ENUMS[name]}")
        elif name in _PRICES:
            value = _num(name, value)
            if value <= 0:
                raise ValueError(f"{name} must be above 0")
        elif name in _BOOLS:
            if not isinstance(value, bool):
                raise ValueError(f"{name} must be true or false")
        elif name in _NUMBERS:
            value = _num(name, value)
        elif name == "notes":
            if not isinstance(value, str) or len(value) > NOTES_MAX:
                raise ValueError(f"notes must be text of at most {NOTES_MAX} characters")
        elif not isinstance(value, str) or len(value) > TEXT_MAX:
            raise ValueError(f"{name} must be text of at most {TEXT_MAX} characters")
        out[name] = value
    return out


def _on_side(side: str, state: str | None) -> bool:
    if state is None:
        return False
    up = state in ("bullish", "up", "breakout_up", "choch_up")
    down = state in ("bearish", "down", "breakout_down", "choch_down")
    return up if side == "buy" else down


def _zone_far(side: str, f: dict) -> float | None:
    """The far side of the demand (sell) or supply (buy) zone in the trade's direction, if one of that kind was
    typed. A zone of the other kind (a supply zone above a sell) is not the M4 zone."""
    edges = [f[k] for k in ("zone_near", "zone_far") if k in f]
    if not edges or f.get("zone_type") != ("demand" if side == "sell" else "supply"):
        return None
    return min(edges) if side == "sell" else max(edges)


def evaluate(fields: dict, cfg: Config, streak_on: bool = False) -> dict:
    """Every computed value of a setup check. Raises ValueError on a field the form does not allow."""
    f = clean(fields)
    side, entry, ref = f["side"], f["entry"], f["stop_ref"]
    pip = cfg.instrument.pip_size
    cushion = f.get("cushion_pips", DEFAULT_CUSHION_PIPS)
    if not 0 <= cushion <= 20:
        raise ValueError("cushion_pips must be from 0 to 20")
    target_r = f.get("target_r", 3)
    allowed = TARGETS + (STREAK_TARGETS if streak_on else ())
    if target_r not in allowed:
        raise ValueError(f"target_r must be one of {allowed}" + ("" if streak_on else " (6-8R only in streak mode)"))
    direction = 1.0 if side == "buy" else -1.0
    if (ref - entry) * direction >= 0:
        raise ValueError("the stop reference must be below the entry for a buy and above it for a sell")
    stop = ref - direction * cushion * pip
    dist = abs(entry - stop)
    stop_pips = round(dist / pip, 6)
    target = entry + direction * target_r * dist
    far = _zone_far(side, f)
    zone_low = min(f.get("zone_top", entry), f.get("zone_bottom", entry))
    zone_high = max(f.get("zone_top", entry), f.get("zone_bottom", entry))
    must = {
        "m1": f.get("break_type") in ("body_close", "choch", "bos"),
        "m2": f.get("entry_zone_type") in ("fvg", "order_block", "fvg_ob") and f.get("zone_untouched") is True,
        "m3": _on_side(side, f.get("daily_candle")) or _on_side(side, f.get("h4_state")),
        "m4": far is None or ((target - far) * direction <= 1e-9),
    }
    checks = {
        "c1": f.get("daily_wick_rejection") is True,
        "c2": f.get("h4_fvg_filled") is True,
        "c3": _on_side(side, f.get("h1_state")),
        "c4": f.get("liquidity_beyond_target") is True,
        "c5": f.get("ob_inside_fvg") is True or f.get("entry_zone_type") == "fvg_ob",
    }
    score = sum(checks.values())
    if all(must.values()) and score >= 4:
        tier, share = "full", 1.0
    elif all(must.values()) and score == 3:
        tier, share = "half", 0.5
    else:
        tier, share = "none", 0.0
    return {
        "fields": f, "side": side, "entry": entry, "zone_low": zone_low, "zone_high": zone_high,
        "stop": round(stop, 6), "stop_pips": stop_pips, "target": round(target, 6), "target_r": target_r,
        "cost_r": cfg.paper.cost_pips / stop_pips, "cost_r_info": cfg.paper.cost_pips_info / stop_pips,
        "must": must, "checks": checks, "score": score, "tier": tier, "risk_share": share,
    }
