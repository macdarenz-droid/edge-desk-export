"""Setup checks in the journal: versions, links to MT5 orders and trades, the honesty lock, results by tick.

Versions: create_check writes version 1 (status open). An edit before the check is locked marks the old version
superseded and writes the next one (open). The first link locks the current version (status locked,
locked_utc). An edit after that writes an 'after_entry' version (after_entry = 1); the locked version stays the
one results are judged on.

Links (blueprint "Linking a setup check to a trade"):
  owner_tap          the owner taps "This is my order" on a pending order (order ticket), or picks a trade
  auto_exact_ticket  the fill of a tapped or matched order: the entry deal whose DEAL_ORDER is the ticket, else a
                     position whose ticket is the order ticket
  auto_match         no tap: the only EUR/USD pending order or position on the check's side, placed after the
                     check and before its expiry, with its price inside the entry zone +/- 1.0 pip and its stop
                     within 1.0 pip of the planned stop. Zero or two or more candidates: no link. Offered with
                     confirmed = 0: it does not lock the check, count in results or raise flags until the owner
                     confirms it; a rejected offer is never offered to that check again.
Not verified: that MT5's DEAL_ORDER equals the filled pending order's ticket (check the official MQL5 docs).
The +/- 1.0 pip tolerances are working readings (blueprint).
Results by tick use a check only when its locked version was written at or before the entry and is not an
after-entry version; a ladder (several positions on one check) counts once, with R = sum of net / sum of risk.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, time
from statistics import mean

from app import db
from app.checklist.score import evaluate
from app.config import Config
from app.timeutil import from_iso, to_iso, trading_day

MATCH_PRICE_PIPS = 1.0
MATCH_STOP_PIPS = 1.0
SOURCES = ("owner", "code")
METHODS = ("owner_tap", "auto_exact_ticket", "auto_match")
OVER_TIER_TOLERANCE = 1.25     # the same tolerance as size_above_risk (app/risk/flags.py)
_TICKET_MAX = 24
_EPS = 1e-9


class NotFoundError(LookupError, ValueError):
    """No setup check with that id."""


def _row(r: sqlite3.Row | None) -> dict | None:
    if r is None:
        return None
    d = dict(r)
    d["fields"] = json.loads(d.pop("fields_json"))
    return d


def _expiry(cfg: Config, now: datetime, fields: dict) -> str:
    if fields.get("expiry_utc"):
        exp = from_iso(fields["expiry_utc"])
        if exp <= now:
            raise ValueError("expiry_utc must be later than now")
        return to_iso(exp)
    d = cfg.day
    day = trading_day(now, d.boundary_tz, d.boundary_hour)
    return to_iso(datetime.combine(day, time(d.boundary_hour), d.boundary_tz))


def _streak_on(conn: sqlite3.Connection, cfg: Config, now: datetime) -> bool:
    from app.risk.flags import streak_now
    return bool(streak_now(conn, cfg, now, "mt5").active)


def _insert(conn, cfg, ev: dict, *, check_id: int | None, version: int, now: datetime, source: str,
            suggestion_id: int | None, status: str, after_entry: int, expiry: str) -> int:
    m, c = ev["must"], ev["checks"]
    cur = conn.execute(
        """INSERT INTO checklist (check_id, version, created_utc, source, suggestion_id, account_alias, symbol, side,
               fields_json, entry, zone_low, zone_high, stop, stop_pips, target, target_r, cost_r, cost_r_info,
               m1, m2, m3, m4, c1, c2, c3, c4, c5, score, tier, risk_share, after_entry, status, expiry_utc)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (check_id or 0, version, to_iso(now), source, suggestion_id, cfg.account.alias, cfg.instrument.symbol,
         ev["side"], json.dumps(ev["fields"], sort_keys=True), ev["entry"], ev["zone_low"], ev["zone_high"],
         ev["stop"], ev["stop_pips"], ev["target"], ev["target_r"], ev["cost_r"], ev["cost_r_info"],
         *(int(m[k]) for k in ("m1", "m2", "m3", "m4")), *(int(c[k]) for k in ("c1", "c2", "c3", "c4", "c5")),
         ev["score"], ev["tier"], ev["risk_share"], after_entry, status, expiry))
    rid = cur.lastrowid
    if check_id is None:
        conn.execute("UPDATE checklist SET check_id = ? WHERE id = ?", (rid, rid))
    return rid


def create_check(conn: sqlite3.Connection, cfg: Config, fields: dict, *, now: datetime, source: str = "owner",
                 suggestion_id: int | None = None) -> dict:
    """Save a new setup check (version 1). Returns it with its computed values."""
    if source not in SOURCES:
        raise ValueError(f"source must be one of {SOURCES}")
    if suggestion_id is not None and (isinstance(suggestion_id, bool) or not isinstance(suggestion_id, int)):
        raise ValueError("suggestion_id must be a whole number")
    with db.transaction(conn):
        ev = evaluate(fields, cfg, streak_on=_streak_on(conn, cfg, now))
        rid = _insert(conn, cfg, ev, check_id=None, version=1, now=now, source=source, suggestion_id=suggestion_id,
                      status="open", after_entry=0, expiry=_expiry(cfg, now, ev["fields"]))
        return _row(conn.execute("SELECT * FROM checklist WHERE id = ?", (rid,)).fetchone())


def get_check(conn: sqlite3.Connection, check_id: int) -> dict:
    """The current (latest) version of a check."""
    r = conn.execute("SELECT * FROM checklist WHERE check_id = ? ORDER BY version DESC LIMIT 1", (check_id,)).fetchone()
    if r is None:
        raise NotFoundError(f"setup check {check_id} not found")
    return _row(r)


def versions(conn: sqlite3.Connection, check_id: int) -> list[dict]:
    return [_row(r) for r in conn.execute("SELECT * FROM checklist WHERE check_id = ? ORDER BY version", (check_id,))]


def locked_version(conn: sqlite3.Connection, check_id: int) -> dict | None:
    return _row(conn.execute("SELECT * FROM checklist WHERE check_id = ? AND locked_utc IS NOT NULL"
                             " ORDER BY version LIMIT 1", (check_id,)).fetchone())


def edit_check(conn: sqlite3.Connection, cfg: Config, check_id: int, fields: dict, *, now: datetime) -> dict:
    """A new version. Before the lock it replaces the current one; after it, it is an after-entry version."""
    with db.transaction(conn):
        cur = get_check(conn, check_id)
        if cur["status"] == "expired":
            raise ValueError("the check has expired")
        ev = evaluate(fields, cfg, streak_on=_streak_on(conn, cfg, now))
        locked = locked_version(conn, check_id) is not None
        if not locked:
            conn.execute("UPDATE checklist SET status = 'superseded' WHERE id = ?", (cur["id"],))
        rid = _insert(conn, cfg, ev, check_id=check_id, version=cur["version"] + 1, now=now, source=cur["source"],
                      suggestion_id=cur["suggestion_id"], status="after_entry" if locked else "open",
                      after_entry=int(locked), expiry=cur["expiry_utc"])
        return _row(conn.execute("SELECT * FROM checklist WHERE id = ?", (rid,)).fetchone())


def links(conn: sqlite3.Connection, check_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute("SELECT * FROM checklist_link WHERE check_id = ? ORDER BY id", (check_id,))]


def _lock(conn: sqlite3.Connection, check_id: int, now: datetime) -> None:
    if locked_version(conn, check_id) is None:
        cur = get_check(conn, check_id)
        conn.execute("UPDATE checklist SET status = 'locked', locked_utc = ? WHERE id = ?", (to_iso(now), cur["id"]))


def _add_link(conn, cfg, check_id: int, now: datetime, method: str, confirmed: int, order_ticket=None,
              position_id=None, trade_id=None) -> dict:
    """A link row. Only a confirmed link locks the check (an auto_match is an offer until the owner confirms)."""
    cur = get_check(conn, check_id)
    lid = conn.execute(
        """INSERT INTO checklist_link (check_id, checklist_row, created_utc, account_alias, order_ticket, position_id,
               trade_id, method, confirmed) VALUES (?,?,?,?,?,?,?,?,?)""",
        (check_id, cur["id"], to_iso(now), cfg.account.alias, order_ticket, position_id, trade_id, method,
         confirmed)).lastrowid
    if confirmed:
        _lock(conn, check_id, now)
    return dict(conn.execute("SELECT * FROM checklist_link WHERE id = ?", (lid,)).fetchone())


def _usable(cur: dict, now: datetime) -> None:
    if cur["status"] == "expired" or (cur["status"] == "open" and from_iso(cur["expiry_utc"]) < now):
        raise ValueError("the check has expired")


def _ticket(value) -> str:
    text = str(value) if isinstance(value, int) and not isinstance(value, bool) else value
    if not isinstance(text, str) or not text.isdigit() or len(text) > _TICKET_MAX:
        raise ValueError("order_ticket must be the order's ticket number")
    return text


def tap_link(conn: sqlite3.Connection, cfg: Config, check_id: int, order_ticket, *, now: datetime) -> dict:
    """The owner taps "This is my order" on a pending order after saving the check: the order must be a pending
    EUR/USD order on the check's side in the latest snapshot."""
    ticket = _ticket(order_ticket)
    with db.transaction(conn):
        cur = get_check(conn, check_id)
        _usable(cur, now)
        order = next((o for o in _pending_orders(conn, cfg) if o["ticket"] == ticket), None)
        if order is None or not cfg.is_eurusd(order["symbol"]):
            raise ValueError("no pending EUR/USD order with that ticket in the latest snapshot")
        if order["side"] != cur["side"]:
            raise ValueError("the order is on the other side")
        return _add_link(conn, cfg, check_id, now, "owner_tap", 1, order_ticket=ticket)


def tap_trade(conn: sqlite3.Connection, cfg: Config, check_id: int, trade_id: int, *, now: datetime) -> dict:
    """The owner picks an MT5 trade for the check (a fill he links by hand, or one leg of a ladder)."""
    with db.transaction(conn):
        cur = get_check(conn, check_id)
        if cur["status"] == "expired":
            raise ValueError("the check has expired")
        t = conn.execute("SELECT * FROM trade WHERE id = ? AND book = 'mt5'", (trade_id,)).fetchone()
        if t is None:
            raise ValueError("no MT5 trade with that id")
        if t["side"] != cur["side"]:
            raise ValueError("the trade is on the other side")
        return _add_link(conn, cfg, check_id, now, "owner_tap", 1, position_id=t["broker_position_id"],
                         trade_id=t["id"])


def _link_row(conn: sqlite3.Connection, link_id: int) -> sqlite3.Row:
    r = conn.execute("SELECT * FROM checklist_link WHERE id = ?", (link_id,)).fetchone()
    if r is None:
        raise NotFoundError(f"link {link_id} not found")
    return r


def confirm_link(conn: sqlite3.Connection, link_id: int, *, now: datetime) -> dict:
    """The owner confirms an offered match: the link counts from now and locks the check."""
    with db.transaction(conn):
        r = _link_row(conn, link_id)
        if r["rejected_utc"]:
            raise ValueError("that match was rejected")
        conn.execute("UPDATE checklist_link SET confirmed = 1 WHERE id = ?", (link_id,))
        if r["order_ticket"]:      # the fill of a confirmed order counts too
            conn.execute("UPDATE checklist_link SET confirmed = 1 WHERE check_id = ? AND order_ticket = ?"
                         " AND method = 'auto_exact_ticket' AND rejected_utc IS NULL", (r["check_id"], r["order_ticket"]))
        _lock(conn, r["check_id"], now)
        return dict(_link_row(conn, link_id))


def reject_link(conn: sqlite3.Connection, link_id: int, *, now: datetime) -> dict:
    """The owner says an offered match is not this check's trade. It is never offered to this check again."""
    with db.transaction(conn):
        r = _link_row(conn, link_id)
        if r["confirmed"]:
            raise ValueError("a confirmed link stays; only an offered match can be rejected")
        conn.execute("UPDATE checklist_link SET rejected_utc = ? WHERE id = ? OR (check_id = ? AND confirmed = 0"
                     " AND order_ticket IS NOT NULL AND order_ticket = ?)",
                     (to_iso(now), link_id, r["check_id"], r["order_ticket"]))
        return dict(_link_row(conn, link_id))


def _pending_orders(conn: sqlite3.Connection, cfg: Config) -> list[dict]:
    from app.ingest.live import _clock
    row = conn.execute("SELECT * FROM bridge_status WHERE account_alias = ?", (cfg.account.alias,)).fetchone()
    if row is None:
        return []
    try:
        orders = json.loads(row["snapshot_json"]).get("orders") or []
    except (ValueError, TypeError, AttributeError):
        return []
    clock = _clock(cfg, row)
    out = []
    for o in orders:
        if not isinstance(o, dict) or not str(o.get("type", "")).startswith(("buy", "sell")):
            continue
        out.append({"ticket": str(o["ticket"]), "symbol": o["symbol"], "side": o["type"].split("_")[0],
                    "price": o["price"], "sl": o["sl"], "at": clock.to_utc(int(o["setup_time"]))})
    return out


def _linked_tickets(conn: sqlite3.Connection) -> tuple[set[str], set[int]]:
    tickets, trades = set(), set()
    for r in conn.execute("SELECT order_ticket, position_id, trade_id FROM checklist_link WHERE rejected_utc IS NULL"):
        if r["order_ticket"]:
            tickets.add(r["order_ticket"])
        if r["position_id"]:
            tickets.add(r["position_id"])
        if r["trade_id"] is not None:
            trades.add(r["trade_id"])
    return tickets, trades


def _fits(cfg: Config, chk: dict, side: str, symbol: str, price, sl, at: datetime) -> bool:
    pip = cfg.instrument.pip_size
    if side != chk["side"] or not cfg.is_eurusd(symbol) or price is None or sl is None:
        return False
    if not from_iso(chk["created_utc"]) <= at <= from_iso(chk["expiry_utc"]):
        return False
    in_zone = chk["zone_low"] - MATCH_PRICE_PIPS * pip - _EPS <= price <= chk["zone_high"] + MATCH_PRICE_PIPS * pip + _EPS
    return in_zone and abs(sl - chk["stop"]) <= MATCH_STOP_PIPS * pip + _EPS


def _fill_of(conn: sqlite3.Connection, cfg: Config, ticket: str) -> sqlite3.Row | None:
    """The MT5 trade an order ticket filled into: by the entry deal's order id, then by the position ticket."""
    d = conn.execute("SELECT position_id FROM deal WHERE account_alias = ? AND order_id = ? AND entry IN ('in','inout')"
                     " ORDER BY time_utc LIMIT 1", (cfg.account.alias, ticket)).fetchone()
    pid = d["position_id"] if d is not None else ticket
    return conn.execute("SELECT * FROM trade WHERE book = 'mt5' AND account_alias = ? AND broker_position_id = ?",
                        (cfg.account.alias, pid)).fetchone()


def resolve_links(conn: sqlite3.Connection, cfg: Config, *, now: datetime) -> list[dict]:
    """Link fills of linked orders by ticket, offer auto-matches, and expire unlinked checks past their expiry.
    Returns the links written. Running twice writes nothing new."""
    made: list[dict] = []
    with db.transaction(conn):
        current = [_row(r) for r in conn.execute(
            "SELECT * FROM checklist c WHERE version = (SELECT MAX(version) FROM checklist WHERE check_id = c.check_id)"
            " AND account_alias = ?", (cfg.account.alias,))]
        for chk in current:                                        # fills of linked orders
            for ln in links(conn, chk["check_id"]):
                if not ln["order_ticket"] or ln["trade_id"] is not None or ln["rejected_utc"]:
                    continue
                t = _fill_of(conn, cfg, ln["order_ticket"])
                if t is None or conn.execute("SELECT 1 FROM checklist_link WHERE check_id = ? AND trade_id = ?",
                                             (chk["check_id"], t["id"])).fetchone():
                    continue
                made.append(_add_link(conn, cfg, chk["check_id"], now, "auto_exact_ticket", ln["confirmed"],
                                      order_ticket=ln["order_ticket"], position_id=t["broker_position_id"],
                                      trade_id=t["id"]))
        tickets, trade_ids = _linked_tickets(conn)
        orders = _pending_orders(conn, cfg)
        trades = [dict(r) for r in conn.execute("SELECT * FROM trade WHERE book = 'mt5' AND account_alias = ?",
                                                (cfg.account.alias,))]
        for chk in current:                                        # auto-match for unlinked open checks
            own = links(conn, chk["check_id"])
            if chk["status"] != "open" or any(not ln["rejected_utc"] for ln in own):
                continue
            if from_iso(chk["expiry_utc"]) < now:
                conn.execute("UPDATE checklist SET status = 'expired' WHERE id = ?", (chk["id"],))
                continue
            refused = {ln["order_ticket"] for ln in own if ln["order_ticket"]} | \
                {ln["position_id"] for ln in own if ln["position_id"]}
            refused_trades = {ln["trade_id"] for ln in own if ln["trade_id"] is not None}
            cands = [("order", o) for o in orders if o["ticket"] not in tickets and o["ticket"] not in refused
                     and _fits(cfg, chk, o["side"], o["symbol"], o["price"], o["sl"], o["at"])]
            order_tickets = {o["ticket"] for _, o in cands}
            cands += [("trade", t) for t in trades if t["id"] not in trade_ids and t["id"] not in refused_trades
                      and t["broker_position_id"] not in refused
                      and t["broker_position_id"] not in tickets and t["broker_position_id"] not in order_tickets
                      and _fits(cfg, chk, t["side"], t["symbol"], t["open_price"], t["initial_sl"],
                                from_iso(t["open_utc"]))]
            if len(cands) != 1:
                continue
            kind, c = cands[0]
            if kind == "order":
                ln = _add_link(conn, cfg, chk["check_id"], now, "auto_match", 0, order_ticket=c["ticket"])
                tickets.add(c["ticket"])
            else:
                ln = _add_link(conn, cfg, chk["check_id"], now, "auto_match", 0, position_id=c["broker_position_id"],
                               trade_id=c["id"])
                trade_ids.add(c["id"])
            made.append(ln)
    return made


def _linked_trades(conn: sqlite3.Connection, check_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT DISTINCT t.* FROM checklist_link l JOIN trade t ON t.id = l.trade_id WHERE l.check_id = ?"
        " AND l.confirmed = 1 AND l.rejected_utc IS NULL ORDER BY t.open_utc, t.id", (check_id,))]


def check_result(conn: sqlite3.Connection, check_id: int) -> dict:
    """The check's closed trades together: R = sum of net / sum of planned risk (a ladder counts by risk)."""
    ts = [t for t in _linked_trades(conn, check_id) if t["status"] == "closed" and t["risk_money"]]
    risk = sum(t["risk_money"] for t in ts)
    net = sum(t["net_profit"] for t in ts)
    return {"trades": len(ts), "risk_money": risk, "net_profit": net, "r": net / risk if risk > 0 else None}


def checks_for_trade(conn: sqlite3.Connection, trade_id: int) -> list[int]:
    return [r[0] for r in conn.execute("SELECT DISTINCT check_id FROM checklist_link WHERE trade_id = ?"
                                       " AND confirmed = 1 AND rejected_utc IS NULL", (trade_id,))]


def first_owner_check_utc(conn: sqlite3.Connection, alias: str) -> str | None:
    r = conn.execute("SELECT MIN(created_utc) FROM checklist WHERE source = 'owner' AND account_alias = ?",
                     (alias,)).fetchone()
    return r[0]


def results_by_tick(conn: sqlite3.Connection, cfg: Config) -> dict:
    """R by check tick (with / without) and by score, from checks locked before their entry. "too early" under
    analytics.min_trades setups."""
    used: list[tuple[dict, float]] = []
    left_out = 0
    for (check_id,) in conn.execute("SELECT DISTINCT check_id FROM checklist_link WHERE trade_id IS NOT NULL"
                                    " AND confirmed = 1 AND rejected_utc IS NULL"):
        res = check_result(conn, check_id)
        if res["r"] is None:
            continue
        v = locked_version(conn, check_id)
        first_open = min(t["open_utc"] for t in _linked_trades(conn, check_id))
        if v is None or v["after_entry"] or v["created_utc"] > first_open:
            left_out += 1
            continue
        used.append((v, res["r"]))

    def agg(rows: list[float]) -> dict:
        return {"trades": len(rows), "mean_r": mean(rows) if rows else None}

    out: dict = {"setups": len(used), "left_out": left_out, "too_early": len(used) < cfg.analytics.min_trades}
    for k in ("c1", "c2", "c3", "c4", "c5"):
        out[k] = {"with": agg([r for v, r in used if v[k]]), "without": agg([r for v, r in used if not v[k]])}
    out["score"] = {str(s): agg([r for v, r in used if v["score"] == s]) for s in range(6)}
    return out


def list_checks(conn: sqlite3.Connection, cfg: Config, limit: int = 50) -> list[dict]:
    out = []
    for (check_id,) in conn.execute("SELECT DISTINCT check_id FROM checklist WHERE account_alias = ?"
                                    " ORDER BY check_id DESC LIMIT ?", (cfg.account.alias, limit)):
        chk = get_check(conn, check_id)
        chk["links"] = links(conn, check_id)
        chk["result"] = check_result(conn, check_id)
        out.append(chk)
    return out


def checklist_flags(conn: sqlite3.Connection, cfg: Config, t) -> list[tuple[str, str]]:
    """no_checklist, below_tier and over_tier_risk for one MT5 trade (app/risk/flags.py)."""
    if t["book"] != "mt5":
        return []
    ids = checks_for_trade(conn, t["id"])
    if not ids:
        # The form is EUR/USD only, and a late tap after the fill is allowed: only closed EUR/USD trades (red team 5).
        if t["status"] != "closed" or not cfg.is_eurusd(t["symbol"]):
            return []
        first = first_owner_check_utc(conn, t["account_alias"])
        if first is not None and first <= t["open_utc"]:
            return [("no_checklist", "no setup check linked")]
        return []
    out: list[tuple[str, str]] = []
    for check_id in ids:
        v = locked_version(conn, check_id) or get_check(conn, check_id)
        if v["tier"] == "none":
            out.append(("below_tier", f"setup check score {v['score']} with a must-have missing or under 3"
                        if not all(v[m] for m in ("m1", "m2", "m3", "m4")) else
                        f"setup check score {v['score']}: no trade"))
            continue
        bal = t["balance_at_open"]
        risk = sum(x["risk_money"] or 0.0 for x in _linked_trades(conn, check_id))
        if bal and risk:
            pct = risk / bal * 100.0
            allowed = v["risk_share"] * cfg.risk.risk_pct_per_trade
            if pct > OVER_TIER_TOLERANCE * allowed:
                out.append(("over_tier_risk", f"risked {pct:.3f}% of balance on a {v['tier']} tier check"))
    return out
