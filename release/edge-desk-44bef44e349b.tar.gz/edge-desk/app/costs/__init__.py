"""Cost per trade: the spread at the fill, quote drift, commission, swap, fee and month rows (A4)."""
