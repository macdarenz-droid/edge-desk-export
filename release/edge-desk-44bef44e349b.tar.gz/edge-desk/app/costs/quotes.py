"""Quote samples from bridge snapshots, and the quote fixed for each deal when it is first stored (A4).

- Every snapshot stores each symbol's bid and ask at the snapshot's own time (gmt_time) with its New York hour.
- A buy or sell deal, when first stored, gets the first sample of its symbol at or after the fill and at most
  SNAPSHOT_WINDOW_S later: source 'snapshot', with the drift = the fill minus the sample's ask (buy deal) or bid
  (sell deal). Else the median spread of at least MIN_MEDIAN_SAMPLES samples taken before the fill in the same New
  York hour: source 'own_median' (mid = the fill minus or plus half that spread, drift unknown). Else 'unknown'.
  The app never invents a spread.
- The row is written once (INSERT OR IGNORE): later snapshots never change it.
- Samples are taken only while the FX market is open (weekend quotes would skew the median), kept in full for 48 h
  (the 10 s window at first storage), then one a minute (the first sample in each minute's first 5 s) up to 90
  days, then dropped: at most about 35 MB for three symbols (red team 2 and 3). prune_samples runs at most once an
  hour from record_samples.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta
from statistics import median

from app.timeutil import NEW_YORK, from_iso, market_open, to_iso

SNAPSHOT_WINDOW_S = 10
MIN_MEDIAN_SAMPLES = 30
FULL_DETAIL = timedelta(hours=48)
KEEP = timedelta(days=90)
PRUNE_EVERY = timedelta(hours=1)


def _pip_size(cfg, symbol, info):
    from app.ingest.state import pip_size        # here, not at import: app.ingest imports this module
    return pip_size(cfg, symbol, info)


def prune_samples(conn: sqlite3.Connection, now: datetime) -> None:
    """Drop samples older than 90 days, and keep one a minute of those older than 48 h."""
    conn.execute("DELETE FROM quote_sample WHERE at_utc < ?", (to_iso(now - KEEP),))
    conn.execute("DELETE FROM quote_sample WHERE at_utc < ? AND CAST(substr(at_utc, 18, 2) AS INTEGER) >= 5",
                 (to_iso(now - FULL_DETAIL),))
    conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('quote_sample_pruned', ?)", (to_iso(now),))


def record_samples(conn: sqlite3.Connection, cfg, alias: str, symbols: dict, at: datetime) -> None:
    """Store one sample per symbol ({symbol: {"bid", "ask", ...}}) taken at `at`, while the market is open."""
    if not market_open(at):
        return
    last = conn.execute("SELECT value FROM meta WHERE key = 'quote_sample_pruned'").fetchone()
    if last is None or from_iso(last[0]) <= at - PRUNE_EVERY:
        prune_samples(conn, at)          # pruned even while raw samples are stopped
    from app.storage import raw_allowed
    if not raw_allowed(conn):        # A10: low disk or over budget: no new raw samples (trades are still stored)
        return
    hour = at.astimezone(NEW_YORK).hour
    for name, info in symbols.items():
        bid, ask = (info.get("bid"), info.get("ask")) if isinstance(info, dict) else (info.bid, info.ask)
        if not bid or not ask or ask < bid:
            continue
        pip = _pip_size(cfg, name, info if isinstance(info, dict) else {"point": info.point, "digits": info.digits})
        if not pip:
            continue
        conn.execute("INSERT OR IGNORE INTO quote_sample (account_alias, symbol, at_utc, bid, ask, spread_pips, ny_hour)"
                     " VALUES (?, ?, ?, ?, ?, ?, ?)", (alias, name, to_iso(at), bid, ask, round((ask - bid) / pip, 6), hour))


def _pip(conn, cfg, alias: str, symbol: str) -> float | None:
    from app.ingest.state import known_symbols
    return _pip_size(cfg, symbol, known_symbols(conn, alias).get(symbol))


def quote_for_deal(conn: sqlite3.Connection, cfg, alias: str, d: dict) -> dict:
    """The quote for one buy or sell deal (a row of the deal table), from the samples stored so far."""
    fill_at = from_iso(d["time_utc"])
    pip = _pip(conn, cfg, alias, d["symbol"])
    out = {"source": "unknown", "bid": None, "ask": None, "mid": None, "spread_pips": None, "drift_pips": None,
           "lag_s": None, "samples": None}
    if not pip:
        return out
    s = conn.execute("SELECT * FROM quote_sample WHERE account_alias = ? AND symbol = ? AND at_utc >= ? AND at_utc <= ?"
                     " ORDER BY at_utc LIMIT 1", (alias, d["symbol"], d["time_utc"],
                                                  to_iso(fill_at + timedelta(seconds=SNAPSHOT_WINDOW_S)))).fetchone()
    if s is not None:
        side_px = s["ask"] if d["type"] == "buy" else s["bid"]
        out.update(source="snapshot", bid=s["bid"], ask=s["ask"], mid=(s["bid"] + s["ask"]) / 2,
                   spread_pips=s["spread_pips"], drift_pips=round((d["price"] - side_px) / pip, 6),
                   lag_s=int((from_iso(s["at_utc"]) - fill_at).total_seconds()))
        return out
    hour = fill_at.astimezone(NEW_YORK).hour
    spreads = [r[0] for r in conn.execute(
        "SELECT spread_pips FROM quote_sample WHERE account_alias = ? AND symbol = ? AND ny_hour = ? AND at_utc < ?",
        (alias, d["symbol"], hour, d["time_utc"]))]
    if len(spreads) >= MIN_MEDIAN_SAMPLES:
        sp = median(spreads)
        half = sp * pip / 2
        out.update(source="own_median", spread_pips=sp, samples=len(spreads),
                   mid=d["price"] - half if d["type"] == "buy" else d["price"] + half)
    return out


def store_new_deal_quotes(conn: sqlite3.Connection, cfg, alias: str, now_iso: str) -> int:
    """Fix the quote of every buy or sell deal that has none yet. Returns the number written."""
    rows = conn.execute(
        "SELECT d.* FROM deal d LEFT JOIN deal_quote q ON q.account_alias = d.account_alias AND q.deal_id = d.deal_id"
        " WHERE d.account_alias = ? AND q.deal_id IS NULL AND d.type IN ('buy', 'sell')", (alias,)).fetchall()
    for d in rows:
        q = quote_for_deal(conn, cfg, alias, dict(d))
        conn.execute("INSERT OR IGNORE INTO deal_quote (account_alias, deal_id, source, bid, ask, mid, spread_pips,"
                     " drift_pips, lag_s, samples, stored_utc) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                     (alias, d["deal_id"], q["source"], q["bid"], q["ask"], q["mid"], q["spread_pips"],
                      q["drift_pips"], q["lag_s"], q["samples"], now_iso))
    return len(rows)
