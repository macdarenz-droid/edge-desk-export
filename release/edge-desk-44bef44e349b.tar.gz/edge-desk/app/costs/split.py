"""The cost split of an MT5 trade and the month rows (A4).

For a trade with known quotes (pips, signed so that a cost is positive):
  chart move   (mid_out - mid_in) x direction / pip                       (gross_mid_pips: before every cost)
  spread       (spread_in + spread_out) / 2                               (half the spread on each side)
  quote drift  direction x (drift_in - drift_out)                         (fill minus the snapshot's quote)
  commission, swap, fee   minus the money / the money per pip of the trade's volume
  net          price result (close - open) x direction / pip + commission + swap + fee in pips (net_pips)
The identity chart move - spread - quote drift - commission - swap - fee = net holds by construction to float
noise; tests/test_costs.py checks it to 0.01 pip on buys, sells and partial closes. An own-median quote has no
drift (0); an unknown quote has no chart move (None), and the screens then show "R before commission and swap".
Money per pip: risk_money / stop_pips when the trade has a stop (the bridge's tick data), else 10 x lots for
EUR/USD on a USD account (contract 100,000), else unknown.
Research costs (2.0 pips, OANDA spreads) never appear here: these are the owner's own trade costs.
"""
from __future__ import annotations

import sqlite3
from collections import defaultdict

TRADE_TYPES = ("buy", "sell")
# Deal types that are account charges, not trades (deposits, withdrawals, credit and bonus are not costs).
CHARGE_TYPES = ("commission", "charge", "correction", "interest", "other")


def money_per_pip(cfg, t: dict) -> float | None:
    if t.get("risk_money") and t.get("stop_pips"):
        return float(t["risk_money"]) / float(t["stop_pips"])
    if cfg.is_eurusd(t["symbol"]) and t.get("volume"):
        return 100_000 * cfg.instrument.pip_size * float(t["volume"])
    return None


def _pip(cfg, t: dict) -> float | None:
    if cfg.is_eurusd(t["symbol"]):
        return cfg.instrument.pip_size
    if t.get("stop_pips") and t.get("initial_sl") is not None:
        return abs(float(t["open_price"]) - float(t["initial_sl"])) / float(t["stop_pips"])
    return None


def cost_split(t: dict, cfg) -> dict:
    """Every part of one closed trade's result in pips (None where unknown)."""
    pip, mpp = _pip(cfg, t), money_per_pip(cfg, t)
    d = 1.0 if t["side"] == "buy" else -1.0
    out = {"chart_pips": None, "spread_pips": None, "drift_pips": None, "commission_pips": None, "swap_pips": None,
           "fee_pips": None, "price_pips": None, "net_pips": None, "source": t.get("spread_source")}
    if not pip or not mpp or t.get("close_price") is None:
        return out
    price = (float(t["close_price"]) - float(t["open_price"])) * d / pip
    costs = {k: -float(t.get(k) or 0.0) / mpp for k in ("commission", "swap", "fee")}
    out.update(price_pips=price, commission_pips=costs["commission"], swap_pips=costs["swap"], fee_pips=costs["fee"],
               net_pips=price - sum(costs.values()))
    if t.get("mid_in") is not None and t.get("mid_out") is not None and t.get("spread_in_pips") is not None \
            and t.get("spread_out_pips") is not None:
        din = t.get("quote_drift_in_pips") or 0.0
        dout = t.get("quote_drift_out_pips") or 0.0
        out.update(chart_pips=(float(t["mid_out"]) - float(t["mid_in"])) * d / pip,
                   spread_pips=(float(t["spread_in_pips"]) + float(t["spread_out_pips"])) / 2,
                   drift_pips=d * (din - dout))
    return out


def _vw(rows: list[tuple[float, float | None]]) -> float | None:
    """Volume-weighted mean of (volume, value); None if any value is missing."""
    if not rows or any(v is None for _, v in rows):
        return None
    vol = sum(w for w, _ in rows)
    return sum(w * v for w, v in rows) / vol if vol > 0 else None


_RANK = {"snapshot": 0, "own_median": 1, "unknown": 2}


def trade_cost_columns(cfg, side: str, entries: list[dict], exits: list[dict], quotes: dict[str, dict],
                       pip: float | None, closed: bool, sl_at_exit: float | None, row: dict) -> dict:
    """The schema 3 cost columns of one MT5 trade from its deals and their fixed quotes."""
    out = dict.fromkeys(("mid_in", "mid_out", "spread_in_pips", "spread_out_pips", "quote_drift_in_pips",
                         "quote_drift_out_pips", "spread_source", "quote_lag_s", "slip_exit_pips", "gross_mid_pips",
                         "net_pips"))
    deals = entries + (exits if closed else [])
    if not pip or not entries:
        return out
    qs = [quotes.get(dl["deal_id"]) or {"source": "unknown"} for dl in deals]
    out["spread_source"] = max((q["source"] for q in qs), key=_RANK.__getitem__)
    lags = [q.get("lag_s") for q in qs if q.get("lag_s") is not None]
    out["quote_lag_s"] = max(lags) if lags else None

    def side_cols(ds: list[dict]):
        rows = [(dl["volume"], quotes.get(dl["deal_id"]) or {}) for dl in ds]
        mid = _vw([(w, q.get("mid")) for w, q in rows])
        spread = _vw([(w, q.get("spread_pips")) for w, q in rows])
        drift = _vw([(w, q.get("drift_pips")) for w, q in rows])
        return mid, spread, drift

    out["mid_in"], out["spread_in_pips"], out["quote_drift_in_pips"] = side_cols(entries)
    if closed and exits:
        out["mid_out"], out["spread_out_pips"], out["quote_drift_out_pips"] = side_cols(exits)
        d = 1.0 if side == "buy" else -1.0
        if out["mid_in"] is not None and out["mid_out"] is not None:
            out["gross_mid_pips"] = round((out["mid_out"] - out["mid_in"]) * d / pip, 6)
        last = exits[-1]
        if last["reason"] == "sl" and sl_at_exit is not None:
            out["slip_exit_pips"] = round((sl_at_exit - last["price"]) * d / pip, 6)
        split = cost_split({**row, **out}, cfg)
        out["net_pips"] = None if split["net_pips"] is None else round(split["net_pips"], 6)
    return out


def month_costs(conn: sqlite3.Connection, cfg, book: str = "mt5", alias: str | None = None) -> list[dict]:
    """One row per month of closed trades (by close trading day): R and money by cost, net pips and money, and
    account charges not tied to a trade (by deal time). Chart move, spread and quote drift cover only the trades
    whose quote is known: spread_known says how many, and the screen shows it beside them."""
    alias = alias or cfg.account.alias
    months: dict[str, dict] = defaultdict(lambda: {
        "trades": 0, "chart_r": 0.0, "chart_known": 0, "spread_known": 0, "spread_r": 0.0, "drift_r": 0.0, "commission": 0.0,
        "swap": 0.0, "fee": 0.0, "commission_r": 0.0, "swap_r": 0.0, "fee_r": 0.0, "net_r": 0.0, "net_pips": 0.0,
        "net_money": 0.0, "other_charges": 0.0})
    for r in conn.execute("SELECT * FROM trade WHERE book = ? AND account_alias = ? AND status = 'closed'"
                          " AND close_trading_day IS NOT NULL", (book, alias)):
        t = dict(r)
        m = months[t["close_trading_day"][:7]]
        s = cost_split(t, cfg)
        stop = t.get("stop_pips")
        m["trades"] += 1
        m["commission"] += t["commission"]
        m["swap"] += t["swap"]
        m["fee"] += t["fee"]
        m["net_money"] += t["net_profit"]
        m["net_r"] += t["r_net"] or 0.0
        if s["net_pips"] is not None:
            m["net_pips"] += s["net_pips"]
        if stop:
            for k in ("commission", "swap", "fee"):
                if s[f"{k}_pips"] is not None:
                    m[f"{k}_r"] -= s[f"{k}_pips"] / stop
            if s["chart_pips"] is not None:
                m["chart_known"] += 1
                m["spread_known"] += 1
                m["chart_r"] += s["chart_pips"] / stop
                m["spread_r"] -= s["spread_pips"] / stop
                m["drift_r"] -= s["drift_pips"] / stop
    from app.timeutil import from_iso, trading_day
    d = cfg.day
    for r in conn.execute(f"SELECT * FROM deal WHERE account_alias = ? AND type IN ({','.join('?' * len(CHARGE_TYPES))})"
                          " AND (position_id IS NULL OR position_id IN ('', '0'))", (alias, *CHARGE_TYPES)):
        month = trading_day(from_iso(r["time_utc"]), d.boundary_tz, d.boundary_hour).isoformat()[:7]
        months[month]["other_charges"] += r["profit"] + r["commission"] + r["swap"] + r["fee"]
    out = []
    for month in sorted(months):
        m = months[month]
        costs_r = m["spread_r"] + m["drift_r"] + m["commission_r"] + m["swap_r"] + m["fee_r"]
        out.append({"month": month, **m, "cost_r": costs_r,
                    "cost_per_trade_r": costs_r / m["trades"] if m["trades"] else None})
    return out
