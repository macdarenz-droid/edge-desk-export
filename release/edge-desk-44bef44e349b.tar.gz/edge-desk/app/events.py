"""Events the ingest step emits for the notifier. Each carries a unique key so an alert is sent once."""
from __future__ import annotations

from dataclasses import dataclass, field

EVENT_KINDS = frozenset({
    "position_opened",     # a new MT5 position (an order filled)
    "position_closed",     # a position fully closed; data has the trade row's results
    "stop_changed",        # stop or target moved on an open position
    "no_stop",             # an open position has no stop (hard incident)
    "terminal_can_trade",  # the bridge terminal is not on an investor login (hard incident)
    "order_placed",        # a new pending order
    "order_removed",       # a pending order is gone (filled, cancelled or expired)
    "clock_mismatch",      # the broker clock rule disagrees with the clock the EA measured
})


@dataclass(frozen=True)
class Event:
    kind: str
    key: str               # unique, stable: e.g. "position_opened:main:123456"
    at_utc: str            # ISO-8601 UTC
    data: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.kind not in EVENT_KINDS:
            raise ValueError(f"unknown event kind {self.kind!r}")
