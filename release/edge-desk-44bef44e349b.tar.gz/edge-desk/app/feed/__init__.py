"""B1 price feed: OANDA practice EUR/USD M1 bid/ask candles (app/feed/oanda.py)."""
