"""B1 price feed: EUR/USD 1-minute bid/ask candles from OANDA practice, and nothing else.

Sources (read 17 Oct 2026; OANDA's pages change, check them again before relying on a detail):
- https://developer.oanda.com/rest-live-v20/development-guide/ : practice host https://api-fxpractice.oanda.com;
  REST limit 120 requests per second per IP, excess gets HTTP 429; at most 2 new connections per second.
- https://developer.oanda.com/rest-live-v20/pricing-ep/ : the candles parameters (price, granularity, from, to;
  "count ... [default=500, maximum=5000]"; count is not given with both from and to; includeFirst default True),
  documented there for /v3/accounts/{accountID}/instruments/{instrument}/candles. The account-free path used here,
  /v3/instruments/{instrument}/candles, is the one the research downloader used on practice
  (research/data/oanda_download.py, read, never imported); its own page
  https://developer.oanda.com/rest-live-v20/instrument-ep/ returned 404 on 17 Oct 2026.
- https://developer.oanda.com/rest-live-v20/instrument-df/ : Candlestick {time, bid, ask, mid, volume, complete};
  "A complete candlestick is one whose ending time is not in the future."
- https://developer.oanda.com/rest-live-v20/authentication/ : "Authorization: Bearer <token>". The same token
  reaches /v3/accounts (the page's own example), so the token is NOT limited to candles: the path and parameter
  allow-list below is what keeps this client to candles.

Limits (coordinator ruling 5, 16 Oct 2026; config [feed], ceilings pinned by tests/test_feed.py): at most one
request every min_gap_s (2 s; the last request time is kept in the DB, so a restart waits too); Retry-After is
honoured; the first 403 or 429 blocks the host for block_hours (24 h, or Retry-After if longer), kept in the DB; 3
failures in a row stop the feed for max(cooldown_s, Retry-After). One gate per host (fix round 1, RULINGS R7 amended
item 2): the Client keeps the host's failures in a row, whoever sent them (the feed or the move record job), and a
not-before time (Retry-After, the 2^n s back-off, or the cool-down after the third in a row) in feed_state; no
client of that host sends before it (HostWait, nothing sent). Complete candles only; a fresh DB backfills backfill_days (120), then
polls from the last saved bar. "Complete through T" (every minute that opened before T is final in the DB) is written
only from a poll made at least marker_delay_s after T, and never past a candle the server still calls incomplete:
a minute with no ticks has no candle, so only the marker tells the worker "no candle" from "not fetched yet".
The token is never logged, stored or put in an exception; response bodies are never kept.
"""
from __future__ import annotations

import email.utils
import http.client
import json
import logging
import math
import sqlite3
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from urllib.parse import urlencode, urlsplit

from app import db

log = logging.getLogger("app.feed")

HOST = "https://api-fxpractice.oanda.com"
CANDLES_PATH = "/v3/instruments/EUR_USD/candles"
ALLOWED_PATHS = frozenset({CANDLES_PATH})
FIXED_PARAMS = {"price": "BA", "granularity": "M1"}
ALLOWED_PARAMS = frozenset({"price", "granularity", "from", "to"})
MAX_CANDLES = 5000                     # OANDA's documented maximum per request
PRICE_FIELDS = ("bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")
UTC = timezone.utc


class FeedError(RuntimeError):
    """A feed failure. Messages hold status codes and times only: never the token or a response body.
    retryable: a 5xx or a network error (only these may resume after the cool-down; red team 17 Oct, item 2)."""

    def __init__(self, msg: str, code: int | None = None, retry_after: float | None = None,
                 retryable: bool = False):
        super().__init__(msg)
        self.code = code
        self.retry_after = retry_after
        self.retryable = retryable


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Never follow a redirect: urllib would carry the Authorization header to the new URL, past the allow-list
    (red team 17 Oct, item 1). A 3xx then comes back as an HTTPError and counts as a failure."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


OPENER = urllib.request.build_opener(_NoRedirect)


class PathRefused(FeedError):
    """A path, parameter or host outside the allow-list; raised before anything is sent."""


class FeedBlocked(FeedError):
    """A 403 or 429: the host is blocked (DB row in feed_block)."""


class FeedStopped(FeedError):
    """max_failures failures in a row: the feed waits max(cooldown_s, Retry-After)."""


class HostWait(FeedError):
    """The host's not-before time has not come (a Retry-After, a back-off or a cool-down that the feed or the move
    record job received): raised before anything is sent. `until` is unix seconds."""

    def __init__(self, msg: str, until: float):
        super().__init__(msg)
        self.until = until


# ---------------------------------------------------------------- state in the DB

def state(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM feed_state WHERE key = ?", (key,)).fetchone()
    return None if row is None else row[0]


def set_state(conn: sqlite3.Connection, key: str, value) -> None:
    with db.transaction(conn):
        conn.execute("INSERT INTO feed_state (key, value) VALUES (?, ?)"
                     " ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, str(value)))


def complete_through(conn: sqlite3.Connection) -> int | None:
    v = state(conn, "complete_through")
    return None if v is None else int(v)


def set_complete_through(conn: sqlite3.Connection, t: int) -> None:
    """The marker only moves forward."""
    with db.transaction(conn):
        cur = complete_through(conn)
        if cur is None or int(t) > cur:
            set_state(conn, "complete_through", int(t))


def reset_halt(conn: sqlite3.Connection) -> None:
    """The owner's (or his helper's) reset after a halt: python -m app feed --reset-halt."""
    with db.transaction(conn):
        conn.execute("DELETE FROM feed_state WHERE key IN ('halted', 'stopped_until', 'failures')")


def not_before(conn: sqlite3.Connection, now: float) -> float | None:
    """The host's not-before time when it is still ahead, else None (feed_state not_before)."""
    v = state(conn, "not_before")
    try:
        t = None if v is None else float(v)
    except ValueError:
        return None
    return t if t is not None and t > now else None


def host_gate(conn: sqlite3.Connection, host: str, now: float) -> tuple[str, float | None] | None:
    """Why nothing may be sent to the OANDA host now, as the feed and the move record job both read it: (reason,
    until; None for a halt), or None when a request may go."""
    if state(conn, "halted"):
        return "feed halted", None
    b = blocked_until(conn, host, now)
    if b is not None:
        return "host blocked", b
    st = state(conn, "stopped_until")
    if st is not None and float(st) > now:
        return "feed stopped", float(st)
    nb = not_before(conn, now)
    if nb is not None:
        return "host waits", nb
    return None


def blocked_until(conn: sqlite3.Connection, host: str, now: float) -> float | None:
    row = conn.execute("SELECT MAX(until_utc) FROM feed_block WHERE host = ?", (host,)).fetchone()
    if row is None or row[0] is None:
        return None
    until = _ts(row[0])
    return until if until > now else None


def history_days(conn: sqlite3.Connection, now: float) -> float:
    row = conn.execute("SELECT MIN(ts) FROM m1_bar").fetchone()
    return 0.0 if row is None or row[0] is None else (now - row[0]) / 86400.0


def last_bar(conn: sqlite3.Connection) -> int | None:
    row = conn.execute("SELECT MAX(ts) FROM m1_bar").fetchone()
    return None if row is None else row[0]


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(int(ts), UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _ts(text: str) -> float:
    return datetime.fromisoformat(text.replace("Z", "+00:00")).timestamp()


def _candle_ts(text: str) -> int:
    """OANDA RFC 3339 time with nanoseconds ("2026-10-19T12:00:00.000000000Z") -> unix seconds."""
    if not isinstance(text, str) or not text.endswith("Z"):
        raise FeedError("a candle time is not RFC 3339 UTC")
    whole = text[:-1].split(".")[0]
    return int(datetime.fromisoformat(whole).replace(tzinfo=UTC).timestamp())


RETRY_AFTER_MAX_S = 30 * 86400.0   # a longer Retry-After is honoured as 30 days, so the block can still be dated and recorded


def _retry_after(value: str | None) -> float | None:
    """Seconds, capped at RETRY_AFTER_MAX_S, or None when unreadable. Never raises: it runs inside the 403/429 path."""
    if not value:
        return None
    v = value.strip()
    if v.isascii() and v.isdigit():
        return RETRY_AFTER_MAX_S if len(v) > 15 else min(float(v), RETRY_AFTER_MAX_S)
    t = _http_date(v)
    return None if t is None else min(max(0.0, t - time.time()), RETRY_AFTER_MAX_S)


def _http_date(value: str | None) -> float | None:
    """An HTTP date as unix seconds, or None when unreadable. A date with no zone ("-0000") is UTC, never the
    server's local zone. Never raises: it reads outside headers."""
    if not value:
        return None
    try:
        d = email.utils.parsedate_to_datetime(value)
        if d is None:
            return None
        if d.tzinfo is None:
            d = d.replace(tzinfo=UTC)
        return d.timestamp()
    except (TypeError, ValueError, IndexError, OverflowError, OSError):
        return None


def _floor_min(t: float) -> int:
    return int(t) - int(t) % 60


# ---------------------------------------------------------------- the client

class Client:
    """GET of the candles path only. base_url is the practice host, or plain http to this machine for tests."""

    def __init__(self, token: str, base_url: str = HOST, conn: sqlite3.Connection | None = None,
                 clock=time.time, sleep=time.sleep, min_gap_s: float = 2.0, timeout_s: float = 20.0,
                 block_hours: int = 24, max_failures: int = 3, cooldown_s: float = 300.0):
        u = urlsplit(base_url)
        local = u.scheme == "http" and u.hostname == "127.0.0.1"
        if not (base_url == HOST or local) or u.path not in ("", "/") or u.query or u.fragment:
            raise PathRefused("the feed reads only https://api-fxpractice.oanda.com (or http://127.0.0.1 in tests)")
        if not isinstance(token, str) or not token:
            raise FeedError("no OANDA practice token (EDGE_OANDA_TOKEN)")
        self._token = token
        self.base_url = base_url.rstrip("/")
        self.host = u.netloc
        self.conn = conn
        self.clock, self.sleep = clock, sleep
        self.min_gap_s = max(2.0, float(min_gap_s))
        self.timeout_s = timeout_s
        self.block_hours = max(24, int(block_hours))
        self.max_failures = min(3, max(1, int(max_failures)))     # the ceilings of [feed] (only ever tighter)
        self.cooldown_s = max(60.0, float(cooldown_s))
        self._host = {"host_failures": "0", "not_before": None}   # without a DB (tests): the same gate in memory
        self._last = None
        self._sent = None            # when the last request was sent: a poll's marker counts from here
        self._server_date = None     # the last response's Date header (unix s), when it had one

    def __repr__(self) -> str:
        return f"Client(host={self.host!r})"

    def _url(self, path: str, params: dict) -> str:
        if path not in ALLOWED_PATHS:
            raise PathRefused(f"path not allowed: {path[:80]!r}")
        if set(params) - ALLOWED_PARAMS or any(params.get(k) != v for k, v in FIXED_PARAMS.items()):
            raise PathRefused("parameters outside the candles allow-list")
        return f"{self.base_url}{path}?{urlencode(params)}"

    def _wait_gap(self) -> None:
        last = self._last
        if self.conn is not None:
            v = state(self.conn, "last_request_ts")
            if v is not None:
                last = max(float(v), last or 0.0)
        if last is not None:
            now = self.clock()
            wait = last + self.min_gap_s - now if last <= now + self.min_gap_s else self.min_gap_s
            if wait > 0:
                self.sleep(wait)
        self._last = self._sent = self.clock()
        if self.conn is not None:
            set_state(self.conn, "last_request_ts", repr(self._last))

    def _block(self, code: int, retry_after: float | None) -> float:
        now = self.clock()
        until = now + max(self.block_hours * 3600.0, retry_after or 0.0)
        if self.conn is not None:
            with db.transaction(self.conn):
                self.conn.execute("INSERT INTO feed_block (host, code, blocked_utc, until_utc, retry_after)"
                                  " VALUES (?, ?, ?, ?, ?)",
                                  (self.host, int(code), _iso(now), _iso(until),
                                   None if retry_after is None else str(int(retry_after))))
        return until

    def _hget(self, key: str) -> str | None:
        return state(self.conn, key) if self.conn is not None else self._host.get(key)

    def _hset(self, key: str, value) -> None:
        if self.conn is not None:
            set_state(self.conn, key, value)
        else:
            self._host[key] = str(value)

    def _host_ok(self) -> None:
        if self._hget("host_failures") not in (None, "0"):
            self._hset("host_failures", 0)

    def _host_failed(self, e: FeedError) -> None:
        """One more failure in a row at this host, whoever sent it: Retry-After, the back-off and, on the
        max_failures-th, the cool-down move the shared not-before time (never earlier than it was)."""
        now = self.clock()
        n = int(self._hget("host_failures") or 0) + 1
        wait = float(e.retry_after or 0.0)
        if e.retryable:
            wait = max(wait, 2.0 ** n)
        if n >= self.max_failures:
            wait, n = max(wait, self.cooldown_s), 0
            log.warning("feed: %s failures in a row at the host: no request for %s s", self.max_failures, int(wait))
        self._hset("host_failures", n)
        if wait > 0:
            cur = self._hget("not_before")
            self._hset("not_before", repr(max(float(cur) if cur else 0.0, now + wait)))

    def _get(self, path: str, params: dict) -> dict:
        url = self._url(path, params)                         # refuses before anything is sent
        if self.conn is not None:
            b = blocked_until(self.conn, self.host, self.clock())
            if b is not None:
                raise FeedBlocked(f"host blocked until {_iso(b)}")
        nb = self._hget("not_before")
        if nb is not None and float(nb) > self.clock():
            raise HostWait(f"host waits until {_iso(float(nb))}", float(nb))
        self._wait_gap()
        try:
            return self._send(url)
        finally:                                              # the gap counts from the end of the last request too
            self._last = self.clock()
            if self.conn is not None:
                set_state(self.conn, "last_request_ts", repr(self._last))

    def _send(self, url: str) -> dict:
        req = urllib.request.Request(url, method="GET", headers={
            "Authorization": f"Bearer {self._token}", "Accept": "application/json", "Connection": "close"})
        self._server_date = None
        try:
            with OPENER.open(req, timeout=self.timeout_s) as r:
                raw = r.read(64 * 1024 * 1024)
                self._server_date = _http_date(r.headers.get("Date"))
        except urllib.error.HTTPError as e:
            code, ra = e.code, _retry_after(e.headers.get("Retry-After") if e.headers else None)
            e.close()
            if code in (403, 429):
                until = self._block(code, ra)
                log.warning("feed: HTTP %s, host blocked until %s", code, _iso(until))
                raise FeedBlocked(f"HTTP {code}: host blocked until {_iso(until)}", code, ra) from None
            log.warning("feed: HTTP %s", code)
            raise FeedError(f"HTTP {code}", code, ra, retryable=500 <= code <= 599) from None
        except (urllib.error.URLError, OSError, TimeoutError, http.client.HTTPException) as e:
            # http.client's own family (a non-HTTP status line, a chunked body cut short, a line too long, too many
            # headers) is neither an OSError nor a URLError: a network error too, so the feed, the move record job
            # and the host gate count it (fix round 3)
            log.warning("feed: network error %s", type(e).__name__)
            raise FeedError(f"network error {type(e).__name__}", retryable=True) from None
        try:
            return json.loads(raw)
        except (ValueError, UnicodeDecodeError, RecursionError):
            raise FeedError("the response is not JSON") from None

    def candles(self, start: int, stop: int) -> list[dict]:
        """Candles with start <= time < stop: [{ts, bid_o..ask_c, volume, complete}]."""
        if stop <= start or stop - start > MAX_CANDLES * 60 or start % 60:
            raise PathRefused("a window must start on a minute and hold at most 5000 minutes")
        try:
            body = self._get(CANDLES_PATH, {**FIXED_PARAMS, "from": _iso(start), "to": _iso(stop)})
            out = self._parse(body, start, stop)
        except (FeedBlocked, PathRefused, HostWait):
            raise
        except FeedError as e:
            self._host_failed(e)
            raise
        self._host_ok()
        return out

    @staticmethod
    def _parse(body, start: int, stop: int) -> list[dict]:
        if not isinstance(body, dict):
            raise FeedError("the response is not a candles object")
        out = []
        for c in body.get("candles") or []:
            try:
                ts = _candle_ts(c["time"])
                vol = int(c.get("volume", 0))
                if not 0 <= vol < 2 ** 63:                 # what SQLite's INTEGER holds; a volume is never negative
                    raise ValueError
                row = {"ts": ts, "volume": vol, "complete": c.get("complete") is True}
                for side in ("bid", "ask"):
                    for k in "ohlc":
                        v = float(c[side][k])
                        if not math.isfinite(v) or v <= 0:
                            raise ValueError
                        row[f"{side}_{k}"] = v
            except (KeyError, TypeError, ValueError, OverflowError):
                raise FeedError("a candle is not a bid/ask candle") from None
            if ts % 60 or not start <= ts < stop:
                continue
            out.append(row)
        return sorted(out, key=lambda r: r["ts"])


# ---------------------------------------------------------------- the feed

class Feed:
    def __init__(self, conn: sqlite3.Connection, client: Client, cfg, clock=time.time):
        self.conn, self.client, self.cfg, self.clock = conn, client, cfg, clock

    def _fetch(self, start: int, stop: int) -> tuple[list[dict], float]:
        fails = int(state(self.conn, "failures") or 0)
        fatal = state(self.conn, "fatal_failure") == "1"
        while True:
            try:
                made = self.clock()
                rows = self.client.candles(start, stop)
                made = max(made, self.client._sent or made)
                if self.client._server_date is not None:     # never past the server's own clock (item 8)
                    made = min(made, self.client._server_date)
                set_state(self.conn, "failures", 0)
                set_state(self.conn, "fatal_failure", 0)
                return rows, made
            except (FeedBlocked, PathRefused, HostWait):
                raise
            except FeedError as e:
                fails += 1
                fatal = fatal or not e.retryable
                set_state(self.conn, "failures", fails)
                set_state(self.conn, "fatal_failure", 1 if fatal else 0)
                if fails >= self.cfg.max_failures:
                    set_state(self.conn, "failures", 0)
                    set_state(self.conn, "fatal_failure", 0)
                    if fatal:                                 # a 4xx, a 3xx or a bad body: no resume on its own
                        set_state(self.conn, "halted", f"{fails} failures in a row, last {e}")
                        log.warning("feed: %s failures in a row (not only 5xx or network): halted until reset", fails)
                        raise FeedStopped(f"{fails} failures in a row; halted until reset", e.code) from None
                    until = self.clock() + max(float(self.cfg.cooldown_s), float(e.retry_after or 0.0))
                    set_state(self.conn, "stopped_until", repr(until))
                    log.warning("feed: %s failures in a row, stopped until %s", fails, _iso(until))
                    raise FeedStopped(f"{fails} failures in a row; stopped until {_iso(until)}", e.code) from None
                self.client.sleep(max(e.retry_after or 0.0, 2.0 ** fails))

    def _save(self, rows: list[dict]) -> int:
        with db.transaction(self.conn):
            n = 0
            for r in rows:
                cur = self.conn.execute(
                    "INSERT OR IGNORE INTO m1_bar (ts, bid_o, bid_h, bid_l, bid_c, ask_o, ask_h, ask_l, ask_c, volume)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", (r["ts"], *(r[k] for k in PRICE_FIELDS), r["volume"]))
                n += cur.rowcount
            return n

    def poll(self) -> dict:
        """Fetch from the last saved bar (or the backfill start) to now. Returns counts and states."""
        now = self.clock()
        out = {"requests": 0, "saved": 0, "blocked_until": None, "stopped_until": None,
               "halted": state(self.conn, "halted"), "complete_through": complete_through(self.conn)}
        if out["halted"]:
            return out
        b = blocked_until(self.conn, self.client.host, now)
        if b is not None:
            out["blocked_until"] = b
            return out
        st = state(self.conn, "stopped_until")
        if st is not None and float(st) > now:
            out["stopped_until"] = float(st)
            return out
        nb = not_before(self.conn, now)                 # a Retry-After, back-off or cool-down the job received too
        if nb is not None:
            out["stopped_until"] = nb
            return out
        last = last_bar(self.conn)
        cur = last + 60 if last is not None else _floor_min(now - self.cfg.backfill_days * 86400)
        end = _floor_min(now) + 60                     # the minute in progress comes back incomplete and is dropped
        while cur < end:
            stop = min(end, cur + MAX_CANDLES * 60)
            rows, made = self._fetch(cur, stop)
            out["requests"] += 1
            inc = [r["ts"] for r in rows if not r["complete"]]
            first_inc = min(inc) if inc else None
            keep = [r for r in rows if r["complete"] and (first_inc is None or r["ts"] < first_inc)]
            out["saved"] += self._save(keep)
            reach = stop if first_inc is None else first_inc
            set_complete_through(self.conn, min(reach, _floor_min(made - self.cfg.marker_delay_s)))
            if first_inc is not None:
                break
            cur = stop
        out["complete_through"] = complete_through(self.conn)
        return out


def run_forever(conn: sqlite3.Connection, cfg, token: str, var_dir=None) -> None:
    """The feed process (python -m app feed): poll every [feed] poll_s; a block or stop waits it out. Between two
    polls, the one-off move record job (app/news/moverecord.py, coordinator ruling R7) uses this same client, so its
    requests share the feed's gap, blocks and allow-list; it stops 2 s before the next poll is due."""
    from pathlib import Path
    from app.news.moverecord import RecordJob
    client = Client(token, conn=conn, min_gap_s=cfg.feed.min_gap_s, timeout_s=cfg.feed.timeout_s,
                    block_hours=cfg.feed.block_hours, max_failures=cfg.feed.max_failures,
                    cooldown_s=cfg.feed.cooldown_s)
    feed = Feed(conn, client, cfg.feed)
    job = RecordJob(conn, client, cfg, Path(var_dir) if var_dir else Path(cfg.app.db_path).parent)
    while True:
        start = time.time()
        try:
            r = feed.poll()
            log.info("feed: %s requests, %s bars saved, complete through %s", r["requests"], r["saved"],
                     None if r["complete_through"] is None else _iso(r["complete_through"]))
        except FeedError as e:
            log.warning("feed: %s", e)
        if job.enabled():
            try:
                job.step(deadline=start + cfg.feed.poll_s - 2)
            except Exception as exc:  # noqa: BLE001 - the record job never stops the feed
                log.error("move record: %s", type(exc).__name__)
            time.sleep(max(1.0, start + cfg.feed.poll_s - time.time()))
        else:
            time.sleep(cfg.feed.poll_s)
