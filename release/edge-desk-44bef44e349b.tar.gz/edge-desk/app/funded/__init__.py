"""Funded-account limits: daily and maximum loss headroom, open risk against the cap (A5)."""
