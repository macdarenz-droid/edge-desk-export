"""Funded-account limits (A5), for the planned FundedNext Stellar account. Values come only from config [funded],
typed by the owner from FundedNext's official pages; blank values show "Not set" and send no alert.

Readings (research/departments/COST/sources/FUNDEDNEXT.md, read 13 Oct 2026; terms change):
- Daily loss = the balance at the last reset minus equity now (closed results of the day plus open positions,
  with commission and swap). That day's closed profit raises the allowance, as in FundedNext's example
  "($100,000 x 0.05 + $2,000) = $7,000". Breach: daily loss above initial balance x daily_loss_pct.
- An open loss held past the reset counts against the new day (the new day starts from the closed balance).
- Maximum loss: static floor at initial balance x (1 - max_loss_pct); breach when the balance or the equity is
  below it ("Your account balance or equity must not drop below 90% of the initial balance at any point",
  help.fundednext.com 17255124, read 30 Oct 2026; 94% for Stellar 1-Step, 17252927).
- Worst case today: if every open stop is hit (open risk below), the day's loss would be the closed loss so far plus
  the open risk, and the balance would end at the balance minus the open risk; a warning when either would break a
  limit. Commission on those closes is not counted, so it reads "about".
- Inactivity: "the system will mark the account as inactive if a trader does not place a trade on the account for 30
  consecutive calendar days" (help.fundednext.com 8019664, updated 27 Jul 2026; the Trading Objectives page says 60
  days, so the shorter is used). A reminder 5 days before, counted from the last trade deal the bridge sent, or from
  the account's first data when it has no trade yet.
- The daily reset is 00:00 on the broker's server clock, from the bridge's measured offset
  (bridge/CONTRACT.md "Broker clock", bridge_status.server_offset_s), not a New York rule: FundedNext says GMT+3
  "during daylight saving time" without saying whose.
- Open risk (FundedNext funded stage: "maximum potential loss on a trade at a time, based on stop-loss placement",
  plus floating losses, against initial balance): for each position the larger of its loss at the stop from
  the open price and its floating loss now; for each pending order its loss at the stop from the order price.
  A position or order with no stop has no stop-based risk and counts with its floating loss only (the no-stop
  incident covers it). This combination is a working reading, not confirmed with FundedNext.
"""
from __future__ import annotations

import json
import sqlite3
from dataclasses import replace
from datetime import datetime, timedelta

from app.notify.alerts import Alert
from app.timeutil import UTC, from_iso, to_iso

NOT_SET = "Not set"
NO_DATA = "No data"               # set, but no snapshot of this account yet (just after a switch)
INACTIVE_AFTER_DAYS = 30          # FundedNext, article 8019664 (above)
IDLE_WARN_DAYS = (25, 28)         # the reminders: 5 and 2 days before
PRODUCTS = {"stellar2": "Stellar 2-Step", "stellar1": "Stellar 1-Step"}
STAGES = {"phase1": "Phase 1", "phase2": "Phase 2", "funded": "FundedNext Account"}


def label(f) -> str | None:
    """'Stellar 2-Step · Phase 1 · 6,000', or None when the product is not set."""
    if f.product not in PRODUCTS:
        return None
    parts = [PRODUCTS[f.product], STAGES.get(f.stage, "")]
    if f.initial_balance is not None:
        parts.append(f"{f.initial_balance:,.0f}")
    return " · ".join(x for x in parts if x)


def last_reset_utc(now: datetime, server_offset_s: int) -> datetime:
    """The last 00:00 on the server clock (server time = UTC + offset), in UTC."""
    server = now.astimezone(UTC) + timedelta(seconds=server_offset_s)
    midnight = server.replace(hour=0, minute=0, second=0, microsecond=0)
    return midnight - timedelta(seconds=server_offset_s)


def _no_stop_note(n: int) -> str:
    if not n:
        return ""
    return (" 1 trade or order with no stop: what it could still lose is not counted." if n == 1 else
            f" {n} trades or orders with no stop: what they could still lose is not counted.")


def evaluate(f, *, start_balance: float, balance: float, equity: float, open_risk: float | None) -> dict:
    """The limit state from the balance at the last reset, the balance and equity now, and the open risk."""
    out = {"enabled": f.enabled, "set": f.is_set, "status": "Off" if not f.enabled else NOT_SET,
           "start_balance": start_balance, "balance": balance, "equity": equity, "daily_loss": start_balance - equity,
           "daily_limit": None, "daily_used": None, "daily_breach": None, "floor": None, "to_floor": None,
           "max_breach": None, "max_used": None, "open_risk": open_risk, "open_risk_pct": None,
           "risk_cap_pct": f.risk_cap_pct, "cap_hit": None, "worst_day_loss": None, "worst_balance": None,
           "room_breach": None, "room_today": None, "target": None, "to_target": None,
           "alert_at": list(f.alert_at), "label": label(f), "min_days": None if f.min_days is None else int(f.min_days)}
    if not f.enabled or not f.is_set:
        return out
    init = f.initial_balance
    limit = init * f.daily_loss_pct / 100.0
    floor = init * (1 - f.max_loss_pct / 100.0)
    loss = start_balance - equity
    low = min(balance, equity)
    out.update(daily_limit=limit, daily_used=max(0.0, loss) / limit, daily_breach=loss > limit + 1e-9,
               floor=floor, to_floor=low - floor, max_breach=low < floor - 1e-9,
               max_used=max(0.0, init - low) / (init - floor),
               # FundedNext's "Today's Permitted Loss": the daily room, which the day's closed profit raises
               # (its example: "$100,000 x 0.05 + $2,000 = $7,000") and an open loss lowers; an open profit can still
               # go, so it does not count (low = the lower of balance and equity). Never more than the room to the floor
               room_today=min(limit - (start_balance - low), low - floor))
    if f.target_pct is not None:
        target = init * (1 + f.target_pct / 100.0)
        out.update(target=target, to_target=target - balance)
    if open_risk is not None:
        pct = open_risk / init * 100.0
        worst, worst_bal = (start_balance - balance) + open_risk, balance - open_risk
        out.update(open_risk_pct=pct, cap_hit=None if f.risk_cap_pct is None else pct > f.risk_cap_pct + 1e-9,
                   worst_day_loss=worst, worst_balance=worst_bal,
                   room_breach=worst > limit + 1e-9 or worst_bal < floor - 1e-9)
    out["status"] = "Breached" if out["daily_breach"] or out["max_breach"] else "Within limits"
    return out


def _value_per_price(info: dict | None, volume: float) -> float | None:
    if info and info.get("tick_size", 0) > 0 and info.get("tick_value", 0) > 0:
        return info["tick_value"] / info["tick_size"] * volume
    if info and info.get("contract_size", 0) > 0:
        return info["contract_size"] * volume
    return None


def open_risk_detail(snap: dict) -> tuple[float | None, int]:
    """(stop-based risk plus floating losses of every position and pending order, in account money; how many of them
    have no stop). A position or order with no stop has no stop-based risk, so it is counted apart (the panel says
    so): its real risk is unknown, and FundedNext's 3% rule and "All stops hit" cannot include it."""
    symbols = snap.get("symbols") or {}
    total, no_stop = 0.0, 0
    for p in snap.get("positions") or []:
        no_stop += p.get("sl") is None
        vpp = _value_per_price(symbols.get(p["symbol"]), p["volume"])
        if vpp is None:
            return None, no_stop
        d = 1.0 if p["side"] == "buy" else -1.0
        at_stop = max(0.0, (p["open_price"] - p["sl"]) * d * vpp) if p.get("sl") is not None else 0.0
        floating = max(0.0, -(p["price"] - p["open_price"]) * d * vpp) if p.get("price") else 0.0
        total += max(at_stop, floating)
    for o in snap.get("orders") or []:
        if not str(o.get("type", "")).startswith(("buy", "sell")):
            continue
        if o.get("sl") is None:
            no_stop += 1
            continue
        vpp = _value_per_price(symbols.get(o["symbol"]), o["volume"])
        if vpp is None:
            return None, no_stop
        d = 1.0 if o["type"].startswith("buy") else -1.0
        total += max(0.0, (o["price"] - o["sl"]) * d * vpp)
    return total, no_stop


def open_risk(snap: dict) -> float | None:
    """Stop-based risk plus floating losses of every position and pending order in a snapshot (account money)."""
    return open_risk_detail(snap)[0]


def funded_state(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    """The limit state from the latest snapshot and the stored deals."""
    row = conn.execute("SELECT * FROM bridge_status WHERE account_alias = ?", (cfg.account.alias,)).fetchone()
    if row is None:
        # No snapshot of this account yet (just after a switch): nothing is known, so nothing is breached or alerted
        out = evaluate(replace(cfg.funded, enabled=False), start_balance=0.0, balance=0.0, equity=0.0, open_risk=None)
        out.update(enabled=cfg.funded.enabled, set=cfg.funded.is_set, reset_utc=None, next_reset_utc=None, data=False,
                   daily_loss=None, start_balance=None, balance=None, equity=None, no_stop=0, days_traded=None,
                   status=NO_DATA if cfg.funded.enabled and cfg.funded.is_set else
                   ("Off" if not cfg.funded.enabled else NOT_SET))
        return out
    snap = json.loads(row["snapshot_json"])
    acct = snap.get("account") or {}
    balance, equity = float(acct.get("balance", 0.0)), float(acct.get("equity", 0.0))
    reset = last_reset_utc(now, int(row["server_offset_s"]))
    # Deposits, withdrawals and payouts ('balance'), credit and bonus move the balance but are not the day's trading
    # result, so they shift the day's starting balance instead of counting as a loss or a gain (red team 14).
    since = conn.execute("SELECT COALESCE(SUM(profit + commission + swap + fee), 0) FROM deal WHERE account_alias = ?"
                         " AND time_utc >= ? AND type NOT IN ('balance', 'credit', 'bonus')",
                         (cfg.account.alias, to_iso(reset))).fetchone()[0]
    risk, no_stop = open_risk_detail(snap)
    out = evaluate(cfg.funded, start_balance=balance - since, balance=balance, equity=equity, open_risk=risk)
    age = (now - from_iso(row["last_seen_utc"])).total_seconds()
    out.update(reset_utc=to_iso(reset), next_reset_utc=to_iso(reset + timedelta(days=1)), data=True,
               server_offset_s=int(row["server_offset_s"]), stale=age > cfg.bridge.silent_alert_after_s,
               snapshot_age_s=age, no_stop=no_stop,
               days_traded=_days_traded(conn, cfg.account.alias, int(row["server_offset_s"])),
               **_idle(conn, cfg.account.alias, now))
    return out


def _days_traded(conn: sqlite3.Connection, alias: str, offset_s: int) -> int:
    """Server days with a trade placed on this account (an entry deal), the way FundedNext counts trading days ("at
    least one trade with non-zero P&L"; a trade closed at exactly 0 is rare and still counted here). Approximate: his
    FundedNext dashboard is the record."""
    return conn.execute(
        "SELECT COUNT(DISTINCT date(time_utc, ? || ' seconds')) FROM deal WHERE account_alias = ? AND type IN"
        " ('buy', 'sell') AND entry IN ('in', 'inout')", (str(offset_s), alias)).fetchone()[0]


def _idle(conn: sqlite3.Connection, alias: str, now: datetime) -> dict:
    """Whole days since the account's last trade deal (FundedNext counts placed trades); with no trade yet, since its
    first deal of any kind (the starting balance, by the deal's own time), else since the bridge first saw it."""
    last = conn.execute("SELECT MAX(time_utc) FROM deal WHERE account_alias = ? AND type IN ('buy', 'sell')",
                        (alias,)).fetchone()[0]
    since = last or conn.execute("SELECT MIN(time_utc) FROM deal WHERE account_alias = ?", (alias,)).fetchone()[0] \
        or conn.execute("SELECT MIN(first_seen_utc) FROM position_seen WHERE account_alias = ?", (alias,)).fetchone()[0]
    if not since:
        return {"idle_since_utc": None, "idle_days": None}
    return {"idle_since_utc": since, "idle_days": int((now - from_iso(since)).total_seconds() // 86400)}


def funded_alerts(cfg, state: dict, reset: datetime | str | None) -> list[Alert]:
    """funded_50 and funded_80 (daily limit used), risk_cap (open risk at the cap): once per server day each."""
    if not state.get("enabled") or not state.get("set") or state.get("stale") or state.get("data") is False:
        return []          # a silent bridge has its own incident; old or missing numbers send no limit alert
    day = reset if isinstance(reset, str) else to_iso(reset) if reset else state.get("reset_utc") or ""
    out: list[Alert] = []
    used = state.get("daily_used")
    cur = cfg.account.currency
    if used is not None:
        for level, kind, prio in ((state["alert_at"][0], "funded_50", 2), (state["alert_at"][1], "funded_80", 4)):
            if used >= level:
                out.append(Alert(f"{kind}:{day}", kind, prio, f"Daily loss limit {round(level * 100)}% used",
                                 f"Today's loss {state['daily_loss']:,.2f} {cur} of {state['daily_limit']:,.2f} {cur}"
                                 f" ({used * 100:.0f}%). Equity {state['equity']:,.2f} {cur}; floor"
                                 f" {state['floor']:,.2f} {cur}."))
    if state.get("cap_hit"):
        out.append(Alert(f"risk_cap:{day}", "risk_cap", 4, f"Open risk over the {state['risk_cap_pct']:g}% cap",
                         f"Open risk {state['open_risk']:,.2f} {cur} = {state['open_risk_pct']:.2f}% of the initial"
                         f" balance; cap {state['risk_cap_pct']:.2f}%."))
    max_used = state.get("max_used")
    if max_used is not None and max_used >= state["alert_at"][1]:
        out.append(Alert(f"funded_max_80:{day}", "funded_max_80", 4,
                         f"Maximum loss {round(state['alert_at'][1] * 100)}% used",
                         f"Balance {state['balance']:,.2f} {cur}, equity {state['equity']:,.2f} {cur};"
                         f" {state['to_floor']:,.2f} {cur} left to the {state['floor']:,.2f} {cur} floor"
                         f" ({max_used * 100:.0f}% of the maximum loss used)."))
    if state.get("room_breach"):
        out.append(Alert(f"funded_room:{day}", "funded_room", 4, "Open stops would break a limit",
                         f"If every open stop is hit, today's loss is about {state['worst_day_loss']:,.2f} {cur} of"
                         f" the {state['daily_limit']:,.2f} {cur} daily limit and the balance about"
                         f" {state['worst_balance']:,.2f} {cur} (floor {state['floor']:,.2f} {cur})."
                         + _no_stop_note(state.get("no_stop") or 0)))
    idle = state.get("idle_days")
    if idle is not None and idle >= IDLE_WARN_DAYS[0] and state.get("idle_since_utc"):
        step = max(d for d in IDLE_WARN_DAYS if d <= idle)
        left = max(0, INACTIVE_AFTER_DAYS - idle)
        on = f"your {state['label'].split(' · ')[0]} account" if state.get("label") else "this account"
        out.append(Alert(f"funded_idle:{state['idle_since_utc']}:{step}", "funded_idle", 4, f"No trade for {idle} days",
                         f"FundedNext deactivates an account after {INACTIVE_AFTER_DAYS} days with no trade placed."
                         f" About {left} days left on {on}."))
    return out
