"""MT5 bridge ingest (edge-bridge/1): validate snapshots, store deals and positions, build MT5 trades.

Read-only by design: nothing here can send, change or close an order.
"""
from app.ingest.live import live_view
from app.ingest.schema import PayloadError, Snapshot, validate
from app.ingest.service import IngestResult, StaleSeqError, apply_snapshot
from app.ingest.status import bridge_state
from app.ingest.trades import sync_trades

__all__ = ["IngestResult", "PayloadError", "Snapshot", "StaleSeqError", "apply_snapshot", "bridge_state",
           "live_view", "sync_trades", "validate"]
