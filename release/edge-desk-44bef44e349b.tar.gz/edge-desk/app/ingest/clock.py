"""Broker clock: MT5 sends times as trade-server epoch seconds (server wall time written as if it were UTC).

Config bridge.broker_clock:
  "ny_close"  the common broker clock: server midnight = 17:00 New York, so the server runs at UTC+2,
              or UTC+3 while New York is on daylight time. Evaluated at each time being converted, so a
              winter deal converts with +2 even when the snapshot arrives in summer.
  "measured"  offset = round((server_time - gmt_time) / 900) * 900 from the snapshot itself, used for
              every time in that snapshot.
With "ny_close", every snapshot also compares the rule offset now with the measured one. If they differ,
the measured offset is used for that snapshot (the EA's own clock wins) and the service raises one
clock_mismatch event per bridge session.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from app.ingest.schema import PayloadError, Snapshot
from app.timeutil import NEW_YORK

UTC = timezone.utc
_EPOCH = datetime(1970, 1, 1)
_NY_CLOSE_SHIFT = timedelta(hours=7)  # server wall time minus New York wall time
QUARTER_HOUR_S = 900


def ny_close_to_utc(server_epoch: int) -> datetime:
    """Server time on a New York close clock -> UTC. Server wall time - 7 h is New York wall time."""
    ny_wall = _EPOCH + timedelta(seconds=server_epoch) - _NY_CLOSE_SHIFT
    return ny_wall.replace(tzinfo=NEW_YORK).astimezone(UTC)


def rule_offset_s(at_utc: datetime) -> int:
    """Server minus UTC under the New York close rule at an instant: 7200, or 10800 in New York summer."""
    ny_offset = at_utc.astimezone(NEW_YORK).utcoffset()
    return int(ny_offset.total_seconds()) + int(_NY_CLOSE_SHIFT.total_seconds())


def measured_offset_s(server_time: int, gmt_time: int) -> int:
    """Server minus UTC as the EA saw it, rounded to the nearest quarter hour (half rounds up)."""
    return int(math.floor((server_time - gmt_time) / QUARTER_HOUR_S + 0.5)) * QUARTER_HOUR_S


@dataclass(frozen=True)
class ServerClock:
    """Turns server epoch seconds from one snapshot into UTC."""
    mode: str                     # "ny_close" (rule per time) or "fixed" (one offset)
    offset_now_s: int             # offset used at the snapshot time (stored as bridge_status.clock_offset_s)
    measured_offset_s: int        # offset the EA measured (stored as bridge_status.server_offset_s)
    rule_offset_s: int | None     # New York close rule at the snapshot time; None in "measured" mode
    mismatch: bool

    def to_utc(self, server_epoch: int) -> datetime:
        if self.mode == "ny_close":
            return ny_close_to_utc(server_epoch)
        return datetime.fromtimestamp(server_epoch - self.offset_now_s, UTC)


def resolve_clock(cfg, snap: Snapshot) -> ServerClock:
    measured = measured_offset_s(snap.server_time, snap.gmt_time)
    if cfg.bridge.broker_clock == "measured":
        return ServerClock("fixed", measured, measured, None, False)
    rule = rule_offset_s(datetime.fromtimestamp(snap.gmt_time, UTC))
    if rule == measured:
        return ServerClock("ny_close", rule, measured, rule, False)
    return ServerClock("fixed", measured, measured, rule, True)


def check_skew(cfg, snap: Snapshot, received_utc: datetime) -> None:
    """The terminal's UTC clock must be within bridge.max_clock_skew_s of this server's clock."""
    skew = abs(snap.gmt_time - received_utc.timestamp())
    if skew > cfg.bridge.max_clock_skew_s:
        raise PayloadError(f"gmt_time: terminal clock is {int(skew)} s away from the app clock "
                           f"(limit {cfg.bridge.max_clock_skew_s} s)")
