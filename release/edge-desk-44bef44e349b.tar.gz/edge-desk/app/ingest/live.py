"""The Live screen: account, open positions with R now, pending orders and today's closed trades.

Readings:
- r_now is price-based against the initial stop (the planned risk); None without a stop.
- progress runs 0..1 from the current stop to the target (clamped); None without both.
- management: "close_or_trail" from management.take_or_trail_r until the stop is at or past the trail
  level (+trail_stop_r); else "move_stop_to_entry" from management.breakeven_from_r until the stop is at
  or past entry (within 0.5 pip counts as at); else None.
- floating_r adds r_now over EUR/USD positions; None when there is none or one has no stop.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime

from app.ingest.clock import ServerClock, rule_offset_s
from app.ingest.state import known_symbols, pip_size, status_row
from app.ingest.status import bridge_state
from app.timeutil import from_iso, to_iso, trading_day

_EPS = 1e-9


def _clock(cfg, row: sqlite3.Row) -> ServerClock:
    offset = row["clock_offset_s"]
    rule = rule_offset_s(from_iso(row["last_seen_utc"])) if cfg.bridge.broker_clock == "ny_close" else None
    mode = "ny_close" if rule is not None and rule == offset else "fixed"
    return ServerClock(mode, offset, row["server_offset_s"], rule, rule is not None and rule != offset)


def _position(cfg, p: dict, seen: dict | None, trade: dict | None, info: dict | None, balance: float,
              clock: ServerClock) -> dict:
    symbol, side = p["symbol"], p["side"]
    direction = 1.0 if side == "buy" else -1.0
    open_price, price, sl, tp = p["open_price"], p["price"], p["sl"], p["tp"]
    pip = pip_size(cfg, symbol, info)
    half = 0.5 * pip if pip else 0.0
    initial_sl = None
    if trade and trade.get("initial_sl") is not None:
        initial_sl = trade["initial_sl"]
    elif seen:
        initial_sl = seen["initial_sl"]
    stop_dist = abs(open_price - initial_sl) if initial_sl is not None else None
    if stop_dist is not None and stop_dist <= _EPS:
        stop_dist = None
    r_now = (price - open_price) * direction / stop_dist if stop_dist and price > 0 else None
    progress = None
    if sl is not None and tp is not None and abs(tp - sl) > _EPS and price > 0:
        progress = min(1.0, max(0.0, (price - sl) / (tp - sl)))
    stop_at_entry = sl is not None and abs(sl - open_price) <= half + _EPS
    stop_past_entry = sl is not None and (sl - open_price) * direction >= -half - _EPS
    stop_past_trail = False
    if sl is not None and stop_dist:
        trail = open_price + direction * cfg.management.trail_stop_r * stop_dist
        stop_past_trail = (sl - trail) * direction >= -half - _EPS
    management = None
    if r_now is not None:
        if r_now >= cfg.management.take_or_trail_r and not stop_past_trail:
            management = "close_or_trail"
        elif r_now >= cfg.management.breakeven_from_r and not stop_past_entry:
            management = "move_stop_to_entry"
    return {
        "position_id": p["position_id"], "ticket": p["ticket"], "symbol": symbol, "is_eurusd": cfg.is_eurusd(symbol),
        "side": side, "volume": p["volume"], "open_price": open_price,
        "open_utc": seen["open_utc"] if seen else to_iso(clock.to_utc(p["open_time"])),
        "price": price, "sl": sl, "tp": tp, "initial_sl": initial_sl, "profit": p["profit"], "swap": p["swap"],
        "r_now": r_now,
        "pct_of_balance": (p["profit"] + p["swap"]) / balance * 100 if balance > 0 else None,
        "to_stop_pips": (price - sl) * direction / pip if sl is not None and pip and price > 0 else None,
        "to_target_pips": (tp - price) * direction / pip if tp is not None and pip and price > 0 else None,
        "progress": progress, "stop_at_entry": stop_at_entry, "no_stop": sl is None, "management": management,
    }


def _order(cfg, o: dict, clock: ServerClock) -> dict:
    exp = o["expiration"]
    return {"ticket": o["ticket"], "symbol": o["symbol"], "is_eurusd": cfg.is_eurusd(o["symbol"]), "type": o["type"],
            "volume": o["volume"], "price": o["price"], "sl": o["sl"], "tp": o["tp"],
            "setup_utc": to_iso(clock.to_utc(o["setup_time"])),
            "expiry_utc": None if exp is None else to_iso(clock.to_utc(exp))}


def live_view(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    alias = cfg.account.alias
    day = trading_day(now, cfg.day.boundary_tz, cfg.day.boundary_hour).isoformat()
    closed_today = [dict(dict(r), is_eurusd=cfg.is_eurusd(r["symbol"])) for r in conn.execute(
        "SELECT * FROM trade WHERE book = 'mt5' AND account_alias = ? AND status = 'closed'"
        " AND close_trading_day = ? ORDER BY close_utc, id", (alias, day))]
    view = {"bridge": bridge_state(conn, cfg, now), "account": None, "positions": [], "orders": [],
            "closed_today": closed_today, "other_symbols_open": 0}
    row = status_row(conn, alias)
    if row is None:
        return view

    snap = json.loads(row["snapshot_json"])
    clock = _clock(cfg, row)
    acct = snap["account"]
    balance, equity = acct["balance"], acct["equity"]
    symbols = dict(known_symbols(conn, alias))
    symbols.update(snap["symbols"])
    seen = {r["position_id"]: dict(r) for r in
            conn.execute("SELECT * FROM position_seen WHERE account_alias = ?", (alias,))}
    trades = {r["broker_position_id"]: dict(r) for r in conn.execute(
        "SELECT * FROM trade WHERE book = 'mt5' AND account_alias = ? AND status = 'open'", (alias,))}
    positions = [_position(cfg, p, seen.get(p["position_id"]), trades.get(p["position_id"]), symbols.get(p["symbol"]),
                           balance, clock) for p in snap["positions"]]
    eur = [p for p in positions if p["is_eurusd"]]
    floating = equity - balance
    view.update({
        "account": {"alias": alias, "currency": acct["currency"], "trade_mode": acct["trade_mode"],
                    "balance": balance, "equity": equity, "floating": floating,
                    "floating_pct": floating / balance * 100 if balance > 0 else None,
                    "floating_r": (sum(p["r_now"] for p in eur)
                                   if eur and all(p["r_now"] is not None for p in eur) else None),
                    "trade_allowed": acct["trade_allowed"]},
        "positions": positions,
        "orders": [_order(cfg, o, clock) for o in snap["orders"]],
        "other_symbols_open": sum(1 for p in positions if not p["is_eurusd"]),
    })
    return view
