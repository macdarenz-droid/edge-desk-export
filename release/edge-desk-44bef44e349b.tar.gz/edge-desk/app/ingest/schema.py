"""edge-bridge/1 payload validation (bridge/CONTRACT.md).

`validate(payload, cfg)` returns a frozen `Snapshot` or raises `PayloadError`. The rules are strict on
purpose: every key is required, unknown keys are refused, numbers must be finite and of the right type
(a bool is never an int), numbers stay within +-MAX_ABS (a finite 1e308 overflowed to inf in derived
figures), strings and lists are capped, and the account alias and currency must be the configured ones.
Error messages name the field, never the value: symbols are named by their position ("symbols entry 2"),
unknown keys only counted (a payload value is never echoed back; the EA prints the reply in the MT5 log).
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Mapping

TOP_KEYS = frozenset({"contract", "bridge_session", "seq", "reason", "server_time", "gmt_time", "account",
                      "terminal", "symbols", "positions", "orders", "deals", "deals_from"})
ACCOUNT_KEYS = frozenset({"alias", "currency", "company", "balance", "equity", "profit", "margin", "margin_free",
                          "trade_mode", "trade_allowed", "trade_expert"})
TERMINAL_KEYS = frozenset({"build", "trade_allowed", "connected"})
SYMBOL_KEYS = frozenset({"digits", "point", "tick_size", "tick_value", "contract_size", "volume_min",
                         "volume_step", "volume_max", "stops_level", "spread", "bid", "ask"})
POSITION_KEYS = frozenset({"ticket", "position_id", "symbol", "side", "volume", "open_price", "open_time", "price",
                           "sl", "tp", "profit", "swap", "magic", "comment"})
ORDER_KEYS = frozenset({"ticket", "symbol", "type", "volume", "price", "sl", "tp", "setup_time", "expiration"})
DEAL_KEYS = frozenset({"deal", "order", "position_id", "symbol", "type", "entry", "volume", "price", "time",
                       "profit", "commission", "swap", "fee", "reason", "sl", "tp", "magic"})

# Epoch-second fields per part of the body (expiration may be null). Tests that post the fixtures to a live
# server shift these by (now - gmt_time) so the clock-skew check passes.
TIME_KEYS = {"body": ("server_time", "gmt_time", "deals_from"), "positions": ("open_time",),
             "orders": ("setup_time", "expiration"), "deals": ("time",)}

REASONS = frozenset({"init", "timer", "trade"})
TRADE_MODES = frozenset({"demo", "contest", "real"})
SIDES = frozenset({"buy", "sell"})
ORDER_TYPES = frozenset({"buy_limit", "sell_limit", "buy_stop", "sell_stop", "buy_stop_limit", "sell_stop_limit",
                         "buy", "sell", "other"})
DEAL_TYPES = frozenset({"buy", "sell", "balance", "credit", "charge", "correction", "bonus", "commission",
                        "interest", "other"})
DEAL_ENTRIES = frozenset({"in", "out", "inout", "out_by", "none"})
DEAL_REASONS = frozenset({"client", "mobile", "web", "expert", "sl", "tp", "so", "rollover", "vmargin", "split",
                          "other"})

MAX_POSITIONS = 200
MAX_ORDERS = 200
MAX_DEALS = 500
MAX_SYMBOLS = 64
MAX_SYMBOL_LEN = 32
MAX_COMPANY_LEN = 128
MAX_COMMENT_LEN = 128
# Trade-server epoch seconds must fall in 2000-01-01 .. 2100-01-01 (catches 0, milliseconds, garbage).
MIN_EPOCH = 946_684_800
MAX_EPOCH = 4_102_444_800
MAX_SEQ = 2**63 - 1
MAX_ABS = 1e12          # money, prices, volumes and symbol data: far above any real account or quote
MAX_TICKET = 2**64 - 1

_SESSION_RE = re.compile(r"[0-9a-f]{16}")
_TICKET_RE = re.compile(r"[0-9]{1,20}")
_CURRENCY_RE = re.compile(r"[A-Z0-9]{2,8}")
_ALIAS_RE = re.compile(r"[A-Za-z0-9_-]{1,32}")


class PayloadError(ValueError):
    """The snapshot does not follow edge-bridge/1. The message names the field, never its value."""


@dataclass(frozen=True)
class Account:
    alias: str
    currency: str
    company: str
    balance: float
    equity: float
    profit: float
    margin: float
    margin_free: float
    trade_mode: str
    trade_allowed: bool
    trade_expert: bool


@dataclass(frozen=True)
class Terminal:
    build: int
    trade_allowed: bool
    connected: bool


@dataclass(frozen=True)
class SymbolInfo:
    digits: int
    point: float
    tick_size: float
    tick_value: float
    contract_size: float
    volume_min: float
    volume_step: float
    volume_max: float
    stops_level: int
    spread: int
    bid: float
    ask: float


@dataclass(frozen=True)
class Position:
    ticket: str
    position_id: str
    symbol: str
    side: str
    volume: float
    open_price: float
    open_time: int
    price: float
    sl: float | None
    tp: float | None
    profit: float
    swap: float
    magic: int
    comment: str


@dataclass(frozen=True)
class Order:
    ticket: str
    symbol: str
    type: str
    volume: float
    price: float
    sl: float | None
    tp: float | None
    setup_time: int
    expiration: int | None


@dataclass(frozen=True)
class Deal:
    deal: str
    order: str
    position_id: str
    symbol: str
    type: str
    entry: str
    volume: float
    price: float
    time: int
    profit: float
    commission: float
    swap: float
    fee: float
    reason: str
    sl: float | None
    tp: float | None
    magic: int


@dataclass(frozen=True)
class Snapshot:
    contract: str
    bridge_session: str
    seq: int
    reason: str
    server_time: int
    gmt_time: int
    account: Account
    terminal: Terminal
    symbols: Mapping[str, SymbolInfo]
    positions: tuple[Position, ...]
    orders: tuple[Order, ...]
    deals: tuple[Deal, ...]
    deals_from: int


# ---------- field checks ----------

def _obj(value: Any, where: str, keys: frozenset[str]) -> dict:
    if not isinstance(value, dict):
        raise PayloadError(f"{where}: must be an object")
    got = set(value)
    unknown = got - keys
    if unknown:
        raise PayloadError(f"{where}: {len(unknown)} unknown key(s)")
    missing = keys - got
    if missing:
        raise PayloadError(f"{where}: missing key(s) {', '.join(sorted(missing))}")
    return value


def _int(value: Any, where: str, lo: int, hi: int) -> int:
    if type(value) is not int:  # bool is a subclass of int and is refused
        raise PayloadError(f"{where}: must be an integer")
    if not lo <= value <= hi:
        raise PayloadError(f"{where}: out of range")
    return value


def _num(value: Any, where: str, lo: float | None = None, positive: bool = False) -> float:
    if type(value) not in (int, float):
        raise PayloadError(f"{where}: must be a number")
    value = float(value)
    if not math.isfinite(value):
        raise PayloadError(f"{where}: must be a finite number")
    if abs(value) > MAX_ABS:
        raise PayloadError(f"{where}: out of range")
    if positive and value <= 0:
        raise PayloadError(f"{where}: must be above 0")
    if lo is not None and value < lo:
        raise PayloadError(f"{where}: must be at least {lo:g}")
    return value


def _price_or_null(value: Any, where: str) -> float | None:
    if value is None:
        return None
    try:
        return _num(value, where, positive=True)
    except PayloadError:
        raise PayloadError(f"{where}: must be null or a positive number (MT5 0 is sent as null)") from None


def _bool(value: Any, where: str) -> bool:
    if type(value) is not bool:
        raise PayloadError(f"{where}: must be true or false")
    return value


def _str(value: Any, where: str, max_len: int, pattern: re.Pattern | None = None, allow_empty: bool = True) -> str:
    if not isinstance(value, str):
        raise PayloadError(f"{where}: must be a string")
    if len(value) > max_len or (not allow_empty and not value):
        raise PayloadError(f"{where}: length must be {0 if allow_empty else 1} to {max_len}")
    if pattern is not None and not pattern.fullmatch(value):
        raise PayloadError(f"{where}: bad format")
    return value


def _enum(value: Any, where: str, allowed: frozenset[str]) -> str:
    if not isinstance(value, str) or value not in allowed:
        raise PayloadError(f"{where}: must be one of {', '.join(sorted(allowed))}")
    return value


def _ticket(value: Any, where: str) -> str:
    if not isinstance(value, str) or not _TICKET_RE.fullmatch(value) or int(value) > MAX_TICKET:
        raise PayloadError(f"{where}: must be a ticket number as a string of digits")
    return value


def _epoch(value: Any, where: str) -> int:
    return _int(value, where, MIN_EPOCH, MAX_EPOCH)


def _list(value: Any, where: str, cap: int) -> list:
    if not isinstance(value, list):
        raise PayloadError(f"{where}: must be a list")
    if len(value) > cap:
        raise PayloadError(f"{where}: at most {cap} items")
    return value


def _symbol_name(value: Any, where: str, allow_empty: bool = False) -> str:
    return _str(value, where, MAX_SYMBOL_LEN, allow_empty=allow_empty)


# ---------- sections ----------

def _account(raw: Any, cfg) -> Account:
    a = _obj(raw, "account", ACCOUNT_KEYS)
    alias = a["alias"]
    if not isinstance(alias, str) or not _ALIAS_RE.fullmatch(alias) or alias != cfg.account.alias:
        raise PayloadError("account.alias: unknown account alias")
    currency = _str(a["currency"], "account.currency", 8, _CURRENCY_RE)
    if currency != cfg.account.currency:
        raise PayloadError("account.currency: not the configured account currency (config account.currency);"
                           " another account under this alias?")
    return Account(
        alias=alias,
        currency=currency,
        company=_str(a["company"], "account.company", MAX_COMPANY_LEN),
        balance=_num(a["balance"], "account.balance"),
        equity=_num(a["equity"], "account.equity"),
        profit=_num(a["profit"], "account.profit"),
        margin=_num(a["margin"], "account.margin", lo=0),
        margin_free=_num(a["margin_free"], "account.margin_free"),
        trade_mode=_enum(a["trade_mode"], "account.trade_mode", TRADE_MODES),
        trade_allowed=_bool(a["trade_allowed"], "account.trade_allowed"),
        trade_expert=_bool(a["trade_expert"], "account.trade_expert"),
    )


def _terminal(raw: Any) -> Terminal:
    t = _obj(raw, "terminal", TERMINAL_KEYS)
    return Terminal(build=_int(t["build"], "terminal.build", 0, 10**7),
                    trade_allowed=_bool(t["trade_allowed"], "terminal.trade_allowed"),
                    connected=_bool(t["connected"], "terminal.connected"))


def _symbol(raw: Any, where: str) -> SymbolInfo:
    s = _obj(raw, where, SYMBOL_KEYS)
    # 0 means "not known yet" (a symbol not in Market Watch); the app falls back where it can.
    return SymbolInfo(
        digits=_int(s["digits"], f"{where}.digits", 0, 10),
        point=_num(s["point"], f"{where}.point", lo=0),
        tick_size=_num(s["tick_size"], f"{where}.tick_size", lo=0),
        tick_value=_num(s["tick_value"], f"{where}.tick_value", lo=0),
        contract_size=_num(s["contract_size"], f"{where}.contract_size", lo=0),
        volume_min=_num(s["volume_min"], f"{where}.volume_min", lo=0),
        volume_step=_num(s["volume_step"], f"{where}.volume_step", lo=0),
        volume_max=_num(s["volume_max"], f"{where}.volume_max", lo=0),
        stops_level=_int(s["stops_level"], f"{where}.stops_level", 0, 10**7),
        spread=_int(s["spread"], f"{where}.spread", 0, 10**7),
        bid=_num(s["bid"], f"{where}.bid", lo=0),
        ask=_num(s["ask"], f"{where}.ask", lo=0),
    )


def _position(raw: Any, i: int) -> Position:
    w = f"positions[{i}]"
    p = _obj(raw, w, POSITION_KEYS)
    return Position(
        ticket=_ticket(p["ticket"], f"{w}.ticket"),
        position_id=_ticket(p["position_id"], f"{w}.position_id"),
        symbol=_symbol_name(p["symbol"], f"{w}.symbol"),
        side=_enum(p["side"], f"{w}.side", SIDES),
        volume=_num(p["volume"], f"{w}.volume", positive=True),
        open_price=_num(p["open_price"], f"{w}.open_price", positive=True),
        open_time=_epoch(p["open_time"], f"{w}.open_time"),
        price=_num(p["price"], f"{w}.price", lo=0),
        sl=_price_or_null(p["sl"], f"{w}.sl"),
        tp=_price_or_null(p["tp"], f"{w}.tp"),
        profit=_num(p["profit"], f"{w}.profit"),
        swap=_num(p["swap"], f"{w}.swap"),
        magic=_int(p["magic"], f"{w}.magic", -(2**63), 2**63 - 1),
        comment=_str(p["comment"], f"{w}.comment", MAX_COMMENT_LEN),
    )


def _order(raw: Any, i: int) -> Order:
    w = f"orders[{i}]"
    o = _obj(raw, w, ORDER_KEYS)
    exp = o["expiration"]
    return Order(
        ticket=_ticket(o["ticket"], f"{w}.ticket"),
        symbol=_symbol_name(o["symbol"], f"{w}.symbol"),
        type=_enum(o["type"], f"{w}.type", ORDER_TYPES),
        volume=_num(o["volume"], f"{w}.volume", lo=0),
        price=_num(o["price"], f"{w}.price", lo=0),
        sl=_price_or_null(o["sl"], f"{w}.sl"),
        tp=_price_or_null(o["tp"], f"{w}.tp"),
        setup_time=_epoch(o["setup_time"], f"{w}.setup_time"),
        expiration=None if exp is None else _epoch(exp, f"{w}.expiration"),
    )


def _deal(raw: Any, i: int) -> Deal:
    w = f"deals[{i}]"
    d = _obj(raw, w, DEAL_KEYS)
    typ = _enum(d["type"], f"{w}.type", DEAL_TYPES)
    return Deal(
        deal=_ticket(d["deal"], f"{w}.deal"),
        order=_ticket(d["order"], f"{w}.order"),
        position_id=_ticket(d["position_id"], f"{w}.position_id"),
        # Balance operations carry no symbol; trade deals must.
        symbol=_symbol_name(d["symbol"], f"{w}.symbol", allow_empty=typ not in SIDES),
        type=typ,
        entry=_enum(d["entry"], f"{w}.entry", DEAL_ENTRIES),
        volume=_num(d["volume"], f"{w}.volume", lo=0),
        price=_num(d["price"], f"{w}.price", lo=0),
        time=_epoch(d["time"], f"{w}.time"),
        profit=_num(d["profit"], f"{w}.profit"),
        commission=_num(d["commission"], f"{w}.commission"),
        swap=_num(d["swap"], f"{w}.swap"),
        fee=_num(d["fee"], f"{w}.fee"),
        reason=_enum(d["reason"], f"{w}.reason", DEAL_REASONS),
        sl=_price_or_null(d["sl"], f"{w}.sl"),
        tp=_price_or_null(d["tp"], f"{w}.tp"),
        magic=_int(d["magic"], f"{w}.magic", -(2**63), 2**63 - 1),
    )


def _unique(values: list[str], where: str) -> None:
    if len(set(values)) != len(values):
        raise PayloadError(f"{where}: duplicate ticket")


def validate(payload: Any, cfg) -> Snapshot:
    """Check a decoded edge-bridge/1 body against the contract and the config. Raises PayloadError."""
    p = _obj(payload, "body", TOP_KEYS)
    if p["contract"] != cfg.bridge.contract:
        raise PayloadError(f"contract: this app speaks {cfg.bridge.contract}")
    session = p["bridge_session"]
    if not isinstance(session, str) or not _SESSION_RE.fullmatch(session):
        raise PayloadError("bridge_session: must be 16 lowercase hex characters")

    raw_symbols = p["symbols"]
    if not isinstance(raw_symbols, dict):
        raise PayloadError("symbols: must be an object")
    if len(raw_symbols) > MAX_SYMBOLS:
        raise PayloadError(f"symbols: at most {MAX_SYMBOLS} entries")
    symbols = {}
    for i, (name, info) in enumerate(raw_symbols.items(), 1):
        _symbol_name(name, f"symbols entry {i} name")
        symbols[name] = _symbol(info, f"symbols entry {i}")

    positions = tuple(_position(x, i) for i, x in enumerate(_list(p["positions"], "positions", MAX_POSITIONS)))
    orders = tuple(_order(x, i) for i, x in enumerate(_list(p["orders"], "orders", MAX_ORDERS)))
    deals = tuple(_deal(x, i) for i, x in enumerate(_list(p["deals"], "deals", MAX_DEALS)))
    _unique([x.position_id for x in positions], "positions")
    _unique([x.ticket for x in orders], "orders")
    _unique([x.deal for x in deals], "deals")

    used = {x.symbol for x in positions} | {x.symbol for x in orders} | {x.symbol for x in deals if x.type in SIDES}
    missing = used - set(symbols)
    if missing:
        raise PayloadError("symbols: every symbol in positions, orders and trade deals needs an entry")
    if not any(cfg.is_eurusd(name) for name in symbols):
        raise PayloadError("symbols: no EUR/USD entry (config instrument.broker_symbols)")

    return Snapshot(
        contract=p["contract"],
        bridge_session=session,
        seq=_int(p["seq"], "seq", 0, MAX_SEQ),
        reason=_enum(p["reason"], "reason", REASONS),
        server_time=_epoch(p["server_time"], "server_time"),
        gmt_time=_epoch(p["gmt_time"], "gmt_time"),
        account=_account(p["account"], cfg),
        terminal=_terminal(p["terminal"]),
        symbols=MappingProxyType(symbols),
        positions=positions,
        orders=orders,
        deals=deals,
        deals_from=_epoch(p["deals_from"], "deals_from"),
    )
