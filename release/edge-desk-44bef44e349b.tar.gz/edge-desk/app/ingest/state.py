"""Small read/write helpers over the bridge tables, shared by the ingest modules."""
from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict
from typing import Mapping

_SYMBOLS_KEY = "bridge_symbols:{alias}"


def status_row(conn: sqlite3.Connection, alias: str) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM bridge_status WHERE account_alias = ?", (alias,)).fetchone()


def latest_snapshot(conn: sqlite3.Connection, alias: str) -> dict | None:
    row = status_row(conn, alias)
    return json.loads(row["snapshot_json"]) if row else None


def known_symbols(conn: sqlite3.Connection, alias: str) -> dict[str, dict]:
    """Every symbol block the bridge has sent for this account, latest values first.

    Old trades on symbols that are no longer in the snapshot still need tick size and tick value.
    """
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (_SYMBOLS_KEY.format(alias=alias),)).fetchone()
    return json.loads(row["value"]) if row else {}


def remember_symbols(conn: sqlite3.Connection, alias: str, symbols: Mapping) -> None:
    merged = known_symbols(conn, alias)
    for name, info in symbols.items():
        merged[name] = asdict(info) if not isinstance(info, dict) else dict(info)
    conn.execute("INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                 (_SYMBOLS_KEY.format(alias=alias), json.dumps(merged, sort_keys=True)))


def pip_size(cfg, symbol: str, info: Mapping | None) -> float | None:
    """EUR/USD pip from config; other symbols: 10 points on 3/5-digit quotes, else 1 point."""
    if cfg.is_eurusd(symbol):
        return cfg.instrument.pip_size
    if info and info.get("point", 0) > 0:
        return info["point"] * 10 if info.get("digits") in (3, 5) else info["point"]
    return None
