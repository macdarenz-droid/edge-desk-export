"""Bridge state for the screens and alerts: live, stale, offline or never (thresholds from config [bridge])."""
from __future__ import annotations

import sqlite3
from datetime import datetime

from app.ingest.state import status_row
from app.timeutil import from_iso


def bridge_state(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    alias = cfg.account.alias
    row = status_row(conn, alias)
    if row is None:
        return {"alias": alias, "state": "never", "last_seen_utc": None, "age_s": None, "seq": None,
                "trade_allowed": None, "reason": "No snapshot yet"}
    age = max(0, int((now - from_iso(row["last_seen_utc"])).total_seconds()))
    if age >= cfg.bridge.offline_after_s:
        state = "offline"
    elif age >= cfg.bridge.stale_after_s:
        state = "stale"
    else:
        state = "live"
    return {"alias": alias, "state": state, "last_seen_utc": row["last_seen_utc"], "age_s": age,
            "seq": row["last_seq"], "trade_allowed": bool(row["trade_allowed"]),
            "reason": f"Last snapshot {age} s ago"}
