"""Ledger 3 for MT5: one `trade` row (book='mt5') per position, rebuilt from deals and positions seen.

Readings (all money in the account currency):
- Deals with entry in/inout open the position, out/out_by/inout close it. Several entries or exits are
  combined volume-weighted. net_profit = profit + commission + swap + fee of all the position's deals.
- initial_sl: the entry deal's stop (the stop on the order that filled), else the stop the bridge saw first.
- risk_money = |open - initial_sl| / tick_size * tick_value * volume (symbol data from the bridge; for
  EUR/USD on a USD account without tick data: |open - initial_sl| * contract_size * volume).
- r_net = net_profit / risk_money (costs in); r_gross = signed price move / stop distance (costs out).
  No initial stop: risk_money, stop_pips, r_net and r_gross stay NULL (R unknown).
- balance_at_open = latest balance minus the net of every deal at or after the open (balance operations
  included), so a deposit after the trade does not inflate it. Credit deals are left out: in MT5 a credit
  changes the account's credit, not its balance (bonus deals are kept; not verified per broker).
- A position whose entry deal is older than the history window: the volume opened is worked out from what
  the bridge saw, so a partial close never shrinks the risk R is measured against: still open -> the
  volume still open (position_seen) plus every exit in the history; closed -> the larger of the exits in
  the history and the last volume seen open.
- close_reason from the last exit deal: tp -> tp; sl -> be when the stop sat at entry (within 0.5 pip) else
  sl; so -> so; client/mobile/web/expert -> manual; anything else -> other.
- Cost columns (schema 3, app/costs/split.py): mid, spread and quote drift on each side from the quotes fixed for
  the deals when first stored (app/costs/quotes.py), chart move, stop slippage and net pips.
Every symbol is kept here; analytics filters EUR/USD.
"""
from __future__ import annotations

import bisect
import sqlite3
from collections import defaultdict

from app.costs.split import trade_cost_columns
from app.db import transaction
from app.ingest.state import known_symbols, latest_snapshot, pip_size
from app.timeutil import from_iso, session_of, trading_day

ENTRY_IN = ("in", "inout")
ENTRY_OUT = ("out", "out_by", "inout")
NOT_BALANCE = ("credit",)   # deal types that change the account's credit, not its balance
_EPS = 1e-9
_COLUMNS = ("book", "account_alias", "broker_position_id", "symbol", "side", "volume", "status", "open_utc",
            "open_price", "initial_sl", "initial_tp", "close_utc", "close_price", "close_reason", "sl_at_exit",
            "profit", "commission", "swap", "fee", "net_profit", "risk_money", "stop_pips", "r_net", "r_gross",
            "balance_at_open", "pct_of_balance", "trading_day", "close_trading_day", "session", "near_miss",
            "mid_in", "mid_out", "spread_in_pips", "spread_out_pips", "quote_drift_in_pips", "quote_drift_out_pips",
            "spread_source", "quote_lag_s", "slip_exit_pips", "gross_mid_pips", "net_pips")


def risk_money(cfg, symbol: str, currency: str, stop_dist: float | None, volume: float,
               info: dict | None) -> float | None:
    if not stop_dist or stop_dist <= 0 or volume <= 0:
        return None
    if info and info.get("tick_size", 0) > 0 and info.get("tick_value", 0) > 0:
        return stop_dist / info["tick_size"] * info["tick_value"] * volume
    if cfg.is_eurusd(symbol) and currency == "USD":
        size = info.get("contract_size", 0) if info else 0
        return stop_dist * (size if size > 0 else 100_000.0) * volume
    return None


def close_reason(deal_reason: str, sl_at_exit: float | None, open_price: float, pip: float | None) -> str:
    if deal_reason == "tp":
        return "tp"
    if deal_reason == "sl":
        if sl_at_exit is not None and pip and abs(sl_at_exit - open_price) <= 0.5 * pip + _EPS:
            return "be"
        return "sl"
    if deal_reason == "so":
        return "so"
    if deal_reason in ("client", "mobile", "web", "expert"):
        return "manual"
    return "other"


def _vwap(deals: list[dict]) -> float:
    vol = sum(d["volume"] for d in deals)
    return sum(d["price"] * d["volume"] for d in deals) / vol


def _r(value: float | None, places: int) -> float | None:
    return None if value is None else round(value, places)


class _Balance:
    """Latest balance minus the net of every deal at or after a time."""

    def __init__(self, balance: float | None, deals: list[dict]):
        self.balance = balance
        deals = [d for d in deals if d["type"] not in NOT_BALANCE]
        self.times = [d["time_utc"] for d in deals]          # sorted ISO strings sort by time
        nets = [d["profit"] + d["commission"] + d["swap"] + d["fee"] for d in deals]
        self.suffix = [0.0] * (len(nets) + 1)
        for i in range(len(nets) - 1, -1, -1):
            self.suffix[i] = self.suffix[i + 1] + nets[i]

    def at(self, open_utc: str) -> float | None:
        if self.balance is None:
            return None
        return self.balance - self.suffix[bisect.bisect_left(self.times, open_utc)]


def _build(cfg, alias: str, pid: str, ds: list[dict], seen: dict | None, symbols: dict, currency: str,
           balance: _Balance, quotes: dict[str, dict] | None = None) -> dict | None:
    entries = [d for d in ds if d["entry"] in ENTRY_IN]
    exits = [d for d in ds if d["entry"] in ENTRY_OUT]
    entry_vol = sum(d["volume"] for d in entries)
    if entries and entry_vol > 0:
        first = entries[0]
        symbol, side, open_utc = first["symbol"], first["type"], first["time_utc"]
        volume, open_price = entry_vol, _vwap(entries)
        initial_sl = first["sl"] if first["sl"] is not None else (seen["initial_sl"] if seen else None)
        initial_tp = first["tp"] if first["tp"] is not None else (seen["initial_tp"] if seen else None)
    elif seen:
        symbol, side, open_utc = seen["symbol"], seen["side"], seen["open_utc"]
        out_vol = sum(d["volume"] for d in exits)
        volume = seen["volume"] + out_vol if seen["closed_utc"] is None else max(seen["volume"], out_vol)
        open_price = seen["open_price"]
        initial_sl, initial_tp = seen["initial_sl"], seen["initial_tp"]
    else:
        return None  # only exits, opened before the history window and never seen open: nothing to measure

    exit_vol = sum(d["volume"] for d in exits)
    if seen is not None and seen["closed_utc"] is None:
        closed = False                      # still in the latest snapshot
    elif seen is not None:
        closed = bool(exits)
    else:
        closed = bool(exits) and exit_vol >= volume - _EPS
        if not exits:
            # Only an entry deal, and the bridge never showed the position open: its exit is still to come
            # (the first history load is paged by InpMaxDeals), not an open trade. Wait for it (red-team EA-2).
            return None

    info = symbols.get(symbol)
    pip = pip_size(cfg, symbol, info)
    stop_dist = abs(open_price - initial_sl) if initial_sl is not None else None
    if stop_dist is not None and stop_dist <= _EPS:
        stop_dist = None                    # a first stop at entry carries no risk to measure R against
    risk = risk_money(cfg, symbol, currency, stop_dist, volume, info)
    money = {k: sum(d[k] for d in ds) for k in ("profit", "commission", "swap", "fee")}
    net = sum(money.values())
    open_dt = from_iso(open_utc)
    bal_open = balance.at(open_utc)
    row = {
        "book": "mt5", "account_alias": alias, "broker_position_id": pid, "symbol": symbol, "side": side,
        "volume": _r(volume, 8), "status": "closed" if closed else "open", "open_utc": open_utc,
        "open_price": _r(open_price, 10), "initial_sl": initial_sl, "initial_tp": initial_tp,
        "close_utc": None, "close_price": None, "close_reason": None, "sl_at_exit": None,
        **{k: _r(v, 6) for k, v in money.items()}, "net_profit": _r(net, 6),
        "risk_money": _r(risk, 6), "stop_pips": _r(stop_dist / pip, 6) if stop_dist and pip else None,
        "r_net": None, "r_gross": None,
        "balance_at_open": _r(bal_open, 6), "pct_of_balance": None,
        "trading_day": trading_day(open_dt, cfg.day.boundary_tz, cfg.day.boundary_hour).isoformat(),
        "close_trading_day": None,
        "session": session_of(open_dt, cfg.day.boundary_tz, cfg.day.boundary_hour, cfg.day.london_open,
                              cfg.day.ny_open),
        "near_miss": None,
    }
    if closed:
        last = exits[-1]
        close_price = _vwap(exits)
        sl_at_exit = last["sl"] if last["sl"] is not None else (seen["last_sl"] if seen else None)
        direction = 1.0 if side == "buy" else -1.0
        row.update({
            "close_utc": last["time_utc"], "close_price": _r(close_price, 10),
            "close_reason": close_reason(last["reason"], sl_at_exit, open_price, pip), "sl_at_exit": sl_at_exit,
            "r_net": _r(net / risk, 10) if risk else None,
            "r_gross": _r((close_price - open_price) * direction / stop_dist, 10) if stop_dist else None,
            "pct_of_balance": _r(net / bal_open * 100, 10) if bal_open and bal_open > 0 else None,
            "close_trading_day": trading_day(from_iso(last["time_utc"]), cfg.day.boundary_tz,
                                             cfg.day.boundary_hour).isoformat(),
        })
    row.update(trade_cost_columns(cfg, side, entries, exits, quotes or {}, pip, closed, row["sl_at_exit"], row))
    return row


def _same(a, b) -> bool:
    if isinstance(a, float) or isinstance(b, float):
        if a is None or b is None:
            return a is None and b is None
        return abs(a - b) <= _EPS * max(1.0, abs(a), abs(b))
    return a == b


def _upsert(conn: sqlite3.Connection, row: dict) -> int | None:
    """Insert or update one trade row; returns its id when something changed, else None."""
    old = conn.execute("SELECT * FROM trade WHERE book = 'mt5' AND account_alias = ? AND broker_position_id = ?",
                       (row["account_alias"], row["broker_position_id"])).fetchone()
    if old is None:
        cols = ", ".join(_COLUMNS)
        marks = ", ".join(f":{c}" for c in _COLUMNS)
        return conn.execute(f"INSERT INTO trade ({cols}) VALUES ({marks})", row).lastrowid
    if all(_same(old[c], row[c]) for c in _COLUMNS):
        return None
    sets = ", ".join(f"{c} = :{c}" for c in _COLUMNS)
    conn.execute(f"UPDATE trade SET {sets} WHERE id = :id", {**row, "id": old["id"]})
    return old["id"]


def sync_trades(conn: sqlite3.Connection, cfg, alias: str) -> list[int]:
    """Rebuild the MT5 trade rows of one account. Returns the ids created or changed."""
    snap = latest_snapshot(conn, alias)
    currency = snap["account"]["currency"] if snap else cfg.account.currency
    balance = snap["account"]["balance"] if snap else None
    symbols = dict(known_symbols(conn, alias))
    if snap:
        symbols.update(snap["symbols"])
    deals = [dict(r) for r in conn.execute("SELECT * FROM deal WHERE account_alias = ?", (alias,))]
    deals.sort(key=lambda d: (d["time_utc"], int(d["deal_id"])))
    seen = {r["position_id"]: dict(r) for r in
            conn.execute("SELECT * FROM position_seen WHERE account_alias = ?", (alias,))}
    by_pos: dict[str, list[dict]] = defaultdict(list)
    for d in deals:
        if d["type"] in ("buy", "sell") and d["position_id"] not in (None, "", "0"):
            by_pos[d["position_id"]].append(d)
    bal = _Balance(balance, deals)
    quotes = {r["deal_id"]: dict(r) for r in conn.execute("SELECT * FROM deal_quote WHERE account_alias = ?", (alias,))}
    changed: list[int] = []
    with transaction(conn):
        for pid in sorted(set(by_pos) | set(seen), key=int):
            row = _build(cfg, alias, pid, by_pos.get(pid, []), seen.get(pid), symbols, currency, bal, quotes)
            if row is not None:
                tid = _upsert(conn, row)
                if tid is not None:
                    changed.append(tid)
    return changed
