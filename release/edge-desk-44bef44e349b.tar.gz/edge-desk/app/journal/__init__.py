"""Journal: the three ledgers (opportunity, choice, actual trade) and the weekly review note."""
