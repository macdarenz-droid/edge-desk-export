"""The trade picture (docs/JOURNAL_DESIGN.md section 7): the pinned A12 engine (pinned/, checked by pins.py) runs in its
own `python -I -B` process (child.py) from the method worker (step.py) and stores its data in journal_analysis; the
server turns that data into the tag lines (words.py) and a standard-library SVG (picture.py), served by views.py.
Never an order, never a verdict: the tags describe the owner's own trade."""
