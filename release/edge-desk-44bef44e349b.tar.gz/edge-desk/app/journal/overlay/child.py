"""The trade picture's child process (docs/JOURNAL_DESIGN.md D10, section 7): the pinned A12 engine, unchanged, on
the app's own prices, for one journal trade.

Run only as `python -I -B child.py` (no user site, no PYTHONPATH, not the script's folder on sys.path, no bytecode
written). stdin: an .npz with ts_utc (int64), bid_o..ask_c (float64, the feed's prices), volume (int64) and `request`
(JSON, request() below names every key). stdout: one JSON object, {"status": "done", ...} or {"status": "refused",
"message"}.

Order of work:
  1. pins.verify (standard library; pins.py is loaded from this folder by its path, not as a package) before anything
     is imported from the copy; any difference: status "refused".
  2. The copy's folder goes on sys.path and `a12` is imported (it imports data, engine and walk); every bare-name
     module must come from the copy. No loader, stage gate or frozen-file check of a12 is ever called: they read
     research paths, and no file outside the copy is opened (tests/test_journal_pins.py).
  3. Prices to K1 units (points = rint(price x 100000), refused unless every price is within 1e-6 of a whole point),
     then the engine's own K2 cleaning (data.clean) and K1 conversion (data.to_units).
  4. tau = the last 5m close at or before the decision (floor(decision / 300) x 300). Every tag (T1-T8) is computed on
     a12.day_from_units(..., cut=tau): no row opening at or after tau exists for them (section 7.3). The minutes
     between tau and the decision get one extra item (gap), tested only against levels known by tau.
  5. The picture's marks (locations with their grades, the 5m walk, the day's high and low, 5m and 15m mid bars of
     the New York day) come from the whole day so far; marks known after tau are flagged "after". T10 (after the
     order) is its own item and never a tag input.
Prices go out as prices (units / 400,000), times as unix seconds. Words are added by the server
(app/journal/overlay/words.py): this output is data only.

The top level imports only the standard library: compute() loads the copy when it is first called, so the tests can
call it in their own process (then unload()). The app's processes never import the pinned code.
"""
import io
import json
import sys
import types
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
PINNED = HERE / "pinned"
QFIELDS = ("bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")
PAIR = "EUR_USD"                     # EUR/USD only (design D1)
POINT_TOL = 1e-6                     # a stored price must be this close to a whole point (0.00001)
U = 400000                           # K1 units per 1.0 of price (1 pip = 40 units)
PIP = 40
NEAR_STOP = 140                      # T6(c): untaken same-side levels up to 3.5 pips past the stop (design 7.2)
AT_LEVEL = 60                        # T10: levels formed after the order within 1.5 pips of the stop or target
FAILED_ABOVE_S = 6 * 3600            # T2: a failed POI started within 6 h before the one that holds is named
PICTURE_BAND = 30 * PIP              # stored locations: within 30 pips of the day's range (the picture's price span)
CHILD_VERSION = 2                    # 2: with nothing holding, T2 names the latest failure only
KINDS = ("market", "buy_limit", "sell_limit", "buy_stop", "sell_stop", "buy_stop_limit", "sell_stop_limit",
         "unknown")
TAU_HOW = ("order", "fill", "unknown")
# a12.py puts these two research folders at sys.path[1] and [2] when it is imported, unless they are on the path
# already (its "if _p not in sys.path" check). load() puts them at the END for the import, so a12 skips its insert and
# no module is ever searched for in /tmp before the interpreter's own folders, then takes them off again.
_SCRATCH = "/tmp/claude-0/-home-user-Forex-signal/f43e2ef7-af07-5a67-8027-a2e50c2c9526/scratchpad"
RESEARCH_PATHS = (_SCRATCH + "/marc_test/v2x_a12/engine", _SCRATCH + "/marc_test/v2x")
REQUEST_KEYS = {"ref", "pair", "D", "side", "kind", "entry", "stop", "target", "decision", "tau_how", "fill_t",
                "exit_t", "exit_price", "exit_kind", "through"}


class ChildRefused(RuntimeError):
    pass


def _pins():
    """app/journal/overlay/pins.py (standard library only), compiled from its source here: no app package is
    imported and no cached bytecode of it is ever read (a __pycache__ beside it is not checked by the pins)."""
    mod = sys.modules.get("_journal_overlay_pins")
    if mod is not None:
        return mod
    path = HERE / "pins.py"
    mod = types.ModuleType("_journal_overlay_pins")
    mod.__file__ = str(path)
    sys.modules["_journal_overlay_pins"] = mod
    try:
        exec(compile(path.read_bytes(), str(path), "exec"), mod.__dict__)   # noqa: S102  (the app's own file)
    except BaseException:
        sys.modules.pop("_journal_overlay_pins", None)
        raise
    return mod


def load(pinned_dir: Path = PINNED) -> dict:
    """Verify the copy, then import it by bare name. Returns {name: module}. Raises ChildRefused."""
    pins = _pins()
    pinned_dir = Path(pinned_dir).resolve()
    try:
        pins.verify(pinned_dir)
    except pins.Refused as e:
        raise ChildRefused(f"pinned code refused: {e}") from None
    loaded = {n: sys.modules.get(n) for n in pins.BARE}
    if all(m is not None for m in loaded.values()):
        _check_origin(pinned_dir, loaded, pins)
        return loaded
    if any(m is not None for m in loaded.values()):
        raise ChildRefused("another module of the same bare name is already loaded")
    before = sys.dont_write_bytecode
    sys.dont_write_bytecode = True           # never a __pycache__ in the copy (pins.verify refuses one)
    import dataclasses  # noqa: F401  (the standard-library modules the copy imports, loaded before its import)
    import zoneinfo  # noqa: F401
    sys.path.insert(0, str(pinned_dir))
    tail = [p for p in RESEARCH_PATHS if p not in sys.path]
    sys.path.extend(tail)                    # last on the path: a12.py's own insert at [1] and [2] is skipped
    for p in tail:
        sys.path_importer_cache[p] = None    # and no finder for them: a module missing everywhere (Python 3.13's
    try:                                     # platform asks for _wmi) is never looked for in them
        import a12  # noqa: F401  (imports data, engine and walk by bare name)
    finally:
        sys.dont_write_bytecode = before
        for p in tail:
            while p in sys.path:
                sys.path.remove(p)
            sys.path_importer_cache.pop(p, None)
    mods = {n: sys.modules.get(n) for n in pins.BARE}
    _check_origin(pinned_dir, mods, pins)
    return mods


def _check_origin(pinned_dir: Path, mods: dict, pins) -> None:
    for name in pins.BARE:
        m = mods.get(name)
        if m is None or Path(m.__file__).resolve().parent != pinned_dir:
            raise ChildRefused(f"module {name} was not loaded from the pinned copy")


def unload(pinned_dir: Path = PINNED) -> None:
    """Remove the copy's bare-name modules and folder from this process (tests, after an in-process run)."""
    for n in ("a12", "walk", "data", "engine"):
        sys.modules.pop(n, None)
    p = str(Path(pinned_dir).resolve())
    while p in sys.path:
        sys.path.remove(p)


# ---------------------------------------------------------------- small helpers

def peak_mb() -> float:
    """This process's peak resident memory in MB: VmHWM (Linux), which starts again at exec, so the parent's pages
    seen between fork and exec are not counted (ru_maxrss counts them); ru_maxrss where /proc is missing."""
    try:
        with open("/proc/self/status", encoding="ascii") as f:
            for ln in f:
                if ln.startswith("VmHWM:"):
                    return round(int(ln.split()[1]) / 1024, 1)
    except OSError:
        pass
    import resource
    return round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 1)


def u2p(x):
    return None if x is None else round(int(x) / U, 6)


def p2u(p):
    return None if p is None else int(round(float(p) * U))


def _plain(x):
    """JSON-safe copy: numpy scalars -> Python numbers, tuples -> lists, dict keys -> text."""
    if isinstance(x, dict):
        return {str(k): _plain(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_plain(v) for v in x]
    if hasattr(x, "item") and not isinstance(x, (str, bytes)):
        return x.item()
    return x


def request_ok(req: dict) -> dict:
    """The request's keys and values, checked. Raises ChildRefused."""
    if not isinstance(req, dict) or set(req) != REQUEST_KEYS:
        got = set(req) if isinstance(req, dict) else set()
        raise ChildRefused(f"request keys differ: extra {sorted(got - REQUEST_KEYS)}, missing "
                           f"{sorted(REQUEST_KEYS - got)}")
    if req["pair"] != PAIR:
        raise ChildRefused(f"pair {req['pair']!r}: only {PAIR}")
    if req["side"] not in ("buy", "sell"):
        raise ChildRefused("side must be buy or sell")
    if req["kind"] not in KINDS:
        raise ChildRefused(f"kind {req['kind']!r} unknown")
    if req["tau_how"] not in TAU_HOW:
        raise ChildRefused(f"tau_how {req['tau_how']!r} unknown")
    for k in ("entry",):
        if not isinstance(req[k], (int, float)) or not req[k] > 0:
            raise ChildRefused(f"{k} must be a price")
    for k in ("stop", "target", "exit_price"):
        if req[k] is not None and (not isinstance(req[k], (int, float)) or not req[k] > 0):
            raise ChildRefused(f"{k} must be a price or null")
    for k in ("decision", "through"):
        if not isinstance(req[k], int) or isinstance(req[k], bool):
            raise ChildRefused(f"{k} must be a whole number of seconds")
    for k in ("fill_t", "exit_t"):
        if req[k] is not None and (not isinstance(req[k], int) or isinstance(req[k], bool)):
            raise ChildRefused(f"{k} must be a whole number of seconds or null")
    try:
        date.fromisoformat(req["D"])
    except (TypeError, ValueError):
        raise ChildRefused("D must be a date") from None
    if req["tau_how"] in ("fill", "unknown") and req["fill_t"] is not None and req["decision"] != req["fill_t"]:
        raise ChildRefused("a market fill or an unknown order time: the decision must be the fill")
    return req


def to_units(arrays: dict, mods: dict) -> tuple[dict, dict]:
    """The feed's float prices -> the engine's unit arrays through its own K2 cleaning and K1 units."""
    import numpy as np
    DA = mods["data"]
    ts = np.asarray(arrays["ts_utc"], dtype=np.int64)
    if len(ts) == 0:
        raise ChildRefused("no bars")
    raw = {"ts_utc": ts.copy(), "volume": np.asarray(arrays["volume"], dtype=np.int64).copy()}
    for f in QFIELDS:
        x = np.asarray(arrays[f], dtype=np.float64) * 100000.0
        if not np.all(np.isfinite(x)):
            raise ChildRefused(f"{f}: a price is not a number")
        r = np.rint(x)
        worst = float(np.abs(x - r).max())
        if worst > POINT_TOL:
            raise ChildRefused(f"{f}: a price is {worst:.2e} points away from a whole point")
        raw[f] = r / 100000.0
    cleaned, rep = DA.clean(raw)
    u = DA.to_units(cleaned)
    u.pop("_k1_worst", None)
    rep = {k: v for k, v in rep.items() if isinstance(v, (int, float))}
    return u, rep


def loc_dict(A, L, tau: int) -> dict:
    """A location as the engine holds it (prices from units), with its grade at tau when it started by then."""
    d = dict(id=L.id, side=L.side, kind=L.kind, grp=L.grp, tf=L.tf, lo=u2p(L.lo), hi=u2p(L.hi), N=u2p(L.N),
             edge=u2p(L.edge), known=int(L.known), s=None if L.s is None else int(L.s), status=L.status,
             g2=L.g2, fT=L.fT, before=bool(L.known <= tau))
    if L.status == "STARTED" and L.s is not None and L.s <= tau:
        d["grade_at_tau"] = A.grade_at(L, tau)
    return d


def ev_dict(m5, e) -> dict:
    return dict(t=int(m5.e[e["j"]]), dir=e["dir"], kind=e["kind"], broken=u2p(e["broken"][0]),
                broken_t=int(m5.t[e["broken"][1]]), prot=u2p(e["prot"][0]), prot_t=int(m5.t[e["prot"][1]]),
                X=u2p(e["X"][0]), X_t=int(m5.t[e["X"][1]]))


# ---------------------------------------------------------------- the tags at tau (T1-T8), data only

def tags_at(mods: dict, day, req: dict, tau: int, E: int, S, T) -> tuple[dict, list]:
    """T1-T8 on the day cut at tau. Returns (tags, the cut day's location ids)."""
    import numpy as np
    A, DA = mods["a12"], mods["data"]
    D = day.D
    long_ = req["side"] == "buy"
    side, opp = ("L", "S") if long_ else ("S", "L")
    want = "UP" if long_ else "DOWN"
    locs, _crts, _ = A.build_locations(day)
    W = A.Walk(day)
    m5 = day.m5
    evs = [e for e in W.events if int(m5.e[e["j"]]) <= tau]
    d = None
    if S is not None:
        d = (E - S) if long_ else (S - E)
        if d <= 0:
            d = None                                   # a stop at or past the entry: no risk to measure against

    # T1 session (the research definition, A12.2.2 AS; design 7.1)
    t1 = dict(session="asia" if tau < DA.lon(D, 7) else ("london" if tau < DA.nyt(D, 7) else "new_york"),
              tau=tau, decision=int(req["decision"]))

    # T2 and T3: his side's locations started on D by tau, the latest first
    mine = sorted([L for L in locs if L.side == side and L.status == "STARTED" and L.s is not None
                   and day.L00 <= L.s <= tau], key=lambda L: (-L.s, L.id))
    zones = [L for L in mine if L.is_zone]
    holds = [L for L in zones if A.grade_at(L, tau) in (1, 2)]
    failed = [L for L in zones if A.grade_at(L, tau) == "F"]
    t2 = dict(holds=None, failed=None)
    if holds:
        touched = min(L.s for L in holds)
        t2["holds"] = dict(lo=u2p(min(L.lo for L in holds)), hi=u2p(max(L.hi for L in holds)),
                           kinds=sorted({L.kind for L in holds}), touched=int(touched),
                           grade=min(A.grade_at(L, tau) for L in holds), ids=[L.id for L in holds])
        recent = [L for L in failed if L.s >= touched - FAILED_ABOVE_S]
    elif failed:                                       # nothing holds: the latest failure before tau, one quoted time
        last = max(L.fT for L in failed)
        recent = [L for L in failed if L.fT == last]
    else:
        recent = []
    if recent:
        t2["failed"] = dict(lo=u2p(min(L.lo for L in recent)), hi=u2p(max(L.hi for L in recent)),
                            kinds=sorted({L.kind for L in recent}), failed_t=int(min(L.fT for L in recent)),
                            ids=[L.id for L in recent])
    levels = [L for L in mine if not L.is_zone]
    other = [L for L in locs if L.side == opp and not L.is_zone and L.status == "STARTED" and L.s is not None
             and day.L00 <= L.s <= tau]
    t3 = dict(taken=[dict(id=L.id, kind=L.kind, side=L.side, level=u2p(L.edge), s=int(L.s),
                          grade=A.grade_at(L, tau), fT=L.fT) for L in levels[:2]],
              both_sides=bool(levels and other))

    # T4 5m structure: the walk at tau, since the first start of his side's locations on D (R1 / R2 triggers,
    # A12.2.4): CHoCH then BOS with no opposite event between = high confidence; CHoCH only = low confidence; else a
    # BOS his way after an opposite location started on D failed = continuation (C1); else no break
    first_start = min((L.s for L in mine), default=None)
    pattern, choch, bos = "none", None, None
    if first_start is not None:
        for e in [e for e in evs if int(m5.e[e["j"]]) > first_start]:
            if e["dir"] != want:
                choch, bos = None, None
                continue
            if e["kind"] == "CHOCH":
                choch, bos = e, None
            elif e["kind"] == "BOS" and choch is not None:
                bos = e
        if choch and bos:
            pattern = "choch_bos"
        elif choch:
            pattern = "choch"
    failed_opp = None
    if pattern == "none" and evs and evs[-1]["dir"] == want and evs[-1]["kind"] == "BOS":
        cj = int(m5.e[evs[-1]["j"]])
        fo = [L for L in locs if L.side == opp and L.status == "STARTED" and L.s is not None and L.s >= day.L00
              and A.failed_by(L, cj)]
        if fo:
            pattern, bos = "continuation", evs[-1]
            last = max(fo, key=lambda L: (L.fT, L.id))
            failed_opp = dict(id=last.id, kind=last.kind, lo=u2p(last.lo), hi=u2p(last.hi), fT=int(last.fT))
    trig = bos or choch
    t4 = dict(pattern=pattern, choch=ev_dict(m5, choch) if choch else None, bos=ev_dict(m5, bos) if bos else None,
              last=ev_dict(m5, evs[-1]) if evs else None, failed_opp=failed_opp,
              events=[ev_dict(m5, e) for e in evs if int(m5.e[e["j"]]) > day.L00])

    # T5 entry: the leg's zone (A12.2.5 step 4) with the last complete 5m bar at tau as the order bar
    t5 = None
    zone = None
    if trig is not None:
        ob = int(np.searchsorted(m5.e, tau, side="right")) - 1
        zone = A.pick_zone(day, long_, trig["prot"][1], trig["broken"][1], ob, tau)
    if zone:
        mid = (zone["lo"] + zone["hi"]) / 2
        t5 = dict(kind=zone["kind"], lo=u2p(zone["lo"]), hi=u2p(zone["hi"]), sync=zone["sync"], c3=int(zone["c3"]),
                  entry_inside=bool(zone["lo"] <= E <= zone["hi"]),
                  entry_vs_middle_pips=round(((E - mid) if long_ else (mid - E)) / PIP, 1))

    # T6 stop: (a) past the gap's far edge; (b) against the swing that protects the break (its bid low for a long,
    # ask high for a short); (c) untaken levels of his side between the entry and the stop or up to 3.5 pips past it
    t6 = dict(past_gap_pips=None, swing=None, near=[])
    if S is not None:
        if zone:
            t6["past_gap_pips"] = round(((zone["lo"] - S) if long_ else (S - zone["hi"])) / PIP, 1)
        if trig is not None:
            X, xb = trig["X"][0], trig["X"][1]
            qa, qb = day.i1(int(m5.t[xb])), day.i1(int(m5.e[xb]))
            q_ext = int(day.q["bid_l"][qa:qb].min()) if long_ else int(day.q["ask_h"][qa:qb].max())
            t6["swing"] = dict(body=u2p(trig["prot"][0]), wick=u2p(X), wick_t=int(m5.t[xb]), quote=u2p(q_ext),
                               stop_past_wick_pips=round(((X - S) if long_ else (S - X)) / PIP, 1),
                               stop_past_quote_pips=round(((q_ext - S) if long_ else (S - q_ext)) / PIP, 1))
        for L in locs:
            if L.side != side or L.is_zone or L.known > tau:
                continue
            if L.s is not None and L.s <= tau:
                continue                                   # already taken by tau
            lv = L.edge
            beyond = (S - lv) if long_ else (lv - S)       # > 0: the level lies past the stop
            between = (E - lv) if long_ else (lv - E)
            if (0 <= beyond <= NEAR_STOP) or (beyond < 0 and between > 0):
                t6["near"].append(dict(id=L.id, kind=L.kind, level=u2p(lv), beyond_stop_pips=round(beyond / PIP, 1)))
        t6["near"].sort(key=lambda x: (x["beyond_stop_pips"], x["id"]))

    # T7 target: R and the next opposing POI live at tau (A12.2.5 step 8 search)
    t7 = dict(tp_R=None, next_poi=None)
    if d is not None and T is not None:
        t7["tp_R"] = round(((T - E) if long_ else (E - T)) / d, 2)
    npoi = A.next_poi([L for L in locs if L.side == opp], tau, E, long_)
    if npoi is not None:
        dist, L = npoi
        t7["next_poi"] = dict(id=L.id, kind=L.kind, tf=L.tf, N=u2p(L.N), lo=u2p(L.lo), hi=u2p(L.hi),
                              dist_pips=round(dist / PIP, 1), dist_R=None if d is None else round(dist / d, 2))

    # T8 bias: daily (W3) and 4h (A1) at tau, a confidence point only
    _F3, _F4, bs, w3, hb = A.bias_tags(day, side, tau)
    t8 = dict(daily=w3, h4=hb, state=bs)

    # the day's high and low so far at tau (New York day, his MT5 D1 candle)
    ai = day.i1(DA.nyt(D - timedelta(days=1), 17))
    so_far = None
    if len(day.t1) > ai:
        so_far = dict(high=u2p(int(day.mh[ai:].max())), low=u2p(int(day.ml[ai:].min())))
    tags = dict(T1=t1, T2=t2, T3=t3, T4=t4, T5=t5, T6=t6, T7=t7, T8=t8, so_far=so_far,
                stop_pips=None if d is None else round(d / PIP, 1))
    return tags, locs


# ---------------------------------------------------------------- the minutes between tau and the decision

def gap_minutes(dayf, locs_cut, tau: int, decision: int) -> dict | None:
    """One extra item for the M1 bars opening in [tau, the decision minute): which levels known and untaken at tau
    were traded through (0.5 pip, K5) in those minutes. Built only from levels known by tau."""
    end = decision // 60 * 60
    if end <= tau:
        return None
    a, b = dayf.i1(tau), dayf.i1(end)
    taken = []
    for L in locs_cut:
        if L.is_zone or L.s is not None:
            continue                                     # zones are POIs; levels taken by tau are T3's
        if L.side == "L":
            k = dayf.first_le(a, b, L.edge - 20)
        else:
            k = dayf.first_ge(a, b, L.edge + 20)
        if k is not None:
            taken.append(dict(id=L.id, kind=L.kind, side=L.side, level=u2p(L.edge), at=int(dayf.t1[k])))
    taken.sort(key=lambda x: (x["at"], x["id"]))
    return dict(start=tau, end=end, taken=taken)


# ---------------------------------------------------------------- after the order (T10), never a tag input

def after_order(mods: dict, dayf, locs_f, Wf, req: dict, tau: int, E: int, S, T) -> dict:
    import numpy as np
    long_ = req["side"] == "buy"
    side, opp = ("L", "S") if long_ else ("S", "L")
    q = dayf.q
    n = len(dayf.t1)
    data_end = int(dayf.t1[-1]) + 60 if n else tau
    fill_t, exit_t = req["fill_t"], req["exit_t"]
    end = exit_t if exit_t is not None else data_end
    d = None
    if S is not None:
        d = (E - S) if long_ else (S - E)
        d = d if d > 0 else None
    out = dict(price_check=None, best=None, exit=None, at_levels=[], breaks=[], data_end=data_end)
    if fill_t is not None:
        fm = fill_t // 60 * 60
        fi = dayf.i1(fm)
        if fi < n and int(dayf.t1[fi]) == fm:
            lo, hi = (int(q["ask_l"][fi]), int(q["ask_h"][fi])) if long_ else (int(q["bid_l"][fi]), int(q["bid_h"][fi]))
            out["price_check"] = dict(minute=fm, side="ask" if long_ else "bid", band=[u2p(lo), u2p(hi)],
                                      off_pips=round(max(0, lo - E, E - hi) / PIP, 1))
        xi = dayf.i1(end // 60 * 60 + 60)
        if xi > fi:
            if long_:
                hi_a, lo_a = q["bid_h"][fi:xi], q["bid_l"][fi:xi]
                best, worst = int(hi_a.max()) - E, E - int(lo_a.min())
                best_t = int(dayf.t1[fi + int(np.argmax(hi_a))])
            else:
                hi_a, lo_a = q["ask_h"][fi:xi], q["ask_l"][fi:xi]
                best, worst = E - int(lo_a.min()), int(hi_a.max()) - E
                best_t = int(dayf.t1[fi + int(np.argmin(lo_a))])
            out["best"] = dict(best_pips=round(best / PIP, 1), best_t=best_t, worst_pips=round(worst / PIP, 1),
                               best_R=None if d is None else round(best / d, 2))
    if exit_t is not None and req["exit_price"] is not None:
        X = p2u(req["exit_price"])
        out["exit"] = dict(t=int(exit_t), price=req["exit_price"], kind=req["exit_kind"],
                           R=None if d is None else round(((X - E) if long_ else (E - X)) / d, 2))
    for L in locs_f:
        if L.is_zone or not (tau < L.known <= end):
            continue
        for want_side, ref, what in ((side, S, "stop"), (opp, T, "target")):
            if ref is not None and L.side == want_side and abs(L.edge - ref) <= AT_LEVEL:
                out["at_levels"].append(dict(id=L.id, kind=L.kind, side=L.side, level=u2p(L.edge), at=what,
                                             known=int(L.known), s=None if L.s is None else int(L.s)))
    m5 = dayf.m5
    out["breaks"] = [ev_dict(m5, e) for e in Wf.events if tau < int(m5.e[e["j"]]) <= end]
    return out


def _ids(x, out: set) -> set:
    if isinstance(x, dict):
        if isinstance(x.get("id"), str):
            out.add(x["id"])
        for k, v in x.items():
            if k == "ids" and isinstance(v, list):
                out.update(i for i in v if isinstance(i, str))
            else:
                _ids(v, out)
    elif isinstance(x, list):
        for v in x:
            _ids(v, out)
    return out


def day_locs(dayf, locs_f, a: int, b: int, tags: dict) -> list:
    """The locations the picture may draw: alive on the day (not gone before 00:00 London on D, not an old equal
    level), within PICTURE_BAND of the New York day's range, plus every one a tag names. The rest of the 90-day
    tracking list is not stored."""
    named = _ids(tags, set())
    if b > a:
        lo, hi = int(dayf.ml[a:b].min()) - PICTURE_BAND, int(dayf.mh[a:b].max()) + PICTURE_BAND
    else:
        lo = hi = None
    out = []
    for L in locs_f:
        if L.id in named:
            out.append(L)
        elif L.status in ("GONE", "EQ_OLD") or lo is None:
            continue
        elif L.hi >= lo and L.lo <= hi:
            out.append(L)
    return out


# ---------------------------------------------------------------- one run

def compute(arrays: dict, req: dict, pinned_dir: Path = PINNED) -> dict:
    import time
    import numpy as np
    t0 = time.perf_counter()
    request_ok(req)
    mods = load(pinned_dir)
    A, DA = mods["a12"], mods["data"]
    D = date.fromisoformat(req["D"])
    decision = int(req["decision"])
    tau = decision // 300 * 300
    ny0, ny1 = DA.nyt(D - timedelta(days=1), 17), DA.nyt(D, 17)
    if not ny0 <= tau < ny1:
        raise ChildRefused("the order time is not on the trading day D")
    ts = np.asarray(arrays["ts_utc"], dtype=np.int64)
    if len(ts) and int(ts.max()) >= min(int(req["through"]), ny1):
        raise ChildRefused("a bar at or after the end of the prices given was passed")
    u, rep = to_units(arrays, mods)
    long_ = req["side"] == "buy"
    E, S, T = p2u(req["entry"]), p2u(req["stop"]), p2u(req["target"])

    day = A.day_from_units(PAIR, D, u, cut=tau)
    if len(day.t1) == 0 or int(day.t1[-1]) >= tau:
        raise ChildRefused("no prices before the order")
    tags, locs_cut = tags_at(mods, day, req, tau, E, S, T)
    t_tags = time.perf_counter()

    dayf = A.day_from_units(PAIR, D, u)
    locs_f, _c, _ = A.build_locations(dayf)
    Wf = A.Walk(dayf)
    gap = gap_minutes(dayf, locs_cut, tau, decision)
    a, b = dayf.i1(ny0), dayf.i1(ny1)
    day_hl = None
    if b > a:
        hi_i = a + int(np.argmax(dayf.mh[a:b]))
        lo_i = a + int(np.argmin(dayf.ml[a:b]))
        day_hl = dict(high=u2p(int(dayf.mh[hi_i])), high_t=int(dayf.t1[hi_i]), low=u2p(int(dayf.ml[lo_i])),
                      low_t=int(dayf.t1[lo_i]))

    def candles(L):
        bb = A.make_bars(dayf.t1[a:b], dayf.mo[a:b], dayf.mh[a:b], dayf.ml[a:b], dayf.mc[a:b], L)
        return [[int(t), u2p(o), u2p(h), u2p(lw), u2p(c)] for t, o, h, lw, c in zip(bb.t, bb.o, bb.h, bb.l, bb.c)]

    m5f = dayf.m5
    marks = dict(day_hl=day_hl, locs=[loc_dict(A, L, tau) for L in day_locs(dayf, locs_f, a, b, tags)],
                 tag_ids=sorted(L.id for L in locs_cut),
                 walk=[ev_dict(m5f, e) for e in Wf.events if int(m5f.e[e["j"]]) > DA.lon(D, 0)])
    after = after_order(mods, dayf, locs_f, Wf, req, tau, E, S, T)
    t_pic = time.perf_counter()
    out = dict(
        status="done", version=CHILD_VERSION, pins_sha=_pins().PINS_SHA, ref=req["ref"], D=D.isoformat(), tau=tau,
        decision=decision, tau_how=req["tau_how"],
        trade=dict(side=req["side"], kind=req["kind"], entry=req["entry"], stop=req["stop"], target=req["target"],
                   fill_t=req["fill_t"], exit_t=req["exit_t"], exit_price=req["exit_price"],
                   exit_kind=req["exit_kind"], long=long_),
        data=dict(rows=int(len(u["t1"])), first=int(u["t1"][0]), last=int(u["t1"][-1]), through=int(req["through"]),
                  clean=rep),
        tags=tags, gap=gap, after=after, marks=marks,
        bars=dict(m5=candles(300), m15=candles(900)),
        cost=dict(tags_s=round(t_tags - t0, 3), picture_s=round(t_pic - t_tags, 3), seconds=round(t_pic - t0, 3),
                  peak_rss_mb=peak_mb()),
        versions=dict(python=sys.version.split()[0], numpy=np.__version__))
    return _plain(out)


def read_npz(raw: bytes) -> tuple[dict, dict]:
    import numpy as np
    with np.load(io.BytesIO(raw), allow_pickle=False) as z:
        req = json.loads(str(z["request"]))
        arrays = {k: z[k] for k in ("ts_utc", "volume") + QFIELDS}
    return arrays, req


def compute_npz(raw: bytes, pinned_dir: Path = PINNED) -> dict:
    arrays, req = read_npz(raw)
    return compute(arrays, req, pinned_dir)


def main() -> int:
    try:
        arrays, req = read_npz(sys.stdin.buffer.read())       # the raw bytes are freed before the work
        out = compute(arrays, req)
    except ChildRefused as e:
        out = {"status": "refused", "message": str(e)[:500]}
    sys.stdout.write(json.dumps(out, sort_keys=True, allow_nan=False))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
