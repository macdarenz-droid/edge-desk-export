"""The trade picture as a standard-library SVG (docs/JOURNAL_DESIGN.md D11, sections 7.1 and 7.4), drawn on request from
the stored analysis (journal_analysis): no matplotlib, no Pillow, nothing kept as a file.

Rules (section 7.4, section 10, and the trader's review of 30 Oct):
  - 1080 x 1620 px (about one screen at 2.7 device pixels per CSS pixel), shown edge to edge in an <img>.
  - Every text at least 40 px (font-size attribute); only presentation attributes: no <style>, no script, no href,
    no foreignObject, no <image>; every text escaped.
  - Every mark has a short label or a numbered marker that matches a tag line (words.py numbers); a mark that gets
    neither (its label does not fit and it has no number) is not drawn, except the POI the tag names, which always
    carries its number. Marks known after tau are faded. The tag sentences are not in the picture: they are page text
    from the tags route, which marks each numbered line with the views that draw its number (views.page_for).
  - A mark with a time (the order, the fill, the exit) is drawn at its true time or not at all. The 5m view keeps the
    setup and the order; when the trade runs past 120 bars, the end is cut and a "Continues" mark says so.
  - Labels never cover a candle or the entry, stop and target lines; a number sits at most 112 px from its mark, with a
    short leader line when it is not beside it. The fill, exit and swing marks are drawn over the candles.
  - The time axis has two rows, Melbourne 12-hour on top and London below (design D16): every hour on a 5m window of
    5 hours or less, else every 2 hours, every 4 hours on the 15m day. Entry, stop and target are MT5-style tags on
    the price axis, and an axis price under a tag is hidden.
  - Dark and light themes from the app's tokens (app/web/static/app.css).
render() returns (svg text, layout): layout lists every drawn mark with its label, number and time, for the tests; a
debug dict, when given, gets the geometry the tests check.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from xml.sax.saxutils import escape

from app.timeutil import LONDON, MELBOURNE, NEW_YORK

VERSION = "picture-3"
W, H = 1080, 1620
STRIP_T, STRIP_B = 6, 70                  # session strip
CH_L, CH_R, CH_T, CH_B = 10, 856, 80, 1440  # chart area; the price-axis column is CH_R..W
ROW_MEL, ROW_LON = 1500, 1572             # the two time-axis rows (text baselines)
FS = 40                                   # every text: at least 40 px
CHAR_W = 0.56                             # average advance of the sans fallback, per px of font size
MARK_R = 27                               # numbered marker radius
MAX_DRIFT = 112                           # a number's centre at most this far (each way) from its mark
LEADER_MIN = MARK_R + 14                  # farther than this from its mark: a leader line joins them
# where a numbered marker may sit around its mark: 28 px steps up to MAX_DRIFT, never on the mark itself, nearest first
MARK_TRIES = sorted(((dx, dy) for dx in range(-MAX_DRIFT, MAX_DRIFT + 1, 28)
                     for dy in range(-MAX_DRIFT, MAX_DRIFT + 1, 28) if math.hypot(dx, dy) >= MARK_R + 4),
                    key=lambda d: (round(math.hypot(*d)), abs(d[1]), d))
BARS_5M = 120                             # the 5m view's most bars
MIN_BOX_W = 24                            # a POI box narrower than this is not drawn (the named one is widened)
FONT = "Geist, Inter, system-ui, -apple-system, Roboto, sans-serif"
PIP = 0.0001

THEMES = {
    "dark": dict(bg="#0a0a09", panel="#111110", grid="#262624", text="#f4f3f0", text2="#a4a29c", text3="#8a8882",
                 up="#00ca52", down="#ff5e63", liq="#3987e5", struct="#9085e9", entry="#c98500", stop="#ff5e63",
                 target="#00ca52", poi="#a4a29c", asia="#16161c", london="#141413", ny="#14140f", on="#0a0a09"),
    "light": dict(bg="#fdfdfc", panel="#f8f7f5", grid="#e2e1dd", text="#1a1917", text2="#55534e", text3="#69675f",
                  up="#107d32", down="#d60020", liq="#0064e2", struct="#5e6ad2", entry="#a64f00", stop="#d60020",
                  target="#107d32", poi="#69675f", asia="#eeeef4", london="#f3f2ef", ny="#f1f0ea", on="#ffffff"),
}
SESSION_SHORT = {"Asia": "Asia", "London": "LDN", "New York": "NY"}
LEVEL_SHORT = {"AS": ("Asian low", "Asian high"), "PD": ("Yesterday's low", "Yesterday's high"),
               "EQ": ("Equal lows", "Equal highs"), "HS": ("1h swing low", "1h swing high"),
               "CRT1": ("1h CRT low", "1h CRT high"), "CRT4": ("4h CRT low", "4h CRT high")}
OVER_CANDLES = ("fill", "exit", "swing")   # drawn after the candles, so a candle never hides them


def text_w(s: str, size: int = FS) -> float:
    return CHAR_W * size * len(s)


def fnum(v: float) -> str:
    return ("%.1f" % v).rstrip("0").rstrip(".")


def hhmm(t: int) -> str:
    return datetime.fromtimestamp(int(t), LONDON).strftime("%H:%M")


def mel_hour(t: int) -> str:
    m = datetime.fromtimestamp(int(t), MELBOURNE)
    h = m.hour % 12 or 12
    return (f"{h}" if m.minute == 0 else f"{h}:{m.minute:02d}") + (" am" if m.hour < 12 else " pm")


def at(d: date, hh: int, tz, mm: int = 0) -> int:
    return int(datetime(d.year, d.month, d.day, hh, mm, tzinfo=tz).timestamp())


@dataclass
class Mark:
    kind: str
    prims: list = field(default_factory=list)     # (tag, attrs) drawn when the mark is kept
    label: str | None = None
    label_tries: list = field(default_factory=list)   # [(x, y baseline, anchor)], first that fits wins
    label_color: str = ""
    number: int | None = None
    anchors: list = field(default_factory=list)   # [(x, y)] the points of the mark a number may sit by
    color: str = ""
    op: float = 1.0
    after: bool = False
    named: bool = False                            # the POI line 1 names
    held: bool = False
    quoted: bool = False
    t: int | None = None                           # a mark of one moment: its true time ...
    x: float | None = None                         # ... and where it is drawn
    width: float | None = None
    strip: bool = False                            # a session band: labelled in the strip above the chart
    linked: str | None = None                      # the risk shading: labelled by the axis tags it lies between
    keep: bool = False                             # drawn whatever the label does (axis-tagged lines)
    taken_t: int | None = None
    placed_label: tuple | None = None
    placed_number: tuple | None = None
    leader: tuple | None = None
    z: int | None = None


class Canvas:
    def __init__(self, c: dict):
        self.c = c
        self.out: list[str] = []
        self.hard: list[tuple] = []                # boxes no label or number may cover: candles, trade lines
        self.soft: list[tuple] = []                # labels and numbers already placed

    @staticmethod
    def el(tag: str, attrs: dict, text: str | None = None) -> str:
        a = " ".join(f'{k.replace("_", "-")}="{v}"' for k, v in attrs.items() if v is not None)
        if text is None:
            return f"<{tag} {a}/>"
        return f"<{tag} {a}>{escape(text)}</{tag}>"

    def add(self, tag: str, **attrs) -> None:
        self.out.append(self.el(tag, {k: (fnum(v) if isinstance(v, float) else v) for k, v in attrs.items()}))

    def text(self, x, y, s, fill, size=FS, anchor="start", weight=None, op=None) -> None:
        if size < FS:
            raise ValueError("every text on the picture is at least 40 px")
        self.out.append(self.el("text", {"x": fnum(x), "y": fnum(y), "font-size": size, "fill": fill,
                                         "text-anchor": None if anchor == "start" else anchor,
                                         "font-weight": weight, "fill-opacity": None if op in (None, 1.0) else op}, s))

    def free(self, box, candles: bool = True) -> bool:
        x0, y0, x1, y1 = box
        if x0 < CH_L or x1 > CH_R or y0 < CH_T or y1 > CH_B:
            return False
        for b in (self.hard if candles else []) + self.soft:
            if x0 < b[2] and b[0] < x1 and y0 < b[3] and b[1] < y1:
                return False
        return True


def _label_box(x, y, s, anchor):
    w = text_w(s)
    x0 = x - w if anchor == "end" else (x - w / 2 if anchor == "middle" else x)
    return (x0 - 4, y - FS * 0.82, x0 + w + 4, y + FS * 0.22)


def window_info(a: dict, view: str) -> tuple[int, int, bool]:
    """(start, end, cut). 15m: the whole New York day. 5m: from the whole hour at or before the earliest of 07:00
    London, tau - 3 h, and the setup's own times (the touch of the POI that holds, the latest level taken, the break and
    its swing, each - 30 min, no earlier than tau - 6 h), to the later of the exit + 30 min and tau + 60 min (an open
    trade: the last price), never after 17:00 New York. Over 120 bars, the start (the setup and the order) is kept and
    the end is cut (cut = True); only if the order itself would fall off is the start moved later."""
    D = date.fromisoformat(a["D"])
    day0, day1 = at(D - timedelta(days=1), 17, NEW_YORK), at(D, 17, NEW_YORK)
    if view == "15m":
        return day0, day1, False
    tau, tr, tg = a["tau"], a["trade"], a["tags"]
    setup = [(tg["T2"].get("holds") or {}).get("touched")]
    setup += [x.get("s") for x in (tg["T3"].get("taken") or [])[:1]]
    setup += [(tg["T4"].get(k) or {}).get("broken_t") for k in ("choch", "bos")]
    setup.append((tg["T6"].get("swing") or {}).get("wick_t"))
    first = [at(D, 7, LONDON), tau - 3 * 3600] + [max(t - 1800, tau - 6 * 3600) for t in setup if t]
    st0 = max(min(first) // 3600 * 3600, day0)
    ends = [tau + 3600]
    ends.append(tr["exit_t"] + 1800 if tr.get("exit_t") is not None else (a["after"].get("data_end") or tau))
    en0 = min(-(-max(ends) // 300) * 300, day1)
    span = BARS_5M * 300
    if en0 - st0 <= span:
        return st0, en0, False
    st, en = st0, st0 + span
    if en < tau + 3600:                                   # keep the order and an hour after it
        st = (tau + 3600 - span) // 300 * 300
        en = st + span
    return st, en, en < en0


def window(a: dict, view: str) -> tuple[int, int]:
    st, en, _cut = window_info(a, view)
    return st, en


def axis_times(st: int, en: int, view: str) -> list[int]:
    """The time axis's hours: every hour on a 5m window of 5 hours or less, every 2 hours on a longer one, every 4
    hours on the 15m day (on the odd London hours: 07:00, 09:00, ...)."""
    every = 4 if view == "15m" else (1 if en - st <= 5 * 3600 else 2)
    out, t = [], -(-st // 3600) * 3600
    while t < en:
        if datetime.fromtimestamp(t, LONDON).hour % every == 1 % every:
            out.append(t)
        t += 3600
    return out


def render(a: dict, page: dict, view: str = "5m", theme: str = "dark", debug: dict | None = None
           ) -> tuple[str, list[dict]]:
    if view not in ("5m", "15m") or theme not in THEMES:
        raise ValueError("view must be 5m or 15m and theme dark or light")
    c = THEMES[theme]
    cv = Canvas(c)
    tr, tg, aft, mk = a["trade"], a["tags"], a["after"], a["marks"]
    tau, long_ = a["tau"], tr["side"] == "buy"
    side = "L" if long_ else "S"
    numbers = {x["n"] for x in page["lines"] + page["after"] if x.get("n")}
    L = 300 if view == "5m" else 900
    st, en, cut = window_info(a, view)
    bars = [b for b in a["bars"]["m5" if view == "5m" else "m15"] if st <= b[0] < en]
    D = date.fromisoformat(a["D"])
    nslots = max(1, (en - st) // L)
    cw = (CH_R - CH_L) / nslots

    def tx(t):                                    # spans: clamped to the window
        return CH_L + (min(max(t, st), en) - st) / L * cw

    def on(t):
        return t is not None and st <= t <= en

    E, S, T = tr["entry"], tr.get("stop"), tr.get("target")
    vals = [b[2] for b in bars] + [b[3] for b in bars] + [E] + [v for v in (S, T) if v is not None]
    lo, hi = min(vals), max(vals)

    # the POI the tag names is kept: the range reaches for it when its near edge is within 30 pips
    held_ids = set((tg["T2"].get("holds") or {}).get("ids") or [])
    t2f = tg["T2"].get("failed") or {}
    failed_ids = set(t2f.get("ids") or [])
    t2_ids = held_ids | failed_ids
    quoted_ids = {x["id"] for x in mk["locs"] if x["id"] in failed_ids and x["fT"] == t2f.get("failed_t")}
    latest = (tg["T3"].get("taken") or [None])[0]       # and the latest level taken before it (line 2)
    reach = t2_ids | ({latest["id"]} if latest and on(latest.get("s")) else set())
    for x in mk["locs"]:
        if x["id"] in reach:
            if x["hi"] < lo and lo - x["hi"] <= 30 * PIP:
                lo = x["hi"] - 3 * PIP
            elif x["lo"] > hi and x["lo"] - hi <= 30 * PIP:
                hi = x["lo"] + 3 * PIP
    pad = max((hi - lo) * 0.06, 2 * PIP)
    lo, hi = lo - pad, hi + pad

    def py(p):
        return CH_B - (p - lo) / (hi - lo) * (CH_B - CH_T)

    def inside(p):
        return lo <= p <= hi

    def along(x0, x1, y_list, anchor="start", w=0.0):
        """label spots along a span: its start, its end, every 120 px between; above and below the line"""
        xs = [x0 + 6, x1 - 6 - w]
        k = x0 + 126
        while k < x1 - w - 6:
            xs.append(k)
            k += 120
        return [(xx, yy, "start") for yy in y_list for xx in xs]

    marks: list[Mark] = []

    # sessions (the research definition, design 7.1): bands in the strip and faint shading in the chart
    sess = [("Asia", at(D, 0, LONDON), at(D, 7, LONDON), c["asia"]),
            ("London", at(D, 7, LONDON), at(D, 7, NEW_YORK), c["london"]),
            ("New York", at(D, 7, NEW_YORK), at(D, 17, NEW_YORK), c["ny"])]
    for name, s0, s1, col in sess:
        s0, s1 = max(s0, st), min(s1, en)
        if s1 <= s0:
            continue
        x0, x1 = tx(s0), tx(s1)
        m = Mark("session", color=col, strip=True)
        m.prims += [("rect", dict(x=x0 + 1, y=STRIP_T, width=max(1.0, x1 - x0 - 2), height=STRIP_B - STRIP_T,
                                  fill=col, stroke=c["grid"], stroke_width=1)),
                    ("rect", dict(x=x0, y=CH_T, width=x1 - x0, height=CH_B - CH_T, fill=col, fill_opacity=0.55)),
                    ("line", dict(x1=x0, y1=CH_T, x2=x0, y2=CH_B, stroke=c["text3"], stroke_width=1.2,
                                  stroke_dasharray="2 5", stroke_opacity=0.6))]
        for word in (name, SESSION_SHORT[name]):
            if text_w(word) + 12 <= x1 - x0:
                m.label, m.label_tries, m.label_color = word, [((x0 + x1) / 2, STRIP_B - 18, "middle")], c["text2"]
                break
        if m.label:
            marks.append(m)

    # POI groups (grey, like his own POIs): his side and the other, known by tau, grouped by side and grade
    keep = []
    for x in mk["locs"]:
        if x["grp"] != "ZONE" or x["id"] not in mk["tag_ids"] or x["known"] > tau or x["status"] == "GONE":
            continue
        if not (x["hi"] >= lo and x["lo"] <= hi):
            continue
        if x["status"] == "STARTED" and x["s"] is not None and x["s"] < st and x["id"] not in t2_ids:
            continue
        g = "F" if (x["fT"] is not None and x["fT"] <= tau) else ("live" if x["s"] is None or x["s"] > tau else "held")
        keep.append(dict(x, g=g))
    groups: list[dict] = []
    for x in sorted(keep, key=lambda z: (z["side"], z["g"], z["lo"])):
        for gp in groups:
            if gp["side"] == x["side"] and gp["g"] == x["g"] and x["lo"] <= gp["hi"] and x["hi"] >= gp["lo"]:
                gp["lo"], gp["hi"] = min(gp["lo"], x["lo"]), max(gp["hi"], x["hi"])
                gp["ids"].append(x["id"])
                gp["known"] = min(gp["known"], x["known"])
                gp["fT"] = min([v for v in (gp["fT"], x["fT"]) if v is not None], default=None)
                break
        else:
            groups.append(dict(side=x["side"], g=x["g"], lo=x["lo"], hi=x["hi"], ids=[x["id"]], known=x["known"],
                               fT=x["fT"]))
    for gp in groups:
        gp["named"] = bool(set(gp["ids"]) & t2_ids)
        gp["held"] = bool(set(gp["ids"]) & held_ids)
        gp["quoted"] = bool(set(gp["ids"]) & quoted_ids)          # holds the zone whose failure time line 1 quotes
    groups = [gp for gp in groups if not (gp["g"] == "F" and gp["fT"] is not None and gp["fT"] < st)]
    named_in_range = any(gp["named"] for gp in groups)      # in its price range and not failed before this view
    chosen_groups = [gp for gp in groups if gp["named"]]                 # the POI the tag names: always kept
    for sd in ("L", "S"):                                                # then up to 2 a side, nearest the entry
        rest = sorted([gp for gp in groups if gp["side"] == sd and not gp["named"]],
                      key=lambda g: abs((g["lo"] + g["hi"]) / 2 - E))
        room = 2 - len([gp for gp in chosen_groups if gp["side"] == sd])
        chosen_groups += rest[:max(0, room)]
    # the 1: on the held box; with nothing holding, on the box of the failure line 1 quotes (else not drawn)
    number_on = "held" if held_ids else "quoted"
    for gp in chosen_groups:
        failed = gp["g"] == "F"
        x0 = tx(gp["known"]) if gp["side"] != side else CH_L
        x1 = tx(gp["fT"]) if failed and gp["fT"] is not None else CH_R
        if x1 - x0 < MIN_BOX_W:
            if not gp["named"]:
                continue                                                 # a sliver: not drawn
            x0 = max(CH_L, x1 - MIN_BOX_W)
            x1 = x0 + MIN_BOX_W
        y0, y1 = py(min(hi, gp["hi"])), py(max(lo, gp["lo"]))
        m = Mark("poi", color=c["poi"], named=gp["named"], held=gp["held"], quoted=gp["quoted"], width=x1 - x0)
        m.prims.append(("rect", dict(x=x0, y=y0, width=x1 - x0, height=max(2.0, y1 - y0), fill=c["poi"],
                                     fill_opacity=0.08 if failed else 0.16, stroke=c["poi"], stroke_width=1.5,
                                     stroke_dasharray="6 5" if failed else None)))
        word = "Buy" if gp["side"] == "L" else "Sell"
        m.label = (f"{word} POI failed" if failed else f"{word} POI held" if gp["g"] == "held" else f"{word} POI")
        w = text_w(m.label)
        ys = [y0 + FS + 2, y1 - 8, (y0 + y1) / 2 + 14]                  # inside its box, so it names that box
        if y1 - y0 < FS + 8:
            ys += [y0 - 8, y1 + FS + 2]                                   # a thin box: just above or below it
        m.label_tries = along(x0, x1, ys, w=w)
        m.label_color = c["text2"]
        if 1 in numbers and gp[number_on] and not any(o.number == 1 and o.kind == "poi" for o in marks):
            m.number = 1
            m.anchors = [(xx, (y0 + y1) / 2) for xx in (x0 + 4, (x0 + x1) / 2, x1 - 4) if CH_L <= xx <= CH_R]
        marks.append(m)

    # liquidity lines: at most 6 (OVERLAY.md section 7): the 2 latest of his sweep side taken on the day before tau,
    # the nearest untaken level each side of the entry at tau (up to 2 a side); then the levels formed after tau
    # within 1.5 pips of the stop, as one faded band
    lv = [x for x in mk["locs"] if (x["grp"] in ("AS", "PD", "EQ", "HS") or (latest and x["id"] == latest["id"]))
          and x["status"] != "GONE" and inside(x["edge"]) and x["known"] <= en]   # a CRT level only when line 2 names it
    D0 = at(D, 0, LONDON)
    a_ = sorted([x for x in lv if x["side"] == side and x["known"] <= tau and x["s"] is not None
                 and max(D0, st) <= x["s"] <= tau], key=lambda x: -x["s"])[:2]
    unt = [x for x in lv if x["known"] <= tau and (x["s"] is None or x["s"] > tau)]
    above = sorted([x for x in unt if x["edge"] > E], key=lambda x: x["edge"])[:2]
    below = sorted([x for x in unt if x["edge"] < E], key=lambda x: -x["edge"])[:2]
    chosen, seen = [], set()
    for x in a_ + above + below:
        if x["id"] not in seen:
            seen.add(x["id"])
            chosen.append(x)
    for x in chosen[:6]:
        s_ = x["s"] if on(x["s"]) else None
        x0, x1, y = tx(max(st, x["known"])), (tx(s_) if s_ else CH_R), py(x["edge"])
        m = Mark("liq", color=c["liq"], taken_t=s_)
        m.prims.append(("line", dict(x1=x0, y1=y, x2=x1, y2=y, stroke=c["liq"], stroke_width=2.4)))
        if s_:
            fade = 0.5 if s_ > tau else None                             # taken after the order: faded
            m.prims += [("line", dict(x1=x1 - 9, y1=y - 9, x2=x1 + 9, y2=y + 9, stroke=c["liq"], stroke_width=3,
                                      stroke_opacity=fade)),
                        ("line", dict(x1=x1 - 9, y1=y + 9, x2=x1 + 9, y2=y - 9, stroke=c["liq"], stroke_width=3,
                                      stroke_opacity=fade))]
        m.label = LEVEL_SHORT.get(x["kind"], ("Low", "High"))[0 if x["side"] == "L" else 1]
        m.label_tries = along(x0, x1, [y - 10, y + FS + 4], w=text_w(m.label))
        m.label_color = c["liq"]
        if latest is not None and 2 in numbers and x["id"] == latest["id"]:
            m.number = 2
            m.anchors = [(x1, y)] if s_ else [(x0, y)]
        marks.append(m)
    at_stop = [x for x in aft.get("at_levels") or [] if x["at"] == "stop" and inside(x["level"])]
    at_stop = [x for x in at_stop if on(x["known"])]
    if at_stop:
        b_lo, b_hi = min(x["level"] for x in at_stop), max(x["level"] for x in at_stop)
        k0 = min(x["known"] for x in at_stop)
        k1 = max([x["s"] for x in at_stop if x["s"] is not None] or [en])
        x0, x1 = tx(k0), max(tx(k1), tx(k0) + 6)
        m = Mark("liq_after", color=c["liq"], after=True, op=0.6)
        m.prims.append(("rect", dict(x=x0, y=py(b_hi) - 3, width=x1 - x0, height=max(6.0, py(b_lo) - py(b_hi) + 6),
                                     fill=c["liq"], fill_opacity=0.18, stroke=c["liq"], stroke_width=1.3,
                                     stroke_dasharray="4 3", stroke_opacity=0.6)))
        if 8 in numbers:
            m.number, m.anchors = 8, [((x0 + x1) / 2, py(b_lo))]
        m.label = "Lows at your stop" if long_ else "Highs at your stop"
        m.label_tries = along(x0, max(x1, x0 + 2), [py(b_lo) + FS + 4, py(b_hi) - 8], w=text_w(m.label))
        m.label_color = c["liq"]
        marks.append(m)

    # day high and low (his MT5 daily candle): grey dotted, not liquidity
    dh = mk.get("day_hl")
    if dh:
        for key, word in (("high", "Day high"), ("low", "Day low")):
            v, t_ = dh[key], dh[key + "_t"]
            if not (inside(v) and on(t_)):
                continue
            y = py(v)
            m = Mark("day_hl", color=c["poi"], after=t_ > tau, op=0.5 if t_ > tau else 1.0)
            m.prims.append(("line", dict(x1=tx(t_), y1=y, x2=CH_R, y2=y, stroke=c["poi"], stroke_width=2,
                                         stroke_dasharray="2 6")))
            m.label = word
            m.label_tries = along(tx(t_), CH_R, [y - 10, y + FS + 4], w=text_w(word))
            m.label_color = c["text2"]
            marks.append(m)

    # structure (design 7.1): the break T4 names, and the breaks after the order up to the exit (faded)
    for e in [e for e in (tg["T4"].get("choch"), tg["T4"].get("bos")) if e]:
        if not (on(e["t"]) and inside(e["broken"])):
            continue
        y, xb, xe = py(e["broken"]), tx(e["broken_t"]), tx(e["t"])
        m = Mark("struct", color=c["struct"])
        m.prims.append(("line", dict(x1=xb, y1=y, x2=xe, y2=y, stroke=c["struct"], stroke_width=2.4,
                                     stroke_dasharray="9 6")))
        m.label = ("CHoCH " if e["kind"] == "CHOCH" else "BOS ") + ("up" if e["dir"] == "UP" else "down")
        w = text_w(m.label)
        ys = [y - 10, y + FS + 4] if e["dir"] == "UP" else [y + FS + 4, y - 10]
        m.label_tries = [(xe - 6 - w, yy, "start") for yy in ys] + along(xb, xe, ys, w=w)
        m.label_color = c["struct"]
        if 4 in numbers:
            m.number, m.anchors = 4, [(xe, y)]
        marks.append(m)
    for e in aft.get("breaks") or []:
        if not (on(e["t"]) and inside(e["broken"])) or 9 not in numbers:
            continue
        y = py(e["broken"])
        m = Mark("struct_after", color=c["struct"], after=True, op=0.45)
        m.prims.append(("line", dict(x1=tx(e["broken_t"]), y1=y, x2=tx(e["t"]), y2=y, stroke=c["struct"],
                                     stroke_width=2.2, stroke_dasharray="9 6")))
        m.number, m.anchors = 9, [(tx(e["t"]), y)]
        marks.append(m)

    # the swing that protects the break (T6 b): a ring over its candle
    sw = tg["T6"].get("swing")
    if sw and 3 in numbers and on(sw["wick_t"]) and inside(sw["wick"]):
        x, y = tx(sw["wick_t"]) + cw / 2, py(sw["wick"])
        m = Mark("swing", color=c["struct"])
        m.prims.append(("circle", dict(cx=x, cy=y, r=12, fill="none", stroke=c["struct"], stroke_width=3)))
        m.number, m.anchors = 3, [(x, y)]
        marks.append(m)

    # the trade: the entry gap, risk and reward shading from the fill, the lines from tau to the exit, the fill and
    # the exit, each at its true time or not drawn
    z = tg.get("T5")
    fill_t, exit_t = tr.get("fill_t"), tr.get("exit_t")
    x_tau = tx(tau)
    fill_on, exit_on = on(fill_t), on(exit_t)
    x_fill = tx(fill_t) if fill_on else None
    x_end = tx(exit_t) if exit_on else CH_R
    if z and 5 in numbers and inside(z["lo"]) and inside(z["hi"]) and on(z["c3"] - 600):
        za = tx(z["c3"] - 600)
        zb = x_fill if x_fill is not None else x_tau
        m = Mark("gap", color=c["entry"])
        m.prims.append(("rect", dict(x=za, y=py(z["hi"]), width=max(4.0, zb - za),
                                     height=max(3.0, py(z["lo"]) - py(z["hi"])), fill=c["entry"], fill_opacity=0.32,
                                     stroke=c["entry"], stroke_width=1.2)))
        m.number, m.anchors = 5, [(za, py((z["lo"] + z["hi"]) / 2))]
        marks.append(m)
    trade_lines = []
    if x_fill is not None and x_end > x_fill:
        shade = Mark("shade", color=c["stop"], linked="Stop")
        if S is not None:
            shade.prims.append(("rect", dict(x=x_fill, y=min(py(E), py(S)), width=x_end - x_fill,
                                             height=abs(py(S) - py(E)), fill=c["stop"], fill_opacity=0.12)))
        if T is not None:
            shade.prims.append(("rect", dict(x=x_fill, y=min(py(E), py(T)), width=x_end - x_fill,
                                             height=abs(py(T) - py(E)), fill=c["target"], fill_opacity=0.08)))
        if shade.prims:
            marks.append(shade)
    axis_tags = []
    for v, col, word, n in ((E, c["entry"], "entry", None), (S, c["stop"], "stop", 6), (T, c["target"], "target", None)):
        if v is None or not inside(v):
            continue
        y = py(v)
        m = Mark("trade_" + word, color=col, keep=True)
        m.prims.append(("line", dict(x1=x_tau, y1=y, x2=x_end, y2=y, stroke=col, stroke_width=3)))
        m.label = {"entry": "Entry", "stop": "Stop", "target": "Target"}[word]
        axis_tags.append((m.label, y, col))
        trade_lines.append((word, (x_tau, y - 5, x_end, y + 5)))
        if n and n in numbers:
            m.number, m.anchors = n, [((x_tau + x_end) / 2, y), (x_tau + 40, y), (x_end - 40, y)]
        marks.append(m)
    if a["tau_how"] != "unknown" and on(tau):
        m = Mark("order", color=c["text2"], t=tau, x=x_tau)
        m.prims.append(("line", dict(x1=x_tau, y1=CH_T, x2=x_tau, y2=CH_B, stroke=c["text2"], stroke_width=1.8,
                                     stroke_dasharray="2 6")))
        m.label, m.label_color = "your order", c["text2"]
        w = text_w(m.label)
        m.label_tries = [(x_tau + 8, CH_T + 46 + k * 50, "start") for k in range(6)] + \
                        [(x_tau - 12 - w, CH_T + 46 + k * 50, "start") for k in range(6)] + \
                        [(x_tau + 8, CH_B - 14 - k * 50, "start") for k in range(4)] + \
                        [(x_tau - 12 - w, CH_B - 14 - k * 50, "start") for k in range(4)]
        marks.append(m)
    if cut:                                               # the trade goes on past the right edge
        m = Mark("cut", color=c["text2"])
        m.prims.append(("line", dict(x1=CH_R - 3, y1=CH_T, x2=CH_R - 3, y2=CH_B, stroke=c["text2"], stroke_width=3,
                                     stroke_dasharray="10 8")))
        m.label, m.label_color = "Continues →", c["text2"]
        w = text_w(m.label)
        m.label_tries = [(CH_R - 14 - w, yy, "start") for yy in list(range(CH_T + 46, CH_B, 50))]
        marks.append(m)
    if fill_on and 7 in numbers and inside(E):
        m = Mark("fill", color=c["entry"], t=fill_t, x=x_fill)
        m.prims.append(("circle", dict(cx=x_fill, cy=py(E), r=10, fill=c["entry"], stroke=c["bg"], stroke_width=2)))
        m.number, m.anchors = 7, [(x_fill, py(E))]
        marks.append(m)
    xp = tr.get("exit_price")
    if exit_on and xp is not None and 8 in numbers and inside(xp):
        y = py(xp)
        m = Mark("exit", color=c["text"], t=exit_t, x=x_end)
        m.prims += [("line", dict(x1=x_end - 11, y1=y - 11, x2=x_end + 11, y2=y + 11, stroke=c["text"],
                                  stroke_width=4)),
                    ("line", dict(x1=x_end - 11, y1=y + 11, x2=x_end + 11, y2=y - 11, stroke=c["text"],
                                  stroke_width=4))]
        m.number, m.anchors = 8, [(x_end, y)]
        marks.append(m)

    # ---------------- layout: candles and trade lines first (nothing covers them), then labels, then numbers
    bw = max(2.0, cw * 0.62)
    candle_boxes = []
    for t_, o, h_, l_, cl in bars:
        x = tx(t_) + cw / 2
        candle_boxes.append((x - bw / 2 - 1, py(h_) - 1, x + bw / 2 + 1, py(l_) + 1))
    cv.hard += candle_boxes + [b for _k, b in trade_lines]
    order = {"cut": 0, "order": 1, "poi": 2, "struct": 3, "day_hl": 4, "liq": 5, "liq_after": 6}
    for m in sorted(marks, key=lambda m: (order.get(m.kind, 9), not m.named)):
        if not m.label or m.strip or not m.label_tries:
            continue
        for x, y, anchor in m.label_tries:
            box = _label_box(x, y, m.label, anchor)
            if cv.free(box):
                cv.soft.append(box)
                m.placed_label = (box[0] + 4, y, box)
                break
    for m in marks:
        if not m.number or not m.anchors:
            continue
        for candles in (True, False):                     # beside its mark, off the candles if it can be
            for ax, ay in m.anchors:
                for dx, dy in MARK_TRIES:
                    cx, cy = ax + dx, ay + dy
                    box = (cx - MARK_R - 2, cy - MARK_R - 2, cx + MARK_R + 2, cy + MARK_R + 2)
                    if cv.free(box, candles=candles):
                        cv.soft.append(box)
                        m.placed_number = (cx, cy, ax, ay)
                        break
                if m.placed_number:
                    break
            if m.placed_number:
                break
    drawn = [m for m in marks if m.placed_label or m.placed_number or m.keep or (m.strip and m.label)
             or (m.linked and any(k == "stop" for k, _b in trade_lines))]

    # ---------------- emit
    cv.add("rect", x=0, y=0, width=W, height=H, fill=c["bg"])
    cv.add("rect", x=CH_L, y=CH_T, width=CH_R - CH_L, height=CH_B - CH_T, fill=c["panel"], stroke=c["grid"],
           stroke_width=1)

    def emit(m):
        m.z = len(cv.out)
        for tag, at_ in m.prims:
            attrs = dict(at_)
            if m.op < 1.0:
                if tag == "line":
                    attrs.setdefault("stroke_opacity", m.op)
                elif tag in ("rect", "circle") and "fill_opacity" not in attrs:
                    attrs["fill_opacity"] = m.op
            cv.add(tag, **attrs)

    for m in [m for m in drawn if m.kind == "session"]:
        emit(m)
    tag_ys = [y for _w, y, _c in axis_tags]
    step = 5 * PIP if (hi - lo) < 70 * PIP else 10 * PIP
    p = (int(lo / step) + 1) * step
    while p < hi:                               # price grid every 5 or 10 pips; no axis price under an axis tag
        y = py(p)
        cv.add("line", x1=CH_L, y1=y, x2=CH_R, y2=y, stroke=c["grid"], stroke_width=1)
        if all(abs(y - ty) > 50 for ty in tag_ys) and CH_T + 30 < y < CH_B - 10:
            cv.text(CH_R + 14, y + 14, f"{p:.4f}", c["text3"])
        p += step
    for m in [m for m in drawn if m.kind != "session" and m.kind not in OVER_CANDLES]:
        emit(m)
    z0 = len(cv.out)
    for t_, o, h_, l_, cl in bars:              # candles: the engine's own mid bars
        x = tx(t_) + cw / 2
        col = c["up"] if cl >= o else c["down"]
        cv.add("line", x1=x, y1=py(h_), x2=x, y2=py(l_), stroke=col, stroke_width=1.4)
        top, bot = py(max(o, cl)), py(min(o, cl))
        cv.add("rect", x=x - bw / 2, y=top, width=bw, height=max(1.5, bot - top), fill=col)
    candles_z = (z0, len(cv.out) - 1)
    for m in [m for m in drawn if m.kind in OVER_CANDLES]:
        emit(m)
    for m in drawn:                             # labels, then leader lines and numbers, on top
        if m.strip and m.label:
            x, y, anchor = m.label_tries[0]
            cv.text(x, y, m.label, m.label_color, anchor=anchor)
        elif m.placed_label:
            x, y, box = m.placed_label
            cv.add("rect", x=box[0], y=box[1], width=box[2] - box[0], height=box[3] - box[1], fill=c["panel"],
                   fill_opacity=0.85)
            cv.text(x, y, m.label, m.label_color or m.color, op=m.op if m.after else None)
    markers = []
    for m in drawn:
        if not m.placed_number:
            continue
        cx, cy, ax, ay = m.placed_number
        dist = math.hypot(cx - ax, cy - ay)
        leader = dist > LEADER_MIN
        if leader:                              # a short line from the mark to the number's edge
            ex, ey = cx - (cx - ax) / dist * MARK_R, cy - (cy - ay) / dist * MARK_R
            cv.add("line", x1=ax, y1=ay, x2=ex, y2=ey, stroke=m.color, stroke_width=2, stroke_opacity=0.85)
        cv.add("circle", cx=cx, cy=cy, r=MARK_R, fill=m.color, fill_opacity=m.op if m.after else None)
        cv.text(cx, cy + 14, str(m.number), c["on"], anchor="middle", weight=600)
        markers.append({"n": m.number, "anchor": (ax, ay), "at": (cx, cy), "leader": leader})
    for word, y, col in axis_tags:              # MT5-style tags on the price axis
        cv.add("rect", x=CH_R + 6, y=y - 28, width=W - CH_R - 12, height=56, rx=6, fill=col)
        cv.text(CH_R + 16, y + 14, word, c["on"], weight=600)
    axis = []
    for t in axis_times(st, en, view):          # two-row time axis: Melbourne 12-hour on top, London below
        x = tx(t)
        if CH_L + 60 < x < CH_R - 70:
            cv.add("line", x1=x, y1=CH_B, x2=x, y2=CH_B + 14, stroke=c["text3"], stroke_width=1.5)
            cv.text(x, ROW_MEL, mel_hour(t), c["text"], anchor="middle")
            cv.text(x, ROW_LON, hhmm(t), c["text3"], anchor="middle")
            axis.append(t)
    cv.text(W - 10, ROW_MEL, "Melb.", c["text"], anchor="end")
    cv.text(W - 10, ROW_LON, "London", c["text3"], anchor="end")
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" '
           f'font-family="{FONT}">' + "".join(cv.out) + "</svg>")
    layout = [dict(kind=m.kind, label=m.linked or (m.label if (m.placed_label or m.keep or m.strip) else None),
                   number=m.number if m.placed_number else None, after=m.after, named=m.named, held=m.held,
                   quoted=m.quoted,
                   t=m.t, x=m.x, z=m.z, width=m.width) for m in drawn]
    if debug is not None:
        debug.update(window=(st, en, cut), L=L, cw=cw, candles=candle_boxes, candles_z=candles_z,
                     trade_lines=trade_lines, labels=[(m.label, m.placed_label[2]) for m in drawn if m.placed_label],
                     markers=markers, axis=axis, named_poi_in_range=named_in_range,
                     marks=[dict(kind=m.kind, prims=m.prims, taken_t=m.taken_t) for m in drawn])
    return svg, layout
