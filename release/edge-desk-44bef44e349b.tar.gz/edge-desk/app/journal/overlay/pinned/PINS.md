# Pinned A12 engine files (trade picture)

Byte copies of the A12 engine and the v2x modules it imports, as the A12 DISCOVER result used them
(`RESULTS_A12.md`: engine sha256 `d101a197…` over `engine/*.py`, unchanged since). Never edit a file here:
`app/journal/overlay/pins.py` refuses the folder unless every file's sha256 is its pin, and the child
(`app/journal/overlay/child.py`) checks that before anything is imported. A new engine version is a new pin
(new copies, new sha256 values in `pins.py`, `SHA256SUMS` and this file).

Source: repository `macdarenz-droid/Forex-signal`, research branch `ccr-b1232258-55ajvr`, commit
`aebc0f2fb557690bc7d637be54408159df7703f5` (the commit that holds these files at this content; the branch head
`679cf073cd37899c03630d369919fd6a13fdad21` holds the same bytes, checked 30 Oct 2026).

| File here | Source path at that commit | sha256 |
|---|---|---|
| `a12.py` | `sandbox/work/marc_test/v2x_a12/engine/a12.py` | `6fa836ef1a69a448faf2d9296ee6f48e18c8ed49c6545c0b408aebad76a47e10` |
| `walk.py` | `sandbox/work/marc_test/v2x_a12/engine/walk.py` | `3b93c60f2c2c490c1279b642c4c7c38cbb1f7567fb848ea5868420bd1f178d7c` |
| `data.py` | `sandbox/work/marc_test/v2x/data.py` | `25e3f5bb5399bc7439e88237eb64a06a1070cbd68d2b867ab12ce459c41a9e2a` |
| `engine.py` | `sandbox/work/marc_test/v2x/engine.py` | `eb6740763ab683c6be95af9a6a09106806b4211592249c46593ca772ea388909` |

Why these four: `a12.py` imports `data` and `engine` (the v2x folder it puts on `sys.path`) and `walk` (its own
folder); `data.py` imports `engine`; `walk.py` and `engine.py` import only the standard library and numpy. No other
module of the research tree is imported. `data.py` and `engine.py` are the same bytes as the A+ copies in
`app/aplus/pinned/vendor/` (and the v2x record `v2x_files_sha256.json`).

The child never calls a loader, a stage gate or a frozen-file check of `a12.py` (they read research paths that do
not exist on the server); it builds the engine's `Day` from the app's own prices with `a12.day_from_units`.
