"""A12 engine: research/marc_rules/A12_text.md (frozen 27 Oct 2026; sha256 on the latest A12 line of FROZEN.txt).

Marc's POI method (R1, R2, H1, C1) and CRT (K1, K2), with every information sequence of A12.4.

This module holds: the frozen checks and the stage gates (A12.1, A12.11), the loaders, A12-day eligibility, bars on the
UTC grid and on New York-close 4h bars (A12.2.1), the locations with their starts and the hold/fail rule (A12.2.2), the
day's body-swing walk (A12.2.3, engine/walk.py at k = 1.0), setups, triggers and candidates (A12.2.4), the order stage
and targets (A12.2.5), the factors and the score (A12.3), CRT (A12.2.9), the order path in every cost case (A12.2.6),
the sequences (A12.2.7) and the H1 cut (A12.5).

Prices are whole K1 units (1 pip = 40; mid = 2 (bid_q + ask_q), always even). Every test with a division is done by
cross-multiplying whole numbers. Outcome code (path, costs, sequences with fills) is pure: it is run on real prices only
by `run_a12.py` stage commands that the gates allow, and in this build only on typed or synthetic bars (and on W1+H4's
own published orders for check 1(c)).

Reused, not rebuilt (imported unchanged; nothing in v2x/ is edited):
  - v2x/data.py: manifest_rows, _read_member, load_run1, clean (K2), to_units (K1), clocks lon/nyt, DayTable (K4),
    make_ctx (PDH/PDL, ADR20 sum A, W3's D1/D2), read_excluded (the only code that opens EXCLUDE_DATES.txt);
  - v2x/engine.py: find_swings (K3), find_eq (K5), daily_bias (W3), bar_bias (A1's 4h bias test);
  - engine/walk.py: the A12.2.3 walk (the pre-freeze calibration build, matched by the checker to 0 differences).
"""
import datetime as dt
import gzip
import hashlib
import json
import os
import re
import sys
import zipfile
from fractions import Fraction

import numpy as np

SCRATCH = '/tmp/claude-0/-home-user-Forex-signal/f43e2ef7-af07-5a67-8027-a2e50c2c9526/scratchpad'
ROOT = SCRATCH + '/marc_test/v2x_a12'
ENGINE = ROOT + '/engine'
OUT = ROOT + '/out'
V2X = SCRATCH + '/marc_test/v2x'
for _p in (ENGINE, V2X):
    if _p not in sys.path:
        sys.path.insert(1, _p)
import data as DA      # noqa: E402  v2x loader, K1, K2, clocks, DayTable, make_ctx, read_excluded
import engine as EN    # noqa: E402  v2x find_swings, find_eq, daily_bias, bar_bias
from walk import run_walk, abar_pairs, prev_weekday   # noqa: E402  A12.2.3

REPO = '/home/user/Forex-signal'
MR = REPO + '/research/marc_rules'
A12_TEXT = MR + '/A12_text.md'
TEXT_SHA = '19dba349db205692334f860b44d1c32be42b4d1b9df27e5ae1aaf4fa82338402'   # the task's check (after rulings R10-R13)
FROZEN_TXT = MR + '/FROZEN.txt'
RULES_PATH = SCRATCH + '/marc_rules/RULES_v1.md'
EXCLUDE = SCRATCH + '/marc_rules/EXCLUDE_DATES.txt'          # opened only by DA.read_excluded()
READING_DATE_PATHS = [MR + '/READING_DATES.txt', SCRATCH + '/marc_rules/READING_DATES.txt']
BUILD_DIR = SCRATCH + '/needle/data'
PRE_DIR = ROOT + '/pre_era'
V2X_RECORD = ENGINE + '/v2x_files_sha256.json'
A8_ELIG = SCRATCH + '/marc_test/v2x_a8/out/eligibility_a8_%s.csv'
W1H4_ORDERS = SCRATCH + '/marc_test/v2x/out/orders_v2x_a1_run1.csv'
OWNER_COST_PY = REPO + '/sandbox/work/whatif/owner_cost.py'

CUT_DISCOVER = 1356998400            # 2013-01-01 00:00 UTC
CUT_RUN1 = DA.CUT_RUN1               # 2016-01-01 00:00 UTC
PRE_LO, PRE_HI = 1104537600, 1262304000   # 2005-01-01, 2010-01-01 UTC (A12.10)
STAGES = {'DISCOVER': (dt.date(2010, 1, 1), dt.date(2012, 12, 31)),
          'VALIDATE': (dt.date(2013, 1, 1), dt.date(2015, 12, 31)),
          'CONFIRM': (dt.date(2005, 1, 1), dt.date(2009, 12, 31))}
PAIRS = ['EUR_USD', 'GBP_USD']       # EUR/USD before GBP/USD everywhere
REPORT_APART = {'DISCOVER': {dt.date(2010, 4, 15)},
                'VALIDATE': {dt.date.fromisoformat(s) for s in (
                    '2013-10-22', '2013-10-23', '2015-02-11', '2015-02-12', '2013-02-13', '2013-02-14',
                    '2014-08-27', '2014-08-28', '2014-07-08', '2014-07-09', '2015-10-23', '2015-09-17')},
                'CONFIRM': set()}

# ---------------------------------------------------------------- constants (units: 1 pip = 40)
PIP = 40
MARGIN = 10          # m1: 0.25 pip break margin, and "inside" for hold/fail
TT = 20              # 0.5 pip trade-through (a sweep, K5)
GAP_MIN = 40         # 1.0 pip FVG minimum, and the 5m OB minimum (m9)
EQ_MAX = 80          # 2.0 pips (K5)
F1_TOL = 80          # F1: ranges within 2.0 pips
BUF = 40             # stop 1 pip past the zone (m10)
BUF15 = 60           # S15: 1.5 pips
SHIFT = 20           # entry: the middle moved 0.5 pip toward price
TICK = 4             # 0.1 pip limit fill-through
POI_OFF = 4          # a POI target 0.1 pip before the POI's near edge (m25)
FLOOR8 = 320         # 8 pips (FLOOR8 information sequences)
A_MIN = 19200        # ADR20 at least 24 pips (60 x d <= A and A >= 19,200)
ORDER_LIFE = 10800   # 180 minutes (m11)
H24 = 86400
H12 = 43200
AGE7 = 604800        # F6: older than 7 days
THIN = {3600: 30, 7200: 60, 14400: 120}
TRACK_DAYS = 90      # m4
SLICE_DAYS = 100     # A12.1
HS_DAYS = 7          # m18
K_WALK = Fraction(1)  # calibrated k = 1.0 (A12.2.3)
SEEDS = {'k14_days': 6001, 'checker_days': 6002, 'k14_old_starts': 6003, 'resim': 6004, 'timing': 6005,
         'k14_shift': 6011, 'seq_shift': 6012, 'validate_k14': 6021, 'validate_checker': 6022,
         'confirm_k14': 6031, 'confirm_checker': 6032, 'r1_single': 6031, 'bootstrap': 1000}

COSTS = {
    # quotes: 'half' = mid +/- half (units); 'data' = the data's bid/ask; 'double' = the spread doubled around mid;
    # 'shaped' = mid +/- the data's half-spread x (8 units / that pair-year's median 07:00-12:00 London spread)
    'owner': dict(quotes='half', half=4, comm=20, stop=20, mkt=0, time=0),
    'owner_stress': dict(quotes='half', half=8, comm=20, stop=40, mkt=40, time=0),
    'standard': dict(quotes='data', comm=28, stop=20, mkt=0, time=0),
    'standard_stress': dict(quotes='double', comm=28, stop=40, mkt=20, time=20),
    'owner_shaped': dict(quotes='shaped', target_spread=8, comm=20, stop=20, mkt=0, time=0),
}
COST_ORDER = ['owner', 'owner_stress', 'standard', 'standard_stress', 'owner_shaped']


# ---------------------------------------------------------------- designs (A12.4)
def _design(fam, **kw):
    d = dict(fam=fam, trig=None, tier=False, stop='zone', target='A', zone='sync', locset='main', c1any=False)
    if fam in ('K1', 'K2'):
        d.update(stop='wick', target='CRT')
    d.update(kw)
    return d


DESIGNS = {
    'R1': _design('R', trig='R1'),
    'R2': _design('R', trig='R2'),
    'H1': _design('R', trig='R1', tier=True),
    'C1': _design('C'),
    'K1': _design('K1'),
    'K2': _design('K2'),
    'R1-FLOOR8': _design('R', trig='R1', stop='floor8'),
    'C1-FLOOR8': _design('C', stop='floor8'),
    'R1-WICK': _design('R', trig='R1', stop='xwick'),
    'C1-WICK': _design('C', stop='xwick'),
    'R1-3R': _design('R', trig='R1', target='3R'),
    'C1-3R': _design('C', target='3R'),
    'K1-3R': _design('K1', target='3R'),
    'K2-3R': _design('K2', target='3R'),
    'R1-TP2': _design('R', trig='R1', target='TP2'),
    'C1-TP2': _design('C', target='TP2'),
    'R1-NEWEST': _design('R', trig='R1', zone='newest'),
    'R1-OLD': _design('R', trig='R1', zone='oldest'),
    'R1-N4': _design('R', trig='R1', locset='n4'),
    'H1-N4': _design('R', trig='R1', tier=True, locset='n4'),
    'C1-ANY': _design('C', c1any=True),
    'R1-HSW': _design('R', trig='R1', locset='hsw'),
    'R1-S15': _design('R', trig='R1', stop='s15'),
    'C1-S15': _design('C', stop='s15'),
    'K1-POI': _design('K1', target='POI'),
    'K2-POI': _design('K2', target='POI'),
    'K2-ZONE': _design('K2', stop='zone'),
}
FAMILY1 = ['R1', 'R2', 'H1', 'C1']          # Holm tie order (A12.7)
FAMILY2 = ['K1', 'K2']
PRIMARIES = FAMILY1 + FAMILY2
INFO_ORDER_DESIGNS = [d for d in DESIGNS if d not in PRIMARIES]
# sequence-only information designs: they re-use another design's ARMED rows (A12.4)
SEQ_DESIGNS = {'R1-RE2': ['R1'], 'C1-RE2': ['C1'], 'R1-MKT': ['R1'], 'BOOK': ['R1', 'C1']}
TIER_DESIGNS = [d for d, c in DESIGNS.items() if c['tier']]          # need c* (A12.5): run at the counts step
ORDER_DESIGNS_NO_TIER = [d for d in DESIGNS if d not in TIER_DESIGNS]
LOOKS = ['H1IN1', 'SIZED', 'BE2', 'AGAINST']

CONFIG = {
    'text_sha256': TEXT_SHA, 'k': '1', 'units': {'pip': PIP, 'margin': MARGIN, 'tt': TT, 'gap_min': GAP_MIN,
                                                'eq_max': EQ_MAX, 'f1_tol': F1_TOL, 'buf': BUF, 'buf15': BUF15,
                                                'shift': SHIFT, 'tick': TICK, 'poi_off': POI_OFF,
                                                'floor8': FLOOR8, 'a_min': A_MIN},
    'times': {'order_life_s': ORDER_LIFE, 'h24': H24, 'h12': H12, 'age7_s': AGE7, 'track_days': TRACK_DAYS,
              'slice_days': SLICE_DAYS, 'hs_days': HS_DAYS, 'window': ['07:05 London', '12:00 New York'],
              'expiry_cap': '13:00 New York', 'exit': '17:00 New York', 'walk_start': '00:00 London prev weekday',
              'n_abar': 16},
    'thin': {str(k): v for k, v in THIN.items()}, 'targets': {'R': 3, 'R_hi': '7/2', 'tp2': 2, 'crt_min_rr': 2},
    'atr_test': '56 x g >= B(c3)', 'cut_shares': [0.10, 0.50, '1/3'], 'leave': {'R1': 330, 'R2': 330, 'C1': 330,
                                                                               'K2': 330, 'K1': 200, 'H1': 130},
    'bar': {'fills': {'R1': 200, 'R2': 200, 'C1': 200, 'K1': 200, 'K2': 200, 'H1': 80}, 'alpha': 0.05,
            'z': 1.645, 'confirm_fills': {'R1': 300, 'R2': 300, 'C1': 300, 'K1': 300, 'K2': 300, 'H1': 125}},
    'seeds': SEEDS, 'costs': COSTS, 'designs': DESIGNS, 'seq_designs': SEQ_DESIGNS,
    'families': {'1': FAMILY1, '2': FAMILY2}, 'pairs': PAIRS,
    'report_apart': {k: sorted(d.isoformat() for d in v) for k, v in REPORT_APART.items()},
    'stages': {k: [a.isoformat(), b.isoformat()] for k, (a, b) in STAGES.items()},
    'cuts_utc': {'discover': CUT_DISCOVER, 'run1': CUT_RUN1, 'pre': [PRE_LO, PRE_HI]},
}


def config_hash():
    s = json.dumps(CONFIG, sort_keys=True, separators=(',', ':'), default=str)
    return hashlib.sha256(s.encode()).hexdigest()


# ================================================================ frozen checks and gates (A12.1, A12.11)
def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def frozen_lines():
    return [ln.rstrip('\n') for ln in open(FROZEN_TXT, encoding='utf-8')]


def frozen_text_sha():
    """A12_text.md sha256 from the latest A12 line of FROZEN.txt that names it (a ruling adds a new line)."""
    hits = [ln for ln in frozen_lines() if re.search(r'\bA12\b', ln) and re.search(r'A12_text\.md sha256 [0-9a-f]{64}', ln)]
    if not hits:
        raise SystemExit('FROZEN.txt has no A12 line with the A12_text.md sha256')
    return re.findall(r'A12_text\.md sha256 ([0-9a-f]{64})', hits[-1])[-1]


def _is_tag_line(ln, tag):
    """a FROZEN.txt line of this tag: '<UTC time> <TAG>' at its head (then ':', ' ', '(' or the end). A line that only
    mentions the tag in its text is not one (the 12:22 A12 FROZEN line mentions 'the A12 CUT line')."""
    return re.match(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z ' + re.escape(tag) + r'(?![\w-])', ln) is not None


def frozen_has(tag):
    """True if FROZEN.txt holds a line of this A12 tag (e.g. 'A12 DISCOVER RESULT', 'A12 CUT'), at the line's head."""
    return any(_is_tag_line(ln, tag) for ln in frozen_lines())


def frozen_line(tag):
    """the latest FROZEN.txt line of this tag (at the line's head), or None"""
    hits = [ln for ln in frozen_lines() if _is_tag_line(ln, tag)]
    return hits[-1] if hits else None


def engine_sha():
    """sha256 over every .py file under engine/ (sorted relative paths, path + NUL + file sha)."""
    h = hashlib.sha256()
    for dp, dn, fn in os.walk(ENGINE):
        dn[:] = sorted(d for d in dn if d != '__pycache__')
        for f in sorted(fn):
            if f.endswith('.py'):
                p = os.path.join(dp, f)
                h.update(os.path.relpath(p, ENGINE).encode() + b'\0' + sha256(p).encode() + b'\n')
    return h.hexdigest()


def v2x_files():
    out = {}
    for dp, dn, fn in os.walk(V2X):
        dn[:] = sorted(d for d in dn if d != '__pycache__')
        for f in sorted(fn):
            p = os.path.join(dp, f)
            out[os.path.relpath(p, V2X)] = sha256(p)
    return out


def check_v2x():
    rec = json.load(open(V2X_RECORD))['sha256']
    now = v2x_files()
    if now != rec:
        bad = sorted(set(rec) ^ set(now) | {k for k in rec if k in now and rec[k] != now[k]})
        raise SystemExit('marc_test/v2x/ changed since the record: %s' % bad[:5])
    return len(now)


def check_frozen():
    """A12.11: the text sha256 equals FROZEN.txt's latest A12 line and the task's value; RULES_v1.md; the v2x files
    unchanged; no reading-date file exists (A8.1). Returns the text sha256."""
    want = frozen_text_sha()
    got = sha256(A12_TEXT)
    if got != want or got != TEXT_SHA:
        raise SystemExit('A12_text.md sha256 %s differs from FROZEN.txt %s / the task %s' % (got, want, TEXT_SHA))
    if sha256(RULES_PATH) != DA.RULES_SHA:
        raise SystemExit('RULES_v1.md sha256 differs')
    for p in READING_DATE_PATHS:
        assert not os.path.exists(p), 'A12.1: no reading-date file may exist (%s)' % p
    check_v2x()
    return got


def read_excluded():
    """The 180 blind dates, only through v2x/data.py read_excluded() (sha256 checked there). Never printed."""
    return DA.read_excluded(EXCLUDE)


def _argv_is(cmd):
    return (len(sys.argv) >= 2 and os.path.basename(sys.argv[0]) == 'run_a12.py' and sys.argv[1] == cmd)


def stage_gate(stage):
    """The loader's gate (A12.1): VALIDATE prices need an 'A12 DISCOVER RESULT' line and `run_a12.py validate`;
    CONFIRM prices need an 'A12 CONFIRM GO' line and `run_a12.py confirm`."""
    if stage == 'DISCOVER':
        return
    if stage == 'VALIDATE':
        if not (frozen_has('A12 DISCOVER RESULT') and _argv_is('validate')):
            raise SystemExit('refused: VALIDATE prices need an "A12 DISCOVER RESULT" line and run_a12.py validate')
        return
    if stage == 'CONFIRM':
        if not (frozen_has('A12 CONFIRM GO') and _argv_is('confirm')):
            raise SystemExit('refused: pre-era prices need an "A12 CONFIRM GO" line and run_a12.py confirm')
        return
    raise SystemExit('unknown stage %s' % stage)


def gate_for_cut(cut):
    """Ruling R9: a BUILD decoder that reads rows before `cut` applies the gate of the latest stage those rows reach:
    up to 2013-01-01 DISCOVER (no gate); up to 2016-01-01 VALIDATE's gate; later rows are never decoded (A12.1)."""
    if cut <= CUT_DISCOVER:
        return 'DISCOVER'
    if cut <= CUT_RUN1:
        stage_gate('VALIDATE')
        return 'VALIDATE'
    raise SystemExit('refused: no row from 2016 on is decoded (A12.1)')


# ================================================================ loaders (A12.1)
def manifest_sha(fname, data_dir=BUILD_DIR):
    m = json.load(open(os.path.join(data_dir, 'DATA_MANIFEST.json')))
    for v in m['pairs'].values():
        if os.path.basename(v['output']['path']) == fname:
            return v['output']['sha256']
    raise SystemExit('%s not in DATA_MANIFEST.json' % fname)


def free_mb():
    try:
        with open('/proc/meminfo') as f:
            for ln in f:
                if ln.startswith('MemAvailable:'):
                    return int(ln.split()[1]) // 1024
    except Exception:
        return None
    return None


def load_raw_prefix(pair, cut, data_dir=BUILD_DIR):
    """A9's Discover loader steps on BUILD: (n16, last16) = manifest_rows (rows before 2016); decode only ts_utc with
    nrows = n16; n = the time stamps < cut, asserted a prefix; then load_run1(path, cut, nrows=n, last_ts=ts[n-1]).
    No price at or after `cut` is decoded. Returns the raw dict (prices as floats). The stage gate of the rows it
    would decode runs first, before any file is opened (ruling R9)."""
    gate_for_cut(cut)
    fname = DA.PAIRS[pair]
    path = os.path.join(data_dir, fname)
    got = sha256(path)
    if got != manifest_sha(fname, data_dir):
        raise SystemExit('%s sha256 %s differs from the manifest' % (fname, got))
    n16, last16 = DA.manifest_rows(os.path.join(data_dir, 'DATA_MANIFEST.json'), fname)
    with zipfile.ZipFile(path) as zf:
        ts, _ = DA._read_member(zf, 'ts_utc.npy', nrows=n16)
    assert int(ts[-1]) == last16 and np.all(ts < CUT_RUN1)
    n = int(np.count_nonzero(ts < cut))
    assert n > 0 and np.all(ts[:n] < cut) and (n == n16 or np.all(ts[n:] >= cut)), 'rows before the cut are not a prefix'
    last = int(ts[n - 1])
    del ts
    raw = DA.load_run1(path, cut=cut, nrows=n, last_ts=last)
    assert int(raw['ts_utc'].max()) < cut
    return raw


def load_stage(pair, stage, data_dir=BUILD_DIR):
    """One pair's cleaned unit arrays for a stage. DISCOVER: rows before 2013-01-01 only (A9's Discover loader:
    assert t1.max() < 1356998400). VALIDATE: rows before 2016-01-01 (gated). CONFIRM: pre-era rows 2005-2009 (gated)."""
    stage_gate(stage)
    avail = free_mb()
    if avail is not None and avail < 1500:
        raise SystemExit('not enough free memory (%s MB available)' % avail)
    if stage == 'CONFIRM':
        raw = load_pre_era(pair)
        cut = PRE_HI
    else:
        cut = CUT_DISCOVER if stage == 'DISCOVER' else CUT_RUN1
        raw = load_raw_prefix(pair, cut, data_dir)
    cleaned, rep = DA.clean(raw)
    del raw
    if stage == 'DISCOVER':
        assert all(int(y) < 2013 for y in rep['by_utc_year']), 'a 2013+ UTC year in the cleaning report'
        assert all(int(y) < 2013 for y in rep['window_0700_1100_by_london_year']), 'a 2013+ London year'
    if rep['stop_2pct']:
        raise SystemExit('K2 step 5: more than 2%% of 07:00-11:00 rows dropped in a pair-year (%s)' % pair)
    u = DA.to_units(cleaned)
    rep['k1_worst_points'] = u.pop('_k1_worst')
    del cleaned
    assert int(u['t1'].max()) < cut
    if stage == 'DISCOVER':
        assert int(u['t1'].max()) < CUT_DISCOVER                 # A9's Discover loader assert
    if stage == 'CONFIRM':
        assert int(u['t1'].min()) >= PRE_LO and int(u['t1'].max()) < PRE_HI
    rep.update(stage=stage, cut_utc=cut, rows_kept=int(len(u['t1'])))
    return u, rep


PRE_FILES = {'EUR_USD': 'EURUSD_M1_BA_2002_2009.csv.gz', 'GBP_USD': 'GBPUSD_M1_BA_2002_2009.csv.gz'}


def convert_pre_era(src_gz, dst_npz, lo=PRE_LO, hi=PRE_HI):
    """A12.10: convert a pre-era csv.gz (ts_utc, bid_o..ask_c, volume) to an npz with BUILD's keys. The guard is a
    filter: only rows with lo <= ts_utc < hi are decoded (the time stamp is read first; other rows' prices never are),
    and the assertion runs on the decoded set. CONFIRM's gate runs first, before the file is opened (ruling R9)."""
    stage_gate('CONFIRM')
    cols = ['ts_utc'] + DA.QFIELDS + ['volume']
    out = {k: [] for k in cols}
    with gzip.open(src_gz, 'rt') as f:
        head = f.readline().strip().split(',')
        idx = [head.index(k) for k in cols]
        for ln in f:
            p = ln.rstrip('\n').split(',')
            ts = int(p[idx[0]])
            if not (lo <= ts < hi):
                continue
            out['ts_utc'].append(ts)
            for k, i in zip(cols[1:], idx[1:]):
                out[k].append(float(p[i]))
    arr = {'ts_utc': np.asarray(out['ts_utc'], np.int64)}
    for k in DA.QFIELDS:
        arr[k] = np.asarray(out[k], np.float64)
    arr['volume'] = np.asarray(out['volume'], np.float64)
    assert len(arr['ts_utc']) == 0 or (int(arr['ts_utc'].min()) >= lo and int(arr['ts_utc'].max()) < hi)
    np.savez(dst_npz, **arr)
    return len(arr['ts_utc'])


def load_pre_era(pair, pre_dir=PRE_DIR):
    stage_gate('CONFIRM')
    path = os.path.join(pre_dir, PRE_FILES[pair].replace('.csv.gz', '.npz'))
    z = np.load(path)
    ts = z['ts_utc']
    keep = (ts >= PRE_LO) & (ts < PRE_HI)
    raw = {k: z[k][keep] for k in ['ts_utc'] + DA.QFIELDS + ['volume']}
    assert int(raw['ts_utc'].min()) >= PRE_LO and int(raw['ts_utc'].max()) < PRE_HI
    return raw


# ================================================================ eligibility and A12 days (A12.1)
class Light:
    """What DayTable and the gap test read: M1 open times and mids."""

    def __init__(self, t1, mh, ml, mc):
        self.t1, self.mh, self.ml, self.mc = t1, mh, ml, mc


def gap_ok_a8(t1, D):
    """A8.1 gap test over [00:00 London, 12:00 New York) on D, with 23:59 London the day before and 12:00 New York
    as the end points; not eligible if two neighbours are more than 16 minutes apart."""
    a0, a1 = DA.lon(D, 0), DA.nyt(D, 12)
    i, j = int(np.searchsorted(t1, a0)), int(np.searchsorted(t1, a1))
    pts = np.r_[a0 - 60, t1[i:j], a1]
    return bool(np.all(np.diff(pts) <= 16 * 60))


def eligibility_a8(t1, table, D, excluded):
    """(eligible, reasons in the order WARMUP, GAP, BLIND, HOLIDAY) as A8's eligibility_a8."""
    reasons = []
    if len(table.before(D)) < 20:
        reasons.append('WARMUP')
    if not gap_ok_a8(t1, D):
        reasons.append('GAP')
    if D in excluded:
        reasons.append('BLIND')
    if (D.month, D.day) in DA.HOLIDAY_MD:
        reasons.append('HOLIDAY')
    return (not reasons), reasons


def zone_warm_ok(t1, D):
    """A12.1 (b): the pair's first loaded M1 bar opens at or before 00:00 London on D - 100 days."""
    return int(t1[0]) <= DA.lon(D - dt.timedelta(days=SLICE_DAYS), 0)


def a12_days(u, stage, excluded):
    """Every London weekday of the stage: [(D, a8_eligible, first reason, zone_warm_ok, a12_day)]."""
    t1 = u['t1']
    table = DA.DayTable(Light(t1, u['mh'], u['ml'], u['mc']))
    d0, d1 = STAGES[stage]
    out = []
    for D in DA.weekdays(d0, d1):
        ok, reasons = eligibility_a8(t1, table, D, excluded)
        w = zone_warm_ok(t1, D)
        out.append((D, ok, '' if ok else reasons[0], w, ok and w))
    return out


# ================================================================ bars (A12.2.1)
class Bars:
    """A bar series: open times t, o, h, l, c (mid units), n = the M1 bars in each, L = length; e = close times."""
    __slots__ = ('t', 'o', 'h', 'l', 'c', 'n', 'L', 'e')

    def __init__(self, t, o, h, l, c, n, L):
        self.t, self.o, self.h, self.l, self.c, self.n, self.L = t, o, h, l, c, n, L
        self.e = t + L


def make_bars(t1, mo, mh, ml, mc, L, slot=None):
    """Bars from M1 mids: slot = floor(t / L) * L on the UTC grid (or the given slot starts); a bar exists if an M1
    bar opens in its slot; open = the first M1 open, high/low = max/min, close = the last M1 close; n = M1 count."""
    if len(t1) == 0:
        e = np.zeros(0, np.int64)
        return Bars(e, e, e, e, e, e, L)
    g = (t1 // L) * L if slot is None else slot
    start = np.flatnonzero(np.r_[True, g[1:] != g[:-1]])
    end = np.r_[start[1:], len(t1)] - 1
    t = g[start].astype(np.int64)
    return Bars(t, mo[start], np.maximum.reduceat(mh, start), np.minimum.reduceat(ml, start), mc[end],
                (end - start + 1).astype(np.int64), L)


NYZ = DA.NYZ


def ny4_slots(t1):
    """New York-close 4h slot starts (A12.2.1, R1-N4): slots start at 17:00 New York and every 4 hours (01:00, 05:00,
    09:00, 13:00, 17:00, 21:00 New York local time). Each M1 bar's slot start is the UTC instant of its slot's New York
    local start time (computed per UTC hour; a US clock change happens on a whole UTC hour, on a Sunday when the market
    is closed)."""
    if len(t1) == 0:
        return np.zeros(0, np.int64)
    hh = t1 // 3600
    uh, inv = np.unique(hh, return_inverse=True)
    starts = []
    for h in uh:
        loc = dt.datetime.fromtimestamp(int(h) * 3600, NYZ)
        k = ((loc.hour - 1) % 24) // 4
        sh = 1 + 4 * k
        day0 = loc.date() - dt.timedelta(days=1) if loc.hour == 0 else loc.date()
        st = dt.datetime(day0.year, day0.month, day0.day, sh, 0, tzinfo=NYZ)
        starts.append(int(st.timestamp()))
    return np.asarray(starts, np.int64)[inv]


def true_ranges(b):
    """TR(k) = max(h(k), c(k-1)) - min(l(k), c(k-1)); the first bar of the loaded series uses h - l. B(k) = the sum
    of TR over k-13..k; B = -1 where k < 13 (a test that needs B then fails)."""
    n = len(b.t)
    if n == 0:
        return np.zeros(0, np.int64)
    pc = np.r_[b.c[0], b.c[:-1]]
    tr = np.maximum(b.h, pc) - np.minimum(b.l, pc)
    tr[0] = b.h[0] - b.l[0]
    cs = np.r_[0, np.cumsum(tr)]
    B = np.full(n, -1, np.int64)
    if n >= 14:
        B[13:] = cs[14:] - cs[:-14]
    return B


class Pattern:
    """A pattern series (A9 B0): the bars of a series with at least THIN[L] M1 bars; fi = full-series index;
    B = the full series' 14-bar TR sum at fi."""

    def __init__(self, b, thr):
        keep = np.flatnonzero(b.n >= thr)
        self.fi = keep
        self.t, self.o, self.h, self.l, self.c = b.t[keep], b.o[keep], b.h[keep], b.l[keep], b.c[keep]
        self.L = b.L
        self.e = self.t + b.L
        self.B = true_ranges(b)[keep]
        # step ok between pattern neighbours k-1, k: open(k) - close(k-1) <= 24 h
        self.step = np.r_[False, (self.t[1:] - self.e[:-1]) <= H24] if len(keep) else np.zeros(0, bool)


# ================================================================ the day (A12.1 slice)
class Loc:
    """A location (A12.2.2). side 'L' (long: demand zone / sell-side level) or 'S'."""
    __slots__ = ('id', 'side', 'kind', 'grp', 'tf', 'lo', 'hi', 'N', 'Fr', 'edge', 'known', 's', 'status', 'age',
                 'g2', 'fT', 'x')

    def __init__(self, side, kind, grp, tf, lo, hi, N, Fr, edge, known, idk, x=None):
        self.side, self.kind, self.grp, self.tf = side, kind, grp, tf
        self.lo, self.hi, self.N, self.Fr, self.edge, self.known = int(lo), int(hi), int(N), int(Fr), int(edge), int(known)
        self.id = '%s%s@%d%s' % (kind, side, int(known), idk)
        self.s = None
        self.status = None
        self.age = None
        self.g2 = None
        self.fT = None
        self.x = x or {}

    @property
    def is_zone(self):
        return self.grp == 'ZONE'


ZONE_KINDS = {('FVG', 3600): 'FVG1', ('FVG', 7200): 'FVG2', ('FVG', 14400): 'FVG4',
              ('OB', 3600): 'OB1', ('OB', 7200): 'OB2', ('OB', 14400): 'OB4'}
TF_RANK = {3600: 1, 7200: 2, 14400: 3}


class Day:
    """One pair-day on its own slice: the M1 rows opening in [00:00 London on D - 100 days, 17:00 New York on D)
    (or a truncated / shifted copy for K14). Holds clocks, bars, the K4 context and range-query helpers."""

    def __init__(self, pair, D, t1, mo, mh, ml, mc, quotes=None, ctx=None, walk_override=None, extra_locs=None,
                 slice_check=True):
        self.pair, self.D = pair, D
        self.t1 = np.asarray(t1, np.int64)
        self.mo, self.mh, self.ml, self.mc = (np.asarray(x, np.int64) for x in (mo, mh, ml, mc))
        self.q = quotes
        L = lambda hh, mm=0: DA.lon(D, hh, mm)
        self.L00, self.L07, self.L0705 = L(0), L(7), L(7, 5)
        self.NY12, self.NY13, self.NY17 = DA.nyt(D, 12), DA.nyt(D, 13), DA.nyt(D, 17)
        self.T90 = DA.lon(D - dt.timedelta(days=TRACK_DAYS), 0)
        self.T7 = DA.lon(D - dt.timedelta(days=HS_DAYS), 0)
        self.S0T = DA.lon(prev_weekday(D), 0)
        if slice_check and len(self.t1):
            assert int(self.t1[-1]) < self.NY17, 'a slice row opens at or after 17:00 New York on D'
        t1, mo, mh, ml, mc = self.t1, self.mo, self.mh, self.ml, self.mc
        self.m5 = make_bars(t1, mo, mh, ml, mc, 300)
        self.m15 = make_bars(t1, mo, mh, ml, mc, 900)
        self.h1 = make_bars(t1, mo, mh, ml, mc, 3600)
        self.h2 = make_bars(t1, mo, mh, ml, mc, 7200)
        self.h4 = make_bars(t1, mo, mh, ml, mc, 14400)
        self._n4 = None
        if ctx is None:
            table = DA.DayTable(Light(t1, mh, ml, mc))
            ctx = DA.make_ctx(D, table)
        self.ctx = ctx
        self.walk_override = walk_override
        self.extra_locs = extra_locs or []
        # block minima / maxima for M1 range queries
        self._B = 256
        n = len(t1)
        nb = (n + self._B - 1) // self._B
        if n:
            pad = nb * self._B - n
            self._bmin = np.r_[ml, np.full(pad, np.iinfo(np.int64).max)].reshape(nb, self._B).min(axis=1)
            self._bmax = np.r_[mh, np.full(pad, np.iinfo(np.int64).min)].reshape(nb, self._B).max(axis=1)
        else:
            self._bmin = self._bmax = np.zeros(0, np.int64)

    @property
    def n4(self):
        if self._n4 is None:
            self._n4 = make_bars(self.t1, self.mo, self.mh, self.ml, self.mc, 14400, slot=ny4_slots(self.t1))
        return self._n4

    # --- M1 helpers
    def i1(self, t):
        """index of the first M1 bar opening at or after t"""
        return int(np.searchsorted(self.t1, t))

    def first_le(self, a, b, thr):
        """first M1 index in [a, b) with mid low <= thr, or None"""
        return self._first(a, b, thr, True)

    def first_ge(self, a, b, thr):
        """first M1 index in [a, b) with mid high >= thr, or None"""
        return self._first(a, b, thr, False)

    def _first(self, a, b, thr, low):
        if b <= a:
            return None
        arr = self.ml if low else self.mh
        B = self._B
        e1 = min(b, ((a // B) + 1) * B)
        seg = arr[a:e1]
        hit = (seg <= thr) if low else (seg >= thr)
        if hit.any():
            return a + int(np.argmax(hit))
        if e1 >= b:
            return None
        k0, k1 = e1 // B, (b - 1) // B
        bm = self._bmin[k0:k1 + 1] if low else self._bmax[k0:k1 + 1]
        hb = (bm <= thr) if low else (bm >= thr)
        if not hb.any():
            return None
        for k in np.flatnonzero(hb):
            s0 = (k0 + int(k)) * B
            seg = arr[s0:min(b, s0 + B)]
            hit = (seg <= thr) if low else (seg >= thr)
            if hit.any():
                return s0 + int(np.argmax(hit))
        return None

    def min_ml(self, t_from, t_to):
        a, b = self.i1(t_from), self.i1(t_to)
        return int(self.ml[a:b].min()) if b > a else None

    def max_mh(self, t_from, t_to):
        a, b = self.i1(t_from), self.i1(t_to)
        return int(self.mh[a:b].max()) if b > a else None

    def h4_bias(self, t, grid='utc'):
        b = self.h4 if grid == 'utc' else self.n4
        return EN.bar_bias(b.t, b.h, b.l, 14400, t)

    def w3(self):
        return EN.daily_bias(self.ctx)


def day_from_units(pair, D, u, cut=None, shift=None, whole=False):
    """The slice of D from the unit arrays u (rows opening in [00:00 London on D - 100 days, 17:00 New York on D)),
    optionally truncated to rows opening before `cut` and with `shift` = (t_from, s_points_by_row) added to all 8
    prices of rows opening at or after t_from (K14). Mids are rebuilt from the quotes. whole=True: every loaded row
    before 17:00 New York on D (K14's window test)."""
    a = 0 if whole else int(np.searchsorted(u['t1'], DA.lon(D - dt.timedelta(days=SLICE_DAYS), 0)))
    b = int(np.searchsorted(u['t1'], DA.nyt(D, 17)))
    if cut is not None:
        b = min(b, int(np.searchsorted(u['t1'], cut)))
    t1 = u['t1'][a:b]
    q = {k: u[k][a:b] for k in DA.QFIELDS}
    mids = {f: u['m' + f][a:b] for f in 'ohlc'}
    if shift is not None:
        t_from, sp = shift
        k0 = int(np.searchsorted(t1, t_from))
        q = {k: v.copy() for k, v in q.items()}
        add = 4 * np.asarray(sp, np.int64)
        assert len(add) == len(t1) - k0
        for k in q:
            q[k][k0:] += add
        mids = {f: (q['bid_' + f] + q['ask_' + f]) // 2 for f in 'ohlc'}
    return Day(pair, D, t1, mids['o'], mids['h'], mids['l'], mids['c'], quotes=q)


# ================================================================ locations (A12.2.2)
def zone_locs(day, b, tfkind, grid='utc'):
    """FVG and OB zones (both sides) on the pattern series of bar series b, with known time in [T90, NY12)."""
    P = Pattern(b, THIN[b.L])
    out = []
    n = len(P.t)
    lo_t, hi_t = day.T90, day.NY12
    sfx = 'N' if grid == 'ny4' else ''
    kf = ZONE_KINDS[('FVG', b.L)] + sfx
    ko = ZONE_KINDS[('OB', b.L)] + sfx
    if n >= 3:
        k = np.arange(2, n)
        ok = P.step[k] & P.step[k - 1] & (P.B[k] >= 0) & (P.e[k] >= lo_t) & (P.e[k] < hi_t)
        gb = P.l[k] - P.h[k - 2]                     # bull gap
        gs = P.l[k - 2] - P.h[k]                     # bear gap
        for kk in k[ok & (gb >= GAP_MIN) & (56 * gb >= P.B[k])]:
            lo, hi = int(P.h[kk - 2]), int(P.l[kk])
            out.append(Loc('L', kf, 'ZONE', b.L, lo, hi, hi, lo, hi, P.e[kk], '', x={'c3': int(P.t[kk])}))
        for kk in k[ok & (gs >= GAP_MIN) & (56 * gs >= P.B[k])]:
            lo, hi = int(P.h[kk]), int(P.l[kk - 2])
            out.append(Loc('S', kf, 'ZONE', b.L, lo, hi, lo, hi, lo, P.e[kk], '', x={'c3': int(P.t[kk])}))
    # OB (K7's form on the pattern series; K3 wick swings)
    if n >= 5:
        sh, sl = EN.find_swings(P.h, P.l)
        for side, sw in (('L', sh), ('S', sl)):
            for a, i in enumerate(sw):
                i = int(i)
                q_hi = int(sw[a + 1]) + 2 if a + 1 < len(sw) else n - 1      # i stays the latest swing up to i' + 2
                q_hi = min(q_hi, n - 1)
                if i + 3 > q_hi:
                    continue
                seg = P.c[i + 3:q_hi + 1]
                hit = (seg > P.h[i]) if side == 'L' else (seg < P.l[i])
                if not hit.any():
                    continue
                q = i + 3 + int(np.argmax(hit))
                if not (lo_t <= P.e[q] < hi_t):
                    continue
                if i - 2 < 0 or not np.all(P.step[i - 1:q + 1]):        # steps i-2..q obey the 24-hour rule
                    continue
                if side == 'L':
                    seg = P.l[i:q + 1]
                    r = i + int(len(seg) - 1 - np.argmin(seg[::-1]))       # the lowest low, the latest on ties
                    obb = None
                    for x in range(r, i - 1, -1):
                        if P.c[x] < P.o[x]:
                            obb = x
                            break
                    if obb is None:
                        continue
                    lo, hi = int(P.l[obb]), int(P.h[obb])
                    out.append(Loc('L', ko, 'ZONE', b.L, lo, hi, hi, lo, hi, P.e[q], '',
                                   x={'q': int(P.t[q]), 'ob': int(P.t[obb]), 'sw': int(P.t[i])}))
                else:
                    seg = P.h[i:q + 1]
                    r = i + int(len(seg) - 1 - np.argmax(seg[::-1]))
                    obb = None
                    for x in range(r, i - 1, -1):
                        if P.c[x] > P.o[x]:
                            obb = x
                            break
                    if obb is None:
                        continue
                    lo, hi = int(P.l[obb]), int(P.h[obb])
                    out.append(Loc('S', ko, 'ZONE', b.L, lo, hi, lo, hi, lo, P.e[q], '',
                                   x={'q': int(P.t[q]), 'ob': int(P.t[obb]), 'sw': int(P.t[i])}))
    return out


def hs_locs(day, wick=False):
    """HS: old 1h body swing levels (m18), or R1-HSW's long-wick swings: H1 pattern series bars i with
    open(i) >= 00:00 London on D - 7 days, every step i-2..i+2 within 24 h, known close(i+2) < 12:00 New York."""
    P = Pattern(day.h1, THIN[3600])
    n = len(P.t)
    out = []
    if n < 5:
        return out
    bt, bb = np.maximum(P.o, P.c), np.minimum(P.o, P.c)
    body = np.abs(P.c - P.o)
    if wick:
        sh, sl = EN.find_swings(P.h, P.l)
    else:
        sh, sl = EN.find_swings(bt, bb)
    kind = 'HSW' if wick else 'HS'
    for side, sw in (('L', sl), ('S', sh)):
        for i in sw:
            i = int(i)
            if P.t[i] < day.T7 or i + 2 >= n or P.e[i + 2] >= day.NY12:
                continue
            if not np.all(P.step[i - 1:i + 3]):
                continue
            if wick:
                if side == 'L':
                    if bb[i] - P.l[i] < body[i]:
                        continue
                    lv = int(P.l[i])
                else:
                    if P.h[i] - bt[i] < body[i]:
                        continue
                    lv = int(P.h[i])
            else:
                lv = int(bb[i]) if side == 'L' else int(bt[i])
            out.append(Loc(side, kind, 'HS', 3600, lv, lv, lv, lv, lv, P.e[i + 2], '', x={'i': int(P.t[i])}))
    return out


def crt_list(day, b, grid='utc'):
    """CRTs (A12.2.9) on the pattern series of b (1h or 4h): c0, c1 in neighbouring slots. Returns (crts, lost):
    every CRT with close(c1) from 00:00 London on D to 12:00 New York on D, both included (K1's decision time
    close(c1) 'must lie from 07:05 London to 12:00 New York', A12.2.9, the phrase A12.2.4 writes '(both included)';
    K2, F8 and crt_a12_{pair}.csv see the same list; only the Family 1 location keeps close(c1) < 12:00 New York,
    crt_locs), and the count of plain-series neighbouring pairs that meet the CRT conditions but have a thin c0 or c1
    (lost to the thin-bar rule)."""
    L = b.L
    thr = THIN[L]
    out, lost = [], 0
    n = len(b.t)
    tfn = ('CRT1' if L == 3600 else 'CRT4') + ('N' if grid == 'ny4' else '')
    for k in range(1, n):
        if b.t[k] != b.t[k - 1] + L:
            continue
        if not (day.L00 <= b.e[k] <= day.NY12):
            continue
        l0, h0, l1, h1, c1 = int(b.l[k - 1]), int(b.h[k - 1]), int(b.l[k]), int(b.h[k]), int(b.c[k])
        for side in ('L', 'S'):
            if side == 'L':
                ok = l1 <= l0 - TT and c1 >= l0 + MARGIN and h1 < h0
            else:
                ok = h1 >= h0 + TT and c1 <= h0 - MARGIN and l1 > l0
            if not ok:
                continue
            if b.n[k] < thr or b.n[k - 1] < thr:
                lost += 1
                continue
            W = l1 if side == 'L' else h1
            lvl = l0 if side == 'L' else h0
            tgt = h0 if side == 'L' else l0
            # the sweep: the first M1 bar of c1 with mid low <= CRT L - 20 (short: mid high >= CRT H + 20)
            a, z = day.i1(int(b.t[k])), day.i1(int(b.e[k]))
            js = day.first_le(a, z, lvl - TT) if side == 'L' else day.first_ge(a, z, lvl + TT)
            out.append(dict(tf=L, kind=tfn, grid=grid, side=side, c0=int(b.t[k - 1]), c1=int(b.t[k]), close=int(b.e[k]),
                            lvl=lvl, tgt=tgt, W=W, cc1=c1, sweep=int(day.t1[js]) if js is not None else None,
                            id='%s%s@%d' % (tfn, side, int(b.e[k]))))
    return out, lost


def level_locs(day):
    """AS (Asian high/low), PD (yesterday's high/low), EQ (equal highs/lows on K3 M5 swings)."""
    out = []
    a, z = day.i1(day.L00), day.i1(day.L07)
    if z > a:
        AL, AH = int(day.ml[a:z].min()), int(day.mh[a:z].max())
        out.append(Loc('L', 'AS', 'AS', None, AL, AL, AL, AL, AL, day.L07, ''))
        out.append(Loc('S', 'AS', 'AS', None, AH, AH, AH, AH, AH, day.L07, ''))
    c = day.ctx
    if c.PDL is not None and c.pd_known is not None:
        out.append(Loc('L', 'PD', 'PD', None, c.PDL, c.PDL, c.PDL, c.PDL, c.PDL, c.pd_known, ''))
        out.append(Loc('S', 'PD', 'PD', None, c.PDH, c.PDH, c.PDH, c.PDH, c.PDH, c.pd_known, ''))
    m5 = day.m5
    n5 = len(m5.t)
    sh, sl = EN.find_swings(m5.h, m5.l)
    for side, sw, ext, high in (('L', sl, m5.l, False), ('S', sh, m5.h, True)):
        lv, ii, jj = EN.find_eq(sw, ext, high)
        # each level is one item per (kind, level bar) (A12.2.2). The level bar is the swing holding the level, the
        # later one on equal values. A level bar can hold two pools, (prev, lb) and (lb, next); the item takes the
        # known time close(j + 2) and the first swing of its earliest-known pool (ruling E1, pending), and the 12-hour
        # tracking filter is applied to that pool after the merge.
        first = {}
        for v, i, j in zip(lv, ii, jj):
            i, j = int(i), int(j)
            if j + 2 >= n5:
                continue
            vi, vj = int(ext[i]), int(ext[j])
            lb = (i if vi > vj else j) if high else (i if vi < vj else j)
            assert int(ext[lb]) == int(v)
            if lb not in first or j < first[lb][1]:
                first[lb] = (i, j)
        for lb in sorted(first):
            i, j = first[lb]
            known = int(m5.e[j + 2])
            if m5.t[i] < day.L00 - H12 or known >= day.NY12:
                continue
            v = int(ext[lb])
            out.append(Loc(side, 'EQ', 'EQ', None, v, v, v, v, v, known, '#%d' % int(m5.t[i]),
                           x={'i': int(m5.t[i]), 'j': int(m5.t[j]), 'lb': int(m5.t[lb])}))
    return out


def crt_locs(day, crts):
    """the CRT1 / CRT4 locations (A12.2.2): the CRTs whose c1 closes in [00:00 London on D, 12:00 New York on D)"""
    out = []
    for c in crts:
        if not (day.L00 <= c['close'] < day.NY12):
            continue
        v = c['lvl']
        L = Loc(c['side'], c['kind'], 'CRT', c['tf'], v, v, v, v, v, c['close'], '', x=dict(c))
        out.append(L)
    return out


def extra_locs(day):
    """typed locations for the unit tests only (dicts: side, kind, lo, hi, known)"""
    out = []
    for e in day.extra_locs:
        side, kind = e['side'], e['kind']
        tf = {'1': 3600, '2': 7200, '4': 14400}[kind[-1]]
        lo, hi = e['lo'], e['hi']
        N, Fr = (hi, lo) if side == 'L' else (lo, hi)
        out.append(Loc(side, kind, 'ZONE', tf, lo, hi, N, Fr, N, e['known'], e.get('idk', '#x')))
    return out


def start_and_grade(day, L):
    """s(L), the status (GONE, NOT_TOUCHED, EQ_OLD, STARTED), the age, and for a started location the grade-2 time
    g2 (the close of the first complete plain M15 bar with close > s(L) that closes inside) and the failure time fT
    (the same on plain H1). Inside: close <= e - 10 (short: >= e + 10)."""
    long_ = L.side == 'L'
    if L.grp == 'CRT':
        s = L.known
    else:
        a, b = day.i1(L.known), day.i1(day.NY12)
        if L.grp == 'ZONE':
            thr = L.N
        else:
            thr = L.edge - TT if long_ else L.edge + TT
        k = day.first_le(a, b, thr) if long_ else day.first_ge(a, b, thr)
        s = int(day.t1[k]) if k is not None else None
    L.s = s
    if s is None:
        L.status = 'NOT_TOUCHED'
        return L
    L.age = s - L.known
    if s < day.L00:
        L.status = 'GONE'
        return L
    if L.grp == 'EQ' and L.x['i'] < s - H12:
        L.status = 'EQ_OLD'
        return L
    L.status = 'STARTED'
    e = L.edge
    for bars, attr in ((day.m15, 'g2'), (day.h1, 'fT')):
        k0 = int(np.searchsorted(bars.e, s, side='right'))      # close > s(L)
        cl = bars.c[k0:]
        ins = (cl <= e - MARGIN) if long_ else (cl >= e + MARGIN)
        if ins.any():
            setattr(L, attr, int(bars.e[k0 + int(np.argmax(ins))]))
    return L


def build_locations(day, locset='main'):
    """Every tracked location of the day for a location set: 'main'; 'hsw' (HS from 1h long-wick swings, R1-HSW);
    'n4' (every 4h item on New York-close 4h bars, R1-N4). Returns (locs, crts, crt_lost)."""
    locs = []
    locs += zone_locs(day, day.h1, 'h1')
    locs += zone_locs(day, day.h2, 'h2')
    if locset == 'n4':
        locs += zone_locs(day, day.n4, 'h4', grid='ny4')
    else:
        locs += zone_locs(day, day.h4, 'h4')
    locs += level_locs(day)
    locs += hs_locs(day, wick=(locset == 'hsw'))
    c1, lost1 = crt_list(day, day.h1)
    if locset == 'n4':
        c4, lost4 = crt_list(day, day.n4, grid='ny4')
    else:
        c4, lost4 = crt_list(day, day.h4)
    crts = c1 + c4
    locs += crt_locs(day, crts)
    locs += extra_locs(day)
    for L in locs:
        start_and_grade(day, L)
    return locs, crts, lost1 + lost4


def grade_at(L, t):
    """1, 2 or 'F' (FAILED) at time t (only for started locations with s(L) <= t)"""
    if L.fT is not None and L.fT <= t:
        return 'F'
    if L.g2 is not None and L.g2 <= t:
        return 2
    return 1


def failed_by(L, t):
    return L.fT is not None and L.fT <= t


# ================================================================ the walk (A12.2.3)
class Walk:
    """The day's walk on M5 bars opening in [s0, 12:00 New York on D) (k = 1.0). Events and moves carry global M5
    indices; ev_at[j] is the event at bar j."""

    def __init__(self, day, keep_states=False):
        m5 = day.m5
        wo = day.walk_override
        if wo is None:
            a = int(np.searchsorted(m5.t, day.S0T))
            b = int(np.searchsorted(m5.t, day.NY12))
            ab = abar_pairs(m5.t[a:b], 300, day.m15.t, day.m15.h, day.m15.l) if b > a else []
            res = run_walk(m5.o[a:b].tolist(), m5.h[a:b].tolist(), m5.l[a:b].tolist(), m5.c[a:b].tolist(), ab,
                           K_WALK, keep_states=keep_states) if b > a else dict(events=[], moves=[], states=[])
        else:
            a = int(np.searchsorted(m5.t, wo['t0']))
            b = int(np.searchsorted(m5.t, wo.get('t1', day.NY12)))
            res = run_walk(m5.o[a:b].tolist(), m5.h[a:b].tolist(), m5.l[a:b].tolist(), m5.c[a:b].tolist(),
                           wo['abar'], wo.get('k', K_WALK), start=wo.get('start'), keep_states=keep_states)
        self.a, self.b = a, b
        self.events = []
        self.ev_at = {}
        for e in res['events']:
            g = dict(j=e['j'] + a, close=e['close'], dir=e['dir'], kind=e['kind'],
                     broken=(e['broken'][0], e['broken'][1] + a), prot=(e['prot'][0], e['prot'][1] + a),
                     X=(e['X'][0], e['X'][1] + a), leg=(e['leg'][0], e['leg'][1] + a))
            self.events.append(g)
            self.ev_at[g['j']] = g
        self.moves = [dict(j=m['j'] + a, which=m['which'], level=(m['level'][0], m['level'][1] + a)) for m in res['moves']]
        self.states = [(j + a, s) for j, s in res.get('states', [])]


# ================================================================ factors and score (A12.3)
def factors(day, side, active, j, locs_by_side, crts, grid='utc'):
    cj = int(day.m5.e[j])
    long_ = side == 'L'
    f = {}
    # F1: two scenarios within 2.0 pips: a zone and a level, or two zones known more than 24 h apart
    f1, f1k = 0, ''
    kinds = []
    for x in range(len(active)):
        for y in range(x + 1, len(active)):
            A, B = active[x], active[y]
            if max(A.lo, B.lo) - min(A.hi, B.hi) > F1_TOL:
                continue
            if A.is_zone != B.is_zone:
                kinds.append('zone+level')
            elif A.is_zone and B.is_zone and abs(A.known - B.known) > H24:
                kinds.append('zone+zone')
    if kinds:
        f1 = 1
        f1k = 'zone+level' if 'zone+level' in kinds else 'zone+zone'
    f['F1'] = f1
    f['F2'] = min(2, sum(1 for L in active if L.grp in ('AS', 'PD', 'EQ', 'HS')))
    w3 = day.w3()
    hb = day.h4_bias(cj, grid)
    want, opp = ('bull', 'bear') if long_ else ('bear', 'bull')
    f['F3'] = int(w3 == want)
    f['F4'] = int(hb != opp)
    f['F5'] = int(any(L.kind in ('FVG4', 'OB4', 'FVG4N', 'OB4N') or L.grp == 'PD' for L in active))
    f['F6'] = int(any(L.is_zone and L.age is not None and L.age > AGE7 for L in active))
    f['F7'] = int(any(grade_at(L, cj) == 1 for L in active))
    t0 = min(L.s for L in active)
    f['F8'] = int(any(c['side'] == side and t0 <= c['close'] <= cj for c in crts))
    f9 = 0
    same = locs_by_side[side]
    for Z in active:
        if not Z.is_zone or Z.tf not in (3600, 7200):
            continue
        for Zp in same:
            if not Zp.is_zone or Zp.tf is None or Zp.tf <= Z.tf:
                continue
            if Zp.known > cj or Zp.status == 'GONE' or failed_by(Zp, cj):
                continue
            if abs(Z.known - Zp.known) > H24:
                continue
            if max(Z.lo, Zp.lo) <= min(Z.hi, Zp.hi):
                f9 = 1
                break
        if f9:
            break
    f['F9'] = f9
    f['score'] = sum(f['F%d' % i] for i in range(1, 10))
    f['f1_kind'] = f1k
    if f['F3'] == 1 and f['F4'] == 1:
        bs = 'WITH'
    elif w3 == opp and hb != want:
        bs = 'AGAINST'
    else:
        bs = 'NONE'
    f['bias_state'] = bs
    f['w3'] = w3
    f['h4b'] = hb
    return f


def bias_tags(day, side, t, grid='utc'):
    """F3, F4 and the bias state at time t (C1 rows carry F3 and F4 only)."""
    long_ = side == 'L'
    w3, hb = day.w3(), day.h4_bias(t, grid)
    want, opp = ('bull', 'bear') if long_ else ('bear', 'bull')
    F3, F4 = int(w3 == want), int(hb != opp)
    bs = 'WITH' if (F3 and F4) else ('AGAINST' if (w3 == opp and hb != want) else 'NONE')
    return F3, F4, bs, w3, hb


# ================================================================ the order stage (A12.2.5)
def leg_gaps(day, long_, pl, ob, tau):
    """the leg's 5m FVGs: neighbouring M5 bars c1, c2, c3 with c1 >= pl, c3 <= ob, gap >= 1.0 pip, not traded
    through by an M1 bar opening in [close(c3), tau). Returns [(c3, lo, hi)] in c3 order."""
    m5 = day.m5
    out = []
    for c3 in range(pl + 2, ob + 1):
        c1 = c3 - 2
        if long_:
            lo, hi = int(m5.h[c1]), int(m5.l[c3])
        else:
            lo, hi = int(m5.h[c3]), int(m5.l[c1])
        if hi - lo < GAP_MIN:
            continue
        if c3 < ob:
            if long_:
                v = day.min_ml(int(m5.e[c3]), tau)
                if v is not None and v <= lo:
                    continue
            else:
                v = day.max_mh(int(m5.e[c3]), tau)
                if v is not None and v >= hi:
                    continue
        out.append((c3, lo, hi))
    return out


def htf_gaps(day, bars, long_, pl, tau):
    """15m or 1h FVGs of the leg for the gap sync (m9): plain bars C1, C2, C3 in consecutive slots, gap >= 1.0 pip,
    C3 opening at or after the slot holding bar(PL'), C3 complete at tau, not traded through by an M1 bar opening in
    [close(C3), tau). Returns [(lo, hi)]."""
    L = bars.L
    slot0 = (int(day.m5.t[pl]) // L) * L
    k0 = int(np.searchsorted(bars.t, slot0))
    k1 = int(np.searchsorted(bars.e, tau, side='right'))          # bars complete at tau: open + L <= tau
    out = []
    for c3 in range(max(k0, 2), k1):
        c1 = c3 - 2
        if bars.t[c3] - bars.t[c1] != 2 * L or bars.t[c3 - 1] - bars.t[c1] != L:
            continue
        if long_:
            lo, hi = int(bars.h[c1]), int(bars.l[c3])
        else:
            lo, hi = int(bars.h[c3]), int(bars.l[c1])
        if hi - lo < GAP_MIN:
            continue
        if long_:
            v = day.min_ml(int(bars.e[c3]), tau)
            if v is not None and v <= lo:
                continue
        else:
            v = day.max_mh(int(bars.e[c3]), tau)
            if v is not None and v >= hi:
                continue
        out.append((lo, hi))
    return out


def shares(a, b):
    """two ranges share at least one unit: max(lo, lo') <= min(hi, hi')"""
    return max(a[0], b[0]) <= min(a[1], b[1])


def choose_gap(gaps, g1, g15, mode='sync'):
    """m9: gaps = the leg's 5m FVGs [(c3, lo, hi)] in c3 order; g1 / g15 = the leg's closed 1h / 15m FVGs [(lo, hi)].
    sync: the latest-c3 gap synced at 1h, else the latest synced at 15m, else the latest; newest: the latest;
    oldest: the earliest. Returns (gap, SYNC of that gap: '1h', '15m' or 'none')."""
    s1 = [g for g in gaps if any(shares(g[1:], h) for h in g1)]
    s15 = [g for g in gaps if any(shares(g[1:], h) for h in g15)]
    if mode == 'sync':
        ch = s1[-1] if s1 else (s15[-1] if s15 else gaps[-1])
    elif mode == 'newest':
        ch = gaps[-1]
    else:
        ch = gaps[0]
    sync = '1h' if any(shares(ch[1:], h) for h in g1) else ('15m' if any(shares(ch[1:], h) for h in g15) else 'none')
    return ch, sync


def pick_zone(day, long_, pl, bk, ob, tau, mode='sync'):
    """A12.2.5 step 4: the leg's FVG (synced at 1h, else 15m, else the latest; or R1-NEWEST / R1-OLD), else K7's OB
    from bar(PL') back to the broken swing's bar (at least 1.0 pip tall), else None.
    Returns dict(kind, lo, hi, c3, sync, n_gaps) or None."""
    gaps = leg_gaps(day, long_, pl, ob, tau)
    if gaps:
        g1 = htf_gaps(day, day.h1, long_, pl, tau)
        g15 = htf_gaps(day, day.m15, long_, pl, tau)
        ch, sync = choose_gap(gaps, g1, g15, mode)
        return dict(kind='FVG', lo=ch[1], hi=ch[2], c3=int(day.m5.t[ch[0]]), sync=sync, n_gaps=len(gaps))
    m5 = day.m5
    for i in range(pl, bk - 1, -1):
        if (long_ and m5.c[i] < m5.o[i]) or (not long_ and m5.c[i] > m5.o[i]):
            lo, hi = int(m5.l[i]), int(m5.h[i])
            if hi - lo < GAP_MIN:
                return None
            return dict(kind='OB', lo=lo, hi=hi, c3=int(m5.t[i]), sync='', n_gaps=0)
    return None


def live_opposing(locs_opp, tau):
    """the opposing POIs live at tau: zones (FVG/OB 1h-4h) and AS/PD levels, known at or before tau, tracked,
    not GONE and not FAILED by tau"""
    out = []
    for L in locs_opp:
        if not (L.is_zone or L.grp in ('AS', 'PD')):
            continue
        if L.known > tau or L.status == 'GONE' or failed_by(L, tau):
            continue
        out.append(L)
    return out


def next_poi(locs_opp, tau, E, long_):
    best = None
    for L in live_opposing(locs_opp, tau):
        dist = (L.N - E) if long_ else (E - L.N)
        if best is None or dist < best[0] or (dist == best[0] and L.id < best[1].id):
            best = (dist, L)
    return best


def order_stage(day, cfg, side, j, ev, locs_opp, active=None, crt=None, cstar=None, score=None):
    """A12.2.5 for one candidate (R, C, K2 families). Returns the order row (dict)."""
    long_ = side == 'L'
    m5 = day.m5
    n5 = len(m5.t)
    row = dict(status=None, ob_open=None, tau=None, X=None, zone_kind='', zone_lo=None, zone_hi=None, zone_c3=None,
               sync='', n_gaps=None, E=None, S0=None, d0=None, d=None, S=None, T=None, target_kind='',
               target_R=None, poi_kind='', poi_id='', poi_N=None, poi_dist=None, poi_R=None, expiry=None)
    ob = j + 1
    if ob >= n5 or m5.e[ob] > day.NY12:
        row['status'] = 'NO_ORDER_BAR'
        return row
    tau = int(m5.e[ob])
    row.update(ob_open=int(m5.t[ob]), tau=tau, expiry=min(tau + ORDER_LIFE, day.NY13))
    fam = cfg['fam']
    if fam == 'R' and all(failed_by(L, tau) for L in active):
        row['status'] = 'POI_FAILED'
        return row
    X = crt['W'] if fam == 'K2' else ev['X'][0]
    row['X'] = X
    cj = int(m5.e[j])
    if long_:
        v = day.min_ml(cj, tau)
        void = v is not None and v < X
    else:
        v = day.max_mh(cj, tau)
        void = v is not None and v > X
    if void:
        row['status'] = 'VOID'
        return row
    pl, bk = ev['prot'][1], ev['broken'][1]
    z = pick_zone(day, long_, pl, bk, ob, tau, cfg['zone'])
    if z is None:
        row['status'] = 'NO_ZONE'
        return row
    row.update(zone_kind=z['kind'], zone_lo=z['lo'], zone_hi=z['hi'], zone_c3=z['c3'], sync=z['sync'],
               n_gaps=z['n_gaps'])
    lo, hi = z['lo'], z['hi']
    assert (lo + hi) % 2 == 0
    E = (lo + hi) // 2 + (SHIFT if long_ else -SHIFT)
    stop = cfg['stop']
    if fam == 'K2' and stop == 'wick':
        S0 = crt['W'] - BUF if long_ else crt['W'] + BUF
    elif stop == 'xwick':
        S0 = X - BUF if long_ else X + BUF
    elif stop == 's15':
        S0 = lo - BUF15 if long_ else hi + BUF15
    else:
        S0 = lo - BUF if long_ else hi + BUF
    row.update(E=E, S0=S0)
    if (long_ and S0 >= E) or (not long_ and S0 <= E):
        row['status'] = 'STOP_SIDE'
        return row
    d0 = (E - S0) if long_ else (S0 - E)
    d = max(d0, FLOOR8) if stop == 'floor8' else d0
    S = (E - d) if long_ else (E + d)
    row.update(d0=d0, d=d, S=S)
    A = day.ctx.A
    if A is None or 60 * d0 > A or A < A_MIN:
        row['status'] = 'CAP'
        return row
    # targets
    sg = 1 if long_ else -1
    tgt = cfg['target']
    if fam == 'K2':
        T = crt['tgt']
        row['target_kind'] = 'CRT'
        if tgt == '3R':
            T = E + sg * 3 * d
            row['target_kind'] = '3R'
        elif tgt == 'POI':
            bp = next_poi(locs_opp, tau, E, long_)
            if bp is not None:
                Tp = bp[1].N - sg * POI_OFF
                row.update(poi_kind=bp[1].kind, poi_id=bp[1].id, poi_N=bp[1].N, poi_dist=bp[0],
                           poi_R=str(Fraction(bp[0], d)))
                if (long_ and Tp < T) or (not long_ and Tp > T):
                    T = Tp
                    row['target_kind'] = 'POI'
        if tgt != '3R' and sg * (T - E) < 2 * d:
            row.update(T=T, status='MIN_RR', target_R=str(Fraction(sg * (T - E), d)))
            return row
    else:
        if tgt == '3R':
            T = E + sg * 3 * d
            row['target_kind'] = '3R'
        else:
            bp = next_poi(locs_opp, tau, E, long_)
            lo_mult = 2 if tgt == 'TP2' else 3
            if bp is not None:
                dist, P = bp
                row.update(poi_kind=P.kind, poi_id=P.id, poi_N=P.N, poi_dist=dist, poi_R=str(Fraction(dist, d)))
            if bp is not None and dist < lo_mult * d:
                row['status'] = 'TARGET_NEAR'
                return row
            if bp is not None and 2 * dist <= 7 * d:
                T = P.N - sg * POI_OFF
                row['target_kind'] = 'POI'
            else:
                T = E + sg * 3 * d
                row['target_kind'] = '3R'
    row['T'] = T
    row['target_R'] = str(Fraction(sg * (T - E), d))
    if cfg['tier']:
        if cstar is None:
            raise ValueError('H1 needs c*')
        if score < cstar:
            row['status'] = 'BELOW_TIER'
            return row
    row['status'] = 'ARMED'
    return row


# ================================================================ setups and candidates (A12.2.4)
def start_bar_ok(day, j, ev, s):
    """touch, then break: the start M1 bar opens no later than the first M1 bar of bar j whose mid close is at or
    beyond broken +/- 10"""
    m5 = day.m5
    a, b = day.i1(int(m5.t[j])), day.i1(int(m5.e[j]))
    br = ev['broken'][0]
    mc = day.mc[a:b]
    hit = (mc >= br + MARGIN) if ev['dir'] == 'UP' else (mc <= br - MARGIN)
    if not hit.any():
        return False
    return s <= int(day.t1[a + int(np.argmax(hit))])


class Setup:
    __slots__ = ('L', 'jstart', 'chfrom', 'chs', 'choch', 'alive', 'end', 'end_t', 'breaks', 'grade_trig', 'sbt')

    def __init__(self, L, jstart, chfrom, chs):
        self.L, self.jstart, self.chfrom, self.chs = L, jstart, chfrom, chs
        self.choch = None
        self.alive = True
        self.end, self.end_t = None, None
        self.breaks = []
        self.grade_trig = ''
        self.sbt = False


def setups_for(day, locs, side):
    m5 = day.m5
    out = []
    for L in locs:
        if L.side != side or L.status != 'STARTED':
            continue
        if L.grp == 'CRT':
            js = int(np.searchsorted(m5.t, L.known))                 # the M5 bar opening at close(c1)
            sw = L.x.get('sweep')
            chf = int(np.searchsorted(m5.t, (sw // 300) * 300)) if sw is not None else js
            chs = sw if sw is not None else L.s
        else:
            js = int(np.searchsorted(m5.t, (L.s // 300) * 300))     # the M5 bar holding s(L)
            chf, chs = js, L.s
        if js >= len(m5.t):
            continue
        out.append(Setup(L, js, min(chf, js), chs))
    return out


def run_reversal(day, dname, cfg, W, locs, crts, cstar=None, grid='utc'):
    """R1, R2, H1 and their variants: setups, candidates and order rows for both sides."""
    m5 = day.m5
    n5 = len(m5.t)
    by_side = {'L': [L for L in locs if L.side == 'L'], 'S': [L for L in locs if L.side == 'S']}
    cands, setups_out = [], []
    jend = int(np.searchsorted(m5.e, day.NY12, side='right'))          # bars closing <= 12:00 New York
    for side in ('L', 'S'):
        up, dn = ('UP', 'DOWN') if side == 'L' else ('DOWN', 'UP')
        opp = by_side['S' if side == 'L' else 'L']
        S = setups_for(day, locs, side)
        if not S:
            continue
        j0 = min(s.chfrom for s in S)
        for j in range(j0, min(jend, n5)):
            cj = int(m5.e[j])
            ev = W.ev_at.get(j)
            trig = []
            for st in S:
                if not st.alive or j < st.chfrom:
                    continue
                if j >= st.jstart and failed_by(st.L, cj):
                    st.alive, st.end, st.end_t = False, 'FAILED', cj
                    continue
                if ev is None:
                    continue
                if cfg['trig'] == 'R1':
                    if ev['dir'] == dn:
                        st.choch = None
                    elif ev['dir'] == up and ev['kind'] == 'CHOCH':
                        ok = True
                        if j == st.chfrom:
                            ok = start_bar_ok(day, j, ev, st.chs)
                        if ok:
                            st.choch = j
                            st.sbt = (j == st.chfrom)
                    elif (ev['dir'] == up and ev['kind'] == 'BOS' and st.choch is not None and j >= st.jstart):
                        trig.append(st)
                else:
                    if ev['dir'] == up and ev['kind'] in ('CHOCH', 'BOS') and j >= st.jstart:
                        if j == st.jstart and not start_bar_ok(day, j, ev, st.L.s):
                            continue
                        st.sbt = (j == st.jstart)
                        trig.append(st)
            if not trig:
                continue
            if cj < day.L0705:
                for st in trig:
                    st.alive, st.end, st.end_t = False, 'ASIA_BREAK', cj
                continue
            active = [st.L for st in trig]
            fac = factors(day, side, active, j, by_side, crts, grid)
            sbt = int(any(st.sbt for st in trig))
            row = order_stage(day, cfg, side, j, ev, opp, active=active, cstar=cstar, score=fac['score'])
            grades = [grade_at(L, cj) for L in active]
            c = dict(design=dname, side=side, j=j, j_open=int(m5.t[j]), j_close=cj, trigger_kind=ev['kind'],
                     broken=ev['broken'][0], broken_open=int(m5.t[ev['broken'][1]]), prot=ev['prot'][0],
                     prot_open=int(m5.t[ev['prot'][1]]), Xev=ev['X'][0], X_open=int(m5.t[ev['X'][1]]),
                     start_bar_trigger=sbt, active=active, grades=grades,
                     choch_open=(';'.join(str(int(m5.t[x])) for x in sorted({st.choch for st in trig}))
                                 if cfg['trig'] == 'R1' else None),
                     **fac)
            c['order'] = row
            cands.append(c)
            for st in trig:
                st.grade_trig = st.grade_trig or str(grade_at(st.L, cj))
                if row['status'] == 'ARMED':
                    st.alive, st.end, st.end_t = False, 'ARMED', row['tau']
                elif row['status'] == 'POI_FAILED':
                    st.alive, st.end, st.end_t = False, 'POI_FAILED', row['tau']
                else:
                    st.breaks.append(row['status'])
        for st in S:
            if st.alive:
                st.alive, st.end, st.end_t = False, 'NO_BREAK', day.NY12
            setups_out.append(st)
    cands.sort(key=lambda c: (c['j'], c['side']))
    return cands, setups_out


def run_c1(day, dname, cfg, W, locs, grid='utc'):
    """C1 and its variants: every BOS in the window; a short needs a long location started on D that FAILED at or
    before close(j) (NO_FAIL otherwise; C1-ANY needs none)."""
    m5 = day.m5
    cands = []
    for ev in W.events:
        if ev['kind'] != 'BOS':
            continue
        j = ev['j']
        cj = int(m5.e[j])
        if not (day.L0705 <= cj <= day.NY12):
            continue
        side = 'L' if ev['dir'] == 'UP' else 'S'
        oside = 'S' if side == 'L' else 'L'
        failed = [L for L in locs if L.side == oside and L.status == 'STARTED' and failed_by(L, cj)]
        F3, F4, bs, w3, hb = bias_tags(day, side, cj, grid)
        last = max(failed, key=lambda L: (L.fT, L.id)) if failed else None
        c = dict(design=dname, side=side, j=j, j_open=int(m5.t[j]), j_close=cj, trigger_kind='BOS',
                 broken=ev['broken'][0], broken_open=int(m5.t[ev['broken'][1]]), prot=ev['prot'][0],
                 prot_open=int(m5.t[ev['prot'][1]]), Xev=ev['X'][0], X_open=int(m5.t[ev['X'][1]]),
                 F3=F3, F4=F4, bias_state=bs, w3=w3, h4b=hb, n_failed=len(failed),
                 failed_kind=last.kind if last else '', failed_tf=(last.tf or '') if last else '',
                 failed_utc=last.fT if last else None, failed_id=last.id if last else '')
        if not failed and not cfg['c1any']:
            c['order'] = dict(status='NO_FAIL')
        else:
            opp = [L for L in locs if L.side == oside]
            c['order'] = order_stage(day, cfg, side, j, ev, opp)
        cands.append(c)
    return cands


def run_k1(day, dname, cfg, crts, locs):
    """K1: entry at the sweep candle's close. Decision time close(c1), from 07:05 London to 12:00 New York."""
    out = []
    for c in crts:
        if not (day.L0705 <= c['close'] <= day.NY12):
            continue
        long_ = c['side'] == 'L'
        sg = 1 if long_ else -1
        Eref = c['cc1']
        S = c['W'] - BUF if long_ else c['W'] + BUF
        dref = sg * (Eref - S)
        T = c['tgt']
        row = dict(status=None, tau=c['close'], E=Eref, S0=S, S=S, d0=dref, d=dref, T=T, target_kind='CRT',
                   poi_kind='', poi_id='', poi_N=None, poi_dist=None, expiry=day.NY13)
        tgt = cfg['target']
        if tgt == 'POI':
            opp = [L for L in locs if L.side != c['side']]
            bp = next_poi(opp, c['close'], Eref, long_)
            if bp is not None:
                Tp = bp[1].N - sg * POI_OFF
                row.update(poi_kind=bp[1].kind, poi_id=bp[1].id, poi_N=bp[1].N, poi_dist=bp[0])
                if (long_ and Tp < T) or (not long_ and Tp > T):
                    T = Tp
                    row['target_kind'] = 'POI'
            row['T'] = T
        if tgt == '3R':
            row.update(T=None, target_kind='3R')         # T = F + 3d, set at the fill
        elif sg * (T - Eref) < 2 * dref:
            row['status'] = 'MIN_RR'
        if row['status'] is None:
            A = day.ctx.A
            if A is None or 60 * dref > A or A < A_MIN:
                row['status'] = 'CAP'
            else:
                row['status'] = 'ARMED'
        if row['T'] is not None and dref > 0:
            row['target_R'] = str(Fraction(sg * (row['T'] - Eref), dref))
        out.append(dict(design=dname, side=c['side'], crt=c, j_close=c['close'], order=row))
    return out


def run_k2(day, dname, cfg, W, crts, locs):
    """K2: entry by his trigger (the first UP event in the next candle's life and in the window)."""
    m5 = day.m5
    out = []
    evs = W.events
    for c in crts:
        long_ = c['side'] == 'L'
        up = 'UP' if long_ else 'DOWN'
        lo_t, hi_t = c['close'], c['close'] + c['tf']
        if hi_t <= day.L0705 or lo_t > day.NY12:
            continue
        trig = None
        for ev in evs:
            cj = int(m5.e[ev['j']])
            if ev['dir'] == up and ev['kind'] in ('CHOCH', 'BOS') and lo_t <= cj < hi_t and day.L0705 <= cj <= day.NY12:
                trig = ev
                break
        rec = dict(design=dname, side=c['side'], crt=c)
        if trig is None:
            rec.update(j_close=None, order=dict(status='NO_TRIGGER'))
            out.append(rec)
            continue
        j = trig['j']
        cj = int(m5.e[j])
        rec.update(j=j, j_open=int(m5.t[j]), j_close=cj, trigger_kind=trig['kind'], broken=trig['broken'][0],
                   prot=trig['prot'][0], prot_open=int(m5.t[trig['prot'][1]]))
        a, z = day.i1(lo_t), day.i1(cj)
        kb = day.first_le(a, z, c['W'] - 1) if long_ else day.first_ge(a, z, c['W'] + 1)
        kt = day.first_ge(a, z, c['tgt']) if long_ else day.first_le(a, z, c['tgt'])
        if kb is not None or kt is not None:
            if kt is None or (kb is not None and kb <= kt):
                rec['order'] = dict(status='CRT_BROKEN')
            else:
                rec['order'] = dict(status='TARGET_TAKEN')
            out.append(rec)
            continue
        opp = [L for L in locs if L.side != c['side']]
        rec['order'] = order_stage(day, cfg, c['side'], j, trig, opp, crt=c)
        out.append(rec)
    return out


# ================================================================ one day, every design
def run_day(day, designs=None, cstar=None, keep_states=False, tier_cs=None):
    """Every location, the walk, the CRTs and each design's setups, candidates and orders for one pair-day.
    Signal facts only: no fill, exit or R. tier_cs (ruling R4, before the A12 CUT line): also H1 and H1-N4 at each
    cut c in tier_cs, under the names tier_name(design, c) ('H1_c1', ..., 'H1-N4_c10')."""
    designs = list(designs) if designs is not None else ORDER_DESIGNS_NO_TIER
    tier_cs = list(tier_cs or [])
    sets = {}
    need = {DESIGNS[d]['locset'] for d in designs} | {'main'}
    if tier_cs:
        need |= {DESIGNS[d]['locset'] for d in TIER_DESIGNS}
    for ls in sorted(need):
        sets[ls] = build_locations(day, ls)
    W = Walk(day, keep_states=keep_states)
    res = dict(locsets=sets, walk=W, designs={})
    for d in designs:
        cfg = DESIGNS[d]
        locs, crts, _ = sets[cfg['locset']]
        grid = 'ny4' if cfg['locset'] == 'n4' else 'utc'
        if cfg['fam'] == 'R':
            cands, sets_ = run_reversal(day, d, cfg, W, locs, crts, cstar=cstar, grid=grid)
            res['designs'][d] = dict(cands=cands, setups=sets_)
        elif cfg['fam'] == 'C':
            res['designs'][d] = dict(cands=run_c1(day, d, cfg, W, locs, grid), setups=[])
        elif cfg['fam'] == 'K1':
            res['designs'][d] = dict(cands=run_k1(day, d, cfg, crts, locs), setups=[])
        else:
            res['designs'][d] = dict(cands=run_k2(day, d, cfg, W, crts, locs), setups=[])
    for d in (TIER_DESIGNS if tier_cs else []):
        cfg = DESIGNS[d]
        locs, crts, _ = sets[cfg['locset']]
        grid = 'ny4' if cfg['locset'] == 'n4' else 'utc'
        for c in tier_cs:
            nm = tier_name(d, c)
            cands, sets_ = run_reversal(day, nm, cfg, W, locs, crts, cstar=c, grid=grid)
            res['designs'][nm] = dict(cands=cands, setups=sets_)
    return res


# ================================================================ rows (CSV)
def fv(v):
    if v is None:
        return ''
    if isinstance(v, bool):
        return '1' if v else '0'
    if isinstance(v, (int, np.integer)):
        return str(int(v))
    if isinstance(v, Fraction):
        return str(v)
    return str(v)


LOC_COLS = ['pair', 'date', 'set', 'side', 'kind', 'grp', 'tf', 'id', 'lo', 'hi', 'N', 'Fr', 'edge', 'known_utc',
            'start_utc', 'status', 'age_s', 'g2_utc', 'fail_utc', 'n', 'x']
WALK_COLS = ['pair', 'date', 'type', 'j_open', 'j_close', 'close', 'dir', 'kind', 'broken', 'broken_open', 'prot',
             'prot_open', 'X', 'X_open', 'leg', 'leg_open']
CRT_COLS = ['pair', 'date', 'set', 'kind', 'side', 'c0_open', 'c1_open', 'c1_close', 'lvl', 'tgt', 'W', 'c_c1',
            'sweep_utc', 'id']
CAND_COLS = ['pair', 'date', 'design', 'side', 'j_open', 'j_close', 'trigger_kind', 'broken', 'broken_open', 'prot',
             'prot_open', 'Xev', 'X_open', 'choch_open', 'start_bar_trigger', 'n_active', 'active_ids', 'kinds',
             'grps', 'tfs', 'ages', 'starts', 'grades', 'max_tf', 'max_age_s', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6',
             'F7', 'F8', 'F9', 'f1_kind', 'score', 'bias_state', 'w3', 'h4b', 'n_failed', 'failed_kind', 'failed_tf',
             'failed_utc', 'failed_id', 'crt_id', 'crt_tf', 'crt_c1_close', 'crt_W', 'crt_lvl', 'crt_tgt', 'crt_cc1']
ORDER_COLS = ['pair', 'date', 'design', 'side', 'j_open', 'j_close', 'crt_id', 'status', 'ob_open', 'tau', 'X',
              'zone_kind', 'zone_lo', 'zone_hi', 'zone_c3', 'sync', 'n_gaps', 'E', 'S0', 'd0', 'd', 'S', 'T',
              'target_kind', 'target_R', 'poi_kind', 'poi_id', 'poi_N', 'poi_dist', 'poi_R', 'expiry', 'score']
SETUP_COLS = ['pair', 'date', 'design', 'side', 'loc_id', 'kind', 'start_utc', 'start_bar_open', 'end', 'end_utc',
              'grade_at_trigger', 'n_breaks_no_order', 'breaks']


def loc_rows(pair, D, setname, locs, aggregate_gone=True):
    rows = []
    gone = {}
    for L in locs:
        if aggregate_gone and L.status == 'GONE':
            k = (L.side, L.kind)
            gone[k] = gone.get(k, 0) + 1
            continue
        x = ';'.join('%s=%s' % (k, fv(L.x[k])) for k in sorted(L.x) if k not in ('id',)) if L.grp != 'CRT' else L.x.get('id', '')
        rows.append([pair, D.isoformat(), setname, L.side, L.kind, L.grp, fv(L.tf), L.id, L.lo, L.hi, L.N, L.Fr,
                     L.edge, L.known, fv(L.s), L.status, fv(L.age), fv(L.g2), fv(L.fT), 1, x])
    for (side, kind), n in sorted(gone.items()):
        rows.append([pair, D.isoformat(), setname, side, kind, '', '', '', '', '', '', '', '', '', '', 'GONE', '', '',
                     '', n, ''])
    return [[fv(v) for v in r] for r in rows]


def walk_rows(pair, D, day, W):
    m5 = day.m5
    rows = []
    for e in W.events:
        rows.append([pair, D.isoformat(), 'EV', int(m5.t[e['j']]), int(m5.e[e['j']]), e['close'], e['dir'], e['kind'],
                     e['broken'][0], int(m5.t[e['broken'][1]]), e['prot'][0], int(m5.t[e['prot'][1]]), e['X'][0],
                     int(m5.t[e['X'][1]]), e['leg'][0], int(m5.t[e['leg'][1]])])
    for mv in W.moves:
        rows.append([pair, D.isoformat(), 'MV', int(m5.t[mv['j']]), int(m5.e[mv['j']]), '', '', mv['which'], '', '',
                     mv['level'][0], int(m5.t[mv['level'][1]]), '', '', '', ''])
    rows.sort(key=lambda r: (r[4], r[2]))
    return [[fv(v) for v in r] for r in rows]


def crt_rows(pair, D, setname, crts):
    return [[fv(v) for v in [pair, D.isoformat(), setname, c['kind'], c['side'], c['c0'], c['c1'], c['close'], c['lvl'],
                             c['tgt'], c['W'], c['cc1'], c['sweep'], c['id']]] for c in crts]


def cand_row(pair, D, c):
    act = c.get('active') or []
    crt = c.get('crt')
    r = dict(pair=pair, date=D.isoformat(), design=c['design'], side=c['side'], j_open=c.get('j_open'),
             j_close=c.get('j_close'), trigger_kind=c.get('trigger_kind', ''), broken=c.get('broken'),
             broken_open=c.get('broken_open'), prot=c.get('prot'), prot_open=c.get('prot_open'), Xev=c.get('Xev'),
             X_open=c.get('X_open'), choch_open=c.get('choch_open'), start_bar_trigger=c.get('start_bar_trigger'),
             n_active=len(act) if act else None, active_ids=';'.join(L.id for L in act),
             kinds=';'.join(L.kind for L in act), grps=';'.join(L.grp for L in act),
             tfs=';'.join(fv(L.tf) for L in act), ages=';'.join(fv(L.age) for L in act),
             starts=';'.join(fv(L.s) for L in act), grades=';'.join(str(g) for g in c.get('grades', [])),
             max_tf=(max((L.tf for L in act if L.is_zone), default=None)) if act else None,
             max_age_s=(max((L.age for L in act if L.is_zone), default=None)) if act else None)
    for k in ('F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'f1_kind', 'score', 'bias_state', 'w3', 'h4b',
              'n_failed', 'failed_kind', 'failed_tf', 'failed_utc', 'failed_id'):
        r[k] = c.get(k)
    if crt is not None:
        r.update(crt_id=crt['id'], crt_tf=crt['tf'], crt_c1_close=crt['close'], crt_W=crt['W'], crt_lvl=crt['lvl'],
                 crt_tgt=crt['tgt'], crt_cc1=crt['cc1'])
    return [fv(r.get(k)) for k in CAND_COLS]


def order_row(pair, D, c):
    o = c['order']
    crt = c.get('crt')
    r = dict(pair=pair, date=D.isoformat(), design=c['design'], side=c['side'], j_open=c.get('j_open'),
             j_close=c.get('j_close'), crt_id=crt['id'] if crt else '', score=c.get('score'))
    r.update(o)
    return [fv(r.get(k)) for k in ORDER_COLS]


def setup_row(pair, D, dname, st, m5):
    L = st.L
    return [fv(v) for v in [pair, D.isoformat(), dname, L.side, L.id, L.kind, L.s, int(m5.t[st.jstart]), st.end,
                            st.end_t, st.grade_trig, len(st.breaks), ';'.join(st.breaks)]]


# ================================================================ the H1 cut and SIZED tiers (A12.5)
def cut_cstar(scores):
    """c* from the SCOREs of DISCOVER R1 ARMED candidates: s_c = share with SCORE >= c (c = 1..10); among
    0.10 <= s_c <= 0.50 the c whose s_c is closest to 1/3 (ties: the larger c). Exact fractions. None if none."""
    n = len(scores)
    if n == 0:
        return None, {}
    sh = {c: Fraction(sum(1 for s in scores if s >= c), n) for c in range(1, 11)}
    ok = [c for c in range(1, 11) if Fraction(1, 10) <= sh[c] <= Fraction(1, 2)]
    if not ok:
        return None, sh
    best = min(ok, key=lambda c: (abs(sh[c] - Fraction(1, 3)), -c))
    return best, sh


def cut_clo(scores, cstar):
    """c_lo = the c in 0..9 whose share with SCORE <= c is closest to 1/3 (ties: the smaller c), at most c* - 1."""
    n = len(scores)
    if n == 0 or cstar is None:
        return None
    cs = [c for c in range(0, 10) if c <= cstar - 1]
    if not cs:
        return None
    sh = {c: Fraction(sum(1 for s in scores if s <= c), n) for c in cs}
    return min(cs, key=lambda c: (abs(sh[c] - Fraction(1, 3)), c))


def sized_weight(score, clo, cstar):
    if score >= cstar:
        return Fraction(3, 2)
    if score <= clo:
        return Fraction(1, 2)
    return Fraction(1)


def family_exits(placed, cstar):
    """A12.5: which primaries leave their family (DISCOVER placed orders below the minimum, or no c*)."""
    need = {'R1': 330, 'R2': 330, 'C1': 330, 'K2': 330, 'K1': 200, 'H1': 130}
    out = {}
    for d in PRIMARIES:
        n = placed.get(d, 0)
        out[d] = (n < need[d]) or (d == 'H1' and cstar is None)
    fam = {'1': [d for d in FAMILY1 if not out[d]], '2': [d for d in FAMILY2 if not out[d]]}
    return out, fam


# ================================================================ order path and costs (A12.2.6)
def make_quotes(case, mids, data_q=None, med_spread=None):
    """Quotes of a cost case from M1 mids (dict o,h,l,c) and the data's quotes. Returns (Q, scale): Q holds integer
    arrays of the quotes times `scale` (scale = 1 except owner_shaped)."""
    c = COSTS[case]
    Q = {}
    if c['quotes'] == 'half':
        for f in 'ohlc':
            Q['bid_' + f] = mids[f] - c['half']
            Q['ask_' + f] = mids[f] + c['half']
        return Q, 1
    if c['quotes'] == 'data':
        return {k: data_q[k] for k in DA.QFIELDS}, 1
    if c['quotes'] == 'double':
        for f in 'ohlc':
            b, a = data_q['bid_' + f], data_q['ask_' + f]
            Q['bid_' + f] = (3 * b - a) // 2
            Q['ask_' + f] = (3 * a - b) // 2
            assert np.all(3 * b - a == 2 * Q['bid_' + f])
        return Q, 1
    # owner shaped: half' = (ask - bid) / 2 x (8 / med); with med = p / q: scale every price by p
    med = Fraction(med_spread)
    p, qd = med.numerator, med.denominator
    for f in 'ohlc':
        b, a = data_q['bid_' + f], data_q['ask_' + f]
        m = (b + a) // 2
        assert np.all(b + a == 2 * m)
        Q['bid_' + f] = p * m - 4 * qd * (a - b)
        Q['ask_' + f] = p * m + 4 * qd * (a - b)
    return Q, p


def _exits(Q, long_, S, T, j0, j1):
    """stop first, then target, from bar j0 to j1 (exclusive); else the close of the last bar (j1 - 1)"""
    if j1 > j0:
        if long_:
            st = Q['bid_l'][j0:j1] <= S
            tg = Q['bid_h'][j0:j1] >= T
        else:
            st = Q['ask_h'][j0:j1] >= S
            tg = Q['ask_l'][j0:j1] <= T
        hit = st | tg
        i = int(np.argmax(hit))
        if hit[i]:
            j = j0 + i
            if st[i]:
                o = int(Q['bid_o'][j] if long_ else Q['ask_o'][j])
                return 'STOP', j, (min(S, o) if long_ else max(S, o))
            return 'TARGET', j, T
    jl = j1 - 1
    return 'TIME', jl, int(Q['bid_c'][jl] if long_ else Q['ask_c'][jl])


def _exits_be(Q, long_, S, T, F, d, j0, j1):
    """BE2: as _exits, but once a bar reaches F + 2d (bid high; short: ask low <= F - 2d) the stop moves to F from
    the next bar on (that bar is judged with the old stop first)."""
    Sx = S
    for j in range(j0, j1):
        if long_:
            if Q['bid_l'][j] <= Sx:
                return 'STOP', j, min(Sx, int(Q['bid_o'][j]))
            if Q['bid_h'][j] >= T:
                return 'TARGET', j, T
            if Q['bid_h'][j] >= F + 2 * d:
                Sx = max(Sx, F)
        else:
            if Q['ask_h'][j] >= Sx:
                return 'STOP', j, max(Sx, int(Q['ask_o'][j]))
            if Q['ask_l'][j] <= T:
                return 'TARGET', j, T
            if Q['ask_l'][j] <= F - 2 * d:
                Sx = min(Sx, F)
    jl = j1 - 1
    return 'TIME', jl, int(Q['bid_c'][jl] if long_ else Q['ask_c'][jl])


def path(t1, Q, o, mode='a12', scale=1, be=False):
    """One placed order through the path (A12.2.6). o: side ('L'/'S'), E, S, T, d (units), tau (live from), expiry X,
    ny17, fail_end (CANCEL_FAILED time or None); reset mode (K8/K9's own, check 1(c)) also S0, floor, k (target R).
    Prices in o are in units; Q is scaled by `scale`. Returns dict: filled, market, fill_i, F, d, S, T, end_kind,
    end_utc, end_known, exit, exit_i, raw (unscaled Fractions)."""
    long_ = o['side'] == 'L'
    sg = 1 if long_ else -1
    E, S, T, d = (Fraction(o[k]) * scale for k in ('E', 'S', 'T', 'd'))
    j0 = int(np.searchsorted(t1, o['tau']))
    stop_t = o['expiry'] if o.get('fail_end') is None else min(o['expiry'], o['fail_end'])
    jX = int(np.searchsorted(t1, stop_t))
    jend = int(np.searchsorted(t1, o['ny17']))
    endk_none = 'CANCEL_FAILED' if (o.get('fail_end') is not None and o['fail_end'] < o['expiry']) else 'EXPIRED'
    res = dict(filled=False, market=False)
    if j0 >= jX:
        res.update(end_kind=endk_none, end_utc=stop_t, end_known=stop_t)
        return res
    oo_bid, oo_ask = Q['bid_o'][j0], Q['ask_o'][j0]
    if mode == 'a12':
        if (long_ and oo_bid <= S) or (not long_ and oo_ask >= S):
            res.update(end_kind='VOID_GAP', end_utc=int(t1[j0]), end_known=int(t1[j0]) + 60)
            return res
    first_o = int(oo_ask if long_ else oo_bid)
    if (long_ and first_o <= E) or (not long_ and first_o >= E):
        F = Fraction(first_o)
        if mode == 'reset':
            d0 = sg * (F - Fraction(o['S0']) * scale)
            d = max(d0, Fraction(o['floor']) * scale)
            S, T = F - sg * d, F + sg * Fraction(o.get('k', 3)) * d
        kind, je, raw = (_exits_be(Q, long_, S, T, F, d, j0, jend) if be else _exits(Q, long_, S, T, j0, jend))
        res.update(filled=True, market=True, fill_i=j0, F=F, d=d, S=S, T=T, exit=kind, exit_i=je, raw=Fraction(raw),
                   end_kind='FILLED', end_utc=int(t1[j0]), end_known=int(t1[j0]) + 60)
        return _unscale(res, scale)
    if long_:
        fill = Q['ask_l'][j0:jX] <= E - TICK * scale
        canc = Q['bid_h'][j0:jX] >= T
    else:
        fill = Q['bid_h'][j0:jX] >= E + TICK * scale
        canc = Q['ask_l'][j0:jX] <= T
    hit = fill | canc
    i = int(np.argmax(hit))
    if not hit[i]:
        res.update(end_kind=endk_none, end_utc=stop_t, end_known=stop_t)
        return res
    j = j0 + i
    if not fill[i]:
        res.update(end_kind='CANCEL_TARGET', end_utc=int(t1[j]), end_known=int(t1[j]) + 60)
        return res
    st = (Q['bid_l'][j] <= S) if long_ else (Q['ask_h'][j] >= S)
    if st:
        oo = int(Q['bid_o'][j] if long_ else Q['ask_o'][j])
        res.update(filled=True, fill_i=j, F=E, d=d, S=S, T=T, exit='STOP', exit_i=j,
                   raw=Fraction(min(S, oo) if long_ else max(S, oo)), end_kind='FILLED', end_utc=int(t1[j]),
                   end_known=int(t1[j]) + 60)
        return _unscale(res, scale)
    tg = (Q['bid_h'][j] >= T) if long_ else (Q['ask_l'][j] <= T)
    if tg:
        res.update(end_kind='CANCEL_FILLBAR', end_utc=int(t1[j]), end_known=int(t1[j]) + 60)
        return res
    kind, je, raw = (_exits_be(Q, long_, S, T, E, d, j + 1, jend) if be else _exits(Q, long_, S, T, j + 1, jend))
    if je < j:
        je, raw = j, int(Q['bid_c'][j] if long_ else Q['ask_c'][j])
    res.update(filled=True, fill_i=j, F=E, d=d, S=S, T=T, exit=kind, exit_i=je, raw=Fraction(raw), end_kind='FILLED',
               end_utc=int(t1[j]), end_known=int(t1[j]) + 60)
    return _unscale(res, scale)


def _unscale(res, scale):
    if scale != 1:
        for k in ('F', 'd', 'S', 'T', 'raw'):
            if k in res and res[k] is not None:
                res[k] = Fraction(res[k]) / scale
    return res


def market_path(t1, Q, o, scale=1, crt_3r=False):
    """K1 (and R1-MKT): a market entry at F = the ask open (short: bid open) of the first M1 bar opening at or after
    o['tau'] and before 13:00 New York; VOID if that bar's bid open is at or beyond S; no trade if F is at or beyond T;
    d = F - S; exits from the fill bar. crt_3r: T = F + 3d (K1-3R)."""
    long_ = o['side'] == 'L'
    sg = 1 if long_ else -1
    S = Fraction(o['S']) * scale
    j0 = int(np.searchsorted(t1, o['tau']))
    jX = int(np.searchsorted(t1, o['ny13']))
    jend = int(np.searchsorted(t1, o['ny17']))
    if j0 >= jX:
        return dict(filled=False, market=True, end_kind='NO_FILL_BAR', end_utc=o['ny13'], end_known=o['ny13'])
    bo, ao = int(Q['bid_o'][j0]), int(Q['ask_o'][j0])
    if (long_ and bo <= S) or (not long_ and ao >= S):
        return dict(filled=False, market=True, end_kind='VOID_GAP', end_utc=int(t1[j0]), end_known=int(t1[j0]) + 60)
    F = Fraction(ao if long_ else bo)
    d = sg * (F - S)
    T = F + sg * 3 * d if crt_3r else Fraction(o['T']) * scale
    if (long_ and F >= T) or (not long_ and F <= T):
        return dict(filled=False, market=True, end_kind='NO_TRADE', end_utc=int(t1[j0]), end_known=int(t1[j0]) + 60)
    kind, je, raw = _exits(Q, long_, S, T, j0, jend)
    res = dict(filled=True, market=True, fill_i=j0, F=F, d=d, S=S, T=T, exit=kind, exit_i=je, raw=Fraction(raw),
               end_kind='FILLED', end_utc=int(t1[j0]), end_known=int(t1[j0]) + 60)
    return _unscale(res, scale)


def net_pips_units(res, long_, case):
    """net units: (exit - F) for a long ((F - exit) for a short) less the case's commission, market-entry slippage
    and stop or 17:00 slippage (A12.2.6, K10). R = net / d."""
    c = COSTS[case]
    gross = (res['raw'] - res['F']) if long_ else (res['F'] - res['raw'])
    slip_in = c['mkt'] if res['market'] else 0
    slip_out = c['stop'] if res['exit'] == 'STOP' else (c['time'] if res['exit'] == 'TIME' else 0)
    return Fraction(gross) - c['comm'] - slip_in - slip_out


def direction_pair(t1, Q, side, fill_i, d, ny17, case, scale=1):
    """K13 direction test for one fill: at the close of the fill bar, A (the trade's side) and B (the other) at market
    (short at that bar's bid close, long at its ask close), stop d and target 3d from its own entry, exits from the next
    bar, the case's costs as market entries. Returns (A_R, B_R)."""
    jend = int(np.searchsorted(t1, ny17))
    out = []
    dd = Fraction(d) * scale
    for s in (side, 'S' if side == 'L' else 'L'):
        long_ = s == 'L'
        sg = 1 if long_ else -1
        F = Fraction(int(Q['ask_c'][fill_i] if long_ else Q['bid_c'][fill_i]))
        S, T = F - sg * dd, F + sg * 3 * dd
        kind, je, raw = _exits(Q, long_, S, T, fill_i + 1, jend)
        if je < fill_i:
            je, raw = fill_i, int(Q['bid_c'][fill_i] if long_ else Q['ask_c'][fill_i])
        r = dict(raw=Fraction(raw) / scale, F=F / scale, market=True, exit=kind)
        out.append(net_pips_units(r, long_, case) / Fraction(d))
    return out[0], out[1]


# ================================================================ sequences (A12.2.7)
TIER_CS = list(range(1, 11))          # ruling R4: H1 and H1-N4 rows for every c = 1..10 before the A12 CUT line


def tier_name(design, c):
    """the name of a tier design's run at cut c (ruling R4): 'H1_c3', 'H1-N4_c3'"""
    return '%s_c%d' % (design, c)


def base_design(name):
    """the DESIGNS key of a design name ('H1_c3' -> 'H1'); other names are returned as they are"""
    if name in DESIGNS:
        return name
    b, sep, c = name.rpartition('_c')
    if sep and b in DESIGNS and DESIGNS[b]['tier'] and c.isdigit():
        return b
    return name


def seq_items(design, cands, day):
    """ARMED orders of one design and pair-day, as sequence items in order of tau (K1/K2: a 4h CRT before a 1h CRT
    at the same tau)."""
    bd = base_design(design)
    fam = DESIGNS[bd]['fam'] if bd in DESIGNS else None
    items = []
    for c in cands:
        o = c['order']
        if o.get('status') != 'ARMED':
            continue
        crt = c.get('crt')
        if fam == 'K1':
            tau, jo = crt['close'], crt['close']
        else:
            tau, jo = o['tau'], c['j_open']
        fail_end = None
        if fam == 'R':
            fts = [L.fT for L in c['active']]
            if fts and all(x is not None for x in fts):
                fail_end = max(fts)
        items.append(dict(design=design, fam=fam, side=c['side'], tau=tau, j_open=jo, cand=c, order=o,
                          tf=(crt['tf'] if crt else 0), fail_end=fail_end))
    items.sort(key=lambda it: (it['tau'], -it['tf'], it['side']))
    return items


def run_order(day, it, Q, scale=1, mode='a12', mkt=False, be=False):
    o = it['order']
    if it['fam'] == 'K1':
        crt_3r = DESIGNS[base_design(it['design'])]['target'] == '3R'
        return market_path(day.t1, Q, dict(side=it['side'], S=o['S'], T=o['T'] if o['T'] is not None else 0,
                                           tau=it['tau'], ny13=day.NY13, ny17=day.NY17), scale, crt_3r=crt_3r)
    if mkt:
        return market_path(day.t1, Q, dict(side=it['side'], S=o['S'], T=o['T'], tau=o['tau'], ny13=day.NY13,
                                           ny17=day.NY17), scale)
    return path(day.t1, Q, dict(side=it['side'], E=o['E'], S=o['S'], T=o['T'], d=o['d'], tau=o['tau'],
                                expiry=o['expiry'], ny17=day.NY17, fail_end=it['fail_end']), mode=mode, scale=scale, be=be)


def sequence_day(day, items, Q, scale=1, mkt=False, place=False):
    """A12.2.7 on one pair-day: one order at a time (a candidate whose break bar opens before the live order ends is
    ORDER_LIVE; K1: whose c1 closes before it ends), one fill per side and London day (AFTER_FILL). Q = the owner
    quotes. place=True: the placement-only path (fill status, fill bar and end; no exit is computed; A12.5, ruling
    R5). Returns [(item, status, path result or None)]."""
    out = []
    live_end = None
    filled = set()
    for it in items:
        if live_end is not None and it['j_open'] < live_end:
            out.append((it, 'ORDER_LIVE', None))
            continue
        if it['side'] in filled:
            out.append((it, 'AFTER_FILL', None))
            continue
        r = place_order(day, it, Q, scale, mkt=mkt) if place else run_order(day, it, Q, scale, mkt=mkt)
        live_end = r['end_utc']
        if r['filled']:
            filled.add(it['side'])
        out.append((it, 'PLACED', r))
    return out


# ---------------------------------------------------------------- placement only (A12.5, ruling R5)
def place_path(t1, Q, o, scale=1):
    """The K8/K9 path of `path` (mode a12) up to the order's end, and nothing after it: whether it filled, its fill
    bar, its end kind and end time (A12.2.7's Ends). No exit is searched. Same inputs as `path`."""
    long_ = o['side'] == 'L'
    E, S, T = (Fraction(o[k]) * scale for k in ('E', 'S', 'T'))
    j0 = int(np.searchsorted(t1, o['tau']))
    stop_t = o['expiry'] if o.get('fail_end') is None else min(o['expiry'], o['fail_end'])
    jX = int(np.searchsorted(t1, stop_t))
    endk_none = 'CANCEL_FAILED' if (o.get('fail_end') is not None and o['fail_end'] < o['expiry']) else 'EXPIRED'
    res = dict(filled=False, market=False)
    if j0 >= jX:
        res.update(end_kind=endk_none, end_utc=stop_t, end_known=stop_t)
        return res
    oo_bid, oo_ask = Q['bid_o'][j0], Q['ask_o'][j0]
    if (long_ and oo_bid <= S) or (not long_ and oo_ask >= S):
        res.update(end_kind='VOID_GAP', end_utc=int(t1[j0]), end_known=int(t1[j0]) + 60)
        return res
    first_o = int(oo_ask if long_ else oo_bid)
    if (long_ and first_o <= E) or (not long_ and first_o >= E):
        res.update(filled=True, market=True, fill_i=j0, end_kind='FILLED', end_utc=int(t1[j0]),
                   end_known=int(t1[j0]) + 60)
        return res
    if long_:
        fill = Q['ask_l'][j0:jX] <= E - TICK * scale
        canc = Q['bid_h'][j0:jX] >= T
    else:
        fill = Q['bid_h'][j0:jX] >= E + TICK * scale
        canc = Q['ask_l'][j0:jX] <= T
    hit = fill | canc
    i = int(np.argmax(hit))
    if not hit[i]:
        res.update(end_kind=endk_none, end_utc=stop_t, end_known=stop_t)
        return res
    j = j0 + i
    if not fill[i]:
        res.update(end_kind='CANCEL_TARGET', end_utc=int(t1[j]), end_known=int(t1[j]) + 60)
        return res
    # K8 on the fill bar: S reached -> a fill (it stands); else T reached -> CANCEL_FILLBAR; else a fill
    s_hit = (Q['bid_l'][j] <= S) if long_ else (Q['ask_h'][j] >= S)
    t_hit = (Q['bid_h'][j] >= T) if long_ else (Q['ask_l'][j] <= T)
    if t_hit and not s_hit:
        res.update(end_kind='CANCEL_FILLBAR', end_utc=int(t1[j]), end_known=int(t1[j]) + 60)
        return res
    res.update(filled=True, fill_i=j, end_kind='FILLED', end_utc=int(t1[j]), end_known=int(t1[j]) + 60)
    return res


def place_market(t1, Q, o, scale=1, crt_3r=False):
    """`market_path` up to the order's end (K1, R1-MKT): VOID_GAP, NO_FILL_BAR, NO_TRADE (F at or beyond T) or the
    fill at the first M1 bar at or after tau. No exit is searched."""
    long_ = o['side'] == 'L'
    sg = 1 if long_ else -1
    S = Fraction(o['S']) * scale
    j0 = int(np.searchsorted(t1, o['tau']))
    jX = int(np.searchsorted(t1, o['ny13']))
    if j0 >= jX:
        return dict(filled=False, market=True, end_kind='NO_FILL_BAR', end_utc=o['ny13'], end_known=o['ny13'])
    bo, ao = int(Q['bid_o'][j0]), int(Q['ask_o'][j0])
    if (long_ and bo <= S) or (not long_ and ao >= S):
        return dict(filled=False, market=True, end_kind='VOID_GAP', end_utc=int(t1[j0]), end_known=int(t1[j0]) + 60)
    F = Fraction(ao if long_ else bo)
    d = sg * (F - S)
    T = F + sg * 3 * d if crt_3r else Fraction(o['T']) * scale
    if (long_ and F >= T) or (not long_ and F <= T):
        return dict(filled=False, market=True, end_kind='NO_TRADE', end_utc=int(t1[j0]), end_known=int(t1[j0]) + 60)
    return dict(filled=True, market=True, fill_i=j0, end_kind='FILLED', end_utc=int(t1[j0]), end_known=int(t1[j0]) + 60)


def place_order(day, it, Q, scale=1, mkt=False):
    """`run_order`'s order through the placement-only path"""
    o = it['order']
    if it['fam'] == 'K1':
        crt_3r = DESIGNS[base_design(it['design'])]['target'] == '3R'
        return place_market(day.t1, Q, dict(side=it['side'], S=o['S'], T=o['T'] if o['T'] is not None else 0,
                                            tau=it['tau'], ny13=day.NY13, ny17=day.NY17), scale, crt_3r=crt_3r)
    if mkt:
        return place_market(day.t1, Q, dict(side=it['side'], S=o['S'], T=o['T'], tau=o['tau'], ny13=day.NY13,
                                            ny17=day.NY17), scale)
    return place_path(day.t1, Q, dict(side=it['side'], E=o['E'], S=o['S'], T=o['T'], d=o['d'], tau=o['tau'],
                                      expiry=o['expiry'], ny17=day.NY17, fail_end=it['fail_end']), scale)


def _stop_first(Q, long_, S, T, j0, j1):
    """the first M1 bar in [j0, j1) reaching S or T: its index if it reaches S (stop first on a bar reaching both),
    else None. Used only by RE2's placement, which needs the stop-out (A12.4)."""
    if j1 <= j0:
        return None
    st = (Q['bid_l'][j0:j1] <= S) if long_ else (Q['ask_h'][j0:j1] >= S)
    tg = (Q['bid_h'][j0:j1] >= T) if long_ else (Q['ask_l'][j0:j1] <= T)
    hit = st | tg
    i = int(np.argmax(hit))
    return j0 + i if (hit[i] and st[i]) else None


def stop_out_time(day, it, Q, pres, scale=1):
    """RE2's placement (A12.4: 'after a stop-out ... the next ARMED candidate whose j opens after the stop exit'):
    the open time of the M1 bar where a filled limit order (R1, C1) is stopped, else None, exactly as `path` would
    exit it (stop first on the fill bar, then from the next bar; a first-bar market fill from its own bar). Kept in
    memory only: no exit kind, time or price is written (A12.5, ruling R5)."""
    assert it['fam'] in ('R', 'C') and pres['filled']
    o = it['order']
    long_ = it['side'] == 'L'
    S, T = Fraction(o['S']) * scale, Fraction(o['T']) * scale
    jend = int(np.searchsorted(day.t1, day.NY17))
    j = pres['fill_i']
    if pres['market']:
        k = _stop_first(Q, long_, S, T, j, jend)
    else:
        if (Q['bid_l'][j] <= S) if long_ else (Q['ask_h'][j] >= S):
            return int(day.t1[j])
        k = _stop_first(Q, long_, S, T, j + 1, jend)
    return None if k is None else int(day.t1[k])


def place_day(day, res, Q, scale=1):
    """Ruling R5 / A12.5: every design's sequence of one pair-day on owner quotes, plus R1-MKT and BOOK, with the
    placement-only path. Returns ({sequence name: [(item, status, placement result or None)]}, {design: items})."""
    items = {d: seq_items(d, r['cands'], day) for d, r in res['designs'].items()}
    seqs = {d: sequence_day(day, its, Q, scale, place=True) for d, its in items.items()}
    if 'R1' in items:
        seqs['R1-MKT'] = sequence_day(day, items['R1'], Q, scale, mkt=True, place=True)
    if 'R1' in items and 'C1' in items:
        bk = sorted(items['R1'] + items['C1'], key=lambda it: (it['tau'], ['R1', 'C1'].index(it['design'])))
        seqs['BOOK'] = sequence_day(day, bk, Q, scale, place=True)
    return seqs, items


def place_re2(date_items, Qs, days):
    """R1-RE2 and C1-RE2 placement for one London date (both pairs in one time order). date_items: {pair: {design:
    items}}; Qs: {pair: owner Q}; days: {pair: day}. Returns {pair: {'R1-RE2': [...], 'C1-RE2': [...]}}."""
    out = {}
    for d in ('R1', 'C1'):
        di = {p: (days[p], date_items[p][d]) for p in PAIRS if p in date_items and d in date_items[p]}
        if not di:
            continue
        for p, lst in sequence_re2(di, {p: Qs[p] for p in di}, place=True).items():
            out.setdefault(p, {})[d + '-RE2'] = lst
    return out


PLACE_COLS = ['pair', 'date', 'seq_design', 'design', 'n', 'side', 'j_open', 'j_close', 'tau', 'crt_id', 'crt_tf',
              'status', 'filled', 'fill_utc', 'end_utc', 'end_kind']
PLACE_FORBIDDEN = ('exit', 'exit_i', 'raw', 'F', 'net', 'R')


def place_rows(pair, D, seqname, lst, t1):
    """placement rows (ruling R5): the sequence status (PLACED, ORDER_LIVE, AFTER_FILL; RE2 also TWO_LOSSES), and for
    a placed order whether it filled, its fill time (the fill bar's open), its end time and its end (A12.2.7's Ends:
    FILLED, EXPIRED, CANCEL_TARGET, CANCEL_FILLBAR, CANCEL_FAILED, VOID_GAP; market entries NO_TRADE, NO_FILL_BAR).
    Never an exit kind, exit time, exit price or R."""
    rows = []
    for n, (it, status, r) in enumerate(lst, 1):
        c = it['cand']
        crt = c.get('crt')
        row = dict(pair=pair, date=D.isoformat(), seq_design=seqname, design=it['design'], n=n, side=it['side'],
                   j_open=c.get('j_open'), j_close=c.get('j_close'), tau=it['tau'], crt_id=crt['id'] if crt else '',
                   crt_tf=crt['tf'] if crt else '', status=status)
        if r is not None:
            assert not any(k in r for k in PLACE_FORBIDDEN), 'a placement result holds an exit field'
            row.update(filled=int(bool(r['filled'])), fill_utc=int(t1[r['fill_i']]) if r['filled'] else None,
                       end_utc=r['end_utc'], end_kind=r['end_kind'])
        rows.append([fv(row.get(k)) for k in PLACE_COLS])
    return rows


def sequence_re2(days_items, Qs, place=False):
    """RE2 (information): both pairs in one time order (EUR/USD first on ties) per London date; after a stop-out the
    pair may take one more fill on that side (a candidate whose j opens after the stop exit); after 2 stop-outs across
    both pairs that day neither pair takes a new order (TWO_LOSSES). Ruling R11: a stop-out counts toward the second
    trade and toward the 2-loss stop when its exit M1 bar opens strictly before the candidate's j opens; ORDER_LIVE is
    tested first. days_items: {pair: (day, items)}; Qs: {pair: Q}.
    place=True: the placement-only path, with the stop-out found by `stop_out_time` (kept in memory, never returned).
    Returns {pair: [(item, status, res)]}."""
    allit = []
    for pi, pair in enumerate(PAIRS):
        if pair not in days_items:
            continue
        day, items = days_items[pair]
        for it in items:
            allit.append((it['tau'], pi, it['tf'] * -1, it['side'], pair, it))
    allit.sort(key=lambda x: x[:4])
    st = {p: dict(live_end=None, fills={'L': 0, 'S': 0}, stopped_at={'L': None, 'S': None}, done={'L': False, 'S': False})
          for p in days_items}
    stops = []                                    # stop exit M1 bars' open times, across both pairs (ruling R11)
    out = {p: [] for p in days_items}
    for _, _, _, _, pair, it in allit:
        day = days_items[pair][0]
        s = st[pair]
        side = it['side']
        if s['live_end'] is not None and it['j_open'] < s['live_end']:
            out[pair].append((it, 'ORDER_LIVE', None))
            continue
        if len([x for x in stops if x < it['j_open']]) >= 2:          # ruling R11: exit bar opens before j opens
            out[pair].append((it, 'TWO_LOSSES', None))
            continue
        if s['done'][side]:
            out[pair].append((it, 'AFTER_FILL', None))
            continue
        if s['fills'][side] == 1:
            sa = s['stopped_at'][side]
            if sa is None or it['j_open'] <= sa:
                out[pair].append((it, 'AFTER_FILL', None))
                continue
        if place:
            r = place_order(day, it, Qs[pair])
            te = stop_out_time(day, it, Qs[pair], r) if r['filled'] else None
        else:
            r = run_order(day, it, Qs[pair])
            te = int(day.t1[r['exit_i']]) if (r['filled'] and r['exit'] == 'STOP') else None
        s['live_end'] = r['end_utc']
        if r['filled']:
            s['fills'][side] += 1
            if te is not None:
                s['stopped_at'][side] = te
                stops.append(te)
                if s['fills'][side] >= 2:
                    s['done'][side] = True
            else:
                s['done'][side] = True
        out[pair].append((it, 'PLACED', r))
    return out


# ================================================================ outcomes (A12.6): built here, run only by the gated
# `run_a12.py <stage> outcomes` (never in the build step; unit-tested on typed bars)
TRADE_COLS = ['pair', 'date', 'design', 'seq', 'side', 'score', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9',
              'f1_kind', 'bias_state', 'grade', 'failed_kind', 'failed_utc', 'kinds', 'max_tf', 'max_age_s',
              'trigger_kind', 'start_bar_trigger', 'zone_kind', 'sync', 'target_kind', 'target_R', 'crt_tf',
              'cost_case', 'filled', 'fill_utc', 'fill_px', 'exit', 'exit_utc', 'exit_px', 'net_pips', 'd', 'd0',
              'net_R', 'A_net_R', 'B_net_R', 'market', 'end_utc', 'end_kind', 'tau', 'j_close', 'E', 'S', 'T']


def spread_medians(u, days):
    """the median 07:00-12:00 London standard spread (ask_c - bid_c of the M1 bars opening in [07:00, 12:00) London)
    per London year over the given A12 days, in units (an exact Fraction)"""
    out = {}
    by = {}
    for D in days:
        a, b = int(np.searchsorted(u['t1'], DA.lon(D, 7))), int(np.searchsorted(u['t1'], DA.lon(D, 12)))
        by.setdefault(D.year, []).append(u['ask_c'][a:b] - u['bid_c'][a:b])
    for y, parts in by.items():
        s = np.sort(np.concatenate(parts))
        n = len(s)
        out[y] = Fraction(int(s[n // 2])) if n % 2 else Fraction(int(s[n // 2 - 1]) + int(s[n // 2]), 2)
    return out


def day_quotes(day, med_spread=None):
    mids = dict(o=day.mo, h=day.mh, l=day.ml, c=day.mc)
    out = {}
    for case in COST_ORDER:
        if case == 'owner_shaped' and med_spread is None:
            continue
        out[case] = make_quotes(case, mids, day.q, med_spread)
    return out


def _cand_tags(c):
    act = c.get('active') or []
    crt = c.get('crt')
    o = c['order']
    grades = c.get('grades') or []
    return dict(score=c.get('score'), **{('F%d' % i): c.get('F%d' % i) for i in range(1, 10)},
                f1_kind=c.get('f1_kind', ''), bias_state=c.get('bias_state', ''),
                grade=(min(grades) if grades and all(g in (1, 2) for g in grades) else ''),
                failed_kind=c.get('failed_kind', ''), failed_utc=c.get('failed_utc'),
                kinds=';'.join(L.kind for L in act), max_tf=max((L.tf for L in act if L.is_zone), default=None),
                max_age_s=max((L.age for L in act if L.is_zone), default=None),
                trigger_kind=c.get('trigger_kind', ''), start_bar_trigger=c.get('start_bar_trigger'),
                zone_kind=o.get('zone_kind', ''), sync=o.get('sync', ''), target_kind=o.get('target_kind', ''),
                target_R=o.get('target_R'), crt_tf=crt['tf'] if crt else None, tau=o.get('tau', crt['close'] if crt else None),
                j_close=c.get('j_close'), E=o.get('E'), S=o.get('S'), T=o.get('T'), d0=o.get('d0'))


def trade_rows(pair, D, day, design, placed, Qs, mkt=False, be=False):
    """one row per placed order and cost case (A12.6). placed: [(item, 'PLACED', owner path result)]; every other
    cost case re-runs the same order on its quotes (L6: arming once). A and B: the direction test (K13)."""
    rows = []
    for n, (it, status, r_own) in enumerate(placed, 1):
        tags = _cand_tags(it['cand'])
        long_ = it['side'] == 'L'
        for case, (Q, sc) in Qs.items():
            if case == 'owner' and not be:
                r = r_own
            else:
                r = run_order(day, it, Q, sc, mkt=mkt, be=be)
            row = dict(pair=pair, date=D.isoformat(), design=design, seq=n, side=it['side'], cost_case=case,
                       filled=int(bool(r['filled'])), market=int(bool(r.get('market'))), end_utc=r['end_utc'],
                       end_kind=r['end_kind'])
            row.update(tags)
            if r['filled']:
                net = net_pips_units(r, long_, case)
                Ra, Rb = direction_pair(day.t1, Q, it['side'], r['fill_i'], r['d'], day.NY17, case, sc)
                row.update(fill_utc=int(day.t1[r['fill_i']]), fill_px=r['F'], exit=r['exit'],
                           exit_utc=int(day.t1[r['exit_i']]), exit_px=r['raw'], net_pips=net / PIP, d=r['d'],
                           net_R=net / r['d'], A_net_R=Ra, B_net_R=Rb)
            rows.append([fv(row.get(k)) for k in TRADE_COLS])
    return rows


def outcomes_pair_day(pair, D, day, res, Qs, designs):
    """the sequences of one pair-day on owner quotes and the trades of every placed order in each cost case.
    Returns ({design: [(item, status, res)]}, {design: trade rows}). RE2 runs across both pairs (outcomes_re2)."""
    seqs, trades = {}, {}
    items = {d: seq_items(d, res['designs'][d]['cands'], day) for d in designs if d in res['designs']}
    Qo, so = Qs['owner']
    for d, its in items.items():
        seqs[d] = sequence_day(day, its, Qo, so)
        trades[d] = trade_rows(pair, D, day, d, [x for x in seqs[d] if x[1] == 'PLACED'], Qs)
    if 'R1' in items:
        mk = sequence_day(day, items['R1'], Qo, so, mkt=True)
        seqs['R1-MKT'] = mk
        trades['R1-MKT'] = trade_rows(pair, D, day, 'R1-MKT', [x for x in mk if x[1] == 'PLACED'], Qs, mkt=True)
    if 'R1' in items and 'C1' in items:
        bk = sorted(items['R1'] + items['C1'], key=lambda it: (it['tau'], ['R1', 'C1'].index(it['design'])))
        seqs['BOOK'] = sequence_day(day, bk, Qo, so)
        trades['BOOK'] = trade_rows(pair, D, day, 'BOOK', [x for x in seqs['BOOK'] if x[1] == 'PLACED'], Qs)
    for d in ('R1', 'C1'):
        if d in seqs:
            trades[d + '-BE2'] = trade_rows(pair, D, day, d + '-BE2', [x for x in seqs[d] if x[1] == 'PLACED'], Qs,
                                            be=True)
    return seqs, trades, items


def outcomes_re2(date_items, Qs_by_pair, days_by_pair, D):
    """R1-RE2 and C1-RE2 for one London date: both pairs in one time order; trades of every placed order"""
    out = {}
    for d in ('R1', 'C1'):
        di = {p: (days_by_pair[p], date_items[p][d]) for p in date_items if d in date_items[p]}
        if not di:
            continue
        qo = {p: Qs_by_pair[p]['owner'][0] for p in di}
        seq = sequence_re2(di, qo)
        for p, lst in seq.items():
            out.setdefault(p, {})[d + '-RE2'] = (lst, trade_rows(p, D, days_by_pair[p], d + '-RE2',
                                                                 [x for x in lst if x[1] == 'PLACED'], Qs_by_pair[p]))
    return out
