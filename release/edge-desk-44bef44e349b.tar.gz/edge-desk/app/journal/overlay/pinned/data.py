"""Engine A: data loading (Run 1 rows only), cleaning (K2), prices (K1), clocks and days (K4).

Run 1 reads only rows with ts_utc < 1451606400 (2016-01-01 00:00 UTC). The price arrays are streamed from the
.npz members and only their first n values are decoded, so the later rows' prices are never read into memory.
"""
import datetime as dt
import hashlib
import io
import zipfile
from zoneinfo import ZoneInfo

import numpy as np

from engine import Series, DayCtx

LON = ZoneInfo('Europe/London')
NYZ = ZoneInfo('America/New_York')
CUT_RUN1 = 1451606400            # 2016-01-01 00:00 UTC
QFIELDS = ['bid_o', 'bid_h', 'bid_l', 'bid_c', 'ask_o', 'ask_h', 'ask_l', 'ask_c']
PAIRS = {'EUR_USD': 'EURUSD_M1_BUILD.npz', 'GBP_USD': 'GBPUSD_M1_BUILD.npz'}
HOLIDAY_MD = {(12, 24), (12, 25), (12, 26), (12, 31), (1, 1)}
RULES_SHA = 'eab205048990dc3e666ec8573f2c4ca512f1381e23ba1e75ee96d22fb8629ea3'   # after L1-L9 (L9 reporting only)
V2X_SHA = '5cd789932a3df9849a807d28616b2e50eb15fff3ae1ebfb53d66921c1b7365ac'     # marc_rules/V2X_SPEC.md with A1
V2X_SHA_FIRST = 'fe2d747d3d57bcfdc4bfef083f852598fdddd56801f24ca25302cd904d66d26a'   # the first run's spec ...
V2X_FIRST_BYTES = 5489                         # ... = the amended file's first 5,489 bytes (A1 is a pure append)
EXCL_SHA = '6ea962065439586f71fd87c6dd7e438230911cb154f1ed4fc25d51ecaffc0ccb'


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


# ---------------------------------------------------------------- loading
def _read_member(zf, name, nrows=None):
    with zf.open(name) as f:
        ver = np.lib.format.read_magic(f)
        if ver == (1, 0):
            shape, fortran, dtype = np.lib.format.read_array_header_1_0(f)
        else:
            shape, fortran, dtype = np.lib.format.read_array_header_2_0(f)
        assert len(shape) == 1 and not fortran, (name, shape, fortran)
        n = shape[0] if nrows is None else nrows
        assert n <= shape[0]
        buf = f.read(n * dtype.itemsize)       # streamed: only the first n values are decompressed
        assert len(buf) == n * dtype.itemsize
        return np.frombuffer(buf, dtype).copy(), shape[0]


def manifest_rows(manifest, fname, cut=CUT_RUN1):
    """(n, last_ts): the number of leading BUILD rows of fname before cut and the last one's ts_utc, from
    DATA_MANIFEST.json's source parts (in time order), so that no row at or after the cut is decoded (CHECK.md
    finding 1). Refuses unless the parts are in order, split exactly at the cut and add up to the file's rows."""
    import json
    m = json.load(open(manifest))
    hit = [v for v in m['pairs'].values() if v['output']['path'].rsplit('/', 1)[-1] == fname]
    assert len(hit) == 1, fname
    src = hit[0]['sources']
    assert sum(s['kept_build_rows'] for s in src) == hit[0]['output']['rows']
    n, last, prev = 0, None, None
    for s in src:
        assert prev is None or s['first_kept_ts'] > prev
        prev = s['last_kept_ts']
        if s['last_kept_ts'] < cut:
            n, last = n + s['kept_build_rows'], s['last_kept_ts']
        else:
            assert s['first_kept_ts'] >= cut, 'a manifest part spans the cut'
    assert n > 0
    return n, last


def load_run1(path, cut=CUT_RUN1, nrows=None, last_ts=None):
    """Rows with ts_utc < cut only (Run 1). Returns dict of arrays (float prices, int volume).
    nrows/last_ts (from manifest_rows): decode only the first nrows time stamps too, and assert the last one is
    last_ts (< cut). Without them (synthetic tests) the whole ts_utc member is decoded to find the cut."""
    with zipfile.ZipFile(path) as zf:
        if nrows is None:
            ts_all, n_all = _read_member(zf, 'ts_utc.npy')
            n = int(np.count_nonzero(ts_all < cut))
            assert np.all(ts_all[:n] < cut), 'rows before the cut are not a prefix'
            ts = ts_all[:n].copy()
            del ts_all
        else:
            ts, n_all = _read_member(zf, 'ts_utc.npy', nrows=nrows)
            n = nrows
            assert int(ts[-1]) == last_ts and last_ts < cut and np.all(ts < cut), 'manifest row count is wrong'
        out = {'ts_utc': ts}
        for k in QFIELDS + ['volume']:
            a, tot = _read_member(zf, k + '.npy', nrows=n)
            assert tot == n_all
            out[k] = a
    assert len(out['ts_utc']) == n and int(out['ts_utc'].max()) < cut     # Run 1 rows only (asserted)
    for k in QFIELDS + ['volume']:
        assert len(out[k]) == n
    return out


# ---------------------------------------------------------------- clocks (K4)
def lon(d, hh, mm=0):
    """unix time of London clock time hh:mm on date d"""
    return int(dt.datetime(d.year, d.month, d.day, hh, mm, tzinfo=LON).timestamp())


def nyt(d, hh, mm=0):
    return int(dt.datetime(d.year, d.month, d.day, hh, mm, tzinfo=NYZ).timestamp())


def lon_date(ts):
    return dt.datetime.fromtimestamp(int(ts), LON).date()


def london_dates_of(ts):
    """London calendar date ordinal for each unix time (vectorised through a boundary table)."""
    d0 = lon_date(int(ts.min())) - dt.timedelta(days=1)
    d1 = lon_date(int(ts.max())) + dt.timedelta(days=1)
    days = [d0 + dt.timedelta(days=i) for i in range((d1 - d0).days + 1)]
    bounds = np.array([lon(d, 0) for d in days], np.int64)
    pos = np.searchsorted(bounds, ts, side='right') - 1
    ords = np.array([d.toordinal() for d in days], np.int64)
    return ords[pos]


# ---------------------------------------------------------------- cleaning (K2) and prices (K1)
def clean(raw):
    """K2 steps 1-4. Returns (cleaned dict, report). Report counts by UTC year of the row, and the 2% check of
    step 5 over rows opening 07:00-11:00 London on London weekdays, by London year."""
    ts = raw['ts_utc']
    assert np.all(np.diff(ts) > 0), 'ts_utc not strictly increasing'          # step 1
    assert np.all(ts % 60 == 0), 'ts_utc not on whole minutes'
    P = np.stack([raw[k] for k in QFIELDS])
    nan = np.isnan(P).any(axis=0)                                              # step 2
    filler = (~nan & (raw['volume'] <= 0)                                     # step 3
              & (raw['bid_o'] == raw['bid_h']) & (raw['bid_o'] == raw['bid_l']) & (raw['bid_o'] == raw['bid_c'])
              & (raw['ask_o'] == raw['ask_h']) & (raw['ask_o'] == raw['ask_l']) & (raw['ask_o'] == raw['ask_c']))
    drop = nan | filler
    yr = _utc_years(ts)
    rep = {'rows_loaded': int(len(ts)), 'rows_dropped_nan': int(nan.sum()), 'rows_dropped_filler': int(filler.sum()),
           'by_utc_year': {}}
    for y in np.unique(yr):
        m = yr == y
        rep['by_utc_year'][int(y)] = {'rows': int(m.sum()), 'nan': int((nan & m).sum()),
                                      'filler': int((filler & m).sum())}
    # step 5 check
    lo_ord = london_dates_of(ts)
    lo_wd = (lo_ord + 6) % 7          # date.fromordinal(o).weekday() == (o + 6) % 7
    tod = _london_minute_of_day(ts, lo_ord)
    win = (lo_wd < 5) & (tod >= 7 * 60) & (tod < 11 * 60)
    uo, inv = np.unique(lo_ord, return_inverse=True)
    lyr = np.array([dt.date.fromordinal(int(o)).year for o in uo], np.int64)[inv]
    rep['window_0700_1100_by_london_year'] = {}
    rep['stop_2pct'] = False
    for y in np.unique(lyr):
        m = win & (lyr == y)
        tot, dr = int(m.sum()), int((m & drop).sum())
        frac = dr / tot if tot else 0.0
        rep['window_0700_1100_by_london_year'][int(y)] = {'rows': tot, 'dropped': dr, 'frac': frac}
        if frac > 0.02:
            rep['stop_2pct'] = True
    keep = ~drop
    out = {k: raw[k][keep] for k in ['ts_utc'] + QFIELDS + ['volume']}
    return out, rep


def _utc_years(ts):
    y0 = dt.datetime.fromtimestamp(int(ts.min()), dt.timezone.utc).year
    y1 = dt.datetime.fromtimestamp(int(ts.max()), dt.timezone.utc).year
    bounds = np.array([int(dt.datetime(y, 1, 1, tzinfo=dt.timezone.utc).timestamp()) for y in range(y0, y1 + 2)])
    return np.arange(y0, y1 + 2)[np.searchsorted(bounds, ts, side='right') - 1]


def _london_minute_of_day(ts, lo_ord):
    u, inv = np.unique(lo_ord, return_inverse=True)
    mid = np.array([lon(dt.date.fromordinal(int(o)), 0) for o in u], np.int64)
    return (ts - mid[inv]) // 60


def to_units(c):
    """K1: q = round(price * 100000), stop if |price * 1e5 - q| > 0.05; units = 4 q (bid/ask), mid = 2 (bid_q+ask_q)."""
    q = {}
    worst = 0.0
    for k in QFIELDS:
        x = c[k] * 100000.0
        r = np.rint(x)
        if len(x):
            worst = max(worst, float(np.abs(x - r).max()))
        q[k] = r.astype(np.int64)
    if worst > 0.05:
        raise SystemExit('K1 stop: a price is %.4f points away from a whole point' % worst)
    u = {'t1': c['ts_utc'].astype(np.int64)}
    for k in QFIELDS:
        u[k] = 4 * q[k]
    for f in 'ohlc':
        u['m' + f] = 2 * (q['bid_' + f] + q['ask_' + f])
    u['_k1_worst'] = worst
    return u


# ---------------------------------------------------------------- the pair's data and its days (K4)
class PairData:
    """Cleaned unit arrays of one pair, with builders for the series and for each day's context."""

    def __init__(self, u):
        self.u = u
        self.t1 = u['t1']

    def rows(self, t_from=None, t_to=None):
        a = 0 if t_from is None else int(np.searchsorted(self.t1, t_from))
        b = len(self.t1) if t_to is None else int(np.searchsorted(self.t1, t_to))
        return a, b

    def series(self, a=0, b=None, shift=None):
        """Series from rows [a, b). shift: optional (row_lo, row_hi, units array) added to all 8 prices
        (scrambled-future test, K14); mids are rebuilt from the shifted quotes."""
        b = len(self.t1) if b is None else b
        u = self.u
        quotes = {k: u[k][a:b] for k in ['bid_o', 'bid_h', 'bid_l', 'bid_c', 'ask_o', 'ask_h', 'ask_l', 'ask_c']}
        mids = {f: u['m' + f][a:b] for f in 'ohlc'}
        if shift is not None:
            s_lo, s_hi, s = shift
            quotes = {k: v.copy() for k, v in quotes.items()}
            for k in quotes:
                quotes[k][s_lo - a:s_hi - a] += s
            mids = {f: (quotes['bid_' + f] + quotes['ask_' + f]) // 2 for f in 'ohlc'}   # 2(bq+aq) = (4bq+4aq)/2
        return Series(u['t1'][a:b], mids['o'], mids['h'], mids['l'], mids['c'], quotes=quotes)


class DayTable:
    """New York days of a series (K4): named N, holding M1 bars opening in [17:00 NY on N-1, 17:00 NY on N)."""

    def __init__(self, S):
        t1 = S.t1
        d0 = dt.datetime.fromtimestamp(int(t1[0]), NYZ).date() - dt.timedelta(days=2)
        d1 = dt.datetime.fromtimestamp(int(t1[-1]), NYZ).date() + dt.timedelta(days=3)
        self.names = [d0 + dt.timedelta(days=i) for i in range((d1 - d0).days + 1)]
        self.start = np.array([nyt(d - dt.timedelta(days=1), 17) for d in self.names], np.int64)
        pos = np.searchsorted(self.start, t1, side='right') - 1
        n = len(self.names)
        self.count = np.bincount(pos, minlength=n)
        hi = np.full(n, np.iinfo(np.int64).min)
        lo = np.full(n, np.iinfo(np.int64).max)
        np.maximum.at(hi, pos, S.mh)
        np.minimum.at(lo, pos, S.ml)
        self.hi, self.lo = hi, lo
        # v2x W3: the day's mid close = mid close of its last M1 bar (t1 is sorted, so pos is non-decreasing)
        last = np.searchsorted(pos, np.arange(n), side='right') - 1
        cl = np.full(n, np.iinfo(np.int64).min)
        has = self.count > 0
        cl[has] = S.mc[last[has]]
        self.close = cl
        wd = np.array([d.weekday() for d in self.names])
        md = [(d.month, d.day) for d in self.names]
        self.complete = (wd < 5) & np.array([m not in {(12, 25), (1, 1)} for m in md]) & (self.count >= 1000)
        self.ci = np.flatnonzero(self.complete)
        self.ords = np.array([d.toordinal() for d in self.names], np.int64)

    def before(self, D):
        """indices of complete NY days named before D (in time order)"""
        p = int(np.searchsorted(self.ords[self.ci], D.toordinal()))
        return self.ci[:p]


def make_ctx(D, table):
    """DayCtx for London date D: clocks, PDH/PDL of the most recent complete NY day before D, ADR20 sum A (K4)."""
    L = lambda hh, mm=0, _D=D: lon(_D, hh, mm)
    ny_start = nyt(D - dt.timedelta(days=1), 17)
    ny_end = nyt(D, 17)
    # K4: 17:00 New York is 21:00 or 22:00 London on every day used
    assert ny_end - lon(D, 0) in (21 * 3600, 22 * 3600), D
    assert ny_start - lon(D - dt.timedelta(days=1), 0) in (21 * 3600, 22 * 3600), D
    prev = table.before(D)
    ctx = DayCtx(date=D, L=L, ny_start=ny_start, ny_end=ny_end)
    ctx.n_complete = len(prev)
    if len(prev):
        p = prev[-1]
        ctx.PDH, ctx.PDL = int(table.hi[p]), int(table.lo[p])
        ctx.pd_known = int(table.start[p + 1])          # 17:00 NY at the end of that day
    if len(prev) >= 20:
        last = prev[-20:]
        ctx.A = int((table.hi[last] - table.lo[last]).sum())
    # v2x W3 daily bias: D1 = the most recent complete New York day named before D, D2 = the complete one before it
    if len(prev) >= 2:
        p1, p2 = prev[-1], prev[-2]
        ctx.D1 = (int(table.hi[p1]), int(table.lo[p1]), int(table.close[p1]))
        ctx.D2 = (int(table.hi[p2]), int(table.lo[p2]), int(table.close[p2]))
    return ctx


def gap_ok(S, D, upto=(11, 0)):
    """K4 gap test: open times of the M1 bars in [00:00, 11:00) London, with 23:59 London of the day before at the
    start and 11:00 at the end; fail if two neighbours are more than 16 minutes apart."""
    a0, a1 = lon(D, 0), lon(D, *upto)
    i, j = int(np.searchsorted(S.t1, a0)), int(np.searchsorted(S.t1, a1))
    pts = np.r_[a0 - 60, S.t1[i:j], a1]
    return bool(np.all(np.diff(pts) <= 16 * 60))


def read_excluded(path):
    """K4: lines not starting with '#', stripped, empty skipped; 180 unique dates; sha256 checked."""
    assert sha256(path) == EXCL_SHA, 'EXCLUDE_DATES.txt sha256 differs'
    out = []
    for line in open(path):
        if line.startswith('#'):
            continue
        s = line.strip()
        if s:
            out.append(dt.date.fromisoformat(s))
    assert len(out) == 180 and len(set(out)) == 180
    return set(out)


def eligibility(S, table, D, excluded):
    """(eligible, first failing reason) in the order WARMUP, GAP, BLIND, HOLIDAY (section 0, K4)."""
    reasons = []
    if len(table.before(D)) < 20:
        reasons.append('WARMUP')
    if not gap_ok(S, D):
        reasons.append('GAP')
    if D in excluded:
        reasons.append('BLIND')
    if (D.month, D.day) in HOLIDAY_MD:
        reasons.append('HOLIDAY')
    return (not reasons), reasons


def weekdays(d0, d1):
    out, d = [], d0
    while d <= d1:
        if d.weekday() < 5:
            out.append(d)
        d += dt.timedelta(days=1)
    return out
