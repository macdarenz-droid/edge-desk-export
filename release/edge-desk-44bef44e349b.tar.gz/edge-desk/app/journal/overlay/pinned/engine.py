"""Engine v2x: a copy of engine A for marc_rules/RULES_v1.md, extended with marc_rules/V2X_SPEC.md's designs
(w1, w1h, w2, w2h, baseh) and its amendment A1 (w1h4, w2h4, baseh4: daily + 4h bias). Engine A's rules and code
paths are unchanged; the new rules are added beside them.

Everything here uses only bars up to the decision time of each rule (the order bar's close; V2: close(t0)+60 s;
V3: its own order bar's close). Trade outcomes (K8-K10, the direction test) live in outcomes.py.

Prices are whole numbers of quarter-point units (K1): 1 pip = 40 units, a mid is 2*(bid_q + ask_q).
E can be a half unit only under the entry25/entry75 stability settings (K12); E, S0, S, T, d0, d are kept as exact
Fractions and never rounded.
"""
from dataclasses import dataclass
from fractions import Fraction
import numpy as np

# ---------------------------------------------------------------- constants in units (K1)
PIP = 40
TICK = 4            # 0.1 pip (3.1 limit fill)
TT = 20             # 0.5 pip trade-through (K5)
FVG_MIN = 40        # 1.0 pip (K7)
EQ_MAX = 80         # 2.0 pips (K5)
BUF = 40            # 1.0 pip stop buffer (3.2)
FLOOR = 320         # 8 pips floor (3.2)
H12 = 12 * 3600     # EQ 12 h window (K5)


# ---------------------------------------------------------------- rules (K11, K12)
@dataclass(frozen=True)
class Rule:
    name: str
    kind: str = 'base'          # base | V2 | V3 | V4 | V5 | V6 (V1 is base with use_s3=False)
    use_s3: bool = True         # V1 drops S3 (K11)
    tt: int = TT                # trade-through (K12 tt0.3 / tt0.7)
    buf: int = BUF              # stop buffer (K12 buf0.5 / buf1.5)
    floor: int = FLOOR          # stop floor (K12 floor6 / floor10), also the "ADR20/3 >= floor" check
    f: Fraction = Fraction(1, 2)  # entry fraction into the zone (K12 entry25 / entry75)
    deadline: tuple = (10, 0)   # last signal-bar close, London (K12 deadline0930 / deadline1030)
    expiry: tuple = (11, 0)     # order expiry, London
    w1: bool = False            # V2X W1: wick-only sweep check on the signal
    hf: bool = False            # V2X W3: daily + 1h bias filter on each order
    hb: int = 3600              # V2X: the bias bar of the hf filter, in seconds: 3600 (W3, 1h) or 14400 (A1, 4h)


RULES = [
    Rule('base'),
    Rule('V1', use_s3=False),
    Rule('V2', kind='V2'),
    Rule('V3', kind='V3'),
    Rule('V4', kind='V4'),
    Rule('V5', kind='V5'),
    Rule('V6', kind='V6'),
    # K12 stability settings (base only, one number changed each)
    Rule('floor6', floor=240),
    Rule('floor10', floor=400),
    Rule('buf0.5', buf=20),
    Rule('buf1.5', buf=60),
    Rule('entry25', f=Fraction(1, 4)),
    Rule('entry75', f=Fraction(3, 4)),
    Rule('deadline0930', deadline=(9, 30), expiry=(10, 30)),
    Rule('deadline1030', deadline=(10, 30), expiry=(11, 30)),
    Rule('tt0.3', tt=12),
    Rule('tt0.7', tt=28),
]
RULE_NAMES = [r.name for r in RULES]
RULE_BY_NAME = {r.name: r for r in RULES}
VARIANT_NAMES = ['base', 'V1', 'V2', 'V3', 'V4', 'V5', 'V6']

# V2X_SPEC.md designs (run beside the base; engine A's 17 rules above are untouched)
NEW_RULES = [
    Rule('w1', w1=True),                 # W1: wick-only sweep, otherwise the v1 base
    Rule('w1h', w1=True, hf=True),       # W1 + W3 filter
    Rule('w2', kind='W2'),               # W2: breakout, then retest or chase
    Rule('w2h', kind='W2', hf=True),     # W2 + W3 filter
    Rule('baseh', hf=True),              # the v1 base + W3 filter
    # V2X_SPEC.md amendment A1: W3's daily bias plus a 4h bias (last 3 complete H4 mid bars on the UTC clock)
    Rule('w1h4', w1=True, hf=True, hb=14400),     # W1 + H4 filter
    Rule('w2h4', kind='W2', hf=True, hb=14400),   # W2 + H4 filter
    Rule('baseh4', hf=True, hb=14400),            # the v1 base + H4 filter
]
A1_NAMES = ['w1h4', 'w2h4', 'baseh4']
NEW_NAMES = [r.name for r in NEW_RULES]
V2X_RULES = [RULE_BY_NAME['base']] + NEW_RULES
V2X_NAMES = [r.name for r in V2X_RULES]
RULE_BY_NAME.update({r.name: r for r in NEW_RULES})
CHASE_END = (10, 55)    # W2: a 1m sweep bar s must open before 10:55 London

COLUMNS = ['pair', 'date', 'rule', 'eligible', 'status', 'side', 't0_close_utc', 'live_from_utc', 'pool', 'P', 'X',
           'REF', 'zone', 'zone_lo', 'zone_hi', 'E', 'S0', 'S', 'T', 'd0', 'd']
FIELDS = COLUMNS[4:]
# v2x columns, appended: W3 bias values at the order time, and W2's chase order (c_*). For W2 rows the A columns hold
# the breakout and the retest order: t0_close_utc = close(b), pool/P = the broken pool, E = P, live_from = close(b).
EXTRA = ['bias_daily', 'bias_h1', 'c_status', 'c_sweep_utc', 'c_live_from_utc', 'c_E', 'c_S0', 'c_S', 'c_T', 'c_d0',
         'c_d', 'c_bias_h1', 'bias_h4', 'c_bias_h4']
V2X_COLUMNS = COLUMNS + EXTRA
V2X_FIELDS = FIELDS + EXTRA
C_FIELDS = [k for k in EXTRA if k.startswith('c_')]


# ---------------------------------------------------------------- bar series (K3)
def build_m5(t1, mo, mh, ml, mc):
    """M5 bars on the UTC grid from M1 mid bars: one bar per 5-minute slot that holds at least one M1 bar (K3)."""
    slot = t1 // 300
    if len(t1) == 0:
        e = np.zeros(0, np.int64)
        return e, e, e, e, e, e
    start = np.flatnonzero(np.r_[True, slot[1:] != slot[:-1]])
    end = np.r_[start[1:], len(t1)] - 1
    t5 = slot[start] * 300
    o5 = mo[start]
    h5 = np.maximum.reduceat(mh, start)
    l5 = np.minimum.reduceat(ml, start)
    c5 = mc[end]
    m1_to_m5 = np.cumsum(np.r_[True, slot[1:] != slot[:-1]]) - 1
    return t5, o5, h5, l5, c5, m1_to_m5


def find_swings(h, l):
    """Swing high at i: h[i] > h[i-1], h[i] > h[i-2], h[i] >= h[i+1], h[i] >= h[i+2]; low mirrors (K3, 0)."""
    n = len(h)
    if n < 5:
        e = np.zeros(0, np.int64)
        return e, e
    c = slice(2, n - 2)
    hi = (h[c] > h[1:n - 3]) & (h[c] > h[0:n - 4]) & (h[c] >= h[3:n - 1]) & (h[c] >= h[4:n])
    lo = (l[c] < l[1:n - 3]) & (l[c] < l[0:n - 4]) & (l[c] <= l[3:n - 1]) & (l[c] <= l[4:n])
    return np.flatnonzero(hi) + 2, np.flatnonzero(lo) + 2


def find_eq(sw, ext, high):
    """Equal highs/lows (K5): neighbouring swings (i, j) in the full swing series, |ext(i) - ext(j)| <= 2.0 pips,
    no M5 high strictly between them above max(...) (lows: no low below min(...)). Level = max (lows: min).
    Returns arrays (level, i, j). Known at close(j+2); P candidate only if open(i) >= tt - 12 h."""
    if len(sw) < 2:
        e = np.zeros(0, np.int64)
        return e, e, e
    i, j = sw[:-1], sw[1:]
    vi, vj = ext[i], ext[j]
    assert np.all(j - i >= 3)          # two swings of one kind are always >= 3 bars apart
    idx = np.empty(2 * len(i), np.int64)
    idx[0::2] = i + 1
    idx[1::2] = j
    if high:
        between = np.maximum.reduceat(ext, idx)[0::2]      # max over bars i+1 .. j-1
        level = np.maximum(vi, vj)
        ok = (np.abs(vi - vj) <= EQ_MAX) & (between <= level)
    else:
        between = np.minimum.reduceat(ext, idx)[0::2]
        level = np.minimum(vi, vj)
        ok = (np.abs(vi - vj) <= EQ_MAX) & (between >= level)
    return level[ok], i[ok], j[ok]


def build_h1(t1, mo, mh, ml, mc):
    """H1 bars on UTC hours from M1 mid bars and their true ranges (K3; V6). First bar: TR = high - low."""
    slot = t1 // 3600
    if len(t1) == 0:
        e = np.zeros(0, np.int64)
        return e, e
    start = np.flatnonzero(np.r_[True, slot[1:] != slot[:-1]])
    end = np.r_[start[1:], len(t1)] - 1
    th = slot[start] * 3600
    hh = np.maximum.reduceat(mh, start)
    lh = np.minimum.reduceat(ml, start)
    ch = mc[end]
    pc = np.r_[ch[0], ch[:-1]]
    tr = np.maximum(hh, pc) - np.minimum(lh, pc)
    tr[0] = hh[0] - lh[0]
    return th, tr


def build_h1_hl(t1, mh, ml):
    """H1 mid bars on UTC hours (K3): open times, highest high, lowest low (V2X W3's 1h bias)."""
    return build_hl(t1, mh, ml, 3600)


def build_hl(t1, mh, ml, sec):
    """Mid bars of sec seconds on the UTC clock (slots t // sec; H4: 00:00, 04:00, ... UTC): open times, highest
    high, lowest low. A slot with any M1 bar is a bar (as for H1, NOTES item 4)."""
    slot = t1 // sec
    if len(t1) == 0:
        e = np.zeros(0, np.int64)
        return e, e, e
    start = np.flatnonzero(np.r_[True, slot[1:] != slot[:-1]])
    return slot[start] * sec, np.maximum.reduceat(mh, start), np.minimum.reduceat(ml, start)


class Series:
    """One pair's continuous series: M1 mid (and optional bid/ask quotes), M5, swings, EQ pools, H1 (K3, K5).
    All prices are int64 units. m5 may be given (set-2 page data, built by tools.bars())."""

    def __init__(self, t1, mo, mh, ml, mc, quotes=None, m5=None):
        self.t1 = np.asarray(t1, np.int64)
        self.mo, self.mh, self.ml, self.mc = (np.asarray(x, np.int64) for x in (mo, mh, ml, mc))
        self.q = quotes                                  # dict bid_o..ask_c (units) or None
        if m5 is None:
            self.t5, self.o5, self.h5, self.l5, self.c5, self.m1_to_m5 = build_m5(self.t1, self.mo, self.mh,
                                                                                  self.ml, self.mc)
        else:
            self.t5, self.o5, self.h5, self.l5, self.c5 = (np.asarray(x, np.int64) for x in m5)
            self.m1_to_m5 = np.searchsorted(self.t5, (self.t1 // 300) * 300)
            ok = self.m1_to_m5 < len(self.t5)
            assert np.all(self.t5[self.m1_to_m5[ok]] == (self.t1[ok] // 300) * 300)
        self.e5 = self.t5 + 300                          # M5 close times
        self.sh, self.sl = find_swings(self.h5, self.l5)            # computed once on the whole series (K3)
        n5 = len(self.t5)
        self.sh_conf = self.e5[np.minimum(self.sh + 2, n5 - 1)] if n5 else self.sh
        self.sl_conf = self.e5[np.minimum(self.sl + 2, n5 - 1)] if n5 else self.sl
        lv, i, j = find_eq(self.sh, self.h5, True)
        self.eqh = dict(level=lv, i=i, j=j, known=self.e5[j + 2] if len(j) else j, open_i=self.t5[i])
        lv, i, j = find_eq(self.sl, self.l5, False)
        self.eql = dict(level=lv, i=i, j=j, known=self.e5[j + 2] if len(j) else j, open_i=self.t5[i])
        self.th1, self.tr1 = build_h1(self.t1, self.mo, self.mh, self.ml, self.mc)
        _, self.hh1, self.lh1 = build_h1_hl(self.t1, self.mh, self.ml)
        self.th4, self.hh4, self.lh4 = build_hl(self.t1, self.mh, self.ml, 14400)     # A1: H4 on the UTC clock

    # helpers
    def i1(self, t):
        """index of the first M1 bar that opens at or after t"""
        return int(np.searchsorted(self.t1, t))


@dataclass
class DayCtx:
    """What a London date D needs from the calendar and from earlier New York days (K4)."""
    date: object
    L: object               # L(hh, mm) -> unix time of that London clock time on D
    ny_start: int           # 17:00 New York on D-1 (start of the New York day named D)
    ny_end: int             # 17:00 New York on D
    PDH: object = None
    PDL: object = None
    pd_known: object = None  # end of the PDH/PDL New York day
    A: object = None         # sum of the 20 complete New York-day ranges behind ADR20 (units)
    D1: object = None        # V2X W3: (high, low, close) mid of the last complete New York day before D
    D2: object = None        # V2X W3: the same for the complete New York day before D1


# ---------------------------------------------------------------- pools (K5)
PRIO = {'AH': 0, 'AL': 0, 'PDH': 1, 'PDL': 1, 'EQH': 2, 'EQL': 2}


def first_through(S, level, high, t_from, t_to, tt):
    """K5: open time of the earliest M1 bar opening in [t_from, t_to) with mid high >= level + tt
    (low pool: mid low <= level - tt), or None."""
    a, b = S.i1(t_from), S.i1(t_to)
    if b <= a:
        return None
    hit = (S.mh[a:b] >= level + tt) if high else (S.ml[a:b] <= level - tt)
    k = int(np.argmax(hit))
    return int(S.t1[a + k]) if hit[k] else None


def day_pools(S, ctx, tt, t_end):
    """Pools of both sides for day D with their first trade-through tt (searched up to t_end), already restricted
    to those that can ever be a P candidate: tt at or after 07:00 London, and for EQ open(i) >= tt - 12 h (K5).
    Returns {'high': [(prio, name, level, tt)], 'low': [...]}, plus the Asian levels."""
    L00, L07 = ctx.L(0, 0), ctx.L(7, 0)
    a, b = S.i1(L00), S.i1(L07)
    AH = int(S.mh[a:b].max()) if b > a else None          # M1 mid bars opening 00:00-06:59 London (1)
    AL = int(S.ml[a:b].min()) if b > a else None
    out = {'high': [], 'low': []}
    base = {'high': [('AH', AH, L07), ('PDH', ctx.PDH, ctx.pd_known)],
            'low': [('AL', AL, L07), ('PDL', ctx.PDL, ctx.pd_known)]}
    for side, high in (('high', True), ('low', False)):
        for name, lv, known in base[side]:
            if lv is None or known is None:
                continue
            t = first_through(S, int(lv), high, known, t_end, tt)
            if t is not None and t >= L07:
                out[side].append((PRIO[name], name, int(lv), t))
        eq = S.eqh if high else S.eql
        # only pools whose first swing opens no earlier than 07:00 - 12 h can pass the 12 h test (tt >= 07:00)
        sel = np.flatnonzero((eq['open_i'] >= L07 - H12) & (eq['known'] < t_end))
        for n in sel:
            lv, known, oi = int(eq['level'][n]), int(eq['known'][n]), int(eq['open_i'][n])
            t = first_through(S, lv, high, known, t_end, tt)
            if t is not None and t >= L07 and oi >= t - H12:
                out[side].append((PRIO['EQH' if high else 'EQL'], 'EQH' if high else 'EQL', lv, t))
    return out, AH, AL


# ---------------------------------------------------------------- the signal (K6)
def find_signal(S, ctx, tt=TT, use_s3=True, deadline=(10, 0), w1=False):
    """First signal of the day for one pair (K6). Returns a dict with status NO_SIGNAL, BOTH_SIDES or SIGNAL.
    w1 (V2X W1): a side is a signal at t only if no M5 close from the bar of P's first trade-through to the bar
    before t is beyond P (short: every such close <= P; long: >= P). A failure is treated like an S3 failure."""
    L00, L07 = ctx.L(0, 0), ctx.L(7, 0)
    Ldl = ctx.L(*deadline)
    pools, AH, AL = day_pools(S, ctx, tt, Ldl)
    j1a, j1b = S.i1(L07), S.i1(Ldl)
    if j1b <= j1a:
        return dict(status='NO_SIGNAL', Ldl=Ldl)
    H, Lw = S.mh[j1a:j1b], S.ml[j1a:j1b]
    cmax, cmin = np.maximum.accumulate(H), np.minimum.accumulate(Lw)
    ar = np.arange(len(H))
    fmax = np.maximum.accumulate(np.where(np.r_[True, H[1:] > cmax[:-1]], ar, 0))   # earliest bar of the max
    fmin = np.maximum.accumulate(np.where(np.r_[True, Lw[1:] < cmin[:-1]], ar, 0))
    t_a = int(np.searchsorted(S.t5, L07))                       # first M5 bar opening >= 07:00 (close >= 07:05)
    t_b = int(np.searchsorted(S.e5, Ldl, side='right'))          # bars closing <= deadline
    for t in range(t_a, t_b):
        ct = int(S.e5[t])
        m = int(np.searchsorted(S.t1, ct)) - j1a                # M1 bars opening in [07:00, close(t))
        if m <= 0:
            continue
        good = []
        for side in ('sell', 'buy'):
            short = side == 'sell'
            if short:
                X, jx = int(cmax[m - 1]), j1a + int(fmax[m - 1])
            else:
                X, jx = int(cmin[m - 1]), j1a + int(fmin[m - 1])
            k = int(S.m1_to_m5[jx])
            ck = int(S.e5[k])
            # S1: P(t) = best pool first traded through in [07:00, close(k)) (K5)
            cands = [p for p in pools['high' if short else 'low'] if p[3] < ck]
            if not cands:
                continue
            if short:
                best = max(c[2] for c in cands)
            else:
                best = min(c[2] for c in cands)
            prio, pname, P, ptt = min((c for c in cands if c[2] == best), key=lambda c: (c[0], c[3]))
            # REF(t): latest swing (low for a short) with index < k, open >= 00:00 London, confirmed by close(t)
            sw, conf = (S.sl, S.sl_conf) if short else (S.sh, S.sh_conf)
            p = min(int(np.searchsorted(sw, k)), int(np.searchsorted(conf, ct, side='right'))) - 1
            if p < 0 or S.t5[sw[p]] < L00:
                continue
            ri = int(sw[p])
            REF = int(S.l5[ri] if short else S.h5[ri])
            # S2: close(t) beyond min(REF, P) strictly
            c = int(S.c5[t])
            if not (c < min(REF, P) if short else c > max(REF, P)):
                continue
            # S3: the other Asian side not traded through by M1 bars opening in [07:00, close(k))
            mk = int(np.searchsorted(S.t1, ck)) - j1a
            if use_s3:
                if short and AL is not None and int(cmin[mk - 1]) <= AL - tt:
                    continue
                if not short and AH is not None and int(cmax[mk - 1]) >= AH + tt:
                    continue
            if w1:
                ib = int(S.m1_to_m5[S.i1(ptt)])          # the M5 bar holding P's first trade-through
                if ib < t:
                    seg = S.c5[ib:t]                     # bars ib .. t-1
                    if (short and int(seg.max()) > P) or (not short and int(seg.min()) < P):
                        continue
            good.append(dict(side=side, t0=t, ct0=ct, k=k, ck=ck, X=X, xt=int(S.t1[jx]), P=P, pool=pname,
                             ptt=ptt, REF=REF, ri=ri))
        if len(good) == 2:
            return dict(status='BOTH_SIDES', t0=t, ct0=ct, Ldl=Ldl)
        if good:
            g = good[0]
            g.update(status='SIGNAL', Ldl=Ldl, AH=AH, AL=AL)
            return g
    return dict(status='NO_SIGNAL', Ldl=Ldl)


# ---------------------------------------------------------------- order bar, void, zone, S5 (K7)
def void_check(S, short, X, t_from, t_to):
    """K7: any M1 mid high > X (long: mid low < X) among M1 bars opening in [t_from, t_to)."""
    a, b = S.i1(t_from), S.i1(t_to)
    if b <= a:
        return False
    return bool(S.mh[a:b].max() > X) if short else bool(S.ml[a:b].min() < X)


def zone_fvg(S, short, c1_min, ob, cob):
    """K7 FVG: neighbouring c1, c2, c3 with index(c1) >= c1_min and index(c3) <= ob, gap >= 1.0 pip, not touched
    by an M1 mid bar opening in [close(c3), close(ob)); the latest c3 wins. Returns (lo, hi, c3) or None."""
    for c3 in range(ob, c1_min + 1, -1):
        c1 = c3 - 2
        if short:
            lo, hi = int(S.h5[c3]), int(S.l5[c1])
        else:
            lo, hi = int(S.h5[c1]), int(S.l5[c3])
        if hi - lo < FVG_MIN:
            continue
        a, b = S.i1(int(S.e5[c3])), S.i1(cob)
        if b > a:
            if short and S.mh[a:b].max() >= hi:
                continue
            if not short and S.ml[a:b].min() <= lo:
                continue
        return lo, hi, c3
    return None


def zone_ob(S, short, i_from, i_to):
    """K7 OB: scan M5 bars from i_from back to i_to (both included); first up-close bar (long: down-close).
    Zone = [low, high], wicks included, no touch test. Returns (lo, hi, bar) or None."""
    for i in range(i_from, i_to - 1, -1):
        if (short and S.c5[i] > S.o5[i]) or (not short and S.c5[i] < S.o5[i]):
            return int(S.l5[i]), int(S.h5[i]), i
    return None


def s5_pass(d0, A, floor):
    """K1/K7: 60 * d0 <= A and A >= 60 * floor (ADR20/3 >= floor; 19,200 at the 8-pip floor)."""
    return A is not None and 60 * d0 <= A and A >= 60 * floor


def entry(lo, hi, short, f):
    """3.1 / K12: E = bottom + f (top - bottom) for a short; top - f (top - bottom) for a long. Exact."""
    lo, hi = Fraction(lo), Fraction(hi)
    return lo + f * (hi - lo) if short else hi - f * (hi - lo)


def _row(**kw):
    r = {k: None for k in FIELDS}
    r.update(kw)
    return r


def _sig_fields(sig):
    return dict(side=sig['side'], t0_close_utc=sig['ct0'], pool=sig['pool'], P=sig['P'], X=sig['X'],
                REF=sig['REF'])


def order_stage(S, ctx, sig, rule, k, ref_i, ob, c1_min=None, ob_scan_to=None):
    """Void, S4 zone, S5 (and V4/V5/V6) at the close of the order bar ob (K7, K11). k/ref_i give the zone
    window: FVG c1 >= c1_min (default k), OB scan from k back to ob_scan_to (default REF's bar)."""
    short = sig['side'] == 'sell'
    sg = 1 if short else -1
    X = sig['X']
    row = _row(status=None, **_sig_fields(sig))
    cob = int(S.e5[ob])
    row['_cob'] = cob
    row['_decision'] = cob
    # (1) void (K7)
    if void_check(S, short, X, sig['ct0'], cob):
        row['status'] = 'VOID'
        return row
    # (2) S4 zone: FVG first, else OB; a chosen FVG is never swapped for the OB (K7)
    c1_min = k if c1_min is None else c1_min
    ob_scan_to = ref_i if ob_scan_to is None else ob_scan_to
    z = zone_fvg(S, short, c1_min, ob, cob)
    kind = 'FVG'
    if z is None:
        z = zone_ob(S, short, c1_min, ob_scan_to)
        kind = 'OB'
    if z is None:
        row['status'] = 'NO_ZONE'
        return row
    lo, hi, zi = z
    row['_zi'] = zi
    E = entry(lo, hi, short, rule.f)
    S0 = Fraction(X + sg * rule.buf)
    if rule.kind == 'V4':
        # K11 V4: latest swing high after k, confirmed by close(ob), strictly above the zone top (long: mirror)
        sw, conf, ext = (S.sh, S.sh_conf, S.h5) if short else (S.sl, S.sl_conf, S.l5)
        m = (sw > k) & (conf <= cob) & ((ext[sw] > hi) if short else (ext[sw] < lo))
        if m.any():
            H = int(ext[sw[np.flatnonzero(m)[-1]]])
            S0 = Fraction(H + sg * rule.buf)
    d0 = sg * (S0 - E)
    row.update(zone=kind, zone_lo=lo, zone_hi=hi, E=E, S0=S0, d0=d0)
    # (3) S5 (K1, K7)
    if not s5_pass(d0, ctx.A, rule.floor):
        row['status'] = 'S5'
        return row
    d = max(d0, Fraction(rule.floor))
    row['d'] = d
    if rule.kind == 'V5':
        # K11 V5: RT over M1 bars opening in [17:00 NY on D-1, close(ob) - 60 s]; skip if 40 d > max(800, A - 20 RT)
        a, b = S.i1(ctx.ny_start), S.i1(cob)
        RT = int(S.mh[a:b].max() - S.ml[a:b].min())
        row['_RT'] = RT
        if 40 * d > max(800, ctx.A - 20 * RT):
            row['status'] = 'V5_FILTER'
            return row
    if rule.kind == 'V6':
        # K11 V6: B = sum of the true ranges of the last 14 H1 bars with open + 60 min <= close(ob)
        m = int(np.searchsorted(S.th1 + 3600, cob, side='right'))
        assert m >= 14, 'fewer than 14 H1 bars before the order bar'
        B = int(S.tr1[m - 14:m].sum())
        row['_B'] = B
        if 1400 * d < 79 * B:
            row['status'] = 'V6_FILTER'
            return row
    if rule.hf:
        bd, bh = bias_at(S, ctx, cob, rule.hb)
        row.update(bias_daily=bd)
        row[BIAS_KEY[rule.hb]] = bh
        if not h_pass(sig['side'], bd, bh):
            row['status'] = 'H_FILTER'
            return row
    row.update(status='ARMED', live_from_utc=cob, S=E + sg * d, T=E - sg * 3 * d)
    return row


def eval_rule(S, ctx, rule, sig):
    """One row of orders_run1 for one rule (K6, K7, K11), given that rule's signal."""
    Lexp = ctx.L(*rule.expiry)
    if rule.kind == 'W2':
        return w2_row(S, ctx, rule)
    if sig['status'] == 'NO_SIGNAL':
        return _row(status='NO_SIGNAL', _decision=sig['Ldl'])
    if sig['status'] == 'BOTH_SIDES':
        return _row(status='BOTH_SIDES', t0_close_utc=sig['ct0'], _decision=sig['ct0'])
    short = sig['side'] == 'sell'
    sg = 1 if short else -1
    X, t0, k = sig['X'], sig['t0'], sig['k']
    n5 = len(S.t5)

    if rule.kind == 'V2':
        # K11 V2: market at the first M1 bar opening >= close(t0) + 60 s; base void/S4/S5 not used.
        # L5: E holds F (the fill bar's bid open; long: ask open) and the ARMED / S5 / V2_ASK_AT_S0 split uses
        # that bar's open quotes. L3: status names V2_NO_FILL_BAR and V2_ASK_AT_S0.
        row = _row(status=None, **_sig_fields(sig))
        tdec = sig['ct0'] + 60
        row['_decision'] = tdec
        jf = S.i1(tdec)
        if jf >= len(S.t1) or S.t1[jf] >= Lexp:
            row['status'] = 'V2_NO_FILL_BAR'
            row['_known'] = Lexp
            return row
        row['_known'] = int(S.t1[jf]) + 60
        row['_fill_i'] = jf
        if void_check(S, short, X, sig['ct0'], int(S.t1[jf])):
            row['status'] = 'VOID'
            return row
        S0 = Fraction(X + sg * BUF)
        row['S0'] = S0
        q = S.q
        if (short and q['ask_o'][jf] >= S0) or (not short and q['bid_o'][jf] <= S0):
            row['status'] = 'V2_ASK_AT_S0'
            return row
        F = Fraction(int(q['bid_o'][jf] if short else q['ask_o'][jf]))
        d0 = sg * (S0 - F)
        row.update(E=F, d0=d0)
        if not s5_pass(d0, ctx.A, FLOOR):
            row['status'] = 'S5'
            return row
        d = max(d0, Fraction(FLOOR))
        # L2: live_from_utc = close(t0) + 60 s, V2's decision time (K14); the fill bar is the first M1 bar that
        # opens at or after it (K11), which outcomes.order_path finds again from live_from_utc.
        row.update(status='ARMED', live_from_utc=tdec, d=d, S=F + sg * d, T=F - sg * 3 * d)
        return row

    if rule.kind == 'V3':
        # K11 V3: wait for the BOS after t0; zone from j; base void/S4/S5 not used
        Ldl = ctx.L(*rule.deadline)
        sw, conf = (S.sh, S.sh_conf) if short else (S.sl, S.sl_conf)
        ext_lo = S.l5 if short else S.h5
        bos = None
        for qb in range(t0 + 1, n5):
            cq = int(S.e5[qb])
            if cq > Ldl:
                break
            p = int(np.searchsorted(conf, cq, side='right')) - 1      # largest swing index confirmed by close(q)
            if p < 0 or sw[p] <= t0:
                continue
            j = int(sw[p])
            seg = ext_lo[t0:j + 1]
            if short:
                L2 = int(seg.min()); l2i = t0 + int(np.argmin(seg))
                hit = S.c5[qb] < L2
            else:
                L2 = int(seg.max()); l2i = t0 + int(np.argmax(seg))
                hit = S.c5[qb] > L2
            if hit:
                bos = (qb, j, L2, l2i)
                break
        if bos is None:
            return _row(status='V3_NO_BOS', _decision=Ldl, **_sig_fields(sig))
        qb, j, L2, l2i = bos
        ob = qb + 1
        if ob >= n5 or S.e5[ob] > Lexp:
            return _row(status='NO_ORDER_BAR', _decision=Lexp, **_sig_fields(sig))
        row = order_stage(S, ctx, sig, rule, k, sig['ri'], ob, c1_min=j, ob_scan_to=l2i)
        row.update(_bos=qb, _j=j, _L2=L2)
        return row

    # base, V1, V4, V5, V6 and the stability settings: order bar = next M5 bar after t0 (K7)
    ob = t0 + 1
    if ob >= n5 or S.e5[ob] > Lexp:
        return _row(status='NO_ORDER_BAR', _decision=Lexp, **_sig_fields(sig))
    return order_stage(S, ctx, sig, rule, k, sig['ri'], ob)


def eval_day(S, ctx, rules=RULES):
    """All rules for one pair-day. Signals are shared between rules with the same (S3, tt, deadline).
    V2 and V3 use the base signal (K11)."""
    cache = {}
    out = {}
    for r in rules:
        if r.kind == 'W2':
            sig = None                       # W2 has no reversal signal; eval_rule builds its own breakout row
        else:
            key = (True, TT, (10, 0), False) if r.kind in ('V2', 'V3') else (r.use_s3, r.tt, r.deadline, r.w1)
            if key not in cache:
                cache[key] = find_signal(S, ctx, tt=key[1], use_s3=key[0], deadline=key[2], w1=key[3])
            sig = cache[key]
        row = eval_rule(S, ctx, r, sig)
        row['_sig'] = sig
        out[r.name] = row
    return out


# ---------------------------------------------------------------- formatting
def fmt(v):
    """Exact text of a unit value: integers as is, half units as 'n.5' (K1, K12). Never rounded."""
    if v is None:
        return ''
    if isinstance(v, str):
        return v
    v = Fraction(v)
    if v.denominator == 1:
        return str(v.numerator)
    assert v.denominator == 2, v
    return '%d.5' % (v.numerator // 2) if v >= 0 else '-%d.5' % ((-v.numerator) // 2)


def row_values(row):
    return [fmt(row.get(k)) for k in FIELDS]


def row_values_v2x(row):
    return [fmt(row.get(k)) for k in V2X_FIELDS]


# ================================================================ V2X_SPEC.md (W2, W3)
# ---------------------------------------------------------------- W3: daily and 1h bias
def daily_bias(ctx):
    """W3 daily bias from D1 (the last complete New York day before D) against D2 (the complete day before it), mid:
    bear if (D1 high > D2 high and D1 close <= D2 high) or D1 close < D2 low; bull if (D1 low < D2 low and
    D1 close >= D2 low) or D1 close > D2 high; both or neither -> none."""
    if ctx.D1 is None or ctx.D2 is None:
        return 'none'
    h1, l1, c1 = ctx.D1
    h2, l2, c2 = ctx.D2
    bear = (h1 > h2 and c1 <= h2) or (c1 < l2)
    bull = (l1 < l2 and c1 >= l2) or (c1 > h2)
    if bear and not bull:
        return 'bear'
    if bull and not bear:
        return 'bull'
    return 'none'


def h1_bias(S, t):
    """W3 1h bias at time t from the last 3 complete H1 mid bars (UTC hours, open + 60 min <= t): bull if their lows
    rise strictly, bear if their highs fall strictly, otherwise (or both) none."""
    return bar_bias(S.th1, S.hh1, S.lh1, 3600, t)


def h4_bias(S, t):
    """A1 4h bias at time t from the last 3 complete H4 mid bars (UTC clock 00:00, 04:00, ...; open + 4 h <= t),
    with W3's 1h test: bull if their lows rise strictly, bear if their highs fall strictly, otherwise none."""
    return bar_bias(S.th4, S.hh4, S.lh4, 14400, t)


def bar_bias(th, hh, lh, sec, t):
    m = int(np.searchsorted(th + sec, t, side='right'))
    if m < 3:
        return 'none'
    lo, hi = lh[m - 3:m], hh[m - 3:m]
    up = lo[0] < lo[1] < lo[2]
    dn = hi[0] > hi[1] > hi[2]
    if up and not dn:
        return 'bull'
    if dn and not up:
        return 'bear'
    return 'none'


BIAS_KEY = {3600: 'bias_h1', 14400: 'bias_h4'}


def bias_at(S, ctx, t, hb=3600):
    return daily_bias(ctx), {3600: h1_bias, 14400: h4_bias}[hb](S, t)


def h_pass(side, bd, bh):
    """W3 filter: keep only if the daily bias equals the trade's side and the 1h bias is not the opposite side."""
    want, opp = ('bull', 'bear') if side == 'buy' else ('bear', 'bull')
    return bd == want and bh != opp


# ---------------------------------------------------------------- W2: breakout, then retest or chase
def w2_pools(S, ctx, t_end):
    """W2 pools with their first trade-through tt (K5 test, searched from the known time to t_end). A pool whose
    first trade-through comes before 07:00 London is gone. EQ pools keep v1's 12 h rule, counted back from the moment
    the pool is first taken: tt if it is known by then, else the bar being checked (see w2 NOTES)."""
    L00, L07 = ctx.L(0, 0), ctx.L(7, 0)
    a, b = S.i1(L00), S.i1(L07)
    AH = int(S.mh[a:b].max()) if b > a else None
    AL = int(S.ml[a:b].min()) if b > a else None
    out = {'high': [], 'low': []}
    base = {'high': [('AH', AH, L07), ('PDH', ctx.PDH, ctx.pd_known)],
            'low': [('AL', AL, L07), ('PDL', ctx.PDL, ctx.pd_known)]}
    for side, high in (('high', True), ('low', False)):
        for name, lv, known in base[side]:
            if lv is None or known is None:
                continue
            t = first_through(S, int(lv), high, known, t_end, TT)
            if t is not None and t < L07:
                continue
            out[side].append(dict(prio=PRIO[name], name=name, lv=int(lv), known=int(known), tt=t, oi=None))
        eq = S.eqh if high else S.eql
        nm = 'EQH' if high else 'EQL'
        sel = np.flatnonzero((eq['open_i'] >= L07 - H12) & (eq['known'] < t_end))
        for n in sel:
            lv, known, oi = int(eq['level'][n]), int(eq['known'][n]), int(eq['open_i'][n])
            t = first_through(S, lv, high, known, t_end, TT)
            if t is not None and t < L07:
                continue
            out[side].append(dict(prio=PRIO[nm], name=nm, lv=lv, known=known, tt=t, oi=oi))
    return out


def find_breakout(S, ctx, deadline=(10, 0)):
    """W2 breakout bar b: the first M5 bar closing in [07:05, 10:00] London whose close is strictly beyond a live
    pool (long: close > a high pool; short: close < a low pool). Both sides on one bar: no trade. P = the highest
    broken high pool (short: the lowest broken low pool); label tie AH/AL, then PD, then EQ (K15)."""
    L07, Ldl = ctx.L(7, 0), ctx.L(*deadline)
    pools = w2_pools(S, ctx, Ldl)
    t_a = int(np.searchsorted(S.t5, L07))
    t_b = int(np.searchsorted(S.e5, Ldl, side='right'))
    for t in range(t_a, t_b):
        ct, c = int(S.e5[t]), int(S.c5[t])
        hits = {}
        for side, high in (('high', True), ('low', False)):
            hs = []
            for p in pools[side]:
                if p['known'] > ct:
                    continue
                if p['oi'] is not None:
                    ref = p['tt'] if (p['tt'] is not None and p['tt'] < ct) else ct
                    if p['oi'] < ref - H12:
                        continue
                if (high and c > p['lv']) or (not high and c < p['lv']):
                    hs.append(p)
            hits[side] = hs
        if hits['high'] and hits['low']:
            return dict(status='BOTH_SIDES', b=t, cb=ct)
        for side, sname in (('high', 'buy'), ('low', 'sell')):
            hs = hits[side]
            if hs:
                best = max(p['lv'] for p in hs) if side == 'high' else min(p['lv'] for p in hs)
                p = min((q for q in hs if q['lv'] == best), key=lambda q: q['prio'])
                return dict(status='BREAKOUT', side=sname, b=t, cb=ct, P=best, pool=p['name'], close=c)
    return dict(status='NO_BREAKOUT')


def w2_stop(S, short, b, t_order):
    """W2 S0: the latest confirmed M5 swing low (short: high) with index >= b, confirmed by t_order, minus 1.0 pip
    (short: plus); with no such swing, b's low minus 1.0 pip (short: b's high plus 1.0 pip)."""
    sw, conf, ext = (S.sh, S.sh_conf, S.h5) if short else (S.sl, S.sl_conf, S.l5)
    sg = 1 if short else -1
    m = np.flatnonzero((sw >= b) & (conf <= t_order))
    if len(m):
        return int(ext[sw[m[-1]]]) + sg * BUF, int(sw[m[-1]])
    return int(ext[b]) + sg * BUF, None


def w2_checks(S, ctx, rule, side, E, S0, t_order, pre=''):
    """W2 checks at an order time, in order: S0 beyond the entry, the v1 cap (S5), the bias filter (w2h: W3, w2h4: A1's
    4h). Returns the status and the values computed up to the failing check (L1 style), with key prefix pre ('' or 'c_')."""
    short = side == 'sell'
    sg = 1 if short else -1
    r = {pre + 'E': E, pre + 'S0': S0}
    if not ((short and S0 > E) or (not short and S0 < E)):
        return 'W2_STOP_SIDE', r
    d0 = sg * (S0 - E)
    r[pre + 'd0'] = d0
    if not s5_pass(d0, ctx.A, rule.floor):
        return 'S5', r
    d = max(d0, Fraction(rule.floor))
    r[pre + 'd'] = d
    if rule.hf:
        bd, bh = bias_at(S, ctx, t_order, rule.hb)
        r['bias_daily'] = bd
        r[pre + BIAS_KEY[rule.hb]] = bh
        if not h_pass(side, bd, bh):
            return 'H_FILTER', r
    r[pre + 'S'] = E + sg * d
    r[pre + 'T'] = E - sg * 3 * d
    r[pre + 'live_from_utc'] = t_order
    return 'ARMED', r


def first_m1_sweep(S, short, a, z):
    """W2 chase: the first M1 bar s with index in [a, z) that sweeps the 5 M1 bars before it: long: mid low strictly
    below their lowest mid low and mid close above it; short: mid high strictly above their highest mid high and
    mid close below it. Returns the index or None."""
    a = max(a, 5)
    if z <= a:
        return None
    W = np.lib.stride_tricks.sliding_window_view(S.mh if short else S.ml, 5)
    idx = np.arange(a, z)
    if short:
        ref = W[idx - 5].max(axis=1)
        ok = (S.mh[idx] > ref) & (S.mc[idx] < ref)
    else:
        ref = W[idx - 5].min(axis=1)
        ok = (S.ml[idx] < ref) & (S.mc[idx] > ref)
    f = np.flatnonzero(ok)
    return int(idx[f[0]]) if len(f) else None


def w2_row(S, ctx, rule):
    """One W2 / W2+H row: the breakout, the retest order at close(b) and the chase order at close(s+1).
    _rdec = when the breakout and retest fields are known; _decision = when the whole row is known."""
    Ldl, Lce = ctx.L(*rule.deadline), ctx.L(*CHASE_END)
    br = find_breakout(S, ctx, rule.deadline)
    if br['status'] == 'NO_BREAKOUT':
        return _row(status='NO_BREAKOUT', _decision=Ldl, _rdec=Ldl)
    if br['status'] == 'BOTH_SIDES':
        return _row(status='BOTH_SIDES', t0_close_utc=br['cb'], _decision=br['cb'], _rdec=br['cb'])
    side, b, cb, P = br['side'], br['b'], br['cb'], br['P']
    short = side == 'sell'
    row = _row(status=None, side=side, t0_close_utc=cb, pool=br['pool'], P=P)
    row.update(_b=b, _rdec=cb, _bclose=br['close'])
    # retest: a limit at P placed at close(b)
    S0, si = w2_stop(S, short, b, cb)
    st, vals = w2_checks(S, ctx, rule, side, Fraction(P), Fraction(S0), cb)
    row['status'] = st
    row.update(vals)
    row['_r_swing'] = si
    # chase: the first 1m sweep s opening in [close(b), 10:55); a stop order at s+1's mid high (short: low)
    j = first_m1_sweep(S, short, S.i1(cb), S.i1(Lce))
    if j is None:
        row.update(c_status='NO_SWEEP', _decision=Lce)
        return row
    row['c_sweep_utc'] = int(S.t1[j])
    if j + 1 >= len(S.t1):
        row.update(c_status='NO_NEXT_BAR', _decision=None)
        return row
    tc = int(S.t1[j + 1]) + 60
    Es = int(S.ml[j + 1]) if short else int(S.mh[j + 1])
    S0c, sic = w2_stop(S, short, b, tc)
    cst, cvals = w2_checks(S, ctx, rule, side, Fraction(Es), Fraction(S0c), tc, pre='c_')
    row['c_status'] = cst
    row.update(cvals)
    row.update(_decision=tc, _c_swing=sic, _sweep_i=j)
    return row
