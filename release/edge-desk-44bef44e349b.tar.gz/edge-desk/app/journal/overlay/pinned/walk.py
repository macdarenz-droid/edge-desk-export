"""A12.2.3: the body-swing walk (Marc's swings as exact steps). Labels only: no fill, exit or R here.

Prices are whole K1 units (mid; 1 pip = 40 units). Every test with a fraction is cross-multiplied in whole numbers:
k is a Fraction, and abar(j) is given as a pair (num, den) with abar(j) = num / den units (on real data:
num = the sum of (h - l) of the last 16 complete M15 mid bars at close(j), den = 16).

The walk is causal: step j reads bars 0..j only, and abar(j) only M15 bars complete by close(j).

Public:
  run_walk(o, h, l, c, abar, k, ...)  -> dict(events, moves, states)
  build_bars(t1, mo, mh, ml, mc, length) -> (t, o, h, l, c) on the UTC grid (A12.2.1)
  abar_pairs(t_walk, length_walk, t15, h15, l15) -> [(sum16, 16), ...] per walk bar
  prev_weekday(D), walk_day(...)    the real-data entry point (s0 to the end of D's window)
"""
import datetime as dt
from fractions import Fraction

import numpy as np

M = 10              # m: 0.25 pip, the break margin (m1)
N_ABAR = 16         # abar: mean (h - l) of the last 16 complete M15 bars


def as_fraction(k):
    return k if isinstance(k, Fraction) else Fraction(str(k))


# ------------------------------------------------------------------ helpers: extremes, latest bar on ties
def _amax(v, lo, hi):
    """index of the highest v[i] over lo..hi inclusive, the latest on ties"""
    s = v[lo:hi + 1]
    x = max(s)
    return hi - s[::-1].index(x)


def _amin(v, lo, hi):
    s = v[lo:hi + 1]
    x = min(s)
    return hi - s[::-1].index(x)


def _obvious(pull, ab, k):
    """pull >= k x abar, cross-multiplied: pull * k.den * abar.den >= k.num * abar.num"""
    num, den = ab
    return pull * k.denominator * den >= k.numerator * num


# ------------------------------------------------------------------ the walk
def run_walk(o, h, l, c, abar, k, m=M, lastlh=True, start=None, j0=None, keep_states=False):
    """A12.2.3, in this order at each bar j >= j0: the state's steps (at most one event), the fixed test,
    then the last-lower-high / higher-low rule (lastlh=False switches that rule off, for the unit tests only).

    o, h, l, c: sequences of whole units (the walk's bars, s0 first).
    abar: a sequence of (num, den) per bar (abar(j) = num / den units), or one (num, den) for every bar (typed).
    k: the pullback multiple (Fraction, or anything Fraction(str(k)) reads exactly).
    start: None = NONE at bar 0 (A12.2.3 'At s0'), loop from j0 = 1. Otherwise a typed state dict
           {'d': 'up', 'PL': i, 'HH': i, 'f': False} / {'d': 'down', 'PH': i, 'LL': i, 'f': False} /
           {'d': 'none', 'Hn': i, 'Ln': i}, and the loop starts at j0 (default 1).
    Returns dict(events=[...], moves=[...], states=[...] if keep_states).
      event: j, close, dir ('UP'/'DOWN'), kind ('FIRST'/'CHOCH'/'BOS'), broken=(price, bar), prot=(price, bar),
             X=(price, bar), leg=(price, bar) (the new leg extreme, not yet fixed; information).
      move:  j, which ('PH' or 'PL'), level=(price, bar): the last lower high / higher low (no event).
    """
    k = as_fraction(k)
    n = len(c)
    o = [int(x) for x in o]; h = [int(x) for x in h]; l = [int(x) for x in l]; c = [int(x) for x in c]
    bt = [max(a, b) for a, b in zip(o, c)]
    bb = [min(a, b) for a, b in zip(o, c)]
    if isinstance(abar, tuple) and len(abar) == 2 and not isinstance(abar[0], (tuple, list)):
        ab = [tuple(abar)] * n
    else:
        ab = [tuple(x) for x in abar]
        assert len(ab) == n
    if start is None:
        st = {'d': 'none', 'Hn': 0, 'Ln': 0}
        j0 = 1 if j0 is None else j0
    else:
        st = dict(start)
        j0 = 1 if j0 is None else j0
    events, moves, states = [], [], []

    def ev(j, d, kind, br, kb, pr, kp, leg, kl):
        if d == 'UP':
            xi = _amin(l, br + 1, j); X = (l[xi], xi)          # Xlow: the move's wick, latest bar on ties
        else:
            xi = _amax(h, br + 1, j); X = (h[xi], xi)          # Xhigh
        price = lambda kind_, i: bt[i] if kind_ == 'H' else bb[i]
        events.append(dict(j=j, close=c[j], dir=d, kind=kind, broken=(price(kb, br), br),
                           prot=(price(kp, pr), pr), X=X, leg=(price(kl, leg), leg)))

    for j in range(j0, n):
        d = st['d']
        if d == 'none':
            if c[j] >= bt[st['Hn']] + m:                                        # N1
                br = st['Hn']; pl = _amin(bb, br + 1, j); hh = _amax(bt, pl, j)
                ev(j, 'UP', 'FIRST', br, 'H', pl, 'L', hh, 'H')
                st = {'d': 'up', 'PL': pl, 'HH': hh, 'f': False}
            elif c[j] <= bb[st['Ln']] - m:                                      # N2
                br = st['Ln']; ph = _amax(bt, br + 1, j); ll = _amin(bb, ph, j)
                ev(j, 'DOWN', 'FIRST', br, 'L', ph, 'H', ll, 'L')
                st = {'d': 'down', 'PH': ph, 'LL': ll, 'f': False}
            else:                                                               # N3
                if bt[j] >= bt[st['Hn']]:
                    st['Hn'] = j
                if bb[j] <= bb[st['Ln']]:
                    st['Ln'] = j
        elif d == 'down':
            if c[j] >= bt[st['PH']] + m:                                        # D1, CHoCH up
                br = st['PH']; pl = _amin(bb, br + 1, j); hh = _amax(bt, pl, j)
                ev(j, 'UP', 'CHOCH', br, 'H', pl, 'L', hh, 'H')
                st = {'d': 'up', 'PL': pl, 'HH': hh, 'f': False}
            elif st['f'] and c[j] <= bb[st['LL']] - m:                          # D2, BOS down
                br = st['LL']; ph = _amax(bt, br + 1, j); ll = _amin(bb, ph, j)
                ev(j, 'DOWN', 'BOS', br, 'L', ph, 'H', ll, 'L')
                st = {'d': 'down', 'PH': ph, 'LL': ll, 'f': False}
            elif not st['f'] and bb[j] <= bb[st['LL']]:                         # D3, the leg extends
                st['LL'] = j
        else:
            if c[j] <= bb[st['PL']] - m:                                        # U1, CHoCH down
                br = st['PL']; ph = _amax(bt, br + 1, j); ll = _amin(bb, ph, j)
                ev(j, 'DOWN', 'CHOCH', br, 'L', ph, 'H', ll, 'L')
                st = {'d': 'down', 'PH': ph, 'LL': ll, 'f': False}
            elif st['f'] and c[j] >= bt[st['HH']] + m:                          # U2, BOS up
                br = st['HH']; pl = _amin(bb, br + 1, j); hh = _amax(bt, pl, j)
                ev(j, 'UP', 'BOS', br, 'H', pl, 'L', hh, 'H')
                st = {'d': 'up', 'PL': pl, 'HH': hh, 'f': False}
            elif not st['f'] and bt[j] >= bt[st['HH']]:                         # U3, the leg extends
                st['HH'] = j
        # the fixed test, after every bar (an event bar included)
        d = st['d']
        if d == 'down' and not st['f']:
            x = st['LL']
            if j >= x + 2 and _obvious(max(bt[x + 1:j + 1]) - bb[x], ab[j], k):
                st['f'] = True
        elif d == 'up' and not st['f']:
            x = st['HH']
            if j >= x + 2 and _obvious(bt[x] - min(bb[x + 1:j + 1]), ab[j], k):
                st['f'] = True
        # the last lower high and the higher low
        if lastlh and d == 'down' and st['f'] and j > st['LL']:
            bh = _amax(bt, st['LL'] + 1, j)
            if (j >= bh + 2 and _obvious(bt[bh] - min(bb[bh + 1:j + 1]), ab[j], k)
                    and bt[bh] < bt[st['PH']]):
                st['PH'] = bh
                moves.append(dict(j=j, which='PH', level=(bt[bh], bh)))
        elif lastlh and d == 'up' and st['f'] and j > st['HH']:
            bl = _amin(bb, st['HH'] + 1, j)
            if (j >= bl + 2 and _obvious(max(bt[bl + 1:j + 1]) - bb[bl], ab[j], k)
                    and bb[bl] > bb[st['PL']]):
                st['PL'] = bl
                moves.append(dict(j=j, which='PL', level=(bb[bl], bl)))
        if keep_states:
            states.append((j, dict(st)))
    out = dict(events=events, moves=moves)
    if keep_states:
        out['states'] = states
    return out


def swing_levels(res):
    """Every broken and every protected level of a walk: [(kind 'H'/'L', bar, price)], each (kind, bar) once.
    Broken: an UP event breaks a high, a DOWN event a low. Protected: an UP event's PL (low), a DOWN event's PH
    (high), and every last-lower-high (PH) / higher-low (PL) move."""
    out = {}
    for e in res['events']:
        bk = 'H' if e['dir'] == 'UP' else 'L'
        pk = 'L' if e['dir'] == 'UP' else 'H'
        out.setdefault((bk, e['broken'][1]), e['broken'][0])
        out.setdefault((pk, e['prot'][1]), e['prot'][0])
    for mv in res['moves']:
        kind = 'H' if mv['which'] == 'PH' else 'L'
        out.setdefault((kind, mv['level'][1]), mv['level'][0])
    return sorted(((kd, b, p) for (kd, b), p in out.items()), key=lambda x: (x[1], x[0]))


# ------------------------------------------------------------------ bars and abar on real data (A12.2.1)
def build_bars(t1, mo, mh, ml, mc, length):
    """Bars on the UTC grid from M1 mid units: slot = floor(t / length) * length; a bar exists if at least one M1
    bar opens in its slot; open = first M1 open, high/low = max/min, close = last M1 close."""
    t1 = np.asarray(t1, np.int64)
    if len(t1) == 0:
        e = np.zeros(0, np.int64)
        return e, e, e, e, e
    assert np.all(np.diff(t1) > 0)
    g = (t1 // length) * length
    keys, idx = np.unique(g, return_index=True)
    ends = np.r_[idx[1:], len(t1)] - 1
    return (keys.astype(np.int64), np.asarray(mo, np.int64)[idx], np.maximum.reduceat(np.asarray(mh, np.int64), idx),
            np.minimum.reduceat(np.asarray(ml, np.int64), idx), np.asarray(mc, np.int64)[ends])


def abar_pairs(t_walk, length_walk, t15, h15, l15, n=N_ABAR):
    """abar(j) for each walk bar: the last n M15 bars complete at close(j) = t_walk[j] + length_walk
    (open + 900 <= close(j)), as (sum of h - l, n). Refuses if fewer than n are complete."""
    t15 = np.asarray(t15, np.int64)
    rng = np.asarray(h15, np.int64) - np.asarray(l15, np.int64)
    cs = np.r_[0, np.cumsum(rng)]
    done = np.searchsorted(t15 + 900, np.asarray(t_walk, np.int64) + length_walk, side='right')   # count complete
    assert np.all(done >= n), 'fewer than %d complete M15 bars before a walk bar' % n
    return [(int(cs[q] - cs[q - n]), n) for q in done]


def prev_weekday(D):
    """the previous calendar weekday (Friday for a Monday), whatever its data or holiday status (A8 M2)"""
    p = D - dt.timedelta(days=1)
    while p.weekday() >= 5:
        p -= dt.timedelta(days=1)
    return p


def walk_day(t1, mo, mh, ml, mc, s0_time, end_time, k, length=300, lastlh=True, keep_states=False):
    """The walk of one trade day on real data. t1, m*: cleaned M1 mid units (K1, K2), holding at least the rows
    from 16 M15 bars before s0 to end_time. The walk's bars: the bars of `length` (300 = M5; 900 = the 15m walk
    reported as information, m2b) opening in [s0_time, end_time). abar from the plain M15 series (every bar).
    Returns (bars dict, walk result)."""
    t1 = np.asarray(t1, np.int64)
    keep = t1 < end_time
    t1, mo, mh, ml, mc = t1[keep], np.asarray(mo)[keep], np.asarray(mh)[keep], np.asarray(ml)[keep], np.asarray(mc)[keep]
    t15, o15, h15, l15, c15 = build_bars(t1, mo, mh, ml, mc, 900)
    tw, ow, hw, lw, cw = build_bars(t1, mo, mh, ml, mc, length)
    sel = tw >= s0_time
    tw, ow, hw, lw, cw = tw[sel], ow[sel], hw[sel], lw[sel], cw[sel]
    ab = abar_pairs(tw, length, t15, h15, l15)
    res = run_walk(ow.tolist(), hw.tolist(), lw.tolist(), cw.tolist(), ab, k, lastlh=lastlh, keep_states=keep_states)
    return dict(t=tw, o=ow, h=hw, l=lw, c=cw, abar=ab), res
