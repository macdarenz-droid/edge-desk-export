"""The pinned A12 engine of the trade picture (app/journal/overlay/pinned; docs/JOURNAL_DESIGN.md D10, section 7.4):
byte copies of the research engine at SOURCE_COMMIT, named with their source paths in pinned/PINS.md.

Standard library only: verify() runs in the child before anything is imported from the copy. It refuses (Refused)
unless pinned/ holds exactly the pinned files plus SHA256SUMS and PINS.md (no other file or folder that a bare-name
import could pick up, and no __pycache__: cached bytecode would be run in place of the checked source), each file's
sha256 is its pin, and SHA256SUMS lists the same pins.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

SOURCE_COMMIT = "aebc0f2fb557690bc7d637be54408159df7703f5"
SOURCE_BRANCH = "ccr-b1232258-55ajvr"
PINNED_DIR = Path(__file__).resolve().with_name("pinned")
PINS = {
    "a12.py": "6fa836ef1a69a448faf2d9296ee6f48e18c8ed49c6545c0b408aebad76a47e10",
    "walk.py": "3b93c60f2c2c490c1279b642c4c7c38cbb1f7567fb848ea5868420bd1f178d7c",
    "data.py": "25e3f5bb5399bc7439e88237eb64a06a1070cbd68d2b867ab12ce459c41a9e2a",
    "engine.py": "eb6740763ab683c6be95af9a6a09106806b4211592249c46593ca772ea388909",
}
SOURCES = {
    "a12.py": "sandbox/work/marc_test/v2x_a12/engine/a12.py",
    "walk.py": "sandbox/work/marc_test/v2x_a12/engine/walk.py",
    "data.py": "sandbox/work/marc_test/v2x/data.py",
    "engine.py": "sandbox/work/marc_test/v2x/engine.py",
}
DOC_FILES = ("SHA256SUMS", "PINS.md")        # not code: no import can load them
# The engine version stored with every analysis (journal_analysis.pins_sha): one sha256 over the pin table, one
# "<sha256>  <path>" line per file in path order, as sha256sum prints them.
PINS_SHA = hashlib.sha256("".join(f"{h}  {f}\n" for f, h in sorted(PINS.items())).encode()).hexdigest()
BARE = ("a12", "walk", "data", "engine")    # the modules the child loads by bare name, all from pinned/


class Refused(RuntimeError):
    pass


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sums_text() -> str:
    """SHA256SUMS as sha256sum writes it for the four files (path order)."""
    return "".join(f"{PINS[f]}  {f}\n" for f in sorted(PINS))


def verify(root: Path | str = PINNED_DIR) -> None:
    """Refused unless root holds exactly PINS and DOC_FILES, every file a regular file (no link), each pinned file
    with its sha256, and SHA256SUMS naming the same sha256 values."""
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise Refused(f"{root} is not a folder")
    got = {p.relative_to(root).as_posix() for p in root.rglob("*")}
    want = set(PINS) | set(DOC_FILES)
    if got != want:
        raise Refused(f"files differ from the pins: extra {sorted(got - want)}, missing {sorted(want - got)}")
    for rel in sorted(want):
        p = root / rel
        if p.is_symlink() or not p.is_file():
            raise Refused(f"{rel} is not a plain file")
    for rel, pin in sorted(PINS.items()):
        have = sha256_file(root / rel)
        if have != pin:
            raise Refused(f"{rel} sha256 {have} differs from the pin {pin}")
    sums = {}
    for line in (root / "SHA256SUMS").read_text(encoding="ascii").splitlines():
        if line.strip():
            h, name = line.split()
            sums[name] = h
    if sums != PINS:
        raise Refused("SHA256SUMS differs from the pins")
