"""The trade picture's step (docs/JOURNAL_DESIGN.md sections 7.3, 7.4 and 8.1): run inside the method worker's loop
(every 30 s) after the A+ step, in its own try. It reads trades and bars, runs the pinned A12 engine in its own
process (child.py) and writes journal_analysis rows. It never touches an order, the planner or the day guard.

Which trades (refs): every MT5 trade (book 'mt5', EUR/USD) as mt5:<trade id>, and every paper trade as
paper:<trade id>. A picture trade (photo:<id>) fits the same row and route shape; it is added with the photo journal.

The decision and tau (section 7.3):
  - MT5: the order_seen row whose ticket is the entry deal's order_id gives setup_utc (a limit or stop order:
    "order"). With no pending order seen, the fill is the decision ("fill", a market order) when the bridge was
    watching: order tracking had begun before the fill (meta order_seen_since:<alias>) and the entry deal reached the
    app within [bridge] silent_alert_after_s of its time. Otherwise the order time is unknown ("unknown"): tau is the
    fill's, and the tags are headed "At the fill: your order time is unknown", every line amber (P8).
  - paper: a limit or stop paper order's created_utc ("order"); a market paper order's fill ("fill").
  - tau = floor(decision / 300) x 300, the last 5m close at or before it. The trading day D is the New York day
    (17:00 to 17:00) holding tau.

When a row is made: a trade's inputs (side, kind, entry, first stop, target, decision, fill, exit, and whether its
trading day had ended) are hashed (inputs_sha); a row is made when no row of that ref has those inputs and the feed's
complete_through marker allows it: at or past tau and the fill minute (an open trade), past the exit minute or the
day's end (a closed one), and past 17:00 New York on D for the final row. So a trade gets a row when it opens, one
when it closes and one when its day is final (one fewer when two of them fall together).

Cost to the method worker's loop (code review, 30 Oct): newest trades first, at most PER_RUN children a loop and no
new child once STEP_BUDGET_S have gone in the step; a child is stopped after CHILD_TIMEOUT_S (measured 0.4 s, design
bar 3 s), so a slow picture never holds the A+ step back for long. A failed child is tried again after RETRY_S; after
MAX_FAILURES failures with the same inputs and the same engine it is not tried again, and the tags route says "Could
not draw this trade" (meta journal_refused:<ref>; a changed trade or a new engine tries again). A timeout is the
server's load, not the trade: it waits RETRY_S too but never counts toward MAX_FAILURES. The scan reads only each
trade's latest inputs_sha, and skips a closed trade whose latest row is final and was made from its closed inputs
(journal_analysis.closed): a close recorded late, however late, still gets its row.
"""
from __future__ import annotations

import gzip
import hashlib
import io
import json
import logging
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from app import db
from app.journal.overlay import pins
from app.timeutil import LONDON, NEW_YORK, from_iso, to_iso, trading_day

log = logging.getLogger("app.journal")
CHILD = Path(__file__).with_name("child.py")
CHILD_ENV = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"}
CHILD_TIMEOUT_S = 20                  # measured 0.4 s a trade; the design's bar is 3 s
STEP_BUDGET_S = 10                    # no new child once this much of the loop has gone in the step
SLICE_DAYS = 100                      # the A12 slice: 00:00 London on D - 100 days (section 7.3, A12.1)
PER_RUN = 2                           # children per loop of the method worker (about 1-2 s each)
RETRY_S = 15 * 60
MAX_FAILURES = 3                      # then no more tries with the same inputs and engine
REFUSED = "journal_refused:"          # meta key + ref: the failures of the latest inputs (JSON)
UNDRAWABLE = "Could not draw this trade"
QFIELDS = ("bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")
CHUNK = 20000
PENDING = ("buy_limit", "sell_limit", "buy_stop", "sell_stop", "buy_stop_limit", "sell_stop_limit")
ENTRY_IN = ("in", "inout")
ORDER_SEEN_SINCE = "order_seen_since:"
EXIT_KIND = {"tp": "tp", "sl": "sl", "be": "be", "manual": "manual", "so": "so", "expired": "expired",
             "other": "other", "cancelled": "other"}


class ChildError(RuntimeError):
    pass


class ChildTimeout(ChildError):
    """The child ran past CHILD_TIMEOUT_S: load on the server, never counted toward MAX_FAILURES."""


def lon(d: date, hh: int, mm: int = 0) -> int:
    return int(datetime(d.year, d.month, d.day, hh, mm, tzinfo=LONDON).timestamp())


def nyt(d: date, hh: int, mm: int = 0) -> int:
    return int(datetime(d.year, d.month, d.day, hh, mm, tzinfo=NEW_YORK).timestamp())


def tau_of(decision: int) -> int:
    """The last 5m close at or before the decision (section 7.3)."""
    return int(decision) // 300 * 300


def day_of(tau: int) -> date:
    """The trading day (the New York day ending 17:00) that holds tau."""
    return trading_day(datetime.fromtimestamp(int(tau), timezone.utc), NEW_YORK, 17)


def _epoch(iso: str | None) -> int | None:
    return None if not iso else int(from_iso(iso).timestamp())


# ---------------------------------------------------------------- the trade's inputs

@dataclass(frozen=True)
class Decision:
    decision: int
    tau_how: str                       # order / fill / unknown
    kind: str                          # buy_limit, ..., market, unknown


def mt5_decision(conn, cfg, t) -> Decision:
    """Section 7.3 item 1 for an MT5 trade (row of `trade`)."""
    fill = _epoch(t["open_utc"])
    entry = conn.execute(
        "SELECT order_id, time_utc, received_utc FROM deal WHERE account_alias = ? AND position_id = ?"
        " AND entry IN (?, ?) ORDER BY time_utc, CAST(deal_id AS INTEGER) LIMIT 1",
        (t["account_alias"], t["broker_position_id"], *ENTRY_IN)).fetchone()
    if entry is not None and entry["order_id"]:
        o = conn.execute("SELECT type, setup_utc FROM order_seen WHERE account_alias = ? AND ticket = ?",
                         (t["account_alias"], entry["order_id"])).fetchone()
        if o is not None and o["type"] in PENDING:
            return Decision(_epoch(o["setup_utc"]), "order", o["type"])
    since = conn.execute("SELECT value FROM meta WHERE key = ?", (ORDER_SEEN_SINCE + t["account_alias"],)).fetchone()
    if entry is not None and since is not None:
        deal_t, got = _epoch(entry["time_utc"]), _epoch(entry["received_utc"])
        if _epoch(since[0]) <= deal_t and got - deal_t <= cfg.bridge.silent_alert_after_s:
            return Decision(fill, "fill", "market")
    return Decision(fill, "unknown", "unknown")


def paper_decision(conn, t) -> Decision | None:
    o = conn.execute("SELECT order_type, created_utc, filled_utc FROM paper_order WHERE id = ?",
                     (t["paper_order_id"],)).fetchone()
    if o is None:
        return None
    if o["order_type"] == "market":
        return Decision(_epoch(o["filled_utc"]) or _epoch(t["open_utc"]), "fill", "market")
    return Decision(_epoch(o["created_utc"]), "order", f"{t['side']}_{o['order_type']}")


def trade_inputs(conn, cfg, ref: str) -> dict | None:
    """The child's request without `through`, for mt5:<id> or paper:<id>; None when the trade has no picture (not
    found, not EUR/USD, no decision time)."""
    book, _, num = ref.partition(":")
    if book not in ("mt5", "paper") or not num.isdigit():
        return None
    t = conn.execute("SELECT * FROM trade WHERE id = ? AND book = ?", (int(num), book)).fetchone()
    if t is None or not cfg.is_eurusd(t["symbol"]):
        return None
    dec = mt5_decision(conn, cfg, t) if book == "mt5" else paper_decision(conn, t)
    if dec is None or dec.decision is None:
        return None
    fill = _epoch(t["open_utc"])
    decision = min(dec.decision, fill) if fill is not None else dec.decision   # never after the fill
    if dec.tau_how in ("fill", "unknown") and fill is not None:
        decision = fill                                                         # the fill is the decision
    tau = tau_of(decision)
    closed = t["status"] == "closed" and t["close_utc"] and t["close_price"] is not None
    return {"ref": ref, "pair": "EUR_USD", "D": day_of(tau).isoformat(), "side": t["side"], "kind": dec.kind,
            "entry": float(t["open_price"]), "stop": None if t["initial_sl"] is None else float(t["initial_sl"]),
            "target": None if t["initial_tp"] is None else float(t["initial_tp"]), "decision": int(decision),
            "tau_how": dec.tau_how, "fill_t": fill,
            "exit_t": _epoch(t["close_utc"]) if closed else None,
            "exit_price": float(t["close_price"]) if closed else None,
            "exit_kind": EXIT_KIND.get(t["close_reason"] or "", "other") if closed else None}


def refs(conn, cfg) -> list[str]:
    """Every trade that can have a picture, newest first."""
    out = []
    for r in conn.execute("SELECT id, book, symbol FROM trade WHERE book IN ('mt5', 'paper')"
                          " ORDER BY open_utc DESC, id DESC"):
        if cfg.is_eurusd(r["symbol"]):
            out.append(f"{r['book']}:{r['id']}")
    return out


def due_at(inp: dict) -> int:
    """The marker the next row needs: tau and the fill minute; the exit minute (or the day's end) once closed."""
    D = date.fromisoformat(inp["D"])
    end = nyt(D, 17)
    need = tau_of(inp["decision"])
    if inp["fill_t"] is not None:
        need = max(need, inp["fill_t"] // 60 * 60 + 60)
    if inp["exit_t"] is not None:
        need = max(need, inp["exit_t"] // 60 * 60 + 60)
    return min(need, end)


def inputs_sha(inp: dict, final: bool) -> str:
    body = json.dumps(dict(inp, final=bool(final)), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(body.encode()).hexdigest()


def latest_sha(conn, ref: str) -> str | None:
    r = conn.execute("SELECT inputs_sha FROM journal_analysis WHERE trade_ref = ? ORDER BY id DESC LIMIT 1",
                     (ref,)).fetchone()
    return None if r is None else r[0]


def refusal(conn, ref: str) -> dict | None:
    r = conn.execute("SELECT value FROM meta WHERE key = ?", (REFUSED + ref,)).fetchone()
    if r is None:
        return None
    try:
        rec = json.loads(r[0])
    except ValueError:
        return None
    return rec if isinstance(rec, dict) else None


def given_up(conn, ref: str, inp: dict | None) -> bool:
    """MAX_FAILURES failures with these inputs (final or not) and this engine: no more tries."""
    rec = refusal(conn, ref)
    if rec is None or inp is None or rec.get("pins_sha") != pins.PINS_SHA:
        return False
    return int(rec.get("n", 0)) >= MAX_FAILURES and rec.get("inputs_sha") in (inputs_sha(inp, False),
                                                                            inputs_sha(inp, True))


def latest_row(conn, ref: str):
    return conn.execute("SELECT * FROM journal_analysis WHERE trade_ref = ? ORDER BY id DESC LIMIT 1",
                        (ref,)).fetchone()


def decode(row) -> dict:
    return json.loads(gzip.decompress(row["analysis_json_gz"]))


# ---------------------------------------------------------------- bars and the child

def read_bars(conn, lo: int, hi: int) -> dict:
    """m1_bar rows with lo <= ts < hi as arrays (ts and volume int64, prices float64). Refuses a row at or after hi."""
    import numpy as np
    n = conn.execute("SELECT COUNT(*) FROM m1_bar WHERE ts >= ? AND ts < ?", (int(lo), int(hi))).fetchone()[0]
    out = {"ts_utc": np.empty(n, dtype=np.int64), "volume": np.empty(n, dtype=np.int64)}
    for f in QFIELDS:
        out[f] = np.empty(n, dtype=np.float64)
    cur = conn.execute("SELECT ts, bid_o, bid_h, bid_l, bid_c, ask_o, ask_h, ask_l, ask_c, volume FROM m1_bar"
                       " WHERE ts >= ? AND ts < ? ORDER BY ts", (int(lo), int(hi)))
    i = 0
    while i < n:
        rows = cur.fetchmany(CHUNK)
        if not rows:
            break
        j = i + len(rows)
        out["ts_utc"][i:j] = [r[0] for r in rows]
        out["volume"][i:j] = [r[9] for r in rows]
        block = np.array([r[1:9] for r in rows], dtype=np.float64)
        for c, f in enumerate(QFIELDS):
            out[f][i:j] = block[:, c]
        i = j
    if i < n:
        out = {k: v[:i] for k, v in out.items()}
    if len(out["ts_utc"]) and int(out["ts_utc"].max()) >= int(hi):
        raise AssertionError("a bar at or after the end reached the picture's child")
    return out


def subprocess_child(arrays: dict, req: dict, timeout_s: int, python: str = sys.executable) -> dict:
    """The pinned code in its own `python -I -B` process; its environment holds PATH and LANG only."""
    import numpy as np
    buf = io.BytesIO()
    np.savez(buf, request=np.array(json.dumps(req)), **arrays)
    r = subprocess.run([python, "-I", "-B", str(CHILD)], input=buf.getvalue(), capture_output=True,
                       timeout=timeout_s, cwd=str(CHILD.parent), env=dict(CHILD_ENV))
    if r.returncode != 0:
        lines = [x.strip() for x in r.stderr.decode(errors="replace").splitlines() if x.strip()]
        raise ChildError(f"{lines[-1] if lines else 'no output'} (exit {r.returncode})")
    return json.loads(r.stdout)


# ---------------------------------------------------------------- the step

class JournalStep:
    def __init__(self, conn, cfg, run_child=None, python: str = sys.executable):
        self.conn, self.cfg = conn, cfg
        self.python = python
        self.run_child = run_child or (lambda arrays, req, timeout_s: subprocess_child(arrays, req, timeout_s,
                                                                                      self.python))

    def due(self, marker: int | None) -> list[tuple[str, dict, bool, str]]:
        """[(ref, inputs, final, inputs_sha)] whose next row the marker allows, newest trades first. Reads each
        trade's latest inputs_sha only (never the analysis itself), and skips a closed trade whose latest row is
        final and made from its closed inputs, and a trade given up on (MAX_FAILURES)."""
        if marker is None:
            return []
        out = []
        rows = self.conn.execute(
            "SELECT t.id, t.book, t.symbol, t.status, (SELECT j.final * 2 + j.closed FROM journal_analysis j"
            " WHERE j.trade_ref = t.book || ':' || t.id ORDER BY j.id DESC LIMIT 1) AS last FROM trade t"
            " WHERE t.book IN ('mt5', 'paper') ORDER BY t.open_utc DESC, t.id DESC").fetchall()
        for r in rows:
            if not self.cfg.is_eurusd(r["symbol"]):
                continue
            if r["status"] == "closed" and r["last"] == 3:      # final, and made from the closed trade: done
                continue
            ref = f"{r['book']}:{r['id']}"
            inp = trade_inputs(self.conn, self.cfg, ref)
            if inp is None:
                continue
            D = date.fromisoformat(inp["D"])
            final = int(marker) >= nyt(D, 17)
            sha = inputs_sha(inp, final)
            if latest_sha(self.conn, ref) == sha or int(marker) < due_at(inp) or given_up(self.conn, ref, inp):
                continue
            out.append((ref, inp, final, sha))
        return out

    def _failed(self, ref: str, sha: str, now_wall: datetime, message: str, counts: bool = True) -> None:
        rec = refusal(self.conn, ref) or {}
        same = rec.get("inputs_sha") == sha and rec.get("pins_sha") == pins.PINS_SHA
        n = (int(rec.get("n", 0)) if same else 0) + (1 if counts else 0)
        value = {"inputs_sha": sha, "pins_sha": pins.PINS_SHA, "n": n,
                 "next_try": int(now_wall.timestamp()) + RETRY_S, "message": message[:300]}
        with db.transaction(self.conn):
            self.conn.execute("INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET"
                              " value = excluded.value", (REFUSED + ref, json.dumps(value, sort_keys=True)))
        if n >= MAX_FAILURES:
            log.warning("trade picture %s: %s failures with the same inputs: not tried again", ref, n)

    def _waiting(self, ref: str, sha: str, now_wall: datetime) -> bool:
        rec = refusal(self.conn, ref)
        return bool(rec and rec.get("inputs_sha") == sha and rec.get("pins_sha") == pins.PINS_SHA
                    and int(now_wall.timestamp()) < int(rec.get("next_try", 0)))

    def run(self, now_wall: datetime) -> dict:
        from app.feed.oanda import complete_through
        marker = complete_through(self.conn)
        if marker is None:
            return {"status": "no prices yet", "made": []}
        made, errors = [], []
        t_start = time.monotonic()
        for ref, inp, final, sha in self.due(marker):
            if len(made) + len(errors) >= PER_RUN or time.monotonic() - t_start >= STEP_BUDGET_S:
                break
            if self._waiting(ref, sha, now_wall):
                continue
            try:
                r = self.analyse(ref, inp, final, sha, int(marker), now_wall)
            except Exception as e:                       # noqa: BLE001  (logged and counted; the loop goes on)
                errors.append(f"{ref}: {type(e).__name__}: {str(e)[:200]}")
                log.warning("trade picture %s: %s", ref, errors[-1])
                self._failed(ref, sha, now_wall, errors[-1], counts=not isinstance(e, ChildTimeout))
                continue
            if r is None:                                # no prices before the order yet: nothing to draw, no failure
                continue
            if refusal(self.conn, ref) is not None:
                with db.transaction(self.conn):
                    self.conn.execute("DELETE FROM meta WHERE key = ?", (REFUSED + ref,))
            made.append(r)
        return {"status": "ran" if made or errors else "idle", "made": made, "errors": errors}

    def analyse(self, ref: str, inp: dict, final: bool, sha: str, marker: int, now_wall: datetime) -> dict | None:
        """One child run and its row. None when the day has no prices before the order (nothing to draw yet)."""
        D = date.fromisoformat(inp["D"])
        tau = tau_of(inp["decision"])
        through = min(marker // 60 * 60, nyt(D, 17))
        lo = lon(D - timedelta(days=SLICE_DAYS), 0)
        have = self.conn.execute("SELECT COUNT(*) FROM m1_bar WHERE ts >= ? AND ts < ?",
                                 (nyt(D - timedelta(days=1), 17), tau)).fetchone()[0]
        if not have:
            return None
        arrays = read_bars(self.conn, lo, through)
        req = dict(inp, through=through)
        t0 = time.monotonic()
        try:
            out = self.run_child(arrays, req, CHILD_TIMEOUT_S)
        except subprocess.TimeoutExpired:
            raise ChildTimeout(f"timeout after {CHILD_TIMEOUT_S} s") from None
        secs = round(time.monotonic() - t0, 3)
        if out.get("status") != "done":
            raise ChildError(str(out.get("message") or out.get("status"))[:300])
        if out.get("tau") != tau or out.get("pins_sha") != pins.PINS_SHA:
            raise ChildError("the child's tau or engine version differs from the step's")
        out["step"] = {"seconds": secs, "marker": int(marker), "made_utc": to_iso(now_wall)}
        blob = gzip.compress(json.dumps(out, sort_keys=True, separators=(",", ":"), allow_nan=False).encode(), 6,
                             mtime=0)
        with db.transaction(self.conn):
            prev = self.conn.execute("SELECT id FROM journal_analysis WHERE trade_ref = ? ORDER BY id DESC LIMIT 1",
                                     (ref,)).fetchone()
            rid = self.conn.execute(
                "INSERT INTO journal_analysis (trade_ref, tau, inputs_sha, pins_sha, analysis_json_gz, final, closed,"
                " made_utc, supersedes_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (ref, tau, sha, pins.PINS_SHA, blob, int(final), int(inp["exit_t"] is not None), to_iso(now_wall),
                 None if prev is None else prev["id"])).lastrowid
        log.info("trade picture %s: row %s (tau %s, final %s, %.2f s)", ref, rid, tau, int(final), secs)
        return {"ref": ref, "id": rid, "final": bool(final), "seconds": secs, "bytes": len(blob)}


def journal_step(step: JournalStep, now: datetime) -> dict | None:
    """One step, logged; an exception is logged and never leaves (the method worker's loop goes on)."""
    try:
        return step.run(now)
    except Exception:                                    # noqa: BLE001
        log.exception("trade picture step failed")
        return None
