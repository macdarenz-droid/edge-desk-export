"""The trade picture's two routes (docs/JOURNAL_DESIGN.md D11, section 7.4), authenticated like every other GET:

  GET /api/journal/<ref>/tags                    JSON page text: heading, tag lines, after lines, notes, the picture's
                                                 two view links; or the state while there is no picture yet
  GET /api/journal/<ref>/chart.svg?view=5m|15m&theme=dark|light
                                                 the picture (image/svg+xml), ETag = sha256 of the stored data, the
                                                 renderer and words versions, the view and the theme, worked out
                                                 before anything is drawn (a 304 draws nothing);
                                                 Cache-Control: private, no-cache

ref is mt5:<trade id>, paper:<trade id> or photo:<id>. The latest journal_analysis row of the ref is shown (a newer
row supersedes an older one, which is kept). The screens never build the picture's link: it comes from here.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Callable

from app.journal.overlay import picture, step, words

REF = r"(?:mt5|paper|photo):[1-9][0-9]{0,11}"
REF_RE = re.compile(REF)
VIEWS = ("5m", "15m")
THEMES = ("dark", "light")
WAIT_FEED = "Needs the OANDA feed"                # the app's one wording for a missing feed (app.js)
WAIT_MAKE = "Not ready yet"
NO_PICTURE = "No picture for this trade"
UNDRAWABLE = step.UNDRAWABLE                      # "Could not draw this trade": never an internal error text
WORDS_VERSION = "words-2"
log = logging.getLogger("app.journal")


class NotFound(LookupError, ValueError):
    pass


class Undrawable(RuntimeError):
    pass


@dataclass(frozen=True)
class SvgReply:
    """The picture route's reply: its ETag first; render() draws the SVG only when the browser does not hold it."""
    etag: str
    render: Callable[[], bytes]
    cache: str = "private, no-cache"
    ctype: str = "image/svg+xml"


def _latest(conn, ref: str):
    return step.latest_row(conn, ref)


def _trade_exists(conn, ref: str) -> bool:
    book, _, num = ref.partition(":")
    if book in ("mt5", "paper"):
        return conn.execute("SELECT 1 FROM trade WHERE id = ? AND book = ?", (int(num), book)).fetchone() is not None
    return False                                     # photo trades come with the photo journal


def _decode(row) -> dict:
    return json.loads(gzip.decompress(row["analysis_json_gz"]))


def links(ref: str) -> dict:
    return {v: f"/api/journal/{ref}/chart.svg?view={v}" for v in VIEWS}


def page_for(a: dict, conn=None) -> dict:
    """The page text, each numbered line marked with the views whose picture draws its number ("on"): the screen
    shows a line's number only on those views, so a line never points at a mark the current picture lacks."""
    page = words.build(a, conn)
    drawn = {}
    for v in VIEWS:
        _svg, layout = picture.render(a, page, v, "dark")
        drawn[v] = {m["number"] for m in layout if m["number"]}
    for ln in page["lines"] + page["after"]:
        ln["on"] = [v for v in VIEWS if ln["n"] and ln["n"] in drawn[v]]
    return page


def tags(conn, cfg, ref: str, now: datetime) -> dict:
    """The tags route's JSON. NotFound for a ref with neither a trade nor a picture."""
    if not REF_RE.fullmatch(ref):
        raise NotFound("no such trade")
    row = _latest(conn, ref)
    if row is None:
        if not _trade_exists(conn, ref):
            raise NotFound("no such trade")
        inp = step.trade_inputs(conn, cfg, ref)
        if inp is None:
            return {"ref": ref, "state": "none", "message": NO_PICTURE}
        if step.given_up(conn, ref, inp):
            return {"ref": ref, "state": "failed", "message": UNDRAWABLE}
        from app.feed.oanda import complete_through
        marker = complete_through(conn)
        if not cfg.feed.enabled or marker is None or int(marker) < step.due_at(inp):
            return {"ref": ref, "state": "waiting", "message": WAIT_FEED}
        return {"ref": ref, "state": "waiting", "message": WAIT_MAKE}
    try:
        a = _decode(row)
        page = page_for(a, conn)
        extra = {"tau": a["tau"], "tau_how": a["tau_how"], "day": a["D"]}
    except Exception:                                # noqa: BLE001  (a row that cannot be read or drawn)
        log.exception("trade picture %s: row %s cannot be drawn", ref, row["id"])
        return {"ref": ref, "state": "failed", "message": UNDRAWABLE}
    return {"ref": ref, "state": "ready", **page, "views": links(ref), "first_view": "5m", **extra,
            "final": bool(row["final"]), "made_utc": row["made_utc"]}


def chart(conn, ref: str, view: str | None, theme: str | None) -> SvgReply:
    """The latest row's picture: its ETag at once, the SVG on render(). NotFound without a row; ValueError for a bad
    view or theme; render() raises Undrawable ("Could not draw this trade") for a row it cannot draw."""
    view = view or "5m"
    theme = theme or "dark"
    if view not in VIEWS:
        raise ValueError("view must be 5m or 15m")
    if theme not in THEMES:
        raise ValueError("theme must be dark or light")
    if not REF_RE.fullmatch(ref):
        raise NotFound("no such trade")
    row = _latest(conn, ref)
    if row is None:
        raise NotFound("no picture yet")
    blob, rid = bytes(row["analysis_json_gz"]), row["id"]
    h = hashlib.sha256()
    for part in (blob, picture.VERSION.encode(), WORDS_VERSION.encode(), view.encode(), theme.encode()):
        h.update(hashlib.sha256(part).digest())

    def render() -> bytes:
        try:
            a = json.loads(gzip.decompress(blob))
            svg, _layout = picture.render(a, words.build(a, None), view, theme)   # numbers need no news
            return svg.encode("utf-8")
        except Exception:                            # noqa: BLE001
            log.exception("trade picture %s: row %s cannot be drawn", ref, rid)
            raise Undrawable(UNDRAWABLE) from None

    return SvgReply('"' + h.hexdigest() + '"', render)


__all__ = ["tags", "chart", "links", "page_for", "REF", "NotFound", "Undrawable", "SvgReply"]
