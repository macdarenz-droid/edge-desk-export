"""The trade picture's page text (docs/JOURNAL_DESIGN.md D11, sections 7.2-7.4): the tag lines under the picture,
made by the server from the stored analysis (journal_analysis), one short line per tag, keyed to the numbered markers
on the picture (picture.py draws the same numbers). Times in the app's own format (app.js hhmm and hm12):
"12:10 London · 11:10 pm Melb." (design D16). The screens place every string with textContent; app.js and
index.html hold none of these words.

Numbers: each kind of mark keeps its number, so a line and its marker always agree:
  1 the POI (T2)   2 the levels taken before the order (T3)   3 the swing that protects the break (T6 b)
  4 the 5m break (T4)   5 the entry gap (T5)   6 the stop (T6)   7 the fill   8 the exit   9 the breaks after it.
The target (T7), the bias (T8) and the session (T1) have no marker: the target is the axis tag "Target".
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from app.timeutil import LONDON, MELBOURNE, NEW_YORK

MID = " · "
ORDER_KNOWN_HEAD = "At your order, "
UNKNOWN_HEAD = "At the fill: your order time is unknown"
SUB = "Only prices before it. Faded marks came after."
SUB_UNKNOWN = "Only prices before the fill. Faded marks came after."
READ_AS = "Marks and lines are how the tested rules read the prices, not facts."
SESSION_LINE = "Session bands use the tested rules' times, not the Today screen's."
SOURCE_LINE = "Prices: OANDA practice mid. MT5 can differ by about 1 pip."
KIND_WORDS = {"FVG1": "1h FVG", "FVG2": "2h FVG", "FVG4": "4h FVG", "OB1": "1h OB", "OB2": "2h OB", "OB4": "4h OB",
              "FVG": "5m gap", "OB": "5m OB"}
SESSION_WORDS = {"asia": "Asia session.", "london": "London session.", "new_york": "New York session."}
EXIT_WORDS = {"sl": "Stopped", "tp": "Target hit", "be": "Closed at the entry", "manual": "Closed", "so": "Stop out",
              "expired": "Closed", "other": "Closed"}


def hhmm(t: int) -> str:
    return datetime.fromtimestamp(int(t), LONDON).strftime("%H:%M")


def hm12(t: int) -> str:
    m = datetime.fromtimestamp(int(t), MELBOURNE)
    return f"{m.hour % 12 or 12}:{m.minute:02d} {'am' if m.hour < 12 else 'pm'}"


def both(t: int) -> str:
    """The app's format (app.js: hhmm(t, LON) + " London" + MID + hm12(t, MELB) + " Melb.")."""
    return f"{hhmm(t)} London{MID}{hm12(t)} Melb."


def level_words(kind: str, side: str) -> str:
    low = side == "L"
    return {"AS": "Asian low" if low else "Asian high",
            "PD": "yesterday's low" if low else "yesterday's high",
            "EQ": "equal lows" if low else "equal highs",
            "HS": "1h swing low" if low else "1h swing high",
            "CRT1": "1h CRT low" if low else "1h CRT high",
            "CRT4": "4h CRT low" if low else "4h CRT high"}.get(kind, "a level")


def cap(s: str) -> str:
    return s[:1].upper() + s[1:]


def pips(x: float) -> str:
    return f"{abs(x):.1f} pip" + ("" if abs(x) == 1.0 or abs(x) < 1.0 else "s")


def r_text(x: float) -> str:
    return ("+" if x > 0 else "−" if x < 0 else "") + f"{abs(x):.1f}R"


def kinds_text(kinds: list[str]) -> str:
    ks = sorted({KIND_WORDS.get(k, k) for k in kinds}, key=lambda k: (-int(k[0]) if k[0].isdigit() else 0, k))
    return " + ".join(ks)


def next_news(conn, decision: int, day_end: int) -> str | None:
    """The next high-impact EUR or USD release from the decision to the day's end, from the app's news store."""
    if conn is None:
        return None
    lo = datetime.fromtimestamp(int(decision), timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    hi = datetime.fromtimestamp(int(day_end), timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        r = conn.execute("SELECT currency, name, event_utc FROM news_event WHERE currency IN ('EUR', 'USD')"
                         " AND impact = 'high' AND time_mode = 'exact' AND event_utc >= ? AND event_utc < ?"
                         " ORDER BY event_utc, id LIMIT 1", (lo, hi)).fetchone()
    except Exception:                                        # noqa: BLE001  (no news store: no news part)
        return None
    if r is None:
        return None
    t = int(datetime.fromisoformat(r[2].replace("Z", "+00:00")).timestamp())
    return f"Next high-impact news: {r[0]} {r[1]} at {both(t)}"


def line(n, key: str, text: str, amber: bool) -> dict:
    text = " ".join(text.split()).replace("Melb..", "Melb.")
    return {"n": n, "key": key, "text": text, "amber": bool(amber)}


def build(a: dict, conn=None) -> dict:
    """The page text of one analysis: heading, sub-heading, tag lines, after lines and notes."""
    tg, tr, aft = a["tags"], a["trade"], a["after"]
    long_ = tr["side"] == "buy"
    unknown = a["tau_how"] == "unknown"
    side_w, opp_w = ("buy", "sell") if long_ else ("sell", "buy")
    lows = "lows" if long_ else "highs"
    swing_w = "higher low" if long_ else "lower high"
    up_w = "up" if long_ else "down"
    before = "before the fill" if unknown else "before your order"     # the cut is at the fill when it is unknown
    lines: list[dict] = []

    def add(n, key, text):
        lines.append(line(n, key, text, unknown))

    # T2 the POI
    t2 = tg["T2"]
    h, f = t2.get("holds"), t2.get("failed")
    where = "above" if long_ else "below"
    if h:
        grade = "wicks only" if h["grade"] == 1 else "lower grade: a 15m body closed inside"
        txt = f"{cap(side_w)} POI ({kinds_text(h['kinds'])}) held: {grade}."
        if f:
            txt += f" The 1st POI {where} it failed at {both(f['failed_t'])}"
        add(1, "poi", txt)
    elif f:
        add(1, "poi", f"{cap(side_w)} POI ({kinds_text(f['kinds'])}) failed at {both(f['failed_t'])}: a 1h body"
                      " closed inside.")
    else:
        add(None, "poi", f"No {side_w} POI touched today {before}.")

    # T3 the levels taken before the order (sell-side for a buy)
    t3 = tg["T3"]
    taken = t3.get("taken") or []
    seen, uniq = set(), []
    for x in taken:                                   # one item a level: its kind, price and time
        key = (x["kind"], x["side"], round(x["level"], 5), x["s"])
        if key not in seen:
            seen.add(key)
            uniq.append(x)
    taken = uniq

    def item(x):
        return f"{level_words(x['kind'], x['side'])} {x['level']:.5f} at {both(x['s'])}"
    if taken:
        brk = [x for x in taken if x["grade"] == "F"]
        swp = [x for x in taken if x["grade"] != "F"]
        part = []
        if brk and not swp:
            part.append(f"{cap(lows)} taken {before} were breaks, not sweeps: " + "; ".join(map(item, brk)) + ".")
        elif swp and not brk:
            part.append(f"{cap(lows)} swept {before} (wick only, held): " + "; ".join(map(item, swp)) + ".")
        else:
            part.append("Swept: " + "; ".join(map(item, swp)) + ". Broken: " + "; ".join(map(item, brk)) + ".")
        if t3.get("both_sides"):
            part.append("Both sides were taken today.")
        add(2, "liq", " ".join(part))
    else:
        add(None, "liq", f"No {lows} taken today {before}.")

    # T6 (b) the swing that protects the break
    t6 = tg["T6"]
    sw = t6.get("swing")
    if sw:
        add(3, "swing", f"{cap(swing_w)} at {both(sw['wick_t'])}")

    # T4 the 5m structure
    t4 = tg["T4"]
    pat = t4["pattern"]
    if pat == "choch_bos":
        add(4, "struct", f"CHoCH {up_w} at {both(t4['choch']['t'])}, then BOS at {both(t4['bos']['t'])}: your"
                         " high-confidence pattern.")
    elif pat == "choch":
        add(4, "struct", f"CHoCH {up_w} at {both(t4['choch']['t'])} No BOS after it yet: your low-confidence"
                         " pattern.")
    elif pat == "continuation":
        add(4, "struct", f"BOS {up_w} at {both(t4['bos']['t'])} after the {opp_w} POI failed: continuation.")
    else:
        add(None, "struct", "No 5m break since the POI or sweep: no break yet.")

    # T5 the entry
    z = tg.get("T5")
    if z:
        what = KIND_WORDS.get(z["kind"], z["kind"])
        mv = z["entry_vs_middle_pips"]
        rel = "at" if mv == 0 else ("above" if (mv > 0) == long_ else "below")
        if z["entry_inside"]:
            txt = f"Entry inside the {what}, {pips(mv)} {rel} its middle." if mv else f"Entry at the middle of the {what}."
        else:
            txt = f"Entry outside the {what}, {pips(mv)} {rel} its middle."
        sync = {"1h": " A 1h gap lines up with it.", "15m": " A 15m gap lines up with it."}.get(z.get("sync"), "")
        if z["kind"] == "FVG" and not sync:
            sync = " No 15m or 1h gap lines up."
        add(5, "entry", txt + sync)
    else:
        add(None, "entry", "No 5m gap or OB on the break leg.")

    # T6 the stop: (b), (a), (c)
    if tr.get("stop") is None or tg.get("stop_pips") is None:
        add(None, "stop", "No first stop on this trade: the stop tags are left out.")
    else:
        part = []
        if sw:
            q = sw["stop_past_quote_pips"]
            if abs(q) < 1.0:
                part.append(f"Stop on the {swing_w} itself: a retest takes it.")
            elif q > 0:
                part.append(f"Stop {pips(q)} past the {swing_w}.")
            else:
                part.append(f"Stop {pips(q)} inside the {swing_w}.")
        if t6.get("past_gap_pips") is not None:
            g = t6["past_gap_pips"]
            part.append(f"{pips(g)} {'past' if g >= 0 else 'inside'} the gap's far edge.")
        near = sorted(t6.get("near") or [], key=lambda x: (x["beyond_stop_pips"] < 0, abs(x["beyond_stop_pips"])))
        for x in near[:3]:                       # the levels past the stop first: a sweep target past it
            w = cap(level_words(x["kind"], "L" if long_ else "S"))
            verb = "sit" if w.endswith("s") else "sits"
            if x["beyond_stop_pips"] >= 0:
                p_ = f"{w} {verb} {pips(x['beyond_stop_pips'])} past your stop."
            else:
                p_ = f"{w} {verb} between your entry and stop."
            if p_ not in part:
                part.append(p_)
        add(6, "stop", " ".join(part) if part else f"Stop {pips(tg['stop_pips'])}.")

    # T7 the target
    t7 = tg["T7"]
    npoi = t7.get("next_poi")
    if t7.get("tp_R") is None:
        add(None, "target", "No target, or no first stop to measure it.")
    elif npoi and npoi.get("dist_R") is not None:
        before = t7["tp_R"] <= npoi["dist_R"]
        add(None, "target", f"Target {t7['tp_R']:.1f}R, {'before' if before else 'past'} the next {opp_w} POI"
                            f" ({npoi['dist_R']:.1f}R){', as your rule says' if before else ''}.")
    else:
        add(None, "target", f"Target {t7['tp_R']:.1f}R. No {opp_w} POI live past the entry.")

    # T8 the bias
    t8 = tg["T8"]
    dw = {"bull": "up", "bear": "down"}
    d, h4 = dw.get(t8["daily"], "flat"), dw.get(t8["h4"], "flat")
    state = {"WITH": f"with your {side_w}", "AGAINST": f"against your {side_w}"}.get(t8["state"], f"mixed for your {side_w}")
    lead = f"Daily and 4h {d}" if d == h4 else f"Daily {d}, 4h {h4}"
    add(None, "bias", f"{lead}: {state} (a confidence point only).")

    # T1 the session and the next news
    D = date.fromisoformat(a["D"])
    news = next_news(conn, a["decision"], int(datetime(D.year, D.month, D.day, 17, tzinfo=NEW_YORK).timestamp()))
    add(None, "session", SESSION_WORDS.get(tg["T1"]["session"], "") + (f" {news}." if news else ""))

    # the minutes between tau and the order
    gap = a.get("gap")
    if gap and a["tau_how"] == "order":
        took = gap.get("taken") or []
        mins = (gap["end"] - gap["start"]) // 60
        if took:
            add(None, "gap", f"In the {mins} min before your order price took "
                             + "; ".join(f"{level_words(x['kind'], x['side'])} at {both(x['at'])}" for x in took) + ".")
        else:
            add(None, "gap", f"In the {mins} min before your order no level was taken.")

    # after the order (T10): never a tag input
    after: list[dict] = []
    fill_t = tr.get("fill_t")
    if fill_t is not None:
        pc, best = aft.get("price_check"), aft.get("best")
        txt = f"Filled {both(fill_t)}"
        if pc is not None:
            txt += " OANDA's price agrees." if pc["off_pips"] <= 1.0 else \
                f" OANDA's {pc['side']} was {pips(pc['off_pips'])} away: check the time."
        else:
            txt += "."
        if best is not None:
            worst = -best["worst_pips"]
            txt += (f" Best move +{best['best_pips']:.1f} pips, worst {'+' if worst > 0 else '−' if worst < 0 else ''}"
                    f"{abs(worst):.1f} pips.")
        after.append(line(7, "fill", txt, False))
    ex = aft.get("exit")
    at_stop = [x for x in aft.get("at_levels") or [] if x["at"] == "stop"]
    if ex:
        txt = f"{EXIT_WORDS.get(ex['kind'], 'Closed')} at {both(ex['t'])}"
        txt += f": {r_text(ex['R'])} before costs." if ex.get("R") is not None else "."
        if at_stop:
            w = level_words(at_stop[0]["kind"], at_stop[0]["side"])
            taken = any(x["s"] is not None and x["s"] <= ex["t"] for x in at_stop)
            took = (" and were taken" if w.endswith("s") else " and was taken") if taken else ""
            txt += f" {cap(w)} formed at your stop after the order{took}."
        after.append(line(8, "exit", txt, False))
    elif fill_t is not None:
        after.append(line(None, "exit", f"Open at {both(aft.get('data_end') or a['tau'])}.", False))
    brk = aft.get("breaks") or []
    if brk:
        names = {"CHOCH": "CHoCH", "BOS": "BOS", "FIRST": "First break"}
        after.append(line(9, "after", "; ".join(f"{names.get(e['kind'], e['kind'])} {'up' if e['dir'] == 'UP' else 'down'}"
                                                f" at {both(e['t'])}" for e in brk[:3]), False))

    notes = [READ_AS, SESSION_LINE, SOURCE_LINE]
    first = a["data"]["first"]
    lo = int(datetime(D.year, D.month, D.day, tzinfo=LONDON).timestamp()) - 100 * 86400
    if first > lo + 86400:
        notes.append(f"Zones from {datetime.fromtimestamp(first, LONDON):%d %b %Y} only: the stored prices start there.")
    head = UNKNOWN_HEAD if unknown else ORDER_KNOWN_HEAD + both(a["decision"])
    return {"heading": head, "sub": SUB_UNKNOWN if unknown else SUB, "amber": unknown, "lines": lines,
            "after": after, "notes": notes}


def all_text(page: dict) -> list[str]:
    """Every string the page shows (the banned-word test scans these)."""
    out = [page["heading"], page["sub"], *page["notes"]]
    out += [x["text"] for x in page["lines"] + page["after"]]
    return out


__all__ = ["build", "both", "all_text"]
