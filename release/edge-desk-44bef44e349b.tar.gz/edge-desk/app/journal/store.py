"""Journal store: read trades with their flags and the owner's choice; write choices and review notes.

Ledgers (app/db.py): opportunity (what the planner found), choice (the owner's decision or own idea),
trade (what actually happened, book 'mt5' or 'paper', never mixed). Every write runs in one
transaction; every input is checked against the same lists the schema enforces.
"""
from __future__ import annotations

import json
import re
import sqlite3
from datetime import date, datetime

from app import db
from app.config import Config
from app.timeutil import now_utc, to_iso

BOOKS = ("mt5", "paper")
TAGS = ("planned", "own_idea", "rule_break")
DECISIONS = ("take", "skip", "modify", "own_idea")
MANAGEMENT = ("close_at_4r", "trail_to_2r")
NOTE_MAX = 2000
_WEEK = re.compile(r"^\d{4}-W(0[1-9]|[1-4]\d|5[0-3])$")


class NotFoundError(LookupError, ValueError):
    """The row asked for does not exist (a LookupError; also a ValueError for simple callers)."""


def _day(value: date | str | None, name: str) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        raise ValueError(f"{name}: give a date, not a time")
    if isinstance(value, date):
        return value.isoformat()
    try:
        return date.fromisoformat(value).isoformat()
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name}: expected YYYY-MM-DD") from exc


def _book(book: str) -> str:
    if book not in BOOKS:
        raise ValueError(f"book must be one of {BOOKS}")
    return book


def _note(note) -> str:
    if not isinstance(note, str):
        raise ValueError("note must be text")
    if len(note) > NOTE_MAX:
        raise ValueError(f"note is longer than {NOTE_MAX} characters")
    return note


def _would_take(value) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int) and value in (0, 1):
        return value
    raise ValueError("would_take must be true, false or empty")


def _bool_or_none(value) -> bool | None:
    return None if value is None else bool(value)


_TRADE_SELECT = """
SELECT t.*, c.id AS choice_id, c.tag AS tag, c.decision AS decision, c.would_take AS would_take,
       c.management AS management, c.note AS note
FROM trade t LEFT JOIN choice c ON c.trade_id = t.id
"""


def _flags(conn: sqlite3.Connection, ids: list[int]) -> dict[int, list[str]]:
    out: dict[int, list[str]] = {i: [] for i in ids}
    if not ids:
        return out
    for chunk in range(0, len(ids), 500):
        part = ids[chunk:chunk + 500]
        q = f"SELECT trade_id, flag FROM trade_flag WHERE trade_id IN ({','.join('?' * len(part))}) ORDER BY flag"
        for row in conn.execute(q, part):
            out[row["trade_id"]].append(row["flag"])
    return out


def _trade_dicts(conn: sqlite3.Connection, rows, linked_alias: str | None = None) -> list[dict]:
    """account_linked: an MT5 trade of the account the bridge is linked to now (config account.alias), False for
    another account's trade after a switch (deploy/install/account.py), None when not known (no config given)."""
    rows = [dict(r) for r in rows]
    flags = _flags(conn, [r["id"] for r in rows])
    for r in rows:
        r["flags"] = flags[r["id"]]
        r["would_take"] = _bool_or_none(r["would_take"])
        r["account_linked"] = (None if linked_alias is None or r["book"] != "mt5"
                               else r["account_alias"] == linked_alias)
    return rows


def list_trades(conn: sqlite3.Connection, cfg: Config, book: str = "mt5", start_day: date | str | None = None,
                end_day: date | str | None = None, eurusd_only: bool = True) -> list[dict]:
    """Trades of one book, oldest open first, each with `flags` and the choice fields.

    A trade is in [start_day, end_day] when its open trading day OR its close trading day is inside
    the range, so a trade that closes in the next month still shows in that month's calendar.
    """
    _book(book)
    start, end = _day(start_day, "start_day"), _day(end_day, "end_day")
    where, args = ["t.book = ?"], [book]
    if start is not None and end is not None:
        where.append("((t.trading_day BETWEEN ? AND ?) OR (t.close_trading_day BETWEEN ? AND ?))")
        args += [start, end, start, end]
    elif start is not None:
        where.append("(t.trading_day >= ? OR t.close_trading_day >= ?)")
        args += [start, start]
    elif end is not None:
        where.append("(t.trading_day <= ? OR t.close_trading_day <= ?)")
        args += [end, end]
    if eurusd_only:
        syms = list(cfg.instrument.broker_symbols)
        where.append(f"t.symbol IN ({','.join('?' * len(syms))})")
        args += syms
    rows = conn.execute(_TRADE_SELECT + " WHERE " + " AND ".join(where) + " ORDER BY t.open_utc, t.id", args)
    return _trade_dicts(conn, rows, cfg.account.alias)


def get_trade(conn: sqlite3.Connection, trade_id: int) -> dict | None:
    rows = _trade_dicts(conn, conn.execute(_TRADE_SELECT + " WHERE t.id = ?", (trade_id,)))
    return rows[0] if rows else None


def _default_decision(conn: sqlite3.Connection, trade_id: int, tag: str) -> str:
    linked = conn.execute("""SELECT 1 FROM trade t JOIN paper_order p ON p.id = t.paper_order_id
                             WHERE t.id = ? AND p.opportunity_id IS NOT NULL""", (trade_id,)).fetchone()
    if linked or tag == "planned":
        return "take"
    return "own_idea"


def set_choice(conn: sqlite3.Connection, trade_id: int, tag: str, decision: str | None = None,
               would_take: bool | None = None, management: str | None = None, note: str = "",
               now: datetime | None = None) -> dict:
    """Create or update the one choice row of a trade; returns the trade (as list_trades shows it).

    decision None keeps the earlier decision, or for a new row: 'take' when the trade came from a
    planner opportunity or is tagged planned, else 'own_idea'.
    """
    if tag not in TAGS:
        raise ValueError(f"tag must be one of {TAGS}")
    if decision is not None and decision not in DECISIONS:
        raise ValueError(f"decision must be one of {DECISIONS}")
    if management is not None and management not in MANAGEMENT:
        raise ValueError(f"management must be one of {MANAGEMENT}")
    wt = _would_take(would_take)
    note = _note(note)
    with db.transaction(conn):
        if conn.execute("SELECT 1 FROM trade WHERE id = ?", (trade_id,)).fetchone() is None:
            raise NotFoundError(f"trade {trade_id} not found")
        row = conn.execute("SELECT id, decision FROM choice WHERE trade_id = ?", (trade_id,)).fetchone()
        if row is None:
            dec = decision or _default_decision(conn, trade_id, tag)
            conn.execute("""INSERT INTO choice (created_utc, trade_id, decision, tag, would_take, management, note)
                            VALUES (?,?,?,?,?,?,?)""",
                         (to_iso(now or now_utc()), trade_id, dec, tag, wt, management, note))
        else:
            dec = decision or row["decision"]
            conn.execute("UPDATE choice SET decision = ?, tag = ?, would_take = ?, management = ?, note = ?"
                         " WHERE id = ?", (dec, tag, wt, management, note, row["id"]))
    return get_trade(conn, trade_id)


def record_choice_for_opportunity(conn: sqlite3.Connection, opportunity_id: int, decision: str, tag: str,
                                  would_take: bool | None = None, note: str = "",
                                  now: datetime | None = None) -> int:
    """The owner's choice on a planner opportunity (taken, skipped or changed). One row per opportunity:
    a second call updates it. Returns the choice id."""
    if decision not in DECISIONS:
        raise ValueError(f"decision must be one of {DECISIONS}")
    if tag not in TAGS:
        raise ValueError(f"tag must be one of {TAGS}")
    wt = _would_take(would_take)
    note = _note(note)
    with db.transaction(conn):
        if conn.execute("SELECT 1 FROM opportunity WHERE id = ?", (opportunity_id,)).fetchone() is None:
            raise NotFoundError(f"opportunity {opportunity_id} not found")
        row = conn.execute("SELECT id FROM choice WHERE opportunity_id = ? ORDER BY id DESC LIMIT 1",
                           (opportunity_id,)).fetchone()
        if row is None:
            cur = conn.execute("""INSERT INTO choice (created_utc, opportunity_id, decision, tag, would_take, note)
                                  VALUES (?,?,?,?,?,?)""",
                               (to_iso(now or now_utc()), opportunity_id, decision, tag, wt, note))
            return cur.lastrowid
        conn.execute("UPDATE choice SET decision = ?, tag = ?, would_take = ?, note = ? WHERE id = ?",
                     (decision, tag, wt, note, row["id"]))
        return row["id"]


def opportunity_dict(row) -> dict:
    d = dict(row)
    d["offered"] = bool(d["offered"])
    d["checklist"] = json.loads(d.pop("checklist_json") or "[]")
    if "would_take" in d:
        d["would_take"] = _bool_or_none(d["would_take"])
    return d


def list_opportunities(conn: sqlite3.Connection, day: date | str) -> list[dict]:
    """Every opportunity of a trading day (offered or not) with the owner's latest choice on it."""
    d = _day(day, "day")
    rows = conn.execute("""
        SELECT o.*, c.id AS choice_id, c.decision AS decision, c.tag AS tag, c.would_take AS would_take,
               c.note AS note
        FROM opportunity o
        LEFT JOIN choice c ON c.id = (SELECT MAX(id) FROM choice WHERE opportunity_id = o.id)
        WHERE o.trading_day = ? ORDER BY o.id""", (d,))
    return [opportunity_dict(r) for r in rows]


def _week(week: str) -> str:
    if not isinstance(week, str) or not _WEEK.match(week):
        raise ValueError("week must look like 2026-W42")
    return week


def set_review_note(conn: sqlite3.Connection, week: str, text: str, now: datetime | None = None) -> dict:
    """Set the one action item of an ISO week (replaces the earlier one)."""
    week, text = _week(week), _note(text)
    with db.transaction(conn):
        conn.execute("""INSERT INTO review_note (week, action_item, created_utc) VALUES (?,?,?)
                        ON CONFLICT(week) DO UPDATE SET action_item = excluded.action_item""",
                     (week, text, to_iso(now or now_utc())))
    return get_review_note(conn, week)


def get_review_note(conn: sqlite3.Connection, week: str) -> dict | None:
    row = conn.execute("SELECT week, action_item, created_utc FROM review_note WHERE week = ?",
                       (_week(week),)).fetchone()
    return dict(row) if row else None
