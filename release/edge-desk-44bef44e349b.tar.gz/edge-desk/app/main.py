"""Command line.

  python3 -m app serve [--config PATH] [--host H] [--port N]   run the web server and the alert schedule
  python3 -m app check [--config PATH]                          config valid, which secrets are set (yes/no),
                                                                journal opens
  python3 -m app bridge-status [--config PATH]                  latest bridge state and snapshot summary
  python3 -m app headlines [--config PATH] [--once] [--reset-halt]
                                                                the Fed and ECB headline feeds (app/news/headlines.py)
  python3 -m app feed [--reset-halt] [--reset-record]           the OANDA feed (B1) and, inside it, the one-off move
                                                                record (app/news/moverecord.py)
  python3 -m app aplus [--config PATH] [--once]               the A+ short's step (app/aplus): --once runs one step now
                                                                and prints its status line (it runs inside the method
                                                                worker; without --once, the step alone in a loop, only
                                                                with [aplus] run_in = "own"); run it as the app's user
  python3 -m app vapid-keygen --out FILE                        a new Web Push (VAPID) private key in FILE
                                                                (mode 0600, never overwritten); prints the
                                                                public key and the variable to set
Secrets are only ever reported as yes/no. Times for the owner are Melbourne time.
"""
from __future__ import annotations

import argparse
import logging
import os
import shlex
import signal
import sys
import threading
from pathlib import Path
from typing import TextIO

from app.config import SECRET_ENV, SUBJECT_ENV, ConfigError, load
from app.db import connect
from app.ingest.state import latest_snapshot
from app.ingest.status import bridge_state
from app.notify import push
from app.timeutil import fmt_melbourne, from_iso, now_utc
from app.web.server import EdgeServer, make_server

__all__ = ["EdgeServer", "main"]


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="python3 -m app", description="Edge Desk: personal EUR/USD journal")
    sub = p.add_subparsers(dest="command", required=True)
    serve = sub.add_parser("serve", help="run the web server and the alert schedule")
    serve.add_argument("--config", default=None)
    serve.add_argument("--host", default=None)
    serve.add_argument("--port", type=int, default=None)
    for name, text in (("check", "check config, secrets (yes/no) and the journal"),
                       ("bridge-status", "show the latest bridge state")):
        sp = sub.add_parser(name, help=text)
        sp.add_argument("--config", default=None)
    mt = sub.add_parser("maintain", help="storage check, prune and the daily backup (run by the systemd timer)")
    mt.add_argument("--config", default=None)
    fd = sub.add_parser("feed", help="the OANDA practice candle feed (B1), runs until stopped")
    fd.add_argument("--config", default=None)
    fd.add_argument("--reset-halt", action="store_true", help="clear a halt after 3 failures that were not 5xx")
    fd.add_argument("--reset-record", action="store_true", help="let the move record job try again after a halt")
    hl = sub.add_parser("headlines", help="the Fed and ECB headline feeds, runs until stopped")
    hl.add_argument("--config", default=None)
    hl.add_argument("--once", action="store_true",
                    help="one pass over the feeds that are due, then stop (not while the service runs)")
    hl.add_argument("--reset-halt", action="store_true",
                    help="clear the feeds' halts (a server's Retry-After and the cool-downs run out by themselves)")
    mw = sub.add_parser("method-worker", help="your method's suggestions, the export and links (B2, B5)")
    mw.add_argument("--config", default=None)
    mw.add_argument("--once", action="store_true", help="one step, then stop")
    lw = sub.add_parser("lead-worker", help="the three paper leads from STATS's pinned code (B3)")
    lw.add_argument("--config", default=None)
    lw.add_argument("--once", action="store_true", help="one step, then stop")
    lw.add_argument("--bundle", default="/opt/edge-desk/lead-bundle", help="the pinned copy (deploy/make_lead_bundle.py)")
    ap = sub.add_parser("aplus", help="the A+ short's step (paper only; it runs inside the method worker)")
    ap.add_argument("--config", default=None)
    ap.add_argument("--once", action="store_true", help="one step now, then print its status line")
    keygen = sub.add_parser("vapid-keygen", help="write a new Web Push private key to a file")
    keygen.add_argument("--out", required=True, help="file to create (mode 0600); an existing file is kept")
    return p


def _yes(flag) -> str:
    return "yes" if flag else "no"


def _load(args, env, out: TextIO):
    try:
        return load(args.config, env=env)
    except (ConfigError, OSError, ValueError, KeyError) as exc:
        # ConfigError messages name the key or variable, never a secret value.
        print(f"config: error: {exc}", file=out)
        return None


def cmd_check(args, env, out: TextIO) -> int:
    cfg = _load(args, env, out)
    if cfg is None:
        return 2
    print("config: ok", file=out)
    for name, present in cfg.secrets.present().items():
        print(f"{name}: {_yes(present)} ({SECRET_ENV[name]})", file=out)
    configured, library = cfg.secrets.push_configured, push.library_available()
    print(f"push: configured {_yes(configured)} ({SECRET_ENV['vapid_private_key']} and {SUBJECT_ENV})", file=out)
    print(f"pywebpush: importable {_yes(library)}", file=out)
    try:
        conn = connect(cfg.app.db_path)
        conn.execute("SELECT COUNT(*) FROM trade").fetchone()
        devices = push.count_subscriptions(conn)
        conn.close()
    except Exception as exc:  # noqa: BLE001
        print(f"db: error: {type(exc).__name__}: {exc}", file=out)
        return 2
    print(f"db: ok ({cfg.app.db_path})", file=out)
    print(f"push devices: {devices}", file=out)
    if configured and not library:
        print("push: error: pywebpush is not installed (pip install --require-hashes -r requirements.txt)", file=out)
        return 2
    return 0


def cmd_vapid_keygen(args, env, out: TextIO) -> int:
    """A new VAPID private key into a new file (mode 0600). Prints only the public key and what to set."""
    path = Path(os.path.abspath(Path(args.out).expanduser()))
    try:
        key = push.generate_private_key()
        public = push.public_key_b64url(key)
    except ImportError as exc:
        print(f"vapid-keygen: error: {exc} (pip install --require-hashes -r requirements.txt)", file=out)
        return 2
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        print(f"vapid-keygen: error: {path} exists; it is kept as it is (choose another file)", file=out)
        return 2
    except OSError as exc:
        print(f"vapid-keygen: error: {type(exc).__name__}: {exc.strerror}", file=out)
        return 2
    try:
        os.fchmod(fd, 0o600)
        os.write(fd, (key + "\n").encode("ascii"))
    finally:
        os.close(fd)
    print(f"public key: {public}", file=out)
    print(f"export {SECRET_ENV['vapid_private_key']}=\"$(cat {shlex.quote(str(path))})\"", file=out)
    return 0


def cmd_bridge_status(args, env, out: TextIO) -> int:
    cfg = _load(args, env, out)
    if cfg is None:
        return 2
    conn = connect(cfg.app.db_path)
    try:
        st = bridge_state(conn, cfg, now_utc())
        snap = latest_snapshot(conn, cfg.account.alias)
    finally:
        conn.close()
    print(f"alias: {st['alias']}", file=out)
    print(f"state: {st['state']}", file=out)
    if st["last_seen_utc"]:
        print(f"last snapshot: {fmt_melbourne(from_iso(st['last_seen_utc']))} Melbourne ({st['age_s']} s ago)",
              file=out)
        print(f"seq: {st['seq']}", file=out)
    if snap:
        acct = snap["account"]
        print(f"balance: {acct['balance']} {acct['currency']}", file=out)
        print(f"equity: {acct['equity']} {acct['currency']}", file=out)
        print(f"positions: {len(snap['positions'])}", file=out)
        print(f"orders: {len(snap['orders'])}", file=out)
        print(f"trade_allowed: {_yes(acct['trade_allowed'])}", file=out)
        print(f"terminal connected: {_yes(snap['terminal']['connected'])}", file=out)
    return 0


def cmd_serve(args, env, out: TextIO) -> int:
    cfg = _load(args, env, out)
    if cfg is None:
        return 2
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    conn = connect(cfg.app.db_path)
    try:
        server = make_server(cfg, conn, args.host, args.port, env=env)
    except (ValueError, OSError, ImportError) as exc:   # TLS files, port in use, pywebpush missing; no secret
        print(f"serve: error: {type(exc).__name__}: {exc}", file=out)
        conn.close()
        return 2
    server.start_monitor()
    present = cfg.secrets.present()
    print(f"Edge Desk on {server.url} (started {fmt_melbourne(now_utc())} Melbourne)", file=out)
    print("secrets: " + ", ".join(f"{k} {_yes(v)}" for k, v in present.items()), file=out)
    print(f"push: configured {_yes(cfg.secrets.push_configured)}", file=out)
    out.flush()

    def _stop(signum, frame):   # SIGTERM (systemd stop) ends the server like Ctrl+C
        raise KeyboardInterrupt

    old = signal.signal(signal.SIGTERM, _stop) if threading.current_thread() is threading.main_thread() else None
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        if old is not None:
            signal.signal(signal.SIGTERM, old)
        server.stop_monitor()
        server.server_close()
        conn.close()
    return 0


def cmd_maintain(args, env, out: TextIO) -> int:
    from app import storage
    cfg = _load(args, env, out)
    if cfg is None:
        return 2
    conn = connect(cfg.app.db_path)
    try:
        for line in storage.maintain(conn, cfg, now_utc()):
            print(line, file=out)
    finally:
        conn.close()
    return 0


def cmd_feed(args, env, out: TextIO) -> int:
    from app.feed.oanda import run_forever
    cfg = _load(args, env, out)
    if cfg is None:
        return 2
    if getattr(args, "reset_halt", False):
        from app.feed.oanda import reset_halt
        conn = connect(cfg.app.db_path)
        reset_halt(conn)
        conn.close()
        print("feed: halt cleared", file=out)
        return 0
    if getattr(args, "reset_record", False):
        from app.news.moverecord import reset_halt as reset_record
        conn = connect(cfg.app.db_path)
        reset_record(conn)
        conn.close()
        print("feed: move record may try again", file=out)
        return 0
    if not cfg.feed.enabled or not cfg.secrets.oanda_token:
        print("feed: off (set feed.enabled = true and EDGE_OANDA_TOKEN in the server's environment)", file=out)
        return 2
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    conn = connect(cfg.app.db_path)
    try:
        run_forever(conn, cfg, cfg.secrets.oanda_token)
    except KeyboardInterrupt:
        pass
    finally:
        conn.close()
    return 0


def cmd_headlines(args, env, out: TextIO) -> int:
    from datetime import datetime, timezone
    from app.news import headlines
    cfg = _load(args, env, out)
    if cfg is None:
        return 2
    conn = connect(cfg.app.db_path)
    lock = None
    try:
        if args.reset_halt:
            headlines.reset_halt(conn)
            print("headlines: halts cleared", file=out)
            return 0
        if not cfg.headlines.enabled or not cfg.headlines.sources:
            print("headlines: off (config)", file=out)
            return 0
        # One headlines process at a time (red team M8): the service and `--once` share a lock file next to the
        # journal, so two processes never race the 10 s gap per host. The service waits for it; --once does not.
        import fcntl
        lock = open(Path(cfg.app.db_path).parent / "headlines.lock", "a")
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | (fcntl.LOCK_NB if args.once else 0))
        except BlockingIOError:
            lock.close()
            print("headlines: already running (the edge-desk-headlines service); nothing fetched", file=out)
            return 1
        if args.once:
            from app.notify.alerts import queue_alert
            client = headlines.Client(conn, timeout_s=cfg.headlines.timeout_s)
            now = datetime.now(timezone.utc)
            for source in cfg.headlines.sources:
                r = headlines.poll(conn, cfg, client, source, now, lambda a: queue_alert(conn, a, now))
                print(f"headlines: {source} {r}", file=out)
            return 0
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
        headlines.run_forever(conn, cfg)
    except KeyboardInterrupt:
        pass
    finally:
        if lock is not None:
            lock.close()                        # closing the file lets the lock go
        conn.close()
    return 0


def cmd_method_worker(args, env, out: TextIO) -> int:
    from app.suggest import service
    cfg = _load(args, env, out)
    if cfg is None:
        return 2
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    conn = connect(cfg.app.db_path)
    try:
        if args.once:
            r = service.method_step(conn, cfg, now_utc())
            print(f"method worker: {r['queued']} alerts queued, {r['links']} links,"
                  f" export {(r['export'] or {}).get('status', 'off')}", file=out)
        else:
            service.run_method_forever(conn, cfg)
    except KeyboardInterrupt:
        pass
    finally:
        conn.close()
    return 0


def cmd_lead_worker(args, env, out: TextIO) -> int:
    from pathlib import Path as _P
    from app.suggest import bundle, service
    cfg = _load(args, env, out)
    if cfg is None:
        return 2
    try:
        bundle.verify(_P(args.bundle))
    except bundle.BundleRefused as exc:
        print(f"lead worker: the pinned bundle is refused: {exc}", file=out)
        return 2
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    conn = connect(cfg.app.db_path)
    cal_root = _P(cfg.app.db_path).parent / "calendar"
    try:
        if args.once:
            r = service.lead_step(conn, cfg, now_utc(), _P(args.bundle), cal_root, last_pull={})
            print(f"lead worker: {r['status']}", file=out)
        else:
            service.run_leads_forever(conn, cfg, _P(args.bundle), cal_root)
    except KeyboardInterrupt:
        pass
    finally:
        conn.close()
    return 0


# The hand run on the server (deploy/README.md section 9): as the app's user, with the journal path of its env file.
APLUS_HAND_RUN = ("cd /opt/edge-desk && sudo -u edge env \"$(grep '^EDGE_DB_PATH=' /etc/edge-desk/env)\" "
                  ".venv/bin/python -m app aplus --once")


def _owner_of(path) -> int | None:
    """The user id that owns the journal file, or None when there is no file yet."""
    try:
        return os.stat(path).st_uid
    except OSError:
        return None


def cmd_aplus(args, env, out: TextIO) -> int:
    from app.aplus.step import AplusStep, status_line
    from app.suggest import service
    cfg = _load(args, env, out)
    if cfg is None:
        return 2
    if not cfg.aplus.enabled:
        print("A+ step: off (config [aplus] enabled = false)", file=out)
        return 0
    if not args.once and cfg.aplus.run_in != "own":
        print('A+ step: it runs inside the method worker ([aplus] run_in = "method"); --once runs one step by hand',
              file=out)
        return 2
    owner = _owner_of(cfg.app.db_path)
    if os.geteuid() == 0 and owner not in (None, 0):
        print("A+ step: not as root (files root makes beside the journal would stop the app). As the app's user: "
              + APLUS_HAND_RUN, file=out)
        return 2
    conn = connect(cfg.app.db_path)
    try:
        if args.once:
            r = AplusStep(conn, cfg).run(now_utc())
            print(status_line(r), file=out)
            return 1 if r.get("status") in ("error", "busy") else 0
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
        service.run_aplus_forever(conn, cfg)
    except KeyboardInterrupt:
        pass
    finally:
        conn.close()
    return 0


def main(argv: list[str] | None = None, env=None, out: TextIO | None = None) -> int:
    args = _parser().parse_args(argv)
    env = os.environ if env is None else env
    out = out or sys.stdout
    if args.command == "check":
        return cmd_check(args, env, out)
    if args.command == "bridge-status":
        return cmd_bridge_status(args, env, out)
    if args.command == "vapid-keygen":
        return cmd_vapid_keygen(args, env, out)
    if args.command == "maintain":
        return cmd_maintain(args, env, out)
    if args.command == "feed":
        return cmd_feed(args, env, out)
    if args.command == "headlines":
        return cmd_headlines(args, env, out)
    if args.command == "method-worker":
        return cmd_method_worker(args, env, out)
    if args.command == "lead-worker":
        return cmd_lead_worker(args, env, out)
    if args.command == "aplus":
        return cmd_aplus(args, env, out)
    return cmd_serve(args, env, out)


if __name__ == "__main__":   # pragma: no cover
    raise SystemExit(main())

