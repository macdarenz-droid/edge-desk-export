"""EUR and USD economic news from the MT5 terminal's own calendar (MetaQuotes'), sent by the read-only EdgeBridge EA
over loopback (contract edge-calendar/2, or /1 from EA 1.10; bridge/CONTRACT.md). The app makes no request of its own
for calendar numbers; the headlines worker (its own process) fetches only the Fed's and the ECB's own feeds.

  schema.py      validate one post (every key required, no other key, errors that never echo a value)
  store.py       apply_calendar: the post replaces its window's rows in news_event (schema 5); fmt_value; state
  families.py    the pinned families table (MT5 names only) and the read: MT5's own label, else the textbook sign
  moverecord.py  the past move record, built once on the server inside the OANDA feed (ruling R7); never shipped
  records.py     the record as the screens and the news_soon alert show it (size only, either way)
  views.py       the news blocks of /api/today, /api/calendar and /api/settings
  alerts.py      the monitor step: news_soon before each high-impact release, news_result when its number is out
  headlines.py   the Fed and ECB headline feeds (python -m app headlines), Today's headlines and their alert
Rows are third-party data, kept news.keep_days and headlines.keep_days (app/storage.py), never exported, never shared.
"""
