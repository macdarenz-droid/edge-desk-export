"""The monitor's news step: news_soon before a release, news_result once its number is out.

Read from news_event only (serve never fetches news). A release qualifies when its time is exact, it is not a
holiday, its impact is in news.alert_impacts and its currency in news.currencies.

news_soon (priority 3): one alert per currency and release minute (key news_soon:<release epoch>:<currency>), due
after now and at most news.alert_before_min away; it lists every qualifying name of that minute, the lead row's
forecast and previous, and, when the lead row has a past move record, its size: "hour move either way 2016-21:
median <m> pips, quiet day <q>" (never a direction), after the lead row's name (as in the names list, one colon a
part) when the minute has several rows and
with ", often shares its hour" when the record says so (fix round 2). Its "in N min" title is set again when the
alert is sent (send_title); a send after the release is dropped. A queued one whose release has passed is marked skipped.

news_result (priority 3, news.result_alerts): one alert per currency and release minute (key
news_result:<currency>:<release epoch>) when the first number is out, from the release to 15 minutes after it. The
title is the lead row's number; the body its forecast and previous, the read (MT5's own label, or the untested
textbook read) and "+k more". It never carries a size figure, so a size never sits beside a direction or a released
number. A queued one more than 30 minutes after its release is marked skipped; its push expires in 15 minutes.

Lead row: the first of the minute in app/news/families.py's table order; rows with no family come last, by name.
Upgrade from part 1 (keys news_soon:<epoch>:mt5:<id>, one per row): a part 1 alert still queued is skipped and the
per-currency one goes instead; one already sent stops the new one for that currency and minute (fix round 1).
The tap opens Today. No quiet hours: the owner is awake at night (CLAUDE.md "Awake at night").
"""
from __future__ import annotations

import math
import sqlite3
from datetime import datetime, timedelta
from typing import Callable

from app import db
from app.news import families, records
from app.news.store import state
from app.notify.alerts import Alert
from app.timeutil import fmt_melbourne_12, from_iso, to_iso

PRIORITY = 3
KIND = "news_soon"
RESULT_KIND = "news_result"
RESULT_WINDOW_MIN = 15
RESULT_SKIP_MIN = 30
TITLE_MAX = 64


def _what(row) -> str:
    return f"{row['country']} {row['name']}" if row["country"] else row["name"]


def _lead_key(row):
    f = families.family_of(row["country"], row["name"])
    return (families.ORDER[f.key] if f else len(families.ORDER), row["name"], row["id"] if "id" in row.keys() else 0)


def _groups(rows) -> list[list]:
    by: dict[tuple, list] = {}
    for r in rows:
        by.setdefault((r["currency"], r["event_utc"]), []).append(r)
    return [sorted(g, key=_lead_key) for _, g in sorted(by.items(), key=lambda kv: (kv[0][1], kv[0][0]))]


def _title(currency: str, left_min: int) -> str:
    return f"{currency} news in {left_min} min"


def news_soon(cfg, row, now: datetime, stale_since: datetime | str | None, more=(), record: dict | None = None) -> Alert:
    """The alert for one release minute of one currency: `row` is the lead row, `more` the other rows of that
    minute. stale_since: when the EA last sent the calendar, given only while the list is stale."""
    event = from_iso(row["event_utc"])
    left = max(1, math.ceil((event - now).total_seconds() / 60))
    names = ", ".join([_what(row)] + [_what(r) for r in more])
    impact = "high" if any(r["impact"] == "high" for r in (row, *more)) else row["impact"]
    parts = [names, f"{impact} impact", f"{fmt_melbourne_12(event)} Melbourne"]
    nums = []
    if row["forecast"]:
        nums.append(f"forecast {row['forecast']}")
    prev = row["revised"] if row["revised"] is not None else row["previous"]
    if prev:
        nums.append(f"previous {prev}")
    # with several rows, the lead row's parts are named as in the names list (country first), one colon a part
    # (fix round 3, red team minor: "Retail Sales m/m: hour move either way 2016-21: median ..." had two)
    if nums and more:
        parts.append(f"{_what(row)}: " + ", ".join(nums))
    else:
        parts += nums
    if record is not None:                     # the lead row's own record: named when the minute has several rows
        part = records.soon_part(record)
        parts.append(f"{_what(row)} {part}" if more else part)
    if stale_since is not None:
        since = from_iso(stale_since) if isinstance(stale_since, str) else stale_since
        parts.append(f"news list not updated since {fmt_melbourne_12(since)}")
    return Alert(f"{KIND}:{int(event.timestamp())}:{row['currency']}", KIND, PRIORITY,
                 _title(row["currency"], left), " · ".join(parts))


def send_title(key: str, title: str, now: datetime) -> str | None:
    """The news_soon title at the moment of sending: the minutes left then, or None once the release is out."""
    try:
        _, epoch, currency = key.split(":")
        left = math.ceil((int(epoch) - now.timestamp()) / 60)
    except (ValueError, TypeError):
        return title
    return _title(currency, left) if left >= 1 else None


def news_result(row, more=()) -> Alert:
    """The alert for the first number of one currency's release minute (lead row and the others)."""
    event = from_iso(row["event_utc"])
    actual = row["actual"]
    room = TITLE_MAX - len(f"{row['currency']} : {actual}")
    title = f"{row['currency']} {row['name'][:max(room, 1)].rstrip()}: {actual}"
    parts = []
    if row["forecast"]:
        parts.append(f"forecast {row['forecast']}")
    prev = row["revised"] if row["revised"] is not None else row["previous"]
    if prev:
        parts.append(f"previous {prev}")
    text = families.read(row)["text"]
    if text:
        for lead in families.SURPRISE_TEXT.values():         # only a leading surprise word, never "USD-negative"
            if text.startswith(lead):
                text = lead[0].lower() + text[1:]
                break
        parts.append(text)
    parts.append("from MT5")
    if more:
        parts.append(f"+{len(more)} more")
    return Alert(f"{RESULT_KIND}:{row['currency']}:{int(event.timestamp())}", RESULT_KIND, PRIORITY, title[:TITLE_MAX],
                 " · ".join(parts))


def _key_epoch(key: str) -> int | None:
    try:
        return int(key.split(":")[1])
    except (IndexError, ValueError):
        return None


def _legacy(conn, now: datetime) -> set:
    """Part 1 news_soon alerts (key news_soon:<epoch>:mt5:<id>): skip the queued ones, and return (epoch, currency)
    of the ones already sent, so the per-currency alert for that minute does not go twice at the upgrade."""
    queued, sent = [], set()
    for r in conn.execute("SELECT id, key, status FROM alert WHERE kind = ? AND key LIKE 'news_soon:%:mt5:%'", (KIND,)):
        if r["status"] == "queued":
            queued.append(r["id"])
            continue
        _, epoch, source, sid = r["key"].split(":", 3)
        if int(epoch) > now.timestamp():
            ev = conn.execute("SELECT currency FROM news_event WHERE source = ? AND source_id = ?",
                              (source, sid)).fetchone()
            sent.add((int(epoch), ev["currency"] if ev else None))
    _skip(conn, queued, "replaced by the alert for its currency")
    return sent


def _skip(conn, ids: list[int], why: str) -> None:
    if ids:
        with db.transaction(conn):
            conn.executemany("UPDATE alert SET status = 'skipped', last_error = ? WHERE id = ? AND status = 'queued'",
                             [(why, i) for i in ids])


def step(conn: sqlite3.Connection, cfg, now: datetime, q: Callable) -> None:
    n = cfg.news
    if not n.enabled:
        return
    _skip(conn, [r["id"] for r in conn.execute("SELECT id, key FROM alert WHERE kind = ? AND status = 'queued'", (KIND,))
                 if (_key_epoch(r["key"]) or 0) <= now.timestamp()], "release time passed")
    late = now.timestamp() - RESULT_SKIP_MIN * 60
    _skip(conn, [r["id"] for r in conn.execute("SELECT id, key FROM alert WHERE kind = ? AND status = 'queued'",
                                               (RESULT_KIND,)) if int(r["key"].rsplit(":", 1)[1]) < late],
          "release time passed")
    if not n.alert_impacts:
        return
    imp, cur = ",".join("?" * len(n.alert_impacts)), ",".join("?" * len(n.currencies))
    base = (f"SELECT * FROM news_event WHERE time_mode = 'exact' AND kind != 'holiday' AND impact IN ({imp})"
            f" AND currency IN ({cur})")
    last = state(conn)["last_ok_utc"]
    stale = last is not None and (now - from_iso(last)).total_seconds() > n.stale_after_min * 60
    rows = conn.execute(base + " AND event_utc > ? AND event_utc <= ? ORDER BY event_utc, id",
                        (*n.alert_impacts, *n.currencies, to_iso(now),
                         to_iso(now + timedelta(minutes=n.alert_before_min)))).fetchall()
    recs = records.load(records.var_of(cfg)) if n.show_record else records.RecordSet()
    sent_before = _legacy(conn, now)
    for g in _groups(rows):
        epoch = int(from_iso(g[0]["event_utc"]).timestamp())
        if (epoch, g[0]["currency"]) in sent_before or (epoch, None) in sent_before:
            continue
        key = families.record_key(g[0]) if recs.rows else None
        rec = records.shown(recs.rows[key]) if key in recs.rows else None
        q(news_soon(cfg, g[0], now, last if stale else None, g[1:], rec))
    if not n.result_alerts:
        return
    out = conn.execute(base + " AND actual IS NOT NULL AND event_utc <= ? AND event_utc >= ? ORDER BY event_utc, id",
                       (*n.alert_impacts, *n.currencies, to_iso(now),
                        to_iso(now - timedelta(minutes=RESULT_WINDOW_MIN)))).fetchall()
    for g in _groups(out):
        q(news_result(g[0], g[1:]))
