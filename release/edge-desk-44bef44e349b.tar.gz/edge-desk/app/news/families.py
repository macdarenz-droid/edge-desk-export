"""Event families: which MT5 calendar row is which release, its usual sign, its past record, and the read.

A row belongs to the first family whose country set holds its country and whose pattern matches norm(name)
(lowercase, "-" deleted, spaces collapsed; patterns anchored). MT5 names only: ForexFactory is not a source. The
names are MetaQuotes' page titles as read in search excerpts or remembered, NOT verified on a terminal; a wrong or
missing name gives no family (the row shows only its values), never another event's record.

Sign: +1 = a number above the MT5 forecast is positive for the row's currency; -1 = inverted (unemployment, claims);
0 = no number (text events). The sign is the textbook convention, not a measurement.

The read (coordinator ruling R2), shown only once the actual is out:
- MetaQuotes' own label when MT5 gives one (MqlCalendarValue.impact_type positive or negative, the EA's "impact"),
  named as MT5's read;
- else the textbook read from the sign table, named "untested textbook read".
Both say which way the release points the currency, then EUR/USD (USD-positive: EUR/USD lower). No probability, and
never in the same alert as a size figure (app/news/alerts.py).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from zoneinfo import ZoneInfo

NY, BERLIN, LUX = "America/New_York", "Europe/Berlin", "Europe/Luxembourg"


@dataclass(frozen=True)
class Family:
    key: str
    countries: frozenset
    pattern: re.Pattern
    sign: int
    record: str | None = None            # the record's event type (app/news/moverecord.py)
    zone: str | None = None              # clock guard for the record: the row's time in this zone ...
    clock: tuple = ()                    # ... must be one of these (HH:MM)
    flash_days: bool = False             # EZ CPI: the record only on a flash day (day 1-7 or 28-31)


def _f(key, countries, pattern, sign, record=None, zone=None, clock=(), flash_days=False) -> Family:
    return Family(key, frozenset(countries.split()), re.compile(rf"^(?:{pattern})$"), sign, record, zone, clock,
                  flash_days)


# Order matters only where two patterns could match the same name (none do: every pattern is anchored).
FAMILIES = (
    _f("US_FED_RATE", "US", r"fed interest rate decision", +1, "FOMC_STATEMENT", NY, ("14:00",)),
    _f("US_FOMC_MINUTES", "US", r"fomc (meeting )?minutes", 0, "FOMC_MINUTES", NY, ("14:00",)),
    _f("US_FOMC_TEXT", "US", r"fomc (statement|press conference|economic projections)", 0),
    _f("US_NFP", "US", r"nonfarm payrolls", +1),            # BLS types: no record (RULINGS R7 amended, item 1)
    _f("US_UNEMP", "US", r"unemployment rate", -1),
    _f("US_AHE", "US", r"average hourly earnings (m/m|y/y)", +1),
    _f("US_CPI", "US", r"cpi m/m", +1),
    _f("US_CPI_OTHER", "US", r"core cpi (m/m|y/y)|cpi y/y", +1),
    _f("US_PPI", "US", r"ppi m/m", +1),
    _f("US_PPI_OTHER", "US", r"core ppi (m/m|y/y)|ppi y/y", +1),
    _f("US_PCE", "US", r"(core )?pce price index (m/m|y/y)", +1),
    _f("US_RETAIL", "US", r"retail sales m/m", +1, "US_RETAIL_SALES", NY, ("08:30",)),
    _f("US_CORE_RETAIL", "US", r"core retail sales m/m", +1),
    _f("US_GDP", "US", r"gdp q/q", +1),                     # the name does not say which estimate: no record
    _f("US_CLAIMS", "US", r"initial jobless claims", -1),
    _f("US_JOLTS", "US", r"jolts job openings", +1),
    _f("US_ISM_MAN", "US", r"ism manufacturing pmi", +1, "US_ISM_MANUFACTURING", NY, ("10:00",)),
    # wider than ADDENDUM A3.2's "ism nonmanufacturing pmi": the same release under its other name (RULINGS R8)
    _f("US_ISM_SVC", "US", r"ism (nonmanufacturing|services) pmi", +1, "US_ISM_SERVICES", NY, ("10:00",)),
    _f("US_PMI", "US", r"s&p global (manufacturing|services|composite) pmi", +1),
    _f("US_CONF", "US", r"cb consumer confidence index", +1),
    _f("US_UOM", "US", r"michigan consumer sentiment", +1),
    _f("US_DURABLES", "US", r"(core )?durable goods orders m/m", +1),
    _f("EU_ECB_MRO", "EU", r"ecb interest rate decision", +1, "ECB_DECISION", BERLIN, ("13:45", "14:15")),
    _f("EU_ECB_DFR", "EU", r"ecb deposit facility rate decision", +1),
    _f("EU_ECB_TEXT", "EU", r"ecb (monetary policy statement|press conference)", 0),
    _f("EU_HICP", "EU", r"cpi y/y", +1, "EZ_CPI_FLASH", LUX, ("11:00",), flash_days=True),
    _f("EU_CORE_HICP", "EU", r"core cpi y/y", +1),
    _f("EU_UNEMP", "EU", r"unemployment rate", -1, "EZ_UNEMPLOYMENT", LUX, ("11:00",)),
    _f("EU_RETAIL", "EU", r"retail sales m/m", +1, "EZ_RETAIL_SALES", LUX, ("11:00",)),
    _f("EU_GDP", "EU", r"gdp q/q", +1),
    _f("EU_PMI", "EU DE FR", r"(hcob |s&p global )?(manufacturing|services|composite) pmi", +1),
    _f("EU_ZEW", "EU DE", r"zew economic sentiment( indicator)?", +1),
    _f("DE_IFO", "DE", r"ifo business climate( indicator)?", +1),
    _f("DE_CPI", "DE", r"(prelim )?cpi (m/m|y/y)", +1),
    _f("DE_UNEMP_CHG", "DE", r"unemployment change", -1),
)
ORDER = {f.key: i for i, f in enumerate(FAMILIES)}


def norm(name: str) -> str:
    return " ".join(str(name).lower().replace("-", "").split())


def family_of(country: str, name: str) -> Family | None:
    n = norm(name)
    for f in FAMILIES:
        if country in f.countries and f.pattern.match(n):
            return f
    return None


def record_key(row, family: Family | None = None) -> str | None:
    """The record a row gets, if its time passes the family's clock guard (A2.2, R7 section 3)."""
    f = family or family_of(row["country"], row["name"])
    if f is None or f.record is None or row["time_mode"] != "exact":
        return None
    local = datetime.fromisoformat(row["event_utc"].replace("Z", "+00:00")).astimezone(ZoneInfo(f.zone))
    if local.strftime("%H:%M") not in f.clock:
        return None
    if f.flash_days and not (local.day <= 7 or local.day >= 28):
        return None
    return f.record


def surprise(actual: float | None, forecast: float | None, digits: int) -> str | None:
    if actual is None or forecast is None:
        return None
    if abs(actual - forecast) < 0.5 * 10 ** -int(digits) + 1e-9:
        return "inline"
    return "above" if actual > forecast else "below"


SURPRISE_TEXT = {"above": "Above MT5 forecast", "below": "Below MT5 forecast", "inline": "In line with MT5 forecast"}


def read(row) -> dict:
    """{surprise, effect, read, read_by, text} for one stored row (news_event); text None when there is nothing."""
    out = {"surprise": None, "effect": None, "read": None, "read_by": None, "text": None}
    if row["kind"] == "holiday" or row["actual"] is None:
        return out
    s = surprise(row["actual_num"], row["forecast_num"], row["digits"])
    out["surprise"] = s
    cur = row["currency"]
    effect = None
    if row["mt5_impact"] in ("positive", "negative"):
        effect, out["read_by"] = row["mt5_impact"], "mt5"
    else:
        f = family_of(row["country"], row["name"])
        if f is not None and f.sign and s in ("above", "below"):
            effect = "positive" if f.sign * (1 if s == "above" else -1) > 0 else "negative"
            out["read_by"] = "textbook"
    parts = [SURPRISE_TEXT[s]] if s else []
    if effect is not None and cur in ("EUR", "USD"):
        up = (cur == "EUR") == (effect == "positive")
        out.update(effect=effect, read="eur_up" if up else "eur_down")
        how = "MT5's read, untested" if out["read_by"] == "mt5" else "untested textbook read"
        parts += [f"{cur}-{effect}", f"{how}: EUR/USD {'higher' if up else 'lower'}"]
    else:
        out["read_by"] = None
    out["text"] = " · ".join(parts) or None
    return out
