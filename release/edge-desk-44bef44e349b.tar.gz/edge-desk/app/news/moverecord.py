"""The past move record, measured on the owner's own server (coordinator ruling R7).

OANDA's terms read "not clearly allowed" for publishing statistics derived from its prices, so the release ships no
move record and no figure of it. (It does carry older backtest and cost figures computed on OANDA prices, the tested
lines and the lead bundle; the release is held until the coordinator rules on those: deploy/README.md section 12,
"Release hold".) For the record it ships move_events.json (release minutes and listed calendar rows, 2016-2021;
dates and times only, built by research/news_reaction/make_move_events.py) and this measurement, written from the
research script (research/news_reaction/reaction.py): the same mid, windows, quiet days, percentiles and rounding.
The job runs inside the OANDA feed process (app/feed/oanda.py run_forever), so it uses the feed's own Client:
candles of EUR/USD M1 bid/ask only, at most one request every 2 s across restarts, Retry-After, the 24 h block on a
403 or 429, and one gate per host (oanda.host_gate: the feed's halt and stop, and the not-before time any failure at
the host sets, whoever sent it; fix round 1). One request per window (release minute -1 to +61). Per window only
four numbers (no price) are written to <var>/news_record/work.jsonl, so a restart resumes; candles are never stored.
When every window is measured it writes <var>/news_record/move_record.json (0600) and deletes the work file. Neither
file is in the journal, its backups, the daily export or a release. Its state (counts only) is meta
news.record.state; failures news.record.failures.

Measures (DECLARATION.md section 7): mid = (bid + ask) / 2; P0 = mid open of the bar at t0 (no bar: dropped); P15
and P60 = mid close of the last bar with t0 <= ts <= t0 + 14 or 59 min; |P - P0| and the largest excursion, in pips;
median and 80th percentile with numpy's percentile (linear), rounded to 0.1. Quiet days (section 8, with R7's skip
days: the 16 public Eurex closures in place of the research's 24 days taken from OANDA's bars): the type's local
clock time, local Monday to Thursday, not 24 Dec to 1 Jan, no listed row within 12 h, no untimed listed row on that
local date, not a skip day (New York trading day), a bar at t0.
"""
from __future__ import annotations

import bisect
import hashlib
import json
import logging
import os
import sqlite3
import time
from datetime import date, datetime, time as dtime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from app import db

log = logging.getLogger("app.news.record")

UTC = timezone.utc
EVENTS_FILE = Path(__file__).resolve().parent / "move_events.json"
EVENTS_SHA256 = "478cc6b31356c41e4737e6ddaef5c4ff39179d11b221ee415c6d12f25e1248fe"
VERSION = "moverecord/1"
PIP = 0.0001
START = 1451606400            # 2016-01-01 00:00 UTC
CUT = 1640995200              # 2022-01-01 00:00 UTC
BEFORE_S = 60                 # each request: from t0 - 60 s ...
AFTER_S = 61 * 60             # ... to t0 + 61 min (release minute -1 to +61)
WINDOW_S = 60 * 60            # shared_window_n: another listed row in [t0, t0 + 60 min)
NEAR_S = 12 * 3600            # quiet days: no listed row within 12 h of t0
DIR_NAME = "news_record"
RECORD_NAME = "move_record.json"
WORK_NAME = "work.jsonl"
STATE_KEY = "news.record.state"
FAILURES_KEY = "news.record.failures"
FATAL_KEY = "news.record.fatal"


class RecordError(RuntimeError):
    """The shipped event list is not the pinned one, or a record file is not well formed."""


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def load_events(path: Path = EVENTS_FILE, sha256: str = EVENTS_SHA256) -> dict:
    raw = Path(path).read_bytes()
    if sha256_bytes(raw) != sha256:
        raise RecordError("move_events.json is not the pinned event list")
    return json.loads(raw)


def record_dir(var_dir: Path) -> Path:
    return Path(var_dir) / DIR_NAME


# ---------------------------------------------------------------- calendar rules (no prices)

def _clock(t: dict) -> tuple[str, str]:
    return t["tz"], t["local_time"]


def ny_day(t0: int) -> str:
    """New York trading day of an instant (17:00 New York rollover), as reaction.py."""
    d = datetime.fromtimestamp(t0, ZoneInfo("America/New_York"))
    return (d.date() + timedelta(days=1 if d.hour >= 17 else 0)).isoformat()


class Calendar:
    """The listed rows of an event list, for the 12-hour rule and the hour window."""

    def __init__(self, ev: dict):
        self.timed = sorted((int(ts), str(key)) for ts, key in ev["listed"])
        self.ts = [t for t, _ in self.timed]
        self.untimed = {tz: set(days) for tz, days in ev["untimed"].items()}
        self.skip = set(ev["skip_days"])
        self.keys = dict(ev["event_keys"])

    def near(self, t0: int) -> bool:
        lo, hi = bisect.bisect_left(self.ts, t0 - NEAR_S), bisect.bisect_right(self.ts, t0 + NEAR_S)
        return hi > lo or any(datetime.fromtimestamp(t0, ZoneInfo(tz)).date().isoformat() in days
                              for tz, days in self.untimed.items())

    def shared(self, typ: str, t0: int) -> bool:
        lo, hi = bisect.bisect_left(self.ts, t0), bisect.bisect_left(self.ts, t0 + WINDOW_S)
        return any(self.timed[i][1] != self.keys[typ] for i in range(lo, hi))


def quiet_candidates(ev: dict, zone: str, hm: str, cal: Calendar | None = None) -> list[int]:
    """Quiet-day t0s of one clock time that the calendar rules leave (the bar check comes with the prices)."""
    cal = cal or Calendar(ev)
    h, mi = (int(x) for x in hm.split(":"))
    out, d = [], date(2016, 1, 1)
    while d <= date(2021, 12, 31):
        if d.weekday() <= 3 and not ((d.month == 12 and d.day >= 24) or (d.month == 1 and d.day == 1)):
            t0 = int(datetime.combine(d, dtime(h, mi), tzinfo=ZoneInfo(zone)).timestamp())
            if not cal.near(t0) and ny_day(t0) not in cal.skip:
                out.append(t0)
        d += timedelta(days=1)
    return out


def release_times(t: dict) -> list[int]:
    return [int(ts) for ts in t["release_utc"] if START <= int(ts) and int(ts) + 59 * 60 < CUT]


def windows(ev: dict) -> list[int]:
    """Every t0 the record needs, once each, in time order."""
    cal = Calendar(ev)
    need: set[int] = set()
    for t in ev["types"]:
        need.update(release_times(t))
    for zone, hm in sorted({_clock(t) for t in ev["types"]}):
        need.update(quiet_candidates(ev, zone, hm, cal))
    return sorted(need)


# ---------------------------------------------------------------- measures (prices in memory only)

def measure(bars: list[dict], t0: int) -> dict | None:
    """The four figures of one window from its candles ({ts, bid_o.., ask_c}), or None with no bar at t0."""
    rows = sorted((b for b in bars if t0 <= b["ts"] <= t0 + 59 * 60), key=lambda b: b["ts"])
    ts = [b["ts"] for b in rows]
    if not ts or ts[0] != t0:
        return None
    mo = [(b["bid_o"] + b["ask_o"]) / 2 for b in rows]
    mh = [(b["bid_h"] + b["ask_h"]) / 2 for b in rows]
    ml = [(b["bid_l"] + b["ask_l"]) / 2 for b in rows]
    mc = [(b["bid_c"] + b["ask_c"]) / 2 for b in rows]
    p0 = mo[0]
    out = {}
    for w in (15, 60):
        j = bisect.bisect_right(ts, t0 + (w - 1) * 60) - 1
        out[f"abs_{w}"] = abs(mc[j] - p0) / PIP
        out[f"exc_{w}"] = max(max(mh[:j + 1]) - p0, p0 - min(ml[:j + 1])) / PIP
    return out


def _stats(vals: list[float]) -> tuple[float, float]:
    import numpy as np
    med, p80 = np.percentile(np.array(vals, dtype=float), [50, 80])
    return round(float(med), 1), round(float(p80), 1)


def _summary(ms: list[dict]) -> dict:
    return {k: _stats([m[k] for m in ms]) for k in ("abs_15", "abs_60", "exc_15", "exc_60")}


def _utc(ts: int) -> str:
    return datetime.fromtimestamp(ts, UTC).strftime("%Y-%m-%d %H:%M")


def table_rows(ev: dict, measured: dict[int, dict | None], min_n: int | None = None) -> list[dict]:
    """reaction.py's table rows (the figures it reports per type) from the measured windows."""
    import numpy as np
    cal = Calendar(ev)
    min_n = int(ev["rules"]["min_n"]) if min_n is None else min_n
    base_by: dict[tuple[str, str], list[dict]] = {}
    for zone, hm in {_clock(t) for t in ev["types"]}:
        base_by[(zone, hm)] = [m for t0 in quiet_candidates(ev, zone, hm, cal)
                               if (m := measured.get(t0)) is not None]
    rows = []
    for t in ev["types"]:
        typ, evs = t["event"], release_times(t)
        ms, shared = [], 0
        for ts in evs:
            m = measured.get(ts)
            if m is None:
                continue
            ms.append(m)
            shared += cal.shared(typ, ts)
        rec = {"event": typ, "currency": t["currency"], "local_time": t["local_time"], "tz": t["tz"], "n": len(ms),
               "shared_window_n": shared, "first": _utc(evs[0]) if evs else None,
               "last": _utc(evs[-1]) if evs else None}
        base = base_by[_clock(t)]
        if len(ms) < min_n or not base:
            rec["status"] = f"not reported (n < {min_n})" if len(ms) < min_n else "not reported (no quiet days)"
            rows.append(rec)
            continue
        s, b = _summary(ms), _summary(base)
        if b["abs_60"][0] == 0:                     # no ratio to a flat quiet day (reaction.py would stop here)
            rec["status"] = "not reported (quiet median 0)"
            rows.append(rec)
            continue
        bp80_60 = float(np.percentile([m["abs_60"] for m in base], 80))
        ratio = round(s["abs_60"][0] / b["abs_60"][0], 2)
        rec.update({
            "median_abs_pips_15m": s["abs_15"][0], "p80_abs_pips_15m": s["abs_15"][1],
            "median_abs_pips_60m": s["abs_60"][0], "p80_abs_pips_60m": s["abs_60"][1],
            "median_excursion_pips_15m": s["exc_15"][0], "p80_excursion_pips_15m": s["exc_15"][1],
            "median_excursion_pips_60m": s["exc_60"][0], "p80_excursion_pips_60m": s["exc_60"][1],
            "baseline": {"n": len(base), "median_abs_pips_15m": b["abs_15"][0], "p80_abs_pips_15m": b["abs_15"][1],
                         "median_abs_pips_60m": b["abs_60"][0], "p80_abs_pips_60m": b["abs_60"][1],
                         "median_excursion_pips_15m": b["exc_15"][0], "p80_excursion_pips_15m": b["exc_15"][1],
                         "median_excursion_pips_60m": b["exc_60"][0], "p80_excursion_pips_60m": b["exc_60"][1]},
            "ratio_60": ratio,
            "share_above_base_p80_60": round(sum(m["abs_60"] > bp80_60 for m in ms) / len(ms), 2),
            "tier": "large" if ratio >= 2.0 else ("moderate" if ratio >= 1.3 else "small"),
            "status": "reported",
        })
        rows.append(rec)
    rows.sort(key=lambda r: -r.get("ratio_60", float("-inf")))
    return rows


def record_rows(table: list[dict]) -> list[dict]:
    """The app's record rows (make_move_record.py's keys) from the reported table rows."""
    out = []
    for r in table:
        if r["status"] != "reported":
            continue
        out.append({"event": r["event"], "currency": r["currency"], "local_time": r["local_time"], "tz": r["tz"],
                    "n": r["n"], "median_15m_pips": r["median_abs_pips_15m"],
                    "median_60m_pips": r["median_abs_pips_60m"],
                    "quiet_median_60m_pips": r["baseline"]["median_abs_pips_60m"],
                    "beat_quiet_p80_share": r["share_above_base_p80_60"], "shared_window_n": r["shared_window_n"],
                    "ratio_60": r["ratio_60"], "tier": r["tier"], "first_utc": r["first"], "last_utc": r["last"]})
    return out


def rows_sha256(rows: list[dict]) -> str:
    return sha256_bytes(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode())


def record_doc(rows: list[dict], events_sha256: str, built: datetime) -> dict:
    return {"what": "EUR/USD move size after scheduled EUR and USD releases, either way, 2016-2021, measured on this "
                    "server from the owner's own OANDA practice prices. A past record, not a forecast. Never shared.",
            "version": VERSION, "events_sha256": events_sha256, "built_utc": built.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "direction": "not measured", "rows": rows, "rows_sha256": rows_sha256(rows)}


# ---------------------------------------------------------------- state

def _meta(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return None if row is None else row[0]


def _put(conn: sqlite3.Connection, key: str, value) -> None:
    with db.transaction(conn):
        conn.execute("INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                     (key, str(value)))


def state(conn: sqlite3.Connection) -> dict | None:
    raw = _meta(conn, STATE_KEY)
    try:
        return json.loads(raw) if raw else None
    except ValueError:
        return None


def reset_halt(conn: sqlite3.Connection) -> None:
    """python -m app feed --reset-record: the job may try again after a halt (never clears a host block)."""
    st = state(conn) or {}
    with db.transaction(conn):
        conn.execute("DELETE FROM meta WHERE key IN (?, ?)", (FAILURES_KEY, FATAL_KEY))
        if st.get("state") in ("halted", "paused"):
            st.update(state="building", next_try_utc=None, error=None)
            conn.execute("INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = "
                         "excluded.value", (STATE_KEY, json.dumps(st, sort_keys=True)))


def _iso(t: float) -> str:
    return datetime.fromtimestamp(int(t), UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _from_iso(s: str) -> float:
    return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def read_record(path: Path) -> dict | None:
    """A record file that parses and whose rows match their sha256, else None."""
    try:
        doc = json.loads(Path(path).read_bytes())
        if doc.get("version") != VERSION or rows_sha256(doc["rows"]) != doc["rows_sha256"]:
            return None
        return doc
    except (OSError, ValueError, KeyError, TypeError):
        return None


# ---------------------------------------------------------------- the job

class RecordJob:
    """One step after each feed poll: fetch and measure windows until `deadline` (feed clock seconds)."""

    def __init__(self, conn: sqlite3.Connection, client, cfg, var_dir: Path, events_path: Path = EVENTS_FILE,
                 events_sha256: str = EVENTS_SHA256, clock=time.time):
        self.conn, self.client, self.cfg, self.clock = conn, client, cfg, clock
        self.dir = record_dir(var_dir)
        self.events_path, self.events_sha256 = Path(events_path), events_sha256
        self._ev = None
        self._todo: list[int] | None = None
        self._total = 0

    @property
    def record_path(self) -> Path:
        return self.dir / RECORD_NAME

    @property
    def work_path(self) -> Path:
        return self.dir / WORK_NAME

    def enabled(self) -> bool:
        return bool(self.cfg.news.enabled and self.cfg.news.show_record)

    def _set_state(self, **st) -> None:
        cur = state(self.conn) or {}
        cur.update(st, updated_utc=_iso(self.clock()))
        _put(self.conn, STATE_KEY, json.dumps(cur, sort_keys=True))

    def _done(self) -> bool:
        doc = read_record(self.record_path)
        return doc is not None and doc.get("events_sha256") == self.events_sha256

    def _load_work(self) -> dict[int, dict | None]:
        got: dict[int, dict | None] = {}
        try:
            text = self.work_path.read_text()
        except OSError:
            return got
        if text and not text.endswith("\n"):          # a line cut short by a stop: end it, so the next one starts clean
            with self.work_path.open("a") as fh:
                fh.write("\n")
        lines = text.splitlines()
        if not lines:
            return got
        try:
            head = json.loads(lines[0])
        except ValueError:
            head = {}
        if head.get("events_sha256") != self.events_sha256 or head.get("version") != VERSION:
            self.work_path.unlink(missing_ok=True)
            return {}
        for line in lines[1:]:
            try:
                r = json.loads(line)
                m = r["m"]
                if m is not None and set(m) != {"abs_15", "abs_60", "exc_15", "exc_60"}:
                    continue
                got[int(r["t0"])] = m
            except (ValueError, KeyError, TypeError):
                continue                             # a line cut short by a stop: measured again
        return got

    def _prepare(self) -> bool:
        """The plan in memory holds only while its work file exists: after a build (the work file is deleted) or a
        lost work file, the next step plans every window again (red team, fix round 1: a deleted or changed record
        was rewritten empty)."""
        if self._todo is not None and self.work_path.exists():
            return True
        try:
            self._ev = load_events(self.events_path, self.events_sha256)
        except (OSError, ValueError, RecordError) as exc:
            self._set_state(state="halted", error=f"event list: {type(exc).__name__}", next_try_utc=None)
            return False
        need = windows(self._ev)
        self.dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        done = self._load_work()
        if not self.work_path.exists():
            self._write_line({"events_sha256": self.events_sha256, "version": VERSION})
        self._todo = [t for t in need if t not in done]
        self._total = len(need)
        return True

    def _write_line(self, obj: dict) -> None:
        """Append one line. A work file lost while a step runs is started again with its header (fix round 2, red
        team minor), so what follows is kept and only the windows in the lost file are measured again."""
        head = {"events_sha256": self.events_sha256, "version": VERSION}
        fd = os.open(self.work_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            if obj != head and os.fstat(fd).st_size == 0:
                os.write(fd, (json.dumps(head, sort_keys=True) + "\n").encode())
            os.write(fd, (json.dumps(obj, sort_keys=True) + "\n").encode())
            os.fsync(fd)
        finally:
            os.close(fd)

    def _finish(self) -> bool:
        """Write the record once every window it needs is measured; else plan the missing ones again (False)."""
        measured = self._load_work()
        need = windows(self._ev)
        missing = [t for t in need if t not in measured]
        if missing:
            self._todo, self._total = missing, len(need)
            self._set_state(state="building", done=len(need) - len(missing), total=len(need), next_try_utc=None,
                            error=None)
            log.warning("move record: %s windows not measured, measured again", len(missing))
            return False
        rows = record_rows(table_rows(self._ev, measured))
        doc = record_doc(rows, self.events_sha256, datetime.fromtimestamp(self.clock(), UTC))
        tmp = self.dir / (RECORD_NAME + ".part")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            os.write(fd, (json.dumps(doc, indent=1, sort_keys=True) + "\n").encode())
            os.fsync(fd)
        finally:
            os.close(fd)
        os.replace(tmp, self.record_path)
        os.chmod(self.record_path, 0o600)
        self.work_path.unlink(missing_ok=True)
        self._set_state(state="done", done=self._total, total=self._total, next_try_utc=None, error=None,
                        types=len(rows))
        log.info("move record: built, %s event types", len(rows))
        return True

    def step(self, deadline: float) -> int:
        """Measure windows until the deadline; returns how many requests were made. Never raises a feed error."""
        from app.feed.oanda import FeedBlocked, FeedError, HostWait, PathRefused, blocked_until, host_gate
        if not self.enabled():
            return 0
        st = state(self.conn) or {}
        if st.get("state") == "halted":
            return 0
        if self._done():
            if st.get("state") != "done":
                self._set_state(state="done", next_try_utc=None, error=None)
            return 0
        now = self.clock()
        if st.get("next_try_utc") and _from_iso(st["next_try_utc"]) > now:
            return 0
        gate = host_gate(self.conn, self.client.host, now)        # shared with the feed (red team B1)
        if gate is not None:
            why, until = gate
            self._set_state(state="paused", next_try_utc=None if until is None else _iso(until), error=why)
            return 0
        if not self._prepare():
            return 0
        made = 0
        while True:
            if not self._todo and self._finish():         # written; else the windows left out are planned again
                break
            if self.clock() + self.client.min_gap_s >= deadline:
                break
            t0 = self._todo[0]
            try:
                bars = self.client.candles(t0 - BEFORE_S, t0 + AFTER_S)
            except HostWait as exc:                                # nothing was sent
                self._set_state(state="paused", next_try_utc=_iso(exc.until), error="host waits")
                return made
            except FeedBlocked as exc:
                made += 1
                until = blocked_until(self.conn, self.client.host, self.clock())
                self._set_state(state="paused", next_try_utc=_iso(until or self.clock() + 86400),
                                error=f"HTTP {exc.code}" if exc.code else "host blocked")
                return made
            except PathRefused:
                self._set_state(state="halted", error="request refused before sending", next_try_utc=None)
                return made
            except FeedError as exc:
                made += 1
                self._failed(exc)
                return made
            made += 1
            _put(self.conn, FAILURES_KEY, 0)
            _put(self.conn, FATAL_KEY, 0)
            m = measure([c for c in bars if c.get("complete")], t0)
            self._write_line({"t0": t0, "m": m})
            self._todo.pop(0)
            self._set_state(state="building", done=self._total - len(self._todo), total=self._total,
                            next_try_utc=None, error=None)
        return made

    def _failed(self, exc) -> None:
        fails = int(_meta(self.conn, FAILURES_KEY) or 0) + 1
        fatal = _meta(self.conn, FATAL_KEY) == "1" or not exc.retryable
        now = self.clock()
        limit = self.cfg.feed.max_failures
        if fails >= limit:
            _put(self.conn, FAILURES_KEY, 0)
            _put(self.conn, FATAL_KEY, 0)
            if fatal:
                self._set_state(state="halted", next_try_utc=None,
                                error=f"{fails} failures in a row, last {exc}"[:120])
                log.warning("move record: %s failures in a row (not only 5xx or network): halted", fails)
            else:
                wait = max(float(self.cfg.feed.cooldown_s), float(exc.retry_after or 0.0))   # Retry-After kept
                self._set_state(state="paused", next_try_utc=_iso(now + wait),
                                error=f"{fails} failures in a row, last {exc}"[:120])
                log.warning("move record: %s failures in a row: paused for %s s", fails, int(wait))
            return
        _put(self.conn, FAILURES_KEY, fails)
        _put(self.conn, FATAL_KEY, 1 if fatal else 0)
        wait = max(exc.retry_after or 0.0, 2.0 ** fails)
        self._set_state(state="building", next_try_utc=_iso(now + wait), error=str(exc)[:120])
