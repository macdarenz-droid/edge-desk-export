"""The past move record beside a mapped release (ADDENDUM A2.2-A2.3 with coordinator ruling R7).

The record is built on this server from the owner's own OANDA practice prices (app/news/moverecord.py) and read
from <var>/news_record/move_record.json. It ships in no release. load(var_dir) returns a RecordSet: `rows` by event
type, `broken` when the file does not parse or its rows do not match their sha256 (check.py FAILs), `missing` when it
is not built yet or was built from another event list (the job builds it again).

Shown (one line, size only, either way, never a direction or a forecast):
  {word} · either way: median {m15} pips in 15 min, {m60} in the hour (quiet day {q60}) · bigger than 4 in 5 quiet
  days: {pct}% (quiet day 20%) · {n} releases, 2016-21[ · often shares its hour with other listed releases]
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

from app.news import moverecord

FOOTNOTE = "Moves: size only, either way, 2016-21 prices. Reads: untested on past prices."


@dataclass(frozen=True)
class RecordSet:
    rows: dict = field(default_factory=dict)
    broken: bool = False
    missing: bool = False
    built_utc: str | None = None


def load(var_dir: Path | None) -> RecordSet:
    """Read the record file (a few KB) each time: no cache that a quick rewrite of the same size could fool."""
    if var_dir is None:
        return RecordSet(missing=True)
    path = moverecord.record_dir(var_dir) / moverecord.RECORD_NAME
    if not path.exists():
        return RecordSet(missing=True)
    doc = moverecord.read_record(path)
    if doc is None:
        return RecordSet(broken=True)
    if doc.get("events_sha256") != moverecord.EVENTS_SHA256:
        return RecordSet(missing=True)
    return RecordSet({r["event"]: r for r in doc["rows"]}, built_utc=doc.get("built_utc"))


def var_of(cfg) -> Path | None:
    p = getattr(getattr(cfg, "app", None), "db_path", None)
    return Path(p).parent if p else None


def whole(x) -> int:
    """Half up to a whole number (9.5 -> 10), as the screens show pips and percentages."""
    return int(Decimal(str(x)).quantize(Decimal(0), ROUND_HALF_UP))


def word(r: dict) -> str:
    if r["tier"] == "large":
        return "Large mover"
    if r["tier"] == "moderate":
        return "Moderate mover"
    x = r["ratio_60"]
    if x > 1.1:
        return "Small mover"
    return "About a quiet day" if x >= 0.9 else "Less than a quiet day"


def shown(r: dict) -> dict:
    """The record of one event type as the screens and the news_soon alert use it."""
    out = {"word": word(r), "m15": whole(r["median_15m_pips"]), "m60": whole(r["median_60m_pips"]),
           "q60": whole(r["quiet_median_60m_pips"]), "pct": whole(r["beat_quiet_p80_share"] * 100), "n": int(r["n"]),
           "shared": 2 * int(r["shared_window_n"]) >= int(r["n"])}
    out["line"] = (f"{out['word']} · either way: median {out['m15']} pips in 15 min, {out['m60']} in the hour (quiet day "
                   f"{out['q60']}) · bigger than 4 in 5 quiet days: {out['pct']}% (quiet day 20%) · {out['n']} releases, "
                   f"2016-21" + (" · often shares its hour with other listed releases" if out["shared"] else ""))
    return out


def soon_part(rec: dict) -> str:
    """The size part of a news_soon alert: either way, no direction; with the shared-hour caveat Today's line has."""
    return (f"hour move either way 2016-21: median {rec['m60']} pips, quiet day {rec['q60']}"
            + (", often shares its hour" if rec.get("shared") else ""))
