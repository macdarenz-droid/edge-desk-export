"""edge-calendar/2 and /1 payload validation (bridge/CONTRACT.md, "Calendar: edge-calendar/2").

`validate(payload)` returns a frozen `CalendarPost` or raises `app.ingest.schema.PayloadError`. As for snapshots:
every key is required, any other key is refused, numbers are finite, never a bool, within +-MAX_ABS, and messages
name the field and the rule, never a value (rows are named by position, "values entry 3"; the EA prints the reply in
the MT5 log). edge-calendar/2 (EA 1.11) adds one key per row, "impact": MetaQuotes' own label of the release for its
currency (MqlCalendarValue.impact_type: none, positive or negative). An edge-calendar/1 post (EA 1.10) is still
accepted, with impact none, so a terminal that has not reloaded the EA keeps its news.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Any

from app.ingest.schema import MAX_ABS, MAX_SEQ, PayloadError, _SESSION_RE, _enum, _epoch, _int, _list, _obj, _str, \
    _ticket

CONTRACT = "edge-calendar/2"
CONTRACTS = ("edge-calendar/1", "edge-calendar/2")
MAX_VALUES = 500
MAX_WINDOW_S = 15 * 86400
MAX_NAME = 128
MAX_PAYLOAD_BYTES = 262144
MAX_CURRENCIES = 8
TOP_KEYS = frozenset({"contract", "bridge_session", "cal_seq", "server_time", "gmt_time", "from", "to", "currencies",
                      "values"})
VALUE_KEYS = frozenset({"value_id", "event_id", "currency", "country", "name", "type", "importance", "time_mode",
                        "time", "unit", "multiplier", "digits", "actual", "forecast", "previous", "revised_previous"})
VALUE_KEYS_2 = VALUE_KEYS | {"impact"}
IMPACT_TYPES = frozenset({"none", "positive", "negative"})
TYPES = frozenset({"indicator", "event", "holiday"})
IMPORTANCES = frozenset({"none", "low", "medium", "high"})
TIME_MODES = frozenset({"datetime", "date", "notime", "tentative"})
UNITS = frozenset({"none", "percent", "currency", "hour", "job", "rig", "usd", "people", "mortgage", "vote", "barrel",
                   "cubicfeet", "position", "building"})
MULTIPLIERS = frozenset({"none", "thousands", "millions", "billions", "trillions"})
MODE_MAP = {"datetime": "exact", "date": "all_day", "notime": "no_time", "tentative": "tentative"}

_CURRENCY_RE = re.compile(r"[A-Z]{3}")
_COUNTRY_RE = re.compile(r"[A-Z]{2}")


@dataclass(frozen=True)
class CalendarValue:
    value_id: str
    event_id: str
    currency: str
    country: str
    name: str
    type: str
    importance: str
    time_mode: str
    time: int
    unit: str
    multiplier: str
    digits: int
    actual: float | None
    forecast: float | None
    previous: float | None
    revised_previous: float | None
    impact: str = "none"


@dataclass(frozen=True)
class CalendarPost:
    contract: str
    bridge_session: str
    cal_seq: int
    server_time: int
    gmt_time: int
    from_: int
    to: int
    currencies: tuple[str, ...]
    values: tuple[CalendarValue, ...]


def _num_or_null(value: Any, where: str) -> float | None:
    if value is None:
        return None
    if type(value) not in (int, float):          # a bool is never a number
        raise PayloadError(f"{where}: must be null or a number")
    value = float(value)
    if not math.isfinite(value) or abs(value) > MAX_ABS:
        raise PayloadError(f"{where}: must be a finite number within +-{MAX_ABS:g}")
    return value


def _name(value: Any, where: str) -> str:
    s = _str(value, where, MAX_NAME, allow_empty=False)
    if any(ord(c) < 0x20 for c in s):
        raise PayloadError(f"{where}: no control characters")
    return s


def _value(raw: Any, i: int, currencies: tuple[str, ...], lo: int, hi: int, contract: str) -> CalendarValue:
    w = f"values entry {i}"
    v = _obj(raw, w, VALUE_KEYS_2 if contract == CONTRACT else VALUE_KEYS)
    currency = _str(v["currency"], f"{w}.currency", 3, _CURRENCY_RE)
    if currency not in currencies:
        raise PayloadError(f"{w}.currency: not in currencies")
    t = _epoch(v["time"], f"{w}.time")
    if not lo <= t <= hi:
        raise PayloadError(f"{w}.time: outside from .. to")
    return CalendarValue(
        value_id=_ticket(v["value_id"], f"{w}.value_id"),
        event_id=_ticket(v["event_id"], f"{w}.event_id"),
        currency=currency,
        country=_str(v["country"], f"{w}.country", 2, _COUNTRY_RE),
        name=_name(v["name"], f"{w}.name"),
        type=_enum(v["type"], f"{w}.type", TYPES),
        importance=_enum(v["importance"], f"{w}.importance", IMPORTANCES),
        time_mode=_enum(v["time_mode"], f"{w}.time_mode", TIME_MODES),
        time=t,
        unit=_enum(v["unit"], f"{w}.unit", UNITS),
        multiplier=_enum(v["multiplier"], f"{w}.multiplier", MULTIPLIERS),
        digits=_int(v["digits"], f"{w}.digits", 0, 10),
        actual=_num_or_null(v["actual"], f"{w}.actual"),
        forecast=_num_or_null(v["forecast"], f"{w}.forecast"),
        previous=_num_or_null(v["previous"], f"{w}.previous"),
        revised_previous=_num_or_null(v["revised_previous"], f"{w}.revised_previous"),
        impact=_enum(v["impact"], f"{w}.impact", IMPACT_TYPES) if contract == CONTRACT else "none",
    )


def validate(payload: Any) -> CalendarPost:
    """Check a decoded edge-calendar/2 (or /1) body against the contract. Raises PayloadError."""
    p = _obj(payload, "body", TOP_KEYS)
    if p["contract"] not in CONTRACTS:
        raise PayloadError(f"contract: this app speaks {CONTRACT} (and {CONTRACTS[0]})")
    contract = p["contract"]
    session = p["bridge_session"]
    if not isinstance(session, str) or not _SESSION_RE.fullmatch(session):
        raise PayloadError("bridge_session: must be 16 lowercase hex characters")
    cal_seq = _int(p["cal_seq"], "cal_seq", 0, MAX_SEQ)
    server_time = _epoch(p["server_time"], "server_time")
    gmt_time = _epoch(p["gmt_time"], "gmt_time")
    lo, hi = _epoch(p["from"], "from"), _epoch(p["to"], "to")
    if lo >= hi:
        raise PayloadError("from: must be before to")
    if hi - lo > MAX_WINDOW_S:
        raise PayloadError("to: at most 15 days after from")
    raw_cur = _list(p["currencies"], "currencies", MAX_CURRENCIES)
    if not raw_cur:
        raise PayloadError(f"currencies: 1 to {MAX_CURRENCIES} items")
    currencies = tuple(_str(c, f"currencies entry {i}", 3, _CURRENCY_RE) for i, c in enumerate(raw_cur, 1))
    if len(set(currencies)) != len(currencies):
        raise PayloadError("currencies: duplicate currency")
    values = tuple(_value(x, i, currencies, lo, hi, contract)
                   for i, x in enumerate(_list(p["values"], "values", MAX_VALUES), 1))
    if len({v.value_id for v in values}) != len(values):
        raise PayloadError("values: duplicate value_id")
    return CalendarPost(contract, session, cal_seq, server_time, gmt_time, lo, hi, currencies, values)
