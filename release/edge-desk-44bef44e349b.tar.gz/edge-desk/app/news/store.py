"""Store one edge-calendar/2 (or /1) post in news_event (schema 5).

A post is the WHOLE window [from, to] for its currencies: rows of those currencies in the window that the post leaves
out were cancelled or moved, and are deleted; the rest are upserted by (source, source_id). Server times become UTC
with the offset the EA measured in the same post ("flat"): exact when the terminal converts the calendar with its
current offset; rows past a coming server clock change are 1 h off when it converts each row with the offset at its
own time, which the clock check records at the first post with a new offset (news spec 7.3, check.py `news`).
Nothing is written for a stale cal_seq (StaleCalSeq), or while storage.raw_allowed() is False (below the disk floor
or over the budget: the panel goes stale and the storage_low alert says why). A post whose measured offset differs
from the server offset of the latest snapshot (bridge_status: its own bridge session first) is ignored, so a terminal
that measured 0 while not connected never moves the stored times (meta news.ignored records the last one); a clock
check that found none of the post's rows stored is not recorded. Each row keeps its numbers beside the strings
(digits, actual_num, forecast_num, previous_num), MetaQuotes' impact label (mt5_impact) and, set once, the time its
actual was first stored (actual_first_utc, the latency record). State lives in meta: news.last_ok_utc,
news.bridge_session, news.cal_seq, news.offset_s, news.clock_check (JSON), news.ignored (JSON).
"""
from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone

from app import db, storage
from app.ingest.clock import check_skew, measured_offset_s
from app.news.schema import MODE_MAP, validate
from app.timeutil import to_iso, trading_day

UTC = timezone.utc
SOURCE = "mt5"
SUFFIX = {"thousands": "K", "millions": "M", "billions": "B", "trillions": "T"}
_COLUMNS = ("source", "source_id", "currency", "country", "name", "kind", "impact", "time_mode", "event_utc", "day",
            "actual", "forecast", "previous", "revised", "first_seen_utc", "updated_utc", "digits", "actual_num",
            "forecast_num", "previous_num", "actual_first_utc", "mt5_impact")
_KEEP = ("source", "source_id", "first_seen_utc", "actual_first_utc")      # never overwritten by a later post


class StaleCalSeq(Exception):
    """A cal_seq not above the stored one in the same bridge_session: already stored, nothing written."""


@dataclass(frozen=True)
class CalendarResult:
    cal_seq: int
    stored: int
    dropped: int
    ignored: str | None = None


def fmt_value(x: float | None, digits: int, unit: str, multiplier: str) -> str | None:
    """A calendar number as shown: the event's digits (at most 6), the multiplier's K/M/B/T, then % for percent."""
    if x is None:
        return None
    d = min(max(int(digits), 0), 6)
    s = f"{x:.{d}f}"
    if s.startswith("-") and float(s) == 0:
        s = s[1:]
    return s + SUFFIX.get(multiplier, "") + ("%" if unit == "percent" else "")


def _meta(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return None if row is None else row[0]


def _set(conn: sqlite3.Connection, key: str, value) -> None:
    conn.execute("INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                 (key, str(value)))


def state(conn: sqlite3.Connection) -> dict:
    off = _meta(conn, "news.offset_s")
    check = _meta(conn, "news.clock_check")
    return {"last_ok_utc": _meta(conn, "news.last_ok_utc"), "offset_s": int(off) if off is not None else None,
            "clock_check": json.loads(check) if check else None}


def _clock_check(conn, post, cur: list[str], old_off: int, off: int, to_utc, now: datetime) -> None:
    """At the first post with a new offset: each exact row already stored either kept its UTC time ("held": the
    terminal converts with the offset at the row's own time) or moved by the offset change ("moved": with its
    current offset). Rows that moved by anything else were changed by the source and are not counted."""
    held = moved = compared = 0
    for v in post.values:
        if v.time_mode != "datetime" or v.currency not in cur:
            continue
        row = conn.execute("SELECT event_utc FROM news_event WHERE source = ? AND source_id = ?",
                           (SOURCE, v.value_id)).fetchone()
        if row is None:
            continue
        compared += 1
        new = to_iso(to_utc(v.time))
        if new == row[0]:
            held += 1
        elif abs((datetime.fromisoformat(new.replace("Z", "+00:00"))
                  - datetime.fromisoformat(row[0].replace("Z", "+00:00"))).total_seconds()) == abs(off - old_off):
            moved += 1
    if compared == 0:                           # compared nothing: says nothing about the conversion
        return
    _set(conn, "news.clock_check", json.dumps({"at": to_iso(now), "from_s": old_off, "to_s": off, "held": held,
                                               "moved": moved}))


def _bridge_offset(conn: sqlite3.Connection, session: str) -> int | None:
    """The server offset of the latest snapshot: from the post's own bridge session if stored, else the newest."""
    row = conn.execute("SELECT server_offset_s FROM bridge_status WHERE bridge_session = ?"
                       " ORDER BY last_seen_utc DESC LIMIT 1", (session,)).fetchone()
    if row is None:
        row = conn.execute("SELECT server_offset_s FROM bridge_status ORDER BY last_seen_utc DESC LIMIT 1").fetchone()
    return None if row is None else int(row[0])


def apply_calendar(conn: sqlite3.Connection, cfg, payload, now: datetime) -> CalendarResult:
    """Validate and store one post (see the module docstring). Raises PayloadError or StaleCalSeq."""
    post = validate(payload)
    check_skew(cfg, post, now)                  # the terminal's UTC clock (gmt_time) against this server's
    off = measured_offset_s(post.server_time, post.gmt_time)

    def to_utc(t: int) -> datetime:
        return datetime.fromtimestamp(t - off, UTC)

    with db.transaction(conn):
        if _meta(conn, "news.bridge_session") == post.bridge_session:
            last = _meta(conn, "news.cal_seq")
            if last is not None and post.cal_seq <= int(last):
                raise StaleCalSeq(post.cal_seq)
        if not storage.raw_allowed(conn):
            return CalendarResult(post.cal_seq, 0, len(post.values))
        bridge_off = _bridge_offset(conn, post.bridge_session)
        if bridge_off is not None and bridge_off != off:
            _set(conn, "news.ignored", json.dumps({"at": to_iso(now), "post_offset_s": off,
                                                   "bridge_offset_s": bridge_off}))
            return CalendarResult(post.cal_seq, 0, len(post.values), "clock")
        cur = [c for c in post.currencies if c in cfg.news.currencies]
        values = [v for v in post.values if v.currency in cur]
        old = _meta(conn, "news.offset_s")
        if old is not None and int(old) != off:
            _clock_check(conn, post, cur, int(old), off, to_utc, now)
        if cur:
            lo, hi = to_iso(to_utc(post.from_)), to_iso(to_utc(post.to))
            ids = [v.value_id for v in values]
            keep = f" AND source_id NOT IN ({','.join('?' * len(ids))})" if ids else ""
            conn.execute(f"DELETE FROM news_event WHERE source = ? AND currency IN ({','.join('?' * len(cur))})"
                         f" AND event_utc >= ? AND event_utc <= ?{keep}", (SOURCE, *cur, lo, hi, *ids))
        stamp = to_iso(now)
        updates = ", ".join([f"{c} = excluded.{c}" for c in _COLUMNS if c not in _KEEP]
                            + ["actual_first_utc = COALESCE(news_event.actual_first_utc, excluded.actual_first_utc)"])
        sql = (f"INSERT INTO news_event ({', '.join(_COLUMNS)}) VALUES ({', '.join('?' * len(_COLUMNS))})"
               f" ON CONFLICT(source, source_id) DO UPDATE SET {updates}")
        for v in values:
            when = to_utc(v.time)
            if v.time_mode == "datetime":
                day = trading_day(when, cfg.day.boundary_tz, cfg.day.boundary_hour)
            else:                                   # the source's own date: the server wall date
                day = datetime.fromtimestamp(v.time, UTC).date()
            nums = [fmt_value(x, v.digits, v.unit, v.multiplier)
                    for x in (v.actual, v.forecast, v.previous, v.revised_previous)]
            prev = v.revised_previous if v.revised_previous is not None else v.previous
            conn.execute(sql, (SOURCE, v.value_id, v.currency, v.country, v.name, v.type, v.importance,
                               MODE_MAP[v.time_mode], to_iso(when), day.isoformat(), *nums, stamp, stamp, v.digits,
                               v.actual, v.forecast, prev, stamp if v.actual is not None else None,
                               v.impact if v.impact in ("positive", "negative") else None))
        _set(conn, "news.last_ok_utc", stamp)
        _set(conn, "news.bridge_session", post.bridge_session)
        _set(conn, "news.cal_seq", post.cal_seq)
        _set(conn, "news.offset_s", off)
    return CalendarResult(post.cal_seq, len(values), len(post.values) - len(values))
