"""The news blocks of /api/today, /api/calendar and /api/settings (read-only; every query keeps to
news.currencies). Names and values are third-party calendar text, shown as data (the screens escape them).

Each row carries, beside its values: the read once its actual is out (app/news/families.py: MT5's own label, else
the untested textbook read; ruling R2), "waiting" for a released number not in yet (30 minutes), and the past move
record of its event type when one is built on this server and the row passes its clock guard (app/news/records.py;
ruling R7). One record per event type at a release minute: companion rows show none.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta

from app.news import families, moverecord, records
from app.news.store import state
from app.timeutil import from_iso, to_iso, trading_day

SOURCE_LABELS = {"mt5": "MT5 calendar"}
WAITING_MIN = 30
_ROW = "SELECT * FROM news_event WHERE currency IN ({cur}) AND (impact IN ({imp}) OR kind = 'holiday')"


def _in(values) -> str:
    return ",".join("?" * len(values))


class _Rows:
    """Builds the row dicts of one block: one record per event type and release minute."""

    def __init__(self, cfg, now: datetime | None):
        self.now = now
        self.recs = records.load(records.var_of(cfg)) if cfg.news.show_record else records.RecordSet()
        self.seen: set = set()

    def row(self, r: sqlite3.Row) -> dict:
        now = self.now
        released = r["time_mode"] == "exact" and now is not None and r["event_utc"] <= to_iso(now)
        rd = families.read(r)
        rec = None
        key = families.record_key(r) if self.recs.rows else None
        if key is not None and key in self.recs.rows and (key, r["event_utc"]) not in self.seen:
            self.seen.add((key, r["event_utc"]))
            rec = records.shown(self.recs.rows[key])
        waiting = bool(released and r["kind"] == "indicator" and r["actual"] is None and now is not None
                       and now <= from_iso(r["event_utc"]) + timedelta(minutes=WAITING_MIN))
        return {"key": f"{r['source']}:{r['source_id']}", "currency": r["currency"], "country": r["country"],
                "name": r["name"], "kind": r["kind"], "impact": r["impact"], "time_mode": r["time_mode"],
                "event_utc": r["event_utc"], "day": r["day"], "actual": r["actual"], "forecast": r["forecast"],
                "previous": r["revised"] if r["revised"] is not None else r["previous"], "released": released,
                "actual_src": "mt5" if r["actual"] is not None else None, "surprise": rd["surprise"],
                "effect": rd["effect"], "read": rd["read"], "read_by": rd["read_by"], "result": rd["text"],
                "record": rec, "waiting": waiting}


def _last_ok(conn: sqlite3.Connection) -> str | None:
    return state(conn)["last_ok_utc"]


def today_block(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    n = cfg.news
    if not n.enabled:
        return {"enabled": False, "events": []}
    last = _last_ok(conn)
    stale = last is None or (now - from_iso(last)).total_seconds() > n.stale_after_min * 60
    end = now + timedelta(hours=n.upcoming_hours)
    d = cfg.day
    sql = (_ROW.format(cur=_in(n.currencies), imp=_in(n.show_impacts))
           + " AND ((time_mode = 'exact' AND event_utc BETWEEN ? AND ?)"
             " OR (time_mode != 'exact' AND day BETWEEN ? AND ?))"
             " ORDER BY event_utc, currency, name LIMIT 60")
    rows = conn.execute(sql, (*n.currencies, *n.show_impacts, to_iso(now - timedelta(hours=2)), to_iso(end),
                              trading_day(now, d.boundary_tz, d.boundary_hour).isoformat(),
                              trading_day(end, d.boundary_tz, d.boundary_hour).isoformat())).fetchall()
    b = _Rows(cfg, now)
    return {"enabled": True, "source_label": SOURCE_LABELS.get(n.source, n.source), "last_ok_utc": last,
            "stale": stale, "hours": n.upcoming_hours, "events": [b.row(r) for r in rows]}


def calendar_block(conn: sqlite3.Connection, cfg, month: str, now: datetime | None = None) -> dict:
    """Per trading day of the month, how many high and medium releases (exact rows of the shown impacts), and the
    month's rows (shown impacts and holidays) for the day sheet. `enabled` lets the screen hide its news legend."""
    n = cfg.news
    if not n.enabled:
        return {"enabled": False, "days": {}, "events": []}
    days: dict[str, dict[str, int]] = {}
    for r in conn.execute(f"SELECT day, impact, COUNT(*) FROM news_event WHERE currency IN ({_in(n.currencies)})"
                          f" AND impact IN ({_in(n.show_impacts)}) AND time_mode = 'exact' AND day LIKE ? || '-%'"
                          " GROUP BY day, impact ORDER BY day", (*n.currencies, *n.show_impacts, month)):
        days.setdefault(r[0], {"high": 0, "medium": 0})[r[1]] = r[2]
    rows = conn.execute(_ROW.format(cur=_in(n.currencies), imp=_in(n.show_impacts))
                        + " AND day LIKE ? || '-%' ORDER BY event_utc LIMIT 400",
                        (*n.currencies, *n.show_impacts, month)).fetchall()
    b = _Rows(cfg, now)
    return {"enabled": True, "days": days, "events": [b.row(r) for r in rows]}


def record_block(conn: sqlite3.Connection, cfg) -> dict:
    """The move record's state for Settings and check.py: off, waiting for the feed, building, paused, halted,
    broken or done (counts only)."""
    n = cfg.news
    if not (n.enabled and n.show_record):
        return {"state": "off"}
    recs = records.load(records.var_of(cfg))
    if recs.rows:
        return {"state": "done", "types": len(recs.rows), "built_utc": recs.built_utc}
    if recs.broken:
        return {"state": "broken"}
    st = moverecord.state(conn) or {}
    feed = bool(cfg.feed.enabled and cfg.secrets.oanda_token)
    s = st.get("state")
    if s in ("building", "paused", "halted"):
        return {"state": s, "done": int(st.get("done") or 0), "total": int(st.get("total") or 0),
                "next_try_utc": st.get("next_try_utc"), "error": st.get("error"), "feed": feed}
    return {"state": "waiting", "feed": feed}


def settings_block(conn: sqlite3.Connection, cfg) -> dict:
    n = cfg.news
    return {"enabled": n.enabled, "source_label": SOURCE_LABELS.get(n.source, n.source),
            "currencies": list(n.currencies), "show_impacts": list(n.show_impacts),
            "alert_impacts": list(n.alert_impacts), "alert_before_min": n.alert_before_min, "keep_days": n.keep_days,
            "last_ok_utc": _last_ok(conn), "result_alerts": n.result_alerts, "show_record": n.show_record,
            "record": record_block(conn, cfg)}
