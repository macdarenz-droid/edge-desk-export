"""Phone alerts by Web Push from the app's own server: the client, transport and saved phones (push.py),
alert texts and the queue (alerts.py), and the schedule that runs every few seconds (monitor.py). The VAPID
private key comes only from EDGE_VAPID_PRIVATE_KEY, the contact from EDGE_VAPID_SUBJECT."""
