"""Web Push from the app's own server: VAPID keys, the transport (pywebpush), the alert client with the
queue rules, and the saved phones (table push_subscription). Only the transport changed from before: the
alert kinds, texts, priorities, rate limits, retries and full details are the same.

Sources (checked 2026-10-11):
  https://pypi.org/project/pywebpush/2.5.0/ (README) and https://github.com/web-push-libs/pywebpush
    webpush(subscription_info, data=None, vapid_private_key=None, vapid_claims=None,
    content_encoding="aes128gcm", curl=False, timeout=None, ttl=0, verbose=False, headers=None,
    requests_session=None) -> requests.Response; raises WebPushException(message, response) when the push
    service answers above 202 (.status_code, .retry_after, .response). vapid_private_key may be a
    py_vapid.Vapid (built once here with Vapid.from_string on the raw 32-byte key). vapid_claims is changed
    by the call (aud and exp filled in), so every push gets a fresh {"sub": subject}.
  RFC 8030 (HTTP Web Push): TTL is required (5.2); Urgency very-low / low / normal / high (5.3); a push
    service must accept a body of 4,096 bytes (7.2); 404 for an expired subscription (7.3); 429 with
    Retry-After when rate limited (8.4). Push services answer 410 for a subscription that is no longer valid
    (https://autopush.readthedocs.io/en/latest/http.html "410 ... should no longer be used").
  RFC 8291 section 4: 4,096 bytes of body leave at most 3,993 bytes of plaintext; alerts here stay at or
    under MAX_PAYLOAD_BYTES (3,000) and the stored alert row keeps the full text.
  RFC 8292 (VAPID): the browser's applicationServerKey is the uncompressed P-256 public key (65 bytes,
    first byte 0x04, base64url), https://developer.mozilla.org/en-US/docs/Web/API/PushManager/subscribe .
Rate limits kept on purpose (owner: "keep the rate limits"), the same figures as the earlier transport:
at most one alert every max(10, notify.min_interval_s) seconds and DAILY_CAP alerts per UTC day; each
retry round counts as one. Those two limits are for the whole client; a pause a push service asks for
(Retry-After) or a back-off after a failure belongs to that one phone only, so one phone never holds the
others. Nothing secret goes into an error, a log or repr(): the endpoint, the phone keys and the private
key are masked, and the HTTP library's own log (it writes the full request URL) is kept at ERROR.
The server posts only to the five push service host names below: an endpoint must be a plain https URL
(RFC 3986 characters only, a host of letters, digits, dots and dashes) that urllib.parse and urllib3 (what
requests connects with) both read as the same host, it is checked again before every push, and the
transport never follows a redirect.
"""
from __future__ import annotations

import base64
import binascii
import json
import logging
import re
import sqlite3
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from typing import Callable, Iterable
from urllib.parse import urlsplit

from app import db
from app.config import P256_ORDER, vapid_key_bytes
from app.timeutil import now_utc, to_iso

__all__ = ["P256_ORDER", "PushClient", "PushResult", "WebPushTransport", "count_subscriptions",
           "delete_subscription", "generate_private_key", "library_available", "list_subscriptions", "payload",
           "public_key_b64url", "save_subscription", "url_for", "urgency_for"]

MIN_INTERVAL_FLOOR_S = 10
DAILY_CAP = 125
DEFAULT_429_WAIT_S = 60        # a 429 without Retry-After: wait a minute before the next try
MAX_RETRY_AFTER_S = 24 * 3600  # a Retry-After is honoured for at most a day (a larger one is a broken answer)
LEFT_BEHIND_MAX_S = 15 * 60    # a phone that failed while another took the alert is tried at least this often
# A news alert is no use after the release: its push expires in 10 minutes (news.alert_before_min is at least 10,
# app/config.py NEWS_MIN_BEFORE_MIN), whatever notify.push_ttl_s says. A released number and a Fed or ECB policy
# headline are old news after 15 minutes.
# An A+ order is no use after its 11:00 London cancel: most arm 08:00-10:05 London, so its push expires in 3 hours
# at most (app/aplus/alerts.py ORDER_TTL_S), and never later than its own cancel (expires_ts below; the drain also
# drops one still queued after the cancel).
KIND_TTL_S = {"news_soon": 600, "news_result": 900, "headline_policy": 900, "aplus_order": 10800}
MAX_WAIT_S = 120               # longest one send() blocks before giving the alert back to the queue
TIMEOUT_S = 10
MAX_PAYLOAD_BYTES = 3000
TITLE_MAX = 200
MAX_DEVICES = 10               # phones that can be saved; every alert goes to each of them
MAX_ENDPOINT_LEN = 1024
USER_AGENT_MAX = 200
ERROR_MAX = 300
INSTALL_HINT = "pip install --require-hashes -r requirements.txt"
# Push service hosts a browser subscription may point at; the server never posts an alert anywhere else.
# Exact hosts where the service publishes one, else the regional pattern its official docs declare
# (A1(c), 11 Oct review; each source read 16 Oct 2026):
PUSH_HOST_SOURCES = {
    # Chrome (FCM, VAPID): "https://fcm.googleapis.com/fcm/send/ABCD1234"
    "fcm.googleapis.com": "https://developer.chrome.com/blog/web-push-interop-wins",
    # Firefox (autopush), production "Endpoint: https://updates.push.services.mozilla.com/"
    "updates.push.services.mozilla.com": "https://mozilla-services.github.io/autopush-rs/",
    # Safari: "allow access for https://*.push.apple.com" (one label read, for example web.push.apple.com)
    r"[a-z0-9-]+\.push\.apple\.com": "https://developer.apple.com/documentation/usernotifications/"
                                    "sending-web-push-notifications-in-web-apps-and-browsers",
    # Edge (WNS): CloudServiceDNS "*.notify.windows.com", regional hosts such as wns2-par02p.notify.windows.com
    r"[a-z0-9-]+\.notify\.windows\.com": "https://learn.microsoft.com/en-us/windows/apps/develop/notifications/"
                                        "push-notifications/firewall-allowlist-config",
}
PUSH_HOSTS = ("fcm.googleapis.com", "updates.push.services.mozilla.com")
PUSH_HOST_PATTERNS = tuple(re.compile(k) for k in PUSH_HOST_SOURCES if k not in PUSH_HOSTS)


def host_allowed(host: str) -> bool:
    """True only for an exact push host or a full match of a declared regional pattern (lower-case host)."""
    return host in PUSH_HOSTS or any(p.fullmatch(host) for p in PUSH_HOST_PATTERNS)
LIVE_KINDS = frozenset({"filled", "closed", "stop_moved", "move_stop_to_entry", "close_or_trail", "no_stop",
                        "bridge_silent", "terminal_can_trade", "clock_mismatch"})
_TAG_RE = re.compile(r"[a-z0-9_+-]{1,32}")
_B64URL = re.compile(r"[A-Za-z0-9_-]+={0,2}")
_MASK = "<hidden>"
# RFC 3986 section 2: unreserved, reserved and "%" (escapes) are the only characters a URL may hold. A
# backslash is not one of them, and it is where urllib.parse and urllib3 disagree on the host (SEC-PUSH-1).
_URL_CHARS = re.compile(r"[A-Za-z0-9._~:/?#\[\]@!$&'()*+,;=%-]+")
_ENDPOINT_RE = re.compile(r"(?i:https)://(?P<host>[A-Za-z0-9](?:[A-Za-z0-9.-]{0,251}[A-Za-z0-9])?)(?::443)?"
                          r"(?:[/?][^#]*)?")
# P-256 curve y^2 = x^3 - 3x + b over the prime field p (SEC 2 v2, section 2.4.2).
_P = 2 ** 256 - 2 ** 224 + 2 ** 192 + 2 ** 96 - 1
_B = 0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B


# ---------------------------------------------------------------- keys


def _b64u(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _unb64u(text: str) -> bytes:
    if not isinstance(text, str) or not _B64URL.fullmatch(text):
        raise ValueError("not base64url")
    try:
        return base64.urlsafe_b64decode(text.rstrip("=") + "=" * (-len(text.rstrip("=")) % 4))
    except (binascii.Error, ValueError):
        raise ValueError("not base64url") from None


def generate_private_key() -> str:
    """A new VAPID private key: the raw 32-byte P-256 scalar in base64url, no padding."""
    from cryptography.hazmat.primitives.asymmetric import ec
    value = ec.generate_private_key(ec.SECP256R1()).private_numbers().private_value
    return _b64u(value.to_bytes(32, "big"))


def public_key_b64url(private_b64url: str) -> str:
    """The browser's applicationServerKey: the uncompressed public point (65 bytes) in base64url."""
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    d = int.from_bytes(vapid_key_bytes(private_b64url), "big")
    point = ec.derive_private_key(d, ec.SECP256R1()).public_key().public_bytes(Encoding.X962,
                                                                               PublicFormat.UncompressedPoint)
    return _b64u(point)


def library_available() -> bool:
    """True when pywebpush (and what it needs) imports."""
    try:
        import py_vapid  # noqa: F401
        import pywebpush  # noqa: F401
    except ImportError:
        return False
    return True


# ---------------------------------------------------------------- payload


def urgency_for(priority: int) -> str:
    """RFC 8030 Urgency: 4-5 high, 3 normal, 1-2 low."""
    return "high" if priority >= 4 else "normal" if priority == 3 else "low"


def url_for(kind: str) -> str:
    """Where a tap on the alert opens the app: Live for positions, stops and incidents, else Today."""
    return "/#live" if kind in LIVE_KINDS else "/#today"


def _cap(text: str, n: int) -> str:
    return text if len(text) <= n else text[: n - 3] + "..."


def _dump(obj: dict) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def expires_ts(kind: str, key: str) -> int | None:
    """When an alert's push is no use any more (unix s), or None: an A+ order at its 11:00 London cancel. Its push TTL
    is cut to the time left, so a phone that comes back online after the cancel never gets it."""
    if kind == "aplus_order":
        from app.aplus.alerts import order_expires_ts
        return order_expires_ts(key)
    return None


def payload(title: str, body: str, priority: int, kind: str, key: str, tags: Iterable[str]) -> bytes:
    """The UTF-8 JSON the service worker shows, at most MAX_PAYLOAD_BYTES (the body is cut with "...")."""
    obj = {"title": _cap(title, TITLE_MAX), "body": body, "priority": priority, "kind": kind, "key": key,
           "tags": list(tags), "url": url_for(kind)}
    data = _dump(obj)
    if len(data) <= MAX_PAYLOAD_BYTES:
        return data
    lo, hi = 0, len(body)
    while lo < hi:                                  # the longest cut body that still fits
        mid = (lo + hi + 1) // 2
        if len(_dump(dict(obj, body=body[:mid] + "..."))) <= MAX_PAYLOAD_BYTES:
            lo = mid
        else:
            hi = mid - 1
    data = _dump(dict(obj, body=body[:lo] + "..."))
    if len(data) > MAX_PAYLOAD_BYTES:
        raise ValueError("alert kind or key too long for a push")
    return data


# ---------------------------------------------------------------- masking


def _secrets_of(sub: dict | None) -> list[str]:
    if not isinstance(sub, dict):
        return []
    out = []
    ep = sub.get("endpoint")
    if isinstance(ep, str) and ep:
        parts = urlsplit(ep)
        out += [ep, parts.path, parts.query, f"{parts.path}?{parts.query}"]
        out += [seg for seg in re.split(r"[/?&=]", f"{parts.path}?{parts.query}") if len(seg) >= 8]
    keys = sub.get("keys") if isinstance(sub.get("keys"), dict) else {}
    out += [v for v in (keys.get("p256dh"), keys.get("auth"), sub.get("p256dh"), sub.get("auth"))
            if isinstance(v, str)]
    return out


def _mask(text: str, secrets: Iterable[str]) -> str:
    for s in sorted({s for s in secrets if isinstance(s, str) and len(s) >= 4}, key=len, reverse=True):
        text = text.replace(s, _MASK)
    return text[:ERROR_MAX]


def _retry_after(value, now: datetime) -> float | None:
    """Retry-After as seconds: a number of seconds or an HTTP date (RFC 9110 section 10.2.3)."""
    if value is None:
        return None
    value = str(value).strip()
    if value.isascii() and value.isdigit():
        return float(value)
    try:
        when = parsedate_to_datetime(value)
    except (TypeError, ValueError, IndexError):
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    return max(0.0, (when - now).total_seconds())


# ---------------------------------------------------------------- transport


@dataclass(frozen=True)
class PushResult:
    ok: bool
    status: int | None             # HTTP status from the push service; None when no answer came back
    retry_after_s: float | None    # from Retry-After on 429 / 503
    gone: bool                     # 404 / 410: the subscription no longer exists
    error: str | None              # short, masked


def _no_redirect_session(requests):
    """A requests.Session class that never follows a redirect (SEC-PUSH-2): the host allow-list checks only
    the saved endpoint, so a 3xx comes back as that status (HTTP 3xx, a failed push) instead of the alert
    being posted again to wherever Location points. pywebpush calls session.post(endpoint, ...), which goes
    through request(), where allow_redirects=False is forced. (max_redirects = 0 is not set: requests then
    raises TooManyRedirects even without following, because it still works out the next request.)"""

    class NoRedirectSession(requests.Session):
        def request(self, method, url, *args, **kwargs):
            kwargs["allow_redirects"] = False
            return super().request(method, url, *args, **kwargs)

    return NoRedirectSession


def _quiet_http_log() -> None:
    """urllib3 logs the full request URL (the secret endpoint) at DEBUG for every request and at WARNING
    when a response header cannot be parsed (SEC-PUSH-3). It logs nothing at ERROR or above, so ERROR keeps
    every endpoint out of the server log whatever level the app runs at."""
    lg = logging.getLogger("urllib3")
    if lg.level < logging.ERROR:
        lg.setLevel(logging.ERROR)


class WebPushTransport:
    """Encrypts (aes128gcm) and signs (VAPID) one alert for one subscription with pywebpush, and posts it.
    send() never raises: every outcome is a PushResult. It does not check the host allow-list (the
    subscription store and PushClient do) and never follows a redirect."""

    def __init__(self, private_key_b64url: str, subject: str, timeout_s: float = TIMEOUT_S,
                 clock: Callable[[], datetime] | None = None):
        try:
            raw = vapid_key_bytes(private_key_b64url)
        except ValueError as exc:
            raise ValueError(f"VAPID private key {exc}") from None
        if not isinstance(subject, str) or not subject:
            raise ValueError("VAPID subject missing")
        try:                                              # imported here: only a server with push needs them
            import requests
            from py_vapid import Vapid
            from pywebpush import WebPushException, webpush
        except ImportError as exc:
            raise ImportError(f"pywebpush is not installed ({INSTALL_HINT})") from exc
        self._webpush = webpush
        self._exception = WebPushException
        self._session_cls = _no_redirect_session(requests)
        _quiet_http_log()
        self._key_text = _b64u(raw)
        self._vapid = Vapid.from_string(self._key_text)   # built once
        self._subject = subject
        self.timeout_s = float(timeout_s)
        self._clock = clock or now_utc

    def __repr__(self) -> str:
        return f"WebPushTransport(timeout_s={self.timeout_s})"

    __str__ = __repr__

    def _mask(self, text: str, subscription) -> str:
        return _mask(text, [self._key_text, *_secrets_of(subscription)])

    def send(self, subscription: dict, data: bytes, ttl: int, urgency: str) -> PushResult:
        try:
            with self._session_cls() as session:      # a fresh session per push: no cookies carried over
                resp = self._webpush(subscription_info=subscription, data=data, vapid_private_key=self._vapid,
                                     vapid_claims={"sub": self._subject}, headers={"Urgency": urgency},
                                     ttl=int(ttl), timeout=self.timeout_s, requests_session=session)
        except self._exception as exc:
            status = exc.status_code
            if status is None:
                return PushResult(False, None, None, False, self._mask(f"push error: {exc.message}", subscription))
            if 200 <= status < 300:
                return PushResult(True, status, None, False, None)
            retry = _retry_after(exc.retry_after, self._clock()) if status in (429, 503) else None
            return PushResult(False, status, retry, status in (404, 410), f"HTTP {status}")
        except Exception as exc:  # noqa: BLE001 - network failures and bad keys become a result, never a crash
            return PushResult(False, None, None, False,
                              self._mask(f"network error: {type(exc).__name__}: {exc}", subscription))
        return PushResult(True, getattr(resp, "status_code", None), None, False, None)


# ---------------------------------------------------------------- saved phones


def _urllib3_host(endpoint: str) -> tuple[str, int | None] | None:
    """The host and port requests / urllib3 would connect to, or None when urllib3 is not installed (then
    nothing can post either). ValueError when urllib3 cannot read the address."""
    try:
        from urllib3.exceptions import LocationParseError
        from urllib3.util import parse_url
    except ImportError:
        return None
    try:
        u = parse_url(endpoint)
    except LocationParseError:
        raise ValueError("endpoint is not a valid address") from None
    if u.auth is not None:
        raise ValueError("endpoint must be a plain https address of a push service")
    return (u.host or "").lower(), u.port


def _endpoint_ok(endpoint) -> str:
    """The endpoint when it is a plain https URL of one of PUSH_HOSTS that every parser on the way reads the
    same, else ValueError (the message never repeats the endpoint)."""
    if not isinstance(endpoint, str) or not endpoint:
        raise ValueError("endpoint must be a push service https address")
    if len(endpoint) > MAX_ENDPOINT_LEN:
        raise ValueError(f"endpoint longer than {MAX_ENDPOINT_LEN} characters")
    if not _URL_CHARS.fullmatch(endpoint):
        raise ValueError("endpoint has spaces or characters a URL cannot have")
    try:
        parts = urlsplit(endpoint)
        port = parts.port
    except ValueError:
        raise ValueError("endpoint is not a valid address") from None
    if parts.scheme != "https":
        raise ValueError("endpoint must be https")
    m = _ENDPOINT_RE.fullmatch(endpoint)
    if (m is None or parts.username is not None or parts.password is not None or port not in (None, 443)
            or parts.fragment):
        raise ValueError("endpoint must be a plain https address of a push service")
    host = m["host"].lower()
    if not host_allowed(host):
        raise ValueError("endpoint is not a known push service (Apple, Google, Mozilla or Microsoft)")
    seen = _urllib3_host(endpoint)
    if (parts.hostname or "").lower() != host or (seen is not None and seen != (host, port)):
        raise ValueError("endpoint is not a valid address")
    return endpoint


def _on_p256(point: bytes) -> bool:
    x, y = int.from_bytes(point[1:33], "big"), int.from_bytes(point[33:], "big")
    return x < _P and y < _P and (y * y - (x * x * x - 3 * x + _B)) % _P == 0


def _keys_ok(keys) -> tuple[str, str]:
    if not isinstance(keys, dict) or set(keys) != {"p256dh", "auth"}:
        raise ValueError("keys must hold exactly p256dh and auth")
    try:
        point, auth = _unb64u(keys["p256dh"]), _unb64u(keys["auth"])
    except ValueError:
        raise ValueError("keys must be base64url text") from None
    if len(point) != 65 or point[0] != 0x04 or not _on_p256(point):
        raise ValueError("p256dh must be a P-256 public key (65 bytes, uncompressed)")
    if len(auth) != 16:
        raise ValueError("auth must be 16 bytes")
    return _b64u(point), _b64u(auth)


def save_subscription(conn: sqlite3.Connection, sub: dict, user_agent: str, now: datetime) -> int:
    """Save one phone (upsert by endpoint) and return its row id. ValueError with a plain message on bad
    input; the message never repeats what was sent."""
    if not isinstance(sub, dict):
        raise ValueError("subscription must be an object with endpoint and keys")
    endpoint = _endpoint_ok(sub.get("endpoint"))
    p256dh, auth = _keys_ok(sub.get("keys"))
    agent = user_agent if isinstance(user_agent, str) else ""
    agent = "".join(c for c in agent if c.isprintable())[:USER_AGENT_MAX]
    with db.transaction(conn):
        row = conn.execute("SELECT id FROM push_subscription WHERE endpoint = ?", (endpoint,)).fetchone()
        if row is not None:
            conn.execute("UPDATE push_subscription SET p256dh = ?, auth = ?, user_agent = ?, failures = 0,"
                         " last_error = NULL WHERE id = ?", (p256dh, auth, agent, row["id"]))
            return int(row["id"])
        if conn.execute("SELECT COUNT(*) FROM push_subscription").fetchone()[0] >= MAX_DEVICES:
            raise ValueError(f"at most {MAX_DEVICES} phones; turn alerts off on one first")
        cur = conn.execute("INSERT INTO push_subscription (endpoint, p256dh, auth, user_agent, created_utc)"
                           " VALUES (?, ?, ?, ?, ?)", (endpoint, p256dh, auth, agent, to_iso(now)))
        return int(cur.lastrowid)


def delete_subscription(conn: sqlite3.Connection, endpoint: str) -> bool:
    """Remove a phone by its endpoint. True when one was removed."""
    if not isinstance(endpoint, str):
        raise ValueError("endpoint must be text")
    with db.transaction(conn):
        return conn.execute("DELETE FROM push_subscription WHERE endpoint = ?", (endpoint,)).rowcount == 1


def list_subscriptions(conn: sqlite3.Connection) -> list[dict]:
    """Every saved phone, oldest first (for the push client; the API never returns these)."""
    with db._LOCK:
        return [dict(r) for r in conn.execute(
            "SELECT id, endpoint, p256dh, auth, user_agent, created_utc, last_ok_utc, failures, last_error"
            " FROM push_subscription ORDER BY id")]


def count_subscriptions(conn: sqlite3.Connection) -> int:
    with db._LOCK:
        return int(conn.execute("SELECT COUNT(*) FROM push_subscription").fetchone()[0])


# ---------------------------------------------------------------- the client


def _transient(status: int | None) -> bool:
    return status is None or status == 429 or status >= 500


class PushClient:
    """Sends one alert at a time to every saved phone, spaced by at least `interval_s`, with retries.

    After send(): `last_attempts` is the number of rounds it made (one round = one push to each phone still
    waiting), `last_error` a short masked reason (None on success), `last_devices` how many phones accepted,
    `deferred` True when it pushed nothing because it would have had to wait longer than `max_wait_s` (the
    caller keeps the alert queued) and `skipped` True when there was nothing to push to (no transport or no
    phone saved). An alert counts as sent when at least one phone's push service accepted it. Per phone:
    accepted -> last_ok_utc; 404 / 410 (or an endpoint that no longer passes the host check) -> the row is
    deleted; anything else -> failures + 1 and last_error.

    The spacing and the daily cap are for the whole client. A pause is per phone (RT2-1): a 429 / 503
    Retry-After (at most MAX_RETRY_AFTER_S) or the back-off after a failure holds only that phone, and an
    alert goes at once to the phones that are not paused; it waits (or is deferred) only when every phone
    is paused. Retries (429, 5xx, no answer) run in rounds, up to max_attempts, only while no phone has
    taken the alert (RT2-2): once one has, the phones that failed get the next alert instead, after a
    back-off of their own that doubles each time (interval_s, 2x, 4x ... at most LEFT_BEHIND_MAX_S), so a
    dead second phone never slows alerts to the working one or uses up its daily cap.
    """

    def __init__(self, conn: sqlite3.Connection, transport, min_interval_s: float, max_attempts: int,
                 ttl_s: int, ttl_urgent_s: int, clock: Callable[[], datetime] | None = None,
                 sleep: Callable[[float], object] | None = None, max_wait_s: float = MAX_WAIT_S):
        if isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or max_attempts < 1:
            raise ValueError("max_attempts must be at least 1")
        for name, ttl in (("ttl_s", ttl_s), ("ttl_urgent_s", ttl_urgent_s)):
            if isinstance(ttl, bool) or not isinstance(ttl, int) or ttl < 0:
                raise ValueError(f"{name} must be a whole number of seconds")
        self._conn = conn
        self._transport = transport
        self.interval_s = max(float(min_interval_s), float(MIN_INTERVAL_FLOOR_S))
        self.max_attempts = max_attempts
        self.ttl_s, self.ttl_urgent_s = ttl_s, ttl_urgent_s
        self.max_wait_s = float(max_wait_s)
        self._clock = clock or now_utc
        self._sleep = sleep or time.sleep
        self._last_request: datetime | None = None
        self._hold: dict[int, datetime] = {}       # subscription id -> no push to that phone before this time
        self._behind: dict[int, int] = {}          # subscription id -> alerts in a row it failed and others took
        self._day: str | None = None
        self._day_count = 0
        self._lock = threading.Lock()
        self.last_attempts = 0
        self.last_error: str | None = None
        self.last_devices = 0
        self.deferred = False
        self.skipped = False

    def __repr__(self) -> str:
        return f"PushClient(transport={self._transport is not None}, interval_s={self.interval_s})"

    __str__ = __repr__

    @property
    def configured(self) -> bool:
        """Alerts can go out now: a transport (VAPID key and subject set) and at least one saved phone."""
        return self._transport is not None and count_subscriptions(self._conn) > 0

    @property
    def skip_reason(self) -> str:
        return "push not configured" if self._transport is None else "no phone saved for alerts"

    # ------------------------------------------------------------ helpers

    def _count_today(self, now: datetime) -> int:
        day = now.astimezone(timezone.utc).date().isoformat()
        if day != self._day:
            self._day, self._day_count = day, 0
        return self._day_count

    def _held_until(self, sub: dict, now: datetime) -> datetime | None:
        t = self._hold.get(sub["id"])
        return t if t is not None and t > now else None

    def _wait_s(self, now: datetime, pending: list[dict]) -> float:
        """Seconds until the next round: the client's spacing, and the earliest end of a pause only when
        every phone still waiting is paused."""
        targets = [self._last_request + timedelta(seconds=self.interval_s)] if self._last_request else []
        holds = [self._held_until(s, now) for s in pending]
        if holds and all(h is not None for h in holds):
            targets.append(min(holds))
        return max([0.0] + [(t - now).total_seconds() for t in targets])

    def _ready(self, pending: list[dict], now: datetime) -> list[dict]:
        ready = [s for s in pending if self._held_until(s, now) is None]
        if ready or not pending:
            return ready
        first = min(self._hold[s["id"]] for s in pending)      # the wait was for this one (a clock that lags)
        return [s for s in pending if self._hold[s["id"]] == first]

    def _push(self, sub: dict, data: bytes, ttl: int, urgency: str) -> PushResult:
        try:
            _endpoint_ok(sub["endpoint"])            # checked again before every push (SEC-PUSH-1)
        except ValueError:
            return PushResult(False, None, None, True, "endpoint is not a known push service; removed")
        info = {"endpoint": sub["endpoint"], "keys": {"p256dh": sub["p256dh"], "auth": sub["auth"]}}
        try:
            res = self._transport.send(info, data, ttl, urgency)
        except Exception as exc:  # noqa: BLE001 - a transport that raises is a failed push, never a crash
            res = PushResult(False, None, None, False, f"network error: {type(exc).__name__}: {exc}")
        error = _mask(res.error, _secrets_of(sub)) if res.error else None
        return PushResult(bool(res.ok), res.status, res.retry_after_s, bool(res.gone), error)

    def _record(self, sub: dict, res: PushResult, now: datetime) -> None:
        with db.transaction(self._conn):
            if res.ok:
                self._conn.execute("UPDATE push_subscription SET last_ok_utc = ? WHERE id = ?",
                                   (to_iso(now), sub["id"]))
            elif res.gone:
                self._conn.execute("DELETE FROM push_subscription WHERE id = ?", (sub["id"],))
            else:
                self._conn.execute("UPDATE push_subscription SET failures = failures + 1, last_error = ?"
                                   " WHERE id = ?", (res.error or "push failed", sub["id"]))

    def _retry_at(self, res: PushResult, now: datetime, attempt: int) -> datetime:
        ra = res.retry_after_s
        if res.status in (429, 503) and isinstance(ra, (int, float)) and not isinstance(ra, bool) and ra == ra:
            return now + timedelta(seconds=max(0.0, min(float(ra), float(MAX_RETRY_AFTER_S))))
        if res.status == 429:
            return now + timedelta(seconds=DEFAULT_429_WAIT_S)
        return now + timedelta(seconds=self.interval_s * 2 ** (attempt - 1))

    # ------------------------------------------------------------ send

    def send(self, title: str, message: str, priority: int = 3, tags: Iterable[str] = (), kind: str = "",
             key: str = "") -> bool:
        if isinstance(priority, bool) or not isinstance(priority, int) or not 1 <= priority <= 5:
            raise ValueError("priority must be an integer from 1 to 5")
        tags = tuple(tags)
        if any(not isinstance(t, str) or not _TAG_RE.fullmatch(t) for t in tags):
            raise ValueError("tags: lower-case letters, digits, _ + - only, at most 32 characters each")
        if not all(isinstance(x, str) for x in (title, message, kind, key)):
            raise ValueError("title, message, kind and key must be text")
        with self._lock:
            return self._send(title, message, priority, tags, kind, key)

    def _send(self, title, message, priority, tags, kind, key) -> bool:
        self.last_attempts, self.last_error, self.last_devices = 0, None, 0
        self.deferred = self.skipped = False
        if self._transport is None:
            self.skipped, self.last_error = True, self.skip_reason
            return False
        pending = list_subscriptions(self._conn)
        if not pending:
            self.skipped, self.last_error = True, self.skip_reason
            return False
        live = {s["id"] for s in pending}
        for state in (self._hold, self._behind):                 # forget phones that were removed
            for sid in [k for k in state if k not in live]:
                del state[sid]
        data = payload(title, message, priority, kind, key, tags)
        urgency = urgency_for(priority)
        ttl_kind = self.ttl_urgent_s if priority >= 4 else self.ttl_s
        ttl_kind = min(ttl_kind, KIND_TTL_S.get(kind, ttl_kind))
        expires = expires_ts(kind, key)
        accepted = 0
        for attempt in range(1, self.max_attempts + 1):
            wait = self._wait_s(self._clock(), pending)
            if wait > self.max_wait_s:
                self.deferred = attempt == 1
                self.last_error = self.last_error or f"waiting {int(wait)} s before the next alert"
                break
            if wait > 0:
                self._sleep(wait)
            now = self._clock()
            if self._count_today(now) >= DAILY_CAP:
                self.last_error = f"daily cap reached ({DAILY_CAP} alerts)"
                break
            ttl = ttl_kind if expires is None else min(ttl_kind, expires - int(now.timestamp()))
            if ttl <= 0:                     # an A+ order whose cancel time came while it waited: not sent
                self.last_error = "order time passed"
                break
            self._day_count += 1
            self._last_request = now
            self.last_attempts = attempt
            ready = self._ready(pending, now)
            still = {s["id"] for s in pending} - {s["id"] for s in ready}   # paused: not pushed this round
            failed = []
            for sub in ready:
                res = self._push(sub, data, ttl, urgency)
                self._record(sub, res, now)
                if res.ok:
                    accepted += 1
                    self._hold.pop(sub["id"], None)
                    self._behind.pop(sub["id"], None)
                    continue
                self.last_error = res.error or (f"HTTP {res.status}" if res.status else "push failed")
                if not res.gone and _transient(res.status):
                    self._hold[sub["id"]] = self._retry_at(res, now, attempt)
                    still.add(sub["id"])
                    failed.append(sub)
                else:
                    self._hold.pop(sub["id"], None)
                    if res.gone:
                        self._behind.pop(sub["id"], None)
            if accepted:                     # a phone took it: the others get the next alert (RT2-2)
                for sub in failed:
                    n = self._behind.get(sub["id"], 0) + 1
                    self._behind[sub["id"]] = n
                    back = now + timedelta(seconds=min(self.interval_s * 2 ** min(n - 1, 30), LEFT_BEHIND_MAX_S))
                    self._hold[sub["id"]] = max(self._hold[sub["id"]], back)
                break
            pending = [s for s in pending if s["id"] in still]
            if not pending:
                break
        self.last_devices = accepted
        if accepted:
            self.last_error = None
        return accepted > 0
