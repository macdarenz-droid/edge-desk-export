"""Paper-trade log: orders followed exactly as if real money were at stake (CLAUDE.md "Paper is real money")."""
