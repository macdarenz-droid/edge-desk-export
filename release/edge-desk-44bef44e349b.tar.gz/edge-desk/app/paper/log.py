"""Paper-trade log, EUR/USD only.

Life cycle: pending -> filled -> closed, or pending -> expired / cancelled. Any other move raises
ValueError. The paper `trade` row (book 'paper') is written at the fill (status 'open', so the day guard
sees the open risk) and completed at the close.

Results ("paper is real money"):
  planned risk   |entry - stop| / tick size * tick value * lots: the money the order put at risk when it
                 was logged (stored as risk_money; stop_pips is the planned stop). R is measured against
                 this plan, never against the fill, so a slipped fill shows as a bigger loss in R and a
                 better fill cannot inflate R.
  money          (signed move from the fill - cost) / tick size * tick value * lots, cost =
                 paper.cost_pips * pip_size (2.0, the pass case), booked in `fee`; financing =
                 paper.financing_pips_night per 17:00 New York close held over (a Wednesday close counts
                 paper.financing_wednesday_nights), booked in `swap`; net_profit = profit + fee + swap.
                 r_at_cost() gives the same trade at paper.cost_pips_info (1.6) for the line shown beside it
  r_gross        signed move from the fill / planned stop distance (no costs)
  r_net          net_profit / planned risk
  pct_of_balance net_profit / balance_at_open * 100 (the money moved, the same way as MT5 trades)
  balance        paper.balance (a fixed example scale; results are read in R and %)
Fills: a limit fills at its entry or better, a stop order at its entry or worse; anything else is
refused. A 'tp' exit is at or beyond the target, an 'sl' exit at or beyond the stop. With `now` given
(the API always gives it), a time later than now + FUTURE_SKEW is refused.
Day rules: a new paper order, and the fill of a resting one, need the paper day guard
(app.risk.flags.guard_now, book 'paper') to allow a new trade; `rule_break=True` logs it anyway, on
purpose (compute_flags then flags it). The order being filled does not count as pending against itself.
Size: lots from app.risk.sizing with paper.balance and the order's risk % (never above
risk.risk_pct_per_trade), with the EUR/USD contract below. No price source is wired in Phase 1;
`resolve_with_bars` is ready for one.
"""
from __future__ import annotations

import math
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Sequence

from app import db
from app.config import Config
from app.ingest.state import known_symbols
from app.risk.day_guard import STATUS_WORDS
from app.risk.flags import guard_now
from app.risk.sizing import lots_for_risk
from app.timeutil import from_iso, now_utc, session_of, to_iso, trading_day

# EUR/USD contract used for paper sizing (5-digit quotes, USD account: 1.0 per tick per lot).
EURUSD_TICK_SIZE = 0.00001
EURUSD_TICK_VALUE = 1.0
EURUSD_VOLUME_STEP = 0.01
EURUSD_VOLUME_MIN = 0.01

SIDES = ("buy", "sell")
ORDER_TYPES = ("limit", "stop", "market")
STATUSES = ("pending", "filled", "closed", "expired", "cancelled")
CLOSE_REASONS = ("tp", "sl", "be", "manual")
NOTE_MAX = 2000
_RISK_EPS = 1e-12
_PRICE_EPS = 1e-9         # float noise in typed prices, far below 0.01 pip
FUTURE_SKEW = timedelta(minutes=5)   # a fill or close time may run this far ahead of the server clock


class NotFoundError(LookupError, ValueError):
    """No paper order with that id."""


def _price(name: str, value) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a number")
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and above 0")
    return value


def _time(name: str, value) -> datetime:
    if isinstance(value, str):
        return from_iso(value)
    if not isinstance(value, datetime) or value.tzinfo is None:
        raise ValueError(f"{name} must be a time with a zone")
    return value


def _check_sides(side: str, entry: float, stop: float, target: float) -> None:
    if side == "buy" and not (stop < entry < target):
        raise ValueError("buy: the stop must be below the entry and the target above it")
    if side == "sell" and not (target < entry < stop):
        raise ValueError("sell: the stop must be above the entry and the target below it")


def _not_future(name: str, at: datetime, now: datetime | None) -> None:
    if now is not None and at > _time("now", now) + FUTURE_SKEW:
        raise ValueError(f"{name} is later than now")


def _day_guard(conn: sqlite3.Connection, cfg: Config, at: datetime, rule_break: bool, own_pending: int) -> None:
    """Refuse a new paper trade the paper day guard would not allow, unless logged as a rule break."""
    if rule_break:
        return
    pending = conn.execute("SELECT COUNT(*) FROM paper_order WHERE status = 'pending'").fetchone()[0]
    g = guard_now(conn, cfg, at, "paper", pending_orders=max(0, pending - own_pending))
    if not g.can_open_new:
        raise ValueError(f"{STATUS_WORDS.get(g.status, g.status)}: {g.reason}")


def _order(conn: sqlite3.Connection, order_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM paper_order WHERE id = ?", (order_id,)).fetchone()
    if row is None:
        raise NotFoundError(f"paper order {order_id} not found")
    return row


def _need(row: sqlite3.Row, status: str, action: str) -> None:
    if row["status"] != status:
        raise ValueError(f"cannot {action} an order that is {row['status']}")


def _broker_volume_max(conn: sqlite3.Connection, cfg: Config) -> float | None:
    """The broker's largest EUR/USD order (SYMBOL_VOLUME_MAX from the bridge), or None before the bridge sent it."""
    found = [info.get("volume_max") for name, info in known_symbols(conn, cfg.account.alias).items()
             if cfg.is_eurusd(name)]
    found = [float(v) for v in found if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0]
    return min(found) if found else None


def create_order(conn: sqlite3.Connection, cfg: Config, *, side: str, order_type: str, entry: float, stop: float,
                 target: float, expiry_utc: datetime | str | None = None, risk_pct: float | None = None,
                 lots: float | None = None, opportunity_id: int | None = None, note: str = "",
                 now: datetime, symbol: str | None = None, rule_break: bool = False) -> int:
    """Log a new paper order (status pending). Returns its id."""
    symbol = cfg.instrument.symbol if symbol is None else symbol
    if not cfg.is_eurusd(symbol):
        raise ValueError("paper orders are EUR/USD only")
    if side not in SIDES:
        raise ValueError(f"side must be one of {SIDES}")
    if order_type not in ORDER_TYPES:
        raise ValueError(f"order_type must be one of {ORDER_TYPES}")
    entry, stop, target = _price("entry", entry), _price("stop", stop), _price("target", target)
    _check_sides(side, entry, stop, target)
    if abs(entry - stop) < EURUSD_TICK_SIZE - _PRICE_EPS:
        # A stop a hair from the entry would size about a billion lots (red-team SEC-05).
        raise ValueError(f"the stop must be at least one tick ({EURUSD_TICK_SIZE:.5f}) from the entry")
    now = _time("now", now)
    expiry = None
    if expiry_utc is not None:
        expiry = _time("expiry_utc", expiry_utc)
        if expiry <= now:
            raise ValueError("expiry must be after now")
    cap = cfg.risk.risk_pct_per_trade
    risk_pct = cap if risk_pct is None else _price("risk_pct", risk_pct)
    if risk_pct > cap + _RISK_EPS:
        raise ValueError(f"risk_pct may not exceed the configured {cap}%")
    sized = lots_for_risk(cfg.paper.balance, risk_pct, entry, stop, EURUSD_TICK_SIZE, EURUSD_TICK_VALUE,
                          EURUSD_VOLUME_STEP, EURUSD_VOLUME_MIN)
    if sized <= 0:
        raise ValueError("stop too wide: even the minimum lot risks more than the configured %")
    if lots is None:
        lots = sized
    else:
        lots = _price("lots", lots)
        if lots > sized + 1e-9:
            raise ValueError(f"lots may not exceed {sized} (the configured risk at this stop)")
        if lots < EURUSD_VOLUME_MIN - 1e-9:
            raise ValueError(f"lots below the minimum {EURUSD_VOLUME_MIN}")
    vmax = _broker_volume_max(conn, cfg)
    if vmax is not None and lots > vmax + 1e-9:
        raise ValueError(f"{lots:g} lots is above the broker maximum {vmax:g}; widen the stop")
    if not isinstance(note, str) or len(note) > NOTE_MAX:
        raise ValueError(f"note must be text of at most {NOTE_MAX} characters")
    with db.transaction(conn):
        _day_guard(conn, cfg, now, rule_break, own_pending=0)
        if opportunity_id is not None and conn.execute("SELECT 1 FROM opportunity WHERE id = ?",
                                                       (opportunity_id,)).fetchone() is None:
            raise NotFoundError(f"opportunity {opportunity_id} not found")
        cur = conn.execute(
            """INSERT INTO paper_order (created_utc, opportunity_id, symbol, side, order_type, entry, stop, target,
                   expiry_utc, risk_pct, lots, status, note) VALUES (?,?,?,?,?,?,?,?,?,?,?, 'pending', ?)""",
            (to_iso(now), opportunity_id, symbol, side, order_type, entry, stop, target,
             to_iso(expiry) if expiry else None, risk_pct, lots, note))
        return cur.lastrowid


def financing_nights(cfg: Config, opened: datetime, closed: datetime) -> int:
    """Nights of financing for a paper trade held from `opened` to `closed`: each Monday-Friday 17:00 New York
    close in (opened, closed] counts 1, a Wednesday close counts paper.financing_wednesday_nights (A2)."""
    tz, hour = cfg.day.boundary_tz, cfg.day.boundary_hour
    if closed <= opened:
        return 0
    day = opened.astimezone(tz).date()
    last = closed.astimezone(tz).date()
    nights = 0
    while day <= last:
        if day.weekday() < 5:
            t = datetime(day.year, day.month, day.day, hour, tzinfo=tz)
            if opened < t <= closed:
                nights += cfg.paper.financing_wednesday_nights if day.weekday() == 2 else 1
        day += timedelta(days=1)
    return nights


def r_at_cost(trade: dict, cfg: Config, cost_pips: float) -> float | None:
    """A closed paper trade's R had it been charged `cost_pips` instead of paper.cost_pips (financing unchanged).
    Worked out from the fee it was actually charged; None unless that fee was paper.cost_pips (a bid/ask-resolved
    trade charged only slippage, or a trade closed under an older cost, has no comparable line)."""
    if trade.get("r_net") is None or not trade.get("stop_pips") or not trade.get("risk_money"):
        return None
    per_pip = float(trade["risk_money"]) / float(trade["stop_pips"])
    charged = -float(trade.get("fee") or 0.0) / per_pip
    if abs(charged - cfg.paper.cost_pips) > 1e-6:
        return None
    return trade["r_net"] + (charged - cost_pips) / trade["stop_pips"]


def _figures(cfg: Config, side: str, entry: float, fill: float, stop: float, exit_price: float | None,
             lots: float, balance: float, cost_pips: float = 0.0, nights: int = 0) -> dict:
    direction = 1.0 if side == "buy" else -1.0
    dist = abs(entry - stop)                                      # the planned stop distance
    per_price = EURUSD_TICK_VALUE / EURUSD_TICK_SIZE * lots      # money per 1.0 of price
    risk = dist * per_price
    out = {"risk_money": risk, "stop_pips": dist / cfg.instrument.pip_size}
    if exit_price is None:
        return out
    move = (exit_price - fill) * direction
    cost = cost_pips * cfg.instrument.pip_size
    financing = nights * cfg.paper.financing_pips_night * cfg.instrument.pip_size
    profit, fee, swap = move * per_price, -cost * per_price, -financing * per_price
    net = profit + fee + swap
    out.update(profit=profit, fee=fee, swap=swap, net_profit=net, r_gross=move / dist, r_net=net / risk,
               pct_of_balance=net / balance * 100.0)
    return out


def _check_fill_side(o, fill_price: float) -> None:
    """A limit fills at its entry or better, a stop order at its entry or worse (market: any price)."""
    side, kind, entry = o["side"], o["order_type"], float(o["entry"])
    better = fill_price <= entry + _PRICE_EPS if side == "buy" else fill_price >= entry - _PRICE_EPS
    worse = fill_price >= entry - _PRICE_EPS if side == "buy" else fill_price <= entry + _PRICE_EPS
    if kind == "limit" and not better:
        raise ValueError(f"a {side} limit fills at {entry:.5f} or better")
    if kind == "stop" and not worse:
        raise ValueError(f"a {side} stop order fills at {entry:.5f} or worse")


def fill(conn: sqlite3.Connection, cfg: Config, order_id: int, fill_price: float, filled_utc: datetime | str, *,
         now: datetime | None = None, rule_break: bool = False) -> dict:
    """pending -> filled. Writes the open paper trade. Returns the order."""
    fill_price = _price("fill_price", fill_price)
    filled = _time("filled_utc", filled_utc)
    _not_future("fill time", filled, now)
    d = cfg.day
    with db.transaction(conn):
        o = _order(conn, order_id)
        _need(o, "pending", "fill")
        if filled < from_iso(o["created_utc"]):
            raise ValueError("fill time is before the order was created")
        if o["expiry_utc"] and filled > from_iso(o["expiry_utc"]):
            raise ValueError("the order had expired by then")
        if (o["side"] == "buy" and not fill_price > o["stop"]) or (o["side"] == "sell" and not fill_price < o["stop"]):
            raise ValueError("fill price is through the stop")
        _check_fill_side(o, fill_price)
        _day_guard(conn, cfg, filled, rule_break, own_pending=1)
        conn.execute("UPDATE paper_order SET status = 'filled', filled_utc = ?, fill_price = ? WHERE id = ?",
                     (to_iso(filled), fill_price, order_id))
        f = _figures(cfg, o["side"], o["entry"], fill_price, o["stop"], None, o["lots"], cfg.paper.balance)
        conn.execute(
            """INSERT INTO trade (book, account_alias, paper_order_id, symbol, side, volume, status, open_utc,
                   open_price, initial_sl, initial_tp, risk_money, stop_pips, balance_at_open, trading_day, session)
               VALUES ('paper', ?, ?, ?, ?, ?, 'open', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (cfg.account.alias, order_id, o["symbol"], o["side"], o["lots"], to_iso(filled), fill_price, o["stop"],
             o["target"], f["risk_money"], f["stop_pips"], cfg.paper.balance,
             trading_day(filled, d.boundary_tz, d.boundary_hour).isoformat(),
             session_of(filled, d.boundary_tz, d.boundary_hour, d.london_open, d.ny_open)))
    return dict(_order(conn, order_id))


def _check_exit_side(o, reason: str, exit_price: float) -> None:
    """A 'tp' exit is at or beyond the target; an 'sl' exit at or beyond the (first) stop."""
    buy = o["side"] == "buy"
    if reason == "tp":
        target = float(o["target"])
        if (buy and exit_price < target - _PRICE_EPS) or (not buy and exit_price > target + _PRICE_EPS):
            raise ValueError(f"a target exit is at {target:.5f} or beyond")
    if reason == "sl":
        stop = float(o["stop"])
        if (buy and exit_price > stop + _PRICE_EPS) or (not buy and exit_price < stop - _PRICE_EPS):
            raise ValueError(f"a stop exit is at {stop:.5f} or beyond")


def close(conn: sqlite3.Connection, cfg: Config, order_id: int, exit_price: float, closed_utc: datetime | str,
          reason: str, *, now: datetime | None = None) -> int:
    """filled -> closed with reason tp | sl | be | manual, charging paper.cost_pips (spread and slippage).
    Completes the paper trade; returns the trade id."""
    return _close(conn, cfg, order_id, exit_price, closed_utc, reason, cfg.paper.cost_pips, now)


def close_resolved(conn: sqlite3.Connection, cfg: Config, order_id: int, res: Resolution,
                   slippage_pips: float = 0.0) -> int | None:
    """Book what resolve_with_bars found for an order: the fill (if still pending) and the exit.

    Bid/ask prices already hold the spread (a buy fills on the ask and exits on the bid), so only
    `slippage_pips` is charged, never paper.cost_pips a second time. Returns the trade id once closed,
    None while the result is still open.
    """
    if isinstance(slippage_pips, bool) or not isinstance(slippage_pips, (int, float)) \
            or not math.isfinite(slippage_pips) or slippage_pips < 0:
        raise ValueError("slippage_pips must be a number of at least 0")
    if res.status not in ("filled", "closed") or res.fill_utc is None:
        raise ValueError(f"nothing to book: the order is {res.status}")
    if _order(conn, order_id)["status"] == "pending":
        fill(conn, cfg, order_id, res.fill_price, res.fill_utc)
    if res.status != "closed":
        return None
    return _close(conn, cfg, order_id, res.exit_price, res.exit_utc, res.exit_reason, float(slippage_pips), None)


def _close(conn: sqlite3.Connection, cfg: Config, order_id: int, exit_price: float, closed_utc: datetime | str,
           reason: str, cost_pips: float, now: datetime | None) -> int:
    if reason not in CLOSE_REASONS:
        raise ValueError(f"reason must be one of {CLOSE_REASONS}")
    exit_price = _price("exit_price", exit_price)
    closed = _time("closed_utc", closed_utc)
    _not_future("close time", closed, now)
    d = cfg.day
    with db.transaction(conn):
        o = _order(conn, order_id)
        _need(o, "filled", "close")
        if closed < from_iso(o["filled_utc"]):
            raise ValueError("close time is before the fill")
        _check_exit_side(o, reason, exit_price)
        t = conn.execute("SELECT id FROM trade WHERE book = 'paper' AND paper_order_id = ?", (order_id,)).fetchone()
        if t is None:
            raise ValueError("the open paper trade is missing")
        bal = conn.execute("SELECT balance_at_open FROM trade WHERE id = ?", (t["id"],)).fetchone()[0]
        f = _figures(cfg, o["side"], o["entry"], o["fill_price"], o["stop"], exit_price, o["lots"],
                     bal or cfg.paper.balance, cost_pips, financing_nights(cfg, from_iso(o["filled_utc"]), closed))
        sl_at_exit = o["fill_price"] if reason == "be" else o["stop"]
        conn.execute("UPDATE paper_order SET status = 'closed', closed_utc = ?, exit_price = ?, exit_reason = ?"
                     " WHERE id = ?", (to_iso(closed), exit_price, reason, order_id))
        conn.execute(
            """UPDATE trade SET status = 'closed', close_utc = ?, close_price = ?, close_reason = ?, sl_at_exit = ?,
                   profit = ?, commission = 0, swap = ?, fee = ?, net_profit = ?, r_net = ?, r_gross = ?,
                   pct_of_balance = ?, close_trading_day = ? WHERE id = ?""",
            (to_iso(closed), exit_price, reason, sl_at_exit, f["profit"], f["swap"], f["fee"], f["net_profit"],
             f["r_net"],
             f["r_gross"], f["pct_of_balance"], trading_day(closed, d.boundary_tz, d.boundary_hour).isoformat(),
             t["id"]))
        return t["id"]


def _end(conn: sqlite3.Connection, order_id: int, at_utc, status: str, now: datetime | None = None) -> dict:
    at = _time("at_utc", at_utc) if at_utc is not None else now_utc()
    _not_future("time", at, now)
    with db.transaction(conn):
        o = _order(conn, order_id)
        _need(o, "pending", "cancel" if status == "cancelled" else "expire")
        if status == "expired":
            if not o["expiry_utc"]:
                raise ValueError("this order has no expiry; cancel it instead")
            if at < from_iso(o["expiry_utc"]):
                raise ValueError("the order has not reached its expiry yet")
        conn.execute("UPDATE paper_order SET status = ?, closed_utc = ?, exit_reason = ? WHERE id = ?",
                     (status, to_iso(at), status, order_id))
    return dict(_order(conn, order_id))


def expire(conn: sqlite3.Connection, cfg: Config, order_id: int, at_utc: datetime | str | None = None, *,
           now: datetime | None = None) -> dict:
    """pending -> expired, only at or after the order's expiry time."""
    return _end(conn, order_id, at_utc, "expired", now)


def cancel(conn: sqlite3.Connection, cfg: Config, order_id: int, at_utc: datetime | str | None = None, *,
           now: datetime | None = None) -> dict:
    """pending -> cancelled. A filled order is closed, never cancelled."""
    return _end(conn, order_id, at_utc, "cancelled", now)


def list_orders(conn: sqlite3.Connection, status: str | None = None) -> list[dict]:
    """Paper orders, newest first, optionally one status only."""
    if status is None:
        rows = conn.execute("SELECT * FROM paper_order ORDER BY id DESC")
    elif status in STATUSES:
        rows = conn.execute("SELECT * FROM paper_order WHERE status = ? ORDER BY id DESC", (status,))
    else:
        raise ValueError(f"status must be one of {STATUSES}")
    return [dict(r) for r in rows]


# ---------------------------------------------------------------- resolver (pure)


@dataclass(frozen=True)
class Bar:
    t_utc: datetime          # bar open time
    bid_o: float
    bid_h: float
    bid_l: float
    bid_c: float
    ask_o: float
    ask_h: float
    ask_l: float
    ask_c: float
    seconds: int = 60        # bar length: the bar covers [t_utc, t_utc + seconds); one-minute bars by default

    def holds(self, t: datetime) -> bool:
        return self.t_utc <= t < self.end

    @property
    def end(self) -> datetime:
        return self.t_utc + timedelta(seconds=self.seconds)


@dataclass(frozen=True)
class Resolution:
    status: str                       # pending | filled | closed | expired
    fill_utc: datetime | None = None
    fill_price: float | None = None
    exit_utc: datetime | None = None
    exit_price: float | None = None
    exit_reason: str | None = None    # tp | sl | expired


def _fill_on(order: dict, b: Bar) -> float | None:
    side, kind, entry = order["side"], order["order_type"], float(order["entry"])
    if kind == "market":
        return b.ask_o if side == "buy" else b.bid_o
    if kind == "limit":
        if side == "buy":
            return entry if b.ask_l <= entry else None
        return entry if b.bid_h >= entry else None
    if side == "buy":                       # stop orders: fill at the entry or the worse open
        return max(entry, b.ask_o) if b.ask_h >= entry else None
    return min(entry, b.bid_o) if b.bid_l <= entry else None


def _exit_on(order: dict, b: Bar, stop_only: bool) -> tuple[str, float] | None:
    stop, target = float(order["stop"]), float(order["target"])
    if order["side"] == "buy":              # a buy exits on the bid
        if b.bid_l <= stop:
            return "sl", stop if stop_only else min(stop, b.bid_o)
        if not stop_only and b.bid_h >= target:
            return "tp", target
        return None
    if b.ask_h >= stop:                     # a sell exits on the ask
        return "sl", stop if stop_only else max(stop, b.ask_o)
    if not stop_only and b.ask_l <= target:
        return "tp", target
    return None


def resolve_with_bars(order: dict, bars: Sequence[Bar]) -> Resolution:
    """What a paper order did over bid/ask bars (conservative).

    Fills: buy limit when ask low <= entry, sell limit when bid high >= entry (at the entry); stop
    orders at the entry or a worse gap open; market at the first bar's open. Exits: a buy on the bid
    (stop when bid low <= stop, target when bid high >= target), a sell on the ask. A bar that touches
    both counts as the stop. In the fill bar only the stop counts. A gap through the stop exits at the
    worse open. Not filled before the expiry -> expired (a bar opening at or after the expiry cannot
    fill).
    Bars cover [t_utc, t_utc + seconds). A time inside a bar is not known within it, so:
      - an order already filled: the bar that holds the fill time is the fill bar (stop only); bars
        that ended at or before the fill are skipped;
      - a pending order: bars that ended at or before its creation are skipped; in the bar that holds
        the creation time a fill counts only together with a stop touch (worst case: stopped out),
        because an entry touch alone may have come before the order existed.
    Prices are bid/ask, so the spread is already in a resolved fill and exit: close a resolved order
    with close_resolved(), which does not charge paper.cost_pips (the spread) a second time.
    """
    bars = sorted(bars, key=lambda b: b.t_utc)
    expiry = _time("expiry_utc", order["expiry_utc"]) if order.get("expiry_utc") else None
    created = _time("created_utc", order["created_utc"]) if order.get("created_utc") else None

    if order.get("status") == "filled":
        fill_utc = _time("filled_utc", order["filled_utc"])
        fill_price = float(order["fill_price"])
        for b in (b for b in bars if b.end > fill_utc):
            hit = _exit_on(order, b, stop_only=b.holds(fill_utc))
            if hit:
                return Resolution("closed", fill_utc, fill_price, max(b.t_utc, fill_utc), hit[1], hit[0])
        return Resolution("filled", fill_utc, fill_price)

    fill_utc = fill_price = None
    for b in bars:
        if created is not None and b.end <= created:
            continue
        if fill_utc is None:
            if expiry is not None and b.t_utc >= expiry:
                return Resolution("expired", exit_utc=expiry, exit_reason="expired")
            price = _fill_on(order, b)
            if price is None:
                continue
            hit = _exit_on(order, b, stop_only=True)
            if created is not None and b.t_utc < created and not hit:
                continue                    # creation bar: an entry touch alone is not a fill
            fill_utc, fill_price = (max(b.t_utc, created) if created else b.t_utc), price
        else:
            hit = _exit_on(order, b, stop_only=False)
        if hit:
            return Resolution("closed", fill_utc, fill_price, max(b.t_utc, fill_utc), hit[1], hit[0])
    if fill_utc is not None:
        return Resolution("filled", fill_utc, fill_price)
    return Resolution("pending")
