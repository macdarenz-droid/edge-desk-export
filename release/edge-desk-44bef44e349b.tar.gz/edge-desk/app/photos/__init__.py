"""Photo journal (docs/JOURNAL_DESIGN.md): pictures in, safely (images, store)."""
