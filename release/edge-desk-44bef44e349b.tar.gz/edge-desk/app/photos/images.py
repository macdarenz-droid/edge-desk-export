"""Picture checks for the photo journal (docs/JOURNAL_DESIGN.md §10 "Image types" and "Metadata strip"). Standard
library only: `serve` never decodes a picture. It checks the type by its magic bytes, reads the size from the header
(JPEG SOF, PNG IHDR) before anything else, refuses animated PNGs, and strips metadata losslessly:
- JPEG keeps SOI, APP0 (JFIF), DQT, SOFn, DHT, DAC, DRI, DNL, SOS with its scan data, RSTn and EOI; it drops APP1-APP15
  (EXIF with GPS, XMP, ICC, maker data, Photoshop) and COM, and anything after EOI (phones can append data there).
- PNG keeps IHDR, PLTE, IDAT, IEND, tRNS, gAMA and sRGB; it drops tEXt, zTXt, iTXt, eXIf, tIME, iCCP and every other
  chunk, and anything after IEND.
The scan data and the IDAT chunks are copied byte for byte, so the pixels are the same. A file that does not parse is
refused, never guessed.
"""
from __future__ import annotations

import struct
import zlib

JPEG, PNG = "image/jpeg", "image/png"
TYPES = {JPEG: (b"\xff\xd8\xff", "jpg"), PNG: (b"\x89PNG\r\n\x1a\n", "png")}
MAX_PIXELS = 12_000_000                # 12 megapixels (design §10)
TYPE_TEXT = "Send it as a screenshot: JPG or PNG"
_SOF = frozenset({0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF})
_JPEG_KEEP = _SOF | {0xC4, 0xCC, 0xDB, 0xDD, 0xDC}          # + DHT, DAC, DQT, DRI, DNL; APP0 only when JFIF
_PNG_KEEP = frozenset({b"IHDR", b"PLTE", b"IDAT", b"IEND", b"tRNS", b"gAMA", b"sRGB"})


class Refused(ValueError):
    """A picture the app does not take; status is the HTTP answer (415 type, 422 size or shape)."""

    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def sniff(data: bytes, ctype: str) -> tuple[str, str]:
    """(mime, ext) when the declared type is JPEG or PNG and the magic bytes say the same; else 415."""
    want = TYPES.get(ctype)
    if want is None or not data.startswith(want[0]):
        raise Refused(415, TYPE_TEXT)
    return ctype, want[1]


def _jpeg_segments(data: bytes):
    """(marker, start, end) of every marker segment, in order, up to and including EOI; scan data is skipped (it
    belongs to the SOS before it). Raises Refused on anything that does not parse."""
    if not data.startswith(b"\xff\xd8"):
        raise Refused(415, TYPE_TEXT)
    i, n = 2, len(data)
    while True:
        if i + 1 >= n or data[i] != 0xFF:
            raise Refused(422, "This picture is cut short or broken: send the original screenshot")
        while i + 1 < n and data[i + 1] == 0xFF:          # fill bytes before a marker
            i += 1
        m = data[i + 1]
        if m == 0xD9:
            yield m, i, i + 2
            return
        if 0xD0 <= m <= 0xD7 or m == 0x01:
            yield m, i, i + 2
            i += 2
            continue
        if i + 4 > n:
            raise Refused(422, "This picture is cut short or broken: send the original screenshot")
        length = struct.unpack(">H", data[i + 2:i + 4])[0]
        end = i + 2 + length
        if length < 2 or end > n:
            raise Refused(422, "This picture is cut short or broken: send the original screenshot")
        if m != 0xDA:
            yield m, i, end
            i = end
            continue
        # SOS: the entropy-coded data runs to the next marker that is not a stuffed 0xFF00 or a restart marker
        j = end
        while True:
            k = data.find(b"\xff", j)
            if k < 0 or k + 1 >= n:
                raise Refused(422, "This picture is cut short or broken: send the original screenshot")
            nxt = data[k + 1]
            if nxt == 0x00 or 0xD0 <= nxt <= 0xD7 or nxt == 0xFF:
                j = k + 1 if nxt == 0xFF else k + 2
                continue
            break
        yield m, i, k                                      # the SOS segment with its scan data
        i = k


def _png_chunks(data: bytes):
    """(type, start, end) of every chunk up to and including IEND; refused when a length runs past the end."""
    if not data.startswith(TYPES[PNG][0]):
        raise Refused(415, TYPE_TEXT)
    i, n = 8, len(data)
    while True:
        if i + 12 > n:
            raise Refused(422, "This picture is cut short or broken: send the original screenshot")
        length = struct.unpack(">I", data[i:i + 4])[0]
        kind = data[i + 4:i + 8]
        end = i + 12 + length
        if end > n or not kind.isalpha():
            raise Refused(422, "This picture is cut short or broken: send the original screenshot")
        crc = struct.unpack(">I", data[end - 4:end])[0]
        if zlib.crc32(data[i + 4:end - 4]) & 0xFFFFFFFF != crc:
            raise Refused(422, "This picture is cut short or broken: send the original screenshot")
        yield kind, i, end
        if kind == b"IEND":
            return
        i = end


def dimensions(data: bytes) -> tuple[int, int]:
    """(width, height) from the header alone."""
    if data.startswith(TYPES[PNG][0]):
        for kind, s, e in _png_chunks(data):
            if kind != b"IHDR" or e - s != 25:          # IHDR holds 13 bytes (+ 12 for length, type and CRC)
                raise Refused(422, "This picture is cut short or broken: send the original screenshot")
            return struct.unpack(">II", data[s + 8:s + 16])
    if data.startswith(TYPES[JPEG][0]):
        for m, s, e in _jpeg_segments(data):
            if m in _SOF:
                if e - s < 10:                          # marker, length, precision, height and width at least
                    raise Refused(422, "This picture is cut short or broken: send the original screenshot")
                h, w = struct.unpack(">HH", data[s + 5:s + 9])
                return w, h
            if m == 0xDA:
                break
        raise Refused(422, "This picture is cut short or broken: send the original screenshot")
    raise Refused(415, TYPE_TEXT)


def is_animated(data: bytes) -> bool:
    return data.startswith(TYPES[PNG][0]) and any(kind == b"acTL" for kind, _, _ in _png_chunks(data))


def check_size(data: bytes, photos) -> tuple[int, int]:
    """Size and shape checks before any decode (design §10): each side from photos.min_side_px to max_side_px, at
    most 12 megapixels, no animated PNG. Returns (width, height)."""
    if is_animated(data):
        raise Refused(415, TYPE_TEXT)
    w, h = dimensions(data)
    if min(w, h) < photos.min_side_px:
        raise Refused(422, "This copy is too small to read. Send the original screenshot from your gallery.")
    if max(w, h) > photos.max_side_px or w * h > MAX_PIXELS:
        raise Refused(422, "This picture is too large. Send the screenshot as it was taken.")
    return w, h


def strip(data: bytes, mime: str) -> bytes:
    """The picture without its metadata; the pixels' bytes unchanged."""
    if mime == PNG:
        return TYPES[PNG][0] + b"".join(data[s:e] for kind, s, e in _png_chunks(data) if kind in _PNG_KEEP)
    if mime == JPEG:
        out = [b"\xff\xd8"]
        for m, s, e in _jpeg_segments(data):
            if m in _SOF and e - s < 10:
                raise Refused(422, "This picture is cut short or broken: send the original screenshot")
            if m in _JPEG_KEEP or m == 0xDA or m == 0xD9 or 0xD0 <= m <= 0xD7 or \
                    (m == 0xE0 and data[s + 4:s + 9] == b"JFIF\x00"):
                out.append(data[s:e])
        return b"".join(out)
    raise Refused(415, TYPE_TEXT)
