"""Picture files and their rows (docs/JOURNAL_DESIGN.md §4 "The row comes before the file", §8.1 `photo` and
`photo_link`, §8.2). D14 replaced (owner, 30 Oct 2026): his account has the bridge, so a picture added from a bridge
trade's sheet is linked to that trade at once ("confirmed"); a picture with no trade waits in the inbox for the
reader (a later phase), and he can link it to a trade or delete it.

Folders under the photos folder (var/photos on the server; mode 0700, files 0600, owned by the app's user):
  tmp/<sha256>.<16 random hex>.part   one per upload, created with O_EXCL and fsynced, outside the journal lock
  inbox/<sha256>.<ext>                a picture with no trade, once its row is committed (state queued)
  store/<yyyy-mm of received_utc>/<sha256>.<ext>   a picture linked to a trade (state confirmed) or read
  wait/                               a file found in inbox/ with no queued row: never read until its row is queued
Paths are derived from the row (sha256, ext, received_utc, state), never stored, so no row can point at a moved file.
Order under the journal lock: an existing sha256 is a duplicate (its temporary file is deleted, the first picture's id
answers); else the row is committed as `receiving`, the file is renamed into place, and the row moves on. A crash
between the two leaves a `receiving` row with no file, which settle() marks `failed` after 10 minutes.
The web server and the hourly maintain job are two processes, so every step that moves, deletes or counts files and
rows takes `folder_lock` (an flock on <photos>/.lock) besides the journal lock; a size walk tolerates a file that goes
while it is counted.
Retention (prune, run by the hourly maintain job): unconfirmed pictures 7 days ([photos] unconfirmed_keep_days),
confirmed 180 days (keep_days); over folder_cap_mb the oldest confirmed go first, never one under 30 days old. The
file goes; the row and its links stay (state deleted). Picture files are never in the backup or the export.
"""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import os
import re
import secrets
import threading
from datetime import datetime, timedelta
from pathlib import Path

from app import db
from app.photos import images
from app.timeutil import from_iso, to_iso

TRADE_REF = re.compile(r"(mt5|paper):([0-9]{1,12})")
ROLES = ("order", "open", "close", "look")
STALE = timedelta(minutes=10)
MIN_KEEP_UNDER_CAP = timedelta(days=30)
INBOX_STATES = frozenset({"receiving", "queued"})


class NotFound(LookupError):
    pass


_HELD = threading.local()


@contextlib.contextmanager
def folder_lock(folder: Path):
    """An exclusive flock on <photos>/.lock: the web server (uploads, links, deletes) and the maintain job (settle,
    prune) never move the same file at once. Re-entrant in the thread that holds it (save() links a duplicate under
    it): two opens of one file are two flocks that wait on each other even in one process."""
    folder.mkdir(parents=True, exist_ok=True)
    key = os.path.realpath(folder)
    held = _HELD.__dict__.setdefault("folders", set())
    if key in held:
        yield
        return
    fd = os.open(folder / ".lock", os.O_RDWR | os.O_CREAT, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        held.add(key)
        try:
            yield
        finally:
            held.discard(key)
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _dirs(folder: Path) -> None:
    for sub in ("tmp", "inbox", "wait", "store"):
        (folder / sub).mkdir(parents=True, exist_ok=True)
        os.chmod(folder / sub, 0o700)
    os.chmod(folder, 0o700)


def path_of(folder: Path, row) -> Path:
    name = f"{row['sha256']}.{row['ext']}"
    if row["state"] in INBOX_STATES:
        return folder / "inbox" / name
    return folder / "store" / row["received_utc"][:7] / name


def _write_tmp(folder: Path, sha: str, data: bytes) -> Path:
    tmp = folder / "tmp" / f"{sha}.{secrets.token_hex(8)}.part"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
    return tmp


def trade_exists(conn, trade_ref: str) -> bool:
    m = TRADE_REF.fullmatch(trade_ref or "")
    if not m:
        return False
    return conn.execute("SELECT 1 FROM trade WHERE id = ? AND book = ?", (int(m.group(2)), m.group(1))).fetchone() \
        is not None


def _commit_row(conn, sha: str, now: datetime, mtime_utc: str | None, size: int, w: int, h: int, mime: str,
                ext: str) -> int:
    with db.transaction(conn):
        old = conn.execute("SELECT id FROM photo WHERE sha256 = ?", (sha,)).fetchone()
        if old is not None:   # deleted or failed before: the same picture sent again starts over, with no old links
            conn.execute("UPDATE photo SET received_utc = ?, file_mtime_utc = ?, state = 'receiving', deleted_utc = NULL,"
                         " confirmed_utc = NULL, attempts = 0, next_try_utc = NULL WHERE id = ?",
                         (to_iso(now), mtime_utc, old["id"]))
            conn.execute("DELETE FROM photo_link WHERE photo_id = ?", (old["id"],))
            return old["id"]
        cur = conn.execute("INSERT INTO photo (sha256, received_utc, file_mtime_utc, bytes, width, height, mime, ext,"
                           " via, state) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'upload', 'receiving')",
                           (sha, to_iso(now), mtime_utc, size, w, h, mime, ext))
        return cur.lastrowid


def _link(conn, photo_id: int, trade_ref: str, role: str, now: datetime) -> None:
    conn.execute("INSERT OR IGNORE INTO photo_link (photo_id, trade_ref, role, at_utc) VALUES (?, ?, ?, ?)",
                 (photo_id, trade_ref, role, to_iso(now)))


def save(conn, cfg, folder: Path, raw: bytes, ctype: str, mtime_utc: str | None, trade_ref: str | None,
         now: datetime) -> dict:
    """One upload: checked, stripped, written, committed. Returns {id, duplicate, state}. Raises images.Refused or
    NotFound (a trade_ref that is not a trade)."""
    mime, ext = images.sniff(raw, ctype)
    w, h = images.check_size(raw, cfg.photos)
    data = images.strip(raw, mime)
    sha = hashlib.sha256(data).hexdigest()
    _dirs(folder)
    tmp = _write_tmp(folder, sha, data)
    try:
        with db._LOCK, folder_lock(folder):
            if trade_ref is not None and not trade_exists(conn, trade_ref):
                raise NotFound("no such trade")
            row = conn.execute("SELECT * FROM photo WHERE sha256 = ?", (sha,)).fetchone()
            if row is not None and not _restartable(row, now):
                if trade_ref is not None:
                    link(conn, cfg, folder, row["id"], trade_ref, "look", now)
                    row = conn.execute("SELECT * FROM photo WHERE id = ?", (row["id"],)).fetchone()
                return {"id": row["id"], "duplicate": True, "state": row["state"]}
            pid = _commit_row(conn, sha, now, mtime_utc, len(data), w, h, mime, ext)
            row = conn.execute("SELECT * FROM photo WHERE id = ?", (pid,)).fetchone()
            state = "confirmed" if trade_ref is not None else "queued"
            dest = path_of(folder, {**dict(row), "state": state})
            dest.parent.mkdir(parents=True, exist_ok=True)
            os.chmod(dest.parent, 0o700)
            os.replace(tmp, dest)
            with db.transaction(conn):
                conn.execute("UPDATE photo SET state = ?, confirmed_utc = ? WHERE id = ?",
                             (state, to_iso(now) if trade_ref is not None else None, pid))
                if trade_ref is not None:
                    _link(conn, pid, trade_ref, "look", now)
            return {"id": pid, "duplicate": False, "state": state}
    finally:
        tmp.unlink(missing_ok=True)


def _restartable(row, now: datetime) -> bool:
    """A row the same bytes may start over: deleted, failed, or still receiving 10 minutes on (its upload died)."""
    return row["state"] in ("deleted", "failed") or (
        row["state"] == "receiving" and from_iso(row["received_utc"]) < now - STALE)


def link(conn, cfg, folder: Path, photo_id: int, trade_ref: str, role: str, now: datetime) -> dict:
    """Link a picture to a journal trade ('mt5:<id>' or 'paper:<id>'). A waiting picture moves to the store and is
    confirmed (kept keep_days). Called under the journal lock."""
    if role not in ROLES:
        raise ValueError(f"role must be one of {ROLES}")
    if not TRADE_REF.fullmatch(trade_ref or ""):
        raise ValueError("trade_ref must be mt5:<id> or paper:<id>")
    if not trade_exists(conn, trade_ref):
        raise NotFound("no such trade")
    with folder_lock(folder):
        row = conn.execute("SELECT * FROM photo WHERE id = ?", (photo_id,)).fetchone()
        if row is None or row["state"] in ("deleted", "failed", "receiving"):
            raise NotFound("no such picture")
        if row["state"] in INBOX_STATES:
            src = path_of(folder, row)
            dest = path_of(folder, {**dict(row), "state": "confirmed"})
            dest.parent.mkdir(parents=True, exist_ok=True)
            os.chmod(dest.parent, 0o700)
            try:
                os.replace(src, dest)
            except FileNotFoundError:
                raise NotFound("no such picture") from None
        with db.transaction(conn):
            if row["state"] != "confirmed":
                conn.execute("UPDATE photo SET state = 'confirmed', confirmed_utc = ? WHERE id = ? AND state = ?",
                             (to_iso(now), photo_id, row["state"]))
            _link(conn, photo_id, trade_ref, role, now)
    return get(conn, photo_id)


def delete(conn, folder: Path, photo_id: int, now: datetime) -> None:
    """The file goes at once; the row and its links stay (state deleted). Called under the journal lock."""
    with folder_lock(folder):
        row = conn.execute("SELECT * FROM photo WHERE id = ?", (photo_id,)).fetchone()
        if row is None or row["state"] == "deleted":
            raise NotFound("no such picture")
        _remove(conn, folder, row, now)


def _remove(conn, folder: Path, row, now: datetime) -> None:
    """The file goes and the row becomes 'deleted', only if the row is still in the state it was read in."""
    with db.transaction(conn):
        cur = conn.execute("UPDATE photo SET state = 'deleted', deleted_utc = ? WHERE id = ? AND state = ?",
                           (to_iso(now), row["id"], row["state"]))
    if cur.rowcount:
        path_of(folder, row).unlink(missing_ok=True)


def _public(row) -> dict:
    keys = ("id", "received_utc", "file_mtime_utc", "bytes", "width", "height", "mime", "state", "kind",
            "confirmed_utc")
    return {k: row[k] for k in keys}


def get(conn, photo_id: int) -> dict:
    row = conn.execute("SELECT * FROM photo WHERE id = ?", (photo_id,)).fetchone()
    if row is None:
        raise NotFound("no such picture")
    out = _public(row)
    out["links"] = [{"trade_ref": r["trade_ref"], "role": r["role"]} for r in conn.execute(
        "SELECT trade_ref, role FROM photo_link WHERE photo_id = ? ORDER BY at_utc", (photo_id,))]
    return out


def list_for_trade(conn, trade_ref: str) -> list[dict]:
    if not TRADE_REF.fullmatch(trade_ref or ""):
        raise ValueError("trade must be mt5:<id> or paper:<id>")
    return [_public(r) for r in conn.execute(
        "SELECT p.* FROM photo p JOIN photo_link l ON l.photo_id = p.id WHERE l.trade_ref = ? AND p.state != 'deleted'"
        " ORDER BY p.received_utc, p.id", (trade_ref,))]


def list_waiting(conn) -> list[dict]:
    return [_public(r) for r in conn.execute("SELECT * FROM photo WHERE state = 'queued' ORDER BY received_utc, id")]


def image(conn, folder: Path, photo_id: int) -> tuple[bytes, str]:
    row = conn.execute("SELECT * FROM photo WHERE id = ?", (photo_id,)).fetchone()
    if row is None or row["state"] in ("deleted", "receiving", "failed"):
        raise NotFound("no such picture")
    try:
        return path_of(folder, row).read_bytes(), row["mime"]
    except FileNotFoundError:
        raise NotFound("no such picture") from None


def uploads_since(conn, since: datetime) -> int:
    return conn.execute("SELECT COUNT(*) FROM photo WHERE received_utc >= ?", (to_iso(since),)).fetchone()[0]


# ---------------------------------------------------------------- settle and prune (the hourly maintain job)

def _age(path: Path, now: datetime) -> float:
    try:
        return now.timestamp() - path.stat().st_mtime
    except FileNotFoundError:
        return 0.0


def settle(conn, cfg, folder: Path, now: datetime) -> None:
    """Keep files and rows in step: a file in inbox/ without a queued row waits in wait/ (and goes back once its row is
    queued, or is deleted after 10 minutes with none); a `receiving` row older than 10 minutes with no file is failed;
    temporary files older than 10 minutes are removed."""
    if not folder.exists():
        return
    _dirs(folder)
    with db._LOCK, folder_lock(folder):
        for f in list((folder / "tmp").iterdir()):
            if _age(f, now) > STALE.total_seconds():
                f.unlink(missing_ok=True)
        for f in list((folder / "inbox").iterdir()):
            sha = f.name.split(".", 1)[0]
            row = conn.execute("SELECT state FROM photo WHERE sha256 = ?", (sha,)).fetchone()
            if row is None or row["state"] != "queued":
                os.replace(f, folder / "wait" / f.name)
                os.utime(folder / "wait" / f.name, (now.timestamp(), now.timestamp()))
        for f in list((folder / "wait").iterdir()):
            sha = f.name.split(".", 1)[0]
            row = conn.execute("SELECT state FROM photo WHERE sha256 = ?", (sha,)).fetchone()
            if row is not None and row["state"] == "queued":
                os.replace(f, folder / "inbox" / f.name)
            elif _age(f, now) > STALE.total_seconds():
                f.unlink(missing_ok=True)
        cutoff = to_iso(now - STALE)
        for row in conn.execute("SELECT * FROM photo WHERE state = 'receiving' AND received_utc < ?",
                                (cutoff,)).fetchall():
            if not path_of(folder, row).exists():
                with db.transaction(conn):
                    conn.execute("UPDATE photo SET state = 'failed' WHERE id = ?", (row["id"],))


def folder_bytes(folder: Path) -> int:
    """Bytes of the picture files; a file that goes while it is counted counts 0."""
    if not folder.exists():
        return 0
    total = 0
    for f in folder.rglob("*"):
        try:
            if f.is_file():
                total += f.stat().st_size
        except FileNotFoundError:
            continue
    return total


def full(cfg, folder: Path) -> bool:
    """At or over [photos] folder_cap_mb: a new upload gets 507 (design §8.2), whatever prune can free later."""
    return folder_bytes(folder) >= cfg.photos.folder_cap_mb * 1024 * 1024


def prune(conn, cfg, folder: Path, now: datetime) -> list[int]:
    """Delete picture files past their keep time, then the oldest confirmed ones while the folder is over its cap
    (never one confirmed under 30 days ago). Returns the ids whose files were removed."""
    p = cfg.photos
    gone: list[int] = []
    if not folder.exists() and conn.execute("SELECT 1 FROM photo LIMIT 1").fetchone() is None:
        return gone                         # pictures never used: no folder and no .lock made
    settle(conn, cfg, folder, now)
    with db._LOCK, folder_lock(folder):
        short = to_iso(now - timedelta(days=p.unconfirmed_keep_days))
        long = to_iso(now - timedelta(days=p.keep_days))
        rows = conn.execute(
            "SELECT * FROM photo WHERE (state NOT IN ('confirmed', 'deleted') AND received_utc < ?)"
            " OR (state = 'confirmed' AND COALESCE(confirmed_utc, received_utc) < ?)", (short, long)).fetchall()
        for row in rows:
            _remove(conn, folder, row, now)
            gone.append(row["id"])
        cap = p.folder_cap_mb * 1024 * 1024
        if folder_bytes(folder) > cap:
            young = to_iso(now - MIN_KEEP_UNDER_CAP)
            for row in conn.execute("SELECT * FROM photo WHERE state = 'confirmed' AND COALESCE(confirmed_utc,"
                                    " received_utc) < ? ORDER BY COALESCE(confirmed_utc, received_utc), id",
                                    (young,)).fetchall():
                if folder_bytes(folder) <= cap:
                    break
                _remove(conn, folder, row, now)
                gone.append(row["id"])
    return gone
