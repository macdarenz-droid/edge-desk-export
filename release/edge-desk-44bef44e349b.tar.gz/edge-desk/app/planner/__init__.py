"""Planner slot. Phase 1 holds no strategy: the only one registered says "no trade today: no proven setup".
A future strategy plugs in through app.planner.interface.Strategy and app.planner.registry."""
