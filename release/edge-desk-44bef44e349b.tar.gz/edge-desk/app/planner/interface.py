"""The contract between the planner service and a strategy. No rules live here.

A strategy gets a PlanContext (trading day, time, balance, day guard and streak state, config) and
returns a PlanResult: order cards, or no cards and a reason. The service, not the strategy, sizes the
cards, sets the expiry from config, checks the stop side, applies the day guard and decides whether a
card is offered. A strategy with no evidence (evidence None) can never have a card offered.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Any, Protocol, runtime_checkable

from app.risk.day_guard import DayGuardState
from app.risk.streak import StreakState


@dataclass(frozen=True)
class OrderCard:
    symbol: str
    side: str                       # buy | sell
    entry: float
    stop: float
    target: float
    expiry_utc: datetime | None     # never later than config planner.order_expiry_london
    setup: str                      # short name of the setup that produced the card
    swept_level: str | None
    checklist: tuple[str, ...] = ()


@dataclass(frozen=True)
class PlanContext:
    trading_day: date
    now_utc: datetime
    symbol: str
    balance: float
    guard: DayGuardState
    streak: StreakState
    cfg: Any                        # app.config.Config


@dataclass(frozen=True)
class PlanResult:
    cards: tuple[OrderCard, ...]
    no_trade_reason: str | None


@runtime_checkable
class Strategy(Protocol):
    name: str
    version: str
    evidence: str | None            # where its tested results are written; None = not proven

    def plan(self, ctx: PlanContext) -> PlanResult: ...
