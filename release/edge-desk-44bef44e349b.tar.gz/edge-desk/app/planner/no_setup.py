"""The empty slot: no setup has passed the tests yet, so no trade is planned."""
from __future__ import annotations

from app.planner.interface import PlanContext, PlanResult

NO_PROVEN_SETUP = "no trade today: no proven setup"


class NoProvenSetup:
    name = "none"
    version = "0"
    evidence: str | None = None

    def plan(self, ctx: PlanContext | None) -> PlanResult:
        return PlanResult((), NO_PROVEN_SETUP)
