"""Strategies the planner may run, by config name (planner.strategy). Phase 1: only "none"."""
from __future__ import annotations

from app.planner.interface import Strategy
from app.planner.no_setup import NoProvenSetup

_REGISTRY = {"none": NoProvenSetup}


def get_strategy(name: str) -> Strategy:
    try:
        return _REGISTRY[name]()
    except KeyError:
        raise ValueError(f"unknown strategy {name!r}; registered: {sorted(_REGISTRY)}") from None
