"""Planner service: runs the configured strategy once per trading day and logs what it found.

Every run writes one planner_run row, plus one opportunity row per card (offered or not). A card is
offered only when ALL hold:
  - the strategy has evidence (a strategy without evidence can never offer a card);
  - the day guard allows a new trade, on both books (MT5 and paper; the stricter one decides);
  - the card is EUR/USD, its stop and target sit on the right sides of the entry, and it can be sized;
  - its expiry (never later than planner.order_expiry_london on the trading day) is still ahead.
Cards are sized with app.risk.sizing from paper.balance and risk.risk_pct_per_trade (planner mode is
paper). Cards that are not EUR/USD, or whose side or prices cannot be stored, are dropped.
The plan reason, when nothing is offered, in order: "no trade today: no proven setup" (no evidence),
"no trade today: <guard reason>", then the strategy's own reason.
"""
from __future__ import annotations

import json
import math
import sqlite3
from datetime import date, datetime

from app import db
from app.config import Config
from app.journal.store import opportunity_dict
from app.paper.log import EURUSD_TICK_SIZE, EURUSD_TICK_VALUE, EURUSD_VOLUME_MIN, EURUSD_VOLUME_STEP
from app.planner.interface import OrderCard, PlanContext, PlanResult, Strategy
from app.planner.no_setup import NO_PROVEN_SETUP
from app.planner.registry import get_strategy
from app.risk.day_guard import DayGuardState
from app.risk.flags import guard_now, streak_now
from app.risk.sizing import lots_for_risk
from app.timeutil import LONDON, UTC, market_open, to_iso, trading_day

PREFIX = "no trade today: "


def _as_date(day: date | str) -> date:
    if isinstance(day, datetime):
        raise ValueError("day must be a date")
    return day if isinstance(day, date) else date.fromisoformat(day)


def _expiry_cap(cfg: Config, day: date) -> datetime:
    return datetime.combine(day, cfg.planner.order_expiry_london, LONDON).astimezone(UTC)


def _plan_time(cfg: Config, day: date) -> datetime:
    return datetime.combine(day, cfg.planner.plan_time_london, LONDON).astimezone(UTC)


def _storable(c: OrderCard) -> bool:
    nums = (c.entry, c.stop, c.target)
    return (c.side in ("buy", "sell")
            and all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) and x > 0
                    for x in nums))


def _card_problem(c: OrderCard) -> str | None:
    if c.stop == c.entry:
        return "stop at the entry"
    if c.side == "buy" and not (c.stop < c.entry < c.target):
        return "buy needs stop below and target above the entry"
    if c.side == "sell" and not (c.target < c.entry < c.stop):
        return "sell needs stop above and target below the entry"
    return None


def check_cards(result: PlanResult) -> None:
    """Only OrderCards fill the planner slot: a suggestion (app/suggest) is never one (B8)."""
    for c in result.cards:
        if not isinstance(c, OrderCard):
            raise TypeError(f"a planner card must be an OrderCard, not {type(c).__name__}")


def _stricter(a: DayGuardState, b: DayGuardState) -> DayGuardState:
    if not a.can_open_new:
        return a
    return b if not b.can_open_new else a


def _reason(text: str | None) -> str:
    text = (text or "").strip() or "no setup"
    return text if text.lower().startswith(PREFIX) else PREFIX + text


def _plan_dict(conn: sqlite3.Connection, run: sqlite3.Row) -> dict:
    cards = conn.execute("SELECT * FROM opportunity WHERE planner_run_id = ? ORDER BY id", (run["id"],))
    d = dict(run)
    d["state"] = json.loads(d.pop("guard_json"))
    d["cards"] = [opportunity_dict(r) for r in cards]
    return d


def latest_plan(conn: sqlite3.Connection, day: date | str) -> dict | None:
    """The day's latest planner run with its cards, or None."""
    run = conn.execute("SELECT * FROM planner_run WHERE trading_day = ? ORDER BY id DESC LIMIT 1",
                       (_as_date(day).isoformat(),)).fetchone()
    return _plan_dict(conn, run) if run else None


def _run(conn: sqlite3.Connection, cfg: Config, day: date, now: datetime, strategy: Strategy | None,
         once: bool) -> dict:
    if not isinstance(now, datetime) or now.tzinfo is None:
        raise ValueError("now must be a time with a zone (UTC)")
    strategy = strategy if strategy is not None else get_strategy(cfg.planner.strategy)
    guard = _stricter(guard_now(conn, cfg, now, "mt5"), guard_now(conn, cfg, now, "paper"))
    streak = streak_now(conn, cfg, now, "mt5")
    balance = cfg.paper.balance
    ctx = PlanContext(day, now, cfg.instrument.symbol, balance, guard, streak, cfg)
    result = strategy.plan(ctx)
    if not isinstance(result, PlanResult):
        raise TypeError("a strategy must return a PlanResult")
    check_cards(result)
    evidence = isinstance(strategy.evidence, str) and bool(strategy.evidence.strip())
    cap = _expiry_cap(cfg, day)
    risk_pct = cfg.risk.risk_pct_per_trade

    rows = []
    for c in result.cards:
        if not isinstance(c, OrderCard) or not cfg.is_eurusd(c.symbol) or not _storable(c):
            continue
        expiry = min(c.expiry_utc, cap) if c.expiry_utc is not None else cap
        problem = _card_problem(c)
        lots, target_r = None, 0.0
        if problem is None:
            target_r = abs(c.target - c.entry) / abs(c.entry - c.stop)
            lots = lots_for_risk(balance, risk_pct, c.entry, c.stop, EURUSD_TICK_SIZE, EURUSD_TICK_VALUE,
                                 EURUSD_VOLUME_STEP, EURUSD_VOLUME_MIN)
        if problem is not None:
            why = f"invalid card: {problem}"
        elif not evidence:
            why = NO_PROVEN_SETUP
        elif not guard.can_open_new:
            why = PREFIX + guard.reason
        elif expiry <= now:
            why = "expiry passed"
        elif not lots:
            why = "stop too wide for the configured risk"
        else:
            why = None
        rows.append((c, expiry, lots, target_r, why))

    offered = any(r[4] is None for r in rows)
    if offered:
        result_kind, reason = "orders", None
    elif not evidence:
        result_kind, reason = "no_trade", NO_PROVEN_SETUP
    elif not guard.can_open_new:
        result_kind, reason = "no_trade", PREFIX + guard.reason
    elif rows:
        result_kind, reason = "no_trade", PREFIX + "no valid card"
    else:
        result_kind, reason = "no_trade", _reason(result.no_trade_reason)

    state = json.dumps({"guard": guard.to_dict(), "streak": streak.to_dict()})
    run_utc = to_iso(now)
    with db.transaction(conn):
        if once:
            existing = conn.execute("SELECT id FROM planner_run WHERE trading_day = ? LIMIT 1",
                                    (day.isoformat(),)).fetchone()
            if existing is not None:
                return latest_plan(conn, day)
        run_id = conn.execute(
            """INSERT INTO planner_run (run_utc, trading_day, strategy, strategy_version, result, reason, n_cards,
                   guard_json) VALUES (?,?,?,?,?,?,?,?)""",
            (run_utc, day.isoformat(), strategy.name, strategy.version, result_kind, reason, len(rows), state)
        ).lastrowid
        for c, expiry, lots, target_r, why in rows:
            conn.execute(
                """INSERT INTO opportunity (planner_run_id, created_utc, trading_day, symbol, setup, side, entry, stop,
                       target, target_r, expiry_utc, swept_level, risk_pct, lots, offered, not_offered_reason,
                       checklist_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (run_id, run_utc, day.isoformat(), c.symbol, str(c.setup), c.side, float(c.entry), float(c.stop),
                 float(c.target), target_r, to_iso(expiry), c.swept_level, risk_pct, lots,
                 1 if why is None else 0, why, json.dumps([str(x) for x in c.checklist])))
    return latest_plan(conn, day)


def run_day(conn: sqlite3.Connection, cfg: Config, day: date | str, now: datetime,
            strategy: Strategy | None = None) -> dict:
    """Run the strategy (default: config planner.strategy) for a trading day and log the result."""
    return _run(conn, cfg, _as_date(day), now, strategy, once=False)


def ensure_plan(conn: sqlite3.Connection, cfg: Config, now: datetime) -> dict | None:
    """Once per trading day, at or after planner.plan_time_london: returns the day's plan, making it the
    first time. None before plan time and on days the market is shut."""
    if not isinstance(now, datetime) or now.tzinfo is None:
        raise ValueError("now must be a time with a zone (UTC)")
    day = trading_day(now, cfg.day.boundary_tz, cfg.day.boundary_hour)
    at = _plan_time(cfg, day)
    if not market_open(at) or now < at:
        return None
    existing = latest_plan(conn, day)
    if existing is not None:
        return existing
    return _run(conn, cfg, day, now, None, once=True)
