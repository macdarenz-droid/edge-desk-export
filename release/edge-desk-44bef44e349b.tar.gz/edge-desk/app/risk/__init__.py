"""Risk: the owner's day rules, streak mode, position size and rule-break flags. Safety code: every
rule branch has a test that fails if the branch is removed or its comparison is flipped."""
