"""Day guard: the owner's day rules (CLAUDE.md "The owner's own rules"), pure, no database.

The rules, in the order they are checked (limits from config [risk], never constants here):

  (a) Max losses. `losses >= max_losses_per_day` -> status "done", reason "<n> losses today".
  (b) Loss after a win. When `loss_after_win_ends_day` is on and any loss closed at or after the close
      of any win -> "done", reason "Loss after a win". A tie in close time counts as "after" (safe).
  (c) One more trade after a win. Once a win has closed, count the trades opened at or after the FIRST
      win's close: closed trades (by their open time), open trades (by their open time) and every
      pending order. `left = trades_after_first_win - that count`. `left <= 0` -> "done", reason
      "After a win: one more trade used"; `left > 0` -> "one_more" with `trades_left = left`, still
      subject to (d).
  (d) Open risk. `losses + open trades at risk + pending orders >= max_losses_per_day` -> "full": one
      more trade could take the day past the loss limit, so no new trade until something closes. Reason
      like "1 loss + 1 open: another trade could make 3 losses". An open trade whose stop sits at or
      through its entry (DayTrade.stop_at_entry) can no longer lose, so it is not open risk here (the
      owner moves the stop to entry at +2R for exactly this reason); it still counts in (c).
  (e) Otherwise "open".

Safe readings kept on purpose:
  - A closed trade with unknown R (no stop) counts as a loss.
  - A stop-at-entry exit (close_reason 'be') is a breakeven when its R before costs (r_gross) is inside
    the breakeven band: costs alone (commission, half a pip of slippage) do not turn it into a loss.
    Without r_gross, or outside the band, R after costs decides as for any other trade.
  - `closed` holds every trade whose close falls in this trading day, on any symbol: the day rules
    guard the account, not one pair.
  - `open_trades` may be a list of DayTrade (close None) with real open times, or a plain count. A
    count has no open times, so each open trade is taken as opened after the first win (stricter).
  - Pending orders always count, in (c) and in (d): an order resting at the broker can fill at any time.
  - Breakevens are neither wins nor losses, but a breakeven opened after a win still uses the extra trade.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, datetime
from typing import Sequence

from app.config import RiskSection

STATUSES = ("open", "one_more", "full", "done")
STATUS_WORDS = {"open": "Open", "one_more": "One more trade", "full": "Full", "done": "Day done"}  # for the owner
RULES = ("max_losses", "loss_after_win", "after_win", "open_risk")
_WORDS = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five"}


@dataclass(frozen=True)
class DayTrade:
    open_utc: datetime
    close_utc: datetime | None = None
    r: float | None = None              # R after costs (r_net)
    close_reason: str | None = None     # 'be': closed by a stop sitting at entry
    r_gross: float | None = None        # R before costs
    stop_at_entry: bool = False         # an open trade whose stop is at or through its entry


@dataclass(frozen=True)
class DayGuardState:
    day: date
    status: str                 # open | one_more | full | done
    can_open_new: bool
    reason: str
    wins: int
    losses: int
    breakevens: int
    open_trades: int
    pending_orders: int
    losses_left: int
    trades_left: int | None     # None: no win yet, so only the loss limit applies
    rule: str = ""              # which rule decided: max_losses | loss_after_win | after_win | open_risk | ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["day"] = self.day.isoformat()
        return d


def classify(r: float | None, band: float, close_reason: str | None = None, r_gross: float | None = None) -> str:
    """'win' when r > band, 'loss' when r < -band, else 'breakeven'. Unknown R (None) is a loss.
    A stop-at-entry exit (close_reason 'be') with r_gross inside the band is a breakeven."""
    if close_reason == "be" and r_gross is not None and -band <= r_gross <= band:
        return "breakeven"
    if r is None:
        return "loss"
    if r > band:
        return "win"
    if r < -band:
        return "loss"
    return "breakeven"


def classify_trade(t, band: float) -> str:
    """classify() for a trade row or dict (r_net, r_gross, close_reason)."""
    r, g = t.get("r_net"), t.get("r_gross")
    return classify(None if r is None else float(r), band, t.get("close_reason"), None if g is None else float(g))


def _plural(n: int, word: str, many: str) -> str:
    return f"{n} {word if n == 1 else many}"


def _count_word(n: int) -> str:
    return _WORDS.get(n, str(n))


def evaluate_day(day: date, closed: Sequence[DayTrade], open_trades: int | Sequence[DayTrade],
                 pending_orders: int, risk: RiskSection) -> DayGuardState:
    """Apply rules (a)-(e) above to one trading day. See the module docstring for the exact reading."""
    for t in closed:
        if t.close_utc is None:
            raise ValueError("a closed trade needs its close time")
    if isinstance(open_trades, int):
        n_open = n_open_risk = open_trades
        open_list: list[DayTrade] | None = None
    else:
        open_list = list(open_trades)
        n_open = len(open_list)
        n_open_risk = sum(1 for t in open_list if not t.stop_at_entry)
    if n_open < 0 or pending_orders < 0:
        raise ValueError("counts cannot be negative")

    kinds = [(t, classify(t.r, risk.breakeven_band_r, t.close_reason, t.r_gross)) for t in closed]
    win_closes = [t.close_utc for t, k in kinds if k == "win"]
    loss_closes = [t.close_utc for t, k in kinds if k == "loss"]
    wins, losses = len(win_closes), len(loss_closes)
    breakevens = len(kinds) - wins - losses
    max_losses = risk.max_losses_per_day
    losses_left = max(0, max_losses - losses)

    def state(status: str, reason: str, rule: str, trades_left: int | None) -> DayGuardState:
        can = status in ("open", "one_more")
        return DayGuardState(day, status, can, reason, wins, losses, breakevens, n_open, pending_orders,
                             losses_left, trades_left if can else 0, rule)

    # (a) max losses
    if losses >= max_losses:
        return state("done", f"{_plural(losses, 'loss', 'losses')} today", "max_losses", 0)

    # (b) a loss closed at or after a win ends the day
    if risk.loss_after_win_ends_day and win_closes and loss_closes:
        if max(loss_closes) >= min(win_closes):
            return state("done", "Loss after a win", "loss_after_win", 0)

    # (c) after the first win, a set number of further trades
    left: int | None = None
    if win_closes:
        first_win = min(win_closes)
        n_after = sum(1 for t in closed if t.open_utc >= first_win)
        if open_list is None:
            n_after += n_open
        else:
            n_after += sum(1 for t in open_list if t.open_utc >= first_win)
        n_after += pending_orders
        left = risk.trades_after_first_win - n_after
        if left <= 0:
            k = risk.trades_after_first_win
            used = "no more trades" if k == 0 else f"{_count_word(k)} more trade{'s' if k != 1 else ''} used"
            return state("done", f"After a win: {used}", "after_win", 0)

    # (d) open risk: one more trade could take the day past the loss limit
    at_risk = losses + n_open_risk + pending_orders
    if at_risk >= max_losses:
        parts = []
        if losses:
            parts.append(_plural(losses, "loss", "losses"))
        if n_open_risk:
            parts.append(f"{n_open_risk} open")
        if pending_orders:
            parts.append(f"{pending_orders} pending")
        reason = f"{' + '.join(parts)}: another trade could make {at_risk + 1} losses"
        return state("full", reason, "open_risk", 0)

    # (e) open, or one more after a win
    if left is not None:
        return state("one_more", f"After a win: {_count_word(left)} more trade{'s' if left != 1 else ''} left",
                     "", left)
    return state("open", f"{_plural(losses_left, 'loss', 'losses')} left", "", None)
