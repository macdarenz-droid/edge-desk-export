"""Rule-break flags on trades, and the day guard / streak state read from the trade table.

compute_flags replays each trade at its open with only what was known then:
  - closed: trades of the same book whose close is in the same trading day and at or before this
    trade's open (the trade itself excluded), on any symbol; a stop-at-entry exit ('be') inside the
    breakeven band before costs is a breakeven (day_guard.classify);
  - open: trades of the same book opened before this one (by open time, then id) and not yet closed
    at this trade's open, from any day, on any symbol; one whose stop sat at or through its entry at
    that moment (the first stop plus the recorded stop changes up to then) is not open risk;
  - pending orders: unknown in history, so 0.
If the guard would not have allowed a new trade, the trade is flagged by the deciding rule:
  (a) max_losses -> after_max_losses, (b) loss_after_win -> after_loss_after_win,
  (c) after_win -> over_trades_after_win, (d) open_risk -> over_open_risk.
Other flags:
  no_stop          initial_sl is NULL, or a recorded stop change went from no stop to a stop (the
                   position was open unprotected for a while); a hard incident, the flag stays
  early_close      closed by hand ('manual') while the trade had a target, unless it was closed at or
                   beyond the configured take-or-trail level (management.take_or_trail_r), which is the
                   owner's own rule ("at +4R close, or move the stop to +2R and let it run")
  size_above_risk  risk_money / balance_at_open * 100 > 1.25 * risk.risk_pct_per_trade
  no_checklist     (A3) an MT5 trade with no setup check linked, once the owner has saved a setup check at or
                   before its open (before he uses the form, no trade is flagged for lacking one)
  below_tier       (A3) the trade's setup check (its locked version) gives no trade: a must-have missing or a
                   score under 3
  over_tier_risk   (A3) the check's linked trades together risked more than 1.25 x the tier's share of the
                   configured risk % (full 1, half 0.5)
  no_stop_to_entry (A6) a closed MT5 trade reached management.breakeven_to_r in the snapshots (position_seen
                   .max_fav_r, approximate) and its stop never moved to the entry side before the close
  stop_moved_away  a recorded stop change put the stop further from the open price than the first
                   stop (buy: lower; sell: higher), or removed it; the detail names the prices (5 decimals
                   for EUR/USD) and the time in Melbourne time, as the owner reads it on his phone
Another account's trades (an account switch, deploy/install/account.py: each MT5 account has its own alias, and the
config's is the linked one) count like any other closed trade, but one still open when that account's bridge went
quiet is open only until that account's last snapshot: nothing will close it, and no snapshot will show it again
(the expired trial account, 30 Oct 2026). guard_now counts open MT5 trades of the linked account only.
Flags follow the current data: each run works them out again, adds new ones, updates a changed detail and
removes a flag the trade no longer earns (for example size_above_risk worked out from a balance_at_open
that the bridge corrected after catching up its history). no_stop stays once raised: it is a hard
incident. Running twice writes nothing new. Alert keys are not touched, so a flag is never alerted twice.

streak_now counts every symbol's losses (they end streak mode, the safe side) but only EUR/USD wins and
breakevens: a win on another pair cannot turn on the 6-8R EUR/USD targets.
"""
from __future__ import annotations

import json
import sqlite3
from collections import defaultdict
from datetime import date, datetime

from app import db
from app.checklist.store import checklist_flags
from app.config import Config
from app.risk.day_guard import DayGuardState, DayTrade, evaluate_day
from app.risk.streak import DayResult, StreakState, evaluate_streak
from app.timeutil import fmt_melbourne, from_iso, now_utc, to_iso, trading_day

BOOKS = ("mt5", "paper")
# Shown on the trade and in the edge leak's by_flag, but not counted as a rule break (edge leak, adherence)
# and not sent as a rule-break alert: the configured risk % is the planner's paper size, not a rule the
# owner has set for his own trading yet (his real risk runs about 0.2% to 2%, docs/TRADE_LOG.md).
INFO_FLAGS = frozenset({"size_above_risk", "over_tier_risk"})   # both compare with the paper size (red team 1)
SIZE_TOLERANCE = 1.25       # size_above_risk: more than 1.25x the configured risk %
STICKY_FLAGS = frozenset({"no_stop"})   # a hard incident: never removed once raised
_PRICE_EPS = 1e-7           # 0.001 pip: float noise, not a stop move
_RULE_FLAG = {
    "max_losses": "after_max_losses",
    "loss_after_win": "after_loss_after_win",
    "after_win": "over_trades_after_win",
    "open_risk": "over_open_risk",
}


def _aware(now: datetime) -> datetime:
    if not isinstance(now, datetime) or now.tzinfo is None:
        raise ValueError("now must be a time with a zone (UTC)")
    return now


def _book(book: str) -> str:
    if book not in BOOKS:
        raise ValueError(f"book must be one of {BOOKS}")
    return book


def _trades(conn: sqlite3.Connection, book: str) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM trade WHERE book = ? ORDER BY open_utc, id", (book,)).fetchall()


def _pip(cfg: Config, t) -> float | None:
    if cfg.is_eurusd(t["symbol"]):
        return cfg.instrument.pip_size
    if t["stop_pips"] and t["initial_sl"] is not None:
        return abs(float(t["open_price"]) - float(t["initial_sl"])) / float(t["stop_pips"])
    return None


def _at_or_through_entry(cfg: Config, t, sl) -> bool:
    """The stop sits at the entry (within half a pip) or beyond it on the profit side: no loss is left."""
    if sl is None or t["open_price"] is None:
        return False
    tol = 0.5 * (_pip(cfg, t) or 0.0) + _PRICE_EPS
    entry, sl = float(t["open_price"]), float(sl)
    return sl >= entry - tol if t["side"] == "buy" else sl <= entry + tol


def _stop_changes(conn: sqlite3.Connection, t) -> list[tuple[str, float | None]]:
    if t["broker_position_id"] is None:
        return []
    return [(r["at_utc"], r["new_sl"]) for r in conn.execute(
        "SELECT at_utc, new_sl FROM sl_change WHERE account_alias = ? AND position_id = ? ORDER BY at_utc, id",
        (t["account_alias"], t["broker_position_id"]))]


def _stop_at(t, changes: list[tuple[str, float | None]], at_iso: str):
    """The trade's stop at a moment: its first stop, then every recorded change at or before then."""
    sl = t["initial_sl"]
    for when, new_sl in changes:
        if when > at_iso:
            break
        sl = new_sl
    return sl


def _closed_r_for_streak(row, cfg: Config) -> float:
    """R of a closed trade for streak mode. Unknown R (no stop) counts as at least a full 1R loss, or
    worse when the money lost was bigger than one configured risk unit."""
    if row["r_net"] is not None:
        return float(row["r_net"])
    pct = row["pct_of_balance"]
    est = (float(pct) / cfg.risk.risk_pct_per_trade) if pct is not None else -1.0
    return min(-1.0, est)


# ---------------------------------------------------------------- flags


def _unlinked_seen(conn: sqlite3.Connection, cfg: Config) -> dict[str, datetime]:
    """{alias: its last snapshot} for every MT5 account other than the linked one (cfg.account.alias)."""
    return {r["account_alias"]: from_iso(r["last_seen_utc"]) for r in conn.execute(
        "SELECT account_alias, last_seen_utc FROM bridge_status WHERE account_alias != ?", (cfg.account.alias,))}


def _guard_flags(conn: sqlite3.Connection, trades, cfg: Config) -> dict[int, tuple[str, str]]:
    """Replay every trade at its open (one sweep in open order) -> {trade_id: (flag, detail)}."""
    gone = _unlinked_seen(conn, cfg)

    def end(t):          # an MT5 trade of an unlinked account still open: open only until that account was last seen
        if t["close_utc"]:
            return from_iso(t["close_utc"])
        return gone.get(t["account_alias"]) if t["book"] == "mt5" else None

    recs = [(t["open_utc"], t["id"], from_iso(t["open_utc"]),
             from_iso(t["close_utc"]) if t["close_utc"] else None, t["close_trading_day"], t["trading_day"],
             t["r_net"], t, end(t)) for t in trades]
    changes = {t["id"]: _stop_changes(conn, t) for t in trades}
    recs.sort(key=lambda x: (x[0], x[1]))
    by_close_day: dict[str, list[tuple]] = defaultdict(list)
    for x in recs:
        if x[3] is not None and x[4]:
            by_close_day[x[4]].append(x)
    out: dict[int, tuple[str, str]] = {}
    active: list[tuple] = []          # trades opened earlier and still open at the current open time
    for x in recs:
        at_iso, tid, t_open, _, _, day, _, _, _ = x
        active = [o for o in active if o[8] is None or o[8] > t_open]
        closed = [DayTrade(o[2], o[3], o[6], o[7]["close_reason"], o[7]["r_gross"]) for o in by_close_day.get(day, ())
                  if o[1] != tid and o[3] <= t_open]
        open_list = [DayTrade(o[2], None, None, stop_at_entry=_at_or_through_entry(
            cfg, o[7], _stop_at(o[7], changes[o[1]], at_iso))) for o in active]
        g = evaluate_day(date.fromisoformat(day), closed, open_list, 0, cfg.risk)
        if not g.can_open_new:
            out[tid] = (_RULE_FLAG[g.rule], g.reason)
        active.append(x)
    return out


def _had_target(conn, t) -> bool:
    if t["initial_tp"] is not None:
        return True
    if t["broker_position_id"] is None:
        return False
    row = conn.execute("SELECT 1 FROM sl_change WHERE account_alias = ? AND position_id = ? AND new_tp IS NOT NULL",
                       (t["account_alias"], t["broker_position_id"])).fetchone()
    return row is not None


def _stop_added_later(conn, t) -> bool:
    """A recorded change from no stop to a stop: the position was open without one for a while."""
    if t["broker_position_id"] is None:
        return False
    row = conn.execute("SELECT 1 FROM sl_change WHERE account_alias = ? AND position_id = ? AND old_sl IS NULL"
                       " AND new_sl IS NOT NULL", (t["account_alias"], t["broker_position_id"])).fetchone()
    return row is not None


def _px(cfg: Config, t, price: float) -> str:
    return f"{price:.5f}" if cfg.is_eurusd(t["symbol"]) else f"{price:.6g}"


def _mel(at_iso: str) -> str:
    return f"{fmt_melbourne(from_iso(at_iso))} Melbourne"


def _stop_moved_away(conn, cfg: Config, t) -> str | None:
    if t["initial_sl"] is None or t["broker_position_id"] is None:
        return None
    first = float(t["initial_sl"])
    rows = conn.execute("SELECT at_utc, old_sl, new_sl FROM sl_change WHERE account_alias = ? AND position_id = ?"
                        " ORDER BY at_utc, id", (t["account_alias"], t["broker_position_id"])).fetchall()
    for r in rows:
        if r["new_sl"] is None:
            if r["old_sl"] is not None:
                return f"stop removed at {_mel(r['at_utc'])}"
            continue
        new = float(r["new_sl"])
        away = new < first - _PRICE_EPS if t["side"] == "buy" else new > first + _PRICE_EPS
        if away:
            return f"stop moved from {_px(cfg, t, first)} to {_px(cfg, t, new)} at {_mel(r['at_utc'])}"
    return None


def _trade_flags(conn: sqlite3.Connection, cfg: Config, t, guard_flag: tuple[str, str] | None
                 ) -> list[tuple[str, str]]:
    """Every flag one trade earns, as (flag, detail)."""
    out: list[tuple[str, str]] = []
    if guard_flag is not None:
        out.append(guard_flag)
    if t["initial_sl"] is None:
        out.append(("no_stop", "opened without a stop"))
    elif _stop_added_later(conn, t):
        out.append(("no_stop", "had no stop until it was added later"))
    if t["status"] == "closed" and t["close_reason"] == "manual" and _had_target(conn, t):
        followed_rule = t["r_gross"] is not None and t["r_gross"] >= cfg.management.take_or_trail_r
        if not followed_rule:
            out.append(("early_close", "closed by hand before the target"))
    if t["risk_money"] is not None and t["balance_at_open"]:
        pct = float(t["risk_money"]) / float(t["balance_at_open"]) * 100.0
        if pct > SIZE_TOLERANCE * cfg.risk.risk_pct_per_trade:
            out.append(("size_above_risk", f"risked {pct:.3f}% of balance"))
    moved = _stop_moved_away(conn, cfg, t)
    if moved:
        out.append(("stop_moved_away", moved))
    late = _no_stop_to_entry(conn, cfg, t)
    if late:
        out.append(("no_stop_to_entry", late))
    out.extend(checklist_flags(conn, cfg, t))
    return out


def _no_stop_to_entry(conn, cfg: Config, t) -> str | None:
    """A6: a closed MT5 trade whose highest R seen in the snapshots reached management.breakeven_to_r, with no
    stop change to the entry side (and no exit stop there) before the close. Approximate (5 s snapshots)."""
    if t["book"] != "mt5" or t["status"] != "closed" or t["broker_position_id"] is None:
        return None
    row = conn.execute("SELECT max_fav_r FROM position_seen WHERE account_alias = ? AND position_id = ?",
                       (t["account_alias"], t["broker_position_id"])).fetchone()
    if row is None or row["max_fav_r"] is None or row["max_fav_r"] < cfg.management.breakeven_to_r - 1e-9:
        return None
    if _at_or_through_entry(cfg, t, t["sl_at_exit"]):
        return None
    for when, new_sl in _stop_changes(conn, t):
        if when <= t["close_utc"] and _at_or_through_entry(cfg, t, new_sl):
            return None
    return f"reached about +{row['max_fav_r']:.1f}R (from snapshots); the stop never moved to entry"


def compute_flags(conn: sqlite3.Connection, cfg: Config, book: str = "mt5", now: datetime | None = None) -> int:
    """Flag every trade of `book` from the current data (see the module docstring). Returns the number of
    new flag rows written."""
    _book(book)
    created = to_iso(now or now_utc())
    trades = _trades(conn, book)
    guard = _guard_flags(conn, trades, cfg)
    written = 0
    with db.transaction(conn):
        have: dict[int, dict[str, str]] = defaultdict(dict)
        for r in conn.execute("SELECT f.trade_id, f.flag, f.detail FROM trade_flag f JOIN trade t ON t.id = f.trade_id"
                              " WHERE t.book = ?", (book,)):
            have[r["trade_id"]][r["flag"]] = r["detail"]
        for t in trades:
            want: dict[str, str] = {}
            for flag, detail in _trade_flags(conn, cfg, t, guard.get(t["id"])):
                want.setdefault(flag, detail)
            old = have.get(t["id"], {})
            for flag, detail in want.items():
                if flag not in old:
                    conn.execute("INSERT INTO trade_flag (trade_id, flag, detail, created_utc) VALUES (?,?,?,?)",
                                 (t["id"], flag, detail, created))
                    written += 1
                elif old[flag] != detail:
                    conn.execute("UPDATE trade_flag SET detail = ? WHERE trade_id = ? AND flag = ?",
                                 (detail, t["id"], flag))
            for flag in set(old) - set(want) - STICKY_FLAGS:
                conn.execute("DELETE FROM trade_flag WHERE trade_id = ? AND flag = ?", (t["id"], flag))
    return written


# ---------------------------------------------------------------- now


def _pending_from_store(conn: sqlite3.Connection, cfg: Config, book: str) -> int:
    if book == "paper":
        return conn.execute("SELECT COUNT(*) FROM paper_order WHERE status = 'pending'").fetchone()[0]
    total = 0       # the linked account's orders only: another account's last snapshot keeps its orders for ever
    for row in conn.execute("SELECT snapshot_json FROM bridge_status WHERE account_alias = ?", (cfg.account.alias,)):
        try:
            orders = json.loads(row["snapshot_json"]).get("orders") or []
        except (ValueError, TypeError, AttributeError):
            continue
        total += len(orders) if isinstance(orders, list) else 0
    return total


def guard_now(conn: sqlite3.Connection, cfg: Config, now: datetime, book: str = "mt5",
              pending_orders: int | None = None) -> DayGuardState:
    """The day guard for the trading day containing `now`, from the trade table (any symbol).

    pending_orders: a count from the caller, or None to read it from the store (mt5: the pending
    orders in the latest bridge snapshot; paper: pending paper orders). Open trades from any day count
    (MT5: the linked account's only; another account's trade left open is not known any more);
    one whose current stop (the bridge's latest, else the first stop plus recorded changes) sits at or
    through its entry is not open risk.
    """
    _book(book)
    day = trading_day(_aware(now), cfg.day.boundary_tz, cfg.day.boundary_hour)
    closed, open_list = [], []
    rows = conn.execute(
        "SELECT t.*, ps.last_sl AS seen_sl, ps.position_id AS seen_id FROM trade t LEFT JOIN position_seen ps"
        " ON ps.account_alias = t.account_alias AND ps.position_id = t.broker_position_id"
        " WHERE t.book = ? AND ((t.status = 'open' AND (t.book = 'paper' OR t.account_alias = ?))"
        " OR t.close_trading_day = ?) ORDER BY t.open_utc, t.id",
        (book, cfg.account.alias, day.isoformat())).fetchall()
    for t in rows:
        if t["status"] == "open":
            sl = t["seen_sl"] if t["seen_id"] is not None else _stop_at(t, _stop_changes(conn, t), to_iso(now))
            open_list.append(DayTrade(from_iso(t["open_utc"]), None, None,
                                      stop_at_entry=_at_or_through_entry(cfg, t, sl)))
        else:  # closed in this trading day (the query above)
            closed.append(DayTrade(from_iso(t["open_utc"]), from_iso(t["close_utc"]), t["r_net"], t["close_reason"],
                                   t["r_gross"]))
    pending = _pending_from_store(conn, cfg, book) if pending_orders is None else int(pending_orders)
    return evaluate_day(day, closed, open_list, pending, cfg.risk)


def streak_now(conn: sqlite3.Connection, cfg: Config, now: datetime, book: str = "mt5") -> StreakState:
    """Streak mode from closed trades: completed trading days before today, plus today's closed R."""
    _book(book)
    today = trading_day(_aware(now), cfg.day.boundary_tz, cfg.day.boundary_hour)
    by_day: dict[str, list[float]] = defaultdict(list)
    for t in conn.execute("SELECT symbol, r_net, pct_of_balance, close_trading_day FROM trade WHERE book = ? AND"
                          " status = 'closed' AND close_trading_day IS NOT NULL", (book,)):
        r = _closed_r_for_streak(t, cfg)
        if not cfg.is_eurusd(t["symbol"]) and r >= 0:
            continue                       # another pair's win or breakeven never builds a EUR/USD streak
        by_day[t["close_trading_day"]].append(r)
    days = [DayResult(date.fromisoformat(d), sum(rs), len(rs)) for d, rs in by_day.items() if d < today.isoformat()]
    today_r = sum(by_day.get(today.isoformat(), []))
    return evaluate_streak(days, cfg.streak, today_r=today_r, today=today)
