"""Position size from the balance, the configured risk % and the stop distance, pure.

Size never grows after a loss or in streak mode: it takes only the balance and the risk % from config
(no loss count, streak flag or multiplier can reach it). Lots are always rounded DOWN to the volume
step, so a sized trade never risks more than the budget.
"""
from __future__ import annotations

import math
from decimal import Decimal

_EPS = 1e-9  # absorbs floating error like 0.3 / 0.01 = 29.999...; far below one volume step


def _check(name: str, value: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a number")
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and above 0")
    return value


def _round_down(lots: float, step: float) -> float:
    n = math.floor(lots / step + _EPS)
    places = max(0, -Decimal(repr(step)).normalize().as_tuple().exponent)
    return round(n * step, places + 2)


def risk_money(entry: float, stop: float, lots: float, tick_size: float, tick_value: float) -> float:
    """Money lost if the stop is hit: |entry - stop| / tick_size * tick_value * lots."""
    entry, stop = _check("entry", entry), _check("stop", stop)
    lots, tick_size, tick_value = _check("lots", lots), _check("tick_size", tick_size), _check("tick_value", tick_value)
    if entry == stop:
        raise ValueError("stop equals entry")
    return abs(entry - stop) / tick_size * tick_value * lots


def lots_for_risk(balance: float, risk_pct: float, entry: float, stop: float, tick_size: float,
                  tick_value: float, volume_step: float, volume_min: float,
                  volume_max: float | None = None) -> float:
    """Lots so that hitting the stop loses `risk_pct` % of `balance`, rounded down to `volume_step`.

    Returns 0.0 when even `volume_min` would risk more than the budget. Capped (down) at volume_max.
    Raises ValueError when stop == entry or any input is not finite and positive.
    """
    balance, risk_pct = _check("balance", balance), _check("risk_pct", risk_pct)
    entry, stop = _check("entry", entry), _check("stop", stop)
    tick_size, tick_value = _check("tick_size", tick_size), _check("tick_value", tick_value)
    volume_step, volume_min = _check("volume_step", volume_step), _check("volume_min", volume_min)
    if volume_max is not None:
        volume_max = _check("volume_max", volume_max)
    if entry == stop:
        raise ValueError("stop equals entry")

    budget = balance * risk_pct / 100.0
    per_lot = abs(entry - stop) / tick_size * tick_value
    lots = _round_down(budget / per_lot, volume_step)
    if volume_max is not None and lots > volume_max:
        lots = _round_down(volume_max, volume_step)
    if lots < volume_min - _EPS * volume_step:
        return 0.0
    return lots
