"""Streak mode (controlled greed), pure, no database.

The owner: "if i got win streak for days I can be a little greedy, target higher RRs. But if that
losses, those winning days should not loss my whole profit." Settings from config [streak].

Reading (completed trading days, oldest first):
  - Days with no trades are skipped: they neither build nor break a run.
  - A green day has r > 0. Any other day with trades (flat or red) breaks the run of green days.
  - Not active: a green day adds its R to the run and counts one green day. When the count reaches
    `green_days_to_start`, streak mode turns on with streak_r = the run's R, peak = streak_r and
    floor = floor_fraction * peak.
  - Active: streak_r += the day's R (red days included); peak = max(peak, streak_r);
    floor = max(floor, floor_fraction * peak), so the floor only moves up. When streak_r <= floor,
    streak mode turns off on that day (ended_on), the floor's share of the streak is kept, and the run
    starts again from zero.
  - today_r (R closed so far today) is applied to the floor check only, and only while active: it can
    end streak mode during the day, it never starts it, and it does not move the peak or the floor.
  - `enabled = false` in config: never active.
Size never changes in streak mode: only the targets (target_min_r .. target_max_r) may.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date
from typing import Sequence

from app.config import StreakSection


@dataclass(frozen=True)
class DayResult:
    day: date
    r: float
    trades: int


@dataclass(frozen=True)
class StreakState:
    active: bool
    green_days: int             # green days in the current run (counting on while streak mode is on)
    streak_r: float             # R banked since the run began (completed days); 0 when no run
    peak_r: float
    floor_r: float | None       # None while streak mode is off
    target_min_r: float         # streak targets from config; they apply only while active
    target_max_r: float
    ended_on: date | None       # the day streak mode last turned off; None while active
    reason: str

    def to_dict(self) -> dict:
        d = asdict(self)
        d["ended_on"] = self.ended_on.isoformat() if self.ended_on else None
        return d


def _r1(x: float) -> str:
    return f"{x:+.1f}R"


def evaluate_streak(days: Sequence[DayResult], cfg: StreakSection, today_r: float = 0.0,
                    today: date | None = None) -> StreakState:
    """Replay completed days (any order; sorted here) and apply today's closed R. See module docstring."""
    tmin, tmax = cfg.target_min_r, cfg.target_max_r
    if not cfg.enabled:
        return StreakState(False, 0, 0.0, 0.0, None, tmin, tmax, None, "Off in config")

    active = False
    green = 0
    run_r = 0.0
    peak = 0.0
    floor: float | None = None
    ended_on: date | None = None
    end_note = ""

    for d in sorted(days, key=lambda x: x.day):
        if d.trades == 0:
            continue
        if not active:
            if d.r > 0:
                green += 1
                run_r += d.r
                if green >= cfg.green_days_to_start:
                    active = True
                    peak = run_r
                    floor = cfg.floor_fraction * peak
                    ended_on = None
            else:
                green, run_r = 0, 0.0
        else:
            run_r += d.r
            if d.r > 0:
                green += 1
            peak = max(peak, run_r)
            floor = max(floor, cfg.floor_fraction * peak)
            if run_r <= floor:
                end_note = f"floor hit on {d.day.isoformat()}, {run_r:.1f}R kept"
                active, green, run_r, peak, floor, ended_on = False, 0, 0.0, 0.0, None, d.day

    if active and run_r + today_r <= floor:
        kept = run_r + today_r
        end_note = f"floor hit today, {kept:.1f}R kept"
        return StreakState(False, 0, 0.0, 0.0, None, tmin, tmax, today, f"Off: {end_note}")

    if active:
        return StreakState(True, green, run_r, peak, floor, tmin, tmax, None,
                           f"On: streak {_r1(run_r)}, floor {_r1(floor)}")
    reason = f"Off: {green} of {cfg.green_days_to_start} green days"
    if end_note and green == 0:
        reason = f"Off: {end_note}"
    return StreakState(False, green, run_r if green else 0.0, 0.0, None, tmin, tmax, ended_on, reason)
