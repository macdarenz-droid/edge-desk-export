"""Storage (A10): the server never fills up. The owner's condition on schemas 2 and 3 (16 Oct 2026): "As long server
never gets populatred. Saved, refresh delete, backup."

- prune()   raw quote samples as app/costs/quotes.py declares (48 h in full, then one a minute, nothing after 90 days)
            and rotates the app's own log files under var/ (*.log, *.jsonl over LOG_MAX_BYTES, LOG_KEEP old copies).
            bridge_status keeps only the latest snapshot per account by design, so there are no old raw snapshots to
            drop. news_event rows older than news.keep_days (14), at most NEWS_MAX_ROWS (app/news; third-party
            calendar rows, never the owner's data); news_headline rows older than headlines.keep_days (14), at most
            1,000 (Fed and ECB titles). The move record (var/news_record/, app/news/moverecord.py) is built once and
            never in a backup. Nothing in KEEP_TABLES is ever deleted: trades, deals, setup checks, links, choices, flags, paper
            orders, alerts, positions seen, stop changes (and, in Phase 3, the suggestion log).
- backup()  once a New York day, after notify.daily_summary_ny: an online copy with SQLite's backup API, gzipped to
            var/backup/edge-YYYY-MM-DD.db.gz; keeps storage.backup_daily_keep daily copies and then the newest copy
            of each of the next storage.backup_weekly_keep ISO weeks. No new backup while free disk is under the
            floor. verify_backup() opens a copy and returns its row counts (the restore check).
- The backup is made only by `python -m app maintain` (the hourly timer), never by serve, under an exclusive lock on
  var/backup/.lock, inside a private temp folder there, and it is kept only after its restore check passes. It needs
  room for two copies above the floor, refuses to run inside an open transaction, and sweeps leftovers of a killed
  run (temp folders, *.part) older than an hour.
- check()   free disk against storage.free_floor_gb and journal plus backups against storage.disk_budget_gb. Below the
            floor or over the budget: no new raw samples (raw_allowed() is False), trades are still stored, nothing
            is deleted to make room, and one phone alert (storage_low), at most one a day. It clears only with
            0.5 GB of free disk above the floor and the journal and backups at most 90% of the budget, so it does
            not flap near the floor.
These backups are on the same server: they do not survive losing it. An off-server copy is the owner's choice at
the server step.
"""
from __future__ import annotations

import fcntl
import gzip
import json
import os
import shutil
import sqlite3
import tempfile
import time
from datetime import datetime
from pathlib import Path

from app.notify.alerts import Alert
from app.timeutil import NEW_YORK, to_iso

GB = 2**30
LOG_MAX_BYTES = 20 * 2**20
LOG_KEEP = 3
ROTATED_LOGS = ("memwatch.jsonl",)          # only these are rotated: never an audit or suggestion log
CLEAR_MARGIN_GB = 0.5
CLEAR_BUDGET_FRACTION = 0.9
ALERT_GAP_S = 24 * 3600
ORPHAN_AGE_S = 3600
KEEP_TABLES = ("trade", "deal", "choice", "checklist", "checklist_link", "trade_flag", "paper_order", "alert",
               "position_seen", "sl_change", "deal_quote", "opportunity", "planner_run", "review_note",
               "push_subscription", "photo", "photo_link")      # photo rows stay; only their files are pruned
KEEP_TABLES += ("order_seen", "journal_analysis")      # the trade picture (docs/JOURNAL_DESIGN.md 8.1)
_LOW_KEY = "storage_low"


def _db_path(conn: sqlite3.Connection) -> Path | None:
    main = next((r[2] for r in conn.execute("PRAGMA database_list") if r[1] == "main"), "")
    return Path(main) if main else None


def _var(conn: sqlite3.Connection, var_dir: Path | None) -> Path | None:
    if var_dir is not None:
        return Path(var_dir)
    p = _db_path(conn)
    return p.parent if p else None


# ---------------------------------------------------------------- prune

def rotate_logs(var_dir: Path) -> list[str]:
    """Rotate the app's own log files in var_dir (ROTATED_LOGS and *.log) over LOG_MAX_BYTES, LOG_KEEP old copies."""
    rotated = []
    names = set(ROTATED_LOGS) | {p.name for p in var_dir.glob("*.log")}
    for log in sorted(var_dir / n for n in names):
        if not log.is_file() or log.stat().st_size <= LOG_MAX_BYTES:
            continue
        for i in range(LOG_KEEP, 0, -1):
            older = log.with_name(f"{log.name}.{i}")
            if i == LOG_KEEP:
                older.unlink(missing_ok=True)
            elif older.exists():
                older.replace(log.with_name(f"{log.name}.{i + 1}"))
        log.replace(log.with_name(f"{log.name}.1"))
        log.touch()
        rotated.append(log.name)
    return rotated


BAR_KEEP_DAYS = 730          # Part B: M1 bars older than two years go, unless a waiting lead still needs them
BAR_LEAD_MARGIN_DAYS = 60    # more than R53's 35-day lookback before a lead's first unsettled decision


def prune_bars(conn: sqlite3.Connection, now: datetime) -> int:
    """m1_bar rows older than BAR_KEEP_DAYS, but never from BAR_LEAD_MARGIN_DAYS before the oldest unsettled lead
    decision of the latest lead run (its lagged inputs). Never a trade, deal, check, suggestion or decision."""
    import json
    cut = int(now.timestamp()) - BAR_KEEP_DAYS * 86400
    row = conn.execute("SELECT state_json FROM lead_run ORDER BY id DESC LIMIT 1").fetchone()
    if row is not None:
        try:
            hs = [v.get("horizon") for v in (json.loads(row[0]).get("states") or {}).values() if isinstance(v, dict)]
        except ValueError:
            hs = []
        hs = [int(h) for h in hs if isinstance(h, (int, float))]
        if hs:
            cut = min(cut, min(hs) - BAR_LEAD_MARGIN_DAYS * 86400)
        try:
            first = json.loads(row[0]).get("first_ts")      # the child's own first bar (red team 17 Oct, item 9)
        except ValueError:
            first = None
        if isinstance(first, int):
            cut = min(cut, first - 86400)
    return conn.execute("DELETE FROM m1_bar WHERE ts < ?", (cut,)).rowcount


NEWS_MAX_ROWS = 5000         # news_event: about 1.5 MB at most; a normal 22-day span is a few hundred rows


def prune_news(conn: sqlite3.Connection, now: datetime, keep_days: int) -> int:
    """news_event rows whose release is older than keep_days, then the oldest beyond NEWS_MAX_ROWS (smallest
    event_utc, then id). Returns the rows deleted."""
    from datetime import timedelta
    n = conn.execute("DELETE FROM news_event WHERE event_utc < ?",
                     (to_iso(now - timedelta(days=keep_days)),)).rowcount
    over = conn.execute("SELECT COUNT(*) FROM news_event").fetchone()[0] - NEWS_MAX_ROWS
    if over > 0:
        n += conn.execute("DELETE FROM news_event WHERE id IN (SELECT id FROM news_event ORDER BY event_utc, id"
                          " LIMIT ?)", (over,)).rowcount
    return n


def prune_headlines(conn: sqlite3.Connection, now: datetime, keep_days: int) -> int:
    """news_headline rows published more than keep_days ago, then the oldest beyond 1,000 (app/news/headlines.py)."""
    from app.news.headlines import prune
    return prune(conn, now, keep_days)


def prune(conn: sqlite3.Connection, cfg, now: datetime, var_dir: Path | None = None) -> dict:
    from app import db
    from app.costs.quotes import prune_samples
    with db.transaction(conn):
        prune_samples(conn, now)
        prune_bars(conn, now)
        prune_news(conn, now, cfg.news.keep_days)
        prune_headlines(conn, now, cfg.headlines.keep_days)
    folder = _var(conn, var_dir)
    return {"rotated": rotate_logs(folder) if folder and folder.is_dir() else []}


# ---------------------------------------------------------------- backup

def _counts(conn: sqlite3.Connection) -> dict:
    tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")]
    return {t: conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in tables}


def _date_of(p: Path) -> str:
    return p.name[len("edge-"):len("edge-") + 10]


def _retain(folder: Path, daily: int, weekly: int) -> list[str]:
    files = sorted(folder.glob("edge-????-??-??.db.gz"), key=_date_of, reverse=True)
    keep = set(files[:daily])
    weeks: list[tuple] = []
    for f in files[daily:]:
        wk = datetime.fromisoformat(_date_of(f)).isocalendar()[:2]
        if wk in weeks:
            continue
        if len(weeks) < weekly:
            weeks.append(wk)
            keep.add(f)
    dropped = [f for f in files if f not in keep]
    for f in dropped:
        f.unlink()
    return [f.name for f in dropped]


def _sweep(folder: Path, now_ts: float) -> None:
    """Leftovers of a killed backup: temp folders and *.part files older than ORPHAN_AGE_S."""
    for p in folder.iterdir():
        if (p.is_dir() and p.name.startswith("tmp")) or p.name.endswith(".part"):
            if now_ts - p.stat().st_mtime > ORPHAN_AGE_S:
                shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True)


def backup(conn: sqlite3.Connection, cfg, now: datetime, var_dir: Path | None = None,
           disk_usage=shutil.disk_usage, now_ts: float | None = None) -> Path | None:
    """Today's gzipped online backup, kept only after its restore check passes; or None (not yet after the day's
    close, already made, in memory, or no room for two copies above the floor)."""
    if conn.in_transaction:
        raise RuntimeError("a backup cannot run inside an open transaction on the same connection")
    if now.astimezone(NEW_YORK).time() < cfg.notify.daily_summary_ny or _db_path(conn) is None:
        return None
    folder = _var(conn, var_dir) / "backup"
    folder.mkdir(parents=True, exist_ok=True)
    with open(folder / ".lock", "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)                 # one backup at a time, across processes
        _sweep(folder, time.time() if now_ts is None else now_ts)
        dest = folder / f"edge-{now.astimezone(NEW_YORK).date().isoformat()}.db.gz"
        if dest.exists():
            return None
        need = cfg.storage.free_floor_gb * GB + 2 * usage(conn, var_dir)["db_bytes"]
        if disk_usage(str(folder)).free < need:
            return None
        with tempfile.TemporaryDirectory(dir=folder) as tmp:
            raw = Path(tmp) / "copy.db"
            target = sqlite3.connect(str(raw))
            try:
                conn.backup(target)
            finally:
                target.close()
            part = Path(tmp) / (dest.name + ".part")
            with open(raw, "rb") as src, gzip.open(part, "wb", compresslevel=6) as out:
                shutil.copyfileobj(src, out)
            raw.unlink()
            verify_backup(part, work=Path(tmp))           # the restore check, before the copy is kept
            part.replace(dest)
        _retain(folder, cfg.storage.backup_daily_keep, cfg.storage.backup_weekly_keep)
    return dest


def verify_backup(path: Path, work: Path | None = None) -> dict:
    """Open a gzipped copy (integrity check) and return its row counts per table. `work` is where it is unpacked
    (the backup folder's own temp folder in a backup, so /tmp is not filled)."""
    with tempfile.TemporaryDirectory(dir=work) as tmp:
        raw = Path(tmp) / "restore.db"
        with gzip.open(path, "rb") as src, open(raw, "wb") as out:
            shutil.copyfileobj(src, out)
        con = sqlite3.connect(str(raw))
        try:
            if con.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise sqlite3.DatabaseError(f"{path.name} failed the integrity check")
            return _counts(con)
        finally:
            con.close()


# ---------------------------------------------------------------- the guard

def _size(paths) -> int:
    """Bytes of the files and folders; a file that goes while it is counted (another process's prune or upload)
    counts 0 instead of stopping the job."""
    total = 0
    for p in paths:
        for f in ([p] if not p.is_dir() else p.rglob("*")):
            try:
                if f.is_file():
                    total += f.stat().st_size
            except FileNotFoundError:
                continue
    return total


def usage(conn: sqlite3.Connection, var_dir: Path | None) -> dict:
    """The journal, its backups and the photo journal's picture files (var/photos), all inside the disk budget."""
    dbp = _db_path(conn)
    db_bytes = _size([dbp, Path(f"{dbp}-wal"), Path(f"{dbp}-shm")]) if dbp else 0
    folder = _var(conn, var_dir)
    backup_bytes = _size((folder / "backup").glob("*")) if folder and (folder / "backup").is_dir() else 0
    photo_bytes = _size([folder / "photos"]) if folder and (folder / "photos").is_dir() else 0
    return {"db_bytes": db_bytes, "backup_bytes": backup_bytes, "photo_bytes": photo_bytes}


def raw_allowed(conn: sqlite3.Connection) -> bool:
    return conn.execute("SELECT 1 FROM meta WHERE key = ?", (_LOW_KEY,)).fetchone() is None


def check(conn: sqlite3.Connection, cfg, now: datetime, var_dir: Path | None = None,
          disk_usage=shutil.disk_usage) -> dict:
    """Set or clear the low-storage state, with hysteresis. Returns it, with an alert when an episode starts and no
    storage_low alert was sent in the last 24 h."""
    from app import db
    u = usage(conn, var_dir)
    folder = _var(conn, var_dir)
    probe = str(folder) if folder and folder.exists() else os.getcwd()
    free = disk_usage(probe).free
    used = u["db_bytes"] + u["backup_bytes"] + u["photo_bytes"]
    floor, budget = cfg.storage.free_floor_gb * GB, cfg.storage.disk_budget_gb * GB
    reasons = []
    if free < floor:
        reasons.append(f"free disk {free / GB:.1f} GB is under the {cfg.storage.free_floor_gb:.1f} GB floor")
    if used > budget:
        reasons.append(f"journal, backups and pictures {used / GB:.2f} GB are over the {cfg.storage.disk_budget_gb:.1f} GB"
                       " budget")
    alert = None
    with db.transaction(conn):
        row = conn.execute("SELECT value FROM meta WHERE key = ?", (_LOW_KEY,)).fetchone()
        last = conn.execute("SELECT value FROM meta WHERE key = 'storage_low_alerted'").fetchone()
        low = row is not None
        if reasons and not low:
            conn.execute("INSERT INTO meta (key, value) VALUES (?, ?)",
                         (_LOW_KEY, json.dumps({"since": to_iso(now), "reason": "; ".join(reasons)})))
            low = True
            if last is None or (now - datetime.fromisoformat(last[0].replace("Z", "+00:00"))).total_seconds() \
                    >= ALERT_GAP_S:
                alert = Alert(f"storage_low:{to_iso(now)}", "storage_low", 4, "Server storage low",
                              "; ".join(reasons).capitalize() + ". New price samples stop; trades are still saved"
                              " and nothing is deleted. Free space on the server.")
                conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('storage_low_alerted', ?)",
                             (to_iso(now),))
        elif low and not reasons and free >= floor + CLEAR_MARGIN_GB * GB and used <= CLEAR_BUDGET_FRACTION * budget:
            conn.execute("DELETE FROM meta WHERE key = ?", (_LOW_KEY,))
            low = False
    return {"raw_allowed": not low, "reason": "; ".join(reasons), "free_gb": free / GB, "used_gb": used / GB,
            **u, "alert": alert}


def maintain(conn: sqlite3.Connection, cfg, now: datetime) -> list[str]:
    """The scheduled job (systemd timer, hourly): check, prune, backup. Returns what it did; queues the alert."""
    from app.notify.alerts import queue_alert
    out = []
    state = check(conn, cfg, now)
    if state["alert"] is not None and queue_alert(conn, state["alert"], now):
        out.append(state["alert"].key)
    out.append(f"storage:{'ok' if state['raw_allowed'] else 'low'}")
    rotated = prune(conn, cfg, now)["rotated"]
    out += [f"rotated:{n}" for n in rotated]
    folder = _var(conn, None)
    if folder is not None:                            # the photo journal's files (app/photos/store.py)
        from app.photos import store as photo_store
        gone = photo_store.prune(conn, cfg, folder / "photos", now)
        if gone:
            out.append(f"photos_pruned:{len(gone)}")
    made = backup(conn, cfg, now)                     # its restore check runs inside, before the copy is kept
    if made is not None:
        out.append(f"backup:{made.name}")
    return out
