"""Part B: suggestions from the coded method (R57-1H-NEAR) and the three STATS paper leads. Never order cards."""
