"""B7 alerts for suggestions and leads. Every suggestion and lead-entry alert carries its rule's record line from
records.json (after 2.0 pips, before costs, then "This rule lost." or "Below the pass case. Paper. Not proven.").
A suggestion never uses the orders_to_place kind and its title never starts with "Orders to place". All are quiet
(priority 2); only the funded 80% and risk-cap alerts (app/funded/limits.py) are loud. Each is queued once by key."""
from __future__ import annotations

import sqlite3
from datetime import datetime

from app.notify.alerts import Alert, queue_alert
from app.suggest import log as L
from app.timeutil import LONDON, MELBOURNE, NEW_YORK

QUIET = 2


def _t(ts, tz) -> str:
    return datetime.fromtimestamp(int(ts), tz).strftime("%H:%M")


def _mel(ts) -> str:
    m = datetime.fromtimestamp(int(ts), MELBOURNE)
    return f"{m:%a} {m.day} {m:%b} {m.strftime('%I:%M %p').lstrip('0').lower()} Melbourne"


def _side(s: dict) -> str:
    return "buy" if s["side"] == 1 else "sell"


def _px(x) -> str:
    return "none" if x is None else f"{x:.5f}"


def _num(x, unit: str) -> str:
    if x is None:
        return "none"
    return f"{x:+.2f}R" if unit == "R" else f"{x:+.1f} pips"


def suggestion(cfg, s: dict) -> Alert:
    tier = {"full": "full risk", "half": "half risk"}.get(s["tier"] or "", "no tier")
    body = (f"EUR/USD {_side(s)} limit {_px(s['entry'])}, stop {_px(s['stop'])}, target {_px(s['target'])}."
            f" Score {s['score']}, {tier}. Expires {_t(s['expiry_ts'], NEW_YORK)} New York ({_mel(s['expiry_ts'])})."
            f" Your check decides. {s['record_line']}")
    return Alert(f"suggestion:{s['id']}", "suggestion", QUIET,
                 f"Your method: {_side(s)} limit {_px(s['entry'])}", body)


def suggestion_cancel(cfg, s: dict) -> Alert:
    return Alert(f"suggestion_cancel:{s['id']}", "suggestion_cancel", QUIET,
                 f"Your method: cancel the {_side(s)} limit {_px(s['entry'])}",
                 "A momentum candle closed against it (its rule 12). If you placed this order, remove it.")


def suggestion_expiry(cfg, s: dict) -> Alert:
    return Alert(f"suggestion_expiry:{s['id']}", "suggestion_expiry", QUIET,
                 f"Your method: the {_side(s)} limit {_px(s['entry'])} expired",
                 f"Not filled by {_t(s['expiry_ts'], NEW_YORK)} New York. If you placed it, remove it.")


def lead_entry(cfg, s: dict) -> Alert:
    return Alert(f"lead_entry:{s['id']}", "lead_entry", QUIET, f"Paper lead {s['rule_id']}: entry time",
                 f"Planned buy of EUR/USD at {_t(s['placed_ts'], LONDON)} London ({_mel(s['placed_ts'])}), on paper."
                 f" {s['record_line']}")


def lead_exit(cfg, s: dict) -> Alert:
    return Alert(f"lead_exit:{s['id']}", "lead_exit", QUIET, f"Paper lead {s['rule_id']}: exit time",
                 f"Planned exit at {_t(s['expiry_ts'], LONDON)} London ({_mel(s['expiry_ts'])}), on paper."
                 " Paper. Not proven.")


def suggestion_result(cfg, s: dict, res: dict) -> Alert:
    unit = res.get("unit") or "R"
    who = "Your method" if s["source"] == "method" else f"Paper lead {s['rule_id']}"
    if res["outcome"] == "filled":
        title = f"{who}: {_num(res['R_20'], unit)} after 2.0 pips"
        body = (f"Exit: {res['exit_reason']}. After 1.6 pips {_num(res['R_16'], unit)}; before costs"
                f" {_num(res['R_before'], unit)}. Its own paper result, taken or not. {s['record_line']}")
    else:
        title = f"{who}: {res['outcome'].replace('_', ' ')}"
        body = f"Its own paper result, taken or not. {s['record_line']}"
    return Alert(f"suggestion_result:{s['id']}", "suggestion_result", QUIET, title, body)


def queue_method(conn: sqlite3.Connection, cfg, made: list[int], now: datetime) -> int:
    return sum(queue_alert(conn, suggestion(cfg, L.current(conn, sid)), now) for sid in made)


def queue_lifecycle(conn: sqlite3.Connection, cfg, life: dict, now: datetime) -> int:
    n = 0
    for sid in life.get("cancel", []):
        n += queue_alert(conn, suggestion_cancel(cfg, L.current(conn, sid)), now)
    for sid in life.get("expiry", []):
        n += queue_alert(conn, suggestion_expiry(cfg, L.current(conn, sid)), now)
    for sid in life.get("settled", []):
        res = L.result(conn, sid)
        s = L.current(conn, sid)
        if res is not None and s["offered"]:
            n += queue_alert(conn, suggestion_result(cfg, s, res), now)
    return n


def queue_leads(conn: sqlite3.Connection, cfg, out: dict, now: datetime) -> int:
    n = 0
    for sid in out.get("entries", []):
        n += queue_alert(conn, lead_entry(cfg, L.current(conn, sid)), now)
    for sid in out.get("exits", []):
        n += queue_alert(conn, lead_exit(cfg, L.current(conn, sid)), now)
    return n
