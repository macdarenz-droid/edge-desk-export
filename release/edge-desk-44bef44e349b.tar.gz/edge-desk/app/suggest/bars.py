"""M1 bars from the journal as numpy arrays, filled in chunks (no list of per-row tuples; red team 17 Oct, item 3)."""
from __future__ import annotations

import sqlite3

COLS = ("ts_utc", "bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")
CHUNK = 20000


def bars_array(conn: sqlite3.Connection, lo: int, hi: int) -> dict:
    """Bars with lo <= ts < hi, as {column: array}. ts_utc is int64, prices float64."""
    import numpy as np
    n = conn.execute("SELECT COUNT(*) FROM m1_bar WHERE ts >= ? AND ts < ?", (int(lo), int(hi))).fetchone()[0]
    out = {k: np.empty(n, dtype=np.int64 if k == "ts_utc" else float) for k in COLS}
    cur = conn.execute("SELECT ts, bid_o, bid_h, bid_l, bid_c, ask_o, ask_h, ask_l, ask_c FROM m1_bar"
                       " WHERE ts >= ? AND ts < ? ORDER BY ts", (int(lo), int(hi)))
    i = 0
    while i < n:
        rows = cur.fetchmany(CHUNK)
        if not rows:
            break
        block = np.array(rows, dtype=float)
        j = i + len(block)
        for c, k in enumerate(COLS):
            out[k][i:j] = block[:, c]
        i = j
    if i < n:                                           # rows removed while reading: keep what was read
        out = {k: v[:i] for k, v in out.items()}
    return out
