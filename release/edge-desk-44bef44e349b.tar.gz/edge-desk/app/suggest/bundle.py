"""B3 pinned research code for the lead worker: sha256-checked copies of exactly the files STATS pins, at their repo
paths (STATS ruling on app items 2 and 3, dept/stats 3c12eb1a, AUDITS.md "App rulings 2 and 3"; moved on 16 Oct 2026
to STATS 77ed1b42, forward tree 1ee7c81b). Standard library only: it runs before any pinned code is imported.

The copy (deploy/make_lead_bundle.py builds it in a research checkout) holds:
- every tracked file of research/departments/STATS/forward at the STATS commit except RED_TEAM.md and the
  calendar pin (calendars/FORWARD_EVENTS.csv and .json: the calendar is its own pin, B3), plus
  research/departments/STATS/audit_inputs.py: together the files of STATS's forward tree sha256
  (fwd_io.tree_sha256 / forward_files: sha256 of "<file sha256>  <path>" lines, sorted by path);
- the DATA files DEPS.json pins (every research/common/*.py, research/data/oanda_download.py, blocks.py) and
  COST's two files, each with the sha256 DEPS.json gives;
- each pick's frozen_files, with the sha256 the pick gives;
- MANIFEST.json: the STATS commit, the forward tree sha256 and every file's sha256.
verify() refuses (BundleRefused) unless the files on disk are exactly the manifest's, each with its sha256, the
forward tree sha256 recomputed from them is the pinned one, the manifest names the pinned commit, and every DEPS.json
and pick pin holds. It runs at every start of the lead child, before anything is imported from the copy.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

STATS_COMMIT = "77ed1b4284e6ef9ec040351482826c776a7b5a3b"
FORWARD_TREE_SHA256 = "1ee7c81b1b4a878159d77904e058ebbf47fbd93106567e9988a9f5a92dbf7c1b"
FORWARD_START = 1791493200                    # fwd_core.FORWARD_START: 17:00 New York 8 Oct 2026
MAX_LAG_DAYS = 400                            # fwd_core.MAX_LAG_DAYS
FWD_REL = "research/departments/STATS/forward"
AUDIT_INPUTS_REL = "research/departments/STATS/audit_inputs.py"
CAL_PIN_RELS = (f"{FWD_REL}/calendars/FORWARD_EVENTS.csv", f"{FWD_REL}/calendars/FORWARD_EVENTS.json")
EXCLUDED = (f"{FWD_REL}/RED_TEAM.md",) + CAL_PIN_RELS
MANIFEST = "MANIFEST.json"


class BundleRefused(RuntimeError):
    pass


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def tree_sha256(file_shas: dict) -> str:
    """STATS's forward tree sha256 (fwd_io.tree_sha256) from {path: sha256} of the forward files."""
    h = hashlib.sha256()
    for f in sorted(file_shas):
        h.update(f"{file_shas[f]}  {f}\n".encode())
    return h.hexdigest()


def forward_files(paths) -> list:
    return sorted(p for p in paths if (p.startswith(FWD_REL + "/") and p not in EXCLUDED) or p == AUDIT_INPUTS_REL)


def required_pins(files: dict) -> dict:
    """{path: sha256} that DEPS.json and the picks pin, read from the copy's own DEPS.json and picks (after their
    own sha256 were checked against the manifest)."""
    deps = json.loads(files["__deps__"])
    want = dict(deps["files"])
    want.update(deps["cost"]["files"])
    for rel, sha in deps["picks"].items():
        want[f"{FWD_REL}/{rel}"] = sha
    for rel in deps["picks"]:
        pick = json.loads(files[f"{FWD_REL}/{rel}"])
        for f, sha in pick["frozen_files"].items():
            if want.get(f, sha) != sha:
                raise BundleRefused(f"{f}: two pins disagree")
            want[f] = sha
    return want


def verify(root: Path) -> dict:
    """The copy at root, checked. Returns its manifest."""
    root = Path(root)
    try:
        man = json.loads((root / MANIFEST).read_text())
    except (OSError, ValueError):
        raise BundleRefused("no readable MANIFEST.json") from None
    if man.get("stats_commit") != STATS_COMMIT or man.get("forward_tree_sha256") != FORWARD_TREE_SHA256:
        raise BundleRefused("the copy is not of the pinned STATS commit and forward tree")
    listed = man.get("files") or {}
    on_disk = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() or p.is_symlink()}
    on_disk.discard(MANIFEST)
    if any((root / p).is_symlink() for p in on_disk):
        raise BundleRefused("a symlink in the copy")
    if on_disk != set(listed):
        extra, miss = sorted(on_disk - set(listed)), sorted(set(listed) - on_disk)
        raise BundleRefused(f"the copy's files differ from its manifest: extra {extra[:5]}, missing {miss[:5]}")
    got = {}
    for rel, want in listed.items():
        sha = sha256_file(root / rel)
        if sha != want:
            raise BundleRefused(f"{rel}: sha256 {sha} is not the manifest's")
        got[rel] = sha
    if tree_sha256({f: got[f] for f in forward_files(got)}) != FORWARD_TREE_SHA256:
        raise BundleRefused("the forward tree sha256 is not the pinned one")
    texts = {"__deps__": (root / FWD_REL / "DEPS.json").read_text()}
    for rel in json.loads(texts["__deps__"])["picks"]:
        texts[f"{FWD_REL}/{rel}"] = (root / FWD_REL / rel).read_text()
    for rel, sha in required_pins(texts).items():
        if got.get(rel) != sha:
            raise BundleRefused(f"{rel}: not in the copy with its pinned sha256")
    pinned = set(required_pins(texts)) | set(forward_files(got))
    if set(got) != pinned:
        raise BundleRefused(f"files in the copy that no pin names: {sorted(set(got) - pinned)[:5]}")
    return man
