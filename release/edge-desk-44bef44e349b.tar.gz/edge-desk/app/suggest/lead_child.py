"""The lead worker's child process (B3): STATS's fwd_core.compute_run, unchanged, from the pinned copy.

Run only as `python -I lead_child.py` (no user site, no PYTHONPATH, not the script's folder on sys.path). stdin: an
.npz with the M1 arrays (ts_utc, bid_o..ask_c) and `request` (JSON: bundle, calendar_dir, data_end, run_day,
run_id, log). stdout: one JSON object. Order: the copy is verified (app.suggest.bundle, standard library only) before
anything is imported from it; then the calendar pin (fwd_core.read_calendar: its CSV sha256 must equal the pin's);
then the pins (DEPS.json data and cost files, the picks, their frozen files); then compute_run. The planned decisions
come from the pinned plan code (fwd_core.simulate's plan) and the waiting states from fwd_core.deps_of.
"""
import io
import json
import math
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

DESK = Path(__file__).resolve().parents[2]


def _out(obj) -> None:
    sys.stdout.write(json.dumps(obj, default=float))
    sys.stdout.flush()


def main() -> None:
    sys.path.insert(0, str(DESK))
    from app.suggest import bundle as B
    sys.path.remove(str(DESK))
    raw = sys.stdin.buffer.read()
    import numpy as np
    z = np.load(io.BytesIO(raw), allow_pickle=False)
    req = json.loads(str(z["request"]))
    root = Path(req["bundle"])
    try:
        man = B.verify(root)
    except B.BundleRefused as e:
        _out({"status": "refused", "message": str(e)[:500]})
        return
    fwd = root / B.FWD_REL
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(fwd))
    import pandas as pd
    import fwd_core as C
    import fwd_cost
    if Path(C.__file__).resolve() != (fwd / "fwd_core.py").resolve():
        _out({"status": "refused", "message": "fwd_core was not imported from the copy"})
        return
    versions = {"numpy": np.__version__, "pandas": pd.__version__, "python": sys.version.split()[0]}
    cal_dir = Path(req["calendar_dir"])
    try:
        cal = C.read_calendar(cal_dir / "FORWARD_EVENTS.csv", cal_dir / "FORWARD_EVENTS.json")
    except (C.CalendarError, OSError, ValueError, KeyError) as e:
        _out({"status": "calendar refused", "message": str(e)[:500], "versions": versions,
              "tree_sha256": man["forward_tree_sha256"]})
        return
    picks = C.load_picks()
    C.verify_pins(picks)
    C.check_data_deps()
    fwd_cost.check(C.REPO)
    log = req.get("log") or []
    floors = C.floors_from_log(log, picks)
    start = C.inputs_start(picks, floors)
    data_end = int(req["data_end"])
    ts = z["ts_utc"].astype(np.int64)
    keep = (ts >= start) & (ts < data_end)
    m1 = {k: z[k][keep] for k in ("ts_utc", "bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")}
    m1["ts_utc"] = m1["ts_utc"].astype(np.int64)
    run_day = date.fromisoformat(req["run_day"])
    cost = fwd_cost.load(C.REPO, cal)
    res = C.compute_run(picks, cal, m1, data_end, req["run_id"], floors=floors, cost=cost, run_day=run_day)

    # planned decisions (the pinned plan code) and each pick's state
    fz = C.frozen(picks)
    days = fz.E.r45.daily_bars(m1)
    m_out = C.outcome_bars(m1)
    crow, allrows = C.calendar_rows(cal), C.calendar_all(cal)
    plans, states = {}, {}
    w = fz.E.World(m_out, {}, C.events_frame(crow), days, data_end) if len(m_out["ts_utc"]) else None
    for p in picks:
        pid = p["id"]
        plan = []
        if w is not None:
            try:
                C.check_coverage(cal, run_day, p.get("calendar", C.EVENT_TYPES))
                _, plan = C.simulate(fz, p, w, crow, C.ERA, max(C.FORWARD_FIRST_DATE, run_day - timedelta(days=10)),
                                     run_day + timedelta(days=120), C.FORWARD_START)
            except Exception:                               # noqa: BLE001  (the run's own error line says why)
                plan = []
        plan = sorted({(int(a), int(b)) for a, b in plan})
        plans[pid] = plan
        nxt = min((t for t, _ in plan if t >= data_end), default=None)
        if pid in res.errors:
            msg = res.calendar_errors.get(pid, "")
            if res.errors[pid] == "CalendarError":
                text = "Calendar error: waiting for the event time" if "no time yet" in msg else "Calendar error"
                states[pid] = {"state": "calendar_error", "text": text, "message": msg[:300]}
            else:
                states[pid] = {"state": "error", "text": "Error", "message": res.errors[pid]}
        else:
            h = res.horizons.get(pid, math.inf)
            st = {"state": "ok", "text": ""}
            if math.isfinite(h):
                te = next((b for a, b in plan if a == int(h)), None)
                dep = None if te is None else C.deps_of(p, int(h), te, allrows)
                if te is None or dep is None:
                    st = {"state": "waiting_time", "text": "waiting for the event time"}
                elif not dep["final"]:
                    st = {"state": "waiting_calendar", "text": "waiting for the calendar"}
                else:
                    st = {"state": "open", "text": "waiting for its exit"}
            if st["state"] == "ok" and res.waiting.get(pid):
                st = {"state": "waiting_calendar", "text": "waiting for the calendar"}
            states[pid] = st
        states[pid]["next_entry_ts"] = nxt
        states[pid]["horizon"] = None if not math.isfinite(res.horizons.get(pid, math.inf)) else int(res.horizons[pid])
    import hashlib
    shas = {ln["position_id"]: hashlib.sha256(C._canon(ln).encode()).hexdigest()
            for ln in res.lines if ln.get("position_id")}
    _out({"status": "done", "lines": res.lines, "line_sha256": shas, "states": states, "plans": plans,
          "picks_sha256": {p["id"]: p["_sha256"] for p in picks},
          "calendar_sha256": C.calendar_sha(cal), "tree_sha256": man["forward_tree_sha256"],
          "stats_commit": man["stats_commit"], "first_ts": int(m1["ts_utc"][0]) if len(m1["ts_utc"]) else None,
          "errors": res.errors, "calendar_errors": res.calendar_errors, "waiting": res.waiting,
          "versions": versions, "made_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")})


if __name__ == "__main__":
    if not sys.flags.isolated:
        sys.stderr.write("run with python -I\n")
        sys.exit(2)
    main()
