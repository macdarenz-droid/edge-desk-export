"""B3 leads: R53-S3X3, PA-F4 and FC-1, run by STATS's own forward code in a separate `python -I` process
(app/suggest/lead_child.py) from the pinned copy (app/suggest/bundle.py), with the calendar as its own pin.

Each run: the copy is verified; the app's M1 bars from 400 days before the forward start (fwd_core MAX_LAG_DAYS; the
child trims further to fwd_core.inputs_start) up to data_end go to the child with the lines logged so far (the
picks' floors, fwd_core.floors_from_log); its lines are kept in lead_line (append-only, one per position, its
sha256 the canonical STATS form fwd_core._canon); a recomputed line that differs is never written (status mismatch).
Settled lines become lead suggestions with their paper result (after 2.0 and 1.6 pips: net floor_2p0 and floor_1p6;
before costs: the mid move; R for R53, pips for the other two). Planned decisions (the pinned plan code) make a lead
suggestion at their entry time and a lead_exit event at their scheduled exit. Nothing here is an order card.
States per pick: waiting for the calendar (a row it depends on is not final), waiting for the event time (a row has
no time yet), the calendar error (a CalendarError from fwd_core, never zero trades), open, ok.
"""
from __future__ import annotations

import io
import json
import sqlite3
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from app import db
from app.suggest import bundle as B
from app.suggest import log as L
from app.suggest.records import lead_ids, record_line
from app.timeutil import to_iso

CHILD = Path(__file__).with_name("lead_child.py")
NY = ZoneInfo("America/New_York")
COLS = ("ts_utc", "bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")
LATE_AFTER_S = 15 * 60
STALE_AFTER_S = 24 * 3600          # entries or exits older than this are logged but raise no alert
POSITION_KINDS = ("trade", "no_trade", "no_exit_bar")


def label_of(ts: int) -> str:
    """fwd_core.label_of: the 17:00 New York trading-day label."""
    t = datetime.fromtimestamp(int(ts), NY).replace(tzinfo=None) + timedelta(hours=7)
    return t.date().isoformat()


def adapter_row(line: dict) -> dict:
    """The fields of a trade line the app shows: entry, exit, side, stop, target and the nets at 2.0 and 1.6 pips."""
    n = line["net"]["long"]
    return {"entry": line["entry"], "exit": line["exit"], "side": line["side"], "stop": line["stop"],
            "target": line["target"], "floor_2p0": n["floor_2p0"], "floor_1p6": n["floor_1p6"]}


def _result(line: dict) -> dict:
    if line["kind"] != "trade":
        return {"outcome": "no_trade", "exit_reason": line.get("reason") or line["kind"], "unit": "R"}
    div = line["r_pips"] if line["unit"] == "R" else 1.0
    n = line["net"]["long"]
    return {"outcome": "filled", "exit_reason": line["exit_reason"], "unit": line["unit"],
            "R_20": n["floor_2p0"] / div, "R_16": n["floor_1p6"] / div,
            "R_before": line["recost"]["long"]["move_mid_pips"] / div}


class LeadWorker:
    def __init__(self, conn: sqlite3.Connection | None, cfg, bundle_dir, calendar_dir, python: str = sys.executable,
                 timeout_s: int = 900, complete_through=None):
        self.conn, self.cfg = conn, cfg
        self.bundle_dir, self.calendar_dir = Path(bundle_dir), Path(calendar_dir)
        self.python, self.timeout_s = python, timeout_s
        self.complete_through = complete_through

    def command(self) -> list[str]:
        return [self.python, "-I", "-B", str(CHILD)]   # -B: no .pyc is written into the pinned copy

    def _bars(self, data_end: int):
        """From 400 days before the forward start, or from a day before the last run's first bar: the child trims
        to fwd_core.inputs_start, which never moves back (the picks' floors only rise)."""
        from app.suggest.bars import bars_array
        lo = B.FORWARD_START - B.MAX_LAG_DAYS * 86400
        row = self.conn.execute("SELECT state_json FROM lead_run WHERE status IN ('done', 'mismatch')"
                                " ORDER BY id DESC LIMIT 1").fetchone()
        if row is not None:
            try:
                first = json.loads(row[0]).get("first_ts")
            except ValueError:
                first = None
            if isinstance(first, int):
                lo = max(lo, first - 86400)
        return bars_array(self.conn, lo, int(data_end))

    def _log(self) -> list[dict]:
        return [json.loads(r[0]) for r in self.conn.execute("SELECT line_json FROM lead_line ORDER BY id")]

    def _record_run(self, now: datetime, data_end: int, out: dict) -> int:
        state = {k: out.get(k) for k in ("states", "plans", "errors", "calendar_errors", "waiting", "first_ts",
                                         "message", "picks_sha256", "mismatch")}
        with db.transaction(self.conn):
            return self.conn.execute(
                "INSERT INTO lead_run (run_utc, data_end_ts, status, calendar_sha256, tree_sha256, versions_json,"
                " state_json) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (to_iso(now), int(data_end), out["status"], out.get("calendar_sha256"), out.get("tree_sha256"),
                 json.dumps(out.get("versions") or {}, sort_keys=True),
                 json.dumps(state, sort_keys=True, default=str))).lastrowid

    def _fail(self, now, data_end, status, message) -> dict:
        st = {pid: {"state": "calendar_refused" if status == "calendar refused" else "refused",
                    "text": "Calendar refused" if status == "calendar refused" else "Code check refused",
                    "next_entry_ts": None} for pid in lead_ids()}
        out = {"status": status, "message": message, "states": st, "new_lines": 0, "entries": [], "exits": [],
               "settled": [], "late": []}
        out["run_id"] = self._record_run(now, data_end, out)
        return out

    def run(self, now: datetime, data_end: int | None = None) -> dict:
        import numpy as np
        if data_end is None:
            mark = self.complete_through() if self.complete_through else None
            if mark is None:
                return {"status": "waiting for the feed", "states": {}, "entries": [], "exits": [], "settled": []}
            data_end = min(int(mark), int(now.timestamp()))
        data_end = int(data_end) - int(data_end) % 60
        try:
            B.verify(self.bundle_dir)
        except B.BundleRefused as e:
            return self._fail(now, data_end, "refused", str(e))
        m1 = self._bars(data_end)
        run_id = f"APP-LEAD-{now:%Y%m%dT%H%M%SZ}"
        req = {"bundle": str(self.bundle_dir), "calendar_dir": str(self.calendar_dir), "data_end": data_end,
               "run_day": label_of(data_end - 60), "run_id": run_id, "log": self._log()}
        buf = io.BytesIO()
        np.savez(buf, request=np.array(json.dumps(req, default=float)), **m1)
        r = subprocess.run(self.command(), input=buf.getvalue(), capture_output=True, timeout=self.timeout_s,
                           cwd=str(self.bundle_dir), env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"})
        if r.returncode != 0:
            return self._fail(now, data_end, "error", r.stderr.decode(errors="replace")[-500:])
        out = json.loads(r.stdout)
        if out["status"] != "done":
            return self._fail(now, data_end, out["status"], out.get("message", ""))
        out.update(new_lines=0, entries=[], exits=[], settled=[], late=[], mismatch=[])
        new = self._store_lines(out)
        if out["mismatch"]:                       # a logged position recomputed differently: never overwritten
            out["status"] = "mismatch"
        pending = out.pop("_pending")
        out["run_id"] = self._record_run(now, data_end, out)
        self._write_lines(out["run_id"], pending)
        out["new_lines"] = len(pending)
        for line in new:
            self._settle(line, out, now)
        self._entries_exits(out, now)
        return out

    def _store_lines(self, out: dict) -> list[dict]:
        new = []
        rows = {r["position_id"]: r["line_sha256"] for r in
                self.conn.execute("SELECT position_id, line_sha256 FROM lead_line WHERE position_id IS NOT NULL")}
        pending = []
        for line in out["lines"]:
            pid = line.get("position_id")
            if not pid or line.get("kind") not in POSITION_KINDS:
                continue
            sha = out["line_sha256"][pid]
            if pid in rows:
                if rows[pid] != sha:
                    out["mismatch"].append(pid)
                continue
            pending.append((line, sha))
        out["_pending"] = pending
        return [x for x, _ in pending]

    def _write_lines(self, run_id: int, pending: list) -> None:
        with db.transaction(self.conn):
            for line, sha in pending:
                self.conn.execute("INSERT INTO lead_line (run_id, pick_id, position_id, kind, line_json, line_sha256)"
                                  " VALUES (?, ?, ?, ?, ?, ?)",
                                  (run_id, line["pick_id"], line["position_id"], line["kind"],
                                   json.dumps(line, sort_keys=True, default=float), sha))

    def _suggestion(self, pid: str, t: int, te: int | None, out: dict, now: datetime, late: bool) -> tuple[int, bool]:
        return L.add_suggestion(self.conn, {
            "key": f"lead:{pid}:{int(t)}:1", "source": "lead", "rule_id": pid,
            "code_sha256": out["picks_sha256"].get(pid, ""), "offered": 1, "reason": None, "placed_ts": int(t),
            "side": 1, "entry": None, "stop": None, "target": None, "expiry_ts": te, "score": None, "tier": None,
            "w": 1.0, "ticks": {}, "record_line": record_line(pid), "late": 1 if late else 0}, now=now)

    def _settle(self, line: dict, out: dict, now: datetime) -> None:
        sid, made = self._suggestion(line["pick_id"], line["decision_ts"], line.get("sched_exit_ts"), out, now, True)
        if made:
            out["late"].append(sid)
        if L.settle(self.conn, sid, _result(line), now=now)[1]:
            out["settled"].append(sid)

    def _entries_exits(self, out: dict, now: datetime) -> None:
        n = now.timestamp()
        for pid, plan in (out.get("plans") or {}).items():
            for t, te in plan:
                if t < B.FORWARD_START or t > n:
                    continue
                late = n - t > LATE_AFTER_S
                sid, made = self._suggestion(pid, t, te, out, now, late)
                if made and n - t <= STALE_AFTER_S:
                    (out["late"] if late else out["entries"]).append(sid)
                if te <= n and L.add_event(self.conn, sid, "lead_exit", te, now=now)[1] and n - te <= STALE_AFTER_S:
                    out["exits"].append(sid)

