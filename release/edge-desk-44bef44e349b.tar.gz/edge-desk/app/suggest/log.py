"""B4 suggestion log: append-only rows for suggestions, the owner's decisions, links to MT5, results and events.

Every table here refuses UPDATE and DELETE (SQLite triggers, app/db.py APPEND_ONLY_TABLES). A correction is a new
row whose supersedes_id points to the row it corrects; the current row is the one nothing supersedes.
- suggestion: one row per worker output (key = source:rule:placement time:side). Rows with offered = 0 are setups
  below the tier, logged as "not offered" with their reason.
- suggestion_decision: Take, Skip or Changed (Skip and Changed need a reason); a second tap supersedes the first.
- suggestion_link: the MT5 order or trade a suggestion led to, by the setup check's link logic (A3,
  app/checklist/store.py): the owner's tap; the fill of a linked order ticket; or an auto-match (the only EUR/USD
  pending order or position on the suggestion's side, placed from the suggestion's time to its expiry, its price
  within 1.0 pip of the entry and its stop within 1.0 pip of the stop), offered until the owner confirms it. Only
  suggestions he took or changed are auto-matched.
- suggestion_result: the suggestion's own paper result, settled once, whether he took it or not.
- suggestion_event: a rule-12 cancel, the 16:55 New York expiry, a lead's exit.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime

from app import db
from app.checklist.store import MATCH_PRICE_PIPS, MATCH_STOP_PIPS, _fill_of, _pending_orders
from app.timeutil import from_iso, to_iso

DECISIONS = ("take", "skip", "changed")
EVENT_KINDS = ("cancel", "expiry", "lead_exit")
OUTCOMES = ("filled", "expired", "cancelled", "no_trade")
_FIELDS = ("key", "source", "rule_id", "code_sha256", "offered", "reason", "placed_ts", "side", "entry", "stop",
           "target", "expiry_ts", "score", "tier", "w", "ticks_json", "record_line", "late")
_EPS = 1e-9


def _one(conn, sql, args=()) -> dict | None:
    r = conn.execute(sql, args).fetchone()
    return None if r is None else dict(r)


def get(conn: sqlite3.Connection, sid: int) -> dict:
    r = _one(conn, "SELECT * FROM suggestion WHERE id = ?", (sid,))
    if r is None:
        raise LookupError(f"no suggestion {sid}")
    return r


def root_of(conn: sqlite3.Connection, sid: int) -> int:
    r = get(conn, sid)
    while r["supersedes_id"] is not None:
        r = get(conn, r["supersedes_id"])
    return r["id"]


def current(conn: sqlite3.Connection, sid: int) -> dict:
    """The newest version of a suggestion (following corrections from any version)."""
    r = get(conn, root_of(conn, sid))
    while True:
        nxt = _one(conn, "SELECT * FROM suggestion WHERE supersedes_id = ? ORDER BY id DESC LIMIT 1", (r["id"],))
        if nxt is None:
            return r
        r = nxt


def by_key(conn: sqlite3.Connection, key: str) -> dict | None:
    return _one(conn, "SELECT * FROM suggestion WHERE key = ? AND supersedes_id IS NULL", (key,))


def add_suggestion(conn: sqlite3.Connection, s: dict, *, now: datetime) -> tuple[int, bool]:
    """Insert once by key. Returns (id, created)."""
    row = dict(s)
    row["ticks_json"] = json.dumps(row.pop("ticks", {}) or {}, sort_keys=True)
    row.setdefault("late", 0)
    if row["offered"] not in (0, 1) or row["side"] not in (-1, 1) or row["source"] not in ("method", "lead"):
        raise ValueError("offered is 0 or 1, side -1 or 1, source method or lead")
    if not row["offered"] and not (row.get("reason") or "").strip():
        raise ValueError("a suggestion that is not offered needs its reason")
    if not (row.get("record_line") or "").strip():
        raise ValueError("every suggestion carries its record line")
    with db.transaction(conn):
        old = by_key(conn, row["key"])
        if old is not None:
            return old["id"], False
        cols = ", ".join(("made_utc",) + _FIELDS)
        sid = conn.execute(f"INSERT INTO suggestion ({cols}) VALUES ({', '.join('?' * (len(_FIELDS) + 1))})",
                           (to_iso(now), *(row.get(k) for k in _FIELDS))).lastrowid
        return sid, True


def correct_suggestion(conn: sqlite3.Connection, sid: int, changes: dict, *, now: datetime) -> int:
    cur = current(conn, sid)
    row = {k: cur[k] for k in _FIELDS}
    if "ticks" in changes:
        changes = {**changes, "ticks_json": json.dumps(changes.pop("ticks"), sort_keys=True)}
    bad = set(changes) - set(_FIELDS) - {"ticks_json"} or {"key"} & set(changes)
    if bad:
        raise ValueError(f"cannot correct {sorted(bad)}")
    row.update(changes)
    with db.transaction(conn):
        cols = ", ".join(("made_utc", "supersedes_id") + _FIELDS)
        return conn.execute(f"INSERT INTO suggestion ({cols}) VALUES ({', '.join('?' * (len(_FIELDS) + 2))})",
                            (to_iso(now), cur["id"], *(row[k] for k in _FIELDS))).lastrowid


# ---------------------------------------------------------------- decisions

def current_decision(conn: sqlite3.Connection, sid: int) -> dict | None:
    return _one(conn, "SELECT * FROM suggestion_decision d WHERE suggestion_id = ? AND NOT EXISTS"
                      " (SELECT 1 FROM suggestion_decision x WHERE x.supersedes_id = d.id) ORDER BY id DESC LIMIT 1",
                (root_of(conn, sid),))


def add_decision(conn: sqlite3.Connection, sid: int, decision: str, reason: str, *, now: datetime) -> dict:
    """One row per tap. Skip and Changed need a reason; a second tap supersedes the first (never an edit)."""
    if decision not in DECISIONS:
        raise ValueError("decision is take, skip or changed")
    reason = (reason or "").strip()
    if decision in ("skip", "changed") and not reason:
        raise ValueError("Skip and Changed need a reason")
    if len(reason) > 500:
        raise ValueError("reason: at most 500 characters")
    root = root_of(conn, sid)
    if not current(conn, root)["offered"]:
        raise ValueError("only an offered suggestion can be decided")
    with db.transaction(conn):
        prev = current_decision(conn, root)
        did = conn.execute("INSERT INTO suggestion_decision (suggestion_id, decision, reason, decided_utc,"
                           " supersedes_id) VALUES (?, ?, ?, ?, ?)",
                           (root, decision, reason, to_iso(now), None if prev is None else prev["id"])).lastrowid
        return _one(conn, "SELECT * FROM suggestion_decision WHERE id = ?", (did,))


# ---------------------------------------------------------------- events, results, runs

def add_event(conn: sqlite3.Connection, sid: int, kind: str, at_ts: int, *, now: datetime,
              detail: str = "") -> tuple[int, bool]:
    if kind not in EVENT_KINDS:
        raise ValueError(kind)
    root = root_of(conn, sid)
    with db.transaction(conn):
        old = _one(conn, "SELECT id FROM suggestion_event WHERE suggestion_id = ? AND kind = ?", (root, kind))
        if old is not None:
            return old["id"], False
        return conn.execute("INSERT INTO suggestion_event (suggestion_id, kind, at_ts, made_utc, detail)"
                            " VALUES (?, ?, ?, ?, ?)", (root, kind, int(at_ts), to_iso(now), detail)).lastrowid, True


def events(conn: sqlite3.Connection, sid: int) -> dict:
    return {r["kind"]: dict(r) for r in conn.execute("SELECT * FROM suggestion_event WHERE suggestion_id = ?",
                                                      (root_of(conn, sid),))}


def settle(conn: sqlite3.Connection, sid: int, res: dict, *, now: datetime) -> tuple[int, bool]:
    """The suggestion's own paper result, written once."""
    if res.get("outcome") not in OUTCOMES:
        raise ValueError("outcome")
    root = root_of(conn, sid)
    with db.transaction(conn):
        old = _one(conn, "SELECT id FROM suggestion_result WHERE suggestion_id = ?", (root,))
        if old is not None:
            return old["id"], False
        rid = conn.execute(
            "INSERT INTO suggestion_result (suggestion_id, outcome, exit_reason, R_20, R_16, R_before, unit,"
            " settled_utc) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (root, res["outcome"], res.get("exit_reason"), res.get("R_20"), res.get("R_16"), res.get("R_before"),
             res.get("unit", "R"), to_iso(now))).lastrowid
        return rid, True


def result(conn: sqlite3.Connection, sid: int) -> dict | None:
    return _one(conn, "SELECT * FROM suggestion_result WHERE suggestion_id = ?", (root_of(conn, sid),))


def log_run(conn: sqlite3.Connection, worker: str, close_ts: int, status: str, *, now: datetime,
            detail: str = "") -> int:
    with db.transaction(conn):
        return conn.execute("INSERT INTO worker_run (worker, close_ts, status, detail, made_utc) VALUES (?,?,?,?,?)",
                            (worker, int(close_ts), status, detail[:1000], to_iso(now))).lastrowid


def runs(conn: sqlite3.Connection, worker: str, close_ts: int) -> list[dict]:
    return [dict(r) for r in conn.execute("SELECT * FROM worker_run WHERE worker = ? AND close_ts = ? ORDER BY id",
                                          (worker, int(close_ts)))]


# ---------------------------------------------------------------- links (A3's logic)

def _live_links(conn: sqlite3.Connection, root: int | None = None) -> list[dict]:
    sql = ("SELECT * FROM suggestion_link l WHERE NOT EXISTS (SELECT 1 FROM suggestion_link x"
           " WHERE x.supersedes_id = l.id)")
    args: tuple = ()
    if root is not None:
        sql += " AND suggestion_id = ?"
        args = (root,)
    return [dict(r) for r in conn.execute(sql + " ORDER BY id", args)]


def _add_link(conn, cfg, root: int, now: datetime, method: str, confirmed: int, order_ticket=None,
              position_id=None, trade_id=None, supersedes_id=None, rejected=0) -> dict:
    lid = conn.execute(
        "INSERT INTO suggestion_link (suggestion_id, created_utc, account_alias, order_ticket, position_id, trade_id,"
        " method, confirmed, rejected, supersedes_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (root, to_iso(now), cfg.account.alias, order_ticket, position_id, trade_id, method, confirmed, rejected,
         supersedes_id)).lastrowid
    return _one(conn, "SELECT * FROM suggestion_link WHERE id = ?", (lid,))


def link_trade(conn: sqlite3.Connection, cfg, sid: int, trade_id: int, *, now: datetime) -> dict:
    """The owner picks the MT5 trade a suggestion led to."""
    root = root_of(conn, sid)
    t = _one(conn, "SELECT * FROM trade WHERE id = ? AND book = 'mt5' AND account_alias = ?",
             (trade_id, cfg.account.alias))
    if t is None or not cfg.is_eurusd(t["symbol"]):
        raise ValueError("not an EUR/USD MT5 trade of this account")
    with db.transaction(conn):
        return _add_link(conn, cfg, root, now, "owner_tap", 1, position_id=t["broker_position_id"], trade_id=t["id"])


def confirm_link(conn: sqlite3.Connection, link_id: int, *, now: datetime) -> dict:
    ln = _one(conn, "SELECT * FROM suggestion_link WHERE id = ?", (link_id,))
    if ln is None or ln["confirmed"] or ln["rejected"]:
        raise ValueError("no offered link with that id")
    with db.transaction(conn):
        return _add_link(conn, _Alias(ln["account_alias"]), ln["suggestion_id"], now, ln["method"], 1,
                         ln["order_ticket"], ln["position_id"], ln["trade_id"], supersedes_id=ln["id"])


def reject_link(conn: sqlite3.Connection, link_id: int, *, now: datetime) -> dict:
    ln = _one(conn, "SELECT * FROM suggestion_link WHERE id = ?", (link_id,))
    if ln is None or ln["rejected"]:
        raise ValueError("no link with that id")
    with db.transaction(conn):
        return _add_link(conn, _Alias(ln["account_alias"]), ln["suggestion_id"], now, ln["method"], 0,
                         ln["order_ticket"], ln["position_id"], ln["trade_id"], supersedes_id=ln["id"], rejected=1)


class _Alias:
    def __init__(self, alias: str):
        self.account = type("A", (), {"alias": alias})()


def linked_trade(conn: sqlite3.Connection, sid: int) -> dict | None:
    for ln in reversed(_live_links(conn, root_of(conn, sid))):
        if ln["confirmed"] and not ln["rejected"] and ln["trade_id"] is not None:
            return _one(conn, "SELECT * FROM trade WHERE id = ?", (ln["trade_id"],))
    return None


def _fits(cfg, s: dict, side: str, symbol: str, price, sl, at: datetime) -> bool:
    pip = cfg.instrument.pip_size
    want = "buy" if s["side"] == 1 else "sell"
    if side != want or not cfg.is_eurusd(symbol) or price is None or sl is None or s["entry"] is None:
        return False
    if not s["placed_ts"] <= at.timestamp() <= (s["expiry_ts"] or s["placed_ts"]):
        return False
    return abs(price - s["entry"]) <= MATCH_PRICE_PIPS * pip + _EPS and \
        (s["stop"] is None or abs(sl - s["stop"]) <= MATCH_STOP_PIPS * pip + _EPS)


def resolve_links(conn: sqlite3.Connection, cfg, *, now: datetime) -> list[dict]:
    """Fills of linked order tickets, then auto-match offers for taken or changed suggestions with no live link.
    Running twice writes nothing new."""
    made: list[dict] = []
    with db.transaction(conn):
        live = _live_links(conn)
        for ln in live:                                           # fills of linked orders
            if not ln["order_ticket"] or ln["trade_id"] is not None or ln["rejected"]:
                continue
            t = _fill_of(conn, cfg, ln["order_ticket"])
            if t is None or any(x["trade_id"] == t["id"] and x["suggestion_id"] == ln["suggestion_id"] for x in live):
                continue
            made.append(_add_link(conn, cfg, ln["suggestion_id"], now, "auto_exact_ticket", ln["confirmed"],
                                  ln["order_ticket"], t["broker_position_id"], t["id"]))
        live = _live_links(conn)
        all_links = [dict(r) for r in conn.execute("SELECT * FROM suggestion_link")]
        used_tickets = {x["order_ticket"] for x in live if x["order_ticket"] and not x["rejected"]} | \
            {x["position_id"] for x in live if x["position_id"] and not x["rejected"]}
        used_trades = {x["trade_id"] for x in live if x["trade_id"] is not None and not x["rejected"]}
        orders = _pending_orders(conn, cfg)
        trades = [dict(r) for r in conn.execute("SELECT * FROM trade WHERE book = 'mt5' AND account_alias = ?",
                                                (cfg.account.alias,))]
        roots = [dict(r) for r in conn.execute("SELECT * FROM suggestion WHERE supersedes_id IS NULL AND offered = 1")]
        for root in roots:
            d = current_decision(conn, root["id"])
            if d is None or d["decision"] not in ("take", "changed"):
                continue
            if any(x["suggestion_id"] == root["id"] and not x["rejected"] for x in live):
                continue
            s = current(conn, root["id"])
            refused = {x["order_ticket"] for x in all_links if x["suggestion_id"] == root["id"] and x["rejected"]} | \
                {x["position_id"] for x in all_links if x["suggestion_id"] == root["id"] and x["rejected"]}
            cands = [("order", o) for o in orders if o["ticket"] not in used_tickets and o["ticket"] not in refused
                     and _fits(cfg, s, o["side"], o["symbol"], o["price"], o["sl"], o["at"])]
            tickets = {o["ticket"] for _, o in cands}
            cands += [("trade", t) for t in trades if t["id"] not in used_trades
                      and t["broker_position_id"] not in used_tickets and t["broker_position_id"] not in refused
                      and t["broker_position_id"] not in tickets
                      and _fits(cfg, s, t["side"], t["symbol"], t["open_price"], t["initial_sl"],
                                from_iso(t["open_utc"]))]
            if len(cands) != 1:
                continue
            kind, c = cands[0]
            if kind == "order":
                made.append(_add_link(conn, cfg, root["id"], now, "auto_match", 0, order_ticket=c["ticket"]))
                used_tickets.add(c["ticket"])
            else:
                made.append(_add_link(conn, cfg, root["id"], now, "auto_match", 0,
                                      position_id=c["broker_position_id"], trade_id=c["id"]))
                used_trades.add(c["id"])
    return made
