"""B2 your method as coded: R57-1H-NEAR from a byte-identical copy of research/round57/owner_rules.py, run at each
1h close from 07:00 to 16:00 London on the bars known at that moment, turned into suggestions.

- The pinned file (app/suggest/owner_rules.py, sha256 below) is never changed. This module only calls R.run.
- At each close t (08:00 to 16:00 London: the trigger bars open from 07:00 and end by 16:00, owner_rules s5 rule 6)
  the worker runs only after the feed's "complete through" marker reaches t, on bars with ts < t only (Market.cut),
  with history from 120 days earlier; with less history it refuses (ATR20 needs 20 New York days, the 4h checks
  about 50 4h bars).
- Adapter rule (docs/APP_BUILD_CARD.md B2), outside the pinned file: on bars cut at t the frozen code closes a still
  open filled trade as a 'time' exit at the last minute (owner_rules.py exit_scan: i = e - 1), so its end_ts is the
  cut and the trigger at t is not marked busy. A main-book trade filled by t whose exit reason is 'time' while its
  16:55 New York expiry is after t is still open: the trigger at t is busy (and the fake result is left out of the
  day rules, which only the trigger at t could read).
- A main-book order placed at t (void empty) becomes a suggestion; a shadow-book setup is logged as not offered,
  and so is a main-book setup the adapter makes busy.
- Lifecycle: a later run that shows a rule-12 cancel (outcome 'cancelled', cancel_ts by then) for an open
  suggestion writes a cancel row; the 16:55 New York expiry writes an expiry row; after the day ends (17:00 New
  York, marker through it) R.run on the full day settles each suggestion's own result, offered or not.
"""
from __future__ import annotations

import hashlib
import json
import math
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path

from app import db
from app.suggest import log as L
from app.suggest.records import record_line
from app.timeutil import LONDON, NEW_YORK, to_iso

PIN_SHA256 = "9cec467583d5da8b416c568d5ad917fb05fae948e9b38f4625013eb25ea56af5"
RULES_PATH = Path(__file__).with_name("owner_rules.py")
VARIANT = "R57-1H-NEAR"
HISTORY_DAYS = 120
LATE_AFTER_S = 15 * 60
COLS = ("ts_utc", "bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")
TICKS = ("M1", "M2", "M3", "M4", "C1", "C2", "C3", "C4", "C5")


class Refused(RuntimeError):
    pass


def rules():
    """The pinned rule file, after its sha256 check."""
    got = hashlib.sha256(RULES_PATH.read_bytes()).hexdigest()
    if got != PIN_SHA256:
        raise Refused(f"owner_rules.py sha256 {got} is not the pinned {PIN_SHA256}")
    from app.suggest import owner_rules as R
    return R


def closes(day: date) -> list[int]:
    """The 1h closes of a London date that can trigger: 08:00 to 16:00 London."""
    return [int(datetime.combine(day, datetime.min.time().replace(hour=h), LONDON).timestamp()) for h in range(8, 17)]


def expiry_ts(day_ny: date) -> int:
    return int(datetime.combine(day_ny, datetime.min.time().replace(hour=16, minute=55), NEW_YORK).timestamp())


def day_end_ts(day_ny: date) -> int:
    return int(datetime.combine(day_ny, datetime.min.time().replace(hour=17), NEW_YORK).timestamp())


def frame(conn: sqlite3.Connection, start_ts: int, end_ts: int):
    """M1 bars with start_ts <= ts < end_ts as owner_rules' DataFrame. No bar at or after end_ts is ever read."""
    import pandas as pd
    rows = conn.execute("SELECT ts, bid_o, bid_h, bid_l, bid_c, ask_o, ask_h, ask_l, ask_c FROM m1_bar"
                        " WHERE ts >= ? AND ts < ? ORDER BY ts", (int(start_ts), int(end_ts))).fetchall()
    return pd.DataFrame([tuple(r) for r in rows], columns=list(COLS))


def _f(x):
    if x is None:
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(v) else v


def _ticks(rec: dict) -> dict:
    out = {}
    for k in TICKS:
        v = rec.get(k)
        out[k] = bool(v) if isinstance(v, (bool, int, float)) and not (isinstance(v, float) and math.isnan(v)) \
            else None
    return out


def _time_open(rec: dict, t: int, R) -> bool:
    """The adapter rule: a main-book trade filled by t, 'time' exit while its expiry is after t."""
    if rec.get("book") != "main" or rec.get("outcome") != "filled" or rec.get("exit_reason") != "time":
        return False
    fill = rec.get("fill_ts")
    exp = expiry_ts(R.ny_day_of(int(rec["t"]) - 60))
    return fill is not None and int(fill) < t and exp > t


def decide_at(R, df, t: int, day: date) -> list[dict]:
    """The records placed at close t from bars cut at t, with the adapter applied. Each item: the record, and
    'offer' (True for a main-book order) or a not-offered reason."""
    M = R.Market(df).cut(t)
    if M.n and int(M.ts[-1]) >= t:
        raise Refused("a bar at or after the cut reached the rules")
    _, recs = R.run(M, VARIANT, start=day.isoformat(), end=day.isoformat())
    if not len(recs):
        return []
    rs = recs.to_dict("records")
    open_at_cut = any(_time_open(r, t, R) for r in rs if int(r["t"]) < t)
    out = []
    for r in rs:
        if int(r["t"]) != t:
            continue
        void = r.get("void") or ""
        if r.get("book") == "main" and (void == "" or (open_at_cut and void == "day_rules")):
            if open_at_cut:
                out.append({"rec": r, "offer": False, "reason": "busy: a trade of the method is still open"})
            elif void == "":
                out.append({"rec": r, "offer": True, "reason": None})
        elif r.get("book") == "shadow" and void == "":
            out.append({"rec": r, "offer": False, "reason": f"score {int(r['score'])}: below the tier"})
    return out


def full_day(R, df, day: date) -> list[dict]:
    """The full-day run's records for one London date (bars through the day's end)."""
    _, recs = R.run(R.Market(df), VARIANT, start=day.isoformat(), end=day.isoformat())
    return recs.to_dict("records") if len(recs) else []


def _key(t: int, side: int) -> str:
    return f"method:{VARIANT}:{int(t)}:{int(side)}"


def _suggestion(rec: dict, offer: bool, reason: str | None, late: bool) -> dict:
    day = date.fromisoformat(str(rec["ny_day"])[:10]) if rec.get("ny_day") is not None else None
    return {"key": _key(rec["t"], rec["side"]), "source": "method", "rule_id": VARIANT, "code_sha256": PIN_SHA256,
            "offered": 1 if offer else 0, "reason": reason, "placed_ts": int(rec["t"]), "side": int(rec["side"]),
            "entry": _f(rec.get("P")), "stop": _f(rec.get("S")), "target": _f(rec.get("T")),
            "expiry_ts": expiry_ts(day) if day else None, "score": int(rec["score"]),
            "tier": {1.0: "full", 0.5: "half"}.get(_f(rec.get("w")), "none") if offer else "none",
            "w": _f(rec.get("w")) or 0.0, "ticks": _ticks(rec), "record_line": record_line(VARIANT),
            "late": 1 if late else 0}


# ---------------------------------------------------------------- the worker

class MethodWorker:
    """One step at a time: run_due(now) runs every due close of today (after the marker), writes lifecycle rows and
    settles the day after its end. Returns the alerts' inputs for app.notify (no order card, ever)."""

    def __init__(self, conn: sqlite3.Connection, cfg, complete_through=None):
        from app.feed.oanda import complete_through as ct
        self.conn, self.cfg = conn, cfg
        self.complete_through = complete_through or (lambda: ct(conn))
        self.R = rules()
        self._cache = None

    def _history_ok(self, t: int) -> bool:
        row = self.conn.execute("SELECT MIN(ts) FROM m1_bar").fetchone()
        return row is not None and row[0] is not None and row[0] <= t - HISTORY_DAYS * 86400

    def _df(self, t: int):
        """Bars with t - 130 days <= ts < t, from an in-memory copy of the window (bars after its last one are
        appended; it is reloaded when an earlier row appears or the window moved past its start; it never holds
        more than the window and a day). No bar at or after t is passed on."""
        import numpy as np
        import pandas as pd
        from app.suggest.bars import bars_array
        lo_need = t - (HISTORY_DAYS + 10) * 86400
        c = self._cache
        if c is not None and len(c["ts_utc"]):
            first, last = int(c["ts_utc"][0]), int(c["ts_utc"][-1])
            held = self.conn.execute("SELECT COUNT(*) FROM m1_bar WHERE ts >= ? AND ts <= ?",
                                     (first, last)).fetchone()[0]
            older = first > lo_need and self.conn.execute(
                "SELECT COUNT(*) FROM m1_bar WHERE ts >= ? AND ts < ?", (lo_need, first)).fetchone()[0] > 0
            if held != len(c["ts_utc"]) or older:
                c = None
        if c is None:
            c = bars_array(self.conn, lo_need, 2 ** 62)
        else:
            new = bars_array(self.conn, int(c["ts_utc"][-1]) + 1, 2 ** 62)
            c = {k: np.concatenate([c[k], new[k]]) for k in COLS}
            keep = int(np.searchsorted(c["ts_utc"], lo_need - 86400))
            if keep:
                c = {k: v[keep:] for k, v in c.items()}
        self._cache = c
        lo, hi = np.searchsorted(c["ts_utc"], lo_need), np.searchsorted(c["ts_utc"], t)
        return pd.DataFrame({k: c[k][lo:hi] for k in COLS})

    def run_close(self, t: int, now: datetime) -> dict:
        """The run for one close. Refuses without the marker or with too little history."""
        out = {"close": t, "made": [], "not_offered": [], "status": None}
        if L.runs(self.conn, "method", t) and any(r["status"] in ("ran", "late") for r in L.runs(self.conn, "method", t)):
            out["status"] = "done"
            return out
        mark = self.complete_through()
        if mark is None or mark < t:
            out["status"] = "waiting for the feed"
            return out
        if not self._history_ok(t):
            if not any(r["status"] == "refused" for r in L.runs(self.conn, "method", t)):   # logged once a close
                L.log_run(self.conn, "method", t, "refused", now=now, detail=f"under {HISTORY_DAYS} days of history")
            out["status"] = "refused"
            return out
        late = now.timestamp() - t > LATE_AFTER_S
        day = datetime.fromtimestamp(t - 60, LONDON).date()
        for item in decide_at(self.R, self._df(t), t, day):
            s = _suggestion(item["rec"], item["offer"], item["reason"], late)
            sid, made = L.add_suggestion(self.conn, s, now=now)
            if made:
                (out["made"] if item["offer"] else out["not_offered"]).append(sid)
        out["status"] = "late" if late else "ran"
        v = versions()
        L.log_run(self.conn, "method", t, out["status"], now=now,
                  detail=f"{len(out['made'])} offered, {len(out['not_offered'])} not offered;"
                         f" numpy {v['numpy']}, pandas {v['pandas']}")
        return out

    def lifecycle(self, now: datetime) -> dict:
        """Cancels (rule 12) seen by a later run, expiries at 16:55 New York, results after the day's end."""
        out = {"cancel": [], "expiry": [], "settled": []}
        mark = self.complete_through()
        if mark is None:
            return out
        rows = [dict(r) for r in self.conn.execute(
            "SELECT * FROM suggestion WHERE source = 'method' AND supersedes_id IS NULL AND id NOT IN"
            " (SELECT suggestion_id FROM suggestion_result) ORDER BY placed_ts")]
        by_day: dict = {}
        for s in rows:
            by_day.setdefault(datetime.fromtimestamp(s["placed_ts"] - 60, LONDON).date(), []).append(s)
        for day, ss in sorted(by_day.items()):
            ny = self.R.ny_day_of(ss[0]["placed_ts"] - 60)
            end = day_end_ts(ny)
            upto = min(mark, end, int(now.timestamp()))
            last = max(s["placed_ts"] for s in ss)
            if upto <= last:
                continue
            recs = {(int(r["t"]), int(r["side"])): r for r in self._recs_until(day, upto)}
            for s in ss:
                cur = L.current(self.conn, s["id"])
                r = recs.get((s["placed_ts"], s["side"]))
                ev = L.events(self.conn, s["id"])
                if cur["offered"] and r is not None and r.get("outcome") == "cancelled" and "cancel" not in ev \
                        and r.get("cancel_ts") is not None and int(r["cancel_ts"]) <= upto:
                    if L.add_event(self.conn, s["id"], "cancel", int(r["cancel_ts"]), now=now)[1]:
                        out["cancel"].append(s["id"])
                exp = s["expiry_ts"]
                if cur["offered"] and exp and upto >= exp and "expiry" not in ev and "cancel" not in L.events(
                        self.conn, s["id"]) and (r is None or r.get("outcome") != "filled"):
                    if L.add_event(self.conn, s["id"], "expiry", exp, now=now)[1]:
                        out["expiry"].append(s["id"])
                if upto >= end:
                    res = _result(r)
                    if L.settle(self.conn, s["id"], res, now=now)[1]:
                        out["settled"].append(s["id"])
        return out

    def _recs_until(self, day: date, upto: int) -> list[dict]:
        df = self._df(upto)
        if upto >= day_end_ts(self.R.ny_day_of(int(datetime.combine(day, datetime.min.time().replace(hour=12),
                                                                        LONDON).timestamp()))):
            return full_day(self.R, df, day)
        _, recs = self.R.run(self.R.Market(df).cut(upto), VARIANT, start=day.isoformat(), end=day.isoformat())
        rs = recs.to_dict("records") if len(recs) else []
        return [r for r in rs if not _time_open(r, upto, self.R)]

    def run_due(self, now: datetime) -> dict:
        """Every close of today up to now, in order, then the lifecycle. Closes of earlier days with no run are
        logged once as skipped."""
        out = {"runs": [], "lifecycle": None}
        today = now.astimezone(LONDON).date()
        for t in closes(today):
            if t <= now.timestamp():
                out["runs"].append(self.run_close(t, now))
        y = today - timedelta(days=1)
        for t in closes(y):
            if not L.runs(self.conn, "method", t) and y.weekday() < 5:
                L.log_run(self.conn, "method", t, "skipped", now=now, detail="no run for this close")
        try:                                   # a lifecycle error never stops the closes (red team 17 Oct, item 4)
            out["lifecycle"] = self.lifecycle(now)
        except Exception as e:                 # noqa: BLE001
            out["lifecycle"] = {"cancel": [], "expiry": [], "settled": []}
            out["lifecycle_error"] = f"{type(e).__name__}: {str(e)[:200]}"
        return out


def _result(r: dict | None) -> dict:
    if r is None:
        return {"outcome": "no_trade"}
    oc = r.get("outcome")
    if oc == "filled":
        return {"outcome": "filled", "exit_reason": r.get("exit_reason"), "R_20": _f(r.get("R_20")),
                "R_16": _f(r.get("R_16")), "R_before": _f(r.get("R_mid"))}
    if oc in ("expired", "cancelled"):
        return {"outcome": oc}
    return {"outcome": "no_trade"}


def parity_view(rec: dict) -> tuple:
    """The fields live-versus-replay parity compares: placement time, side, entry, stop, target, score, tier."""
    return (int(rec["t"]), int(rec["side"]), round(float(rec["P"]), 6), round(float(rec["S"]), 6),
            round(float(rec["T"]), 6), int(rec["score"]), _f(rec.get("w")))


def versions() -> dict:
    import numpy
    import pandas
    import sys
    return {"numpy": numpy.__version__, "pandas": pandas.__version__, "python": sys.version.split()[0]}


def dumps(x) -> str:
    return json.dumps(x, sort_keys=True, default=str)


__all__ = ["MethodWorker", "decide_at", "full_day", "closes", "rules", "parity_view", "versions", "to_iso", "db"]
