"""The owner's EUR/USD method as exact rule code (Round 57). One self-contained file.

WHAT THIS IS
    The owner's 12 Oct 2026 chart method, written as rules a computer can check without judgement, scored as his checklist,
    plus a small simulator that fills and exits his limit orders on 1-minute bid/ask prices with the repo's costs. The
    repo's own test (research/round57/r57_run.py) imports and runs this same file, so what an outside agent runs here is
    the code the test ran. Nothing here sends an order anywhere; it only reads prices you give it.
    The rules come from research/round57/DECLARATION.md (sections 3-7). Section numbers below ("s5") point there.

INPUT
    A pandas DataFrame (or a dict of arrays) of EUR/USD 1-minute bars with these columns:
        ts_utc                      the minute's open time, unix seconds (UTC), one row per minute that traded
        bid_o, bid_h, bid_l, bid_c  bid open, high, low, close
        ask_o, ask_h, ask_l, ask_c  ask open, high, low, close
    Mid prices are (bid + ask) / 2 per field. Missing minutes are fine (no bar is made for them). Give at least a few
    months of history before the first day you want traded: ATR20 needs 20 New York days, the 4h checks about 50 4h bars.
    Give whole New York days, up to 17:00 New York after the last day you want traded: if the data stops earlier, an
    open trade is closed as a 'time' exit at the last minute there is.

HOW TO CALL IT
    import pandas as pd, owner_rules as R
    m1 = pd.read_csv("EURUSD_M1_bidask.csv")                       # your own data, the columns above
    trades, records = R.run(m1, "R57-30M-TF30", start="2024-01-01", end="2024-12-31")
    print(trades[["london_date", "side", "book", "P", "S", "T", "exit_reason", "R_20", "wR_20"]])
    print(R.summary(trades))
    -   variant: one of R.VARIANTS ("R57-1H-NEAR", "R57-1H-TF30", "R57-30M-NEAR", "R57-30M-TF30"): the trigger
        timeframe (1h or 30m body close) and the FVG choice ("nearest", or "tf30_first" = his "i only chose 30m").
    -   start / end: London dates of the trigger bars to trade (inclusive); earlier rows are used as history only.
    -   trades: one row per FILLED order, both books (book "main" = the trades of the method; book "shadow" = setups
        the checklist says not to take, kept for information). R_20 / R_16 are R after a 2.0 / 1.6 pip cost a trade;
        wR_20 = w x R_20 with w = 1.0 (full risk, score 4-5) or 0.5 (half risk, score 3); wR_20 is blank (NaN) for
        shadow trades. side is -1 for a short, +1 for a long; london_date is the trigger bar's London date. When no
        order fills, trades is empty but still has these columns (R.TRADE_COLUMNS), so the line above prints an empty
        table.
    -   records: one row per setup (every body-close break of a floor in the London window), filled or not, with every
        level the rules found (the daily wick zone, the 4h gap, the lower highs, the floor, the pools and demand zone,
        the leg, the chosen FVG and order block, the checks, the score, the order, the fill, the exit and every R).
    -   R.decide(R.Market(m1), variant, side, k) gives the decision of one trigger-timeframe bar k on one side (-1
        short, +1 long), using only bars closed by that bar's end. It takes a Market, not a DataFrame. Market(m1).cut(t)
        is the same market as known at time t.

THE RULES (short side; the long side is the exact mirror: prices are negated, so highs become lows, above becomes
below, the bid becomes the ask. The code has ONE copy of each rule and runs it on a mirrored view for longs.)
    Owner's words (Melbourne times, 12 Oct 2026 unless stated) and the rule each one became:
    Direction
      C1 daily (s5)  "Daily wick longer than body" (7:40 pm): one of the last 5 completed New York daily candles has an
                     upper wick longer than its body and at least 0.20 x ATR20; within the last 24 hours a closed 1h
                     bar came back up into that wick zone (body top to high); no 1h close since went above the zone's
                     top ("a candle body closing beyond the level means it's a real break, not a sweep", 11 Oct); the
                     last closed 1h bar closes back below the zone.
      C2 4h (s5)     "Fvg Filled, means price has been corrected": the newest bearish 4h FVG whose middle candle is a
                     momentum candle, with its third candle in the last 30 4h bars, has been traded up to its top by a
                     later 4h bar, and the last 4h close is back below that top.
      C3 1h (s5)     the falling trendline of lower highs (his 7:44 pm chart): the last three 1h swing highs (5 bars
                     each side) are all within 168 hours and each lower than the one before, and the last 1h close is
                     below the straight line through the last two (in 1h bar count).
    Map
      floor (rule 4) a double low: two 1h swing lows (2 bars each side) within 72 hours, at most 3.0 pips apart, with no
                     1h bar between them lower than the lower one; the floor F is the lower low; unbroken = no trigger
                     bar has closed below F since the second low; the highest unbroken floor is used.
      pools (rule 5) "$$$= i marked that as liquidity pools": untaken 1h swing lows within 120 hours more than 1.0 pip
                     below F. L = the nearest one; the demand zone runs from Zb (the lowest pool at most 10.0 pips
                     below L) up to F.
    Trigger
      M1 (rule 6)    "Wait for valid candle body bearish break": a bearish trigger bar (1h or 30m by variant) that
                     opens at or after 07:00 London and ends by 16:00 London closes below F. A wick does not count.
                     "If price never breaks that floor, i dont trade" (rule 11).
      rule 12        "if it goes up and seen that its a momentum candle bullish, then i wait for another structure
                     bullish": a bullish momentum candle on the trigger timeframe that closes above the last swing high
                     blocks shorts for the rest of the New York day and cancels an unfilled short order.
    Entry
      M2 (rules 7-8) "whatever fvg i see that is not yet touched can be my entry, i only chose 30m. But it could be 15m
                     or 5m too": an untouched bearish FVG on 30m, 15m or 5m left in the last 24 hours (from the highest
                     minute), with its 50% (CE) at least 2.0 pips above the trigger close; the sell limit sits at the
                     CE. "inside those 30m fvg, thered 5 or 3m orderblocks, that makes my entry stronger" -> C5.
    Stop and target
      stop (rule 9)  "The wick is always for sl" (10 Oct): 1.5 pips above the FVG's top, at least 5.0 pips from the
                     entry, at most 30.0 pips ("i dont mind 30 pips", 11 Oct).
      target (r. 10) "Im more on 3R" (10 Oct): T = entry - 3 x risk. M4: "once the price go downthere, it might not hit
                     tp" (7:55 pm): no trade if T is below the demand zone's bottom Zb (inside the zone is fine).
    Checklist ("The more checks, the more reason to go into. Less checks, less risk capital. Or half", 7:52 pm)
      must-haves M1 break, M2 entry FVG, M3 "follow the trend" (7:58 pm) = C1 or C2, M4 zone cap;
      checks C1 daily, C2 4h, C3 1h lower highs, C4 a pool below T, C5 an order block inside the entry FVG;
      score 4-5 = full risk (w 1.0), 3 = half (w 0.5), 0-2 = no trade (shadow book).
    Gallery habits G1-G3 (his old screenshots, 8:12 pm), report only: G1 entry on the right side of the 17:00 New York
      daily open; G2 a sweep of the Asia range or of the previous day's extreme before the break; G3 a trigger close
      from 07:00 to 11:30 or from 13:00 to 14:30 London.
    Orders, fills, exits (s6): the limit is placed at the trigger bar's end t and lives until 16:55 New York (or a
      rule-12 cancel). A sell limit fills at its price when the bid high reaches it; a stop fills at max(stop, ask open)
      + 0.2 pip; a target fills at its price (never in the fill minute); stop first when both are hit in one minute;
      once +2R is reached the stop moves to the entry from the next minute (a +2R touch in the fill minute does not
      arm it, as a target there does not count: the order of prices inside that minute is unknown; AMENDMENTS.md);
      still open at 16:55 New York -> closed at the ask close + 0.2 pip.
    Day rules (s7, his product rules of 8 Oct): one order or position at a time (an unfilled live order also blocks
      the book); after a win at most one more trade; a loss after a win ends the day; two losses end the day; a
      breakeven exit counts as neither.
    R (s6): R_ba from bid/ask fills; R_mid from mid prices; R_20 = min(R_mid - 2.0 / stop pips, R_ba) - financing.

CONSTANTS: listed below with their section; PIP 0.0001, EPS 1e-9, TICK 0.1 pip.
All times inside are UTC unix seconds; London and New York local times use zoneinfo (daylight saving handled).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------------------------------------- constants
PIP = 1e-4                    # s4
EPS = 1e-9                    # s4
TICK = 1e-5                   # s4: price tick 0.1 pip
SLIP = 0.2 * PIP              # s6: stop and time-exit slippage
FVG_MIN_PIPS = 0.5            # s5 FVG (Round 1)
SWING_N = 2                   # s5 swing default (Round 1)
MOM_K, MOM_LOOK, MOM_BODY = 1.5, 20, 0.60      # s5 momentum candle (Round 16 displacement_bars, k 1.5, look 20)
R1_DAYS, R1_WICK_ATR, R1_TOUCH_H = 5, 0.20, 24  # s5 C1
R2_BARS = 30                  # s5 C2: the last 30 4h bars
R3_N, R3_HIGHS, R3_HOURS = 5, 3, 168            # s5 C3
R4_TOL_PIPS, R4_HOURS = 3.0, 72                  # s5 rule 4
R5_HOURS, R5_MARGIN_PIPS, R5_CLUSTER_PIPS = 120, 1.0, 10.0   # s5 rule 5
TRIGGER_LONDON = ("07:00", "16:00")              # s5 rule 6
LEG_HOURS = 24                # s5 rule 7
CE_MIN_PIPS = 2.0             # s5 rule 7 (Round 16 GEO-2a)
STOP_BUFFER_PIPS, STOP_MIN_PIPS, STOP_CAP_PIPS = 1.5, 5.0, 30.0   # s5 rule 9
TARGET_R = 3.0                # s5 rule 10
BREAKEVEN_R = 2.0             # s6 stop to entry
EXPIRY_NY = "16:55"           # s6 order expiry and time exit
R12_FROM_LONDON = "07:00"     # s5 rule 12 (a block candle ends after 07:00 London and by 16:55 New York)
COSTS = (2.0, 1.6)            # s6 R_20 and R_16
FIN_PIPS, FIN_WED_PIPS = 1.0, 3.0   # r45 financing_pips (must be 0 here: every trade closes before 17:00 New York)
DAY_MIN_MINUTES = 100         # s4 daily bars: shorter New York days are dropped (r45 daily_bars)
WEIGHTS = {5: 1.0, 4: 1.0, 3: 0.5}   # s3 tiers
G3_WINDOWS = (("07:00", "11:30"), ("13:00", "14:30"))   # s5 G3 (London)
TFS = {"1h": 3600, "30m": 1800, "15m": 900, "5m": 300, "3m": 180}   # clock-aligned UTC buckets; "4h" and "D" below
ENTRY_TFS = ("30m", "15m", "5m")
OB_TFS = ("5m", "3m")
TF_RANK = {"30m": 0, "15m": 1, "5m": 2}
LON, NY, MEL = ZoneInfo("Europe/London"), ZoneInfo("America/New_York"), ZoneInfo("Australia/Melbourne")
COLS = ("ts_utc", "bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")


@dataclass(frozen=True)
class Variant:
    row: int
    id: str
    trigger_tf: str            # "1h" or "30m"
    fvg_choice: str            # "nearest" or "tf30_first"


VARIANTS = {v.id: v for v in (Variant(1, "R57-1H-NEAR", "1h", "nearest"), Variant(2, "R57-1H-TF30", "1h", "tf30_first"),
                              Variant(3, "R57-30M-NEAR", "30m", "nearest"),
                              Variant(4, "R57-30M-TF30", "30m", "tf30_first"))}


def variant_of(v) -> Variant:
    return v if isinstance(v, Variant) else VARIANTS[v]


# ---------------------------------------------------------------------------------------------------------- clocks
def local_ts(d: date, hhmm: str, tz: ZoneInfo) -> int:
    h, m = map(int, hhmm.split(":"))
    return int(datetime.combine(d, time(h, m), tz).timestamp())


def ny_day_of(ts: int) -> date:
    """The New York trading day of a minute: the New York date of (ts + 7 h), so a day ends 17:00 New York (r45)."""
    return datetime.fromtimestamp(int(ts) + 7 * 3600, NY).date()


def _hour_dates(ts: np.ndarray, shift_s: int, tz: ZoneInfo) -> np.ndarray:
    """Local dates of (ts + shift_s) in tz, one zoneinfo lookup per UTC hour (offsets change on whole UTC hours)."""
    hrs = (np.asarray(ts, dtype=np.int64) + shift_s) // 3600
    if len(hrs) == 0:
        return np.zeros(0, dtype=object)
    if (np.diff(hrs) >= 0).all():
        chg = np.r_[0, np.flatnonzero(np.diff(hrs)) + 1]
        u = hrs[chg]
        inv = np.repeat(np.arange(len(u)), np.diff(np.r_[chg, len(hrs)]))
    else:
        u, inv = np.unique(hrs, return_inverse=True)
    d = np.array(pd.to_datetime(u * 3600, unit="s", utc=True).tz_convert(tz).date)
    return d[inv]


def ny_days(ts: np.ndarray) -> np.ndarray:
    """The New York trading day of each minute (vectorised ny_day_of)."""
    return _hour_dates(ts, 7 * 3600, NY)


def day_end_ts(day: date) -> int:
    return local_ts(day, "17:00", NY)


def day_start_ts(day: date) -> int:
    return local_ts(day - timedelta(days=1), "17:00", NY)


def london_date_of(ts: int) -> date:
    return datetime.fromtimestamp(int(ts), LON).date()


def london_hhmm(ts: int) -> str:
    return datetime.fromtimestamp(int(ts), LON).strftime("%H:%M")


def tick(x: float, mode: str) -> float:
    """Round to 0.1 pip: 'up', 'down' or 'near' (r21_sim.tick; 1e-6 tick tolerance for binary noise)."""
    q = x / TICK
    if mode == "up":
        v = math.ceil(q - 1e-6)
    elif mode == "down":
        v = math.floor(q + 1e-6)
    else:
        v = math.floor(q + 0.5 + 1e-6)
    return round(v * TICK, 5)


# ---------------------------------------------------------------------------------------------------------- bars
@dataclass
class Bars:
    o: np.ndarray
    h: np.ndarray
    l: np.ndarray
    c: np.ndarray
    t_open: np.ndarray
    t_end: np.ndarray          # nominal end: open + length (4h: capped at the New York day's end)
    first: np.ndarray          # index of the bar's first 1-minute row
    n: int = field(init=False)

    def __post_init__(self):
        self.n = len(self.o)

    def closed_by(self, t: int) -> int:
        """How many bars are complete at time t (nominal end at or before t). Bars [0, closed_by(t)) are usable."""
        return int(np.searchsorted(self.t_end, int(t), side="right"))

    def holding(self, ts: int) -> int:
        """Index of the bar whose span holds time ts, or -1."""
        k = int(np.searchsorted(self.t_open, int(ts), side="right")) - 1
        return k if k >= 0 and int(self.t_end[k]) > int(ts) else -1


def make_bars(ts, o, h, l, c, t_open_of_minute, t_end_of_minute) -> Bars:
    """Bars from 1-minute rows grouped by their bar's open time (r21_events.make_bars, keyed by open time)."""
    key = np.asarray(t_open_of_minute, dtype=np.int64)
    if len(key) and (np.diff(key) < 0).any():
        raise ValueError("bar keys must be non-decreasing in time")
    if len(key) == 0:
        z = np.zeros(0)
        zi = np.zeros(0, dtype=np.int64)
        return Bars(z, z, z, z, zi, zi, zi)
    first = np.r_[0, np.flatnonzero(np.diff(key)) + 1]
    u = key[first]
    last = np.r_[first[1:], len(key)] - 1
    return Bars(o=o[first], h=np.maximum.reduceat(h, first), l=np.minimum.reduceat(l, first), c=c[last],
                t_open=u.astype(np.int64), t_end=np.asarray(t_end_of_minute, dtype=np.int64)[first],
                first=first.astype(np.int64))


def fractal_swings(h, l, n: int = SWING_N):
    """Strict fractals (r21_events.fractal_swings): is_sh[i] when h[i] > h[j] + EPS for every j != i within n bars;
    is_sl mirrored. A swing at i is usable once bar i + n has closed."""
    m = len(h)
    is_sh = np.zeros(m, dtype=bool)
    is_sl = np.zeros(m, dtype=bool)
    if m < 2 * n + 1:
        return is_sh, is_sl
    core = slice(n, m - n)
    sh = np.ones(m - 2 * n, dtype=bool)
    sl = np.ones(m - 2 * n, dtype=bool)
    for k in range(1, n + 1):
        sh &= (h[core] > h[n - k:m - n - k] + EPS) & (h[core] > h[n + k:m - n + k] + EPS)
        sl &= (l[core] < l[n - k:m - n - k] - EPS) & (l[core] < l[n + k:m - n + k] - EPS)
    is_sh[core] = sh
    is_sl[core] = sl
    return is_sh, is_sl


def momentum_flags(b: Bars):
    """(bearish, bullish) momentum candles (s5): range >= 1.5 x the median range of the 20 bars before it (median > 0)
    and body >= 60% of the range; bearish closes below its open, bullish above."""
    r = b.h - b.l
    med = pd.Series(r).rolling(MOM_LOOK).median().shift(1).to_numpy()
    big = np.isfinite(med) & (med > 0) & (r >= MOM_K * np.where(np.isfinite(med), med, np.inf))
    body = np.abs(b.c - b.o) >= MOM_BODY * r - EPS
    return big & body & (b.c < b.o - EPS), big & body & (b.c > b.o + EPS)


def fvg_list(b: Bars) -> dict:
    """Bearish FVGs (Round 1 fvgs): bars c1, c2, c3 with low(c1) - high(c3) >= 0.5 pip; zone bottom = high(c3),
    top = low(c1); known when c3 closes. Sorted by c3."""
    if b.n < 3:
        e = np.zeros(0, dtype=np.int64)
        return {"c1": e, "c3": e, "bottom": np.zeros(0), "top": np.zeros(0)}
    c3 = np.arange(2, b.n)
    ok = (b.l[c3 - 2] - b.h[c3]) >= FVG_MIN_PIPS * PIP - EPS
    c3 = c3[ok]
    return {"c1": c3 - 2, "c3": c3, "bottom": b.h[c3], "top": b.l[c3 - 2]}


def order_block_list(b: Bars, is_sl: np.ndarray) -> dict:
    """Bearish order blocks (Round 1 order_blocks, mirrored; vectorised, tests check equality with the loop): follow
    the most recent usable swing low (a swing at s becomes current at bar s + 3 and stays current until the next one
    does); the first bar j that closes below it makes an order block of the last bullish bar strictly before j; one per
    broken swing, and an order-block bar is kept only the first time. Zone = that bar's low to high; known when j closes.
    """
    e = np.zeros(0, dtype=np.int64)
    out = {"bar": e, "brk": e, "low": np.zeros(0), "high": np.zeros(0)}
    s = np.flatnonzero(is_sl)
    if b.n == 0 or len(s) == 0:
        return out
    start = s + 3
    keep = start < b.n
    s, start = s[keep], start[keep]
    if len(s) == 0:
        return out
    # current swing at each bar j: the latest k with start[k] <= j
    cur = np.searchsorted(start, np.arange(b.n), side="right") - 1
    valid = cur >= 0
    hit = np.zeros(b.n, dtype=bool)
    jj = np.flatnonzero(valid)
    hit[jj] = b.c[jj] < b.l[s[cur[jj]]] - EPS
    hj = np.flatnonzero(hit)
    if len(hj) == 0:
        return out
    k_of = cur[hj]
    uk, first = np.unique(k_of, return_index=True)     # the first break of each swing (hj ascending)
    brk = hj[first]
    bull = b.c > b.o
    idx = np.where(bull, np.arange(b.n), -1)
    last_bull_upto = np.maximum.accumulate(idx)         # latest bullish bar at or before j
    ob = np.where(brk > 0, last_bull_upto[np.maximum(brk - 1, 0)], -1)
    ok = ob >= 0
    brk, ob = brk[ok], ob[ok]
    _, firstb = np.unique(ob, return_index=True)        # an OB bar only the first time (brk is ascending)
    sel = np.sort(firstb)
    brk, ob = brk[sel], ob[sel]
    return {"bar": ob.astype(np.int64), "brk": brk.astype(np.int64), "low": b.l[ob], "high": b.h[ob]}


# ---------------------------------------------------------------------------------------------------------- market
class Market:
    """1-minute EUR/USD bid/ask and every bar built from its mid prices. Market(m1).cut(t) = the market known at t."""

    def __init__(self, m1):
        df = m1 if isinstance(m1, pd.DataFrame) else pd.DataFrame(m1)
        miss = [c for c in COLS if c not in df.columns]
        if miss:
            raise ValueError(f"missing columns: {miss}")
        df = df[list(COLS)].drop_duplicates("ts_utc").sort_values("ts_utc")
        self.ts = df["ts_utc"].to_numpy(np.int64)
        if (self.ts % 60).any():
            raise ValueError("ts_utc must be minute open times (multiples of 60 s)")
        self.raw = {c: df[c].to_numpy(float) for c in COLS[1:]}
        self.n = len(self.ts)
        self.end_ts = int(self.ts[-1]) + 60 if self.n else 0
        self._bars, self._views, self._days, self._mid = {}, {}, None, {}
        self._nyday = None

    @classmethod
    def _from(cls, ts, raw):
        m = cls.__new__(cls)
        m.ts, m.raw, m.n = ts, raw, len(ts)
        m.end_ts = int(ts[-1]) + 60 if m.n else 0
        m._bars, m._views, m._days, m._nyday, m._mid = {}, {}, None, None, {}
        return m

    def cut(self, t: int) -> "Market":
        """The same market as known at t: only 1-minute bars opened at or before t - 60 (closed by t)."""
        k = int(np.searchsorted(self.ts, int(t) - 60, side="right"))
        return Market._from(self.ts[:k], {c: v[:k] for c, v in self.raw.items()})

    def mid(self, k: str) -> np.ndarray:
        if k not in self._mid:
            self._mid[k] = (self.raw[f"bid_{k}"] + self.raw[f"ask_{k}"]) / 2
        return self._mid[k]

    @property
    def nyday(self) -> np.ndarray:
        """The New York trading day (a date) of every minute."""
        if self._nyday is None:
            self._nyday = ny_days(self.ts)
        return self._nyday

    def _day_runs(self):
        """(first minute index, day) of each New York day, in time order (minutes are sorted, so days are runs)."""
        d = self.nyday
        if len(d) == 0:
            return np.zeros(0, dtype=np.int64), np.zeros(0, dtype=object)
        chg = np.r_[0, np.flatnonzero(d[1:] != d[:-1]) + 1].astype(np.int64)
        return chg, d[chg]

    def days(self) -> pd.DataFrame:
        """Mid daily bars by New York trading day (r45 daily_bars): day, o, h, l, c, n, start, end, atr20. Days with
        fewer than 100 minutes are dropped; ATR20 = the 20-day mean of the true range (the first day: high - low)."""
        if self._days is None:
            mo, mh, ml, mc = (self.mid(k) for k in "ohlc")
            first, day = self._day_runs()
            if len(first) == 0:
                self._days = pd.DataFrame(columns=["day", "o", "h", "l", "c", "n", "end", "start", "atr20"])
                return self._days
            last = np.r_[first[1:], len(mo)] - 1
            d = pd.DataFrame({"day": day, "o": mo[first], "h": np.maximum.reduceat(mh, first),
                              "l": np.minimum.reduceat(ml, first), "c": mc[last], "n": last - first + 1})
            d = d[d.n >= DAY_MIN_MINUTES].reset_index(drop=True)
            d["end"] = np.array([day_end_ts(x) for x in d.day], dtype=np.int64)
            d["start"] = np.array([day_start_ts(x) for x in d.day], dtype=np.int64)
            pc = d.c.shift(1)
            tr = np.maximum(d.h - d.l, np.maximum((d.h - pc).abs(), (d.l - pc).abs()))
            if len(tr):
                tr.iloc[0] = d.h.iloc[0] - d.l.iloc[0]
            d["atr20"] = tr.rolling(20).mean()
            self._days = d
        return self._days

    def bars(self, tf: str) -> Bars:
        """Mid bars: '1h', '30m', '15m', '5m', '3m' (clock-aligned UTC) or '4h' (six a New York day from 17:00 NY)."""
        if tf not in self._bars:
            mo, mh, ml, mc = (self.mid(k) for k in "ohlc")
            if tf in TFS:
                s = TFS[tf]
                key = self.ts // s * s
                self._bars[tf] = make_bars(self.ts, mo, mh, ml, mc, key, key + s)
            elif tf == "4h":
                first, day = self._day_runs()
                reps = np.diff(np.r_[first, self.n])
                st = np.repeat(np.array([day_start_ts(x) for x in day], dtype=np.int64), reps)
                en = np.repeat(np.array([day_end_ts(x) for x in day], dtype=np.int64), reps)
                key = st + (self.ts - st) // 14400 * 14400
                self._bars[tf] = make_bars(self.ts, mo, mh, ml, mc, key, np.minimum(key + 14400, en))
            else:
                raise ValueError(tf)
        return self._bars[tf]

    def view(self, side: int) -> "View":
        if side not in (-1, 1):
            raise ValueError("side is -1 (short) or +1 (long)")
        if side not in self._views:
            self._views[side] = View(self, side)
        return self._views[side]


class View:
    """The market as the short-side rules see it. side -1: prices as they are. side +1 (long): every price negated
    (highs become lows, the bid becomes the ask), so the short rules applied here are the long rules (s4 Mirror)."""

    def __init__(self, M: Market, side: int):
        self.M, self.side, self.ts = M, side, M.ts
        r = M.raw
        if side == -1:
            self.bid = {k: r[f"bid_{k}"] for k in "ohlc"}
            self.ask = {k: r[f"ask_{k}"] for k in "ohlc"}
        else:
            sw = {"o": "o", "h": "l", "l": "h", "c": "c"}
            self.bid = {k: -r[f"ask_{sw[k]}"] for k in "ohlc"}    # a buy fills on the ask: its mirror is a 'bid'
            self.ask = {k: -r[f"bid_{sw[k]}"] for k in "ohlc"}
        self.mid = {k: (self.bid[k] + self.ask[k]) / 2 for k in "ohlc"}
        self._c = {}

    def price(self, x):
        """A view price back to a real price."""
        if x is None:
            return None
        return x if self.side == -1 else -x

    def zone(self, lo, hi):
        """A view zone (lo <= hi) back to a real zone (low, high)."""
        if lo is None:
            return None
        return (lo, hi) if self.side == -1 else (-hi, -lo)

    def bars(self, tf: str) -> Bars:
        key = ("bars", tf)
        if key not in self._c:
            b = self.M.bars(tf)
            if self.side == -1:
                self._c[key] = b
            else:
                self._c[key] = Bars(-b.o, -b.l, -b.h, -b.c, b.t_open, b.t_end, b.first)
        return self._c[key]

    def days(self) -> dict:
        if "days" not in self._c:
            d = self.M.days()
            if self.side == -1:
                o, h, l, c = (d[k].to_numpy() for k in "ohlc")
            else:
                o, h, l, c = -d.o.to_numpy(), -d.l.to_numpy(), -d.h.to_numpy(), -d.c.to_numpy()
            self._c["days"] = {"day": d.day.to_numpy(), "o": o, "h": h, "l": l, "c": c,
                               "end": d.end.to_numpy(np.int64), "start": d.start.to_numpy(np.int64),
                               "atr20": d.atr20.to_numpy(float)}
        return self._c["days"]

    def swings(self, tf: str, n: int = SWING_N):
        key = ("sw", tf, n)
        if key not in self._c:
            b = self.bars(tf)
            self._c[key] = fractal_swings(b.h, b.l, n)
        return self._c[key]

    def swing_idx(self, tf: str, n: int, kind: str) -> np.ndarray:
        key = ("swi", tf, n, kind)
        if key not in self._c:
            sh, sl = self.swings(tf, n)
            self._c[key] = np.flatnonzero(sh if kind == "high" else sl)
        return self._c[key]

    def momentum(self, tf: str):
        key = ("mom", tf)
        if key not in self._c:
            self._c[key] = momentum_flags(self.bars(tf))
        return self._c[key]

    def fvgs(self, tf: str) -> dict:
        key = ("fvg", tf)
        if key not in self._c:
            self._c[key] = fvg_list(self.bars(tf))
        return self._c[key]

    def obs(self, tf: str) -> dict:
        key = ("ob", tf)
        if key not in self._c:
            self._c[key] = order_block_list(self.bars(tf), self.swings(tf, SWING_N)[1])
        return self._c[key]

    def blocks(self, tf: str) -> dict:
        """Rule 12 candles against this side: a bullish (in this view) momentum candle on tf that closes above the most
        recent swing high (2 bars) usable at its open, ending after 07:00 London and by 16:55 New York of its New York
        day. Returns {New York day: (end time, bar index)} for the FIRST such candle of each day."""
        key = ("blk", tf)
        if key not in self._c:
            b = self.bars(tf)
            _, bull = self.momentum(tf)
            sh = self.swing_idx(tf, SWING_N, "high")
            out = {}
            for k in np.flatnonzero(bull):
                j = int(np.searchsorted(sh, k - 3, side="right")) - 1          # swing s usable at k: s + 2 < k
                if j < 0 or not b.c[k] > b.h[sh[j]] + EPS:
                    continue
                te = int(b.t_end[k])
                d = ny_day_of(int(b.t_open[k]))
                if d in out:
                    continue
                if te > local_ts(d, R12_FROM_LONDON, LON) and te <= local_ts(d, EXPIRY_NY, NY):
                    out[d] = (te, int(k))
            self._c[key] = out
        return self._c[key]


# ---------------------------------------------------------------------------------------------------------- definitions
def c1_daily(V: View, t: int) -> dict:
    """C1 (rule 1): the daily wick rejection at t. Returns {'ticked': bool, ...} with W, Z and the touch bar."""
    D = V.days()
    H = V.bars("1h")
    nb = H.closed_by(t)
    kd = int(np.searchsorted(D["end"], int(t), side="right")) - 1
    for w in range(kd, max(kd - R1_DAYS, -1), -1):
        o, h, c, atr = D["o"][w], D["h"][w], D["c"][w], D["atr20"][w]
        U, B = h - max(o, c), abs(c - o)
        if not (U > B + EPS and np.isfinite(atr) and U >= R1_WICK_ATR * atr - EPS):
            continue
        zb, zt = max(o, c), h
        a = int(np.searchsorted(H.t_open, int(D["end"][w]), side="left"))    # 1h bars opened at or after W's end
        if nb <= a:
            continue
        idx = np.arange(a, nb)
        touch = idx[(H.t_open[a:nb] >= int(t) - R1_TOUCH_H * 3600) & (H.h[a:nb] >= zb - EPS)]
        if len(touch) == 0:
            continue
        if (H.c[a:nb] > zt + EPS).any():                                     # accepted above the zone: a real break
            continue
        if not H.c[nb - 1] < zb - EPS:                                       # not rejected
            continue
        return {"ticked": True, "W": D["day"][w], "W_end": int(D["end"][w]), "Z": (zb, zt),
                "touch_bar_open": int(H.t_open[touch[0]]), "touch_high": float(H.h[touch[0]])}
    return {"ticked": False}


def c2_4h(V: View, t: int) -> dict:
    """C2 (rule 2): the newest bearish 4h FVG with a momentum middle candle and c3 in the last 30 4h bars; ticked when a
    later 4h bar has traded to its top and the last 4h close is below the top."""
    B4 = V.bars("4h")
    nb = B4.closed_by(t)
    bear, _ = V.momentum("4h")
    for c3 in range(nb - 1, max(nb - R2_BARS, 2) - 1, -1):
        c1 = c3 - 2
        if not (B4.l[c1] - B4.h[c3] >= FVG_MIN_PIPS * PIP - EPS and bear[c3 - 1]):
            continue
        bottom, top = float(B4.h[c3]), float(B4.l[c1])
        later = np.arange(c3 + 1, nb)
        fill = later[B4.h[c3 + 1:nb] >= top - EPS]
        below = bool(B4.c[nb - 1] < top - EPS)
        return {"ticked": bool(len(fill) and below), "fvg": (bottom, top), "c3_open": int(B4.t_open[c3]),
                "filled_by_open": int(B4.t_open[fill[0]]) if len(fill) else None, "close_below": below}
    return {"ticked": False, "fvg": None}


def c3_lower_highs(V: View, t: int) -> dict:
    """C3 (rule 3): the last three usable 1h swing highs (5 bars each side) within 168 h, each lower; the last 1h close
    below the line through the last two (in 1h bar count)."""
    H = V.bars("1h")
    nb = H.closed_by(t)
    sh = V.swing_idx("1h", R3_N, "high")
    sh = sh[sh + R3_N < nb]
    if len(sh) < R3_HIGHS:
        return {"ticked": False, "highs": None}
    i1, i2, i3 = (int(x) for x in sh[-3:])
    highs = (float(H.h[i1]), float(H.h[i2]), float(H.h[i3]))
    times = (int(H.t_open[i1]), int(H.t_open[i2]), int(H.t_open[i3]))
    recent = all(x >= int(t) - R3_HOURS * 3600 for x in times)
    lower = highs[0] > highs[1] + EPS and highs[1] > highs[2] + EPS
    j = nb - 1
    line = highs[2] + (highs[2] - highs[1]) * (j - i3) / (i3 - i2)
    below = bool(H.c[j] < line - EPS)
    return {"ticked": bool(recent and lower and below), "highs": highs, "times": times, "line": float(line),
            "last_close": float(H.c[j])}


def floor_at(V: View, trig_tf: str, t0: int):
    """Rule 4: the highest unbroken double low at t0 (1h bars closed by t0), or None."""
    H = V.bars("1h")
    T = V.bars(trig_tf)
    nb = H.closed_by(t0)
    sl = V.swing_idx("1h", SWING_N, "low")
    hi = int(np.searchsorted(sl, nb - SWING_N - 1, side="right"))           # usable: i + 2 <= nb - 1
    lo = int(np.searchsorted(H.t_open[sl], int(t0) - R4_HOURS * 3600, side="left")) if len(sl) else 0
    cand = sl[lo:hi]
    if len(cand) < 2:
        return None
    j1 = T.closed_by(t0)
    best, bkey = None, None
    for ib in range(1, len(cand)):
        b = int(cand[ib])
        j0 = int(np.searchsorted(T.t_open, int(H.t_end[b]), side="left"))
        cmin = float(T.c[j0:j1].min()) if j1 > j0 else np.inf
        for ia in range(ib):
            a = int(cand[ia])
            la, lb = float(H.l[a]), float(H.l[b])
            if abs(la - lb) > R4_TOL_PIPS * PIP + EPS:
                continue
            F = min(la, lb)
            if b - a > 1 and float(H.l[a + 1:b].min()) < F - EPS:
                continue
            if cmin < F - EPS:
                continue
            key = (F, b, a)
            if bkey is None or key > bkey:
                bkey = key
                best = {"F": F, "zone_top": max(la, lb), "a": a, "b": b, "low_a": la, "low_b": lb,
                        "a_open": int(H.t_open[a]), "b_open": int(H.t_open[b])}
    return best


def pools_at(V: View, t0: int, t: int, F: float) -> dict:
    """Rule 5: untaken 1h swing lows more than 1.0 pip below F (usable by t0, within 120 h); L, Zb."""
    H = V.bars("1h")
    nb = H.closed_by(t0)
    sl = V.swing_idx("1h", SWING_N, "low")
    sl = sl[(sl + SWING_N < nb) & (H.t_open[sl] >= int(t0) - R5_HOURS * 3600) & (H.l[sl] < F - R5_MARGIN_PIPS * PIP - EPS)]
    ml, ts = V.mid["l"], V.ts
    k1 = int(np.searchsorted(ts, int(t) - 60, side="right"))
    pools = []
    for i in sl:
        k0 = int(np.searchsorted(ts, int(H.t_end[i]), side="left"))
        if k1 > k0 and float(ml[k0:k1].min()) < H.l[i] - EPS:
            continue
        pools.append((float(H.l[i]), int(H.t_open[i])))
    if not pools:
        return {"pools": [], "L": None, "Zb": None}
    L = max(p for p, _ in pools)
    Zb = min(p for p, _ in pools if p >= L - R5_CLUSTER_PIPS * PIP - EPS)
    return {"pools": sorted(pools), "L": L, "Zb": Zb}


def leg_at(V: View, t: int):
    """Rule 7: the leg top = the highest 1-minute mid high of the minutes opened in the 24 h before t; its earliest
    minute m_top. Returns (top, m_top) or None."""
    ts = V.ts
    i0 = int(np.searchsorted(ts, int(t) - LEG_HOURS * 3600, side="left"))
    i1 = int(np.searchsorted(ts, int(t) - 60, side="right"))
    if i1 <= i0:
        return None
    h = V.mid["h"][i0:i1]
    top = float(h.max())
    k = i0 + int(np.argmax(h >= top - EPS))
    return top, int(ts[k])


def entry_candidates(V: View, t: int, m_top: int, close: float) -> list:
    """Rule 7: untouched bearish FVGs on 30m, 15m, 5m from the leg's first bar, c3 closed by t, CE >= close + 2 pips;
    each with the 5m/3m order blocks it holds (rule 8)."""
    obs = {}
    for tf in OB_TFS:
        b = V.bars(tf)
        lb = b.holding(m_top)
        ob = V.obs(tf)
        sel = (ob["bar"] >= max(lb, 0)) & (b.t_end[ob["brk"]] <= int(t)) if len(ob["bar"]) else np.zeros(0, bool)
        obs[tf] = [(float(ob["low"][i]), float(ob["high"][i]), int(b.t_open[ob["bar"][i]]), int(b.t_end[ob["brk"][i]]))
                   for i in np.flatnonzero(sel)]
    out = []
    for tf in ENTRY_TFS:
        b = V.bars(tf)
        nb = b.closed_by(t)
        lb = b.holding(m_top)
        f = V.fvgs(tf)
        if lb < 0 or len(f["c3"]) == 0:
            continue
        a = int(np.searchsorted(f["c1"], lb, side="left"))
        z = int(np.searchsorted(f["c3"], nb - 1, side="right"))
        for i in range(a, z):
            c1, c3 = int(f["c1"][i]), int(f["c3"][i])
            bot, top = float(f["bottom"][i]), float(f["top"][i])
            if c3 + 1 < nb and float(b.h[c3 + 1:nb].max()) >= bot - EPS:
                continue                                                     # touched
            ce = (bot + top) / 2
            if ce < close + CE_MIN_PIPS * PIP - EPS:
                continue
            held = [(otf, x) for otf in OB_TFS for x in obs[otf] if x[0] <= top + EPS and x[1] >= bot - EPS]
            out.append({"tf": tf, "c1_open": int(b.t_open[c1]), "c3_open": int(b.t_open[c3]),
                        "c3_end": int(b.t_end[c3]), "bottom": bot, "top": top, "ce": ce, "obs": held})
    return out


def choose_fvg(cands: list, close: float, rule: str):
    """Rule 8: 'nearest' = holders of an order block first, then the smallest CE - close, ties 30m > 15m > 5m, then the
    later c3; 'tf30_first' = 30m, then 15m, then 5m; inside a timeframe holders first, then the nearest CE, ties later
    c3. Distances are compared at 1e-8 (so equal gaps on two timeframes tie)."""
    if not cands:
        return None
    if rule == "nearest":
        key = lambda x: (0 if x["obs"] else 1, round(x["ce"] - close, 8), TF_RANK[x["tf"]], -x["c3_end"])  # noqa: E731
    elif rule == "tf30_first":
        key = lambda x: (TF_RANK[x["tf"]], 0 if x["obs"] else 1, round(x["ce"] - close, 8), -x["c3_end"])  # noqa: E731
    else:
        raise ValueError(rule)
    return min(cands, key=key)


def order_plan(fvg: dict):
    """Rules 7, 9, 10 in the short view: P = CE rounded up; S = top + 1.5 pips, at least 5.0 pips away (moved out),
    rounded up; T = P - 3 (S - P) rounded to 0.00001. Returns (P, S, T, moved)."""
    P = tick(fvg["ce"], "up")
    S_raw = fvg["top"] + STOP_BUFFER_PIPS * PIP
    moved = S_raw - P < STOP_MIN_PIPS * PIP - EPS
    if moved:
        S_raw = P + STOP_MIN_PIPS * PIP
    S = tick(S_raw, "up")
    T = round(P - TARGET_R * (S - P), 5)
    return P, S, T, bool(moved)


def day_allows(classes: list) -> bool:
    """Section 7 on the day's closed main-book trades (+1 win, -1 loss, 0 breakeven, in order): after a win at most one
    more trade; a loss after a win ends the day; two losses end the day; breakeven exits are not counted."""
    wl = [x for x in classes if x != 0]
    if sum(1 for x in wl if x < 0) >= 2:
        return False
    if 1 in wl and len(wl) - 1 - wl.index(1) >= 1:
        return False
    return True


def tier_weight(score: int) -> float:
    return WEIGHTS.get(int(score), 0.0)


# ---------------------------------------------------------------------------------------------------------- decision
def trigger_bars(M: Market, tf: str, start=None, end=None) -> np.ndarray:
    """Indices of trigger-timeframe bars that open at or after 07:00 London and end by 16:00 London of their London
    date (Monday-Friday), with that date in [start, end]."""
    b = M.bars(tf)
    if b.n == 0:
        return np.zeros(0, dtype=np.int64)
    dates = _hour_dates(b.t_open, 0, LON)
    out = []
    lo = pd.Timestamp(start).date() if start is not None else None
    hi = pd.Timestamp(end).date() if end is not None else None
    cache = {}
    for k in range(b.n):
        d = dates[k]
        if d.weekday() >= 5 or (lo and d < lo) or (hi and d > hi):
            continue
        if d not in cache:
            cache[d] = (local_ts(d, TRIGGER_LONDON[0], LON), local_ts(d, TRIGGER_LONDON[1], LON))
        a, z = cache[d]
        if int(b.t_open[k]) >= a and int(b.t_end[k]) <= z:
            out.append(k)
    return np.array(out, dtype=np.int64)


def is_trigger(V: View, tf: str, k: int):
    """Rule 6 in this view: the bar closes below the floor chosen at its open and below its own open. Returns the floor
    dict when it triggers, else None."""
    b = V.bars(tf)
    if not b.c[k] < b.o[k] - EPS:
        return None
    fl = floor_at(V, tf, int(b.t_open[k]))
    if fl is None or not b.c[k] < fl["F"] - EPS:
        return None
    return fl


def decide(M: Market, variant, side: int, k: int, fl: dict = None) -> dict:
    """The decision of trigger bar k (of the variant's trigger timeframe) on one side, from bars closed by its end t.
    Returns a record (real prices). rec['void'] names the first failed step ('' when an order would be placed)."""
    v = variant_of(variant)
    V = M.view(side)
    tb = V.bars(v.trigger_tf)
    t0, t = int(tb.t_open[k]), int(tb.t_end[k])
    if fl is None:
        fl = is_trigger(V, v.trigger_tf, k)
    rec = {"variant": v.id, "side": side, "trigger_tf": v.trigger_tf, "k": int(k), "t0": t0, "t": t,
           "london_date": str(london_date_of(t0)), "ny_day": str(ny_day_of(t - 60)),
           "trigger_close": float(V.price(tb.c[k])), "m1": fl is not None, "void": ""}
    if fl is None:
        rec["void"] = "no_trigger"
        return rec
    bear, _ = V.momentum(v.trigger_tf)
    rec["trigger_momentum"] = bool(bear[k])
    rec.update({"F": V.price(fl["F"]), "floor_zone": V.zone(fl["F"], fl["zone_top"]),
                "floor_lows": (V.price(fl["low_a"]), V.price(fl["low_b"])), "floor_opens": (fl["a_open"], fl["b_open"])})
    day = ny_day_of(t - 60)
    blk = V.blocks(v.trigger_tf).get(day)
    if blk is not None and blk[0] <= t:
        rec["void"] = "blocked_r12"
        rec["block_end"] = blk[0]
        return rec
    # checks C1-C3
    c1, c2, c3 = c1_daily(V, t), c2_4h(V, t), c3_lower_highs(V, t)
    rec.update({"C1": c1["ticked"], "C2": c2["ticked"], "C3": c3["ticked"],
                "W": str(c1["W"]) if c1["ticked"] else None, "Z": V.zone(*c1["Z"]) if c1["ticked"] else None,
                "touch_bar_open": c1.get("touch_bar_open"),
                "fvg4h": V.zone(*c2["fvg"]) if c2.get("fvg") else None, "fvg4h_c3_open": c2.get("c3_open"),
                "fvg4h_filled_by": c2.get("filled_by_open"),
                "highs": tuple(V.price(x) for x in c3["highs"]) if c3.get("highs") else None,
                "highs_open": c3.get("times"), "trendline": V.price(c3["line"]) if "line" in c3 else None})
    rec["M3"] = bool(c1["ticked"] or c2["ticked"])
    # pools and zone (rule 5), leg (rule 7)
    po = pools_at(V, t0, t, fl["F"])
    rec.update({"pools": [V.price(p) for p, _ in po["pools"]], "L": V.price(po["L"]), "Zb": V.price(po["Zb"])})
    leg = leg_at(V, t)
    close = float(tb.c[k])
    if leg is None:
        rec["void"] = "no_fvg"
        rec["M2"] = False
        return rec
    rec.update({"leg_top": V.price(leg[0]), "leg_top_ts": leg[1]})
    cands = entry_candidates(V, t, leg[1], close)
    rec["n_candidates"] = len(cands)
    ch = choose_fvg(cands, close, v.fvg_choice)
    rec["M2"] = ch is not None
    if ch is None:
        rec["void"] = "no_fvg"
        return rec
    ob = None
    if ch["obs"]:
        otf, x = max(ch["obs"], key=lambda z: (z[1][3], -OB_TFS.index(z[0])))
        ob = {"tf": otf, "zone": V.zone(x[0], x[1]), "bar_open": x[2], "known": x[3]}
    rec.update({"fvg_tf": ch["tf"], "fvg": V.zone(ch["bottom"], ch["top"]), "fvg_ce": V.price(ch["ce"]),
                "fvg_c1_open": ch["c1_open"], "fvg_c3_open": ch["c3_open"], "ob": ob})
    P, S, T, moved = order_plan(ch)
    R_px = S - P
    rec.update({"P": V.price(P), "S": V.price(S), "T": V.price(T), "stop_moved": moved, "R_pips": R_px / PIP})
    if R_px > STOP_CAP_PIPS * PIP + EPS:
        rec["void"] = "stop_over_cap"
        return rec
    rec["M4"] = not (po["Zb"] is not None and T < po["Zb"] - EPS)
    if not rec["M4"]:
        rec["void"] = "target_past_zone"
        return rec
    rec["T_above_L"] = None if po["L"] is None else bool(T > po["L"] + EPS)
    if marketable(V, P, t):
        rec["void"] = "marketable"
        return rec
    rec["C4"] = bool(any(p < T - EPS for p, _ in po["pools"]))
    rec["C5"] = bool(ch["obs"])
    score = int(sum(bool(rec[c]) for c in ("C1", "C2", "C3", "C4", "C5")))
    rec["score"] = score
    rec["w"] = tier_weight(score) if rec["M3"] else 0.0
    rec["tier"] = {1.0: "full", 0.5: "half"}.get(rec["w"], "none")
    rec["book"] = "main" if (rec["M3"] and score >= 3) else "shadow"
    rec["shadow_reason"] = "" if rec["book"] == "main" else ("no_macro" if not rec["M3"] else "shadow")
    rec.update(gallery(V, t0, t, P))
    return rec


def marketable(V: View, P: float, t: int) -> bool:
    """Step 6 (r23_sim.limit_through_market): in this view a sell limit at P cannot rest when P is at or below the bid
    close of the last minute closed by t (a buy limit: at or above the ask close). No such minute: also refused."""
    kb = int(np.searchsorted(V.ts, int(t) - 60, side="right")) - 1
    return bool(kb < 0 or P <= V.bid["c"][kb] + EPS)


def gallery(V: View, t0: int, t: int, P: float) -> dict:
    """G1-G3 (report only)."""
    ts = V.ts
    day = ny_day_of(t - 60)
    i = int(np.searchsorted(ts, day_start_ts(day), side="left"))
    od = float(V.mid["o"][i]) if i < len(ts) and ny_day_of(int(ts[i])) == day else None
    g1 = bool(od is not None and P > od + EPS)
    ld = london_date_of(t0)
    a0, a1 = local_ts(ld, "00:00", LON), local_ts(ld, "07:00", LON)
    i0, i1 = int(np.searchsorted(ts, a0, side="left")), int(np.searchsorted(ts, a1, side="left"))
    asia = float(V.mid["h"][i0:i1].max()) if i1 > i0 else None
    D = V.days()
    kd = int(np.searchsorted(D["end"], day_start_ts(day), side="right")) - 1
    pdh = float(D["h"][kd]) if kd >= 0 else None
    j1 = int(np.searchsorted(ts, int(t) - 60, side="right"))
    run_hi = float(V.mid["h"][i1:j1].max()) if j1 > i1 else None
    g2 = bool(run_hi is not None and ((asia is not None and run_hi > asia + EPS) or (pdh is not None and run_hi > pdh + EPS)))
    hm = london_hhmm(t)
    g3 = any(a <= hm <= b for a, b in G3_WINDOWS)
    return {"G1": g1, "G2": g2, "G3": bool(g3), "day_open": V.price(od), "asia_extreme": V.price(asia),
            "prev_day_extreme": V.price(pdh)}


SIGNATURE = ("side", "t", "F", "floor_lows", "floor_opens", "W", "Z", "fvg4h", "fvg4h_c3_open", "highs", "highs_open",
             "pools", "L", "Zb", "leg_top", "leg_top_ts", "fvg_tf", "fvg", "ob", "C1", "C2", "C3", "C4", "C5", "score",
             "P", "S", "T", "void", "block_end")


TRADE_COLUMNS = (
    # what the trade is
    "variant", "side", "book", "london_date", "ny_day", "trigger_tf", "k", "t0", "t", "score", "w", "tier",
    "shadow_reason", "P", "S", "T", "R_pips", "stop_moved", "fvg_tf",
    # how it went
    "outcome", "cancel_ts", "f", "fill_ts", "exit_i", "exit_ts", "exit_reason", "exit_price", "exit_mid", "R_ba",
    "R_mid", "fin_pips", "R_20", "R_16", "wR_20", "wR_16", "end_ts",
    # the decision record
    "trigger_close", "m1", "void", "trigger_momentum", "F", "floor_zone", "floor_lows", "floor_opens", "C1", "C2", "C3",
    "W", "Z", "touch_bar_open", "fvg4h", "fvg4h_c3_open", "fvg4h_filled_by", "highs", "highs_open", "trendline", "M3",
    "pools", "L", "Zb", "leg_top", "leg_top_ts", "n_candidates", "M2", "fvg", "fvg_ce", "fvg_c1_open", "fvg_c3_open",
    "ob", "M4", "T_above_L", "C4", "C5", "G1", "G2", "G3", "day_open", "asia_extreme", "prev_day_extreme")


def signature(rec: dict) -> dict:
    """The fields the leak test compares (s9): side, W, Z, the 4h FVG, h1-h3, F and its two lows, the pools, L, Zb,
    the leg top, the chosen FVG and order block, the checks, the score, P, S, T (and the void)."""
    return {k: rec.get(k) for k in SIGNATURE}


# ---------------------------------------------------------------------------------------------------------- simulator
def _first(mask: np.ndarray) -> int:
    return int(np.argmax(mask)) if mask.any() else -1


def exit_scan(V: View, P: float, S: float, T: float, entry_mid: float, i_stop: int, i_tgt: int, e: int) -> dict:
    """Exits of a short (in this view) from 1-minute bars: the stop counts from minute i_stop, the target and the +2R
    stop-to-entry trigger from minute i_tgt, to minute e (exclusive; e = the first minute at or after 16:55 New York).
    P is the price the R is measured from (the limit, or the planned entry); entry_mid its mid. Returns the exit."""
    ah, al, ao, ac = V.ask["h"], V.ask["l"], V.ask["o"], V.ask["c"]
    mo, mc = V.mid["o"], V.mid["c"]
    R_px = S - P
    n = e - i_stop
    if n <= 0:
        raise ValueError("no minute to exit in")
    off = i_tgt - i_stop
    rng_al = al[i_tgt:e]
    kt = _first(rng_al <= T + EPS)
    kb = _first(rng_al <= P - BREAKEVEN_R * R_px + EPS)
    kt = kt + off if kt >= 0 else -1
    kb = kb + off if kb >= 0 else -1                                # index relative to i_stop
    hit_s = ah[i_stop:e] >= S - EPS
    ks1 = _first(hit_s)
    ks2 = -1
    if kb >= 0 and kb + 1 < n:
        k2 = _first(ah[i_stop + kb + 1:e] >= P - EPS)
        ks2 = kb + 1 + k2 if k2 >= 0 else -1
    if ks1 >= 0 and (kb < 0 or ks1 <= kb):
        ks, lvl = ks1, S
    elif ks2 >= 0:
        ks, lvl = ks2, P
    else:
        ks, lvl = -1, None
    if ks >= 0 and (kt < 0 or ks <= kt):
        i = i_stop + ks
        why = "stop" if lvl == S else "breakeven"
        return {"i": i, "fill": max(lvl, ao[i]) + SLIP, "mid": max(lvl, mo[i]), "why": why}
    if kt >= 0:
        i = i_stop + kt
        return {"i": i, "fill": T, "mid": T, "why": "target"}
    i = e - 1
    return {"i": i, "fill": ac[i] + SLIP, "mid": mc[i], "why": "time"}


def financing_pips(entry_ts: int, exit_ts: int, day_ends: np.ndarray, day_list) -> float:
    """r45 financing_pips: 1 pip per 17:00 New York close held over (3 on a Wednesday). Zero for every trade here."""
    k0 = int(np.searchsorted(day_ends, int(entry_ts), side="right"))
    k1 = int(np.searchsorted(day_ends, int(exit_ts), side="right"))
    return float(sum(FIN_WED_PIPS if pd.Timestamp(day_list[k]).weekday() == 2 else FIN_PIPS for k in range(k0, k1)))


def r_values(V: View, P: float, entry_fill: float, entry_mid: float, ex: dict, R_px: float, i_entry: int) -> dict:
    """R in the short view: R_ba from bid/ask fills, R_mid from mids, R_20 / R_16 after cost and financing."""
    D = V.days()
    fin = financing_pips(int(V.ts[i_entry]), int(V.ts[ex["i"]]), D["end"], D["day"])
    r_pips = R_px / PIP
    R_ba = (entry_fill - ex["fill"]) / R_px
    R_mid = (entry_mid - ex["mid"]) / R_px
    return {"R_ba": R_ba, "R_mid": R_mid, "fin_pips": fin,
            "R_20": min(R_mid - COSTS[0] / r_pips, R_ba) - fin / r_pips,
            "R_16": min(R_mid - COSTS[1] / r_pips, R_ba) - fin / r_pips}


def simulate_limit(M: Market, side: int, P: float, S: float, T: float, t_place: int, cancel_ts=None) -> dict:
    """A limit order in REAL prices placed at t_place, live until 16:55 New York of its day or cancel_ts; its fill
    and exit (s6). Returns {'status': 'filled' | 'expired' | 'cancelled', ...}."""
    V = M.view(side)
    s = 1 if side == -1 else -1
    Pv, Sv, Tv = s * P, s * S, s * T
    day = ny_day_of(int(t_place) - 60)
    exp = local_ts(day, EXPIRY_NY, NY)
    live_end = exp if cancel_ts is None else min(exp, int(cancel_ts))
    ts = V.ts
    i0 = int(np.searchsorted(ts, int(t_place), side="left"))
    i1 = int(np.searchsorted(ts, live_end, side="left"))
    f = _first(V.bid["h"][i0:i1] >= Pv - EPS) if i1 > i0 else -1
    if f < 0:
        st = "cancelled" if (cancel_ts is not None and int(cancel_ts) < exp) else "expired"
        return {"status": st, "end_ts": live_end}
    f += i0
    e = int(np.searchsorted(ts, exp, side="left"))
    ex = exit_scan(V, Pv, Sv, Tv, Pv, f, f + 1, e)
    R = r_values(V, Pv, Pv, Pv, ex, Sv - Pv, f)
    return {"status": "filled", "f": f, "fill_ts": int(ts[f]), "exit_i": ex["i"], "exit_ts": int(ts[ex["i"]]),
            "exit_reason": ex["why"], "exit_price": s * ex["fill"], "exit_mid": s * ex["mid"], **R,
            "end_ts": int(ts[ex["i"]]) + 60}


def twin_trade(M: Market, side: int, f: int, R_px: float) -> float:
    """Random-side twin (s11) of a trade on `side` filled in minute f: the OPPOSITE side enters at minute f's close
    (bid close for a short twin, ask close for a long one; mid entry = mid close); stop and 3R target placed from the
    mid entry with the same stop distance; stop to entry at +2R; exits from minute f + 1; 16:55 New York time exit;
    no entry slippage. Returns its R_20."""
    tw = -side
    V = M.view(tw)
    ts = V.ts
    day = ny_day_of(int(ts[f]))
    e = int(np.searchsorted(ts, local_ts(day, EXPIRY_NY, NY), side="left"))
    if f + 1 >= e:
        i = f
        fill, mid = V.bid["c"][f], V.mid["c"][f]
        ex = {"i": i, "fill": V.ask["c"][i] + SLIP, "mid": V.mid["c"][i], "why": "time"}
        return r_values(V, mid, fill, mid, ex, R_px, f)["R_20"]
    fill, mid = V.bid["c"][f], V.mid["c"][f]
    S, T = mid + R_px, mid - TARGET_R * R_px
    ex = exit_scan(V, mid, S, T, mid, f + 1, f + 1, e)
    return r_values(V, mid, fill, mid, ex, R_px, f)["R_20"]


def market_trade(M: Market, side: int, i: int, R_px: float, e: int) -> float:
    """Random-entry-time null (s11): a market entry on `side` at minute i's open (bid open for a short, ask open for a
    long; no slippage), stop and 3R target from the mid open, stop to entry at +2R, exits from minute i, time exit at
    minute e - 1. Returns its R_20."""
    V = M.view(side)
    fill, mid = V.bid["o"][i], V.mid["o"][i]
    ex = exit_scan(V, mid, mid + R_px, mid - TARGET_R * R_px, mid, i, i, e)
    return r_values(V, mid, fill, mid, ex, R_px, i)["R_20"]


def order_window(M: Market, rec: dict) -> tuple:
    """The random-entry-time window of a record (s11): minutes from t to the earlier of 16:55 New York and the end of
    the first rule-12 candle against its side after t. Returns (first minute, end minute) indices."""
    v = variant_of(rec["variant"])
    V = M.view(rec["side"])
    t = int(rec["t"])
    day = ny_day_of(t - 60)
    end = local_ts(day, EXPIRY_NY, NY)
    blk = V.blocks(v.trigger_tf).get(day)
    if blk is not None and blk[0] > t:
        end = min(end, blk[0])
    return int(np.searchsorted(V.ts, t, side="left")), int(np.searchsorted(V.ts, end, side="left"))


# ---------------------------------------------------------------------------------------------------------- engine
def run(m1, variant, start=None, end=None) -> tuple:
    """Run one variant over trigger bars with London dates in [start, end]. Returns (trades, records) DataFrames."""
    M = m1 if isinstance(m1, Market) else Market(m1)
    v = variant_of(variant)
    tb = M.bars(v.trigger_tf)
    ks = trigger_bars(M, v.trigger_tf, start, end)
    main_free, shadow_free = -1, -1
    day_classes = {}
    records = []
    for k in ks:
        k = int(k)
        trig = {}
        for side in (-1, 1):
            fl = is_trigger(M.view(side), v.trigger_tf, k)
            if fl is not None:
                trig[side] = fl
        if not trig:
            continue
        if len(trig) == 2:
            for side, fl in trig.items():
                r = decide(M, v, side, k, fl)
                r["void"] = "both_sides"
                records.append(r)
            continue
        side, fl = next(iter(trig.items()))
        rec = decide(M, v, side, k, fl)
        records.append(rec)
        if rec["void"]:
            continue
        t = int(rec["t"])
        day = rec["ny_day"]
        blk = M.view(side).blocks(v.trigger_tf).get(ny_day_of(t - 60))
        cancel = blk[0] if (blk is not None and blk[0] > t) else None
        rec["cancel_ts"] = cancel
        if rec["book"] == "main":
            if main_free > t:
                rec["void"] = "busy"
                continue
            if not day_allows(day_classes.get(day, [])):
                rec["void"] = "day_rules"
                continue
        else:
            if shadow_free > t:
                rec["void"] = "shadow_busy"
                continue
        sim = simulate_limit(M, side, rec["P"], rec["S"], rec["T"], t, cancel)
        rec["outcome"] = sim["status"]
        rec.update({k_: v_ for k_, v_ in sim.items() if k_ not in ("status",)})
        if rec["book"] == "main":
            main_free = sim["end_ts"]
            if sim["status"] == "filled":
                rm = sim["R_mid"]
                cls = 1 if rm > 1e-9 else (-1 if rm < -1e-9 else 0)
                day_classes.setdefault(day, []).append(cls)
        else:
            shadow_free = sim["end_ts"]
        if sim["status"] == "filled":
            main = rec["book"] == "main"                                # the shadow book is reported unweighted
            rec["wR_20"] = rec["w"] * sim["R_20"] if main else np.nan
            rec["wR_16"] = rec["w"] * sim["R_16"] if main else np.nan
    recs = pd.DataFrame(records)
    if len(recs) and "outcome" in recs and (recs.outcome == "filled").any():
        trades = recs[recs.outcome == "filled"].copy().reset_index(drop=True)
    else:                                       # nothing filled: an empty table that still has every trade column
        trades = recs.iloc[0:0].reindex(columns=list(dict.fromkeys([*TRADE_COLUMNS, *recs.columns]))).copy()
    return trades, recs


def summary(trades: pd.DataFrame) -> dict:
    """A short summary of the main book (weighted R at 2.0 and 1.6 pips)."""
    t = trades[trades.book == "main"] if len(trades) else trades
    if not len(t):
        return {"trades": 0}
    return {"trades": int(len(t)), "full": int((t.w == 1.0).sum()), "half": int((t.w == 0.5).sum()),
            "win_rate": float((t.exit_reason == "target").mean()), "mean_wR_20": float(t.wR_20.mean()),
            "total_wR_20": float(t.wR_20.sum()), "mean_wR_16": float(t.wR_16.mean()),
            "exits": t.exit_reason.value_counts().to_dict()}
