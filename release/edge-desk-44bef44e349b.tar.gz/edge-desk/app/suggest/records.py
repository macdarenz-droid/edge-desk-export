"""Record lines (B6, B7): every suggestion card and alert carries its rule's tested record, built from one template
per kind in records.json. Every number there names its source file; tests/test_records.py checks them."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

PATH = Path(__file__).with_name("records.json")
METHOD_END = "This rule lost."
LEAD_END = "Below the pass case. Paper. Not proven."


@lru_cache(maxsize=1)
def data() -> dict:
    return json.loads(PATH.read_text())


def _num(x: float, unit: str) -> str:
    if unit == "R":
        return f"{x:+.2f}R"
    return f"{x:+.1f} pips"


def _net(periods: list, unit: str) -> str:
    parts = []
    for i, p in enumerate(periods):
        n = _num(p["net"], unit)
        parts.append(f"{p['label']} {n} a trade ({p['trades']} trades)" if i == 0 else
                     f"{p['label']} {n} ({p['trades']})")
    return ", ".join(parts)


def _before(rule: dict) -> str:
    if any(p.get("before") is None for p in rule["periods"]):
        return rule["before_note"]
    return ", ".join(_num(p["before"], rule["unit"]) for p in rule["periods"])


def record_line(rule_id: str) -> str:
    d = data()
    rule = d["rules"][rule_id]
    tpl = d["templates"][rule["kind"]]
    return tpl.format(rule=rule_id, net=_net(rule["periods"], rule["unit"]), before=_before(rule),
                      p=f"{rule['p']:.3f}" if "p" in rule else "")


def check_line(rule_id: str, line: str) -> None:
    """ValueError unless the line holds every field its template requires: every period with its net and trade
    count, the before-cost item, and the kind's ending (with the timing p for a lead)."""
    rule = data()["rules"][rule_id]
    need = ["After 2.0 pips: ", "Before costs: " + _before(rule)]
    need += [f"{p['label']} {_num(p['net'], rule['unit'])}" for p in rule["periods"]]
    if len(rule["periods"]) < 3:
        raise ValueError(f"{rule_id}: the build period and each judging period are needed")
    if rule["kind"] == "method":
        need.append(METHOD_END)
        ok_end = line.endswith(METHOD_END)
    else:
        need += [f"Timing test p {rule['p']:.3f}", LEAD_END]
        ok_end = line.endswith(LEAD_END)
    miss = [n for n in need if n not in line]
    if miss or not ok_end:
        raise ValueError(f"{rule_id}: record line lacks {miss or ['its ending']}")


def rule_ids() -> list[str]:
    return list(data()["rules"])


def lead_ids() -> list[str]:
    return [k for k, v in data()["rules"].items() if v["kind"] == "lead"]
