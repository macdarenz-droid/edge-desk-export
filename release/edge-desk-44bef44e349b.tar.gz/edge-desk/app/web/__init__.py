"""The Edge Desk web server (server.py), its JSON API (api.py) and login (auth.py). Screens live in static/."""
