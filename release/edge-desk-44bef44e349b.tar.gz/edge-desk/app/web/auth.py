"""Who may use the API.

Dashboard: POST /api/login {"token"} with EDGE_DASHBOARD_TOKEN sets an HttpOnly, SameSite=Strict, Path=/
cookie holding "<issued>.<hex hmac_sha256(dashboard_token, issued)>", valid 30 days (Secure over HTTPS, behind
a trusted proxy unless EDGE_COOKIE_SECURE=0, or when EDGE_COOKIE_SECURE=1). Rotating EDGE_DASHBOARD_TOKEN ends
every session; so does logout: it raises a stored "sessions valid after" time, so a copied cookie stops
working too (every device logs in again).
At most 5 failed logins per minute per client address; more get 429. A try is counted before its body is
read, so tries sent at the same moment cannot slip past the limit; a right token gives its slot back.
X-Forwarded-For is trusted only from the addresses in EDGE_TRUSTED_PROXY (the reverse proxy in front, comma
separated): then the limit follows the right-most forwarded address (the one the proxy saw), so a stranger's
bad tries do not lock the owner out. Without EDGE_TRUSTED_PROXY every client behind a proxy shares the
proxy's address and the limit covers everyone together (stricter, never looser).
Bridge: "Authorization: Bearer <EDGE_INGEST_TOKEN>".
Every compare is constant time (hmac.compare_digest over SHA-256 digests, so the length leaks nothing).
A missing secret closes its surface (the server answers 503 "not configured"); nothing is open by default.
"""
from __future__ import annotations

import hashlib
import hmac
import ipaddress
import threading
from collections import deque
from http.cookies import CookieError, SimpleCookie

COOKIE_NAME = "edge_session"
SESSION_TTL_S = 30 * 86400
CLOCK_SKEW_S = 60                 # a cookie issued up to a minute "in the future" is still fine
LOGIN_FAILS_PER_WINDOW = 5
LOGIN_WINDOW_S = 60


def token_equal(given: str | None, expected: str | None) -> bool:
    if not given or not expected or not isinstance(given, str) or not isinstance(expected, str):
        return False
    a = hashlib.sha256(given.encode("utf-8", "surrogatepass")).digest()
    b = hashlib.sha256(expected.encode("utf-8")).digest()
    return hmac.compare_digest(a, b)


def _mac(token: str, issued: int) -> str:
    return hmac.new(token.encode("utf-8"), str(issued).encode("ascii"), hashlib.sha256).hexdigest()


def sign_session(token: str, issued: int) -> str:
    return f"{int(issued)}.{_mac(token, int(issued))}"


def _digits(text: str) -> bool:
    """ASCII digits only: str.isdigit() is also True for '²' or Arabic-Indic digits, which int() refuses."""
    return text.isascii() and text.isdigit()


def verify_session(token: str | None, value: str | None, now_s: float, valid_after: int = 0) -> bool:
    """valid_after: sessions issued at or before this time (the last logout) are over."""
    if not token or not value or not isinstance(value, str) or value.count(".") != 1:
        return False
    issued_text, mac = value.split(".")
    if not _digits(issued_text) or len(issued_text) > 12 or len(mac) != 64:
        return False
    issued = int(issued_text)
    if issued > now_s + CLOCK_SKEW_S or now_s - issued >= SESSION_TTL_S or issued <= valid_after:
        return False
    return hmac.compare_digest(mac.encode("ascii", "replace"), _mac(token, issued).encode("ascii"))


def bearer_ok(header: str | None, token: str | None) -> bool:
    if not header or not token or not header.startswith("Bearer "):
        return False
    return token_equal(header[len("Bearer "):].strip(), token)


def read_cookie(header: str | None) -> str | None:
    if not header:
        return None
    try:
        jar = SimpleCookie()
        jar.load(header)
    except CookieError:
        return None
    morsel = jar.get(COOKIE_NAME)
    return morsel.value if morsel else None


def session_cookie(value: str, secure: bool) -> str:
    parts = [f"{COOKIE_NAME}={value}", "HttpOnly", "SameSite=Strict", "Path=/", f"Max-Age={SESSION_TTL_S}"]
    if secure:
        parts.append("Secure")
    return "; ".join(parts)


def clear_cookie(secure: bool) -> str:
    parts = [f"{COOKIE_NAME}=", "HttpOnly", "SameSite=Strict", "Path=/", "Max-Age=0"]
    if secure:
        parts.append("Secure")
    return "; ".join(parts)


def cookie_secure(tls: bool, env, behind_proxy: bool = False) -> bool:
    """Secure over our own TLS, when EDGE_COOKIE_SECURE=1, or behind a trusted proxy (which serves HTTPS)
    unless EDGE_COOKIE_SECURE=0."""
    flag = (env or {}).get("EDGE_COOKIE_SECURE", "").strip()
    return bool(tls) or flag == "1" or (behind_proxy and flag != "0")


def trusted_proxies(env) -> frozenset:
    """EDGE_TRUSTED_PROXY: comma-separated addresses of the reverse proxy in front (empty: none)."""
    out = set()
    for part in ((env or {}).get("EDGE_TRUSTED_PROXY") or "").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            out.add(ipaddress.ip_address(part))
        except ValueError:
            raise ValueError("EDGE_TRUSTED_PROXY must list IP addresses, comma separated") from None
    return frozenset(out)


def client_key(peer: str, forwarded: list[str] | None, proxies: frozenset) -> str:
    """The address the login limit is kept for. The peer, unless the peer is a trusted proxy: then the
    right-most X-Forwarded-For entry (the address that proxy saw; entries to its left are the client's word).
    A missing or malformed entry keeps the proxy's address (all such clients share one limit)."""
    try:
        if not proxies or ipaddress.ip_address(peer) not in proxies:
            return peer
    except ValueError:
        return peer
    entries = [e.strip() for line in (forwarded or []) for e in str(line).split(",")]
    if not entries or not entries[-1]:
        return peer
    try:
        return str(ipaddress.ip_address(entries[-1]))
    except ValueError:
        return peer


class LoginLimiter:
    """Failed logins per client address in a sliding window (thread safe)."""

    def __init__(self, max_fails: int = LOGIN_FAILS_PER_WINDOW, window_s: float = LOGIN_WINDOW_S):
        self.max_fails = max_fails
        self.window_s = window_s
        self._fails: dict[str, deque] = {}
        self._lock = threading.Lock()

    def _trim(self, ip: str, now_s: float) -> deque:
        q = self._fails.setdefault(ip, deque())
        while q and now_s - q[0] >= self.window_s:
            q.popleft()
        return q

    def blocked(self, ip: str, now_s: float) -> bool:
        with self._lock:
            q = self._trim(ip, now_s)
            if not q:
                self._fails.pop(ip, None)
                return False
            return len(q) >= self.max_fails

    def reserve(self, ip: str, now_s: float) -> bool:
        """Count a try before its body is read (atomic check-and-count). False: over the limit, refuse it.
        A wrong try keeps its slot; a right one gives it back with release()."""
        with self._lock:
            q = self._trim(ip, now_s)
            if len(q) >= self.max_fails:
                return False
            q.append(now_s)
            self._forget_idle(now_s)
            return True

    def release(self, ip: str, now_s: float) -> None:
        with self._lock:
            q = self._fails.get(ip)
            if q:
                try:
                    q.remove(now_s)
                except ValueError:
                    pass
                if not q:
                    self._fails.pop(ip, None)

    def _forget_idle(self, now_s: float) -> None:
        if len(self._fails) > 10_000:          # bound memory: forget addresses with nothing recent
            for key in [k for k, v in self._fails.items() if not v or now_s - v[-1] >= self.window_s]:
                del self._fails[key]

    def fail(self, ip: str, now_s: float) -> None:
        with self._lock:
            self._trim(ip, now_s).append(now_s)
            self._forget_idle(now_s)

    def retry_after(self, ip: str, now_s: float) -> int:
        with self._lock:
            q = self._trim(ip, now_s)
            if len(q) < self.max_fails:
                return 0
            return max(1, int(q[-self.max_fails] + self.window_s - now_s + 0.999))
