#!/usr/bin/env python3
"""Draws the Edge Desk app icons from icon.svg. Pure Python: standard library only (xml, math, zlib, struct).
No ImageMagick and no Pillow, so the same PNGs come out on any machine.

    python3 app/web/static/icons/make_icons.py             # writes the PNGs next to this file
    python3 app/web/static/icons/make_icons.py --out DIR   # writes them to DIR (tests/test_pwa.py compares)

Read from icon.svg: the <path d="..."> data (M, L, H, V, A and Z, absolute or relative; arcs must be circular),
the stroke colour and width, and the background <rect> fill. The layout of each PNG is set here (LAYOUT):

  icon-192.png, icon-512.png   opaque, glyph 64 % of the width, centred        (manifest, purpose "any")
  icon-maskable-512.png        opaque, glyph 56 % of the width, well inside the 40 % safe circle ("maskable")
  apple-touch-icon.png         opaque, 180 x 180, glyph 64 % (iOS rounds the corners itself)
  badge-96.png                 white glyph on transparent, 86 % (Android's status bar badge)

Strokes have round caps and joins, like the brand mark. Edges are antialiased from the exact distance of each
pixel centre to the lines and arcs. Nothing is animated: one still frame per file, no time stamp chunk.
"""
from __future__ import annotations

import argparse
import math
import re
import struct
import xml.etree.ElementTree as ET
import zlib
from dataclasses import dataclass
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "icon.svg"
WHITE = (255, 255, 255)
TAU = 2 * math.pi

# file name: (size in px, glyph width as a share of the size, opaque background?)
LAYOUT = {
    "icon-192.png": (192, 0.64, True),
    "icon-512.png": (512, 0.64, True),
    "icon-maskable-512.png": (512, 0.56, True),
    "apple-touch-icon.png": (180, 0.64, True),
    "badge-96.png": (96, 0.86, False),
}


@dataclass(frozen=True)
class Source:
    shapes: list            # ("line", x1, y1, x2, y2) | ("arc", cx, cy, r, start, sweep, (x1, y1), (x2, y2))
    stroke: tuple
    stroke_width: float
    background: tuple


# ----------------------------------------------------------------------------- reading the svg


def _colour(value: str | None) -> tuple:
    m = re.fullmatch(r"#([0-9a-fA-F]{6})", (value or "").strip())
    if not m:
        raise ValueError(f"colour must be #rrggbb, got {value!r}")
    h = m.group(1)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


_NUM = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")


class _PathReader:
    def __init__(self, d: str) -> None:
        self.d, self.i = d, 0

    def _skip(self) -> None:
        while self.i < len(self.d) and self.d[self.i] in " \t\r\n,":
            self.i += 1

    def done(self) -> bool:
        self._skip()
        return self.i >= len(self.d)

    def command(self) -> str | None:
        self._skip()
        c = self.d[self.i]
        if c.isalpha():
            self.i += 1
            return c
        return None

    def num(self) -> float:
        self._skip()
        m = _NUM.match(self.d, self.i)
        if not m:
            raise ValueError(f"number expected at {self.i} in path {self.d!r}")
        self.i = m.end()
        return float(m.group(0))

    def flag(self) -> bool:
        self._skip()
        c = self.d[self.i:self.i + 1]
        if c not in ("0", "1"):
            raise ValueError(f"arc flag expected at {self.i} in path {self.d!r}")
        self.i += 1
        return c == "1"


def _in_sweep(angle: float, start: float, sweep: float) -> bool:
    rel = (angle - start) % TAU if sweep > 0 else (start - angle) % TAU
    return rel <= abs(sweep) + 1e-12


def _arc(x1, y1, rx, ry, large, sweep, x2, y2):
    """SVG endpoint arc -> centre form (SVG 1.1, appendix F.6.5), circles only."""
    if (x1, y1) == (x2, y2):
        return None
    if rx == 0 or ry == 0:
        return ("line", x1, y1, x2, y2)
    if abs(abs(rx) - abs(ry)) > 1e-9:
        raise ValueError("only circular arcs are supported")
    r = abs(rx)
    hx, hy = (x1 - x2) / 2, (y1 - y2) / 2
    lam = (hx * hx + hy * hy) / (r * r)
    if lam > 1:
        r *= math.sqrt(lam)
    coef = math.sqrt(max(0.0, (r * r - hx * hx - hy * hy) / (hx * hx + hy * hy)))
    if large == sweep:
        coef = -coef
    cx, cy = coef * hy + (x1 + x2) / 2, -coef * hx + (y1 + y2) / 2
    start = math.atan2(y1 - cy, x1 - cx)
    delta = math.atan2(y2 - cy, x2 - cx) - start
    if sweep and delta < 0:
        delta += TAU
    elif not sweep and delta > 0:
        delta -= TAU
    return ("arc", cx, cy, r, start, delta, (x1, y1), (x2, y2))


def parse_path(d: str) -> list:
    rd, shapes = _PathReader(d), []
    x = y = sx = sy = 0.0
    cmd = None
    while not rd.done():
        c = rd.command()
        if c is not None:
            cmd = c
        elif cmd is None or cmd in "Zz":
            raise ValueError(f"command expected in path {d!r}")
        elif cmd == "M":
            cmd = "L"            # more pairs after a move are lines
        elif cmd == "m":
            cmd = "l"
        rel, up = cmd.islower(), cmd.upper()
        if up == "Z":
            if (x, y) != (sx, sy):
                shapes.append(("line", x, y, sx, sy))
            x, y = sx, sy
        elif up == "M":
            nx, ny = rd.num(), rd.num()
            x, y = (x + nx, y + ny) if rel else (nx, ny)
            sx, sy = x, y
        elif up in "LHV":
            if up == "L":
                nx, ny = rd.num(), rd.num()
                nx, ny = (x + nx, y + ny) if rel else (nx, ny)
            elif up == "H":
                nx, ny = rd.num() + (x if rel else 0.0), y
            else:
                nx, ny = x, rd.num() + (y if rel else 0.0)
            shapes.append(("line", x, y, nx, ny))
            x, y = nx, ny
        elif up == "A":
            rx, ry, _rot = rd.num(), rd.num(), rd.num()
            large, sweep = rd.flag(), rd.flag()
            nx, ny = rd.num(), rd.num()
            nx, ny = (x + nx, y + ny) if rel else (nx, ny)
            arc = _arc(x, y, rx, ry, large, sweep, nx, ny)
            if arc:
                shapes.append(arc)
            x, y = nx, ny
        else:
            raise ValueError(f"path command {cmd!r} is not supported (M L H V A Z only)")
    return shapes


def read_source(path: Path = SOURCE) -> Source:
    root = ET.parse(path).getroot()
    found = {"shapes": [], "stroke": None, "width": None, "bg": None}

    def walk(el, inherited: dict) -> None:
        attrs = dict(inherited)
        for key in ("stroke", "stroke-width"):
            if key in el.attrib:
                attrs[key] = el.attrib[key]
        tag = el.tag.rsplit("}", 1)[-1]
        if tag == "rect" and found["bg"] is None:
            found["bg"] = _colour(el.attrib.get("fill"))
        if tag == "path":
            found["shapes"] += parse_path(el.attrib.get("d", ""))
            found["stroke"] = _colour(attrs.get("stroke"))
            found["width"] = float(attrs.get("stroke-width", "1"))
        for child in el:
            walk(child, attrs)

    walk(root, {})
    if not found["shapes"] or found["bg"] is None:
        raise ValueError(f"{path}: needs a background <rect> and at least one <path>")
    return Source(found["shapes"], found["stroke"], found["width"], found["bg"])


# ----------------------------------------------------------------------------- drawing


def _bbox(shapes: list) -> tuple:
    pts = []
    for s in shapes:
        if s[0] == "line":
            pts += [(s[1], s[2]), (s[3], s[4])]
        else:
            _, cx, cy, r, start, sweep, p1, p2 = s
            pts += [p1, p2]
            for k in range(4):
                a = k * math.pi / 2
                if _in_sweep(a, start, sweep):
                    pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _seg_dist(px, py, x1, y1, x2, y2) -> float:
    dx, dy = x2 - x1, y2 - y1
    ll = dx * dx + dy * dy
    t = 0.0 if ll == 0 else max(0.0, min(1.0, ((px - x1) * dx + (py - y1) * dy) / ll))
    return math.hypot(px - x1 - t * dx, py - y1 - t * dy)


def _arc_dist(px, py, cx, cy, r, start, sweep, p1, p2) -> float:
    if _in_sweep(math.atan2(py - cy, px - cx), start, sweep):
        return abs(math.hypot(px - cx, py - cy) - r)
    return min(math.hypot(px - p1[0], py - p1[1]), math.hypot(px - p2[0], py - p2[1]))


def render(src: Source, size: int, share: float) -> list:
    """Coverage (0..1) of every pixel, row by row: the glyph scaled to `share` of the width and centred."""
    half = src.stroke_width / 2
    x0, y0, x1, y1 = _bbox(src.shapes)
    x0, y0, x1, y1 = x0 - half, y0 - half, x1 + half, y1 + half
    k = share * size / (x1 - x0)
    ox, oy = size / 2 - (x0 + x1) / 2 * k, size / 2 - (y0 + y1) / 2 * k
    rad = half * k
    cov = [0.0] * (size * size)
    for s in src.shapes:
        if s[0] == "line":
            ax, ay, bx, by = s[1] * k + ox, s[2] * k + oy, s[3] * k + ox, s[4] * k + oy
            lo_x, hi_x, lo_y, hi_y = min(ax, bx), max(ax, bx), min(ay, by), max(ay, by)

            def dist(px, py, ax=ax, ay=ay, bx=bx, by=by):
                return _seg_dist(px, py, ax, ay, bx, by)
        else:
            _, cx, cy, r, start, sweep, p1, p2 = s
            bx0, by0, bx1, by1 = _bbox([s])
            lo_x, lo_y, hi_x, hi_y = bx0 * k + ox, by0 * k + oy, bx1 * k + ox, by1 * k + oy
            arc = (cx * k + ox, cy * k + oy, r * k, start, sweep, (p1[0] * k + ox, p1[1] * k + oy),
                   (p2[0] * k + ox, p2[1] * k + oy))

            def dist(px, py, arc=arc):
                return _arc_dist(px, py, *arc)
        xa, xb = max(0, int(lo_x - rad - 1)), min(size - 1, int(hi_x + rad + 1))
        ya, yb = max(0, int(lo_y - rad - 1)), min(size - 1, int(hi_y + rad + 1))
        for py in range(ya, yb + 1):
            row = py * size
            for px in range(xa, xb + 1):
                a = rad + 0.5 - dist(px + 0.5, py + 0.5)
                if a > 0:
                    a = 1.0 if a >= 1 else a
                    if a > cov[row + px]:
                        cov[row + px] = a
    return cov


def encode_png(size: int, cov: list, fg: tuple, bg: tuple | None) -> bytes:
    """8-bit PNG: RGB blended over `bg`, or RGBA (fg with coverage as alpha) when bg is None."""
    raw = bytearray()
    for y in range(size):
        raw.append(0)                     # filter: none
        for a in cov[y * size:(y + 1) * size]:
            if bg is None:
                raw += bytes((*fg, int(a * 255 + 0.5)))
            else:
                raw += bytes(int(b + (f - b) * a + 0.5) for f, b in zip(fg, bg))

    def chunk(kind: bytes, body: bytes) -> bytes:
        return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", size, size, 8, 6 if bg is None else 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) +
            chunk(b"IEND", b""))


def main(argv: list | None = None) -> int:
    ap = argparse.ArgumentParser(description="Draw the Edge Desk icons from icon.svg (pure Python).")
    ap.add_argument("--out", type=Path, default=HERE, help="output folder (default: next to this script)")
    ap.add_argument("--svg", type=Path, default=SOURCE, help="icon source (default: icon.svg next to this script)")
    args = ap.parse_args(argv)
    src = read_source(args.svg)
    args.out.mkdir(parents=True, exist_ok=True)
    for name, (size, share, opaque) in LAYOUT.items():
        cov = render(src, size, share)
        data = encode_png(size, cov, src.stroke if opaque else WHITE, src.background if opaque else None)
        (args.out / name).write_bytes(data)
        print(f"{name} {size}x{size}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
