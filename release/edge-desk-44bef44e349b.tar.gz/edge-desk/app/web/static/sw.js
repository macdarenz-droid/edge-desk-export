/* Edge Desk service worker: shows the app's own phone alerts (Web Push) and opens the right screen on a tap.
   It has no network handler and stores nothing, so every screen always reads fresh data from the server.
   No timers; alerts follow the phone's own sound settings. Served at /sw.js so its scope is the whole app ("/"). */
"use strict";

var ICON = "/static/icons/icon-192.png";
var BADGE = "/static/icons/badge-96.png";
var APP = "Edge Desk";

function text(x, max) { return typeof x === "string" ? x.slice(0, max) : ""; }

/* The mark in front of the title that alerts showed before the move to Web Push (emoji short codes): hard
   incidents carry the tag "warning", rule breaks "triangular_flag_on_post". Any other tag adds nothing. */
var MARKS = { warning: "\u26A0\uFE0F", triangular_flag_on_post: "\uD83D\uDEA9" };

function marked(title, tags) {
  if (!Array.isArray(tags)) return title;
  var marks = [];
  for (var i = 0; i < tags.length && i < 5; i++) {
    var t = tags[i];
    if (typeof t === "string" && Object.prototype.hasOwnProperty.call(MARKS, t) && marks.indexOf(MARKS[t]) < 0) {
      marks.push(MARKS[t]);
    }
  }
  return marks.length ? marks.join(" ") + " " + title : title;
}

/* Priority 1-5 like the alert queue; anything else counts as 3 (normal). */
function priorityOf(x) {
  var p = typeof x === "number" ? x : Number(x);
  if (!isFinite(p)) return 3;
  return Math.max(1, Math.min(5, Math.round(p)));
}

/* Only a path on this app ("/#live"); a full address or "//host" opens the app's start page instead. */
function appPath(u) {
  if (typeof u !== "string" || u.charAt(0) !== "/" || u.charAt(1) === "/" || u.indexOf("\\") >= 0) return "/";
  return u;
}

function payload(data) {
  if (!data) return {};
  try {
    var d = data.json();
    return d !== null && typeof d === "object" && !Array.isArray(d) ? d : {};
  } catch (e) {
    try { return { body: data.text() }; } catch (e2) { return {}; }
  }
}

self.addEventListener("install", function () {
  self.skipWaiting();
});

self.addEventListener("activate", function (event) {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("push", function (event) {
  var d = payload(event.data), p = priorityOf(d.priority);
  var title = marked(text(d.title, 200) || APP, d.tags);
  event.waitUntil(self.registration.showNotification(title, {
    body: text(d.body, 3000),
    tag: text(d.key, 200),
    data: { url: appPath(d.url) },
    icon: ICON,
    badge: BADGE,
    requireInteraction: p >= 5,
    silent: p <= 2
  }));
});

self.addEventListener("notificationclick", function (event) {
  event.notification.close();
  var data = event.notification.data || {};
  var target = new URL(appPath(data.url), self.location.origin).href;
  event.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(function (list) {
    for (var i = 0; i < list.length; i++) {
      var c = list[i];
      if (new URL(c.url).origin === self.location.origin && typeof c.focus === "function") {
        return c.focus().then(function (w) {
          var win = w || c;
          if (typeof win.navigate !== "function") return win;
          return win.navigate(target).catch(function () { return win; });
        }, function () {
          return self.clients.openWindow(target);
        });
      }
    }
    return self.clients.openWindow(target);
  }));
});
