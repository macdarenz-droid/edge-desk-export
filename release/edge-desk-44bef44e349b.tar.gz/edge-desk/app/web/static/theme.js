/* Sets the saved theme before the page paints, so a light choice never shows dark first. */
(function () {
  "use strict";
  try {
    var t = window.localStorage.getItem("edgedesk:theme");
    if (t === "dark" || t === "light") document.documentElement.setAttribute("data-theme", t);
  } catch (e) { /* storage blocked: the system theme applies */ }
})();
