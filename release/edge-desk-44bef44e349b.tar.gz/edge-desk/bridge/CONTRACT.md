# Edge Bridge contract: `edge-bridge/1`

The bridge is a small MT5 Expert Advisor (`bridge/EdgeBridge.mq5`). It runs in a desktop MT5 terminal on
a Windows VPS, logged in with the **investor (read-only) password**. Every few seconds, and on every trade
event, it reads the account, open positions, pending orders and new closed deals, and POSTs them as JSON
to the Edge Desk app.

**It cannot trade.** The EA has no order functions, no trade library, no DLLs, no imports and never
writes files. `tests/test_bridge_ea_static.py` scans the source on every test run to keep it that way.
The app side (`app/ingest/`) only stores what it receives.

## Request

```
POST /api/bridge/v1/snapshot
Authorization: Bearer <ingest token>
Content-Type: application/json
```

Body: one JSON object. **Every key is required. Any key not listed here is refused (400).**

```
{"contract":"edge-bridge/1", "bridge_session":"<16 lowercase hex>", "seq":<int >= 0>,
 "reason":"init|timer|trade", "server_time":<int>, "gmt_time":<int>,
 "account":{"alias":"main", "currency":"USD", "company":"<broker name>", "balance":<num>,
            "equity":<num>, "profit":<num>, "margin":<num>, "margin_free":<num>,
            "trade_mode":"demo|contest|real", "trade_allowed":<bool>, "trade_expert":<bool>},
 "terminal":{"build":<int>, "trade_allowed":<bool>, "connected":<bool>},
 "symbols":{"EURUSD":{"digits":5, "point":0.00001, "tick_size":0.00001, "tick_value":1.0,
            "contract_size":100000, "volume_min":0.01, "volume_step":0.01, "volume_max":<num>,
            "stops_level":<int points>, "spread":<int points>, "bid":<num>, "ask":<num>}},
 "positions":[{"ticket":"<str>", "position_id":"<str>", "symbol":"EURUSD", "side":"buy|sell",
               "volume":<num>, "open_price":<num>, "open_time":<int>, "price":<num>,
               "sl":<num|null>, "tp":<num|null>, "profit":<num>, "swap":<num>, "magic":<int>,
               "comment":"<str>"}],
 "orders":[{"ticket":"<str>", "symbol":"EURUSD",
            "type":"buy_limit|sell_limit|buy_stop|sell_stop|buy_stop_limit|sell_stop_limit|buy|sell|other",
            "volume":<num>, "price":<num>, "sl":<num|null>, "tp":<num|null>, "setup_time":<int>,
            "expiration":<int|null>}],
 "deals":[{"deal":"<str>", "order":"<str>", "position_id":"<str>", "symbol":"<str>",
           "type":"buy|sell|balance|credit|charge|correction|bonus|commission|interest|other",
           "entry":"in|out|inout|out_by|none", "volume":<num>, "price":<num>, "time":<int>,
           "profit":<num>, "commission":<num>, "swap":<num>, "fee":<num>,
           "reason":"client|mobile|web|expert|sl|tp|so|rollover|vmargin|split|other",
           "sl":<num|null>, "tp":<num|null>, "magic":<int>}],
 "deals_from":<int>}
```

Field rules:

| Rule | Detail |
|---|---|
| Times | Integer **trade-server** epoch seconds (MT5 `datetime`), except `gmt_time` = UTC epoch from `TimeGMT()`. Range 2000-01-01 to 2100-01-01. |
| Tickets | Strings of digits, up to 2^64 - 1 (64-bit safe). |
| Stops | MT5 reports "no stop" as 0; the contract sends `null`. 0 or a negative stop is refused. |
| Numbers | Finite and within +-1e12. A bool is never accepted as a number, an integer field refuses 1.0. Money is sent with 8 decimals (never rounded to the account's currency digits). |
| Symbols | `symbols` holds every symbol used by positions, orders and buy/sell deals, plus the EUR/USD name. A 0 in tick size, tick value or prices means "not known yet". |
| Deals | `entry` is `none` for balance operations (they carry an empty symbol and position `"0"`). A deal's `sl`/`tp`: on an entry, the order's stop and target; on an exit, the position's stop and target at the moment it closed (so a stop moved to entry is detected). |
| Caps | positions 200, orders 200, deals 500, symbols 64; symbol 32 chars, company 128, comment 128; body `bridge.max_payload_bytes`. |
| Alias | `account.alias` must equal config `account.alias`, otherwise 400 "unknown account alias". |
| Account | `account.currency` must equal config `account.currency`; `account.company` and `account.trade_mode` must match what this alias sent before. Otherwise 400 and nothing is stored: another account logged in under the same alias is never merged into the journal. Use a new alias for another account. |
| Connected | `terminal.connected` false is refused (400, nothing stored): a terminal that lost the broker shows frozen positions and prices. The EA does not send while disconnected or before an account is logged in; the app then reads the bridge as stale, then offline, and raises the bridge-silent incident. |

### Responses

| Code | Body | EA does |
|---|---|---|
| 200 | `{"ok":true,"seq":n,"stored_deals":k}` | moves the deal cursor on, only when the reply holds `"ok":true` and its own `seq` (a proxy or login page answering 200 counts as a failure) |
| 400 | `{"ok":false,"error":"<field>: <rule>"}` (never echoes a value: symbols are named by position, `symbols entry 2`, unknown keys only counted) | backs off, prints the error |
| 401 | same body for a missing or wrong token (constant-time compare) | backs off, prints "token refused" |
| 409 | stale `seq` in the same `bridge_session` (already stored), or a new `bridge_session` whose `gmt_time` is not later than the stored snapshot (a replay) | treats it as done, no back-off |
| 413 | body too large | backs off, prints "lower InpMaxDeals" |
| 415 | not JSON | backs off |

## How the EA sends

- **Session and seq.** Each start makes a new `bridge_session` (16 hex chars) and counts `seq` from 0.
  The app refuses a `seq` that is not above the last one in the same session (a replay) and writes nothing.
- **When.** Every `InpIntervalSec` seconds (`reason` `timer`), the first one after a start is `init`.
  On a trade event it sends at once (`trade`) if the last send was at least 1 s ago, otherwise the next
  timer send carries `trade`.
- **Deal cursor.** The first snapshot covers `InpHistoryDays` of closed deals; later ones send deals from
  the cursor on, oldest first (sorted by `DEAL_TIME_MSC`), at most `InpMaxDeals`. The cursor moves **only
  after an Edge Desk 2xx** and keeps one minute of overlap for late deals, also between pages of a long first
  load; the app stores each deal once (by ticket), so repeats are harmless. A page also ends before a deal
  whose symbol would not fit in the 64-symbol block. An old trade whose entry and exit land on different
  pages raises no alert: the app writes no trade from an entry alone that the bridge never showed open, and
  a trade never shown open is news only if it closed after the previous snapshot.
- **Connection.** Each request sends `Connection: close`, so no idle connection is left on the server.
- **Back-off.** On a failure (WebRequest -1 or a non-2xx code other than 409) it waits 5, 10, 20, 40,
  then 60 s between tries. Error 4014 prints how to allow the URL.

## Broker clock

MT5 times are the trade server's wall clock. Config `bridge.broker_clock`:

- `ny_close` (default): server midnight = 17:00 New York, so UTC+2, or UTC+3 while New York is on
  daylight time, worked out at each time (a winter deal converts with +2 even in summer).
- `measured`: offset = `round((server_time - gmt_time) / 900) * 900`, one offset per snapshot.

With `ny_close`, each snapshot compares the rule with the measured offset. If they differ, that snapshot
uses the measured offset and the app raises one `clock_mismatch` alert per session (then set
`broker_clock = "measured"`). If `gmt_time` is more than `bridge.max_clock_skew_s` away from the app's
clock, the snapshot is refused: fix the VPS clock.

## EA inputs

| Input | Default | Meaning |
|---|---|---|
| `InpAlias` | `main` | Account alias. Must equal config `account.alias`. Never the account number (all digits are refused by both the EA and the app). |
| `InpUrl` | placeholder | `https://<your host>/api/bridge/v1/snapshot`. HTTPS only; plain http only when the host is exactly `127.0.0.1` or `localhost` (optional port), for local tests. A URL with user info (`@` in the host part) is refused. |
| `InpTokenFile` | `edge_bridge_token.txt` | Token file in the terminal's **Common\Files** folder. The token is never an input value. |
| `InpSymbol` | `EURUSD` | The broker's EUR/USD name (for example `EURUSD.r`); it must also be in config `instrument.broker_symbols`. |
| `InpIntervalSec` | 5 | Seconds between snapshots (1-10: the app reads the bridge stale after 15 s, config `bridge.stale_after_s`). |
| `InpHistoryDays` | 30 | Days of closed deals sent at start (1-365). |
| `InpTimeoutMs` | 5000 | HTTP timeout (1000-30000). |
| `InpMaxDeals` | 100 | Most deals per snapshot (1-500). |
| `InpCalendarSec` | 60 | Seconds between calendar posts (`edge-calendar/2`, below): 0 turns the calendar off, otherwise 60-3600 (EA 1.12; 1.11 took 30: the MetaQuotes licence reading, condition K4, allows one calendar read a minute at most). |

## Setup on the VPS

1. Install MetaTrader 5 from your broker. Log in with the account number and the **investor password**
   (read-only). The Live screen shows a hard incident if the terminal could trade.
2. Make the ingest token: a random string of 32+ characters, for example
   `python3 -c "import secrets; print(secrets.token_urlsafe(32))"`. Put it in the server's environment
   secret `EDGE_INGEST_TOKEN`. Never in chat, code or the repo.
3. Put the same token, on one line, in `edge_bridge_token.txt` in the Common\Files folder: in MT5,
   File > Open Data Folder, go up one level (to `Terminal`), then `Common\Files`. Save it as plain text.
4. Tools > Options > Expert Advisors: tick "Allow WebRequest for listed URL" and add your app's base URL,
   for example `https://edge.example.com`.
5. Copy `EdgeBridge.mq5` to `MQL5\Experts` (File > Open Data Folder), compile it in MetaEditor (F7),
   then drag it onto any one chart. Set `InpUrl` (and `InpSymbol` if your broker adds a suffix).
6. The Experts tab shows `EdgeBridge edge-bridge/1 started`. The app's Live screen turns "live" within
   a few seconds. `python3 -m app bridge-status` shows the same from the server.

## What is never sent

Account number, account name, server name, passwords, the terminal's folder or IP. The token travels only
in the `Authorization` header. The app stores the alias and MT5 tickets on your own server only.

## Versioning

This is `edge-bridge/1`. The app refuses unknown keys, so **any** change (a new key, a removed key, a new
type or meaning) needs `edge-bridge/2`: a new contract name in the EA, in config `bridge.contract` and in
`app/ingest/schema.py`, with the old version refused rather than half-read.

## Calendar: `edge-calendar/2`

The same EA also reads the terminal's own economic calendar (MetaQuotes') and posts the EUR and USD rows to the app,
which shows them on Today and Calendar and sends a phone alert before high-impact releases (`app/news`). The snapshot
contract `edge-bridge/1` above does not change. The app itself makes no request for calendar numbers.

`edge-calendar/2` (EA 1.11) is `edge-calendar/1` (EA 1.10) with one more key per row, `impact`. The app reads both:
a `/1` post is stored with `impact` "none", so a terminal that has not reloaded the EA keeps its news. Each version's
own key set is exact (a `/1` row with `impact`, or a `/2` row without it, is refused).

```
POST /api/bridge/v1/calendar
Authorization: Bearer <ingest token>        (the same EDGE_INGEST_TOKEN as snapshots)
Content-Type: application/json
```

Every key is required; any other key is refused (400). Times are trade-server epoch seconds (as in `edge-bridge/1`),
except `gmt_time` (UTC, `TimeGMT()`).

```
{"contract":"edge-calendar/2", "bridge_session":"<16 lowercase hex>", "cal_seq":<int >= 0>,
 "server_time":<int>, "gmt_time":<int>, "from":<int>, "to":<int>, "currencies":["EUR","USD"],
 "values":[{"value_id":"<digits>", "event_id":"<digits>", "currency":"USD", "country":"US", "name":"<1-128 chars>",
            "type":"indicator|event|holiday", "importance":"none|low|medium|high",
            "time_mode":"datetime|date|notime|tentative", "time":<int>,
            "unit":"none|percent|currency|hour|job|rig|usd|people|mortgage|vote|barrel|cubicfeet|position|building",
            "multiplier":"none|thousands|millions|billions|trillions", "digits":<int 0-10>,
            "actual":<num|null>, "forecast":<num|null>, "previous":<num|null>, "revised_previous":<num|null>,
            "impact":"none|positive|negative"}]}
```

| Rule | Detail |
|---|---|
| Window | `from < to`, `to - from` at most 15 days; every `time` within `[from, to]`. The EA sends 2 days back to 8 days ahead of the server time. |
| Whole window | The post is the **whole** window for its currencies: a stored row in the window that the post leaves out was cancelled or moved, and is deleted. So the EA never sends a partial window: any read error sends nothing. |
| Values | at most 500, `value_id` unique; `currencies` 1-8 unique `[A-Z]{3}`, each value's `currency` in it; `country` `[A-Z]{2}`; `name` 1-128 characters, no control character. |
| Numbers | finite, within +-1e12, never a bool (`null` when the calendar has no value). The EA sends `Get...Value()`, in the event's multiplier units (254.0 with `thousands` shows as 254K). |
| Importance | the EA sends medium and high importance rows and holidays; low-importance rows are not sent (size and focus). |
| Impact | MetaQuotes' own label of a released value for its currency (`MqlCalendarValue.impact_type`: `CALENDAR_IMPACT_POSITIVE`, `_NEGATIVE`, otherwise "none"). The app shows it as "MT5's read, untested" once the actual is out; it is never measured here. |
| Session | `cal_seq` counts from 1 in each `bridge_session` (the EA's start); the app refuses one not above the last in the same session. |

### Responses

| Code | Body | EA does |
|---|---|---|
| 200 | `{"ok":true,"cal_seq":n,"stored":k}`, with `"ignored":"clock"` added when the post's measured server offset differs from the latest snapshot's (nothing stored, so a terminal that is not connected never moves the stored times) | next post after `InpCalendarSec`, only when the reply holds `"ok":true` and its own `"cal_seq":n,` |
| 400 | `{"ok":false,"error":"<field>: <rule>"}` (never echoes a value; rows named by position, `values entry 3`) | backs off, prints the error |
| 401 | missing or wrong token | backs off, prints "token refused" |
| 404 | `{"ok":false,"error":"news is off"}` (config `[news] enabled = false`) | stops calendar posts until the EA restarts |
| 409 | stale `cal_seq` in the same `bridge_session` | treats it as done, no back-off |
| 413 | body over 262,144 bytes | backs off, prints "calendar too large" |
| 415 | not JSON | backs off |

### How the EA sends the calendar

- `OnTimer` sends the snapshot first, then the calendar when it is due, on its own back-off (send failures: the
  snapshot's 5-60 s steps, but never sooner than `InpCalendarSec`; read failures: 60 s, 5 min, 15 min, then hourly,
  because a calendar read that times out blocks the EA's timer for about 50 s; real run, 19 Oct 2026). A calendar
  failure never touches the snapshot's back-off, `seq` or deal cursor.
- Only from a connected terminal with an account logged in, like snapshots, and each `CalendarValueHistory` read
  comes right after a `TERMINAL_CONNECTED` check that gives up. A read that starts while connected and loses the
  connection can still block the timer for about 50 s (the read failures' back-off above limits how often).
- Exactly two `WebRequest` calls in the EA: the snapshot to `InpUrl` and the calendar to `g_cal_url`, which is set
  once, in `OnInit`, from `InpUrl` (pinned by `tests/test_bridge_ea_static.py`).
- The URL is `InpUrl` with its last part `snapshot` replaced by `calendar`; an `InpUrl` that does not end with
  `/api/bridge/v1/snapshot` turns the calendar off (the Experts tab says so). The WebRequest allow-list entry
  `http://127.0.0.1:8787` (the base URL) covers both paths.
- What is never sent: anything about the account. The token travels only in the `Authorization` header.
- Calendar names come in the terminal's language (English on the server); they are shown as data.

### Calendar sources (MQL5, read 19-20 Oct 2026)

- Calendar functions, "All functions for working with the economic calendar use the trade server time":
  https://www.mql5.com/en/docs/calendar
- `int CalendarValueHistory(MqlCalendarValue& values[], datetime datetime_from, datetime datetime_to=0, const string
  country_code=NULL, const string currency=NULL)`, -1 on error (5401 ERR_CALENDAR_TIMEOUT, 5400, 4001, 4004):
  https://www.mql5.com/en/docs/calendar/calendarvaluehistory
- `bool CalendarEventById(ulong event_id, MqlCalendarEvent& event)`: https://www.mql5.com/en/docs/calendar/calendareventbyid
- `bool CalendarCountryById(const long country_id, MqlCalendarCountry& country)` (`code`: ISO 3166-1 alpha-2, "EU"
  for the euro area): https://www.mql5.com/en/docs/calendar/calendarcountrybyid
- `MqlCalendarValue` (`id`, `event_id`, `time`, `HasActualValue()`/`GetActualValue()` and the forecast, previous and
  revised pairs; raw fields are scaled by 10^6, LONG_MIN when not set), `MqlCalendarEvent` (`type`, `time_mode`,
  `country_id`, `unit`, `importance`, `multiplier`, `digits`, `name`), `MqlCalendarCountry`, and the enums
  `ENUM_CALENDAR_EVENT_TYPE`, `_IMPORTANCE`, `_TIMEMODE`, `_UNIT`, `_MULTIPLIER`:
  https://www.mql5.com/en/docs/constants/structures/mqlcalendar
- `MqlCalendarValue.impact_type` ("potential impact on the currency rate") and `CALENDAR_IMPACT_NA` (0),
  `CALENDAR_IMPACT_POSITIVE` (1), `CALENDAR_IMPACT_NEGATIVE` (2): MetaTrader 5 build 1920 release note,
  https://www.metatrader5.com/en/releasenotes/terminal/1920 (read 19 Oct 2026). Its enum type is spelled
  `ENUM_CALENDAR_EVENT_IMPACRT` there, so the EA never names the type: it compares the field as an `int` with the two
  constants. The names were confirmed by the compiler (build 6274), and a copy with `CALENDAR_IMPACT_POSITIVEX` and
  `impact_typex` failed with 2 errors (`evidence/news/compile_negative_control_1.11.log`).
- Every enum name the EA uses compiled in MetaEditor build 6273: 0 errors, 0 warnings (19 Oct 2026); EA 1.11 on
  build 6274: 0 errors, 0 warnings (20 Oct 2026 Melbourne).

## Verified

- `EdgeBridge.mq5` compiled in MetaEditor 64-bit (MT5 installed from `mt5setup.exe`, run under Wine):
  0 errors, 0 warnings (10 Oct 2026). Version 1.10 with the calendar: 0 errors, 0 warnings on MetaEditor build 6273
  under WineHQ devel 11.20 (19 Oct 2026, `evidence/news/EVIDENCE.md`). Version 1.11 (`edge-calendar/2`, the impact
  label, the connected check before each calendar read): 0 errors, 0 warnings on MetaEditor build 6274 under WineHQ
  devel 11.20 (`evidence/news/compile_1.11.log`). Version 1.12 (`InpCalendarSec` 0 or 60-3600, nothing else
  changed): 0 errors, 0 warnings on MetaEditor 5.0.0.6272 under WineHQ devel 11.20 (`evidence/news/compile_1.12.log`).
  Not yet run on a connected terminal: which values `impact_type` really carries is unverified.
- The app side is covered by `tests/test_ingest_*.py` with the sample snapshots in
  `tests/fixtures/bridge_*.json` (fake alias "main", fake tickets).

## Sources

Every MQL5 function, enum and constant the EA uses was checked against the official documentation:

- WebRequest: https://www.mql5.com/en/docs/network/webrequest
- ArraySort (1-D ascending; used on packed time-in-ms keys): https://www.mql5.com/en/docs/array/arraysort
- DEAL_TIME_MSC, DEAL_TYPE_BUY_CANCELED / SELL_CANCELED (a cancelled deal changes type, its profit is zeroed and a
  separate balance deal settles it; sent as "other", not handled further in edge-bridge/1):
  https://www.mql5.com/en/docs/constants/tradingconstants/dealproperties
- Error codes (4014, 5200-5203): https://www.mql5.com/en/docs/constants/errorswarnings/errorcodes
- Trade permission (investor login makes `ACCOUNT_TRADE_ALLOWED` false): https://www.mql5.com/en/docs/runtime/tradepermission
- Handlers: https://www.mql5.com/en/docs/event_handlers/oninit ,
  https://www.mql5.com/en/docs/event_handlers/ondeinit , https://www.mql5.com/en/docs/event_handlers/ontimer ,
  https://www.mql5.com/en/docs/event_handlers/ontradetransaction ,
  https://www.mql5.com/en/docs/constants/structures/mqltradetransaction
- Timer: https://www.mql5.com/en/docs/eventfunctions/eventsettimer ,
  https://www.mql5.com/en/docs/eventfunctions/eventkilltimer
- Files: https://www.mql5.com/en/docs/files/fileopen , https://www.mql5.com/en/docs/files/filereadstring ,
  https://www.mql5.com/en/docs/files/fileclose , https://www.mql5.com/en/docs/constants/io_constants/fileflags ,
  https://www.mql5.com/en/docs/constants/io_constants/codepageusage ,
  https://www.mql5.com/en/docs/constants/namedconstants/otherconstants
- Account: https://www.mql5.com/en/docs/constants/environment_state/accountinformation ,
  https://www.mql5.com/en/docs/account/accountinfodouble , https://www.mql5.com/en/docs/account/accountinfointeger ,
  https://www.mql5.com/en/docs/account/accountinfostring
- Terminal: https://www.mql5.com/en/docs/constants/environment_state/terminalstatus ,
  https://www.mql5.com/en/docs/check/terminalinfointeger
- Symbols: https://www.mql5.com/en/docs/constants/environment_state/marketinfoconstants ,
  https://www.mql5.com/en/docs/marketinformation/symbolinfodouble ,
  https://www.mql5.com/en/docs/marketinformation/symbolinfointeger
- Positions: https://www.mql5.com/en/docs/constants/tradingconstants/positionproperties ,
  https://www.mql5.com/en/docs/trading/positionstotal , https://www.mql5.com/en/docs/trading/positiongetticket ,
  https://www.mql5.com/en/docs/trading/positiongetdouble , https://www.mql5.com/en/docs/trading/positiongetinteger ,
  https://www.mql5.com/en/docs/trading/positiongetstring
- Orders: https://www.mql5.com/en/docs/constants/tradingconstants/orderproperties ,
  https://www.mql5.com/en/docs/trading/orderstotal , https://www.mql5.com/en/docs/trading/ordergetticket ,
  https://www.mql5.com/en/docs/trading/ordergetdouble , https://www.mql5.com/en/docs/trading/ordergetinteger ,
  https://www.mql5.com/en/docs/trading/ordergetstring
- Deals: https://www.mql5.com/en/docs/constants/tradingconstants/dealproperties ,
  https://www.mql5.com/en/docs/trading/historyselect , https://www.mql5.com/en/docs/trading/historydealstotal ,
  https://www.mql5.com/en/docs/trading/historydealgetticket , https://www.mql5.com/en/docs/trading/historydealgetinteger ,
  https://www.mql5.com/en/docs/trading/historydealgetdouble , https://www.mql5.com/en/docs/trading/historydealgetstring
- Time: https://www.mql5.com/en/docs/dateandtime/timegmt , https://www.mql5.com/en/docs/dateandtime/timetradeserver ,
  https://www.mql5.com/en/docs/common/gettickcount64 , https://www.mql5.com/en/docs/common/getmicrosecondcount
- Strings and conversion: https://www.mql5.com/en/docs/convert/stringtochararray ,
  https://www.mql5.com/en/docs/convert/chararraytostring , https://www.mql5.com/en/docs/convert/doubletostring ,
  https://www.mql5.com/en/docs/convert/integertostring , https://www.mql5.com/en/docs/strings/stringgetcharacter ,
  https://www.mql5.com/en/docs/strings/stringsubstr , https://www.mql5.com/en/docs/strings/stringlen ,
  https://www.mql5.com/en/docs/strings/stringfind
- Maths and arrays: https://www.mql5.com/en/docs/math/mathisvalidnumber , https://www.mql5.com/en/docs/math/mathrand ,
  https://www.mql5.com/en/docs/math/mathsrand , https://www.mql5.com/en/docs/array/arrayresize ,
  https://www.mql5.com/en/docs/array/arraysize , https://www.mql5.com/en/docs/array/arraysort
- Errors and output: https://www.mql5.com/en/docs/check/getlasterror , https://www.mql5.com/en/docs/common/resetlasterror ,
  https://www.mql5.com/en/docs/common/print
- Language: https://www.mql5.com/en/docs/basis/variables/inputvariables ,
  https://www.mql5.com/en/docs/basis/preprosessor/compilation , https://www.mql5.com/en/docs/basis/types/integer/datetime ,
  https://www.mql5.com/en/docs/basis/types/casting
