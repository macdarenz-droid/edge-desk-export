//+------------------------------------------------------------------+
//| EdgeBridge.mq5                                                   |
//| Read-only bridge for Edge Desk, contract edge-bridge/1.          |
//| Every few seconds, and on trade events, it reads the account,    |
//| open positions, pending orders and closed deals, and POSTs them  |
//| as JSON to the Edge Desk app. It has no order code at all.       |
//| It also sends the EUR and USD economic calendar (MetaQuotes'),   |
//| contract edge-calendar/2, every InpCalendarSec seconds.          |
//| Setup and the full contract: bridge/CONTRACT.md                  |
//+------------------------------------------------------------------+
#property copyright   "Personal use only"
#property version     "1.12"
#property description "Edge Desk read-only bridge (edge-bridge/1)."
#property description "Reads the account and sends snapshots. No order code."
#property description "Also sends EUR and USD calendar rows (edge-calendar/2)."

input string InpAlias       = "main";                                     // Account alias (a label, never the account number)
input string InpUrl         = "https://your-host/api/bridge/v1/snapshot"; // Ingest URL (also add it in Tools > Options > Expert Advisors)
input string InpTokenFile   = "edge_bridge_token.txt";                    // Token file in the Common\Files folder
input string InpSymbol      = "EURUSD";                                   // Broker name of EUR/USD (for example EURUSD.r)
input int    InpIntervalSec = 5;                                          // Seconds between snapshots (1-10; the app reads stale at 15 s)
input int    InpHistoryDays = 30;                                         // Days of closed deals sent at start
input int    InpTimeoutMs   = 5000;                                       // HTTP timeout in ms
input int    InpMaxDeals    = 100;                                        // Most closed deals in one snapshot
input int    InpCalendarSec = 60;                                         // Seconds between calendar sends (0 = off; else 60-3600)

#define EB_CONTRACT "edge-bridge/1"
#define EB_MAX_LIST 200
#define EB_MAX_SYMBOLS 64          // the app refuses more (app/ingest/schema.py MAX_SYMBOLS)
#define EB_IDX_SPAN 2097152        // 2^21: a deal's list index packed under its time in ms (sort key)
#define EB_CAL_CONTRACT "edge-calendar/2"
#define EB_CAL_MAX 500             // the app refuses more (app/news/schema.py MAX_VALUES)
#define EB_CAL_BACK_S 172800       // calendar rows from 2 days back ...
#define EB_CAL_AHEAD_S 691200      // ... to 8 days ahead (the app takes a window of at most 15 days)
#define EB_CAL_TAIL "/api/bridge/v1/snapshot"

string   g_token        = "";      // ingest token; never printed
string   g_session      = "";      // 16 hex chars, new on every start
long     g_seq          = 0;       // snapshot number within the session
datetime g_cursor       = 0;       // closed-deal cursor (server time); moves only after HTTP 2xx
string   g_pending      = "init";  // reason waiting to be sent; "" when nothing is due
ulong    g_last_ms      = 0;       // last send attempt (GetTickCount64)
ulong    g_retry_ms     = 0;       // no attempt before this (back-off)
int      g_fails        = 0;
bool     g_waiting      = false;   // not connected to the broker (or no account): nothing is sent
string   g_syms[];
int      g_backoff[]    = {5, 10, 20, 40, 60};
long     g_cal_seq      = 0;       // calendar post number within the session (only has to rise)
ulong    g_cal_due_ms   = 0;       // no calendar send before this (GetTickCount64)
int      g_cal_fails    = 0;       // calendar sends that failed in a row
int      g_cal_reads    = 0;       // calendar reads that failed in a row
bool     g_cal_off      = false;   // InpCalendarSec 0, a URL without the snapshot path, or the app's 404
string   g_cal_url      = "";
string   g_cal_cur[]    = {"EUR", "USD"};
int      g_cal_read_wait[] = {60, 300, 900, 3600};   // after a failed read: a read that times out blocks the timer

//--- small JSON helpers ----------------------------------------------
string HexDigit(const int v) { return StringSubstr("0123456789abcdef", v & 15, 1); }

string Q(const string s)
  {
   string out = "\"";
   int n = StringLen(s);
   for(int i = 0; i < n; i++)
     {
      ushort c = StringGetCharacter(s, i);
      if(c == 34)
         out += "\\\"";
      else if(c == 92)
         out += "\\\\";
      else if(c < 32)
         out += "\\u00" + HexDigit(c >> 4) + HexDigit(c);
      else
         out += StringSubstr(s, i, 1);
     }
   return out + "\"";
  }

string Num(const double v, const int digits) { return MathIsValidNumber(v) ? DoubleToString(v, digits) : "0"; }
string Px(const double v)    { return (MathIsValidNumber(v) && v > 0.0) ? Num(v, 8) : "null"; }   // MT5 uses 0 for "no stop"
string Money(const double v) { return Num(v, 8); }   // fixed decimals: never rounded to the account's digits
string B(const bool v)       { return v ? "true" : "false"; }
string I(const long v)       { return IntegerToString(v); }
string T(const datetime v)   { return IntegerToString((long)v); }      // trade-server epoch seconds

// A ulong in decimal without a signed cast (2^63 and above stay positive).
string U64(ulong v)
  {
   if(v == 0)
      return "0";
   string s = "";
   while(v > 0)
     {
      s = StringSubstr("0123456789", (int)(v % 10), 1) + s;
      v /= 10;
     }
   return s;
  }

string Tk(const ulong v)     { return Q(U64(v)); }                     // tickets are strings (64-bit safe)
string Kv(const string key, const string raw) { return "\"" + key + "\":" + raw; }

//--- checks ----------------------------------------------------------
string Trim(const string s)
  {
   int a = 0, b = StringLen(s) - 1;
   while(a <= b && StringGetCharacter(s, a) <= 32)
      a++;
   while(b >= a && StringGetCharacter(s, b) <= 32)
      b--;
   return StringSubstr(s, a, b - a + 1);
  }

bool IsDigit(const ushort c)  { return c >= '0' && c <= '9'; }
bool IsLetter(const ushort c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'); }

bool AliasOk(const string a)
  {
   int n = StringLen(a);
   if(n < 1 || n > 32)
      return false;
   bool digits_only = true;
   for(int i = 0; i < n; i++)
     {
      ushort c = StringGetCharacter(a, i);
      if(!IsDigit(c) && !IsLetter(c) && c != '-' && c != '_')
         return false;
      if(!IsDigit(c))
         digits_only = false;
     }
   return !digits_only;   // all digits looks like an account number
  }

bool TokenOk(const string t)
  {
   int n = StringLen(t);
   if(n < 32 || n > 256)
      return false;
   for(int i = 0; i < n; i++)
     {
      ushort c = StringGetCharacter(t, i);
      if(!IsDigit(c) && !IsLetter(c) && StringFind("-_.~+/=", StringSubstr(t, i, 1)) < 0)
         return false;
     }
   return true;
  }

// The host part of a URL: between "://" and the next "/".
string Authority(const string u)
  {
   int start = StringFind(u, "://");
   if(start < 0)
      return "";
   start += 3;
   int slash = StringFind(u, "/", start);
   return slash < 0 ? StringSubstr(u, start) : StringSubstr(u, start, slash - start);
  }

// Exactly 127.0.0.1 or localhost, with an optional numeric port.
bool LocalAuthority(const string a)
  {
   string host = a;
   int colon = StringFind(a, ":");
   if(colon >= 0)
     {
      host = StringSubstr(a, 0, colon);
      string port = StringSubstr(a, colon + 1);
      int n = StringLen(port);
      if(n < 1 || n > 5)
         return false;
      for(int i = 0; i < n; i++)
         if(!IsDigit(StringGetCharacter(port, i)))
            return false;
     }
   return host == "127.0.0.1" || host == "localhost";
  }

// https to any host; plain http only to this machine (the token must never cross a network in clear).
bool UrlOk(const string u)
  {
   if(StringFind(u, "your-host") >= 0)
      return false;
   string a = Authority(u);
   if(a == "" || StringFind(a, "@") >= 0)   // no user info: the host is what it looks like
      return false;
   if(StringFind(u, "https://") == 0)
      return true;
   return StringFind(u, "http://") == 0 && LocalAuthority(a);
  }

string UrlBase(const string u)
  {
   int start = StringFind(u, "://");
   if(start < 0)
      return u;
   int slash = StringFind(u, "/", start + 3);
   return slash < 0 ? u : StringSubstr(u, 0, slash);
  }

bool ReadToken()
  {
   ResetLastError();
   int h = FileOpen(InpTokenFile, FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
     {
      Print("EdgeBridge: cannot open the token file '", InpTokenFile, "' in the Common\\Files folder (error ",
            GetLastError(), "). Put the ingest token there; see bridge/CONTRACT.md.");
      return false;
     }
   string t = Trim(FileReadString(h));
   FileClose(h);
   if(!TokenOk(t))
     {
      Print("EdgeBridge: the token in '", InpTokenFile, "' must be 32 to 256 characters of letters, digits",
            " and - _ . ~ + / = only, on one line, saved as plain text (no BOM).");
      return false;
     }
   g_token = t;
   return true;
  }

string NewSession()
  {
   MathSrand((int)(GetMicrosecondCount() ^ GetTickCount64() ^ (ulong)TimeGMT()));
   string s = "";
   for(int i = 0; i < 16; i++)
      s += HexDigit(MathRand());
   return s;
  }

//--- snapshot parts --------------------------------------------------
// Adds a symbol to the snapshot's symbols block; false when the block is full (EB_MAX_SYMBOLS).
bool AddSym(const string s)
  {
   if(s == "")
      return true;
   int n = ArraySize(g_syms);
   for(int i = 0; i < n; i++)
      if(g_syms[i] == s)
         return true;
   if(n >= EB_MAX_SYMBOLS)
      return false;
   ArrayResize(g_syms, n + 1);
   g_syms[n] = s;
   return true;
  }

string SymbolsJson()
  {
   string j = "";
   int n = ArraySize(g_syms);
   for(int i = 0; i < n; i++)
     {
      string s = g_syms[i];
      if(i > 0)
         j += ",";
      j += Q(s) + ":{"
           + Kv("digits", I(SymbolInfoInteger(s, SYMBOL_DIGITS))) + ","
           + Kv("point", Num(SymbolInfoDouble(s, SYMBOL_POINT), 10)) + ","
           + Kv("tick_size", Num(SymbolInfoDouble(s, SYMBOL_TRADE_TICK_SIZE), 10)) + ","
           + Kv("tick_value", Num(SymbolInfoDouble(s, SYMBOL_TRADE_TICK_VALUE), 10)) + ","
           + Kv("contract_size", Num(SymbolInfoDouble(s, SYMBOL_TRADE_CONTRACT_SIZE), 4)) + ","
           + Kv("volume_min", Num(SymbolInfoDouble(s, SYMBOL_VOLUME_MIN), 8)) + ","
           + Kv("volume_step", Num(SymbolInfoDouble(s, SYMBOL_VOLUME_STEP), 8)) + ","
           + Kv("volume_max", Num(SymbolInfoDouble(s, SYMBOL_VOLUME_MAX), 4)) + ","
           + Kv("stops_level", I(SymbolInfoInteger(s, SYMBOL_TRADE_STOPS_LEVEL))) + ","
           + Kv("spread", I(SymbolInfoInteger(s, SYMBOL_SPREAD))) + ","
           + Kv("bid", Num(SymbolInfoDouble(s, SYMBOL_BID), 8)) + ","
           + Kv("ask", Num(SymbolInfoDouble(s, SYMBOL_ASK), 8)) + "}";
     }
   return "{" + j + "}";
  }

string PositionsJson()
  {
   string j = "";
   int total = PositionsTotal(), k = 0;
   for(int i = 0; i < total && k < EB_MAX_LIST; i++)
     {
      ulong ticket = PositionGetTicket(i);   // selects the position
      if(ticket == 0)
         continue;
      string sym = PositionGetString(POSITION_SYMBOL);
      AddSym(sym);
      bool buy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
      if(k++ > 0)
         j += ",";
      j += "{" + Kv("ticket", Tk(ticket)) + ","
           + Kv("position_id", Tk((ulong)PositionGetInteger(POSITION_IDENTIFIER))) + ","
           + Kv("symbol", Q(sym)) + ","
           + Kv("side", buy ? Q("buy") : Q("sell")) + ","
           + Kv("volume", Num(PositionGetDouble(POSITION_VOLUME), 8)) + ","
           + Kv("open_price", Num(PositionGetDouble(POSITION_PRICE_OPEN), 8)) + ","
           + Kv("open_time", T((datetime)PositionGetInteger(POSITION_TIME))) + ","
           + Kv("price", Num(PositionGetDouble(POSITION_PRICE_CURRENT), 8)) + ","
           + Kv("sl", Px(PositionGetDouble(POSITION_SL))) + ","
           + Kv("tp", Px(PositionGetDouble(POSITION_TP))) + ","
           + Kv("profit", Money(PositionGetDouble(POSITION_PROFIT))) + ","
           + Kv("swap", Money(PositionGetDouble(POSITION_SWAP))) + ","
           + Kv("magic", I(PositionGetInteger(POSITION_MAGIC))) + ","
           + Kv("comment", Q(StringSubstr(PositionGetString(POSITION_COMMENT), 0, 64))) + "}";
     }
   return "[" + j + "]";
  }

string OrderTypeName(const long t)
  {
   if(t == ORDER_TYPE_BUY_LIMIT)       return "buy_limit";
   if(t == ORDER_TYPE_SELL_LIMIT)      return "sell_limit";
   if(t == ORDER_TYPE_BUY_STOP)        return "buy_stop";
   if(t == ORDER_TYPE_SELL_STOP)       return "sell_stop";
   if(t == ORDER_TYPE_BUY_STOP_LIMIT)  return "buy_stop_limit";
   if(t == ORDER_TYPE_SELL_STOP_LIMIT) return "sell_stop_limit";
   if(t == ORDER_TYPE_BUY)             return "buy";
   if(t == ORDER_TYPE_SELL)            return "sell";
   return "other";
  }

string OrdersJson()
  {
   string j = "";
   int total = OrdersTotal(), k = 0;
   for(int i = 0; i < total && k < EB_MAX_LIST; i++)
     {
      ulong ticket = OrderGetTicket(i);   // selects the order
      if(ticket == 0)
         continue;
      string sym = OrderGetString(ORDER_SYMBOL);
      AddSym(sym);
      datetime exp = (datetime)OrderGetInteger(ORDER_TIME_EXPIRATION);
      if(k++ > 0)
         j += ",";
      j += "{" + Kv("ticket", Tk(ticket)) + ","
           + Kv("symbol", Q(sym)) + ","
           + Kv("type", Q(OrderTypeName(OrderGetInteger(ORDER_TYPE)))) + ","
           + Kv("volume", Num(OrderGetDouble(ORDER_VOLUME_CURRENT), 8)) + ","
           + Kv("price", Num(OrderGetDouble(ORDER_PRICE_OPEN), 8)) + ","
           + Kv("sl", Px(OrderGetDouble(ORDER_SL))) + ","
           + Kv("tp", Px(OrderGetDouble(ORDER_TP))) + ","
           + Kv("setup_time", T((datetime)OrderGetInteger(ORDER_TIME_SETUP))) + ","
           + Kv("expiration", exp > 0 ? T(exp) : "null") + "}";
     }
   return "[" + j + "]";
  }

string DealTypeName(const long t)
  {
   if(t == DEAL_TYPE_BUY)        return "buy";
   if(t == DEAL_TYPE_SELL)       return "sell";
   if(t == DEAL_TYPE_BALANCE)    return "balance";
   if(t == DEAL_TYPE_CREDIT)     return "credit";
   if(t == DEAL_TYPE_CHARGE)     return "charge";
   if(t == DEAL_TYPE_CORRECTION) return "correction";
   if(t == DEAL_TYPE_BONUS)      return "bonus";
   if(t == DEAL_TYPE_COMMISSION || t == DEAL_TYPE_COMMISSION_DAILY || t == DEAL_TYPE_COMMISSION_MONTHLY ||
      t == DEAL_TYPE_COMMISSION_AGENT_DAILY || t == DEAL_TYPE_COMMISSION_AGENT_MONTHLY)
      return "commission";
   if(t == DEAL_TYPE_INTEREST)   return "interest";
   return "other";
  }

string DealEntryName(const long e)
  {
   if(e == DEAL_ENTRY_IN)     return "in";
   if(e == DEAL_ENTRY_OUT)    return "out";
   if(e == DEAL_ENTRY_INOUT)  return "inout";
   if(e == DEAL_ENTRY_OUT_BY) return "out_by";
   return "none";
  }

string DealReasonName(const long r)
  {
   if(r == DEAL_REASON_CLIENT)   return "client";
   if(r == DEAL_REASON_MOBILE)   return "mobile";
   if(r == DEAL_REASON_WEB)      return "web";
   if(r == DEAL_REASON_EXPERT)   return "expert";
   if(r == DEAL_REASON_SL)       return "sl";
   if(r == DEAL_REASON_TP)       return "tp";
   if(r == DEAL_REASON_SO)       return "so";
   if(r == DEAL_REASON_ROLLOVER) return "rollover";
   if(r == DEAL_REASON_VMARGIN)  return "vmargin";
   if(r == DEAL_REASON_SPLIT)    return "split";
   return "other";
  }

// Closed deals from the cursor on, oldest first, at most InpMaxDeals. The history list has no documented
// order, so deals are sorted by DEAL_TIME_MSC (then list position) before the page is cut. A page also ends
// before a trade deal whose symbol would not fit in the symbols block (capped: the rest comes next time).
string DealsJson(datetime &last_time, int &count, bool &capped)
  {
   last_time = 0;
   count = 0;
   capped = false;
   if(!HistorySelect(g_cursor, TimeTradeServer() + 86400))
      return "[]";
   int total = HistoryDealsTotal();
   long keys[];
   ArrayResize(keys, total);
   int n = 0;
   for(int i = 0; i < total && i < EB_IDX_SPAN; i++)
     {
      ulong tk = HistoryDealGetTicket(i);
      if(tk == 0)
         continue;
      keys[n++] = HistoryDealGetInteger(tk, DEAL_TIME_MSC) * EB_IDX_SPAN + i;   // time in ms, then position
     }
   ArrayResize(keys, n);
   ArraySort(keys);
   capped = (n > InpMaxDeals);
   string j = "";
   for(int k = 0; k < n && count < InpMaxDeals; k++)
     {
      ulong t = HistoryDealGetTicket((int)(keys[k] % EB_IDX_SPAN));
      if(t == 0)
         continue;
      datetime when = (datetime)HistoryDealGetInteger(t, DEAL_TIME);
      string type = DealTypeName(HistoryDealGetInteger(t, DEAL_TYPE));
      bool trade = (type == "buy" || type == "sell");
      string sym = HistoryDealGetString(t, DEAL_SYMBOL);
      if(trade && !AddSym(sym))
        {
         capped = true;   // symbols block full: end the page here
         break;
        }
      if(count++ > 0)
         j += ",";
      j += "{" + Kv("deal", Tk(t)) + ","
           + Kv("order", Tk((ulong)HistoryDealGetInteger(t, DEAL_ORDER))) + ","
           + Kv("position_id", Tk((ulong)HistoryDealGetInteger(t, DEAL_POSITION_ID))) + ","
           + Kv("symbol", Q(sym)) + ","
           + Kv("type", Q(type)) + ","
           + Kv("entry", Q(trade ? DealEntryName(HistoryDealGetInteger(t, DEAL_ENTRY)) : "none")) + ","
           + Kv("volume", Num(HistoryDealGetDouble(t, DEAL_VOLUME), 8)) + ","
           + Kv("price", Num(HistoryDealGetDouble(t, DEAL_PRICE), 8)) + ","
           + Kv("time", T(when)) + ","
           + Kv("profit", Money(HistoryDealGetDouble(t, DEAL_PROFIT))) + ","
           + Kv("commission", Money(HistoryDealGetDouble(t, DEAL_COMMISSION))) + ","
           + Kv("swap", Money(HistoryDealGetDouble(t, DEAL_SWAP))) + ","
           + Kv("fee", Money(HistoryDealGetDouble(t, DEAL_FEE))) + ","
           + Kv("reason", Q(DealReasonName(HistoryDealGetInteger(t, DEAL_REASON)))) + ","
           + Kv("sl", Px(HistoryDealGetDouble(t, DEAL_SL))) + ","
           + Kv("tp", Px(HistoryDealGetDouble(t, DEAL_TP))) + ","
           + Kv("magic", I(HistoryDealGetInteger(t, DEAL_MAGIC))) + "}";
      if(when > last_time)
         last_time = when;
     }
   return "[" + j + "]";
  }

string BuildSnapshot(const string reason, datetime &last_time, int &count, bool &capped)
  {
   ArrayResize(g_syms, 0);
   AddSym(InpSymbol);
   string positions = PositionsJson();
   string orders    = OrdersJson();
   string deals     = DealsJson(last_time, count, capped);
   long mode = AccountInfoInteger(ACCOUNT_TRADE_MODE);
   string trade_mode = "real";   // anything unknown is treated as real money
   if(mode == ACCOUNT_TRADE_MODE_DEMO)
      trade_mode = "demo";
   else if(mode == ACCOUNT_TRADE_MODE_CONTEST)
      trade_mode = "contest";
   string account = "{" + Kv("alias", Q(InpAlias)) + ","
                    + Kv("currency", Q(AccountInfoString(ACCOUNT_CURRENCY))) + ","
                    + Kv("company", Q(StringSubstr(AccountInfoString(ACCOUNT_COMPANY), 0, 128))) + ","
                    + Kv("balance", Money(AccountInfoDouble(ACCOUNT_BALANCE))) + ","
                    + Kv("equity", Money(AccountInfoDouble(ACCOUNT_EQUITY))) + ","
                    + Kv("profit", Money(AccountInfoDouble(ACCOUNT_PROFIT))) + ","
                    + Kv("margin", Money(AccountInfoDouble(ACCOUNT_MARGIN))) + ","
                    + Kv("margin_free", Money(AccountInfoDouble(ACCOUNT_MARGIN_FREE))) + ","
                    + Kv("trade_mode", Q(trade_mode)) + ","
                    + Kv("trade_allowed", B(AccountInfoInteger(ACCOUNT_TRADE_ALLOWED) != 0)) + ","
                    + Kv("trade_expert", B(AccountInfoInteger(ACCOUNT_TRADE_EXPERT) != 0)) + "}";
   string terminal = "{" + Kv("build", I(TerminalInfoInteger(TERMINAL_BUILD))) + ","
                     + Kv("trade_allowed", B(TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) != 0)) + ","
                     + Kv("connected", B(TerminalInfoInteger(TERMINAL_CONNECTED) != 0)) + "}";
   return "{" + Kv("contract", Q(EB_CONTRACT)) + ","
          + Kv("bridge_session", Q(g_session)) + ","
          + Kv("seq", I(g_seq)) + ","
          + Kv("reason", Q(reason)) + ","
          + Kv("server_time", T(TimeTradeServer())) + ","
          + Kv("gmt_time", T(TimeGMT())) + ","
          + Kv("account", account) + ","
          + Kv("terminal", terminal) + ","
          + Kv("symbols", SymbolsJson()) + ","
          + Kv("positions", positions) + ","
          + Kv("orders", orders) + ","
          + Kv("deals", deals) + ","
          + Kv("deals_from", T(g_cursor)) + "}";
  }

//--- sending ---------------------------------------------------------
// The cursor keeps one minute of overlap for late deals, also between history pages; the app ignores deals
// it already has. A full page inside one minute moves to its last second, so paging always moves on.
void AdvanceCursor(const datetime last_time, const int count, const bool capped)
  {
   if(count == 0)
      return;
   datetime next = last_time - 60;
   if(capped && next <= g_cursor)
      next = last_time;
   if(capped && next <= g_cursor)
     {
      next = g_cursor + 1;
      Print("EdgeBridge: more than ", InpMaxDeals, " deals share one second; raise InpMaxDeals.");
     }
   if(next > g_cursor)
      g_cursor = next;
  }

void Send()
  {
   ulong now = GetTickCount64();
   if(now < g_retry_ms)
      return;
   // Not connected to the broker, or no account logged in: positions and prices would be frozen copies
   // (and the account fields empty). Send nothing; the app reads the silence as stale, then offline.
   if(TerminalInfoInteger(TERMINAL_CONNECTED) == 0 || AccountInfoString(ACCOUNT_CURRENCY) == "")
     {
      if(!g_waiting)
         Print("EdgeBridge: the terminal is not connected to the broker (or no account is logged in);",
               " nothing is sent until it is.");
      g_waiting = true;
      return;
     }
   if(g_waiting)
      Print("EdgeBridge: connected again; sending.");
   g_waiting = false;
   string reason = (g_pending == "") ? "timer" : g_pending;
   datetime last_time = 0;
   int count = 0;
   bool capped = false;
   string body = BuildSnapshot(reason, last_time, count, capped);
   char data[];
   char reply[];
   string reply_headers;
   int len = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(len > 0)
      ArrayResize(data, len - 1);   // drop the terminating zero
   string headers = "Content-Type: application/json\r\nAuthorization: Bearer " + g_token + "\r\n"
                    + "Connection: close\r\n";   // no idle keep-alive connection left on the server
   g_last_ms = now;
   g_seq++;
   ResetLastError();
   int code = WebRequest("POST", InpUrl, headers, InpTimeoutMs, data, reply, reply_headers);
   string answer = (ArraySize(reply) > 0) ? CharArrayToString(reply, 0, -1, CP_UTF8) : "";
   // A 2xx counts only when Edge Desk wrote it ({"ok":true,"seq":<this seq>,...}): a proxy or login page
   // answering 200 must not move the deal cursor past deals the app never stored.
   bool stored = (code >= 200 && code < 300) && StringFind(answer, "\"ok\":true") >= 0
                 && StringFind(answer, "\"seq\":" + I(g_seq) + ",") >= 0;
   if(stored || code == 409)   // 409: this seq is already stored, not an error
     {
      if(code != 409)
         AdvanceCursor(last_time, count, capped);
      if(g_fails > 0)
         Print("EdgeBridge: sending again after ", g_fails, " failed attempt(s).");
      g_pending = "";
      g_fails = 0;
      g_retry_ms = 0;
      return;
     }
   g_fails++;
   int wait = g_backoff[g_fails < 5 ? g_fails - 1 : 4];
   g_retry_ms = GetTickCount64() + (ulong)wait * 1000;
   if(code == -1)
     {
      int err = GetLastError();
      if(err == 4014)
         Print("EdgeBridge: WebRequest is not allowed for this URL. Open Tools > Options > Expert Advisors, tick",
               " 'Allow WebRequest for listed URL' and add ", UrlBase(InpUrl));
      else
         Print("EdgeBridge: send failed (error ", err, "); next try in ", wait, " s.");
      return;
     }
   string text = StringSubstr(answer, 0, 200);
   if(code >= 200 && code < 300)
      Print("EdgeBridge: HTTP ", code, " but not an Edge Desk reply (a proxy or login page in the way?);",
            " next try in ", wait, " s.");
   else if(code == 401)
      Print("EdgeBridge: the app refused the token (401). The token file must match EDGE_INGEST_TOKEN.");
   else if(code == 413)
      Print("EdgeBridge: snapshot too large (413); lower InpMaxDeals.");
   else
      Print("EdgeBridge: the app answered ", code, " ", text, "; next try in ", wait, " s.");
  }

//--- calendar (edge-calendar/2) --------------------------------------
// The calendar URL beside the snapshot URL: ".../api/bridge/v1/snapshot" becomes ".../api/bridge/v1/calendar".
string CalendarUrl(const string u)
  {
   int n = StringLen(u), t = StringLen(EB_CAL_TAIL);
   if(n < t || StringSubstr(u, n - t) != EB_CAL_TAIL)
      return "";
   return StringSubstr(u, 0, n - 8) + "calendar";
  }

string CalTypeName(const ENUM_CALENDAR_EVENT_TYPE t)
  {
   if(t == CALENDAR_TYPE_INDICATOR) return "indicator";
   if(t == CALENDAR_TYPE_HOLIDAY)   return "holiday";
   return "event";
  }

string CalImpName(const ENUM_CALENDAR_EVENT_IMPORTANCE i)
  {
   if(i == CALENDAR_IMPORTANCE_LOW)      return "low";
   if(i == CALENDAR_IMPORTANCE_MODERATE) return "medium";
   if(i == CALENDAR_IMPORTANCE_HIGH)     return "high";
   return "none";
  }

string CalModeName(const ENUM_CALENDAR_EVENT_TIMEMODE m)
  {
   if(m == CALENDAR_TIMEMODE_DATE)      return "date";
   if(m == CALENDAR_TIMEMODE_NOTIME)    return "notime";
   if(m == CALENDAR_TIMEMODE_TENTATIVE) return "tentative";
   return "datetime";
  }

string CalUnitName(const ENUM_CALENDAR_EVENT_UNIT u)
  {
   if(u == CALENDAR_UNIT_PERCENT)   return "percent";
   if(u == CALENDAR_UNIT_CURRENCY)  return "currency";
   if(u == CALENDAR_UNIT_HOUR)      return "hour";
   if(u == CALENDAR_UNIT_JOB)       return "job";
   if(u == CALENDAR_UNIT_RIG)       return "rig";
   if(u == CALENDAR_UNIT_USD)       return "usd";
   if(u == CALENDAR_UNIT_PEOPLE)    return "people";
   if(u == CALENDAR_UNIT_MORTGAGE)  return "mortgage";
   if(u == CALENDAR_UNIT_VOTE)      return "vote";
   if(u == CALENDAR_UNIT_BARREL)    return "barrel";
   if(u == CALENDAR_UNIT_CUBICFEET) return "cubicfeet";
   if(u == CALENDAR_UNIT_POSITION)  return "position";
   if(u == CALENDAR_UNIT_BUILDING)  return "building";
   return "none";
  }

string CalMultName(const ENUM_CALENDAR_EVENT_MULTIPLIER m)
  {
   if(m == CALENDAR_MULTIPLIER_THOUSANDS) return "thousands";
   if(m == CALENDAR_MULTIPLIER_MILLIONS)  return "millions";
   if(m == CALENDAR_MULTIPLIER_BILLIONS)  return "billions";
   if(m == CALENDAR_MULTIPLIER_TRILLIONS) return "trillions";
   return "none";
  }

// MetaQuotes' own label of a released value for its currency (MqlCalendarValue.impact_type; the enum's own type
// name is left out on purpose: an old release note spells it ENUM_CALENDAR_EVENT_IMPACRT).
string CalImpactName(const int i)
  {
   if(i == (int)CALENDAR_IMPACT_POSITIVE) return "positive";
   if(i == (int)CALENDAR_IMPACT_NEGATIVE) return "negative";
   return "none";
  }

string CalNum(const bool has, const double v) { return (has && MathIsValidNumber(v)) ? DoubleToString(v, 6) : "null"; }

// The EUR and USD calendar from EB_CAL_BACK_S before to EB_CAL_AHEAD_S after the server time, as one edge-calendar/2
// body: medium and high importance, and holidays (low-importance rows are not sent). The app deletes the stored rows a
// window leaves out, so any read error sets ok = false and nothing is sent: never a partial window. Over EB_CAL_MAX
// rows, the window ends before the time of the first row that does not fit.
string CalendarJson(datetime &from, datetime &to, int &count, bool &ok)
  {
   from = (datetime)((long)TimeTradeServer() - EB_CAL_BACK_S);
   to = (datetime)((long)TimeTradeServer() + EB_CAL_AHEAD_S);
   ok = true;
   count = 0;
   string rows[];
   datetime times[];
   long keys[];
   for(int c = 0; c < ArraySize(g_cal_cur); c++)
     {
      string cur = g_cal_cur[c];
      MqlCalendarValue v[];
      // a read while the terminal is not connected waits about 50 s for data that cannot come: read only connected
      if(TerminalInfoInteger(TERMINAL_CONNECTED) == 0)
        {
         ok = false;
         return "";
        }
      ResetLastError();
      int n = CalendarValueHistory(v, from, to, NULL, cur);
      if(n < 0)
        {
         ok = false;
         return "";
        }
      for(int i = 0; i < n; i++)
        {
         MqlCalendarEvent ev;
         if(!CalendarEventById(v[i].event_id, ev))
           {
            ok = false;
            return "";
           }
         if(ev.importance != CALENDAR_IMPORTANCE_MODERATE && ev.importance != CALENDAR_IMPORTANCE_HIGH &&
            ev.type != CALENDAR_TYPE_HOLIDAY)
            continue;
         MqlCalendarCountry co;
         if(!CalendarCountryById((long)ev.country_id, co))
           {
            ok = false;
            return "";
           }
         int k = ArraySize(rows);
         ArrayResize(rows, k + 1);
         ArrayResize(times, k + 1);
         ArrayResize(keys, k + 1);
         rows[k] = "{" + Kv("value_id", Q(U64(v[i].id))) + ","
                   + Kv("event_id", Q(U64(v[i].event_id))) + ","
                   + Kv("currency", Q(cur)) + ","
                   + Kv("country", Q(co.code)) + ","
                   + Kv("name", Q(StringSubstr(ev.name, 0, 128))) + ","
                   + Kv("type", Q(CalTypeName(ev.type))) + ","
                   + Kv("importance", Q(CalImpName(ev.importance))) + ","
                   + Kv("time_mode", Q(CalModeName(ev.time_mode))) + ","
                   + Kv("time", T(v[i].time)) + ","
                   + Kv("unit", Q(CalUnitName(ev.unit))) + ","
                   + Kv("multiplier", Q(CalMultName(ev.multiplier))) + ","
                   + Kv("digits", I((long)ev.digits)) + ","
                   + Kv("actual", CalNum(v[i].HasActualValue(), v[i].GetActualValue())) + ","
                   + Kv("forecast", CalNum(v[i].HasForecastValue(), v[i].GetForecastValue())) + ","
                   + Kv("previous", CalNum(v[i].HasPreviousValue(), v[i].GetPreviousValue())) + ","
                   + Kv("revised_previous", CalNum(v[i].HasRevisedValue(), v[i].GetRevisedValue())) + ","
                   + Kv("impact", Q(CalImpactName((int)v[i].impact_type))) + "}";
         times[k] = v[i].time;
         keys[k] = (long)v[i].time * EB_IDX_SPAN + k;   // time, then read order (as DealsJson)
        }
     }
   ArraySort(keys);
   int total = ArraySize(keys);
   datetime cut = 0;
   if(total > EB_CAL_MAX)
     {
      cut = (datetime)(keys[EB_CAL_MAX] / EB_IDX_SPAN);
      to = (datetime)((long)cut - 1);
      if(to <= from)
        {
         ok = false;
         Print("EdgeBridge: too many calendar rows; calendar not sent.");
         return "";
        }
     }
   string list = "";
   for(int s = 0; s < total; s++)
     {
      int k = (int)(keys[s] % EB_IDX_SPAN);
      if(cut > 0 && times[k] >= cut)
         break;
      if(count++ > 0)
         list += ",";
      list += rows[k];
     }
   string curs = "";
   for(int c = 0; c < ArraySize(g_cal_cur); c++)
      curs += (c > 0 ? "," : "") + Q(g_cal_cur[c]);
   return "{" + Kv("contract", Q(EB_CAL_CONTRACT)) + ","
          + Kv("bridge_session", Q(g_session)) + ","
          + Kv("cal_seq", I(g_cal_seq)) + ","
          + Kv("server_time", T(TimeTradeServer())) + ","
          + Kv("gmt_time", T(TimeGMT())) + ","
          + Kv("from", T(from)) + ","
          + Kv("to", T(to)) + ","
          + Kv("currencies", "[" + curs + "]") + ","
          + Kv("values", "[" + list + "]") + "}";
  }

// One calendar post every InpCalendarSec seconds, after the snapshot (OnTimer) and on its own back-off: a calendar
// failure never touches the snapshot's back-off, seq or deal cursor. Only from a connected terminal with an account.
void SendCalendar()
  {
   if(g_cal_off)
      return;
   if(GetTickCount64() < g_cal_due_ms)
      return;
   if(TerminalInfoInteger(TERMINAL_CONNECTED) == 0 || AccountInfoString(ACCOUNT_CURRENCY) == "")
      return;
   g_cal_seq++;   // a number skipped by a failed read is harmless: the app needs it only to rise
   datetime from = 0, to = 0;
   int count = 0;
   bool ok = false;
   string body = CalendarJson(from, to, count, ok);
   if(!ok)
     {
      int err = GetLastError();
      int rwait = g_cal_read_wait[g_cal_reads < 3 ? g_cal_reads : 3];
      g_cal_reads++;
      g_cal_due_ms = GetTickCount64() + (ulong)rwait * 1000;
      Print("EdgeBridge: calendar read failed (error ", err, "); next try in ", rwait, " s.");
      return;
     }
   g_cal_reads = 0;
   char data[];
   char reply[];
   string reply_headers;
   int len = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(len > 0)
      ArrayResize(data, len - 1);   // drop the terminating zero
   string headers = "Content-Type: application/json\r\nAuthorization: Bearer " + g_token + "\r\n"
                    + "Connection: close\r\n";
   ResetLastError();
   int code = WebRequest("POST", g_cal_url, headers, InpTimeoutMs, data, reply, reply_headers);
   string answer = (ArraySize(reply) > 0) ? CharArrayToString(reply, 0, -1, CP_UTF8) : "";
   // stored only when Edge Desk wrote it: {"ok":true,"cal_seq":<this cal_seq>,...}
   bool stored = (code >= 200 && code < 300) && StringFind(answer, "\"ok\":true") >= 0
                 && StringFind(answer, "\"cal_seq\":" + I(g_cal_seq) + ",") >= 0;
   if(stored || code == 409)   // 409: this cal_seq is already stored, not an error
     {
      if(g_cal_fails > 0)
         Print("EdgeBridge: calendar sent again after ", g_cal_fails, " failed attempt(s).");
      g_cal_fails = 0;
      g_cal_due_ms = GetTickCount64() + (ulong)InpCalendarSec * 1000;
      return;
     }
   if(code == 404)
     {
      g_cal_off = true;
      Print("EdgeBridge: the app has news off (404); calendar sending stopped until the EA restarts.");
      return;
     }
   g_cal_fails++;
   int wait = g_backoff[g_cal_fails < 5 ? g_cal_fails - 1 : 4];
   if(wait < InpCalendarSec)
      wait = InpCalendarSec;
   g_cal_due_ms = GetTickCount64() + (ulong)wait * 1000;
   if(code == -1)
     {
      int err = GetLastError();
      if(err == 4014)
         Print("EdgeBridge: WebRequest is not allowed for the calendar URL. Open Tools > Options > Expert Advisors,",
               " tick 'Allow WebRequest for listed URL' and add ", UrlBase(InpUrl));
      else
         Print("EdgeBridge: calendar send failed (error ", err, "); next try in ", wait, " s.");
      return;
     }
   string text = StringSubstr(answer, 0, 200);
   if(code >= 200 && code < 300)
      Print("EdgeBridge: calendar HTTP ", code, " but not an Edge Desk reply (a proxy or login page in the way?);",
            " next try in ", wait, " s.");
   else if(code == 401)
      Print("EdgeBridge: the app refused the token for the calendar (401). The token file must match EDGE_INGEST_TOKEN.");
   else if(code == 413)
      Print("EdgeBridge: calendar too large (413); next try in ", wait, " s.");
   else
      Print("EdgeBridge: the app answered ", code, " to the calendar ", text, "; next try in ", wait, " s.");
  }

//--- event handlers --------------------------------------------------
int OnInit()
  {
   if(!AliasOk(InpAlias))
     {
      Print("EdgeBridge: InpAlias must be a short label such as main (letters, digits, - or _),",
            " never the account number.");
      return INIT_PARAMETERS_INCORRECT;
     }
   if(!UrlOk(InpUrl))
     {
      Print("EdgeBridge: set InpUrl to your app, for example https://host/api/bridge/v1/snapshot",
            " (https only; http is allowed for 127.0.0.1 tests).");
      return INIT_PARAMETERS_INCORRECT;
     }
   if(InpIntervalSec < 1 || InpIntervalSec > 10 || InpHistoryDays < 1 || InpHistoryDays > 365 ||
      InpTimeoutMs < 1000 || InpTimeoutMs > 30000 || InpMaxDeals < 1 || InpMaxDeals > 500)
     {
      Print("EdgeBridge: inputs out of range (interval 1-10 s, below the app's 15 s stale limit;",
            " history 1-365 days, timeout 1000-30000 ms, max deals 1-500).");
      return INIT_PARAMETERS_INCORRECT;
     }
   if(!(InpCalendarSec == 0 || (InpCalendarSec >= 60 && InpCalendarSec <= 3600)))   // K4: one read a minute at most
     {
      Print("EdgeBridge: InpCalendarSec out of range (0 for no calendar, or 60-3600 s).");
      return INIT_PARAMETERS_INCORRECT;
     }
   if(!ReadToken())
      return INIT_FAILED;
   if(SymbolInfoDouble(InpSymbol, SYMBOL_POINT) <= 0.0)
      Print("EdgeBridge: symbol ", InpSymbol, " is not known yet; set InpSymbol to the broker's EUR/USD name.");
   g_session = NewSession();
   g_seq = 0;
   g_cursor = (datetime)((long)TimeTradeServer() - (long)InpHistoryDays * 86400);
   g_pending = "init";
   g_fails = 0;
   g_retry_ms = 0;
   g_last_ms = 0;
   g_waiting = false;
   g_cal_seq = 0;
   g_cal_due_ms = 0;
   g_cal_fails = 0;
   g_cal_reads = 0;
   g_cal_url = CalendarUrl(InpUrl);
   g_cal_off = (InpCalendarSec == 0 || g_cal_url == "");
   if(!EventSetTimer(InpIntervalSec))
     {
      Print("EdgeBridge: the timer did not start (error ", GetLastError(), ").");
      return INIT_FAILED;
     }
   Print("EdgeBridge ", EB_CONTRACT, " started: alias ", InpAlias, ", session ", g_session,
         ". Read-only: it only reads the account and sends snapshots.");
   if(g_cal_off)
      Print("EdgeBridge calendar off.", (InpCalendarSec != 0 && g_cal_url == "") ?
            " InpUrl does not end with /api/bridge/v1/snapshot." : "");
   else
      Print("EdgeBridge calendar edge-calendar/2 on: every ", InpCalendarSec,
            " s, EUR and USD, medium and high importance, holidays.");
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   Print("EdgeBridge stopped (reason ", reason, ").");
  }

void OnTimer()
  {
   Send();
   SendCalendar();
  }

void OnTradeTransaction(const MqlTradeTransaction &trans, const MqlTradeRequest &request,
                        const MqlTradeResult &result)
  {
   if(g_pending == "")
      g_pending = "trade";
   if(g_pending == "trade" && GetTickCount64() - g_last_ms >= 1000)
      Send();   // at most one immediate send per second; later events wait for the timer
  }
//+------------------------------------------------------------------+
