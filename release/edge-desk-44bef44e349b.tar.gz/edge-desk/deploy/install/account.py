#!/usr/bin/env python3
"""The MT5 account behind the app, per server (run by deploy/install/stage2.sh as root, with the system Python;
standard library only). Owner, 30 Oct 2026: the FundedNext trial account is replaced by his paid FundedNext $6K
account, and changing accounts must be one paste of the install line.

Each MT5 account gets its own alias, `acct-` + 8 letters (a-p: the first 4 bytes of HMAC-SHA256(key, "<login>"), each
half-byte one letter, so the daily export never takes it for an account number). The server name is not used: the same
account keeps its alias when its server is typed another way or FundedNext moves it. The key is 32 random bytes made
once on this server
(/etc/edge-desk/account-key, root, 0600) and never leaves it, so the alias cannot be turned back into the account
number. The same account typed again gets the same alias and keeps its journal; another account gets another alias
and is never merged into this one's (bridge/CONTRACT.md "Account": "Use a new alias for another account").

/etc/edge-desk/account (root, 0600) holds KEY=value lines and nothing secret:
  ALIAS=acct-xxxxxxxx            the alias the config and the EA both use (8 letters a-p)
  FUNDED_TYPE=stellar2|stellar1|off, FUNDED_STAGE=phase1|phase2|funded, FUNDED_SIZE=<USD, digits>
The account number, the server name and the password are never written here, printed or kept by this script: they
are read from the installer's root-only login file (install.sh "ask"), which stage2 shreds once MT5 is set up.
A server set up before this release has no account file; it keeps the config's alias ("main") until a new account
number is typed.

  python3 -I account.py --secrets /etc/edge-desk/install --key /etc/edge-desk/account-key \
      --account /etc/edge-desk/account
  python3 -I account.py --account /etc/edge-desk/account --alias      (prints the alias, "main" when none is saved)
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import os
import re
import secrets as _secrets
import sys
import tempfile
from pathlib import Path

LEGACY_ALIAS = "main"
ALIAS_RE = re.compile(r"acct-[a-p]{8}")
LOGIN_RE = re.compile(r"[0-9]{3,20}")
FUNDED_TYPES = ("stellar2", "stellar1", "off")
FUNDED_STAGES = ("phase1", "phase2", "funded")
SIZE_RE = re.compile(r"[1-9][0-9]{2,8}")
KEYS = ("ALIAS", "FUNDED_TYPE", "FUNDED_STAGE", "FUNDED_SIZE")


def _lines(text: str) -> dict[str, str]:
    out = {}
    for line in text.splitlines():
        k, sep, v = line.partition("=")
        if sep:
            out[k.strip()] = v
    return out


def derive_alias(key: bytes, login: str) -> str:
    mac = hmac.new(key, login.strip().encode(), hashlib.sha256).digest()
    return "acct-" + "".join("abcdefghijklmnop"[b >> 4] + "abcdefghijklmnop"[b & 15] for b in mac[:4])


def read_account(path: Path) -> dict[str, str]:
    try:
        got = _lines(path.read_text())
    except FileNotFoundError:
        return {}
    return {k: v for k, v in got.items() if k in KEYS}


def alias_of(path: Path) -> str:
    alias = read_account(path).get("ALIAS", "")
    return alias if ALIAS_RE.fullmatch(alias) else LEGACY_ALIAS


def _key(path: Path) -> bytes:
    try:
        text = path.read_text().strip()
    except FileNotFoundError:
        path.parent.mkdir(parents=True, exist_ok=True)
        text = _secrets.token_hex(32)
        _write(path, text + "\n")
    if not re.fullmatch(r"[0-9a-f]{64}", text):
        raise ValueError(f"{path} is not a 64-character hex key")
    return bytes.fromhex(text)


def _write(path: Path, text: str) -> None:
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix="." + path.name + ".")
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def funded_answers(text: str) -> dict[str, str]:
    """install.sh's answers about the FundedNext account, checked. FUNDED_TYPE=off needs nothing else."""
    got = _lines(text)
    kind = got.get("FUNDED_TYPE", "")
    if kind not in FUNDED_TYPES:
        raise ValueError("FUNDED_TYPE must be stellar2, stellar1 or off")
    if kind == "off":
        return {"FUNDED_TYPE": "off"}
    stage, size = got.get("FUNDED_STAGE", ""), got.get("FUNDED_SIZE", "")
    if stage not in FUNDED_STAGES:
        raise ValueError("FUNDED_STAGE must be phase1, phase2 or funded")
    if kind == "stellar1" and stage == "phase2":
        raise ValueError("Stellar 1-Step has no phase 2")
    if not SIZE_RE.fullmatch(size):
        raise ValueError("FUNDED_SIZE must be the account size in USD, digits only")
    return {"FUNDED_TYPE": kind, "FUNDED_STAGE": stage, "FUNDED_SIZE": size}


def update(secrets_dir: Path, key_path: Path, account_path: Path) -> None:
    """A new login (secrets_dir/mt5-login) sets the alias; new answers (secrets_dir/funded) replace the FUNDED lines
    and are then removed. With neither, nothing is written."""
    cur = read_account(account_path)
    new = dict(cur)
    login_file, funded_file = secrets_dir / "mt5-login", secrets_dir / "funded"
    if login_file.exists():
        got = _lines(login_file.read_text())
        login, server = got.get("MT5_LOGIN", ""), got.get("MT5_SERVER", "")
        if not LOGIN_RE.fullmatch(login) or not server.strip():
            raise ValueError("the saved MT5 login needs an account number (digits) and a server name")
        new["ALIAS"] = derive_alias(_key(key_path), login)
        if new["ALIAS"] != cur.get("ALIAS"):            # another account: the old one's limits are not its limits
            for k in ("FUNDED_TYPE", "FUNDED_STAGE", "FUNDED_SIZE"):
                new.pop(k, None)
    if funded_file.exists():
        for k in ("FUNDED_TYPE", "FUNDED_STAGE", "FUNDED_SIZE"):
            new.pop(k, None)
        new.update(funded_answers(funded_file.read_text()))
    if new != cur or (new and not account_path.exists()):
        account_path.parent.mkdir(parents=True, exist_ok=True)
        _write(account_path, "".join(f"{k}={new[k]}\n" for k in KEYS if k in new))
    funded_file.unlink(missing_ok=True)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--account", required=True)
    ap.add_argument("--secrets")
    ap.add_argument("--key")
    ap.add_argument("--alias", action="store_true", help="print the saved alias and exit")
    a = ap.parse_args(argv)
    if a.alias:
        print(alias_of(Path(a.account)))
        return 0
    if not a.secrets or not a.key:
        ap.error("--secrets and --key are needed to update the account file")
    try:
        update(Path(a.secrets), Path(a.key), Path(a.account))
    except ValueError as exc:
        print(f"account: {exc}", file=sys.stderr)
        return 2
    print(f"account: alias {alias_of(Path(a.account))}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
