# Host guard for the Edge Desk installer (sourced; make_release.py also copies it into install.sh, so the bootstrap
# checks the host before it downloads anything). The owner types no hostname or machine id: the meme bot's host is
# known by its own markers (meme-snipe ops/install.sh): any zeroed-* systemd unit, /var/lib/zeroed, or the
# zeroed-signer or zeroed-worker user. deploy/check.py's host line uses the same markers.
# EDGE_ROOT is empty on a server; only the tests point it at a fake root.

EDGE_MIN_MEM_KB=1572864   # 1.5 GiB: refuses the 1 GB plan (about 0.96 GiB) widely, passes the 2 GB plan

edge_meme_markers() {     # prints one line per marker found
  local r="${EDGE_ROOT:-}" d f
  for d in etc/systemd/system lib/systemd/system usr/lib/systemd/system run/systemd/system run/systemd/transient; do
    for f in "$r/$d"/zeroed-*; do
      [ -e "$f" ] || [ -L "$f" ] && printf '%s\n' "/$d/${f##*/}"
    done
  done
  [ -e "$r/var/lib/zeroed" ] && printf '%s\n' "/var/lib/zeroed"
  for f in zeroed-signer zeroed-worker; do
    grep -q "^$f:" "$r/etc/passwd" 2>/dev/null && printf 'user %s\n' "$f"
  done
  return 0
}

edge_mem_kb() {
  awk '$1 == "MemTotal:" { print $2; exit }' "${EDGE_ROOT:-}/proc/meminfo" 2>/dev/null || true
}

edge_guard() {            # 0 when this host may take the Edge Desk; otherwise a reason on stderr
  local found kb
  found="$(edge_meme_markers)"
  if [ -n "$found" ]; then
    printf 'Install stopped: this is the meme bot'\''s server (found: %s). The Edge Desk never runs there.\n' \
      "$(printf '%s' "$found" | paste -sd, - | sed 's/,/, /g')" >&2
    return 1
  fi
  kb="$(edge_mem_kb)"
  if ! [[ "$kb" =~ ^[0-9]{1,12}$ ]]; then
    printf 'Install stopped: the RAM size could not be read from /proc/meminfo.\n' >&2
    return 1
  fi
  if [ "$kb" -lt "$EDGE_MIN_MEM_KB" ]; then
    awk -v k="$kb" 'BEGIN { printf "Install stopped: this server has %.2f GiB of RAM; the app and MT5 need the 2 GB plan (at least 1.5 GiB reported).\n", k / 1048576 }' >&2
    return 1
  fi
  return 0
}
