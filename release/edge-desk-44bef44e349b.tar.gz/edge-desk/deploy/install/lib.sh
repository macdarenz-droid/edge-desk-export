# Helpers for deploy/install/stage2.sh (sourced). Output goes to the edge-desk-install unit's journal, so nothing
# here ever prints a secret value: commands' own output goes to per-step log files, and only their last lines are
# shown when a step fails (none of these commands is given a secret: secrets reach programs only through files
# with mode 0600 or stdin).

LOG_DIR="${LOG_DIR:-/var/log/edge-desk-install}"
STATE="${STATE:-/var/lib/edge-desk-install}"
STEP=0
SOFT_FAILED=()

say() { printf '%s\n' "$*"; }

# run_fn FUNCTION LOG: the function in a subshell with errexit really on. (Called straight from an `if`, bash ignores
# set -e inside the function, so a failing command in the middle of a step would go unnoticed.) Steps pass results
# to later steps through files in $STATE, never through variables.
# So run_fn is never called from an `if`, `&&` or `||` itself: it leaves the exit status in RC.
run_fn() {
  set +e
  ( set -e; "$1" ) >"$2" 2>&1
  RC=$?
  set -e
}

# step "title" function: a step that must work; the install stops when it fails.
step() {
  local title="$1" fn="$2" log
  STEP=$((STEP + 1))
  log="$LOG_DIR/$(printf '%02d' "$STEP")-$fn.log"
  printf "step %d of %d: %s\n" "$STEP" "$TOTAL" "$title"
  run_fn "$fn" "$log"
  if [ "$RC" != 0 ]; then
    say "  failed. Last lines of $log:"
    tail -n 20 "$log" | sed 's/^/  | /'
    printf 'failed step %d: %s\n' "$STEP" "$title" > "$STATE/result"
    say "Install stopped at step $STEP. Fix what the lines above say, then paste the install line again."
    exit 1
  fi
}

# soft_step "title" function: a step that may wait for something outside the server (a broker, a login); when it
# fails, the install goes on and the finish lists it as missing.
soft_step() {
  local title="$1" fn="$2" log
  STEP=$((STEP + 1))
  log="$LOG_DIR/$(printf '%02d' "$STEP")-$fn.log"
  printf "step %d of %d: %s\n" "$STEP" "$TOTAL" "$title"
  run_fn "$fn" "$log"
  if [ "$RC" != 0 ]; then
    say "  not finished. Last lines of $log:"
    tail -n 12 "$log" | sed 's/^/  | /'
    SOFT_FAILED+=("$title")
  fi
}

# fetch_pinned URL SHA256 OUT: download to OUT only if its sha256 matches the pin.
fetch_pinned() {
  local url="$1" sha="$2" out="$3"
  [[ "$sha" =~ ^[0-9a-f]{64}$ ]] || { echo "no pin for $url"; return 1; }
  if [ -f "$out" ] && echo "$sha  $out" | sha256sum -c --quiet - >/dev/null 2>&1; then
    return 0
  fi
  rm -f "$out.part"
  curl -fsSL --proto '=https' --tlsv1.2 --retry 3 --retry-delay 5 -A 'curl/8.5.0' -o "$out.part" "$url" || return 1
  if ! echo "$sha  $out.part" | sha256sum -c --quiet -; then
    echo "$url does not match its pinned sha256; nothing from it is used"
    rm -f "$out.part"
    return 1
  fi
  mv -f "$out.part" "$out"
}

# set_env KEY: writes KEY=<value of the shell variable VALUE> to the app's environment file (root:edge 0640).
# The value travels only through bash builtins (no argv).
ENV_FILE="${ENV_FILE:-/etc/edge-desk/env}"
set_env() {
  local k="$1" tmp
  tmp="$(mktemp "$(dirname "$ENV_FILE")/.env.XXXXXX")"
  { grep -v "^$k=" "$ENV_FILE" 2>/dev/null || true; printf '%s=%s\n' "$k" "$VALUE"; } > "$tmp"
  chown root:edge "$tmp" 2>/dev/null || true
  chmod 0640 "$tmp"
  mv -f "$tmp" "$ENV_FILE"
}

env_has() {   # env_has KEY: true when the environment file holds a non-empty value for KEY
  grep -q "^$1=." "$ENV_FILE" 2>/dev/null
}

apt_get() { DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=600 -q -y "$@"; }
