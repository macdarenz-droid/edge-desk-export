#!/usr/bin/env python3
"""Turn Part B on or off in the release's config/app.toml and set this server's MT5 account (run by
deploy/install/stage2.sh, as root, with the system Python; standard library only). Only these values change: [feed]
enabled, [export] enabled and [export] repo; and, from the server's account file (deploy/install/account.py), [account]
alias and the [funded] limits of his FundedNext account type; and, from his choices file (install.sh ask_photos),
[photos] enabled. Every ceiling stays as it is, and the result is read back with tomllib before it replaces the file.

  python3 render_config.py <app.toml> --part-b on|off --export-repo owner/name [--account-file /etc/edge-desk/account]

FundedNext's limits by account type (help.fundednext.com, read 30 Oct 2026; terms change, so they are read again
before each change here; research/departments/COST/sources/FUNDEDNEXT.md has the older reading of 13 Oct):
- Stellar 2-Step, article 17255124 (updated 2 Oct 2026): "Your account must not lose more than 5% of the initial
  balance in a single trading day in either phase." / "Your account balance or equity must not drop below 90% of the
  initial balance at any point in either phase." The FundedNext Account keeps 5% and 10%.
- Stellar 1-Step, article 17252927 (updated 30 Sep 2026): 3% a day; "Your account balance or equity must not drop
  below 94% of the initial balance at any point." The FundedNext Account keeps 3% and 6%.
- Both, the FundedNext Account stage only: "FundedNext requires traders to limit risk to a maximum of 3% at any given
  time in the FundedNext Account." The challenge phases have no such cap, so it is left "" (not set) there.
- Profit targets and minimum trading days: 2-Step "You must reach an 8% profit in Phase 1 and a 5% profit in Phase 2"
  and "at least 5 separate calendar days per phase"; 1-Step "a 10% profit" and "at least 2 separate calendar days";
  "No Profit Target required in the FundedNext Account".
Only these two products are sold at $6K (fundednext.com's plan list, read 30 Oct 2026).
"""
from __future__ import annotations

import argparse
import os
import re
import sys
import tempfile
import tomllib
from pathlib import Path

REPO_RE = re.compile(r"[A-Za-z0-9-]{1,39}/[A-Za-z0-9._-]{1,100}")
RESEARCH_REPOS = {"forex-signal"}          # app/config.py refuses it too
ALIAS_RE = re.compile(r"acct-[a-p]{8}|main")
# FundedNext's limits by account type: (daily loss %, maximum loss %), of the initial balance (sources above)
FUNDED_LIMITS = {"stellar2": (5, 10), "stellar1": (3, 6)}
FUNDED_STAGE_RISK_CAP = 3                   # % of the initial balance, FundedNext Account stage only
# Profit target % and minimum trading days of each challenge phase (same articles: 2-Step "8% profit in Phase 1 and a
# 5% profit in Phase 2", "at least 5 separate calendar days per phase"; 1-Step "a 10% profit", "at least 2 separate
# calendar days"); the FundedNext Account has neither.
FUNDED_PHASES = {("stellar2", "phase1"): (8, 5), ("stellar2", "phase2"): (5, 5), ("stellar1", "phase1"): (10, 2)}
FUNDED_KEYS = ("enabled", "initial_balance", "daily_loss_pct", "max_loss_pct", "risk_cap_pct", "product", "stage",
               "target_pct", "min_days")
CHANGES = {("feed", "enabled"), ("export", "enabled"), ("export", "repo")}
CHOICE_CHANGES = {("photos", "enabled")}    # his own choices from install.sh (the photo journal)
ACCOUNT_CHANGES = {("account", "alias")} | {("funded", k) for k in FUNDED_KEYS}


def _set(text: str, section: str, key: str, value: str) -> str:
    """Replace `key = ...` inside [section] only, keeping the line's comment."""
    head = re.search(rf"(?m)^\[{re.escape(section)}\]\s*$", text)
    if head is None:
        raise ValueError(f"[{section}] is missing")
    nxt = re.search(r"(?m)^\[", text[head.end():])
    end = head.end() + (nxt.start() if nxt else len(text) - head.end())
    body = text[head.end():end]
    new, n = re.subn(rf"(?m)^({re.escape(key)}\s*=\s*)(\"[^\"]*\"|\S+)", lambda m: m.group(1) + value, body, count=1)
    if n != 1:
        raise ValueError(f"[{section}] {key} is missing")
    return text[:head.end()] + new + text[end:]


def _account(path: Path) -> dict[str, str]:
    out = {}
    for line in path.read_text().splitlines():
        k, sep, v = line.partition("=")
        if sep:
            out[k.strip()] = v.strip()
    return out


def _render_account(text: str, acct: dict[str, str]) -> str:
    """[account] alias and [funded] from the account file; a key it does not hold changes nothing."""
    alias = acct.get("ALIAS")
    if alias is not None:
        if not ALIAS_RE.fullmatch(alias):
            raise ValueError("the account file's ALIAS is not acct- and 8 letters a-p")
        text = _set(text, "account", "alias", f'"{alias}"')
    kind = acct.get("FUNDED_TYPE", "off")    # the account file decides [funded]: no answers = no limits
    if kind == "off":                       # every value blank again: a re-paste may reuse an already rendered file
        text = _set(text, "funded", "enabled", "false")
        for k in FUNDED_KEYS[1:]:
            text = _set(text, "funded", k, '""')
        return text
    if kind not in FUNDED_LIMITS:
        raise ValueError("the account file's FUNDED_TYPE is not stellar2, stellar1 or off")
    stage, size = acct.get("FUNDED_STAGE"), acct.get("FUNDED_SIZE", "")
    if stage not in ("phase1", "phase2", "funded") or not re.fullmatch(r"[1-9][0-9]{2,8}", size):
        raise ValueError("the account file needs FUNDED_STAGE (phase1, phase2 or funded) and FUNDED_SIZE (digits)")
    if stage != "funded" and (kind, stage) not in FUNDED_PHASES:
        raise ValueError("Stellar 1-Step has no phase 2")
    daily, total = FUNDED_LIMITS[kind]
    target, days = FUNDED_PHASES.get((kind, stage), ('""', '""'))
    values = {"enabled": "true", "initial_balance": size, "daily_loss_pct": str(daily), "max_loss_pct": str(total),
              "risk_cap_pct": str(FUNDED_STAGE_RISK_CAP) if stage == "funded" else '""',
              "product": f'"{kind}"', "stage": f'"{stage}"', "target_pct": str(target), "min_days": str(days)}
    for k in FUNDED_KEYS:
        text = _set(text, "funded", k, values[k])
    return text


def _render_choices(text: str, choices: dict[str, str]) -> str:
    photos = choices.get("PHOTOS")
    if photos is None:
        return text
    if photos not in ("on", "off"):
        raise ValueError("the choices file's PHOTOS is not on or off")
    return _set(text, "photos", "enabled", "true" if photos == "on" else "false")


def render(path: Path, part_b: bool, export_repo: str, account_file: Path | None = None,
           choices_file: Path | None = None) -> None:
    if not REPO_RE.fullmatch(export_repo) or ".." in export_repo:
        raise ValueError("the export repo must be owner/name")
    if export_repo.split("/", 1)[1].lower() in RESEARCH_REPOS:
        raise ValueError("the research repo is never the export repo")
    text = path.read_text()
    before = tomllib.loads(text)
    flag = "true" if part_b else "false"
    text = _set(text, "feed", "enabled", flag)
    text = _set(text, "export", "enabled", flag)
    text = _set(text, "export", "repo", f'"{export_repo}"')
    allowed = set(CHANGES)
    if account_file is not None and account_file.exists():
        text = _render_account(text, _account(account_file))
        allowed |= ACCOUNT_CHANGES
    if choices_file is not None and choices_file.exists():
        text = _render_choices(text, _account(choices_file))
        allowed |= CHOICE_CHANGES
    after = tomllib.loads(text)
    changed = {(s, k) for s in before for k in before[s] if before[s][k] != after.get(s, {}).get(k)}
    if not changed <= allowed:
        raise ValueError(f"unexpected change: {sorted(changed)}")
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".app.toml.")
    with os.fdopen(fd, "w") as fh:
        fh.write(text)
    os.chmod(tmp, 0o644)
    os.replace(tmp, path)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("config")
    ap.add_argument("--part-b", choices=("on", "off"), required=True)
    ap.add_argument("--export-repo", required=True)
    ap.add_argument("--account-file", help="the server's account file (deploy/install/account.py); skipped if absent")
    ap.add_argument("--choices-file", help="his choices from install.sh (PHOTOS=on|off); skipped if absent")
    a = ap.parse_args(argv)
    try:
        render(Path(a.config), a.part_b == "on", a.export_repo,
               Path(a.account_file) if a.account_file else None, Path(a.choices_file) if a.choices_file else None)
    except ValueError as exc:
        print(f"render_config: {exc}", file=sys.stderr)
        return 2
    print(f"config: Part B {a.part_b}, export repo {a.export_repo}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
