#!/usr/bin/env bash
# edge-desk-install-status: where the Edge Desk install stands (installed by stage2.sh). Root only. Prints the
# install unit's progress lines and the last server check; never a secret (none is ever written to that journal).
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "run as root (sudo -i first)"; exit 1; }
STATE=/var/lib/edge-desk-install
printf 'install: %s (%s)\n' "$(cat "$STATE/result" 2>/dev/null || echo 'not started')" \
  "$(systemctl is-active edge-desk-install 2>/dev/null || true)"
journalctl -u edge-desk-install -o cat --no-pager -n 200 2>/dev/null | grep -E '^(step|  |missing|Install|Server)' || true
if [ "${1:-}" = --login ]; then
  # the dashboard login, shown only on this console when asked for
  grep '^EDGE_DASHBOARD_TOKEN=' /etc/edge-desk/env | cut -d= -f2-
fi
