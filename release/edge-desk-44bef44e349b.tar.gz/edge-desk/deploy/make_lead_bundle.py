#!/usr/bin/env python3
"""Build the lead worker's pinned copy (B3) in a checkout of this research repo, on any machine with git; then copy
the folder to the server (no credential for this repo goes to the server).

    python3 desk/deploy/make_lead_bundle.py --out /tmp/lead-bundle [--repo .] [--commit 77ed1b42...]

Each file is taken from the checkout when its bytes there have the pinned sha256, else from its pinned commit with
`git show` (forward tree, audit_inputs.py and the picks' frozen files: the STATS commit; DATA's files: DEPS.json
data_commit; COST's: cost_commit). Every file is sha256-checked against its pin; the forward tree sha256 must be the
one STATS's red team approved (app/suggest/bundle.py FORWARD_TREE_SHA256). Then MANIFEST.json is written and the
copy is checked with app.suggest.bundle.verify, the same check the server runs at every start.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.suggest import bundle as B  # noqa: E402


def _git(repo: Path, *args) -> bytes:
    return subprocess.run(["git", "-C", str(repo), "--no-replace-objects", *args], capture_output=True,
                          check=True).stdout


def _bytes(repo: Path, rel: str, commit: str, want: str | None) -> bytes:
    p = repo / rel
    if p.is_file() and not p.is_symlink():
        data = p.read_bytes()
        if want is None or B.sha256_bytes(data) == want:
            return data
    data = _git(repo, "show", f"{commit}:{rel}")
    if want is not None and B.sha256_bytes(data) != want:
        raise B.BundleRefused(f"{rel} at {commit[:8]} has sha256 {B.sha256_bytes(data)}, not the pinned {want}")
    return data


def build(out: Path, repo: Path, commit: str = B.STATS_COMMIT) -> dict:
    out, repo = Path(out), Path(repo)
    if commit != B.STATS_COMMIT:
        raise B.BundleRefused("the app pins one STATS commit (app/suggest/bundle.py); change both together")
    have = subprocess.run(["git", "-C", str(repo), "cat-file", "-e", f"{commit}^{{commit}}"],
                          capture_output=True).returncode == 0
    files: dict[str, bytes] = {}
    if have:                                   # the file list and bytes of the STATS commit itself
        tree = _git(repo, "ls-tree", "-r", "--name-only", commit, B.FWD_REL).decode().split("\n")
        for rel in [f for f in tree if f and f not in B.EXCLUDED] + [B.AUDIT_INPUTS_REL]:
            files[rel] = _git(repo, "show", f"{commit}:{rel}")
    else:                                      # a shallow checkout (CI): the tracked files; the tree sha256 decides
        tree = _git(repo, "ls-files", "--", B.FWD_REL, B.AUDIT_INPUTS_REL).decode().split("\n")
        for rel in [f for f in tree if f and f not in B.EXCLUDED]:
            files[rel] = (repo / rel).read_bytes()
    shas = {k: B.sha256_bytes(v) for k, v in files.items()}
    if B.tree_sha256({f: shas[f] for f in B.forward_files(shas)}) != B.FORWARD_TREE_SHA256:
        raise B.BundleRefused("the forward tree at the STATS commit is not the approved one")
    deps = json.loads(files[f"{B.FWD_REL}/DEPS.json"])
    for rel, sha in deps["files"].items():
        files[rel] = _bytes(repo, rel, deps["data_commit"], sha)
    for rel, sha in deps["cost"]["files"].items():
        files[rel] = _bytes(repo, rel, deps["cost"]["cost_commit"], sha)
    for rel in deps["picks"]:
        pick = json.loads(files[f"{B.FWD_REL}/{rel}"])
        for f, sha in pick["frozen_files"].items():
            files[f] = _bytes(repo, f, commit, sha)
    if out.exists():
        shutil.rmtree(out)
    for rel, data in files.items():
        p = out / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    man = {"stats_commit": commit, "forward_tree_sha256": B.FORWARD_TREE_SHA256,
           "data_commit": deps["data_commit"], "cost_commit": deps["cost"]["cost_commit"],
           "files": {k: B.sha256_bytes(v) for k, v in sorted(files.items())}}
    (out / B.MANIFEST).write_text(json.dumps(man, indent=1, sort_keys=True) + "\n")
    return B.verify(out)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--out", required=True)
    ap.add_argument("--repo", default=".")
    ap.add_argument("--commit", default=B.STATS_COMMIT)
    a = ap.parse_args()
    man = build(Path(a.out), Path(a.repo), a.commit)
    print(f"lead bundle: {len(man['files'])} files, STATS {man['stats_commit'][:8]}, forward tree "
          f"{man['forward_tree_sha256'][:8]}")


if __name__ == "__main__":
    main()
