"""research.common: the edge hunt's shared, tested toolkit (DATA department).

Part 1 (this file's siblings): eras, loaders, asof, looks, access. Part 2 (simulators, cost hook,
baselines, leak helper, parity) lives in the same package. See README.md.

Importing this package installs a process-wide runtime guard (``audit``): a ``sys.addaudithook``
that refuses opening a registered price file for reading unless the FIRST non-library caller is one
of the trusted readers -- the loaders (load_m1 / load_bars), research/common/files.py,
looks.sha256_file or research/data/ -- decided by code-object identity, not by file name. It is one
defence-in-depth layer over the loaders' access rules, ACCESS_LOG.jsonl and the static guard test;
see ``audit`` for what it protects, why it fails closed, and why it never touches synthetic test data.
"""
# Load the loaders (and numpy / pandas) fully BEFORE the guard arms, so (a) the hook never fires
# during their own import and cannot trigger a circular pandas re-import from inside the snapshot
# build, and (b) the registry the hook protects is always present even if a caller never imports the
# loaders itself. The guard is installed last; audit hooks cannot be removed once added.
from . import loaders as _loaders       # noqa: F401  (imported for its import-time side effects)
from . import audit as _audit

_audit.install()

