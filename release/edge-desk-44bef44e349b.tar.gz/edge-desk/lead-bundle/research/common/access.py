"""ACCESS_LOG.jsonl writer used by the loaders (docs/EDGE_HUNT.md sections 3 and 5).

Every C, T or locked read appends one line to research/departments/<DEPT>/ACCESS_LOG.jsonl:
  {"utc", "dept", "study", "era", "first_ts", "last_ts", "code_sha256", "frozen_sha256", "run_id"}
plus "common_sha256" (common_sha256(): the shared research/common/*.py code), "instrument",
"datasets", "override", "ledger_id" and the loaders' gate fields for traceability.

The main script (audit finding #6). ``main_info()`` finds the code the interpreter really runs,
not ``__main__.__file__`` or ``sys.argv[0]`` (both can be reassigned by the script):
- the command line from /proc/self/cmdline (``sys.orig_argv`` where /proc is missing) names a
  script file or a ``-m`` module; ``-c``, ``-`` (stdin) and an interactive session have no main
  file, so a C, T or locked read from them is refused;
- the main module's frame is the bottom frame of the main thread's stack (after the runpy frames
  of a ``-m`` run); its code object's file must agree with the command line;
- ``code_sha256_of_main()`` hashes that file and refuses when the file's current bytes do not
  compile to the code that is running (a script that rewrote itself after it started).
Under pytest the main is pytest's own entry file (``main_info()['pytest']`` is True).

``run_id()`` names this process's run: pid, process start time and a random nonce, fixed at
import (a forked worker keeps its parent's run id). The loaders allow several reads in one run and
refuse a C or T read of a frozen pick whose ACCESS_LOG already holds another run's read.

Python docs: ``sys.orig_argv``, ``sys._getframe``, ``sys._current_frames``, ``compile``
(https://docs.python.org/3/library/sys.html, functions.html); code objects compare equal when
they hold the same bytecode, constants and names (checked on Python 3.13 by the tests).
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import sys
import sysconfig
import threading
import time
from pathlib import Path

from .looks import check_dept, dept_dir, sha256_file, utc_now

_RUNPY_FILES = frozenset({"<frozen runpy>", os.path.join(sysconfig.get_paths()["stdlib"], "runpy.py")})
_PYTEST_NAMES = frozenset({"pytest", "py.test"})


def _process_start() -> str:
    """Start time of this process in clock ticks since boot (/proc/self/stat field 22), else now."""
    try:
        stat = Path("/proc/self/stat").read_text()
        return stat.rsplit(")", 1)[1].split()[19]
    except (OSError, IndexError):
        return str(time.time_ns())


def _make_run_id():
    rid = f"{os.getpid()}-{_process_start()}-{secrets.token_hex(8)}"

    def run_id() -> str:
        """This process's run id (fixed at import; inherited by a forked child)."""
        return rid
    return run_id


run_id = _make_run_id()


def _cmdline() -> list[str]:
    try:
        raw = Path("/proc/self/cmdline").read_bytes()
        args = [a.decode("utf-8", "surrogateescape") for a in raw.split(b"\0")]
        if args and args[-1] == "":
            args.pop()
        if args:
            return args
    except OSError:
        pass
    return list(getattr(sys, "orig_argv", None) or [])


def parse_python_args(args: list[str]):
    """('script', path) or ('module', name) from a python command line, else (None, None) for
    -c, - (stdin), --help/--version or no target."""
    i, n = 1, len(args)
    while i < n:
        a = args[i]
        if a == "--":
            return ("script", args[i + 1]) if i + 1 < n and args[i + 1] != "-" else (None, None)
        if a == "-":
            return None, None
        if a.startswith("--"):
            if a == "--check-hash-based-pycs":
                i += 2
                continue
            if a.startswith("--help") or a == "--version":
                return None, None
            i += 1
            continue
        if a.startswith("-") and len(a) > 1:
            skip_next = False
            for j in range(1, len(a)):
                c = a[j]
                if c in "cm":
                    val = a[j + 1:] or (args[i + 1] if i + 1 < n else "")
                    if c == "c" or not val:
                        return None, None
                    return "module", val
                if c in "WX":
                    skip_next = not a[j + 1:]
                    break
            i += 2 if skip_next else 1
            continue
        return "script", a
    return None, None


def _bottom_module_frame(frame):
    chain = []
    while frame is not None:
        chain.append(frame)
        frame = frame.f_back
    chain.reverse()
    k = 0
    while k < len(chain) and chain[k].f_code.co_filename in _RUNPY_FILES:
        k += 1
    if k < len(chain) and chain[k].f_code.co_name == "<module>":
        return chain[k]
    return None


def _main_frame():
    tops = [sys._getframe(1)]
    try:
        tops.append(sys._current_frames().get(threading.main_thread().ident))
    except Exception:                          # pragma: no cover - interpreter without threads
        pass
    for top in tops:
        if top is not None:
            f = _bottom_module_frame(top)
            if f is not None:
                return f
    return None


def main_info() -> dict | None:
    """{'path', 'code', 'kind', 'pytest'} of the main script, or None (no main file, or the
    command line and the running main code disagree)."""
    kind, val = parse_python_args(_cmdline())
    if kind is None:
        return None
    fr = _main_frame()
    if fr is None:
        return None
    fn = fr.f_code.co_filename
    if not os.path.isabs(fn) or not os.path.isfile(fn):
        return None
    p = Path(fn)
    if kind == "script":
        s = Path(os.path.normpath(val))
        if s.is_absolute():
            try:
                if not os.path.samefile(s, p):
                    return None
            except OSError:
                return None
        elif ".." in s.parts or tuple(p.parts[-len(s.parts):]) != s.parts:
            return None
    else:
        mod = tuple(val.split("."))
        as_pkg = p.name == "__main__.py" and tuple(p.parts[-len(mod) - 1:-1]) == mod
        as_mod = p.suffix == ".py" and tuple(p.parts[-len(mod):-1]) + (p.stem,) == mod
        if not (as_pkg or as_mod):
            return None
    pytest = (p.name in _PYTEST_NAMES or (p.name == "__main__.py" and p.parent.name == "pytest")
              or (kind == "module" and val in _PYTEST_NAMES))
    return {"path": str(p), "code": fr.f_code, "kind": kind, "pytest": bool(pytest)}


def main_code_path() -> str | None:
    info = main_info()
    return info["path"] if info else None


def code_sha256_of_main() -> str:
    """sha256 of the main script file; refused (PermissionError) with no main file, or when the
    file's current bytes do not compile to the code that is running."""
    info = main_info()
    if not info:
        raise PermissionError("C, T or locked reads must run from a script file (python3 <file> or "
                              "python3 -m <module>; not -c, stdin or an interactive session)")
    path = info["path"]
    try:
        data = Path(path).read_bytes()
    except OSError as e:
        raise PermissionError(f"cannot hash the calling script {path}: {e}") from None
    try:
        code = compile(data, path, "exec", dont_inherit=True)
    except (SyntaxError, ValueError):
        code = None
    if code != info["code"]:
        raise PermissionError(f"the main script {path} on disk is not the code that is running "
                              "(changed after it started)")
    return hashlib.sha256(data).hexdigest()


def common_sha256() -> str:
    """sha256 over research/common/*.py (sorted by name; each file's name, a NUL, its sha256 and
    a newline), so an ACCESS_LOG line ties a read to the exact shared code (EDGE_HUNT section 4
    item 2: FROZEN.json pins every imported research/common file)."""
    h = hashlib.sha256()
    for p in sorted(Path(__file__).resolve().parent.glob("*.py")):
        h.update(p.name.encode() + b"\0" + sha256_file(p).encode() + b"\n")
    return h.hexdigest()


def access_log_path(dept: str):
    return dept_dir(dept) / "ACCESS_LOG.jsonl"


def log_access(dept, study, era, first_ts, last_ts, code_sha256, frozen_sha256, **extra) -> dict:
    check_dept(dept)
    row = {"utc": utc_now(), "dept": dept, "study": study, "era": era,
           "first_ts": None if first_ts is None else int(first_ts),
           "last_ts": None if last_ts is None else int(last_ts),
           "code_sha256": code_sha256, "frozen_sha256": frozen_sha256, "run_id": run_id()}
    for k, v in extra.items():
        if k not in row:
            row[k] = v
    p = access_log_path(dept)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a") as f:
        f.write(json.dumps(row) + "\n")
    return row


def read_access_log(dept) -> list[dict]:
    p = access_log_path(dept)
    if not p.exists():
        return []
    return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
