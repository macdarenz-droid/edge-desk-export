"""As-of joins (DATA BRIEF item 4): a decision at time t sees only what existed before t.

- asof_join: values (macro prints, COT, calendars) with a ``release_ts`` column; a decision at t
  gets the latest row with release_ts < t (STRICT: a value released exactly at t is not seen).
- bars_asof: bars labelled by OPEN time; a decision at t sees a bar only when its END time
  (open + bar_seconds, or an ``end_ts`` column when bar_seconds is None) is <= t. A bar ending
  exactly at t is seen (it has closed).
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def _asof_positions(decisions: np.ndarray, release: np.ndarray) -> np.ndarray:
    """release sorted ascending; index of the last release strictly before each decision, or -1."""
    return np.searchsorted(release, decisions, side="left") - 1


def asof_join(decisions_ts, values_df: pd.DataFrame, release_col: str = "release_ts",
              by: str | None = None, decisions_by=None) -> pd.DataFrame:
    """One row per decision, in the order of decisions_ts, holding the columns of values_df from
    the latest row with release_ts < decision ts; all NaN when there is none.
    Ties in release_ts: the row that comes last after a stable sort by release_ts wins.
    by / decisions_by: optional key column of values_df and one key per decision (for example a
    series name); the join then runs within each key.
    """
    d = np.asarray(decisions_ts, dtype=np.int64)
    if release_col not in values_df.columns:
        raise KeyError(f"values_df needs a {release_col!r} column")
    if values_df[release_col].isna().any():
        raise ValueError(f"{release_col} has NaN; every value needs a known release time")
    v = values_df.reset_index(drop=True)
    src = np.full(len(d), -1, dtype=np.int64)          # row of v used by each decision
    if by is None:
        order = np.argsort(v[release_col].to_numpy(np.int64), kind="stable")
        rel = v[release_col].to_numpy(np.int64)[order]
        pos = _asof_positions(d, rel)
        src = np.where(pos >= 0, order[np.clip(pos, 0, None)], -1)
    else:
        keys = np.asarray(decisions_by, dtype=object)
        if len(keys) != len(d):
            raise ValueError("decisions_by must have one key per decision")
        for k, g in v.groupby(by, sort=False):
            rows = np.flatnonzero(keys == k)
            if len(rows) == 0:
                continue
            gi = g.index.to_numpy()
            order = np.argsort(g[release_col].to_numpy(np.int64), kind="stable")
            rel = g[release_col].to_numpy(np.int64)[order]
            pos = _asof_positions(d[rows], rel)
            src[rows] = np.where(pos >= 0, gi[order[np.clip(pos, 0, None)]], -1)
    out = v.iloc[np.clip(src, 0, None)].reset_index(drop=True) if len(v) else \
        pd.DataFrame(index=range(len(d)), columns=v.columns)
    out = out.astype({c: "float64" for c in out.columns
                      if pd.api.types.is_integer_dtype(out[c]) or pd.api.types.is_bool_dtype(out[c])})
    out.loc[src < 0, :] = np.nan
    out.insert(0, "decision_ts", d)
    return out


def _bar_end(bars_df: pd.DataFrame, bar_seconds) -> np.ndarray:
    if bar_seconds is None:
        if "end_ts" not in bars_df.columns:
            raise ValueError("bar_seconds is None and bars_df has no end_ts column")
        return bars_df["end_ts"].to_numpy(np.int64)
    if bar_seconds <= 0:
        raise ValueError("bar_seconds must be positive")
    return bars_df["ts_utc"].to_numpy(np.int64) + int(bar_seconds)


def bars_asof(decision_ts, bars_df: pd.DataFrame, bar_seconds):
    """Bars visible at a decision: END time <= t.

    Scalar decision_ts -> the visible rows of bars_df (a DataFrame).
    Array decision_ts -> int array: for each decision, the position (iloc) of the last visible
    bar, or -1. bars_df must be sorted by ts_utc with non-decreasing end times.
    """
    end = _bar_end(bars_df, bar_seconds)
    if len(end) > 1 and np.any(np.diff(end) < 0):
        raise ValueError("bars_df must be sorted with non-decreasing end times")
    if np.ndim(decision_ts) == 0:
        n = int(np.searchsorted(end, int(decision_ts), side="right"))
        return bars_df.iloc[:n]
    d = np.asarray(decision_ts, dtype=np.int64)
    return np.searchsorted(end, d, side="right") - 1
