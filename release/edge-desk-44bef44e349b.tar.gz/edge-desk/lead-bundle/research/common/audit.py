"""Runtime price-file guard: a ``sys.addaudithook`` layer that refuses opening a registered price
file for reading unless the read comes through this package's own readers (the loaders, files.py,
looks.sha256_file, and research/data/).

Why a runtime layer (docs/EDGE_HUNT.md section 5; the coordinator's Priority-2 "defence in depth"):
the static guard test (``tests/test_core_guard.py``) reads source with ``ast`` and cannot see a path
built at runtime, read through an alias, or reached by a renamed on-disk copy. This hook fires when
the file is actually opened, so those routes are closed too. It never replaces the loaders' access
rules, ACCESS_LOG.jsonl or STATS's audit; it is one more layer.

Three red-team-blocking holes in the first version are closed here:

1. **Innermost caller, by identity.** The old check accepted the read if ANY frame on the stack was
   a loaders/files/research-data file. So code the loaders call back into (a ``str`` subclass whose
   ``.strip()`` reads a file, run through ``normalise_instrument``) read freely, and a spoofed
   ``compile(src, loaders.__file__, 'exec')`` passed on its co_filename. Now the decision is made on
   the FIRST non-library, non-``<frozen>``, non-audit frame walking outward, and "allowed" means its
   code object's identity is in a set built once from the actual functions of ``loaders.py``,
   ``files.py``, ``looks.py`` and ``research/data/*.py`` (and their nested code objects). A spoofed
   co_filename is a fresh code object, so its id is not in the set.

2. **Path-like objects.** ``io.FileIO(Path(price))`` hands the audit event the Path OBJECT, not a
   str, so the old ``if not isinstance(p, str): return`` let it through. Now a ``pathlib`` path is
   converted with ``str()``; any OTHER object (a custom ``os.PathLike`` with a stateful
   ``__fspath__`` that could hand FileIO a different path than the hook would see, or any non path)
   fails closed: it is refused unless an allowed frame is found.

3. **Fail closed, not open, on a broken data root.** A hunter-set ``$FX_DATA_ROOT`` of a missing
   user (``~no_such_user/x``) made ``data_root().expanduser()`` raise, which the old code swallowed,
   leaving the snapshot ``None`` and every later open allowed. The protected set is now split: a
   static part (registered basenames and sha256s, the default root, the allowed code ids and the
   library prefixes) built once at first use and independent of the environment, and an env part
   (the ``$FX_DATA_ROOT`` root, its files' canonical paths, sizes and (device, inode) pairs). If the
   env part cannot be built it is ``None`` and cached as such; the static part still applies and any
   read of a registered basename or a path under the default root is REFUSED, not allowed.

What counts as a real registered price file (using the package's own registry,
``loaders._package_entries`` -- never ``$FX_DATASETS_JSON`` or a synthetic test registry):
  - its basename (raw or realpath) is a registered relpath's basename; or
  - (env) its (device, inode) match a registered file's -- a symlink, hard link or rename to any
    name, anywhere; or its realpath is a registered file's canonical path; or
  - it is under a real data root and its name matches the data/round21 ``derived/`` pattern; or
  - (env) its size matches a registered file's and its sha256 is a registered price sha256 -- a
    renamed or copied file at any path, under the roots or not (hashed once per (path, size, mtime)
    and cached, never on every open).

Synthetic test data (a tmp root with no real registered file, the synthetic registry of
``tests/test_core_loaders.py``) matches none of these, so the hook does not touch it -- exactly as
``loaders._real_data`` scopes the loaders' own gate (audit finding #2). Writes are always allowed
(the loaders write fetched files; only reads are guarded).

All of the hook's state is held in a closure (``_make_guard``), so there is no module attribute an
attacker can reassign to turn it off (``audit._state.inside = True`` and the like). Audit hooks
cannot be removed once added, so a refusal raises ``PermissionError`` with a clear message, and any
internal error fails open (returns) so a bug here can never break an unrelated ``open``.

Known gaps (documented; covered by ACCESS_LOG, the static guard, and the loaders' own gate):
``ctypes.CDLL(None).fopen`` and other native/FFI opens, ``pyarrow.csv`` / ``pyarrow.dataset`` /
a pyarrow-backed ``read_parquet`` (pyarrow is not installed in this environment), and subprocess
children (``python3 -I``, ``cat``, ``cp``) do not raise this process's ``open`` audit event.

Python docs: ``sys.addaudithook`` and the ``open`` audit event
(https://docs.python.org/3/library/sys.html#sys.addaudithook,
https://docs.python.org/3/library/audit_events.html); ``os.O_WRONLY`` / ``os.O_ACCMODE``
(https://docs.python.org/3/library/os.html); ``sysconfig.get_paths`` and ``site.getsitepackages``.
"""
from __future__ import annotations

import hashlib
import os
import site
import sys
import sysconfig
import threading
import types
from pathlib import Path, PurePath

_installed = False

_MSG = ("research.common: reading the price file {name} is allowed only through "
        "research.common.loaders (load_m1 / load_bars); a direct open is refused")

# Source modules whose functions are trusted to open a registered price file: the loaders and their
# hashing reader (looks.sha256_file), files.py (its own price-refusal reads the header and hashes),
# and research/data/ (the downloader, which resumes its own file, and the packager).
_COMMON_READERS = ("research.common.loaders", "research.common.files", "research.common.looks")
_DATA_READERS = ("research.data.oanda_download", "research.data.package_branch",
                 "research.data.publish_branch")


# ---------------------------------------------------------------------------- pure helpers
def _is_read(mode, flags) -> bool:
    """A read open (default 'r'); write-only opens ('w', 'a', 'x', O_WRONLY) are allowed."""
    if isinstance(mode, str):
        return ("r" in mode) or ("+" in mode)
    if mode is None and flags is not None:
        try:
            return (int(flags) & os.O_ACCMODE) != os.O_WRONLY
        except (TypeError, ValueError):
            return True
    return True


def _under(rp: str, roots) -> bool:
    return any(rp == r or rp.startswith(r + os.sep) for r in roots)


def _walk_code(code, out: set) -> None:
    out.add(id(code))
    for c in code.co_consts:
        if isinstance(c, types.CodeType):
            _walk_code(c, out)


def _obj_codes(v, out: set, seen: set) -> None:
    if id(v) in seen:
        return
    seen.add(id(v))
    if isinstance(v, types.FunctionType):
        _walk_code(v.__code__, out)
    elif isinstance(v, (staticmethod, classmethod)):
        f = v.__func__
        if isinstance(f, types.FunctionType):
            _walk_code(f.__code__, out)
    elif isinstance(v, property):
        for fn in (v.fget, v.fset, v.fdel):
            if isinstance(fn, types.FunctionType):
                _walk_code(fn.__code__, out)
    elif isinstance(v, type):
        for m in list(vars(v).values()):
            _obj_codes(m, out, seen)


def _module_codes(mod, out: set) -> None:
    seen: set = set()
    for v in list(vars(mod).values()):
        _obj_codes(v, out, seen)


def _library_prefixes() -> tuple[str, ...]:
    pre: set[str] = set()
    try:
        paths = sysconfig.get_paths()
    except Exception:
        paths = {}
    for k in ("stdlib", "platstdlib", "purelib", "platlib"):
        p = paths.get(k)
        if p:
            pre.add(p)
    try:
        for p in site.getsitepackages():
            pre.add(p)
    except Exception:
        pass
    try:
        p = site.getusersitepackages()
        if p:
            pre.add(p)
    except Exception:
        pass
    return tuple(sorted(pre))


def _hash_is_price(rp: str, shas: frozenset) -> bool:
    h = hashlib.sha256()
    try:
        with open(rp, "rb") as f:                            # _state.inside is set: no re-entry
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
    except OSError:
        return False
    return h.hexdigest() in shas


# ---------------------------------------------------------------------------- the guard
def _make_guard():
    _state = threading.local()                 # re-entry guard, closure-held (no module attribute)
    _cache: dict = {"static": None, "allowed": None}
    _env_cache: dict = {}                      # $FX_DATA_ROOT value -> env dict or None (cached)
    _sha_cache: dict = {}                      # (realpath, size, mtime_ns) -> is a registered sha
    _keepalive: list = []                      # hold the reader modules so their code ids stay valid

    def _build_static() -> dict:
        """The registry-derived, environment-independent part: basenames, sha256s, relpaths, the
        default root and the derived-file pattern. All of its loaders dependencies are defined
        early, so it is correct even when first triggered mid-import of the package."""
        from . import loaders as L                          # lazy: no import cycle, no env read
        entries = L._package_entries()                      # [{"sha256", "relpath"}], package registry
        shas = frozenset(e["sha256"] for e in entries if e.get("sha256"))
        relpaths = tuple(e["relpath"] for e in entries if e.get("relpath"))
        basenames = frozenset(os.path.basename(rp) for rp in relpaths)
        default_roots: list[str] = []
        try:
            default_roots.append(str(L._DEFAULT_ROOT.resolve()))
        except OSError:
            default_roots.append(str(L._DEFAULT_ROOT))
        return {"shas": shas, "basenames": basenames, "relpaths": relpaths,
                "default_roots": tuple(dict.fromkeys(default_roots)), "derived": L.DERIVED_PATTERN}

    def _ensure_allowed() -> dict:
        """The trusted readers' code-object ids and the library path prefixes, built lazily. This
        runs only from ``_allowed_frame``, which is reached only on a protected read or a weird
        path-like open -- by then the reader modules are fully imported. A partial build (e.g. if
        ever triggered before loaders finished importing) is NOT cached, so it is retried."""
        a = _cache["allowed"]
        if a is not None and a["complete"]:
            return a
        import importlib
        codes: set = set()
        complete = True
        _state.inside = True                                # importing research.data opens files
        try:
            for name in _COMMON_READERS + _DATA_READERS:
                mod = sys.modules.get(name)
                if mod is None:
                    try:
                        mod = importlib.import_module(name)
                    except Exception:
                        if name in _COMMON_READERS:
                            complete = False
                        continue
                _keepalive.append(mod)
                _module_codes(mod, codes)
            L = sys.modules.get("research.common.loaders")
            if not (L is not None and hasattr(L, "_read_csv_range") and hasattr(L, "load_m1")):
                complete = False                            # loaders not fully initialised yet
        finally:
            _state.inside = False
        a = {"codes": frozenset(codes), "libs": _library_prefixes(), "complete": complete}
        if complete:
            _cache["allowed"] = a
        return a

    def _build_env(static: dict):
        """The $FX_DATA_ROOT-dependent part, or None when the root cannot even be resolved (fail
        closed). Every step is wrapped so a broken root never raises out of the hook."""
        from . import loaders as L
        try:
            root = L.data_root()
        except Exception:
            return None                                     # cannot resolve the root: fail closed
        roots: list[str] = []
        try:
            rr = root.resolve()
            if L._is_real_root(rr, static["relpaths"]):
                roots.append(str(rr))
        except Exception:
            pass
        canonical: set[str] = set()
        sizes: set[int] = set()
        inodes: set[tuple[int, int]] = set()
        for rp in static["relpaths"]:
            try:
                p = (root / rp).resolve()
                st = p.stat()
            except OSError:
                continue
            canonical.add(str(p))
            sizes.add(st.st_size)
            inodes.add((st.st_dev, st.st_ino))
        return {"roots": tuple(dict.fromkeys(roots)), "canonical": frozenset(canonical),
                "sizes": frozenset(sizes), "inodes": frozenset(inodes)}

    def _snapshot():
        static = _cache["static"]
        if static is None:
            static = _cache["static"] = _build_static()
        key = os.environ.get("FX_DATA_ROOT", "")
        if key in _env_cache:
            env = _env_cache[key]
        else:
            try:
                env = _build_env(static)
            except Exception:
                env = None
            _env_cache[key] = env
        return static, env

    def _protected(p: str, static: dict, env) -> bool:
        rp = os.path.realpath(p)
        if os.path.basename(rp) in static["basenames"] or os.path.basename(p) in static["basenames"]:
            return True
        try:
            st = os.stat(rp)
        except OSError:
            st = None
        if env is not None and st is not None:
            if (st.st_dev, st.st_ino) in env["inodes"]:
                return True                                 # symlink / hard link / rename, any name
            if rp in env["canonical"]:
                return True
        roots = static["default_roots"] + (env["roots"] if env is not None else ())
        if _under(rp, roots) and (static["derived"].search(os.path.basename(rp))
                                  or static["derived"].search(rp)):
            return True
        if env is not None and st is not None and st.st_size in env["sizes"]:
            ck = (rp, st.st_size, st.st_mtime_ns)
            hit = _sha_cache.get(ck)
            if hit is None:
                hit = _hash_is_price(rp, static["shas"])
                if len(_sha_cache) > 4096:
                    _sha_cache.clear()
                _sha_cache[ck] = hit
            if hit:
                return True                                 # a copy at any path (size + sha match)
        if env is None and _under(rp, static["default_roots"]):
            return True                                     # env unavailable: fail closed under root
        return False

    def _allowed_frame() -> bool:
        """True when the FIRST non-library, non-``<...>``, non-audit frame (walking outward) is one
        of the trusted readers, decided by code-object identity (a spoofed co_filename is a fresh
        code object, so its id is not in the set)."""
        a = _ensure_allowed()
        libs = a["libs"]
        allowed = a["codes"]
        f = sys._getframe(1)
        while f is not None:
            co = f.f_code
            cf = co.co_filename
            if f.f_globals.get("__name__") == __name__:     # skip audit.py's own frames
                f = f.f_back
                continue
            if cf.startswith("<frozen"):                    # importlib internals only; NOT <string>
                f = f.f_back                                # / <stdin> (attacker -c / exec code lives there)
                continue
            if "/site-packages/" in cf or "/dist-packages/" in cf \
                    or any(cf.startswith(pre) for pre in libs):
                f = f.f_back
                continue
            return id(co) in allowed                        # first real frame decides, by identity
        return False                                        # only library/frozen frames: fail closed

    def _hook(event: str, args) -> None:
        if event != "open":
            return
        if getattr(_state, "inside", False):
            return
        try:
            if not args:
                return
            p0 = args[0]
            if isinstance(p0, int):
                return                                       # an int fd: already open
            mode = args[1] if len(args) > 1 else None
            flags = args[2] if len(args) > 2 else None
            if not _is_read(mode, flags):
                return                                       # writes are allowed
            _state.inside = True
            try:
                static, env = _snapshot()
            finally:
                _state.inside = False
            if isinstance(p0, (bytes, bytearray)):
                p = os.fsdecode(bytes(p0))
            elif isinstance(p0, str):
                p = p0
            elif isinstance(p0, PurePath):
                p = str(p0)
            else:
                # a custom os.PathLike (whose __fspath__ could be stateful) or any non-path object:
                # do not trust __fspath__; fail closed unless a trusted reader is calling.
                if _allowed_frame():
                    return
                raise PermissionError(_MSG.format(name="a path-like object"))
            _state.inside = True
            try:
                protected = _protected(p, static, env)
            finally:
                _state.inside = False
            if not protected:
                return
            if _allowed_frame():
                return
            raise PermissionError(_MSG.format(name=os.path.basename(p)))
        except PermissionError:
            raise
        except Exception:
            return                                           # never break an unrelated open

    return _hook


_HOOK = _make_guard()


def install() -> None:
    """Register the audit hook once for this process. Called from research/common/__init__.py.
    An audit hook can never be removed, so this is a one-way switch."""
    global _installed
    if _installed:
        return
    _installed = True
    sys.addaudithook(_HOOK)
