"""Baseline generators (docs/EDGE_HUNT.md section 4 item 4c; STATS PASS_BAR.md v2 section 4,
origin/dept/stats 73cb7f43 / 530a9245, judge.py ``_null_stats``).

STATS judges with its own judge.py. ``stats_null_means`` runs that exact code (read with
``git show <STATS_REF>:research/departments/STATS/judge.py``), so a department pre-check gets the
same null STATS judges with; prefer it. The local draws below are inspectable copies of the
PUBLISHED v2 nulls (STATS_REF) for the random side (flip, basket permutation) and of the v3 draft
time-block same tilt (STATS_TILT_REF): same seed, same random-number sequence, same means
(checked in tests/test_sims_baselines.py). STATS's v3 (pass bar v3, work in progress at origin/dept/stats
34f5f508, not yet published) changes same tilt (calendar-month and time-block versions) and the
block length; when STATS publishes it, STATS_REF moves and the local copies are re-pinned.

Sizes, days, entries and exits never change; only the side, and with it pnl_long or pnl_short.
Time blocks: the window's labels (``days``) cut into consecutive blocks of ``block`` labels (L,
from STATS ``judge.block_length``: the caller passes it); a position belongs to the block of its
first label, and every row of a position takes one side in every draw.
  - random side, flip ('random' or 'random_side_flip'): each time block is flipped (all its
    positions, every pair at once) with probability 0.5;
  - random side, baskets ('random_side_perm', needs a 'rebalance' column): the signed sizes are
    permuted across the POSITIONS of each rebalance (one draw per position_id, applied to all its
    rows); PASS_BAR takes the larger p of this and the flip;
  - same tilt ('same_tilt'): the time blocks are permuted; each position takes the side of the
    source position at the same pair, offset and rank in its source block (identity = the pick);
    a missing source takes the source block's net side for that pair, then one draw per position
    with the pair's long share. This is STATS's v3 draft 'tilt_block' (STATS_TILT_REF), not v2's
    row-level version, which can give one position two sides (fallback draws per row) and is not
    the pick at the identity order when a pair holds opposite positions on one label.
Every draw is seeded (numpy default_rng(seed)), so the same call gives the same draws.

Inputs:
  - a position-day file (position_id, pair, day, w, pnl_long, pnl_short [, decision_ts, rebalance]), or
  - a trade list (one row per position) with pair, w (or side), a day/date/entry_ts column and the
    two outcomes (pnl_long_col, pnl_short_col, e.g. net_long / net_short).
For stop and target trades the short outcome is the mirrored order re-simulated (mirror_orders),
never minus the long outcome.
"""
from __future__ import annotations

from datetime import date

import hashlib
import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from .sim_daily import trading_day, weekdays_between

# PASS_BAR v2, the published STATS pass bar (STATS: "pass bar v2 after red team", 73cb7f43, and
# "status, PASS_BAR time fix", 530a9245; judge.py identical in both).
STATS_REF = "530a9245118083aabf9a81735e46ded9aefe0a0e"
# the position-level same tilt follows STATS's v3 draft ("pass bar v3 work in progress", 34f5f508)
STATS_TILT_REF = "34f5f508c4d31e2dd2bee27375140e03d42fb3c1"
JUDGE_PATH = "research/departments/STATS/judge.py"
MODES = ("random", "random_side_flip", "random_side_perm", "same_tilt")


def mirror_orders(orders: pd.DataFrame) -> pd.DataFrame:
    """The same orders on the other side. stop_dist and target_r stay as they are; absolute stop and
    target prices are reflected around the entry level ('level', or 'ref_price' for market orders);
    a limit becomes a stop order at the same level and a stop order a limit, so the mirror triggers
    at the same price."""
    m = orders.copy()
    m["side"] = -m["side"].astype(int)
    if "kind" in m:
        m["kind"] = m["kind"].map(lambda k: {"limit": "stop", "stop": "limit"}.get(k, k))
    for col in ("stop", "target"):
        if col in m and m[col].notna().any():
            ref = m["level"] if "level" in m else None
            if "ref_price" in m:
                ref = m["ref_price"] if ref is None else ref.fillna(m["ref_price"])
            if ref is None or ref[m[col].notna()].isna().any():
                raise ValueError(f"absolute {col} needs 'level' or 'ref_price' to mirror; "
                                 "or use stop_dist / target_r")
            m[col] = 2 * ref - m[col]
    return m


def _labels(df: pd.DataFrame, day_col=None) -> np.ndarray:
    if day_col is not None:
        return df[day_col].astype(str).str[:10].to_numpy()
    if "day" in df:
        return df["day"].astype(str).str[:10].to_numpy()
    if "date" in df:
        return df["date"].astype(str).str[:10].to_numpy()
    if "entry_ts" in df:
        return np.array([d.isoformat() for d in trading_day(df["entry_ts"].to_numpy(np.int64))])
    raise ValueError("need a 'day', 'date', 'entry_ts' or day_col column for the label")


def _pids(df: pd.DataFrame) -> np.ndarray:
    if "position_id" in df:
        return df["position_id"].astype(str).to_numpy()
    return np.arange(len(df)).astype(str)                           # a trade list: one row each


def default_days(labels) -> list:
    """Every weekday from the first to the last label."""
    ds = sorted(set(labels))
    return [d.isoformat() for d in weekdays_between(date.fromisoformat(ds[0]), date.fromisoformat(ds[-1]))]


def _sizes(df: pd.DataFrame) -> np.ndarray:
    if "w" in df:
        return df["w"].to_numpy(float)
    if "side" in df:
        return df["side"].to_numpy(float)
    raise ValueError("need a 'w' or 'side' column")


def long_share(df: pd.DataFrame) -> dict:
    """Pick's long share per pair, size-weighted (position-days on a position-day file)."""
    w = _sizes(df)
    pairs = df["pair"].astype(str).to_numpy()
    out = {}
    for p in np.unique(pairs):
        a = np.abs(w[pairs == p])
        tot = a.sum()
        out[p] = float(a[w[pairs == p] > 0].sum() / tot) if tot > 0 else 0.5
    return out


def _frame(df, days, block, day_col):
    if int(block) < 1:
        raise ValueError("block must be >= 1 (STATS judge.block_length)")
    lab = _labels(df, day_col)
    days = default_days(lab) if days is None else [str(d) for d in days]
    di = pd.Index(days).get_indexer(lab)
    if (di < 0).any():
        raise ValueError(f"row labels outside days, e.g. {sorted(set(lab[di < 0]))[:3]}")
    pid = _pids(df)
    first = pd.Series(di).groupby(pid).transform("min").to_numpy()
    return days, di, pid, first, first // int(block)


def draw_sides(df: pd.DataFrame, n_draws: int, seed: int, mode: str = "random", block: int = 5,
               days=None, day_col=None) -> np.ndarray:
    """(n_draws, len(df)): the side (+1/-1) each row takes in each draw; for 'random_side_perm'
    the permuted signed size w of each row. Every row of a position_id gets the same value."""
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}")
    days, di, pid, first, tb = _frame(df, days, block, day_col)
    rng = np.random.default_rng(seed)
    w = _sizes(df)
    s0 = np.sign(w)
    nb = int(tb.max()) + 1
    out = np.empty((n_draws, len(df)))
    if mode in ("random", "random_side_flip"):
        for b in range(n_draws):
            out[b] = s0 * np.where(rng.random(nb) < 0.5, -1.0, 1.0)[tb]
    elif mode == "random_side_perm":
        if "rebalance" not in df:
            raise ValueError("random_side_perm needs a 'rebalance' column")
        pos = pd.DataFrame({"pid": pid, "rebalance": df["rebalance"].to_numpy(), "w": w}) \
            .drop_duplicates("pid").reset_index(drop=True)
        if pos["pid"].duplicated().any():
            raise ValueError("a position_id must have one rebalance and one size")
        groups = [g.index.to_numpy() for _, g in pos.groupby("rebalance")]
        wp = pos["w"].to_numpy(float)
        row_of = pd.Index(pos["pid"]).get_indexer(pid)
        for b in range(n_draws):
            perm = np.arange(len(pos))
            for g in groups:
                perm[g] = g[rng.permutation(len(g))]
            out[b] = wp[perm][row_of]
    else:                                                           # same_tilt, per position
        # STATS's time-block same tilt at position level (judge.py v3 draft 'tilt_block',
        # STATS_TILT_REF): time blocks permuted; each position takes the side of the source
        # position at the same pair, offset and rank (identity order = the pick); a missing
        # source takes the source block's net side for that pair, then one draw per position
        # with the pair's long share. v2's row-level version (STATS_REF) can give one position
        # two sides and is not used.
        pos = pd.DataFrame({"pid": pid, "pair": df["pair"].astype(str).to_numpy(), "w": w,
                            "di": di}).groupby("pid", sort=True).agg(
            pair=("pair", "first"), w=("w", "first"), first=("di", "min"))
        row_of = pos.index.get_indexer(pid)
        side0 = np.sign(pos["w"].to_numpy(float))
        upairs, ppos = np.unique(pos["pair"].to_numpy(), return_inverse=True)
        pfirst = pos["first"].to_numpy()
        ptb = pfirst // int(block)
        off = pfirst - ptb * int(block)
        rank = pd.Series(np.zeros(len(pos))).groupby([ppos, pfirst]).cumcount().to_numpy()
        R = int(rank.max()) + 1 if len(pos) else 1
        SIDE = np.zeros((len(upairs), nb * int(block) + int(block), R))
        SIDE[ppos, pfirst, rank] = side0
        S = np.zeros((len(upairs), nb))
        np.add.at(S, (ppos, ptb), side0 * np.abs(pos["w"].to_numpy(float)))
        S = np.sign(S)
        share = long_share(df)
        pr = np.array([share[p] for p in upairs])[ppos]
        for b in range(n_draws):
            src = rng.permutation(nb)[ptb]
            got = SIDE[ppos, src * int(block) + off, rank]
            got = np.where(got != 0, got, S[ppos, src])
            got = np.where(got != 0, got, np.where(rng.random(len(pos)) < pr, 1.0, -1.0))
            out[b] = got[row_of]
    return out


def baseline_values(df: pd.DataFrame, draws: np.ndarray, pnl_long_col="pnl_long",
                    pnl_short_col="pnl_short", sized: bool = False) -> np.ndarray:
    """(n_draws, len(df)) per-row values |size| x (pnl_long if draw > 0 else pnl_short).
    sized=False: draws are signs and the pick's |w| is kept; sized=True: draws are signed sizes
    ('random_side_perm')."""
    pl = df[pnl_long_col].to_numpy(float)
    ps = df[pnl_short_col].to_numpy(float)
    size = np.abs(draws) if sized else np.abs(_sizes(df))[None, :]
    return size * np.where(draws > 0, pl[None, :], ps[None, :])


def daily_baseline(pos_days: pd.DataFrame, n_draws: int, seed: int, mode: str = "random",
                   block: int = 5, days=None) -> np.ndarray:
    """(n_draws, n_days) daily nets of the baseline over `days` (default: every weekday from the
    first to the last row; 0 where flat). Row means = STATS judge._null_stats for the same seed."""
    if days is None:
        days = default_days(_labels(pos_days))
    draws = draw_sides(pos_days, n_draws, seed, mode, block, days)
    vals = baseline_values(pos_days, draws, sized=(mode == "random_side_perm"))
    col = pd.Index([str(d) for d in days]).get_indexer(_labels(pos_days))
    out = np.zeros((n_draws, len(days)))
    np.add.at(out, (np.arange(n_draws)[:, None], col[None, :]), vals)
    return out


def trade_baseline(trades: pd.DataFrame, n_draws: int, seed: int, mode: str = "random",
                   block: int = 5, days=None, pnl_long_col="net_long", pnl_short_col="net_short",
                   day_col=None) -> np.ndarray:
    """(n_draws,) mean per trade of the baseline on a trade list (one row per position)."""
    d = draw_sides(trades, n_draws, seed, mode, block, days, day_col)
    v = baseline_values(trades, d, pnl_long_col, pnl_short_col, sized=(mode == "random_side_perm"))
    return v.mean(axis=1)


def one_sided_p(stat: float, null: np.ndarray) -> float:
    """(1 + #{null >= stat}) / (B + 1)."""
    null = np.asarray(null, float)
    return float((1 + np.sum(null >= stat - 1e-12)) / (len(null) + 1))


# ---------------------------------------------------------------------------- STATS's own code
_JUDGES: dict = {}


def load_stats_judge(ref: str = STATS_REF, repo=None, fetch: bool = True):
    """STATS's judge.py at `ref` as a module (git show; fetches origin/dept/stats once if the ref
    is missing). ``module.__source_info__`` = {ref, commit, sha256}."""
    from .looks import repo_root
    repo = Path(repo) if repo is not None else repo_root()

    def show():
        return subprocess.run(["git", "-C", str(repo), "show", f"{ref}:{JUDGE_PATH}"], capture_output=True)

    r = show()
    if r.returncode != 0 and fetch:
        subprocess.run(["git", "-C", str(repo), "fetch", "-q", "origin",
                        "+refs/heads/dept/stats:refs/remotes/origin/dept/stats"], capture_output=True)
        r = show()
    if r.returncode != 0:
        raise FileNotFoundError(f"{ref}:{JUDGE_PATH} not found; git fetch origin dept/stats")
    sha = hashlib.sha256(r.stdout).hexdigest()
    if sha in _JUDGES:
        return _JUDGES[sha]
    c = subprocess.run(["git", "-C", str(repo), "rev-parse", ref], capture_output=True, text=True)
    d = Path(tempfile.mkdtemp(prefix="stats_judge_"))
    f = d / f"stats_judge_{sha[:12]}.py"
    f.write_bytes(r.stdout)
    spec = importlib.util.spec_from_file_location(f.stem, f)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[f.stem] = mod
    spec.loader.exec_module(mod)
    mod.__source_info__ = {"ref": ref, "commit": c.stdout.strip() or None, "sha256": sha}
    _JUDGES[sha] = mod
    return mod


def stats_null_means(pos_days: pd.DataFrame, days, kind: str, block: int, B: int, seed: int,
                     eras=None, ref: str = STATS_REF) -> np.ndarray:
    """(B,) null means of the daily net, computed by STATS's judge.py at `ref` (its validate, then
    its null). kind is the judge's own name: v2 'random_side_flip', 'random_side_perm',
    'same_tilt'; v3 'flip', 'perm', 'tilt_month', 'tilt_block'."""
    j = load_stats_judge(ref)
    days = [str(d) for d in days]
    basket = kind in ("random_side_perm", "perm")
    df = j.validate(pos_days, days, set(eras or j.ERAS), basket)
    if hasattr(j, "_null_stats"):
        return j._null_stats(df, len(days), kind, int(block), int(B), int(seed), basket)
    return j._null(j.Book(df, len(days)), kind, int(block), int(B), int(seed))
