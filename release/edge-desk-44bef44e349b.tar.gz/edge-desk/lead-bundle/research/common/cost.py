"""Cost hook: a thin re-export of COST's research/departments/COST/cost.py (docs/EDGE_HUNT.md section 4
item 3; coordinator ruling 14 Oct 2026: one cost implementation, COST's).

This module holds NO cost rule. It only
  - loads COST's cost.py (the local file first, else ``git show <ref>:research/departments/COST/cost.py``),
    which must have the array interface (``CostModel.round_trip`` / ``leg_charge``, COST 53eef569 on); a
    local copy older than that is skipped for the ref's, and ``.info["cost_py"]["note"]`` says so,
  - loads COST_MODEL.json the same way (local first, else ``git show``); PROVISIONAL.json is not used,
    because COST's cost.py needs a model of version 2 or later,
  - records the sha256 (and the git commit, for a ref) of both files in ``.info`` for FROZEN.json, and
  - keeps LegacyFloor, the older rounds' flat convention, for parity checks only (never a judged pick).

Every charge, floor, window, slippage, freeze refusal and the EUR/USD 2.0 pip minimum come from COST's
CostModel. Release times are passed by the caller (EVENTS' calendar); there is no default list, and COST's
class refuses an empty one unless ``allow_no_releases=True`` (a non-judging run).

    from research.common.cost import CostModel
    cm = CostModel.load(release_ts=calendar_ts)          # COST's CostModel, with .info
    cm.round_trip("EUR_USD", entry_ts, exit_ts, spread_paid, entry_kind="market", exit_kind="stop", ...)

sim_bar applies its own ``fill_slip`` only with LegacyFloor: COST's model adds the fill slippage, so a
judged run never pays it twice (sim_bar refuses fill_slip with any other cost hook).
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import types
from pathlib import Path

import numpy as np

COST_PY_PATH = "research/departments/COST/cost.py"
MODEL_PATH = "research/departments/COST/COST_MODEL.json"
DEFAULT_REF = "origin/dept/cost"
_MODULES: dict[str, types.ModuleType] = {}      # sha256 of COST's cost.py -> module (one class per file)


class CostModelMissing(FileNotFoundError):
    pass


def pip_size(pair: str) -> float:
    """Pip of a pair (0.01 for JPY quotes, else 0.0001): a quote convention, not a cost rule."""
    return 0.01 if pair.replace("_", "").replace("/", "").upper().endswith("JPY") else 1e-4


def _repo_root() -> Path:
    from .looks import repo_root
    return repo_root()


def _git_show(ref: str, path: str, repo: Path) -> tuple[bytes, str | None] | None:
    r = subprocess.run(["git", "-C", str(repo), "show", f"{ref}:{path}"], capture_output=True)
    if r.returncode != 0:
        return None
    c = subprocess.run(["git", "-C", str(repo), "rev-parse", ref], capture_output=True, text=True)
    return r.stdout, (c.stdout.strip() if c.returncode == 0 else None)


def _fetch(repo: Path, ref: str) -> None:
    subprocess.run(["git", "-C", str(repo), "fetch", "-q", "origin",
                    f"+refs/heads/{ref.split('/', 1)[1]}:refs/remotes/{ref}"], capture_output=True)


def _read(rel: str, repo: Path, ref: str, local: bool) -> tuple[bytes, dict] | None:
    p = repo / rel
    if local and p.exists():
        b = p.read_bytes()
        return b, {"source": f"local:{rel}", "commit": None, "sha256": hashlib.sha256(b).hexdigest()}
    got = _git_show(ref, rel, repo)
    if got is None:
        return None
    b, commit = got
    return b, {"source": f"{ref}:{rel}", "commit": commit, "sha256": hashlib.sha256(b).hexdigest()}


def cost_module(repo=None, ref: str = DEFAULT_REF, fetch: bool = False,
                local: bool = True) -> tuple[types.ModuleType, dict]:
    """COST's cost.py as a module, and its {source, commit, sha256}."""
    repo = Path(repo) if repo is not None else _repo_root()
    if fetch:
        _fetch(repo, ref)
    got = _read(COST_PY_PATH, repo, ref, local)
    if got is not None and local and got[1]["source"].startswith("local:") and b"def round_trip" not in got[0]:
        # an older local copy without the array interface (before COST 53eef569 is merged here):
        # use COST's pushed file instead, and say so in .info
        older = got[1]["sha256"]
        got = _read(COST_PY_PATH, repo, ref, local=False)
        if got is not None:
            got[1]["note"] = f"local {COST_PY_PATH} (sha256 {older[:12]}...) predates the array interface"
    if got is None:
        raise CostModelMissing(f"no {COST_PY_PATH}, locally or at {ref}; the cost hook never computes its "
                               "own cost. git fetch origin dept/cost.")
    src, info = got
    mod = _MODULES.get(info["sha256"])
    if mod is None:
        mod = types.ModuleType(f"cost_reference_{info['sha256'][:12]}")
        mod.__file__ = info["source"]
        sys.modules[mod.__name__] = mod                 # dataclass/pickle lookups need the module listed
        exec(compile(src, info["source"], "exec"), mod.__dict__)
        _MODULES[info["sha256"]] = mod
    if not (hasattr(mod, "CostModel") and hasattr(mod.CostModel, "round_trip")
            and hasattr(mod.CostModel, "leg_charge")):
        raise CostModelMissing(f"{info['source']} has no array interface (CostModel.round_trip / leg_charge); "
                               "it needs COST's cost.py at 53eef569 or later")
    return mod, info


def load_model_bytes(repo=None, ref: str = DEFAULT_REF, fetch: bool = False,
                     local: bool = True) -> tuple[bytes, dict]:
    """COST_MODEL.json's bytes and {kind, source, commit, sha256}."""
    repo = Path(repo) if repo is not None else _repo_root()
    if fetch:
        _fetch(repo, ref)
    got = _read(MODEL_PATH, repo, ref, local)
    if got is None:
        raise CostModelMissing(f"no {MODEL_PATH}, locally or at {ref}; the cost hook never computes its own "
                               "cost (EDGE_HUNT section 4 item 3). Ask COST, or git fetch origin dept/cost.")
    b, info = got
    return b, {"kind": "COST_MODEL", **info}


class CostModel:
    """Factory for COST's CostModel. ``CostModel(model, release_ts, ...)`` and ``CostModel.load(...)``
    return an instance of the class defined in COST's cost.py, with ``.info`` holding the sha256 of
    the model and of COST's cost.py."""

    def __new__(cls, model: dict, release_ts=None, allow_no_releases: bool = False,
                unmeasured_release_ts=(), info: dict | None = None, repo=None, ref: str = DEFAULT_REF,
                local: bool = True):
        if release_ts is None:
            raise ValueError("release_ts is required: pass EVENTS' calendar (there is no default list), "
                             "or release_ts=() with allow_no_releases=True for a non-judging run")
        mod, cinfo = cost_module(repo, ref, local=local)
        cm = mod.CostModel(model, release_ts, allow_no_releases=allow_no_releases,
                           unmeasured_release_ts=unmeasured_release_ts, info=info)
        cm.info = {**dict(info or {}), "cost_py": cinfo}
        return cm

    @classmethod
    def load(cls, repo=None, ref: str = DEFAULT_REF, fetch: bool = False, local: bool = True,
             release_ts=None, allow_no_releases: bool = False, unmeasured_release_ts=()):
        b, info = load_model_bytes(repo, ref, fetch, local)
        return cls(json.loads(b), release_ts, allow_no_releases, unmeasured_release_ts, info=info,
                   repo=repo, ref=ref, local=local)


def __getattr__(name: str):
    """ClosedMarket, FrozenPlaceholder, pair_key, financing_nights, vol_from_mid_close, KINDS ...:
    taken from COST's cost.py (the local file, else origin/dept/cost)."""
    if name.startswith("__"):
        raise AttributeError(name)
    mod, _ = cost_module()
    try:
        return getattr(mod, name)
    except AttributeError:
        raise AttributeError(f"research.common.cost has no {name!r}, and COST's cost.py has none") from None


class LegacyFloor:
    """Older rounds' convention (Rounds 45-63): charge = max(floor_pips, spread paid incl. the
    simulator's fill slippage). net = min(mid - floor, bid/ask). Parity checks only."""

    def __init__(self, floor_pips: float = 2.0):
        self.floor = float(floor_pips)
        self.info = {"kind": "legacy_flat_floor", "floor_pips": self.floor, "source": None,
                     "commit": None, "sha256": None, "note": "parity only, never for a judged pick"}

    def round_trip(self, pair, entry_ts, exit_ts, spread_paid_pips, entry_kind="market",
                   exit_kind="market", vol_entry=None, vol_exit=None, decision_ts=None,
                   freezing: bool = False, signal_ts=None, exit_time=None, bar_sec=60) -> np.ndarray:
        if freezing:
            raise ValueError("LegacyFloor is for parity checks only; it cannot price a frozen pick")
        return np.maximum(np.atleast_1d(np.asarray(spread_paid_pips, dtype=float)), self.floor)

    def leg_charge(self, pair, ts, half_spread_paid_pips, kind="market", vol=None, decision_ts=None,
                   signal_ts=None, bar_sec=60):
        return np.maximum(np.atleast_1d(np.asarray(half_spread_paid_pips, dtype=float)), self.floor / 2)
