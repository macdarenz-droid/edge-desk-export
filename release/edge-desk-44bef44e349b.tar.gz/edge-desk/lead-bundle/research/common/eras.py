"""Data eras of the edge hunt (docs/EDGE_HUNT.md section 3), in ts_utc (unix seconds, UTC).

| Era        | first ts_utc | last ts_utc  |
|------------|--------------|--------------|
| PRE        | (all before) | 1262303999   |
| BUILD      | 1262304000   | 1640995199   |
| C          | 1640995200   | 1701388799   |
| T          | 1701388800   | 1751317199   |
| VALIDATION | 1751317200   | 1774990799   |
| HOLDOUT    | 1774990800   | 1791493199   |
| FORWARD    | 1791493200   | (open)       |

Era rule (section 3), as code:
- A trade belongs to the era of its DECISION time: ``decision_era(decision_ts)`` (= ``era_of``).
- ``cut_at_era_end(decision_ts, exit_ts, bar_ts=None)``: a position still open at its decision
  era's last bar is closed at that bar's bid/ask CLOSE and flagged "cut". The function returns the
  exit bar open time (the last bar of the era when cut) and a boolean ``cut`` mask; the simulator
  prices that exit at the bar's close (bid_c for a long, ask_c for a short).
- ``drop_labels_crossing(label_end_ts, decision_ts)``: a model label whose horizon crosses its
  decision era's end is dropped (returns a boolean KEEP mask).
- ``walk_forward_splits``: nested walk-forward inside BUILD only, with a purge gap of at least
  the label horizon between each training fold and its test fold.

PRE (coordinator, DATA-PRE-2, 15 Oct 2026): every row before 2010-01-01 00:00 UTC. It is LOCKED by default:
``PRE_OPEN`` is False, and research.common.loaders refuses every PRE read while it is. Only a release that carries
STATS's PRE-era ruling (and STATS's re-pin of research/common) may set it, together with the read rules that ruling
gives; a runtime change is refused like any other change below. BUILD starts at 2010-01-01, so a BUILD read never
serves a PRE row, open or not, and no BUILD result changes when PRE data is registered.

The era table is read-only (audit finding #8): ``_BOUNDS`` is a MappingProxyType of tuples, the
start and end arrays cannot be written, and the functions hold the original objects as default
arguments; research.common.loaders refuses every read once any attribute here was changed.
"""
from __future__ import annotations

from types import MappingProxyType

import numpy as np

PRE_END = 1262304000              # first ts that is NOT PRE (2010-01-01 00:00 UTC): BUILD's first second
PRE_OPEN = False                  # STATS-ruled flag: PRE rows are refused while False (module docstring)
BUILD_START = PRE_END
BUILD_END = 1640995200            # first ts that is NOT BUILD (2022-01-01 00:00 UTC)
C_START = 1640995200
C_END = 1701388799
T_START = 1701388800
T_END = 1751317199
LOCK_START = 1751317200           # 2025-06-30 21:00 UTC; nothing at or after this outside STATS
VALIDATION_START = LOCK_START
VALIDATION_END = 1774990799
HOLDOUT_START = 1774990800
HOLDOUT_END = 1791493199
FORWARD_START = 1791493200

ERAS = ("PRE", "BUILD", "C", "T", "VALIDATION", "HOLDOUT", "FORWARD")
LOCKED_ERAS = ("VALIDATION", "HOLDOUT", "FORWARD")

# Sentinels for the open ends: PRE starts at the beginning of time, FORWARD never ends.
_MIN_TS = -(2 ** 62)
_MAX_TS = 2 ** 62

# Read-only (audit finding #8): a MappingProxyType of tuples cannot be changed in place, and the
# functions below hold the original objects as default arguments, so rebinding a module attribute
# (eras._BOUNDS = {...}) changes nothing they return. research.common.loaders also refuses every
# read once any attribute of this module differs from its import-time value.
_BOUNDS = MappingProxyType({
    "PRE": (_MIN_TS, PRE_END - 1),
    "BUILD": (BUILD_START, BUILD_END - 1),
    "C": (C_START, C_END),
    "T": (T_START, T_END),
    "VALIDATION": (VALIDATION_START, VALIDATION_END),
    "HOLDOUT": (HOLDOUT_START, HOLDOUT_END),
    "FORWARD": (FORWARD_START, _MAX_TS),
})


def _readonly(values, dtype) -> np.ndarray:
    """An array over immutable bytes: its WRITEABLE flag cannot be set back to True."""
    return np.frombuffer(np.array(values, dtype=dtype).tobytes(), dtype=dtype)


# Era starts in order; np.searchsorted on these gives the era index.
_STARTS = _readonly([BUILD_START, C_START, T_START, VALIDATION_START, HOLDOUT_START, FORWARD_START], np.int64)
_ENDS = _readonly([_BOUNDS[e][1] for e in ERAS], np.int64)
_NAMES = np.array(ERAS, dtype=object)
_NAMES.flags.writeable = False


def era_bounds(era: str, _bounds=_BOUNDS, _eras=ERAS) -> tuple[int, int]:
    """(first_ts, last_ts), both inclusive. PRE's first and FORWARD's last are open sentinels."""
    try:
        return _bounds[era]
    except (KeyError, TypeError):
        raise ValueError(f"unknown era {era!r}; expected one of {_eras}") from None


def era_of(ts, _starts=_STARTS, _names=_NAMES):
    """Era name of ts (scalar -> str; array -> numpy object array of names)."""
    arr = np.asarray(ts)
    if arr.dtype.kind == "f":
        if np.isnan(arr).any():
            raise ValueError("era_of: NaN timestamp")
    idx = np.searchsorted(_starts, arr.astype(np.int64), side="right")
    out = _names[idx]
    if np.ndim(ts) == 0:
        return str(out)
    return out


def era_index(ts, _starts=_STARTS):
    """0..6 in ERAS order (vectorised)."""
    return np.searchsorted(_starts, np.asarray(ts).astype(np.int64), side="right")


decision_era = era_of


def era_last_ts(decision_ts, _ends=_ENDS, _index=era_index):
    """Last ts_utc of each decision's era (vectorised)."""
    return _ends[_index(decision_ts)]


def cut_at_era_end(decision_ts, exit_ts, bar_ts=None):
    """Apply the "cut" rule.

    decision_ts, exit_ts: planned exit BAR OPEN times (arrays or scalars).
    bar_ts: optional sorted array of available bar open times. When given, a cut exit is snapped
    to the last bar whose open time is <= the era's last ts (the era's last bar).
    Returns (exit_ts_out, cut_mask). A trade whose planned exit bar opens after its decision era's
    last ts is cut: its exit becomes the era's last bar, priced at that bar's bid/ask close.

    WARNING: without bar_ts a cut exit is the era's LAST SECOND (for example 1701388799), NOT a
    bar open time. A caller that prices "that bar's close" must pass bar_ts (the bar open times
    it holds), or look the bar up itself.
    """
    d = np.asarray(decision_ts, dtype=np.int64)
    x = np.asarray(exit_ts, dtype=np.int64)
    last = era_last_ts(d)
    cut = x > last
    out = np.where(cut, last, x)
    if bar_ts is not None:
        b = np.asarray(bar_ts, dtype=np.int64)
        pos = np.searchsorted(b, last, side="right") - 1
        if np.any(cut & (pos < 0)):
            raise ValueError("cut_at_era_end: no bar at or before the era end")
        snapped = b[np.clip(pos, 0, len(b) - 1)]
        out = np.where(cut, snapped, out)
    if np.ndim(decision_ts) == 0 and np.ndim(exit_ts) == 0:
        return int(out), bool(cut)
    return out, cut


def drop_labels_crossing(label_end_ts, decision_ts):
    """KEEP mask: True where the label's end lies in the same era as its decision."""
    le = np.asarray(label_end_ts, dtype=np.int64)
    d = np.asarray(decision_ts, dtype=np.int64)
    keep = le <= era_last_ts(d)
    if np.any(le < d):
        raise ValueError("drop_labels_crossing: a label ends before its decision")
    return keep


def walk_forward_splits(ts, n_folds=None, boundaries=None, purge_gap_seconds=None,
                        label_horizon_seconds=None):
    """Expanding-window walk-forward splits on BUILD rows only (2010-01-01 to 2021-12-31; a PRE row is refused).

    ts: array of decision times (any order). Exactly one of
      n_folds: the unique sorted times are cut into n_folds + 1 equal-count blocks; block 0 is
        training only and blocks 1..n_folds are the test folds;
      boundaries: increasing ts values b_1 < ... < b_k; test fold i is [b_i, b_{i+1}) (the last
        one runs to the end of BUILD).
    purge_gap_seconds: required, and >= label_horizon_seconds (required too). Training rows for a
      test fold starting at b are those with ts < b - purge_gap_seconds, so no training label
      (ending at most label_horizon_seconds after its decision) reaches the test fold.
    Returns a list of (train_idx, test_idx) integer index arrays into ts.
    """
    t = np.asarray(ts, dtype=np.int64)
    if purge_gap_seconds is None or label_horizon_seconds is None:
        raise ValueError("walk_forward_splits needs purge_gap_seconds and label_horizon_seconds")
    if purge_gap_seconds < label_horizon_seconds:
        raise ValueError("purge gap must be at least the label horizon")
    if len(t) and (t.max() >= BUILD_END or t.min() < BUILD_START):
        raise ValueError("walk_forward_splits is for BUILD rows only (1262304000 <= ts < 1640995200)")
    if (n_folds is None) == (boundaries is None):
        raise ValueError("give exactly one of n_folds or boundaries")
    if boundaries is None:
        u = np.unique(t)
        if n_folds < 1 or len(u) < n_folds + 1:
            raise ValueError("not enough distinct times for n_folds")
        cuts = np.array_split(u, n_folds + 1)
        bnds = [int(c[0]) for c in cuts[1:]]
    else:
        bnds = [int(b) for b in boundaries]
        if any(b2 <= b1 for b1, b2 in zip(bnds, bnds[1:])):
            raise ValueError("boundaries must increase")
    bnds_end = bnds[1:] + [BUILD_END]
    out = []
    for b, e in zip(bnds, bnds_end):
        test = np.flatnonzero((t >= b) & (t < e))
        train = np.flatnonzero(t < b - purge_gap_seconds)
        out.append((train, test))
    return out
