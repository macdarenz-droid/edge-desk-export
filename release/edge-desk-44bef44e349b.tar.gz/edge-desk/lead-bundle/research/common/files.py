"""Read a department's own NON-price table, text or binary file whose path is a parameter or comes from the
command line (calendars, trade lists, logs). It refuses a price file: one whose header has bid/ask
or OHLC bar columns, or whose sha256 is a registered price data set. Price bars are read only with
research.common.loaders (load_m1 / load_bars); the guard test treats these helpers as checked readers.
"""
from __future__ import annotations

import gzip
import hashlib
import io
from pathlib import Path

import pandas as pd

PRICE_COLS = {"bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c"}
BAR_COLS = {"o", "h", "l", "c"}


class PriceFileRefused(PermissionError):
    pass


def _open_text(path: Path):
    return gzip.open(path, "rt") if str(path).endswith(".gz") else open(path, encoding="utf-8")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _refuse_price(path: Path, header: list[str]) -> None:
    cols = {c.strip().lower() for c in header}
    if cols & PRICE_COLS or BAR_COLS <= cols:
        raise PriceFileRefused(f"{path}: has price-bar columns; read prices with load_m1 / load_bars")
    from research.common.loaders import registry
    shas = {d["sha256"] for d in registry().values()}
    if _sha256(path) in shas:
        raise PriceFileRefused(f"{path}: is a registered price data set; read it with load_m1 / load_bars")


def read_table(path, **kw) -> pd.DataFrame:
    """pandas.read_csv for a non-price CSV (plain or .gz)."""
    path = Path(path)
    with _open_text(path) as f:
        header = f.readline().rstrip("\n").split(kw.get("sep", ","))
    _refuse_price(path, header)
    return pd.read_csv(path, **kw)


def read_text(path) -> str:
    """Text of a non-price file (logs, JSON lines, notes)."""
    path = Path(path)
    with _open_text(path) as f:
        txt = f.read()
    first = txt.split("\n", 1)[0].split(",")
    _refuse_price(path, first)
    return txt


def read_bytes(path) -> bytes:
    """Raw bytes of a non-price file (a latin-1 statistics page, a PDF). The first line, decoded as
    latin-1 (after gunzip for .gz), gets the same price-bar header check as read_text, and the file's
    sha256 the same registry check."""
    path = Path(path)
    data = path.read_bytes()
    raw = gzip.decompress(data) if str(path).endswith(".gz") else data
    first = raw.split(b"\n", 1)[0].decode("latin-1").rstrip("\r").split(",")
    _refuse_price(path, first)
    return data
