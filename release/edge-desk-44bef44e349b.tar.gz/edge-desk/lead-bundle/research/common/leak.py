"""Truncation (leak) test helper (docs/EDGE_HUNT.md sections 4 item 6 and 5 "Looks").

A rule is causal when its decisions up to time t depend only on bars that closed by t. The test:
run the rule on the full data once; then, for each of N decision times t, run it again on the data
truncated to the bars that closed by t (bar open + bar length <= t) and assert that every decision
with decision_ts <= t is identical in both runs.

    from research.common.leak import truncation_test
    report = truncation_test(rule, data, n=50, seed=1)        # raises LeakFound on any mismatch

rule(data) -> DataFrame with a 'decision_ts' column (unix s) plus whatever it decides (side, level,
stop, ...). data: a bars DataFrame with ts_utc (bar open), or a dict {name: DataFrame} (several
pairs or timeframes, each truncated by its own bar length). bar_seconds: one int, or a dict by name;
default: inferred as the most common ts_utc step of each frame.
Decision times tested: N drawn (seeded) from the full run's decision times; ``times`` overrides.
Comparison: the columns in ``cols`` (default all), floats with atol (default 0: exact).
"""
from __future__ import annotations

import numpy as np
import pandas as pd


class LeakFound(AssertionError):
    pass


def _bar_s(df: pd.DataFrame) -> int:
    d = np.diff(df["ts_utc"].to_numpy(np.int64))
    if len(d) == 0:
        return 60
    v, c = np.unique(d, return_counts=True)
    return int(v[np.argmax(c)])


def truncate(data, t: int, bar_seconds=None):
    """Bars closed by t: ts_utc + bar length <= t."""
    if isinstance(data, dict):
        return {k: truncate(v, t, bar_seconds.get(k) if isinstance(bar_seconds, dict) else bar_seconds)
                for k, v in data.items()}
    bs = bar_seconds if bar_seconds is not None else _bar_s(data)
    ts = data["ts_utc"].to_numpy(np.int64)
    return data.iloc[: int(np.searchsorted(ts, t - bs, side="right"))]


def _norm(df: pd.DataFrame, t: int, cols) -> pd.DataFrame:
    d = df[df["decision_ts"].astype(np.int64) <= t]
    if cols is not None:
        d = d[list(cols)]
    return d.sort_values(list(d.columns)).reset_index(drop=True) if len(d) else d.reset_index(drop=True)


def _same(a: pd.DataFrame, b: pd.DataFrame, atol: float) -> tuple[bool, str]:
    if list(a.columns) != list(b.columns):
        return False, f"columns differ: {list(a.columns)} vs {list(b.columns)}"
    if len(a) != len(b):
        return False, f"{len(a)} decisions on full data, {len(b)} on truncated data"
    for c in a.columns:
        x, y = a[c].to_numpy(), b[c].to_numpy()
        if x.dtype.kind in "fc" or y.dtype.kind in "fc":
            xf, yf = x.astype(float), y.astype(float)
            ok = (np.isnan(xf) & np.isnan(yf)) | (np.abs(xf - yf) <= atol)
        else:
            ok = x == y
        if not np.all(ok):
            k = int(np.argmin(ok))
            return False, f"column {c!r} row {k}: full {x[k]!r} vs truncated {y[k]!r}"
    return True, ""


def truncation_test(rule, data, n: int = 50, seed: int = 0, times=None, bar_seconds=None,
                    cols=None, atol: float = 0.0, raise_on_fail: bool = True) -> dict:
    full = rule(data)
    if "decision_ts" not in full:
        raise ValueError("rule output needs a 'decision_ts' column")
    if times is None:
        dts = np.unique(full["decision_ts"].to_numpy(np.int64))
        if len(dts) == 0:
            raise ValueError("the rule made no decision on the full data; nothing to test")
        rng = np.random.default_rng(seed)
        times = np.sort(rng.choice(dts, size=min(n, len(dts)), replace=False))
    fails = []
    for t in times:
        t = int(t)
        cut = rule(truncate(data, t, bar_seconds))
        ok, why = _same(_norm(full, t, cols), _norm(cut, t, cols), atol)
        if not ok:
            fails.append({"t": t, "why": why})
    rep = {"tested": len(times), "failed": len(fails), "fails": fails[:20],
           "times": [int(x) for x in times]}
    if fails and raise_on_fail:
        raise LeakFound(f"look-ahead: {len(fails)} of {len(times)} truncations differ; first at "
                        f"t={fails[0]['t']}: {fails[0]['why']}")
    return rep
