"""Price loaders with the edge hunt's access rules (docs/EDGE_HUNT.md sections 3-6).

Every price read in research/departments/ goes through ``load_m1`` / ``load_bars`` (a guard
test enforces it). What they do:

1. Find the data sets (registry below, plus research/common/datasets.json, or the JSON file in
   $FX_DATASETS_JSON) whose period overlaps the requested era, under $FX_DATA_ROOT
   (default ~/.cache/fx_data), at each entry's ``relpath``.
2. Check each file's sha256 on every read, in every era, and refuse on mismatch: the reader hashes
   the exact bytes it parses (the file is read once into memory, hashed, then parsed) and raises
   DataIntegrityError before parsing (release 7, coordinator, 14 Oct 2026). No marker is trusted, so a file or a .verified
   marker that some other process wrote cannot change what a read returns.
3. Apply the access rules:
   - era='BUILD' (default): rows with 1262304000 <= ts_utc < 1640995200 only. No log line.
   - era='PRE' (rows before 1262304000, 2010-01-01): refused while research.common.eras.PRE_OPEN is False
     (locked by default; coordinator, DATA-PRE-2, 15 Oct 2026). Only a release carrying STATS's PRE ruling sets it,
     with that ruling's read rules; until then no PRE row is served by any read (BUILD starts at 2010-01-01), and
     PRE must be read on its own.
   - era='C', 'T' or 'C+T': needs dept, study and frozen=<path>. The checks:
     a. FROZEN path: research/departments/<DEPT>/<study>/FROZEN.json (STATS: any
        research/departments/STATS/.../<study>/FROZEN.json, one JSON object; STATS's byte copies
        of picks' FROZEN files need no more, since STATS is exempt from the checks the keys feed).
        A department's own FROZEN is a JSON object with the section 4 item 2 keys
        (``frozen_problems``): "study" and "dept" (equal to the read's), "spec" (the selection rule's output and the BUILD effect, PASS_BAR section 1
        item 3), "expected_counts", "pins" ({repo path: sha256} of every file run, including each
        research/common file), the declaration's sha256 ("declaration": {"sha256"} or
        "decl_sha256"), and a {"sha256", "commit" or "last_commit"} record for
        research/departments/STATS/PASS_BAR.md and research/departments/COST/COST_MODEL.json
        (both also in "pins").
     b. ``git fetch origin dept/<dept>`` must succeed (no offline fallback), its head must equal
        ``git ls-remote origin refs/heads/dept/<dept>`` (a failed attempt is retried after 1, 3
        and 9 s, PUSHED_HEAD_DELAYS, and refused after the fourth), and every pushed file is read
        from that commit with each git object's hash checked (replace refs and changed local
        objects are refused). For a script main (not STATS) that head must be in the checkout's
        history (``git merge-base --is-ancestor <head> HEAD``): a look runs from a checkout of
        its own department's branch.
     c. The PUSHED FROZEN.json has the local file's sha256, and the PUSHED
        research/departments/<DEPT>/LOOKS.jsonl has a "started" line with that frozen_sha256,
        study and era ('C+T' needs a C and a T line). A "done" or "aborted" line for that
        frozen_sha256 and era, pushed or local, refuses the read as a second look (STATS exempt).
        A T-only read also needs a pushed "done" C line (T after C; STATS exempt; one C+T read is
        allowed).
     d. Code pin (STATS exempt): the sha256 of the main script (access.code_sha256_of_main: the
        file the interpreter runs, unchanged since it started) equals the started line's
        "code_sha256" or "main_sha256", equals FROZEN pins[<main script path>], and every module
        loaded from research/departments/<DEPT>/ is in "pins" with its current sha256 (a pytest
        main on synthetic data: its sha256 among the pins values); the started line's
        "decl_sha256" equals the FROZEN declaration sha256.
     e. One look = one run (STATS exempt): a read is refused when the local or pushed ACCESS_LOG
        already holds a read of that frozen_sha256 and era by another run (access.run_id).
     f. History for a T look (STATS ruling, AUDITS.md dept/stats f319c711; coordinator, 14 Oct 2026):
        ``history_for='T'`` with era 'C' reads the lookback a T run needs from C without a second C
        look. FROZEN.json holds "history_lookback_days" (a whole number, 1 to 400: the pick's longest
        declared lookback); the pushed T "started" line names "needs_history_eras" (here ["C"]) and
        the same "history_lookback_days". Only rows in [T start - that bound, T start) are served,
        with every T check above (b to e, for era T) applied; the read is logged with kind
        "history", history_for "T" and the bound, under this run's run_id, and counts as part of
        the T look in check e. Anything else is refused. Not for STATS (its locked runner reads its
        own lagged rows, capped at 400 days) or for locked eras.
   - era 'VALIDATION', 'HOLDOUT' or 'FORWARD' (rows >= 1751317200): dept='STATS' only, and
     override=(kind, ledger_id) or (kind, ledger_id, decision_ts) or {'kind', 'ledger_id',
     'decision_ts'}. 'validation' opens VALIDATION only, 'holdout' HOLDOUT only, 'forward_inputs'
     any locked era. The ledger id must be the run_id of a PUSHED start line on origin/dept/stats
     with no closing line (pushed or local): 'validation' a "validation_run_start" event in
     research/VALIDATION2_LEDGER.jsonl or a "holdout_run_start" event in
     research/HOLDOUT_LEDGER.jsonl (a holdout run reads its picks' validation lookback), 'holdout'
     a "holdout_run_start" event, 'forward_inputs' a "forward_run_start" line (its ledger_id) in
     research/departments/STATS/ACCESS_LOG.jsonl, closed by "forward_run_done" (ledger_id) or
     "forward_stale_lock_cleared" (cleared_ledger_id). 'forward_inputs' reads only rows from
     FORWARD_START - 400 days on; with decision_ts (>= FORWARD_START) only [decision_ts - 400
     days, decision_ts). Only data sets registered with "locked": true and no branch (STATS's own
     local files) can serve these rows.
   - Who is calling (audit findings #2 and #4): for real data (a set whose sha256 is in the
     built-in registry or research/common/datasets.json, or a file under a real data root, or a
     hard-linked file) the repo root must be the checkout that holds this package
     (FX_REPO_ROOT may not point elsewhere) and its origin must be
     github.com/macdarenz-droid/Forex-signal; the main script must sit in
     research/departments/<DEPT>/<study>/ (STATS: research/departments/STATS/), so dept, study and
     STATS's exemptions follow from where the code lives; pytest is refused. For synthetic data
     (tests) a pytest main may read with any dept, and FX_REPO_ROOT and a local origin are
     honoured; every other check still applies.
   - Every C, T or locked read appends a line to research/departments/<DEPT>/ACCESS_LOG.jsonl
     (research/common/access.py) with run_id, fetch_ok, origin_commit, main_path and synthetic.
4. Refuse the data/round21 ``derived/`` files (r15, r17, r18, r19 tables, daytable, c2 flags):
   outcome labels including 2022-2023, not for hunters.
5. Changed at runtime (audit finding #8): every read first checks that no attribute of this module,
   eras, access or looks (and no function's code, defaults or closure) differs from its value at
   import, and refuses otherwise; the reader runs only when called by the loader itself.
6. DATA and STATS only (coordinator, 14 Oct 2026, after another department's scratchpad script called
   fetch_dataset): ``fetch_dataset``, ``verify_file`` and research.common.macro's ``fetch`` and
   ``macro_dir`` refuse a call unless the first caller frame outside the Python libraries is code in
   this checkout's research/common/, research/data/, research/departments/DATA/ or
   research/departments/STATS/ (its file path, resolved). A scratchpad script, ``python -c``, stdin
   or another department's folder is refused; load_m1 / load_bars and macro.load reach them through
   their own logged path. One exception: a department's tests/ folder may call macro.fetch for a test world, a
   repo outside this checkout whose origin is not the GitHub repo (the static guard exempts tests there too). A file name forged with compile() or a file placed in those folders is
   not caught here (the static guard and STATS's audits cover committed code).

Git commands used (git docs: git-fetch, git-ls-remote, git-remote get-url, git-cat-file, git-show,
git-ls-tree, git --no-replace-objects): ``git fetch origin +refs/heads/<b>:refs/remotes/origin/<b>``,
``git ls-remote origin refs/heads/<b>``, ``git remote get-url --all origin`` (insteadOf expanded),
``git cat-file <type> <sha>`` (raw object; hashed here as "<type> <len>\\0<data>"),
``git rev-parse --show-object-format``, ``git show origin/<b>:<path>``, ``git ls-tree --name-only``.
"""
from __future__ import annotations

import builtins
import copy
import gzip
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import tarfile
import tempfile
import time
import types
from pathlib import Path
from types import MappingProxyType

import numpy as np
import pandas as pd

from . import access as A
from . import eras as E
from . import looks as K
from .access import code_sha256_of_main, common_sha256, log_access, main_info, run_id
from .looks import check_dept, package_root, read_looks_text, repo_root, sha256_file

M1_COLS = ["bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c", "volume"]
MID_COLS = ["o", "h", "l", "c", "volume"]
GRANULARITY_SECONDS = MappingProxyType({"M1": 60, "M5": 300, "M15": 900, "M30": 1800, "H1": 3600,
                                        "H4": 14400})
OVERRIDE_KINDS = MappingProxyType({"validation": ("VALIDATION",), "holdout": ("HOLDOUT",),
                                   "forward_inputs": ("VALIDATION", "HOLDOUT", "FORWARD")})
DERIVED_PATTERN = re.compile(r"(^|/)derived/|r1[5789]_|daytable|c2_flags", re.I)
ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,63}")   # ledger and study ids (DATA's downloader)
GITHUB_ORIGIN = re.compile(r"(?:https://github\.com/|git@github\.com:|ssh://git@github\.com/)"
                           r"macdarenz-droid/Forex-signal(?:\.git)?/?")
FORWARD_LAG_SECONDS = 400 * 86400                  # docs/EDGE_HUNT.md section 3: lagged inputs only
HISTORY_KEY = "history_lookback_days"              # FROZEN.json and the T 'started' line (item 3f)
HISTORY_MAX_DAYS = 400                             # the locked runner's cap on lagged rows
HISTORY_TARGETS = MappingProxyType({"T": ("C",)})  # target era -> eras a history read may name
# kind -> the runs whose id opens it, each (ledger file on origin/dept/stats, key, start value,
# id key, closing records as (value, id key)). A holdout run's id also opens 'validation': a
# holdout run reads the validation rows inside its picks' lookback (STATS run_holdout.py, its
# lagged inputs) with override ('validation', <holdout run id>).
_VAL_RUN = ("research/VALIDATION2_LEDGER.jsonl", "event", "validation_run_start", "run_id",
            (("validation_run_end", "run_id"), ("validation_run_error", "run_id")))
_HOLD_RUN = ("research/HOLDOUT_LEDGER.jsonl", "event", "holdout_run_start", "run_id",
             (("holdout_run_end", "run_id"), ("holdout_run_error", "run_id")))
_FWD_RUN = ("research/departments/STATS/ACCESS_LOG.jsonl", "kind", "forward_run_start", "ledger_id",
            (("forward_run_done", "ledger_id"), ("forward_stale_lock_cleared", "cleared_ledger_id")))
LEDGERS = MappingProxyType({
    "validation": (_VAL_RUN, _HOLD_RUN),
    "holdout": (_HOLD_RUN,),
    "forward_inputs": (_FWD_RUN,),
})
# Seconds between attempts of the live fetch + ls-remote check (4 attempts in all): one proxy
# cut-off, connection reset or concurrent push must not refuse a read that STATS makes after its
# start line is pushed (that would spend the run). Every success still needs a live fetch and the
# local ref equal to ls-remote.
PUSHED_HEAD_DELAYS = (1, 3, 9)
FROZEN_KEYS = ("study", "dept", "spec", "expected_counts", "pins")
FROZEN_COMMIT_PINS = ("research/departments/STATS/PASS_BAR.md",
                      "research/departments/COST/COST_MODEL.json")
_HEX64 = re.compile(r"[0-9a-f]{64}")
_HEXC = re.compile(r"[0-9a-f]{7,64}")
# git environment variables that would point git at other objects, refs or repos, or turn off TLS
# checks; the loaders' git calls run without them (and with --no-replace-objects).
_GIT_ENV_DROP = frozenset({
    "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY", "GIT_COMMON_DIR",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_NAMESPACE", "GIT_REPLACE_REF_BASE", "GIT_SHALLOW_FILE",
    "GIT_GRAFT_FILE", "GIT_QUARANTINE_PATH", "GIT_SSL_NO_VERIFY", "GIT_CEILING_DIRECTORIES",
    "GIT_DISCOVERY_ACROSS_FILESYSTEM", "GIT_NO_REPLACE_OBJECTS"})


class AccessDenied(PermissionError):
    """A read the hunt's rules do not allow."""


class DataIntegrityError(RuntimeError):
    """A file whose sha256 does not match the registry."""


# --------------------------------------------------------------------------------------------
# Registry
# --------------------------------------------------------------------------------------------
_P1 = (1262304000, 1451606399)      # 2010-01-01 .. 2015-12-31 23:59:59
_P2 = (1451606400, E.C_END)         # 2016-01-01 .. 2023-11-30 23:59:59
_P3 = (E.T_START, E.T_END)          # 2023-12-01 .. 2025-06-30 20:59:59

_XASSET_D2 = MappingProxyType({
    "AUD_USD": "36e87c23c9d070c3130475010288c18bcc1957e9aecec9d976f1026f39354333",
    "BCO_USD": "7b45d08c5a35c4dad509f9e7e2d18521454669c0f615cc516d24ef9cc0176482",
    "DE10YB_EUR": "c5203353bad9a7e9871525e62e09df1bc75acbe5ac731f78df07e0036dc6387a",
    "DE30_EUR": "55ea7182796e3a266e12014d8af91f3c1a217a4fd4bdcffccac8b89e38c34111",
    "EUR_GBP": "cb863838449b360e8a4a16f8ba73e78dc85ce571a3e7fd79f5ce6bfc931e4067",
    "JP225_USD": "a82043b428b5484347035e530773de5505c8f9315319bee1c014c6552b9b7df3",
    "NAS100_USD": "14c9117813199a40bb19c14196e03676fc5dfb9bb0264416d8ec33b091464f06",
    "SPX500_USD": "1626947d5d06ff0be06559f7febca1834f6e45fd0d1385b10aef3946e22bf290",
    "UK100_GBP": "9965e36d15d26b10fd8dcde84007b951e33a5110e1e4beff8f915eaf46fec8ac",
    "UK10YB_GBP": "a6b8d4b1ce29b70bc3ea882b3b2963d8d684192f8c200b17cc8637b8a7b3f23f",
    "USB02Y_USD": "76c547009968d6e8feca24817ef2589d6e32fae48aecb8b39164918c6f1b3e99",
    "USB10Y_USD": "2768d2a1a25019b0b58270d2061fe9eac04af707a7bb8edcc7eba8bd61e7d76c",
    "USD_CAD": "74b1231f379b9afeea9572fea1bf71f48a3a238a2e0d053a472d26356e184800",
    "USD_CHF": "2ba73f1c20f93ebfd6ee874f2ad8ea9c6963b1bae60cb77b4c98f1c2ea3306db",
    "USD_JPY": "016d4c0ebc6a5db370a24203fbf4a34bb751f10f170f8dd853a7ae17b664d3b9",
    "XAU_USD": "1677b2aff1f2507a5acd936d35a8fed06f8d38250b9d198ee5f22c19940c96da",
})
_XASSET_ERA3 = MappingProxyType({
    "AUD_USD": "bb38459e5a3d3b3435792267012623e369a0ebe4c29b3dff8c330a893c09621b",
    "BCO_USD": "d46fb7a6f59470c09558cc142bbacb4a5308cc245d82aca7dc495ddf6e09ad32",
    "DE10YB_EUR": "a12c9e53164734ac4dcce03673c3537cede3e545717042dbeff01d1125085b19",
    "DE30_EUR": "b476b36c27a6ab4cd9ca2c043cdd14e79f180b120d92504a993bf19aa6ad686d",
    "EUR_GBP": "1d96f81b17a9bbcf55a37e5a05550f7c6cc6ee49e11a3d532c98bc590b12b6f6",
    "JP225_USD": "a730b9eb65a89ee891229c8405d7f7d1cc21ff60850d403b30b4790170088de7",
    "NAS100_USD": "f55b75078166f177479230f08d57ce818ff426311216823cfec034d107ff3413",
    "SPX500_USD": "15dbd8d867ca64a8274b31c13d9803da44f4a30d8f060039714410ffda283a5a",
    "UK100_GBP": "4581f523533cea8c81a51f696f874e97cabb05db9f131a3490e27708b805207f",
    "UK10YB_GBP": "fd59707ec090f680805fcf8c58960bcaa0cb37a333b279b7fdb46a07fe6d1f29",
    "USB02Y_USD": "13df35ca6ca56ceb8e9e29aa10a6c8558ea4ca0a1df95ed6707c014b2d62baa7",
    "USB10Y_USD": "e4489b7cc2c36396094a467a1cb42da6a71b15c4c51f55812076ddd6a43746f5",
    "USD_CAD": "6515fd3d35c2f59ac5a1821ecfda3f91a6dcc4fc0db7045d232c50bb2d2fd6b0",
    "USD_CHF": "e0463a421bc15f5e563b37acbea94f18a37863cb137ad03a23a8570d9fef4450",
    "USD_JPY": "a38c4155c8b7e9fe5754a925dad62226a9e4050960b2caa39ebade04267be4a4",
    "XAU_USD": "5f3c7802d1935eaa807e260470c2af78e8e63f6faab322d8848fe069aeac37d9",
})


def _builtin_registry() -> list[dict]:
    m1 = [
        ("EUR_USD_M1_BA_2010_2015", "EUR_USD", _P1, "data/eurusd-2010-2015",
         "EURUSD_M1_BA_2010_2015.csv.gz", False,
         "d683ea3fc7f4273198d10aa89c67188a3087ee186598bf326206fca941c7b06d",
         "eurusd_2010_2015/EURUSD_M1_BA_2010_2015.csv", True),
        ("GBP_USD_M1_BA_2010_2015", "GBP_USD", _P1, "data/gbpusd-2010-2015",
         "GBPUSD_M1_BA_2010_2015.csv.gz", False,
         "7e6bdd9220c8e9d544a677b8885b8ce7bb7cfc12d52b701b25ba14beb72b3443",
         "gbpusd_2010_2015/GBPUSD_M1_BA_2010_2015.csv", True),
        ("EUR_USD_M1_BA_2016_2023", "EUR_USD", _P2, "data/round21",
         "prices_2016_2023/OLD_EURUSD_M1_BA_2016_2023.csv.gz", True,
         "cbeba6e7736ab6c7ea9276eead834a5d8925b772e75125e017a5c0a4a6ac48f8",
         "r21/prices_2016_2023/OLD_EURUSD_M1_BA_2016_2023.csv", True),
        ("GBP_USD_M1_BA_2016_2023", "GBP_USD", _P2, "data/round21",
         "prices_2016_2023/OLD_GBPUSD_M1_BA_2016_2023.csv.gz", True,
         "8d9700fde7964d53544eb7e2b3053645744ac6348cc39e5a39c42f0ef6736370",
         "r21/prices_2016_2023/OLD_GBPUSD_M1_BA_2016_2023.csv", True),
        ("EUR_USD_M1_BA_2023_2025", "EUR_USD", _P3, "data/round21",
         "prices_dec2023_jun2025/EURUSD_M1_BA_to_2025-06-30.csv.gz", False,
         "57a54121c457f49f023356efb0fc0738d68aa46115997cf06eadce17ddfd3c44",
         "r21/prices_dec2023_jun2025/EURUSD_M1_BA_to_2025-06-30.csv", True),
        ("GBP_USD_M1_BA_2023_2025", "GBP_USD", _P3, "data/round21",
         "prices_dec2023_jun2025/GBPUSD_M1_BA_to_2025-06-30.csv.gz", False,
         "74cef91b0f04e29ef8e8bdc45a19991dd56510ebf23fcae295b538ffe360c8f8",
         "r21/prices_dec2023_jun2025/GBPUSD_M1_BA_to_2025-06-30.csv", True),
    ]
    out = []
    for name, inst, (a, b), br, path, parts, sha, rel, pushed in m1:
        out.append(dict(name=name, instrument=inst, granularity="M1", price="BA",
                        first_ts=a, last_ts=b, branch=br, branch_path=path, parts=parts,
                        packing="gz", tar_member=None, sha256=sha, relpath=rel, pushed=pushed))
    for tag, period, table in (("d2", _P2, _XASSET_D2), ("era3", _P3, _XASSET_ERA3)):
        yrs = "2016_2023" if tag == "d2" else "2023_2025"
        for inst, sha in table.items():
            fn = f"{inst}_M15_M.csv"
            out.append(dict(name=f"{inst}_M15_M_{yrs}", instrument=inst, granularity="M15",
                            price="M", first_ts=period[0], last_ts=period[1],
                            branch="data/round21", branch_path=f"xasset/fxdata_xasset_{tag}.tar.gz",
                            parts=False, packing="tar.gz", tar_member=f"fxdata_xasset_{tag}/{fn}",
                            sha256=sha, relpath=f"r21/xasset/fxdata_xasset_{tag}/{fn}", pushed=True))
    return out


_REQUIRED = ("name", "instrument", "granularity", "price", "first_ts", "last_ts", "sha256",
             "relpath")


def _validate_entry(e: dict) -> dict:
    for k in _REQUIRED:
        if e.get(k) in (None, ""):
            raise ValueError(f"dataset {e.get('name')!r}: missing {k}")
    if not re.fullmatch(r"[0-9a-f]{64}", e["sha256"]):
        raise ValueError(f"dataset {e['name']}: sha256 must be 64 hex chars")
    for k in ("branch_path", "relpath", "tar_member"):
        if e.get(k) and DERIVED_PATTERN.search(str(e[k])):
            raise AccessDenied(f"dataset {e['name']}: {e[k]} is a data/round21 derived/ outcome "
                               "file (labels incl. 2022-2023): not for hunters")
    if e["price"] not in ("BA", "M"):
        raise ValueError(f"dataset {e['name']}: price must be 'BA' or 'M'")
    if int(e["last_ts"]) >= E.LOCK_START or int(e["first_ts"]) >= E.LOCK_START:
        if not e.get("locked") or e.get("branch"):
            raise AccessDenied(f"dataset {e['name']}: rows at or after 1751317200 may only be a "
                               "STATS local data set with locked=true and no branch")
    elif e.get("locked"):
        raise ValueError(f"dataset {e['name']}: locked=true only for rows >= 1751317200")
    if int(e["first_ts"]) < E.PRE_END <= int(e["last_ts"]):
        raise ValueError(f"dataset {e['name']}: rows before 2010-01-01 (era PRE) go in their own data set, "
                         "not mixed with later rows")
    e.setdefault("parts", False)
    e.setdefault("packing", "gz")
    e.setdefault("tar_member", None)
    e.setdefault("branch", None)
    e.setdefault("branch_path", None)
    e.setdefault("pushed", False)
    e.setdefault("locked", False)
    e["instrument"] = normalise_instrument(e["instrument"])
    return e


def datasets_json_path() -> Path:
    env = os.environ.get("FX_DATASETS_JSON")
    return Path(env) if env else Path(__file__).resolve().parent / "datasets.json"


def registry(include_builtin: bool | None = None) -> dict[str, dict]:
    """name -> entry. Built-ins plus the entries of datasets.json (a JSON list of objects with the
    built-in fields). Set FX_REGISTRY_BUILTIN=0 to drop the built-ins (tests)."""
    if include_builtin is None:
        include_builtin = os.environ.get("FX_REGISTRY_BUILTIN", "1") != "0"
    entries = [dict(e) for e in _builtin_registry()] if include_builtin else []
    p = datasets_json_path()
    if p.exists():
        extra = json.loads(p.read_text())
        if not isinstance(extra, list):
            raise ValueError(f"{p} must hold a JSON list")
        entries += [dict(e) for e in extra]
    reg: dict[str, dict] = {}
    for e in entries:
        e = _validate_entry(e)
        if e["name"] in reg:
            raise ValueError(f"duplicate dataset name {e['name']}")
        reg[e["name"]] = e
    return reg


CATALOG_FIELDS = ("name", "instrument", "granularity", "price", "first_ts", "last_ts", "locked")


def catalog() -> list[dict]:
    """Metadata of every registered data set, for coverage checks before any read: name, instrument,
    granularity, price ('BA' or 'M'), first_ts, last_ts (the set's period, unix s) and locked. No path,
    branch or hash is exposed, and no data file is opened (it reads only the registry JSON)."""
    return [{k: e[k] for k in CATALOG_FIELDS} for e in sorted(registry().values(), key=lambda d: d["name"])]


def normalise_instrument(s: str) -> str:
    s = s.strip().upper()
    if "_" not in s and len(s) == 6 and s.isalpha():
        s = s[:3] + "_" + s[3:]
    return s


def data_root() -> Path:
    return Path(os.environ.get("FX_DATA_ROOT", "~/.cache/fx_data")).expanduser()


# --------------------------------------------------------------------------------------------
# real or synthetic data (audit finding #2)
# --------------------------------------------------------------------------------------------
_DEFAULT_ROOT = Path("~/.cache/fx_data").expanduser()
_PACKAGE_DATASETS = Path(__file__).resolve().parent / "datasets.json"


def _package_entries() -> list[dict]:
    """The package's own registry entries (never $FX_DATASETS_JSON), as (sha256, relpath) dicts."""
    out = [{"sha256": e["sha256"], "relpath": e["relpath"]} for e in _builtin_registry()]
    try:
        extra = json.loads(_PACKAGE_DATASETS.read_text())
    except (OSError, ValueError):
        extra = []
    if isinstance(extra, list):
        out += [{"sha256": e.get("sha256"), "relpath": e.get("relpath")} for e in extra
                if isinstance(e, dict) and e.get("sha256") and e.get("relpath")]
    return out


_REAL_SHAS = frozenset(e["sha256"] for e in _package_entries())
_REAL_RELPATHS = tuple(sorted({e["relpath"] for e in _package_entries()}))


def _is_real_root(d: Path, relpaths) -> bool:
    """A directory that holds the real price cache: the default root, or one with a file of the
    package registry at its relpath."""
    try:
        if d == _DEFAULT_ROOT.resolve():
            return True
    except OSError:
        return True
    return any((d / rp).exists() for rp in relpaths)


def _real_data(sets) -> bool:
    """True unless every data set of the read is clearly synthetic: its sha256 is in no package
    registry entry, neither the data root nor any folder above the file's real location is a real
    data root, and the file has no other hard link."""
    entries = _package_entries()
    shas = _REAL_SHAS | {e["sha256"] for e in entries}
    relpaths = tuple(sorted(set(_REAL_RELPATHS) | {e["relpath"] for e in entries}))
    if any(d["sha256"] in shas for d in sets):
        return True
    root = data_root()
    try:
        if _is_real_root(root.resolve(), relpaths):
            return True
        for d in sets:
            p = root / d["relpath"]
            if not p.exists():
                continue
            if p.stat().st_nlink > 1:
                return True
            if any(_is_real_root(a, relpaths) for a in p.resolve().parents):
                return True
    except OSError:
        return True
    return False


# --------------------------------------------------------------------------------------------
# sha256 verification (audit finding #21; release 7: no markers) and the DATA/STATS-only rule
# --------------------------------------------------------------------------------------------
_INTERNAL_DIRS = ("research/common/", "research/data/", "research/departments/DATA/",
                  "research/departments/STATS/")


def _library_prefixes() -> tuple[str, ...]:
    from .audit import _library_prefixes as lp          # the same library rule as the audit hook
    return lp()


_DEPT_TEST = re.compile(r"research/departments/[^/]+/(?:[^/]+/)*tests/")


def _first_caller(skip: int) -> tuple[str | None, str | None]:
    """(path relative to this package's root, None) of the first caller frame outside the Python libraries
    (``skip`` frames above the caller of this function), or (None, reason) when it is not a file of this checkout."""
    f = sys._getframe(skip + 1)
    libs = _library_prefixes()
    while f is not None:
        cf = f.f_code.co_filename
        if cf.startswith("<frozen") or "/site-packages/" in cf or "/dist-packages/" in cf \
                or any(cf.startswith(pre) for pre in libs):
            f = f.f_back
            continue
        if not os.path.isabs(cf):
            return None, f"called from {cf!r}"
        try:
            return Path(cf).resolve().relative_to(package_root().resolve()).as_posix(), None
        except (OSError, ValueError):
            return None, f"called from {cf}, outside this checkout"
    return None, "called with no caller outside the Python libraries"


def internal_caller_problem(skip: int = 1, tests_ok: bool = False) -> str | None:
    """None when the first caller frame outside the Python libraries (``skip`` frames above the caller of this
    function) is code of this checkout's research/common/, research/data/, research/departments/DATA/ or
    research/departments/STATS/ (with tests_ok, also a department's tests/ folder); else the reason (module
    docstring item 6). Decided on the frame's resolved file path against this package's own root (never
    $FX_REPO_ROOT). '<string>', '<stdin>' and other pseudo-files, and only-library stacks (a thread or pool
    worker), are refused."""
    rel, why = _first_caller(skip + 1)
    if rel is None:
        return why
    if rel.startswith(_INTERNAL_DIRS) or (tests_ok and _DEPT_TEST.match(rel)):
        return None
    return f"called from {rel}"


def require_internal_caller(name: str, skip: int = 1, tests_ok: bool = False) -> None:
    why = internal_caller_problem(skip + 1, tests_ok)
    if why is not None:
        raise AccessDenied(f"{name} is for DATA and STATS only ({why}); department code reads prices with "
                           "load_m1 / load_bars and macro data with macro.load, which fetch and check on "
                           "demand (coordinator, 14 Oct 2026)")


def verify_file(path: Path, sha: str, force: bool = True) -> None:
    """Refuse a file whose sha256 differs from sha. The file is hashed on every call; no marker is
    trusted (release 7). ``force`` is kept for callers that pass it and changes nothing. DATA and
    STATS only (module docstring item 6)."""
    require_internal_caller("verify_file")
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"{path} not found (fetch_dataset or set FX_DATA_ROOT)")
    got = sha256_file(path)
    if got != sha:
        raise DataIntegrityError(f"{path}: sha256 {got} != expected {sha}; refusing to load")


# --------------------------------------------------------------------------------------------
# git helpers
# --------------------------------------------------------------------------------------------
def _git_env() -> dict:
    env = {k: v for k, v in os.environ.items() if k not in _GIT_ENV_DROP}
    env["GIT_NO_REPLACE_OBJECTS"] = "1"
    return env


def _git_run(args, repo: Path, **kw) -> subprocess.CompletedProcess:
    kw.setdefault("capture_output", True)
    return subprocess.run(["git", "--no-replace-objects", "-c", "http.sslVerify=true", "-C", str(repo)]
                          + list(args), env=_git_env(), **kw)


def _git(args, repo: Path, binary: bool = False, check: bool = True):
    r = _git_run(args, repo)
    if check and r.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {r.stderr.decode(errors='replace').strip()}")
    return r if not check else (r.stdout if binary else r.stdout.decode())


def _fetch_branch(branch: str, repo: Path) -> bool:
    r = _git_run(["fetch", "--quiet", "origin", f"+refs/heads/{branch}:refs/remotes/origin/{branch}"],
                 repo)
    return r.returncode == 0


def _ref_exists(ref: str, repo: Path) -> bool:
    return _git_run(["rev-parse", "--verify", "--quiet", ref], repo).returncode == 0


def _show(ref_path: str, repo: Path) -> bytes | None:
    r = _git_run(["show", ref_path], repo)
    return r.stdout if r.returncode == 0 else None


def _origin_ok(repo: Path) -> bool:
    """Every URL of origin (insteadOf expanded) is the GitHub repo macdarenz-droid/Forex-signal."""
    r = _git_run(["remote", "get-url", "--all", "origin"], repo)
    if r.returncode:
        return False
    urls = [u.strip() for u in r.stdout.decode(errors="replace").splitlines() if u.strip()]
    return bool(urls) and all(GITHUB_ORIGIN.fullmatch(u) for u in urls)


def _object_format(repo: Path) -> str:
    r = _git_run(["rev-parse", "--show-object-format"], repo)
    fmt = r.stdout.decode().strip() if r.returncode == 0 else ""
    return fmt if fmt in ("sha1", "sha256") else "sha1"


def _pushed_head_once(branch: str, repo: Path) -> str:
    r = _git_run(["fetch", "--quiet", "origin", f"+refs/heads/{branch}:refs/remotes/origin/{branch}"],
                 repo)
    if r.returncode:
        raise AccessDenied(f"git fetch origin {branch} failed ({r.stderr.decode(errors='replace').strip()[:200]}); "
                           "C, T and locked reads need a live fetch (no offline fallback)")
    r = _git_run(["ls-remote", "origin", f"refs/heads/{branch}"], repo)
    if r.returncode:
        raise AccessDenied(f"git ls-remote origin {branch} failed; refusing")
    rows = [line.split("\t") for line in r.stdout.decode(errors="replace").splitlines() if line.strip()]
    rows = [x for x in rows if len(x) == 2 and x[1] == f"refs/heads/{branch}"]
    if len(rows) != 1 or not re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", rows[0][0]):
        raise AccessDenied(f"origin has no branch {branch}")
    remote = rows[0][0]
    r = _git_run(["rev-parse", "--verify", "--quiet", f"refs/remotes/origin/{branch}^{{commit}}"], repo)
    local = r.stdout.decode().strip()
    if local != remote:
        raise AccessDenied(f"origin/{branch} is {local[:12] or 'missing'} here but {remote[:12]} on origin "
                           "(moved during the check, or the local ref was changed)")
    return remote


def _pushed_head(branch: str, repo: Path) -> str:
    """The commit of origin's refs/heads/<branch> (audit finding #3): a live fetch that succeeds,
    and the fetched ref equal to `git ls-remote origin`; refused otherwise (no offline fallback).
    A failed attempt is retried after 1, 3 and 9 s (PUSHED_HEAD_DELAYS); refused after the last."""
    err = None
    for n in range(len(PUSHED_HEAD_DELAYS) + 1):
        if n:
            time.sleep(PUSHED_HEAD_DELAYS[n - 1])
        try:
            return _pushed_head_once(branch, repo)
        except AccessDenied as e:
            err = e
    raise AccessDenied(f"{err} (refused after {len(PUSHED_HEAD_DELAYS) + 1} attempts)")


def _in_history(commit: str, repo: Path) -> bool:
    """commit is HEAD or an ancestor of HEAD (git merge-base --is-ancestor)."""
    return _git_run(["merge-base", "--is-ancestor", commit, "HEAD"], repo).returncode == 0


def _cat_verified(repo: Path, kind: str, oid: str, algo: str) -> bytes:
    r = _git_run(["cat-file", kind, oid], repo)
    if r.returncode:
        raise AccessDenied(f"git cat-file {kind} {oid[:12]} failed; refusing")
    data = r.stdout
    got = hashlib.new(algo, f"{kind} {len(data)}\0".encode() + data).hexdigest()
    if got != oid:
        raise AccessDenied(f"git object {oid[:12]} fails its {algo} check (the local object store was "
                           "changed); refusing")
    return data


def _pushed_blob(repo: Path, commit: str, path: str, algo: str) -> bytes | None:
    """The bytes of path at commit, every object (commit, trees, blob) hash-checked; None if the
    path is missing or is not a regular file."""
    first = _cat_verified(repo, "commit", commit, algo).split(b"\n", 1)[0]
    if not first.startswith(b"tree "):
        raise AccessDenied(f"commit {commit[:12]} has no tree line")
    oid, hlen = first[5:].decode().strip(), (20 if algo == "sha1" else 32)
    parts = path.split("/")
    for i, name in enumerate(parts):
        raw, pos, hit = _cat_verified(repo, "tree", oid, algo), 0, None
        while pos < len(raw):
            sp = raw.index(b" ", pos)
            nul = raw.index(b"\0", sp)
            mode, nm, ent = raw[pos:sp], raw[sp + 1:nul], raw[nul + 1:nul + 1 + hlen].hex()
            pos = nul + 1 + hlen
            if nm == name.encode():
                hit = (mode, ent)
                break
        if hit is None:
            return None
        mode, oid = hit
        if i < len(parts) - 1:
            if mode != b"40000":
                return None
        elif mode in (b"100644", b"100755"):
            return _cat_verified(repo, "blob", oid, algo)
        else:
            return None
    return None


# --------------------------------------------------------------------------------------------
# fetch from a data branch
# --------------------------------------------------------------------------------------------
def fetch_dataset(name: str, repo: Path | None = None) -> Path:
    """Pull one registered data set from its git data branch into $FX_DATA_ROOT/<relpath>:
    git fetch origin <branch>; git show origin/<branch>:<path> (joining <path>.part* in name
    order when parts=true); gunzip (or extract the tar member); check sha256.
    Returns the local path. An already-present file is only verified (re-hashed). DATA and STATS only
    (module docstring item 6); load_m1 / load_bars call it on demand."""
    require_internal_caller("fetch_dataset")
    e = registry().get(name)
    if e is None:
        if DERIVED_PATTERN.search(name):
            raise AccessDenied(f"{name}: derived/ outcome files are not for hunters")
        raise KeyError(f"unknown dataset {name}")
    if not e.get("branch"):
        raise AccessDenied(f"{name} has no data branch (locked or local-only set)")
    if not str(e["branch"]).startswith("data/"):
        raise AccessDenied(f"{name}: data sets come only from data/* branches")
    dest = data_root() / e["relpath"]
    if dest.exists():
        verify_file(dest, e["sha256"])
        return dest
    repo = Path(repo) if repo else repo_root()
    b = e["branch"]
    if not _fetch_branch(b, repo) and not _ref_exists(f"refs/remotes/origin/{b}", repo):
        raise RuntimeError(f"cannot fetch origin/{b} (not pushed yet?)")
    bp = e["branch_path"]
    if e["parts"]:
        d = bp.rsplit("/", 1)[0] + "/" if "/" in bp else ""
        listing = _git(["ls-tree", "--name-only", f"origin/{b}", d] if d else
                       ["ls-tree", "--name-only", f"origin/{b}"], repo).splitlines()
        parts = sorted(p for p in listing if re.fullmatch(re.escape(bp) + r"\.part\d+", p))
        if not parts:
            raise RuntimeError(f"no {bp}.part* files on origin/{b}")
    else:
        parts = [bp]
    for p in parts:
        if DERIVED_PATTERN.search(p):
            raise AccessDenied(f"{p}: derived/ outcome files are not for hunters")
    dest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=dest.parent) as td:
        packed = Path(td) / "packed"
        with open(packed, "wb") as f:
            for p in parts:
                r = _git_run(["show", f"origin/{b}:{p}"], repo, capture_output=False, stdout=f,
                             stderr=subprocess.PIPE)
                if r.returncode != 0:
                    raise RuntimeError(f"git show origin/{b}:{p} failed: {r.stderr.decode().strip()}")
        tmp_out = Path(td) / "out"
        h = hashlib.sha256()
        with open(tmp_out, "wb") as out:
            if e["packing"] == "gz":
                src = gzip.open(packed, "rb")
            elif e["packing"] == "tar.gz":
                tf = tarfile.open(packed, "r:gz")
                member = tf.getmember(e["tar_member"])
                if not member.isfile():
                    raise RuntimeError(f"{e['tar_member']} is not a regular file")
                src = tf.extractfile(member)
            elif e["packing"] == "none":
                src = open(packed, "rb")
            else:
                raise ValueError(f"unknown packing {e['packing']}")
            with src:
                while True:
                    chunk = src.read(1 << 20)
                    if not chunk:
                        break
                    h.update(chunk)
                    out.write(chunk)
        if h.hexdigest() != e["sha256"]:
            raise DataIntegrityError(f"{name}: fetched sha256 {h.hexdigest()} != {e['sha256']}")
        os.replace(tmp_out, dest)
    verify_file(dest, e["sha256"])
    return dest


# --------------------------------------------------------------------------------------------
# access rules
# --------------------------------------------------------------------------------------------
def _parse_override(override):
    """-> (kind, ledger_id, decision_ts or None); (None, None, None) without an override."""
    if override is None:
        return None, None, None
    if isinstance(override, dict):
        extra = set(override) - {"kind", "ledger_id", "decision_ts"}
        if extra:
            raise AccessDenied(f"override has unknown keys {sorted(extra)}")
        kind, lid, dts = override.get("kind"), override.get("ledger_id"), override.get("decision_ts")
    else:
        try:
            t = tuple(override)
        except TypeError:
            raise AccessDenied("override must be (kind, ledger_id[, decision_ts]) or a dict") from None
        if len(t) == 2:
            (kind, lid), dts = t, None
        elif len(t) == 3:
            kind, lid, dts = t
        else:
            raise AccessDenied("override must be (kind, ledger_id[, decision_ts]) or a dict")
    if kind not in OVERRIDE_KINDS:
        raise AccessDenied(f"override kind must be one of {tuple(OVERRIDE_KINDS)}")
    if not lid or not isinstance(lid, str):
        raise AccessDenied("override needs a ledger id")
    if not ID_PATTERN.fullmatch(lid):
        raise AccessDenied(f"ledger id {lid!r} is not a plain id (letters, digits, . _ : -)")
    if dts is not None:
        if kind != "forward_inputs":
            raise AccessDenied("decision_ts is only for the 'forward_inputs' override")
        if isinstance(dts, (bool, np.bool_)) or not isinstance(dts, (int, np.integer)):
            raise AccessDenied("decision_ts must be whole unix seconds (int)")
        dts = int(dts)
        if dts < E.FORWARD_START:
            raise AccessDenied(f"forward_inputs: decision_ts {dts} is before the forward start "
                               f"{E.FORWARD_START}")
    return kind, lid, dts


def _eras_of_request(era: str) -> tuple[str, ...]:
    if not isinstance(era, str):
        raise ValueError("era must be a string such as 'BUILD', 'C', 'T' or 'C+T'")
    parts = tuple(era.split("+"))
    for p in parts:
        E.era_bounds(p)
    if len(set(parts)) != len(parts):
        raise ValueError(f"era {era!r} repeats an era")
    order = [E.ERAS.index(p) for p in parts]
    if order != sorted(order) or order != list(range(order[0], order[0] + len(order))):
        raise ValueError(f"era {era!r}: give adjacent eras in time order, e.g. 'C+T'")
    return parts


def _plain(x):
    """An exact str copy of a str argument (red team 14 Oct 2026: a str subclass whose split, __eq__ or __hash__
    lies made one check see 'C' and the next 'C+T'); other values unchanged."""
    return str.__str__(x) if isinstance(x, str) else x


def _check_request(era, override, dept, study, history_for=None) -> tuple:
    """Structure of a read, before any data set is chosen -> (eras, kind, ledger_id, decision_ts)."""
    eras = _eras_of_request(era)
    kind, lid, dts = _parse_override(override)
    if history_for is not None:
        if type(history_for) is not str or history_for not in HISTORY_TARGETS:
            raise AccessDenied(f"history_for {history_for!r}: only {tuple(HISTORY_TARGETS)} (item 3f)")
        if kind is not None:
            raise AccessDenied("a history read takes no override")
        if dept == "STATS":
            raise AccessDenied("history_for is for a department's T look; STATS's locked runner reads its "
                               "own lagged rows")
        if any(e not in HISTORY_TARGETS[history_for] for e in eras):
            raise AccessDenied(f"a history read for {history_for} reads {HISTORY_TARGETS[history_for]} only, "
                               f"not {era}")
    if "PRE" in eras:
        if E.PRE_OPEN is not True:
            raise AccessDenied("era PRE (rows before 2010-01-01) is locked until STATS rules on it "
                               "(research.common.eras.PRE_OPEN)")
        if len(eras) > 1:
            raise AccessDenied("read PRE on its own")
    locked = [e for e in eras if e in E.LOCKED_ERAS]
    open_ = [e for e in eras if e not in E.LOCKED_ERAS]
    if locked:
        if open_:
            raise AccessDenied("a locked era cannot be combined with BUILD, C or T in one read")
        if kind is None:
            raise AccessDenied("rows at or after 1751317200 need STATS's logged override")
        if dept != "STATS":
            raise AccessDenied("locked overrides are for dept STATS only")
        if any(e not in OVERRIDE_KINDS[kind] for e in locked):
            raise AccessDenied(f"override {kind!r} does not open {locked}")
        if not study:
            raise AccessDenied("locked reads need a study id")
    elif kind is not None:
        raise AccessDenied("override is only for locked eras")
    if "BUILD" in eras and len(eras) > 1:
        raise AccessDenied("read BUILD on its own; C and T need their own frozen read")
    if eras != ("BUILD",):
        if not dept or not study:
            raise AccessDenied(f"era {era} needs dept and study")
        if not isinstance(study, str) or not ID_PATTERN.fullmatch(study):
            raise AccessDenied(f"study {study!r} is not a plain id (letters, digits, . _ : -)")
    if dept:
        check_dept(dept)
    return eras, kind, lid, dts


def _to_lines(raw) -> list[dict]:
    out = []
    text = raw.decode(errors="replace") if isinstance(raw, bytes) else (raw or "")
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            r = json.loads(line)
        except ValueError:
            continue
        if isinstance(r, dict):
            out.append(r)
    return out


def _frozen_decl_sha(doc: dict):
    d = doc.get("declaration")
    if isinstance(d, dict) and isinstance(d.get("sha256"), str) and _HEX64.fullmatch(d["sha256"]):
        return d["sha256"]
    v = doc.get("decl_sha256")
    return v if isinstance(v, str) and _HEX64.fullmatch(v) else None


def _has_commit_record(x, path: str, sha: str) -> bool:
    if isinstance(x, dict):
        rec = x.get(path)
        if isinstance(rec, dict) and rec.get("sha256") == sha:
            c = rec.get("commit") or rec.get("last_commit")
            if isinstance(c, str) and _HEXC.fullmatch(c):
                return True
        return any(_has_commit_record(v, path, sha) for v in x.values())
    if isinstance(x, list):
        return any(_has_commit_record(v, path, sha) for v in x)
    return False


def frozen_problems(doc, dept: str | None = None, study: str | None = None) -> list[str]:
    """What a FROZEN.json lacks for a C or T read (docs/EDGE_HUNT.md section 4 item 2); [] when
    it is complete. dept and study (not for STATS's copies) must equal its "dept" and "study"."""
    if not isinstance(doc, dict):
        return ["FROZEN.json must hold one JSON object"]
    out = [f"missing {k!r}" for k in FROZEN_KEYS if doc.get(k) in (None, "", {}, [])]
    if dept and dept != "STATS":
        if doc.get("dept") != dept:
            out.append(f"'dept' is {doc.get('dept')!r}, not {dept!r}")
        if doc.get("study") != study:
            out.append(f"'study' is {doc.get('study')!r}, not {study!r}")
    if "expected_counts" in doc and not isinstance(doc["expected_counts"], dict):
        out.append("'expected_counts' must be an object")
    pins = doc.get("pins")
    if pins is not None and not isinstance(pins, dict):
        out.append("'pins' must map repo path -> sha256")
        pins = {}
    pins = pins or {}
    bad = sorted(str(k) for k, v in pins.items() if not (isinstance(v, str) and _HEX64.fullmatch(v)))
    if bad:
        out.append(f"'pins' values must be sha256 hex: {bad[:3]}")
    if _frozen_decl_sha(doc) is None:
        out.append("no declaration sha256 ('declaration': {'sha256'} or 'decl_sha256')")
    for path in FROZEN_COMMIT_PINS:
        sha = pins.get(path)
        if not isinstance(sha, str):
            out.append(f"'pins' lacks {path}")
        elif not _has_commit_record(doc, path, sha):
            out.append(f"no {{'sha256', 'commit'}} record for {path}")
    return out


def _bind_main(path: str, repo: Path, dept: str, study: str, locked: bool) -> str:
    """The main script's repo path; refused unless it sits in research/departments/<dept>/<study>/
    (STATS, and every locked read: research/departments/STATS/). Audit finding #4."""
    rp = Path(path).resolve()
    try:
        parts = rp.relative_to(repo.resolve()).parts
    except ValueError:
        raise AccessDenied(f"the main script {path} is not inside the repo {repo}: run the look from "
                           f"research/departments/{dept}/{study}/") from None
    if len(parts) < 4 or parts[0] != "research" or parts[1] != "departments":
        raise AccessDenied(f"the main script {'/'.join(parts)} is not under research/departments/{dept}/")
    if any(parts[i] == "research" and parts[i + 1] == "departments" for i in range(2, len(parts) - 1)):
        raise AccessDenied(f"the main script {'/'.join(parts)} sits in a nested research/departments folder")
    if parts[2] != dept:
        raise AccessDenied(f"dept={dept!r}, but the main script is in research/departments/{parts[2]}/: "
                           "a department reads only as itself")
    if dept != "STATS" and not locked and (len(parts) < 5 or parts[3] != study):
        raise AccessDenied(f"study={study!r}, but the main script {'/'.join(parts)} is not in "
                           f"research/departments/{dept}/{study}/")
    return "/".join(parts)


def _unpinned_dept_modules(repo: Path, dept: str, pins: dict) -> list[str]:
    """Modules loaded from research/departments/<dept>/ whose file is not in pins with its sha256."""
    root = repo.resolve()
    base = root / "research" / "departments" / dept
    out = []
    for m in list(sys.modules.values()):
        f = getattr(m, "__file__", None)
        if not isinstance(f, str):
            continue
        try:
            rp = Path(f).resolve()
        except OSError:
            continue
        if base not in rp.parents:
            continue
        rel = rp.relative_to(root).as_posix()
        if not rp.is_file() or pins.get(rel) != sha256_file(rp):
            out.append(rel)
    return sorted(set(out))


def _line_eras(r: dict) -> set:
    """The eras an ACCESS_LOG line read for the one-look check: a history read counts as its T look."""
    if r.get("kind") == "history":
        return {str(r.get("history_for", ""))}
    return set(str(r.get("era", "")).split("+"))


def _check_frozen(dept, study, frozen, eras, repo, code_sha, main_rel, relaxed, history=None) -> tuple[str, str]:
    """-> (frozen_sha256, origin commit) or AccessDenied. history = (target era, days) for a history
    read (item 3f): the target's checks apply, plus its started line's history declaration."""
    read_eras = eras
    if history is not None:
        eras = (history[0],)
    if frozen is None:
        raise AccessDenied(f"era {'+'.join(eras)} needs frozen=<path to a pushed FROZEN.json>")
    fp = Path(frozen).resolve()
    if not fp.is_file():
        raise AccessDenied(f"FROZEN file {frozen} not found")
    try:
        rel = fp.relative_to(repo.resolve()).as_posix()
    except ValueError:
        raise AccessDenied(f"FROZEN file {frozen} is not inside the repo {repo}") from None
    if dept == "STATS":
        ok = rel.startswith("research/departments/STATS/") and rel.endswith(f"/{study}/FROZEN.json")
    else:
        ok = rel == f"research/departments/{dept}/{study}/FROZEN.json"
    if not ok:
        raise AccessDenied(f"frozen={rel}: a {dept} read of study {study} needs "
                           f"research/departments/{dept}/{study}/FROZEN.json (audit finding #20)")
    raw = fp.read_bytes()
    fsha = hashlib.sha256(raw).hexdigest()
    try:
        doc = json.loads(raw)
    except ValueError:
        raise AccessDenied(f"{rel} is not JSON") from None
    if not isinstance(doc, dict):
        raise AccessDenied(f"{rel} must hold one JSON object")
    if history is not None and doc.get(HISTORY_KEY) != history[1]:
        raise AccessDenied(f"{rel}: {HISTORY_KEY} is not {history[1]} (it changed during the read)")
    if dept != "STATS":
        # STATS's reads use byte copies of the picks' FROZEN files and are exempt from the code
        # pin, declaration and one-run checks these keys feed; a key a pick lacks must not refuse
        # STATS's lagged read after its validation or holdout start line is pushed.
        probs = frozen_problems(doc, dept, study)
        if probs:
            raise AccessDenied(f"{rel} is not a complete FROZEN.json (EDGE_HUNT section 4 item 2): "
                               + "; ".join(probs))
    branch = f"dept/{dept.lower()}"
    head = _pushed_head(branch, repo)
    if dept != "STATS" and not relaxed and not _in_history(head, repo):
        # Audit finding #4 (red team): another department's pinned script and FROZEN copied into
        # this checkout would read as that department, with the log line left in the wrong branch.
        raise AccessDenied(f"origin/{branch} ({head[:12]}) is not in this checkout's history (HEAD): "
                           f"a {dept} look runs from a checkout of dept/{dept.lower()} that holds its "
                           "pushed FROZEN and 'started' line (audit finding #4)")
    algo = _object_format(repo)
    pushed_frozen = _pushed_blob(repo, head, rel, algo)
    if pushed_frozen is None:
        raise AccessDenied(f"{rel} is not pushed on origin/{branch}")
    if hashlib.sha256(pushed_frozen).hexdigest() != fsha:
        raise AccessDenied(f"local {rel} differs from the pushed copy on origin/{branch}")
    looks_raw = _pushed_blob(repo, head, f"research/departments/{dept}/LOOKS.jsonl", algo)
    if looks_raw is None:
        raise AccessDenied(f"no pushed research/departments/{dept}/LOOKS.jsonl on origin/{branch}")
    lines = read_looks_text(looks_raw.decode())
    # The local LOOKS.jsonl also counts for closing lines: a look closed locally but not yet
    # pushed is still closed.
    local_p = repo / "research" / "departments" / dept / "LOOKS.jsonl"
    local = read_looks_text(local_p.read_text()) if local_p.exists() else []
    closing = [r for r in lines + local if r.get("frozen_sha256") == fsha and
               r.get("status") in ("done", "aborted")]
    if dept != "STATS" and "T" in eras and "C" not in eras:
        # EDGE_HUNT section 3: T is one look per frozen pick, AFTER C.
        if not any(r.get("era") == "C" and r.get("status") == "done" and
                   r.get("frozen_sha256") == fsha for r in lines):
            raise AccessDenied(f"a T read needs a pushed 'done' C line for frozen_sha256 "
                               f"{fsha[:12]}... first (T comes after C), or one C+T read")
    pins = doc["pins"] if isinstance(doc.get("pins"), dict) else {}
    decl = _frozen_decl_sha(doc)
    for era in eras:
        started = [r for r in lines if r.get("frozen_sha256") == fsha and r.get("era") == era and
                   r.get("status") == "started" and r.get("study") == study]
        if history is not None:
            # item 3f: the T started line names the eras this read takes and the frozen bound
            started = [r for r in started if type(r.get(HISTORY_KEY)) is int and r[HISTORY_KEY] == history[1]
                       and type(r.get("needs_history_eras")) is list
                       and all(type(x) is str for x in r["needs_history_eras"])
                       and set(read_eras) <= set(r["needs_history_eras"])
                       and set(r["needs_history_eras"]) <= set(HISTORY_TARGETS[era])]
            if not started:
                raise AccessDenied(f"no pushed 'started' line for study {study}, era {era}, frozen_sha256 "
                                   f"{fsha[:12]}... names needs_history_eras with {'+'.join(read_eras)} and "
                                   f"{HISTORY_KEY} {history[1]} (item 3f)")
        if not started:
            raise AccessDenied(f"no pushed LOOKS.jsonl 'started' line for study {study}, era {era},"
                               f" frozen_sha256 {fsha[:12]}...")
        if dept != "STATS" and any(r.get("era") == era for r in closing):
            raise AccessDenied(f"era {era} was already looked at for frozen_sha256 {fsha[:12]}..."
                               " (a 'done' or 'aborted' line exists, pushed or local): one look "
                               "per frozen pick; a re-look needs a new, counted FROZEN and "
                               "'started' line")
        if dept != "STATS" and not any(code_sha in (r.get("code_sha256"), r.get("main_sha256"))
                                       and r.get("decl_sha256") == decl for r in started):
            raise AccessDenied(f"the pushed 'started' line for era {era} does not pin this code: its "
                               f"code_sha256 (or main_sha256) must be the main script's sha256 "
                               f"{code_sha[:12]}... and its decl_sha256 the FROZEN declaration's "
                               "(audit finding #6)")
    if dept != "STATS":
        if main_rel is not None:
            if pins.get(main_rel) != code_sha:
                raise AccessDenied(f"FROZEN pins does not hold {main_rel} with its sha256 "
                                   f"{code_sha[:12]}... (audit finding #6)")
            loose = _unpinned_dept_modules(repo, dept, pins)
            if loose:
                raise AccessDenied(f"code loaded from research/departments/{dept}/ is not pinned in "
                                   f"FROZEN pins (or changed): {loose[:5]}")
        elif code_sha not in pins.values():
            raise AccessDenied(f"FROZEN pins does not hold the main script's sha256 {code_sha[:12]}...")
        rid = run_id()
        acc_raw = _pushed_blob(repo, head, f"research/departments/{dept}/ACCESS_LOG.jsonl", algo)
        acc_local = repo / "research" / "departments" / dept / "ACCESS_LOG.jsonl"
        acc = _to_lines(acc_raw) + (_to_lines(acc_local.read_bytes()) if acc_local.exists() else [])
        for r in acc:
            if (r.get("frozen_sha256") == fsha and _line_eras(r) & set(eras)
                    and r.get("run_id") != rid):
                raise AccessDenied(f"ACCESS_LOG already holds a {r.get('era')} read of frozen_sha256 "
                                   f"{fsha[:12]}... by another run ({r.get('run_id')}): one look is one "
                                   "process; a re-look needs a new, counted FROZEN and 'started' line")
    return fsha, head


def check_frozen_pushed(dept: str, study: str, frozen, eras: tuple[str, ...],
                        repo: Path | None = None) -> str:
    """Return the frozen sha256 if a C or T read of every era in eras by this process's main
    script is allowed (module docstring, item 3); raise AccessDenied otherwise."""
    repo = Path(repo) if repo else repo_root()
    info = main_info()
    if info is None:
        raise AccessDenied("C or T reads must run from a script file")
    main_rel = None if info["pytest"] else _bind_main(info["path"], repo, dept, study, False)
    return _check_frozen(dept, study, frozen, tuple(eras), repo, code_sha256_of_main(), main_rel,
                         info["pytest"])[0]


def _check_ledger(kind: str, lid: str, repo: Path) -> str:
    """The ledger id must be the id of a pushed start line on origin/dept/stats of a run that opens
    this kind (LEDGERS: 'validation' a validation run or a holdout run, 'holdout' a holdout run,
    'forward_inputs' a forward run), and no ledger where it started may hold a closing line for it
    (pushed or local). Audit finding #5. -> the origin commit read."""
    head = _pushed_head("dept/stats", repo)
    algo = _object_format(repo)
    opened, missing = None, []
    for rel, key, start, id_key, closing in LEDGERS[kind]:
        lines = _to_lines(_pushed_blob(repo, head, rel, algo))
        if not any(r.get(key) == start and r.get(id_key) == lid for r in lines):
            missing.append(f"no pushed {start!r} line with {id_key} {lid!r} in {rel}")
            continue
        local_p = repo / rel
        local = _to_lines(local_p.read_bytes()) if local_p.exists() else []
        if any(r.get(key) == value and r.get(ck) == lid for r in lines + local for value, ck in closing):
            raise AccessDenied(f"override {kind!r}: run {lid!r} is already closed in {rel}")
        opened = rel
    if opened is None:
        raise AccessDenied(f"override {kind!r}: " + "; ".join(missing) + " on origin/dept/stats; "
                           "STATS pushes its ledger line before the read")
    return head


def open_run_kind(ledger_id, repo=None):
    """'holdout', 'validation' or 'forward_inputs': the kind of the open run whose id ledger_id is (a pushed,
    unclosed STATS start line on origin, which must be the GitHub repo (_origin_ok): the same rule as a locked
    read's override, _check_ledger); None otherwise. A
    holdout run is reported as 'holdout' (its id also opens 'validation'). DATA's downloader asks this before any
    window past the cutoff (integration check R1, 14 Oct 2026: an id anywhere in a ledger line was enough before)."""
    if not isinstance(ledger_id, str) or not ID_PATTERN.fullmatch(ledger_id):
        return None
    repo = Path(repo) if repo is not None else repo_root()
    if not _origin_ok(repo):
        # a mirror, or an insteadOf rewrite of origin, may hold any start line (STATS locked-runner red team 2,
        # 14 Oct 2026); only the GitHub repo's pushed ledgers open a run
        return None
    for kind in ("holdout", "validation", "forward_inputs"):
        try:
            _check_ledger(kind, ledger_id, repo)
            return kind
        except AccessDenied:
            continue
    return None


def locked_window(kind, now=None):
    """[lo, hi) in ts_utc that an open run of this kind (open_run_kind) may read past the cutoff, as the loaders'
    overrides allow it: a validation run the VALIDATION era; a holdout run VALIDATION and HOLDOUT (its id opens
    both kinds); a forward run from FORWARD_START - 400 days to now (FORWARD_LAG_SECONDS). None for anything else.
    DATA's downloader refuses a window outside it (red team 14 Oct 2026: a validation id opened holdout and
    forward windows)."""
    if kind == "validation":
        return E.VALIDATION_START, E.HOLDOUT_START
    if kind == "holdout":
        return E.VALIDATION_START, E.FORWARD_START
    if kind == "forward_inputs":
        t = int(now if now is not None else time.time())
        return E.FORWARD_START - FORWARD_LAG_SECONDS, t + 1
    return None


def _gate(eras, sets, frozen, kind, lid, dept, study, history=None) -> tuple:
    """Every check of a C, T or locked read -> (frozen_sha256 or None, code_sha256, log fields)."""
    locked = eras[0] in E.LOCKED_ERAS
    repo = repo_root()
    info = main_info()
    if info is None:
        raise AccessDenied("C, T or locked reads must run from a script file (python3 <file> or "
                           "python3 -m <module>; not -c, stdin or an interactive session)")
    real = _real_data(sets)
    if real:
        if repo.resolve() != package_root():
            raise AccessDenied(f"repo root {repo} is not the checkout that holds research/common "
                               f"({package_root()}): FX_REPO_ROOT may point elsewhere only for "
                               "synthetic test data (audit finding #2)")
        if not _origin_ok(repo):
            raise AccessDenied("origin is not github.com/macdarenz-droid/Forex-signal: real data "
                               "needs the real repo's pushed LOOKS and FROZEN (audit finding #2)")
        if info["pytest"]:
            raise AccessDenied("a test (pytest) may read C, T or locked rows of synthetic data only")
    relaxed = (not real) and info["pytest"]
    main_rel = None if relaxed else _bind_main(info["path"], repo, dept, study, locked)
    code_sha = code_sha256_of_main()
    fields = {"run_id": run_id(), "fetch_ok": True, "synthetic": not real,
              "main_path": main_rel or info["path"]}
    if locked:
        fields["origin_commit"] = _check_ledger(kind, lid, repo)
        return None, code_sha, fields
    fsha, head = _check_frozen(dept, study, frozen, eras, repo, code_sha, main_rel, relaxed, history)
    fields["origin_commit"] = head
    return fsha, code_sha, fields


def _to_ts(x) -> int | None:
    """unix seconds, or a date string / Timestamp (naive means UTC)."""
    if x is None:
        return None
    if isinstance(x, (bool, np.bool_)):
        raise ValueError("start/end must be unix seconds or a date, not a bool")
    if isinstance(x, (int, np.integer)):
        return int(x)
    if isinstance(x, (float, np.floating)):
        # pd.Timestamp(float) reads nanoseconds, so a float is taken as unix seconds here and
        # must hold a whole number.
        if not np.isfinite(x) or float(x) != int(x):
            raise ValueError(f"start/end {x!r}: a float must be whole unix seconds")
        return int(x)
    t = pd.Timestamp(x)
    if t.tzinfo is None:
        t = t.tz_localize("UTC")
    return int(t.timestamp())


def _history_days(history_for, frozen, dept, study) -> int | None:
    """The FROZEN.json's history_lookback_days for a history read (item 3f), or None without one. Read only
    from research/departments/<dept>/<study>/FROZEN.json in the repo (red team 14 Oct 2026: any path was read
    before the path check); _check_frozen then checks that the pushed FROZEN is byte-equal and holds it."""
    if history_for is None:
        return None
    if frozen is None:
        raise AccessDenied("a history read needs frozen=<path to a pushed FROZEN.json>")
    fp, repo = Path(frozen).resolve(), repo_root().resolve()
    try:
        rel = fp.relative_to(repo).as_posix()
    except ValueError:
        raise AccessDenied(f"FROZEN file {frozen} is not inside the repo {repo}") from None
    if rel != f"research/departments/{dept}/{study}/FROZEN.json" or not fp.is_file():
        raise AccessDenied(f"frozen={rel}: a {dept} history read of study {study} needs "
                           f"research/departments/{dept}/{study}/FROZEN.json")
    try:
        doc = json.loads(fp.read_bytes())
    except (OSError, ValueError):
        raise AccessDenied(f"FROZEN file {frozen} cannot be read as JSON") from None
    days = doc.get(HISTORY_KEY) if isinstance(doc, dict) else None
    if type(days) is not int or not 1 <= days <= HISTORY_MAX_DAYS:
        raise AccessDenied(f"{frozen}: a history read needs \"{HISTORY_KEY}\", a whole number of days from 1 "
                           f"to {HISTORY_MAX_DAYS}, frozen in FROZEN.json (item 3f)")
    return days


def _read_range(era, start, end, override=None, history=None) -> tuple[int, int]:
    """Inclusive (lo, hi) of a read: the era bounds narrowed by start (incl.) and end (excl.), for
    'forward_inputs' by the 400-day lag window, and for a history read (history = (target era,
    days)) by [target start - days, target start) (module docstring, items 3 and 3f)."""
    eras = _eras_of_request(era)
    lo, hi = E.era_bounds(eras[0])[0], E.era_bounds(eras[-1])[1]
    s, e_ = _to_ts(start), _to_ts(end)
    if s is not None:
        lo = max(lo, s)
    if e_ is not None:
        hi = min(hi, e_ - 1)
    kind, _, dts = _parse_override(override)
    if kind == "forward_inputs":
        if dts is None:
            lo = max(lo, E.FORWARD_START - FORWARD_LAG_SECONDS)
        else:
            lo, hi = max(lo, dts - FORWARD_LAG_SECONDS), min(hi, dts - 1)
    if history is not None:
        t0 = E.era_bounds(history[0])[0]
        lo, hi = max(lo, t0 - int(history[1]) * 86400), min(hi, t0 - 1)
    return lo, hi


# --------------------------------------------------------------------------------------------
# changed at runtime (audit finding #8)
# --------------------------------------------------------------------------------------------
_UNCHECKED = frozenset({"load_m1", "load_bars", "catalog"})   # entry points: replacing one opens nothing


_BUILTIN_HOMES = frozenset({"_hashlib", "_sha2", "_io", "posix", "nt", "time", "builtins", "zlib"})


def _owned(owner, v) -> bool:
    """v is a library function of owner's own package (red team 14 Oct 2026: a replacement made before
    research.common was imported became the guard's reference): a Python function defined in the package's
    files, a C builtin of the expected module, or a class of owner's module."""
    if isinstance(v, types.FunctionType):
        mod = owner if isinstance(owner, types.ModuleType) else sys.modules.get(getattr(owner, "__module__", ""))
        top = sys.modules.get(mod.__name__.split(".")[0]) if mod is not None else None
        f0 = getattr(top, "__file__", None)
        if not f0:
            return False
        base = Path(f0).resolve()
        root = base.parent if base.name == "__init__.py" else base
        f = Path(v.__code__.co_filename).resolve()
        return f == root or root in f.parents
    if isinstance(v, types.BuiltinFunctionType):
        return getattr(v, "__module__", None) in _BUILTIN_HOMES
    if isinstance(v, type):
        return v.__module__ == getattr(owner, "__name__", None)
    return False


def _make_guard():
    snap: dict = {}
    ext: tuple = ()                         # (owner, attribute, object, state), set once at arm
    bsnap: dict = {}                        # builtins' public names at arm: each must stay the same object

    def _cells(f):
        out = []
        for c in f.__closure__ or ():
            try:
                out.append(c.cell_contents)
            except ValueError:
                out.append(snap)                   # an empty cell: compared as "empty" below
        return tuple(out)

    def _state(v):
        if isinstance(v, types.FunctionType):
            kw = v.__kwdefaults__
            return ("fn", v.__code__, v.__defaults__, None if kw is None else dict(kw), _cells(v))
        if isinstance(v, MappingProxyType):
            return ("box", dict(v))
        if isinstance(v, (dict, list, set)):
            return ("box", copy.deepcopy(v))
        if isinstance(v, np.ndarray):
            return ("arr", v.copy())
        return ("obj",)

    def _same(v, ref, st) -> bool:
        if v is not ref:
            return False
        kind = st[0]
        if kind == "fn":
            if v.__code__ is not st[1] or v.__defaults__ is not st[2]:
                return False
            kw = v.__kwdefaults__
            if (kw is None) != (st[3] is None) or (kw is not None and (kw.keys() != st[3].keys() or any(
                    kw[k] is not st[3][k] for k in kw))):
                return False
            cells = _cells(v)
            return len(cells) == len(st[4]) and all(a is b for a, b in zip(cells, st[4]))
        if kind == "box":
            return (dict(v) if isinstance(v, MappingProxyType) else v) == st[1]
        if kind == "arr":
            return v.shape == st[1].shape and bool(np.array_equal(v, st[1]))
        return True

    def _names(d, skip) -> set:
        return {k for k in d if not (k.startswith("__") and k.endswith("__")) and k not in skip}

    def _space(name, d, src, skip, files) -> None:
        for k in _names(d, skip):
            v = d[k]
            if isinstance(v, types.FunctionType) and str(v.__module__).startswith("research.common"):
                own = files.get(v.__module__) or getattr(sys.modules.get(v.__module__), "__file__", None)
                if not own or Path(v.__code__.co_filename).resolve() != Path(own).resolve():
                    raise ImportError(f"{name}.{k} was changed before research.common.loaders "
                                      "was imported")
        snap[name] = (d, skip, {k: (d[k], _state(d[k])) for k in _names(d, skip)})

    def add(space) -> None:
        """One more namespace (research.common.macro, which imports the loaders) after arm; never one twice."""
        name, d, src, skip = space
        if not snap or name in snap:
            raise RuntimeError(f"guard: {name} cannot be added")
        _space(name, d, src, skip, {name: src})

    def arm(spaces, externals=()) -> None:
        """spaces: (name, module namespace dict, source file, names not checked); externals: (owner, attribute)
        of library functions the checks use: each must be its library's own at arm, and still the same (object,
        code, defaults and closure) at every read; builtins' public names must stay the same objects."""
        nonlocal ext
        if snap:
            raise RuntimeError("guard already armed")
        for o, a in externals:
            if not _owned(o, getattr(o, a)):
                raise ImportError(f"{getattr(o, '__name__', o)}.{a} was changed before research.common.loaders "
                                  "was imported")
        ext = tuple((o, a, getattr(o, a), _state(getattr(o, a))) for o, a in externals)
        bsnap.update({k: v for k, v in vars(builtins).items() if not k.startswith("_")})
        files = {name: src for name, _, src, _ in spaces}
        for name, d, src, skip in spaces:
            _space(name, d, src, skip, files)

    def check() -> None:
        if not snap:
            raise AccessDenied("research.common.loaders is not initialised")
        for name, (d, skip, items) in snap.items():
            names = _names(d, skip)
            if names != items.keys():
                diff = sorted(names ^ items.keys())
                raise AccessDenied(f"{name} gained or lost attributes at runtime {diff[:5]}: reads "
                                   "refused (audit finding #8)")
            for k, (ref, st) in items.items():
                if not _same(d[k], ref, st):
                    raise AccessDenied(f"{name}.{k} was changed at runtime: reads refused "
                                       "(audit finding #8)")
        for o, a, ref, st in ext:
            if not _same(getattr(o, a, None), ref, st):
                raise AccessDenied(f"{getattr(o, '__name__', o)}.{a} was replaced at runtime: reads refused (the "
                                   "loaders' checks use it; red team of the history read, 14 Oct 2026)")
        b = vars(builtins)
        for k, v in bsnap.items():
            if b.get(k) is not v:
                raise AccessDenied(f"builtins.{k} was replaced at runtime: reads refused")
    return arm, check, add


_arm_guard, _check_guard, _guard_add = _make_guard()


# --------------------------------------------------------------------------------------------
# the process's C, T or locked run, for research.common.macro (STATS macro-series rule, AUDITS.md
# dept/stats a0f8738f; coordinator, 14 Oct 2026). Release 5 (EDGE_HUNT, coordinator 14 Oct about 4:47 pm
# Melbourne): (a) an unpinned macro read is refused while a look of this code is open, also in a process
# that made no gated read of its own; (b) the pin must be the sha256 the look's FROZEN.json gives the file.
# --------------------------------------------------------------------------------------------
MACRO_PIN_PREFIX = "data/macro:"


def frozen_macro_pins(doc) -> dict:
    """{file name: set of sha256} a FROZEN.json gives the data/macro files, from "data_macro_sha256"
    ({"data/macro:<file>": sha256}, MACRO-01's form) and from "pins" keys "data/macro:<file>". A file the
    FROZEN does not name is not readable by its look (release 5 item b)."""
    out: dict = {}
    if not isinstance(doc, dict):
        return out
    for key in ("data_macro_sha256", "pins"):
        m = doc.get(key)
        if not isinstance(m, dict):
            continue
        for k, v in m.items():
            if isinstance(k, str) and k.startswith(MACRO_PIN_PREFIX) and isinstance(v, str) and _HEX64.fullmatch(v):
                out.setdefault(k[len(MACRO_PIN_PREFIX):], set()).add(v)
    return out


def _run_macro_pins(frozen, fsha) -> dict:
    """The macro pins of the FROZEN.json a gated read just checked (_check_frozen): its bytes are read again and
    must still have the checked sha256."""
    raw = Path(frozen).read_bytes()
    if hashlib.sha256(raw).hexdigest() != fsha:
        raise AccessDenied(f"{frozen} changed during the read (its sha256 is no longer {fsha[:12]}...)")
    return frozen_macro_pins(json.loads(raw))


LINK_ERAS = frozenset({"C", "T", "VALIDATION", "HOLDOUT", "FORWARD"})
LOCKED_RUN_ENV = "FX_LOCKED_RUN"   # set by STATS's runner in a locked run's worker: that run's ledger id (release 6)
LINK_TTL_S = 60          # the pushed looks are read at most once a minute per process (FX_MACRO_LINK_TTL may lower it)


def _check_macro_pin(look, series, sha256, pinned) -> None:
    """(a) and (b) for one look: refused unless the read was pinned and, when the look has a FROZEN.json, the
    pin is the sha256 that FROZEN gives this file."""
    name = look.get("name") or f"{look['dept']} {look['study']} {look['era']} look"
    if not pinned:
        raise AccessDenied(f"macro {series}: an unpinned macro read is refused while {look.get('while') or f'the {name} is open'} "
                           "(load(name, sha256=<the pin its FROZEN.json records>); release 5 item a)")
    if look.get("frozen_problem"):
        raise AccessDenied(f"macro {series}: the {name}'s pin cannot be checked: {look['frozen_problem']} "
                           "(release 5 item b)")
    pins = look.get("macro_pins")
    if pins is None:
        return                                    # a locked or STATS run: the loaders hold no FROZEN.json for it
    got = pins.get(series, set())
    if got != {sha256}:
        why = (f"gives it {sorted(x[:12] for x in got)}" if got else "does not name it (data_macro_sha256 or "
               f"pins key '{MACRO_PIN_PREFIX}{series}')")
        raise AccessDenied(f"macro {series}: the pin {sha256[:12]}... is not the {name}'s FROZEN.json pin; "
                           f"the FROZEN {why} (release 5 item b)")


def _make_runs():
    """A closure, so the runtime guard (which compares module attributes) does not see the state change. Under
    a pytest main (synthetic data only) the state is kept per test (PYTEST_CURRENT_TEST): one test's run must
    not bound another test's macro reads; a script main ignores that variable."""
    st: dict = {}

    def _key():
        info = main_info()
        return os.environ.get("PYTEST_CURRENT_TEST", "").rsplit(" ", 1)[0] if info and info["pytest"] else None

    def _here() -> dict:
        k = _key()
        if st.get("key", object()) != k:
            st.clear()
            st.update(key=k, runs=[], loads=[])
        return st

    def admit(dept, study, era, fsha, bound, code_sha, macro_pins=None) -> None:
        """Record a gated read's run. Every macro file this process loaded so far (before any run or under an
        earlier run) must fit this run too: no row after its bound, loaded with a pin, the pin this run's FROZEN
        gives (macro_pins None: a locked run, no FROZEN check); otherwise the read is refused. Loads made outside
        any run are logged now (kind "macro", before_run true)."""
        here = _here()
        run = {"dept": dept, "study": study, "era": era, "frozen_sha256": fsha, "bound": int(bound),
               "code_sha256": code_sha, "macro_pins": macro_pins}
        for m in here["loads"]:
            if m["latest"] is not None and m["latest"] > bound:
                raise AccessDenied(f"macro.load served {m['series']} with rows up to ts {int(m['latest'])} in this "
                                   f"process before this {era} run's first read, past its bound {bound}: load macro "
                                   "files after the run's first C, T or locked read (STATS macro-series rule)")
            if not m["pinned"]:
                raise AccessDenied(f"macro.load served {m['series']} unpinned in this process before this {era} "
                                   "run's first read; a run's process loads macro files with sha256= only (release 5 "
                                   "item a): this read is refused")
            _check_macro_pin(dict(run, name=f"{dept} {study} {era} run"), m["series"], m["sha256"], True)
        here["runs"].append(run)
        for m in here["loads"]:
            if not m["logged"]:
                _log_macro(run, m["series"], m["sha256"], m["rows"], 0, before_run=True)
                m["logged"] = True

    def runs() -> list[dict]:
        return [dict(r) for r in _here()["runs"]]

    def note_macro(series, sha256, latest, rows, pinned, logged=False) -> None:
        _here()["loads"].append({"series": series, "sha256": sha256, "latest": latest, "rows": rows,
                                 "pinned": bool(pinned), "logged": bool(logged)})

    return admit, runs, note_macro


def _log_macro(run, series, sha256, rows, dropped, before_run=False, linked=False) -> None:
    extra = {"linked": True} if linked else {}
    log_access(run["dept"], run["study"], run["era"], None, None, run["code_sha256"], run["frozen_sha256"],
               kind="macro", series=series, sha256=sha256, asof_bound=run["bound"], rows=int(rows),
               rows_dropped=int(dropped), before_run=before_run, common_sha256=common_sha256(), **extra)


_admit_run, current_runs, _note_macro_load = _make_runs()


def _pushed_dept_heads(repo: Path) -> dict:
    """{DEPT: commit} of every dept/<name> branch on origin, read live with `git ls-remote`; each local
    refs/remotes/origin/dept/<name> must equal it, after one fetch of refs/heads/dept/* when any differs. One
    attempt (the caller keeps its last good result); AccessDenied when origin cannot be read. A department with no
    branch on origin has no looks."""
    r = _git_run(["ls-remote", "origin", "refs/heads/dept/*"], repo)
    if r.returncode:
        raise AccessDenied("git ls-remote origin dept/* failed")
    remote = {}
    for line in r.stdout.decode(errors="replace").splitlines():
        x = line.split("\t")
        if len(x) != 2 or not re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", x[0]):
            continue
        name = x[1][len("refs/heads/dept/"):] if x[1].startswith("refs/heads/dept/") else ""
        if name.upper() in K.DEPTS and name == name.lower():
            remote[name] = x[0]

    def _local(name):
        return _git_run(["rev-parse", "--verify", "--quiet", f"refs/remotes/origin/dept/{name}^{{commit}}"],
                        repo).stdout.decode().strip()
    if any(_local(b) != c for b, c in remote.items()):
        f = _git_run(["fetch", "--quiet", "origin", "+refs/heads/dept/*:refs/remotes/origin/dept/*"], repo)
        if f.returncode:
            raise AccessDenied(f"git fetch origin dept/* failed ({f.stderr.decode(errors='replace').strip()[:200]})")
        stale = [b for b, c in remote.items() if _local(b) != c]
        if stale:
            raise AccessDenied(f"origin/dept/{stale[0]} moved during the check")
    return {b.upper(): c for b, c in remote.items()}


def _link_code() -> str | None:
    """sha256 of the code this process runs, for linking it to a look: the main script, or in a multiprocessing
    child started by spawn or forkserver (whose command line is `-c ...`) the parent's main (__mp_main__)."""
    if main_info() is not None:
        try:
            return code_sha256_of_main()
        except PermissionError as e:
            raise AccessDenied(f"macro read: {e}") from None
    mp = sys.modules.get("__mp_main__")
    f = getattr(mp, "__file__", None) if mp is not None else None
    return sha256_file(f) if isinstance(f, str) and os.path.isfile(f) else None


def _open_looks(repo: Path, heads: dict) -> list[dict]:
    """Every open look on origin: a pushed 'started' line (era C, T, VALIDATION, HOLDOUT or FORWARD, or a '+' join
    of eras) with no pushed 'done' or 'aborted' line for its frozen_sha256 and era. A line that is not a JSON object
    with string fields is skipped (one bad line must not stop every department's reads). For a non-STATS line the
    look's pushed FROZEN.json (research/departments/<dept>/<study>/FROZEN.json, sha256 equal to the line's
    frozen_sha256) gives its macro pins and the code pinned in the look's own folder."""
    algo = _object_format(repo) if heads else "sha1"
    out = []
    for dept, head in sorted(heads.items()):
        raw = _pushed_blob(repo, head, f"research/departments/{dept}/LOOKS.jsonl", algo)
        if raw is None:
            continue
        lines = []
        for t in raw.decode("utf-8", errors="replace").splitlines():
            try:
                r = json.loads(t)
            except ValueError:
                continue
            if isinstance(r, dict) and all(isinstance(r.get(k), str) for k in ("status", "era")) and \
                    (r.get("frozen_sha256") is None or isinstance(r.get("frozen_sha256"), str)):
                lines.append(r)
        ends = [r for r in lines if r["status"] in ("done", "aborted")]
        by_id = {(r.get("id"), r["era"]) for r in ends if isinstance(r.get("id"), str)}
        by_pick = {(r.get("frozen_sha256"), r["era"]) for r in ends if not isinstance(r.get("id"), str)}
        any_pick = {(r.get("frozen_sha256"), r["era"]) for r in ends}
        for r in lines:
            era, fsha, study = r["era"], r.get("frozen_sha256"), r.get("study")
            parts = era.split("+")
            # a line with an id is closed by a closing line with its id (STATS reruns one pick: red team 2), or by
            # one with no id for its pick; a line with no id by any closing line for its pick
            rid = r.get("id") if isinstance(r.get("id"), str) else None
            shut = ((rid, era) in by_id or (fsha, era) in by_pick) if rid else (fsha, era) in any_pick
            if r["status"] != "started" or shut or not all(x in E.ERAS for x in parts) \
                    or not LINK_ERAS & set(parts):
                continue
            codes = {v for v in (r.get("code_sha256"), r.get("main_sha256")) if isinstance(v, str)}
            look = {"dept": dept, "study": study if isinstance(study, str) else "?", "era": era,
                    "frozen_sha256": fsha, "bound": max(int(E.era_bounds(x)[1]) for x in parts),
                    "codes": codes, "own_pins": set(), "macro_pins": None, "frozen_problem": None}
            if dept != "STATS":
                rel = f"research/departments/{dept}/{study}/FROZEN.json"
                fr = (_pushed_blob(repo, head, rel, algo) if isinstance(study, str)
                      and re.fullmatch(r"[A-Z]+-[0-9A-Za-z_-]+", study) else None)
                doc = None
                if fr is None:
                    look["frozen_problem"] = f"its pushed FROZEN.json ({rel}) is missing"
                elif fsha is None or hashlib.sha256(fr).hexdigest() != fsha:
                    look["frozen_problem"] = f"its pushed {rel} is not the started line's frozen_sha256"
                else:
                    try:
                        doc = json.loads(fr)
                    except ValueError:
                        doc = None
                    if not isinstance(doc, dict):
                        look["frozen_problem"], doc = f"its pushed {rel} is not one JSON object", None
                if doc is not None:
                    pins = doc.get("pins") if isinstance(doc.get("pins"), dict) else {}
                    own = f"research/departments/{dept}/{study}/"
                    look["own_pins"] = {v for k, v in pins.items() if isinstance(k, str) and k.startswith(own)
                                        and isinstance(v, str)}
                    look["macro_pins"] = frozen_macro_pins(doc)
            out.append(look)
    return out


def _make_linked():
    """linked() -> the constraints of open looks on this process when it has no run of its own (release 5 item a):
      - the looks whose code this process runs (the started line's code_sha256 or main_sha256, or a pin of the
        look's FROZEN.json inside research/departments/<dept>/<study>/): pin required, the FROZEN pin, rows up to
        the look's era end, logged (linked=true);
      - no main script file (-c, stdin, an interactive session) while any look is open: pin required, and the
        read is refused when rows past the earliest open look's era end would be dropped (no silent drops);
      - origin unreadable and no earlier reading in this process: the read is refused; a failed re-read keeps the
        last reading and adds "pin required".
    The pushed looks are re-read at most every LINK_TTL_S seconds. The code's sha256 is taken once, when a look is
    first open (a main changed on disk before that counts as no main script)."""
    memo: dict = {}

    def linked() -> list[dict]:
        repo = repo_root()
        try:
            ttl = min(LINK_TTL_S, max(0, int(os.environ.get("FX_MACRO_LINK_TTL", LINK_TTL_S))))
        except ValueError:
            ttl = LINK_TTL_S
        now = time.monotonic()
        key = str(repo.resolve())
        got = memo.get(key)
        if got is None or now - got[0] >= ttl:
            try:
                got = (now, _open_looks(repo, _pushed_dept_heads(repo)), None)
            except AccessDenied as e:
                got = (now, got[1] if got is not None else None, str(e))
            memo[key] = got
        looks, failed = got[1], got[2]
        if looks is None:
            # never read in this process and unreadable now: refused (red team 2: a pin alone served a look's
            # process every row past its era end)
            raise AccessDenied(f"macro read refused: origin's dept/* looks could not be read ({failed}) and were "
                               "never read in this process, so the open looks of this code are unknown (release 5)")
        extra = ([{"while": f"the pushed looks could not be re-read ({failed}; the last reading is kept)",
                   "dept": "-", "study": "-", "era": "-", "frozen_sha256": None, "bound": None, "macro_pins": None,
                   "log": False}] if failed else [])
        if not looks:
            return extra
        if "code" not in memo:
            try:
                memo["code"] = _link_code()
            except AccessDenied:
                memo["code"] = None              # the running main changed on disk: treated as no main (red team 2)
        code = memo["code"]
        if code is None:
            if not looks:
                return []
            first = min(looks, key=lambda x: x["bound"])
            return extra + [{"while": f"{len(looks)} look(s) are open (the earliest era end: {first['dept']} "
                                      f"{first['study']} {first['era']}) and this process has no main script file to "
                                      "tell which is its own", "dept": "-", "study": "-", "era": "-",
                             "frozen_sha256": None, "bound": first["bound"], "macro_pins": None, "log": False,
                             "refuse_drop": True}]
        out = []
        for lk in looks:
            if code in lk["codes"] or code in lk["own_pins"]:
                out.append({k: lk[k] for k in ("dept", "study", "era", "frozen_sha256", "bound", "macro_pins",
                                               "frozen_problem")} | {"code_sha256": code, "log": True})
        return out + extra                       # the looks first: a refusal names the look

    return linked


_linked_looks = _make_linked()


def _given_frozen(frozen) -> tuple[str, dict]:
    """(sha256, macro pins) of the FROZEN.json a macro read names (macro.load(frozen=...)): STATS's locked runner
    passes the frozen pick's copy, so a locked run checks the pin against it too (coordinator, 14 Oct 2026)."""
    if not isinstance(frozen, (str, os.PathLike)):
        raise TypeError("frozen is the path of a FROZEN.json")
    try:
        raw = Path(os.fspath(frozen)).read_bytes()
        doc = json.loads(raw)
    except (OSError, ValueError) as e:
        raise AccessDenied(f"frozen={os.fspath(frozen)!r} is not a readable FROZEN.json ({e})") from None
    if not isinstance(doc, dict):
        raise AccessDenied(f"frozen={os.fspath(frozen)!r} must hold one JSON object")
    return hashlib.sha256(raw).hexdigest(), frozen_macro_pins(doc)


def macro_read(series: str, sha256: str, latest: np.ndarray, pinned: bool = False, frozen=None) -> np.ndarray:
    """For research.common.macro.load: inside this process's C, T or locked run, a boolean mask of the rows to
    serve (each row's latest time at or before the run's bound, the strictest when there are several) and an
    ACCESS_LOG line (kind "macro", the series, its sha256, the bound, rows served and dropped, this run_id). A
    process with no run of its own is bound by the open looks of its code (_linked_looks: the same, and its lines
    say linked=true), or with no main script file by every open look. The read must be pinned, by the run's or
    look's FROZEN pin (release 5). frozen= (a FROZEN.json path) gives a run with no FROZEN of its own here (a locked
    run) the pins to check; it must be the FROZEN of any C or T run or look in force (same sha256), and outside any
    run a pinned read must carry its pin. Every load is noted, so a later run's first read checks it."""
    _check_guard()                                  # research.common.macro is in the guard too (red team)
    latest = np.asarray(latest, dtype=float)
    given = _given_frozen(frozen) if frozen is not None else None
    lid = os.environ.get(LOCKED_RUN_ENV)
    if lid:
        # release 6 (coordinator, 14 Oct 2026): STATS's runner names its open locked run in its worker's
        # environment; the worker reads macro files pinned and with the pick's FROZEN only
        kind = open_run_kind(lid, repo_root())
        if kind is None:
            raise AccessDenied(f"macro {series}: {LOCKED_RUN_ENV}={lid!r} is not an open STATS run on origin "
                               "(loaders.open_run_kind); a locked run's worker reads only while its run is open")
        if not pinned or given is None:
            raise AccessDenied(f"macro {series}: this process is a worker of STATS's open {kind} run {lid} "
                               f"({LOCKED_RUN_ENV}); it reads macro files with sha256= and frozen= only (release 6)")
    rs = [dict(r, log=True, name=f"{r['dept']} {r['study']} {r['era']} run") for r in current_runs()]
    in_run, linked = bool(rs), False
    if not rs:
        rs = _linked_looks()
        linked = bool(rs)
    if given is not None:
        for r in rs:
            if r["frozen_sha256"] is not None and r["frozen_sha256"] != given[0]:
                raise AccessDenied(f"macro {series}: frozen={os.fspath(frozen)!r} (sha256 {given[0][:12]}...) is not "
                                   f"the FROZEN.json of the {r['dept']} {r['study']} {r['era']} run in force")
        rs = [dict(r, macro_pins=given[1]) if r["macro_pins"] is None else r for r in rs]
        if not rs:
            rs = [{"name": f"named FROZEN.json {os.fspath(frozen)}", "while": f"frozen= names {os.fspath(frozen)}",
                   "dept": "-", "study": "-", "era": "-", "frozen_sha256": None, "bound": None,
                   "macro_pins": given[1], "log": False}]
    for r in rs:
        _check_macro_pin(r, series, sha256, pinned)
    bounds = [r["bound"] for r in rs if r["bound"] is not None]
    keep = ~(latest > min(bounds)) if bounds else np.ones(len(latest), dtype=bool)
    if not keep.all() and any(r.get("refuse_drop") for r in rs):
        raise AccessDenied(f"macro {series}: rows after ts {min(bounds)} would be dropped, because this process has "
                           "no main script file while looks are open; run from a script file so its own looks "
                           "decide (release 5: no silent row drops)")
    logged = [r for r in rs if r["log"]]
    if logged and not linked:
        logged = [min(logged, key=lambda r: r["bound"])]      # in a run: one line, under the strictest run
    for r in logged:
        _log_macro(r, series, sha256, int(keep.sum()), int((~keep).sum()), linked=linked)
    served = latest[keep & np.isfinite(latest)]
    _note_macro_load(series, sha256, float(served.max()) if len(served) else None, int(keep.sum()), pinned,
                     logged=in_run or (linked and bool(logged)))
    return keep


# --------------------------------------------------------------------------------------------
# reading
# --------------------------------------------------------------------------------------------
def _make_load(check):
    def _load(instrument, granularity, price, era, frozen, cols, dtype, start, end, override,
              dept, study, history_for=None) -> pd.DataFrame:
        check()
        instrument, granularity, price, era, dept, study, history_for = (
            _plain(x) for x in (instrument, granularity, price, era, dept, study, history_for))
        inst = normalise_instrument(instrument)
        eras, kind, lid, dts = _check_request(era, override, dept, study, history_for)
        days = _history_days(history_for, frozen, dept, study)
        history = None if days is None else (history_for, days)
        if history is not None:
            t0 = E.era_bounds(history_for)[0]
            w0, s_, e_ = t0 - days * 86400, _to_ts(start), _to_ts(end)
            if (s_ is not None and s_ < w0) or (e_ is not None and e_ > t0):
                raise AccessDenied(f"a history read for {history_for} serves [{w0}, {t0}) only "
                                   f"({HISTORY_KEY} {days}); a start or end outside it is refused (item 3f)")
        lo, hi = _read_range(era, start, end, override, history)
        base = M1_COLS if price == "BA" else MID_COLS
        cols = list(base) if cols is None else list(cols)
        bad = [c for c in cols if c not in base]
        if bad:
            raise KeyError(f"unknown columns {bad}; available {base}")
        usecols = ["ts_utc"] + [c for c in base if c in cols]
        np_dtype = np.dtype(dtype)
        dtypes = {c: (np.int64 if c == "ts_utc" else np.int64 if c == "volume" else np_dtype)
                  for c in usecols}
        sets = [d for d in registry().values()
                if d["instrument"] == inst and d["granularity"] == granularity and d["price"] == price
                and d["first_ts"] <= hi and d["last_ts"] >= lo]
        if kind is None:
            sets = [d for d in sets if not d["locked"]]
        if not sets:
            if kind is not None:
                raise AccessDenied("no locked data set registered: rows >= 1751317200 are never in "
                                   "a DATA branch; STATS registers its own local locked files")
            raise FileNotFoundError(f"no registered {inst} {granularity} {price} data for era {era}")
        sets.sort(key=lambda d: d["first_ts"])
        needs_log = eras != ("BUILD",)
        fsha = code_sha = None
        fields: dict = {}
        if needs_log:
            fsha, code_sha, fields = _gate(eras, sets, frozen, kind, lid, dept, study, history)
            if history is not None:
                fields.update(kind="history", history_for=history[0], history_lookback_days=history[1])
            run_era = history[0] if history is not None else "+".join(eras)
            _admit_run(dept, study, run_era, fsha, E.era_bounds(history[0] if history else eras[-1])[1], code_sha,
                       _run_macro_pins(frozen, fsha) if fsha else None)
        frames = []
        for d in sets:
            path = data_root() / d["relpath"]
            if not path.exists() and d.get("branch"):
                path = fetch_dataset(d["name"])           # on demand: hunters never call it
            if not path.exists():
                raise FileNotFoundError(f"{path} not found (fetch_dataset or set FX_DATA_ROOT)")
            frames.append(_read_csv_range(path, usecols, dtypes, lo, hi, d["sha256"]))
        out = pd.concat(frames, ignore_index=True) if len(frames) > 1 else frames[0]
        out = out.sort_values("ts_utc", kind="stable").reset_index(drop=True)
        if out["ts_utc"].duplicated().any():
            raise DataIntegrityError(f"{inst} {granularity}: duplicate ts_utc across data sets")
        if "volume" in out.columns:
            out["volume"] = out["volume"].astype(np.int64)
        ts = out["ts_utc"].to_numpy()
        if len(ts) and (ts.min() < lo or ts.max() > hi):
            raise AssertionError("loader returned rows outside the authorised range")
        if kind is None and len(ts) and ts.max() >= E.LOCK_START:
            raise AccessDenied("a row at or after 1751317200 reached the loader without an override")
        if len(ts) and ts.min() < E.PRE_END and (E.PRE_OPEN is not True or eras != ("PRE",)):
            raise AccessDenied("a row before 2010-01-01 (era PRE) reached the loader outside an open PRE read")
        if needs_log:
            if dts is not None:
                fields["decision_ts"] = dts
            log_access(dept, study, era, ts.min() if len(ts) else None,
                       ts.max() if len(ts) else None, code_sha, fsha,
                       common_sha256=common_sha256(), instrument=inst, granularity=granularity,
                       datasets=[d["name"] for d in sets], override=kind, ledger_id=lid, **fields)
        if history is not None:
            out.attrs["history"] = history            # load_bars trims with the bound checked here
        return out
    return _load


_load = _make_load(_check_guard)


_BytesIO = io.BytesIO          # bound once: checked by identity with the module (finding #8)


def _make_reader(check, caller_code):
    def _read_csv_range(path: Path, usecols, dtypes, lo: int, hi: int, sha: str | None = None) -> pd.DataFrame:
        if sys._getframe(1).f_code is not caller_code:
            raise AccessDenied("the loaders' reader is called only by load_m1 / load_bars")
        if not (isinstance(sha, str) and re.fullmatch(r"[0-9a-f]{64}", sha)):
            raise AccessDenied("the loaders' reader needs the data set's sha256")
        check()
        with open(path, "rb") as f:                       # one read: the bytes hashed are the bytes parsed
            data = f.read()
        got = hashlib.sha256(data).hexdigest()
        if got != sha:
            raise DataIntegrityError(f"{path}: sha256 {got} != expected {sha}; refusing to load")
        chunks = []
        for ch in pd.read_csv(_BytesIO(data), usecols=usecols, dtype=dtypes, chunksize=1_000_000):
            ts = ch["ts_utc"].to_numpy()
            if len(ts) and (ts.max() < lo or ts.min() > hi):
                continue
            chunks.append(ch[(ts >= lo) & (ts <= hi)])
        del data
        if not chunks:
            return pd.DataFrame({c: pd.Series(dtype=dtypes[c]) for c in usecols})[usecols]
        return pd.concat(chunks, ignore_index=True)
    return _read_csv_range


_read_csv_range = _make_reader(_check_guard, _load.__code__)


def load_m1(instrument, era="BUILD", frozen=None, cols=None, dtype="float32", start=None,
            end=None, override=None, dept=None, study=None, history_for=None) -> pd.DataFrame:
    """M1 bid/ask bars: int64 ts_utc (bar open) and `dtype` prices (volume int64).
    start (inclusive) and end (exclusive) narrow the era: unix seconds or a UTC date string.
    history_for='T' with era='C': the T look's frozen lookback from C (module docstring, item 3f)."""
    return _load(instrument, "M1", "BA", era, frozen, cols, dtype, start, end, override,
                 dept, study, history_for)


def load_bars(instrument, granularity, era="BUILD", frozen=None, cols=None, dtype="float32",
              start=None, end=None, override=None, dept=None, study=None, price=None,
              resample_from_m1=False, drop_partial=True, h4_alignment="UTC",
              history_for=None) -> pd.DataFrame:
    """Bars of another granularity (M5, M15, M30, H1, H4, D) from a registered set.
    price: 'BA' (bid/ask) or 'M' (mid o,h,l,c); default: the only one registered. When both are registered
    (M15 of SPX500_USD, UK100_GBP, JP225_USD, XAU_USD, BCO_USD, NAS100_USD and DE30_EUR: BA 2010-2021, M from
    2016) price must be given; a call without it is refused before any read, since a silent default would
    drop the other set's years (14 Oct 2026).
    resample_from_m1=True builds the bars from M1 bid/ask (resample_m1) when no native set
    exists; D then means the 17:00 New York day ('D17NY'); H4 from M1 is UTC-aligned unless
    h4_alignment='17NY' ('H4_17NY', the alignment of the native OANDA H4 sets).
    drop_partial (resampled bars only): a bar whose span [open, end) is not wholly inside the
    read's range (era bounds narrowed by start/end) is dropped by default. Such an edge bar holds
    only part of its minutes, and its label can sit in the previous era (a T read's first D17NY
    bar opens at 1701381600, 17:00 New York on 30 Nov 2023, which era_of calls C). With
    drop_partial=False the bars are kept and flagged in a boolean 'partial' column. Interior
    gaps (weekends, missing minutes) are not flagged: check n.
    """
    instrument, granularity, era, price, history_for, h4_alignment = (
        _plain(x) for x in (instrument, granularity, era, price, history_for, h4_alignment))
    g = granularity.upper()
    if h4_alignment not in ("UTC", "17NY"):
        raise ValueError(f"h4_alignment {h4_alignment!r} is not 'UTC' or '17NY'")
    if g == "M1":
        return load_m1(instrument, era, frozen, cols, dtype, start, end, override, dept, study, history_for)
    inst = normalise_instrument(instrument)
    have = {d["price"] for d in registry().values() if d["instrument"] == inst and d["granularity"] == g}
    if price is None:
        if {"BA", "M"} <= have:
            raise ValueError(f"{inst} {g} has both a BA and an M set; pass price='BA' or price='M' "
                             "(DATA_CATALOG gives the years each covers)")
        price = "BA" if "BA" in have else ("M" if "M" in have else None)
    if price in have:
        out = _load(inst, g, price, era, frozen, cols, dtype, start, end, override, dept, study, history_for)
        # A native bar is labelled by its open but holds prices up to its close. Drop a bar whose
        # close lies after the read's range: a C read's D bar opening 30 Nov 2023 17:00 New York
        # closes on 1 Dec, in T (docs/EDGE_HUNT.md section 3 era rule).
        _, hi = _read_range(era, start, end, override, out.attrs.get("history"))
        keep = native_bar_end(out["ts_utc"].to_numpy(np.int64), g) - 1 <= hi
        return out[keep].reset_index(drop=True)
    if resample_from_m1 and price in (None, "BA"):
        m1 = load_m1(inst, era, frozen, None, dtype, start, end, override, dept, study, history_for)
        history = m1.attrs.get("history")
        rule = "D17NY" if g == "D" else "H4_17NY" if (g == "H4" and h4_alignment == "17NY") else \
            {"M5": "5min", "M15": "15min", "M30": "30min", "H1": "1h", "H4": "4h"}[g]
        out = resample_m1(m1, rule)
        lo, hi = _read_range(era, start, end, override, history)
        span_end = out["end_ts"].to_numpy() if "end_ts" in out.columns else \
            out["ts_utc"].to_numpy() + int(pd.Timedelta(rule).total_seconds())
        partial = (out["ts_utc"].to_numpy() < lo) | (span_end - 1 > hi)
        if drop_partial:
            out = out[~partial].reset_index(drop=True)
        else:
            out = out.assign(partial=partial)
        if cols is not None:
            out = out[["ts_utc"] + [c for c in out.columns if c in cols] +
                      [c for c in ("end_ts", "partial") if c in out.columns]]
        return out
    raise FileNotFoundError(f"no registered {inst} {g} data set (price {price}); "
                            "ask DATA, or pass resample_from_m1=True")


_NATIVE_SPAN = MappingProxyType({"M5": 300, "M15": 900, "M30": 1800, "H1": 3600, "H4": 4 * 3600})


def native_bar_end(open_ts: np.ndarray, granularity: str) -> np.ndarray:
    """Close time (exclusive, unix s) of native OANDA bars labelled by open time. D bars run to the
    next 17:00 New York (dailyAlignment 17, research/data/README.md); the other granularities
    are open + span (an H4 bar across a US clock change is taken as 4 h)."""
    g = granularity.upper()
    ts = np.asarray(open_ts, np.int64)
    if g == "D":
        t = pd.to_datetime(ts, unit="s", utc=True).tz_convert("America/New_York").tz_localize(None)
        close_local = (t + pd.Timedelta(hours=7)).normalize() + pd.Timedelta(hours=17)
        close_local = close_local.where(close_local > t, close_local + pd.Timedelta(days=1))
        return close_local.tz_localize("America/New_York").tz_convert("UTC").as_unit("s").asi8.astype(np.int64)
    return ts + _NATIVE_SPAN[g]


def resample_m1(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    """Resample M1 (bid/ask or mid) bars, labelled by OPEN time.
    o = first, h = max, l = min, c = last, volume = sum, plus n = number of M1 bars.
    rule: a fixed span ('5min', '15min', '1h', '4h', ...; buckets aligned to the unix epoch, so
    H4 opens at 00, 04, 08 ... UTC; 'H4_UTC' is the same 4-hour bars, named so a department call says
    its alignment, coordinator 14 Oct 2026), or 'D17NY': the trading day that runs from 17:00 to 17:00
    America/New_York (DST-aware), labelled by its 17:00 New York open in UTC and carrying an
    end_ts column (23, 24 or 25 hours later), or 'H4_17NY': 4-hour bars aligned to that day, opening
    at 17:00, 21:00, 01:00, 05:00, 09:00 and 13:00 New York (DST-aware, as OANDA's H4 with
    dailyAlignment 17 America/New_York; the coordinator, 14 Oct 2026), with an end_ts column. A bar whose
    New York open falls in a clock change (only on a Sunday morning, when FX is shut) is refused.
    Bars at an era edge can be partial; check n. df must be sorted by ts_utc.
    """
    ts = df["ts_utc"].to_numpy(np.int64)
    if len(ts) > 1 and np.any(np.diff(ts) <= 0):
        raise ValueError("resample_m1 needs strictly increasing ts_utc")
    end_ts = None
    if rule == "D17NY":
        t = pd.to_datetime(ts, unit="s", utc=True).tz_convert("America/New_York").tz_localize(None)
        day = (t + pd.Timedelta(hours=7)).normalize()          # trading day = date of t + 7h
        open_local = day - pd.Timedelta(hours=7)               # 17:00 New York the day before
        open_utc = open_local.tz_localize("America/New_York").tz_convert("UTC")
        key = open_utc.as_unit("s").asi8.astype(np.int64)
        close_local = open_local + pd.Timedelta(days=1)
        close_utc = close_local.tz_localize("America/New_York").tz_convert("UTC")
        end_all = close_utc.as_unit("s").asi8.astype(np.int64)
    elif rule == "H4_17NY":
        t = pd.to_datetime(ts, unit="s", utc=True).tz_convert("America/New_York").tz_localize(None)
        open_local = (t + pd.Timedelta(hours=7)).floor("4h") - pd.Timedelta(hours=7)   # 17, 21, 01, 05, 09, 13
        try:
            open_utc = open_local.tz_localize("America/New_York", ambiguous="raise", nonexistent="raise")
            close_utc = (open_local + pd.Timedelta(hours=4)).tz_localize("America/New_York", ambiguous="raise",
                                                                         nonexistent="raise")
        except (ValueError, TypeError) as e:          # pytz Ambiguous/NonExistentTimeError are ValueErrors
            raise ValueError(f"H4_17NY: a bar's 4-hour New York span falls in a clock change ({e})") from None
        key = open_utc.tz_convert("UTC").as_unit("s").asi8.astype(np.int64)
        end_all = close_utc.tz_convert("UTC").as_unit("s").asi8.astype(np.int64)
    else:
        sec = 4 * 3600 if rule == "H4_UTC" else int(pd.Timedelta(rule).total_seconds())
        if sec <= 0 or sec % 60:
            raise ValueError("rule must be a whole number of minutes")
        key = (ts // sec) * sec
    starts = np.flatnonzero(np.r_[True, key[1:] != key[:-1]]) if len(key) else np.array([], int)
    if len(key) > 1 and np.any(np.diff(key) < 0):
        raise ValueError("bucket keys not monotonic")
    out = {"ts_utc": key[starts]}
    for side in ("bid_", "ask_", ""):
        o, h, l, c = (side + x for x in "ohlc")
        if o in df.columns:
            out[o] = df[o].to_numpy()[starts]
        if h in df.columns:
            out[h] = np.maximum.reduceat(df[h].to_numpy(), starts) if len(starts) else df[h].to_numpy()[:0]
        if l in df.columns:
            out[l] = np.minimum.reduceat(df[l].to_numpy(), starts) if len(starts) else df[l].to_numpy()[:0]
        if c in df.columns:
            ends = np.r_[starts[1:], len(key)] - 1
            out[c] = df[c].to_numpy()[ends] if len(starts) else df[c].to_numpy()[:0]
    if "volume" in df.columns:
        out["volume"] = np.add.reduceat(df["volume"].to_numpy(np.int64), starts) if len(starts) \
            else np.array([], np.int64)
    out["n"] = np.diff(np.r_[starts, len(key)]).astype(np.int64)
    res = pd.DataFrame(out)
    if rule in ("D17NY", "H4_17NY"):
        res["end_ts"] = end_all[starts]
    cols = ["ts_utc"] + [c for c in df.columns if c in res.columns and c != "ts_utc"] + \
        [c for c in ("n", "end_ts") if c in res.columns]
    return res[cols]


# Arm the runtime guard (audit finding #8) last, once every name of this module exists. The era
# table is checked against its literal values, so a change made before this import is refused too.
if (E.PRE_END, E.PRE_OPEN, E.BUILD_START) != (1262304000, False, 1262304000) or \
        dict(E._BOUNDS) != {"PRE": (-(2 ** 62), 1262303999), "BUILD": (1262304000, 1640995199), "C": (1640995200, 1701388799),
                       "T": (1701388800, 1751317199), "VALIDATION": (1751317200, 1774990799),
                       "HOLDOUT": (1774990800, 1791493199), "FORWARD": (1791493200, 2 ** 62)}:
    raise ImportError("research.common.eras was changed before research.common.loaders was imported")
_GUARDED_EXTERNALS = ((json, "loads"), (json, "load"), (json, "dumps"), (json, "dump"), (hashlib, "sha256"),
                      (hashlib, "new"), (subprocess, "run"), (subprocess, "Popen"), (builtins, "open"), (io, "open"),
                      (os, "open"), (os, "fspath"), (Path, "read_bytes"), (Path, "read_text"), (Path, "open"),
                      (Path, "resolve"), (Path, "exists"), (Path, "is_file"), (Path, "relative_to"), (gzip, "open"),
                      (gzip, "decompress"), (pd, "read_csv"), (pd, "concat"), (time, "time"))
_arm_guard(((__name__, globals(), __file__, _UNCHECKED), (E.__name__, vars(E), E.__file__, frozenset()),
            (A.__name__, vars(A), A.__file__, frozenset()), (K.__name__, vars(K), K.__file__, frozenset())),
           _GUARDED_EXTERNALS)
