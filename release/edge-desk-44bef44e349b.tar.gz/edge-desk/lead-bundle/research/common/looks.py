"""LOOKS.jsonl writer (docs/EDGE_HUNT.md section 5, "Looks") and small shared helpers.

Line format, one JSON object per line, in research/departments/<DEPT>/LOOKS.jsonl:
  {"id", "study", "era", "what", "n_configs", "code_sha256", "decl_sha256", "frozen_sha256",
   "utc", "status"} + summary numbers (only on the "done" line, by convention).
Before any run that reads outcomes, append the "started" line AND PUSH IT; the loaders check
the pushed copy (origin/dept/<dept>) before any C or T read. After the run, append the same id
with status "done" and the summary.

The repo root is $FX_REPO_ROOT when set (tests use temporary repos), else the checkout that
holds this file (``package_root()``). research.common.loaders refuses a C, T or locked read of
real data unless repo_root() is package_root() and its origin is the GitHub repo (audit
finding #2): FX_REPO_ROOT can point the loaders at another checkout only for synthetic data.
"""
from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

DEPTS = ("DATA", "STATS", "COST", "MACRO", "EVENTS", "OWNER", "FUNDED")   # FUNDED: coordinator, 14 Oct 2026
STATUSES = ("started", "done", "aborted")
LOOK_ERAS = ("BUILD", "C", "T", "VALIDATION", "HOLDOUT", "FORWARD")
CORE_KEYS = ("id", "study", "era", "what", "n_configs", "code_sha256", "decl_sha256",
             "frozen_sha256", "utc", "status")


_PACKAGE_ROOT = Path(__file__).resolve().parents[2]


def package_root(_root=_PACKAGE_ROOT) -> Path:
    """The checkout that holds this research/common package (fixed at import)."""
    return _root


def repo_root() -> Path:
    env = os.environ.get("FX_REPO_ROOT")
    if env:
        return Path(env).resolve()
    return package_root()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def check_dept(dept: str) -> str:
    if dept not in DEPTS:
        raise ValueError(f"unknown department {dept!r}; expected one of {DEPTS}")
    return dept


def dept_dir(dept: str) -> Path:
    return repo_root() / "research" / "departments" / check_dept(dept)


def looks_path(dept: str) -> Path:
    return dept_dir(dept) / "LOOKS.jsonl"


def read_looks_text(text: str) -> list[dict]:
    out = []
    for i, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError as e:
            raise ValueError(f"LOOKS.jsonl line {i} is not JSON: {e}") from None
    return out


def read_looks(dept: str) -> list[dict]:
    p = looks_path(dept)
    return read_looks_text(p.read_text()) if p.exists() else []


def append_look(dept, study, era, what, n_configs, code_sha256, decl_sha256, frozen_sha256,
                status, look_id=None, **summary) -> dict:
    """Append one line to research/departments/<DEPT>/LOOKS.jsonl and return it.

    look_id: for "started", default "<study>-L<nn>" (next number for that study); for "done" or
    "aborted", default the id of the latest "started" line of the same study, era and
    frozen_sha256 that has no closing line yet.
    Pushing the file is the caller's job (git add/commit/push by the session lead).
    """
    check_dept(dept)
    if status not in STATUSES:
        raise ValueError(f"status must be one of {STATUSES}")
    if era not in LOOK_ERAS:
        raise ValueError(f"era must be one of {LOOK_ERAS}")
    if not study or not isinstance(study, str):
        raise ValueError("study id required")
    if not isinstance(n_configs, int) or n_configs < 1:
        raise ValueError("n_configs must be a positive int (count every configuration)")
    clash = set(summary) & set(CORE_KEYS)
    if clash:
        raise ValueError(f"summary may not override core keys: {sorted(clash)}")
    lines = read_looks(dept)
    if look_id is None:
        if status == "started":
            n = sum(1 for r in lines if r.get("study") == study and r.get("status") == "started")
            look_id = f"{study}-L{n + 1:02d}"
        else:
            closed = {r.get("id") for r in lines if r.get("status") in ("done", "aborted")}
            open_ = [r for r in lines if r.get("status") == "started" and r.get("study") == study
                     and r.get("era") == era and r.get("frozen_sha256") == frozen_sha256
                     and r.get("id") not in closed]
            if not open_:
                raise ValueError("no open 'started' line to close; pass look_id")
            look_id = open_[-1]["id"]
    row = {"id": look_id, "study": study, "era": era, "what": what, "n_configs": n_configs,
           "code_sha256": code_sha256, "decl_sha256": decl_sha256, "frozen_sha256": frozen_sha256,
           "utc": utc_now(), "status": status}
    row.update(summary)
    p = looks_path(dept)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a") as f:
        f.write(json.dumps(row, sort_keys=False) + "\n")
    return row
