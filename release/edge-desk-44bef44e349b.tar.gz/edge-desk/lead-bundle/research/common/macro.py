"""Sha-checked loader for DATA's published macro package, branch ``data/macro`` (audit finding #17).

The branch holds flat CSV files (meetings.csv, bank_calendar.csv, us_releases.csv, policy_rates.csv,
policy_rates_daily.csv, cpi.csv, yields.csv, cftc_cot.csv, bis_eer.csv, fixings_2004_2009.csv, ...),
a README.md, and SHA256.txt with one ``<sha256>  <file name>`` line per file (sha256sum format).
Department code reads these files only through ``load``, never with ``git show`` or a raw reader of its own.
The static guard (research/common/tests/guard_scan.py, rule C) flags this module's ``macro_dir``, ``fetch`` and
``L`` and FX_DATA_ROOT named in non-test department code (release 5); a ``git show`` of data/macro and a
committed copy of one of these files are not machine-checked.

    from research.common import macro
    m = macro.load("meetings.csv")                   # one file (fetched first); *_utc columns parsed as UTC
    m = macro.load("meetings.csv", sha256=pin)       # the version a frozen study recorded
    t = macro.release_ts(m, "announce_utc_latest")   # int64 unix seconds
    rate = macro.rate_fn(macro.load("policy_rates_daily.csv"))
    rate("USD", 1450378800)                          # % a year in force that day, announced before ts

What each function checks:

- Only the ref ``origin/data/macro`` is accepted (``ValueError`` for any other, data/* included), so
  this module can never copy another branch's files onto disk.
- ``fetch(repo=None, ref="origin/data/macro")``: ``git fetch origin +refs/heads/data/macro:
  refs/remotes/origin/data/macro``, then ``git show refs/remotes/origin/data/macro:SHA256.txt`` and
  ``git show ...:<file>`` for every listed file. The listing may name only ``*.csv`` tables and
  README.md (``MacroIntegrityError`` for ``x.csv.gz``, ``x.txt`` ...). Every file must match its
  listed sha256 (``MacroIntegrityError`` otherwise) and must not be a registered price data set;
  every CSV must pass the header, cutoff and price-file checks below; README.md must be UTF-8 text of
  at most README_MAX_BYTES. Only then is anything written (atomically) to
  ``<loaders.data_root()>/macro/``, with SHA256.txt last. Returns that folder. ``MacroNotPublished``
  when origin has no such branch. Offline (fetch and ``git ls-remote`` both fail) it uses the last
  fetched ref if there is one, with the same checks.
- ``load(name, columns=None, *, sha256=None, repo=None, ref=...)``: the listing is the ref's own
  SHA256.txt in this checkout (no network; ``fetch`` is called once when the ref is missing). A name
  not in the listing raises ``KeyError``; a listed file that is not a ``.csv`` raises ``ValueError``.
  The local file is re-hashed on every call; a missing or changed copy is replaced from the ref
  (sha-checked), so ``load`` serves the published bytes of the checkout's ref. ``sha256=`` pins a
  version: when the tip publishes another sha (DATA republished), the newest commit in the ref's
  history whose SHA256.txt lists ``name`` with the pin is found (``git rev-list --full-history``) and
  its blob served, after the same checks (nothing is written to disk for it); a pin no commit
  published raises ``MacroIntegrityError``. So DATA publishes data/macro only as fast-forward
  commits (research/data/publish_branch.py), never a force-pushed orphan.
  The table is parsed from the bytes that were hashed, the cutoff check runs again on every row,
  and ``*_utc`` text columns are parsed as tz-aware UTC datetimes; ``*_ts`` columns are Int64.
- Inside a C, T or locked run (the process's first gated read of research.common.loaders, kept per test under
  pytest): ``load`` needs ``sha256=``, serves only the rows whose latest time (as the cutoff check reads them) is
  at or before the run's era end (T's end for a T look with history), and writes one ACCESS_LOG line (kind
  "macro", series, sha256, asof_bound, rows, rows_dropped, run_id). A load before the run's first read is
  logged by that read (before_run true), or refuses it when it served a row past the bound (STATS macro-series
  rule, AUDITS.md dept/stats a0f8738f; coordinator, 14 Oct 2026). Outside runs the cutoff check above applies.
- Release 5 (docs/EDGE_HUNT.md; coordinator, 14 Oct 2026; loaders.macro_read): the pin must be the sha256 the
  run's FROZEN.json gives the file (``data_macro_sha256`` or ``pins`` key ``data/macro:<file>``); every load of
  the process (before or under an earlier run) must fit each run admitted later. A process with no run of its
  own that runs an open look's code (the started line's code_sha256 or main_sha256, or a pin in the look's own
  folder; a multiprocessing child counts as its parent's main) is bound the same way and logs with linked=true;
  one with no main script file needs a pin and is refused when rows past the earliest open look's era end would
  be dropped; when origin's looks cannot be read and were never read in the process, the read is refused, and
  when a re-read fails the last reading is kept and a pin is needed. Open looks: pushed 'started' lines for C, T,
  VALIDATION, HOLDOUT or FORWARD with no pushed 'done' or 'aborted' line (matched by id when the lines have one),
  read at most once a minute.
  ``frozen=`` (STATS's locked runner) gives a run with no FROZEN of its own the pins to check.
- Release 6 (coordinator, 14 Oct 2026): in a process whose FX_LOCKED_RUN names a STATS ledger id, ``load`` needs
  ``sha256=`` and ``frozen=`` while that id is an open run (loaders.open_run_kind), and is refused when it is not
  open. STATS's runner sets it in a locked run's worker; no other process is affected.
- ``release_ts(df, col)``: int64 unix seconds from a tz-aware datetime column, an ISO text column
  with a time and a UTC offset (``2015-12-16T19:00:00Z``), or an integer seconds column. A
  calendar-day column (asof_date, effective_date, period), a missing value, a naive datetime, a date
  without a time or a fractional number raises ``ValueError``: a date is not a release time.
- ``rate_fn(df_daily=None)``: a callable ``rate(ccy, ts) -> float``, the policy rate in % a year that
  was in force on the UTC calendar day of ``ts``, counting only levels announced before ``ts``.
  See ``rate_fn`` for the rule. A judged pick prices financing with COST's
  ``policy_rate_lookup(macro.load("policy_rates_daily.csv"))``, which also gives the ``rate_range``
  that ``financing_rows(..., freezing=True)`` needs; the test suite checks that the two agree.

Header check: a CSV whose header has a blank cell or two cells with one name (after the name rule
below), or a row with more fields than the header, raises ``MacroIntegrityError``.

Cutoff check (defence in depth; docs/EDGE_HUNT.md section 3): ``fetch`` and ``load`` refuse a file
with any row at or after ``ts_utc`` 1751317200 (30 Jun 2025 21:00 UTC) in any time column, by
raising ``MacroLateRow`` (nothing is written or returned; the message names the column and the row
count, never a value). Time columns are found by name: the name is stripped, camelCase is split, it
is lower-cased, and every run of characters other than a-z and 0-9 splits it into tokens
('Obs Date' -> obs, date; 'releaseUTC' -> release, utc):
  - a ``ts`` token: unix seconds (announce_ts_utc, ts_utc);
  - else a ``utc`` token: an ISO instant (release_utc, announce_utc_latest, ...);
  - else a ``date``, ``period``, ``month``, ``quarter`` or ``year`` token, or a last token ``from``:
    a calendar day, checked at 00:00 UTC of that day (effective_date, asof_date, obs_date,
    local_date, period, rate_effective_from);
  - a first token retrieved, fetched, downloaded or accessed followed only by utc, at, on, date,
    ts or time tokens (retrieved_utc) is a retrieval stamp (when DATA read the source, after the
    cutoff by nature) and is not checked.
Every other text column is also scanned: a whole-cell ISO date or instant (``2025-07``,
``2025-07-01``, ``2025-07-01T12:00Z``) at or after the cutoff raises ``MacroLateRow``, whatever the
column's name. A value in a time column that does not parse raises ``MacroIntegrityError`` (it cannot
be shown to be before the cutoff), and so does a file with calendar-day values but no release-time
(``ts`` or ``utc``) value at all. A CSV with bid/ask/mid or o/h/l/c (open/high/low/close) bar columns,
or any file whose sha256 is a registered price data set, is refused (``files.PriceFileRefused``):
prices come only from load_m1 / load_bars. A price series under plain column names (``value``)
cannot be told from a macro series by its header. Two published tables are FX prices or built from them:
fixings_2004_2009.csv (ECB and Fed H.10 daily rates) and bis_eer.csv (BIS effective exchange rates). While
``eras.PRE_OPEN`` is False their rows whose earliest time (observation date or release; a blank calendar day, or no
time at all, counts as PRE) is before 2010-01-01 (era PRE) are locked (STATS ruling, 16 Oct 2026 about 2:28 am
Melbourne; PASS_BAR section 15 "Locks"): ``load`` raises ``MacroPreLocked`` on such a table unless
``pre_rows="exclude"`` (the table without those rows, window or not). The lock is decided on the published bytes before pandas
reads them (csv's C reader, str methods and integer arithmetic, bound at import and in the loaders' runtime guard;
red team of release 13), the table is parsed from the kept lines only, and the parsed table is checked again.
Exception: a frozen study reads the PRE rows inside its declared look-back before its first BUILD decision (STATS
rulings 16 Oct 2026 about 3:44 and 4:04 am), the rows whose earliest time is in
[first_build_decision - history_lookback_days, min(first_build_decision, 2010-01-01)), when all of these hold:
- the calling code (the first frame outside research/common, an existing file) sits in
  research/departments/<DEPT>/<study>/, DEPT is not STATS and is the main script's department when the main script
  is a department's, and no STATS locked run is named;
- every frame of the call is a file of that study folder, research/common or a Python library, and the stack starts
  at the main script, which is a file of that study or pytest (``python -m pytest``, or pytest's own launcher
  unchanged); so a STATS test or an outside script running the study's code, exec() or compile() under the study's
  file names, a thread or a callback with no caller never get the window;
- that study's FROZEN.json is complete (loaders.frozen_problems), committed unchanged at HEAD of this checkout (not
  of a repository made inside the folder; while $FX_REPO_ROOT points at another checkout, a test world, that one
  counts too, but then a table whose bytes this checkout's data/macro history publishes gets no window), and records ``history_lookback_days`` (1 to 400) and
  ``first_build_decision`` (ts_utc of its first BUILD decision, inside BUILD). When FROZEN.json lacks
  ``first_build_decision`` it is read from the study's FROZEN_AMEND.json, which must name that FROZEN.json
  ("frozen": "FROZEN.json" or its repo path), record its exact sha256 ("frozen_sha256") and be committed unchanged
  at HEAD; when both files hold the field they must agree. Either field missing refuses the exception, and a
  look-back that starts in 2010 or later reads no PRE row.
Each such read is logged in that department's ACCESS_LOG.jsonl (kind "macro_pre_lookback", era "BUILD" because it
feeds BUILD decisions; rows_era "PRE").
Rates, yields, CPI, CFTC and the calendars are not affected.

``rate_fn`` and ``release_ts`` are pure functions of the frame they get and apply no cutoff, so STATS
can use them on its own locked-era tables; frames from ``load`` have already passed the check.

Git commands (git docs: git-fetch, git-ls-remote, git-show, git-rev-parse, git-rev-list), run through
the loaders' git wrapper (GIT_* redirection variables dropped, ``--no-replace-objects``): ``git fetch
--quiet origin +refs/heads/<b>:refs/remotes/origin/<b>``, ``git ls-remote origin refs/heads/<b>``,
``git rev-parse --verify --quiet <ref>``, ``git show <ref>:<path>``, ``git rev-list --full-history
<ref> -- SHA256.txt``. The full ref ``refs/remotes/origin/data/macro`` is used, so a local branch
named ``origin/data/macro`` cannot shadow it. pandas: ``read_csv`` (``index_col=False``; a
``ParserWarning`` about a row longer than the header is raised as an error), ``to_datetime(utc=True,
format="ISO8601")``, ``DatetimeIndex.as_unit("s").asi8`` (pandas 3 keeps us resolution for ISO text;
``as_unit`` before ``asi8``), ``to_numeric``.
"""
from __future__ import annotations

import _csv
import _imp
import hashlib
import io
import json
import os
import re
import runpy
import sys
import tempfile
import warnings
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

from . import access as A
from . import eras as E
from . import files as FL
from . import loaders as L
from .looks import repo_root

CUTOFF_TS = 1751317200                     # 2025-06-30 21:00 UTC (eras.LOCK_START)
assert CUTOFF_TS == E.LOCK_START
BRANCH = "data/macro"
DEFAULT_REF = "origin/data/macro"          # the ONLY ref accepted (red team: no other data/* branch)
LISTING = "SHA256.txt"
README = "README.md"                       # the one listed file that is not a .csv table
README_MAX_BYTES = 256 * 1024              # the published README is about 72 KB (13 Oct 2026)
_REFS = (DEFAULT_REF, BRANCH, f"refs/remotes/{DEFAULT_REF}")     # bound: see _full_ref
_NAME_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")
_CSV_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*\.csv")
_SHA_RE = re.compile(r"[0-9a-f]{64}")
_COMMIT_RE = re.compile(r"[0-9a-f]{40}|[0-9a-f]{64}")
_CAMEL = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
_NON_ALNUM = re.compile(r"[^0-9a-z]+")
_META_FIRST = frozenset({"retrieved", "fetched", "downloaded", "accessed"})
_META_REST = frozenset({"utc", "at", "on", "date", "ts", "time"})
_DAY_TOKENS = frozenset({"date", "period", "month", "quarter", "year"})
_INSTANT_TEXT = re.compile(r"\s*\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?\s*(Z|[+-]\d{2}:?\d{2})\s*")
_DATE_SHAPE = re.compile(r"\d{4}-\d{2}(-\d{2}([T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?\s*(Z|[+-]\d{2}:?\d{2})?)?)?")
_PRICE_PREFIX = re.compile(r"(bid|ask|mid)_(o|h|l|c|open|high|low|close)")
_OHLC_LONG = frozenset({"open", "high", "low", "close"})
_PKG_PRICE_SHAS = frozenset(getattr(L, "_REAL_SHAS", frozenset()))   # the package registry, never $FX_DATASETS_JSON
_DAY = 86400
# The PRE gate's own tools, bound once at import (red team of release 13, 16 Oct 2026: the PRE mask used numpy
# functions a script could replace through sys.modules). The gate decides on the published bytes with the csv
# module's C reader, str methods, these compiled patterns and integer arithmetic only, before pandas or numpy
# see the table; this module's names are in the loaders' runtime guard, so rebinding any of them refuses reads.
_getframe = sys._getframe
_csv_reader = _csv.reader
_is_frozen = _imp.is_frozen
_RUN_AS_MAIN = runpy._run_module_as_main.__code__
if type(_getframe) is not type(len) or _getframe.__module__ != "sys" or type(_csv_reader) is not type(len) \
        or _csv_reader.__module__ != "_csv" or _RUN_AS_MAIN.co_filename not in ("<frozen runpy>", runpy.__file__):
    raise ImportError("sys._getframe, _csv.reader or runpy was changed before research.common.macro was imported")
_DIGITS = str.maketrans("0123456789", "9999999999")
# frame file names of the frozen import machinery, whose frozen module names differ (red team, 16 Oct 2026)
_FROZEN_FRAMES = frozenset({"<frozen importlib._bootstrap>", "<frozen importlib._bootstrap_external>"})
_LIB_DIRS = tuple(sorted(set(L._library_prefixes()) | {
    str(Path(m.__file__).resolve().parent) for m in (sys.modules.get(k) for k in (
        "pytest", "_pytest", "pluggy", "iniconfig", "packaging", "numpy", "pandas", "dateutil", "pytz", "tzdata"))
    if m is not None and str(getattr(m, "__file__", "") or "").endswith("__init__.py")}))
_PYTEST_DIR = (str(Path(sys.modules["pytest"].__file__).resolve().parent)
               if "pytest" in sys.modules and getattr(sys.modules["pytest"], "__file__", None) else None)
_PYTEST_WRAPPER = re.compile(
    rb"#![^\n]*\n# -\*- coding: utf-8 -\*-\n(?:import re\nimport sys\nfrom pytest import console_main\n"
    rb"if __name__ == ['\"]__main__['\"]:\n    sys\.argv\[0\] = re\.sub\(r['\"]\(-script\\\.pyw\|\\\.exe\)\?\$['\"], "
    rb"['\"]['\"], sys\.argv\[0\]\)\n    sys\.exit\(console_main\(\)\)\n?"
    rb"|import sys\nfrom _pytest\.config import _console_main\nif __name__ == ['\"]__main__['\"]:\n"
    rb"    if sys\.argv\[0\]\.endswith\(['\"]-script\.pyw['\"]\):\n        sys\.argv\[0\] = sys\.argv\[0\]\[:-11\]\n"
    rb"    elif sys\.argv\[0\]\.endswith\(['\"]\.exe['\"]\):\n        sys\.argv\[0\] = sys\.argv\[0\]\[:-4\]\n"
    rb"    sys\.exit\(_console_main\(\)\)\n?)")


class MacroNotPublished(RuntimeError):
    """origin has no data/macro branch (not published yet), or its ref is missing offline."""


class MacroIntegrityError(L.DataIntegrityError):
    """A file does not match SHA256.txt, the listing is malformed, or a time value does not parse."""


class MacroLateRow(L.AccessDenied):
    """A row at or after ts_utc 1751317200 in a time column: refused, nothing stored or returned."""


class MacroPreLocked(L.AccessDenied):
    """A table's rows before 2010-01-01 (era PRE) are locked (module docstring)."""


PRE_LOCKED = frozenset({"fixings_2004_2009.csv", "bis_eer.csv"})   # FX prices, or built from them
PRE_LOOKBACK_MAX_DAYS = 400                                         # the STATS cap on history_lookback_days


class RateMissing(ValueError):
    """rate(ccy, ts) has no policy rate: unknown currency, a day outside the table, no level announced
    before ts, or a day on which the bank had no rate target (an empty ``rate``)."""


# ------------------------------------------------------------------------------------- paths and refs
def macro_dir() -> Path:
    """<loaders.data_root()>/macro, where ``fetch`` writes and ``load`` reads. DATA and STATS only
    (loaders module docstring item 6)."""
    L.require_internal_caller("macro_dir")
    return L.data_root() / "macro"


def _full_ref(ref: str, _refs=_REFS) -> tuple[str, str]:
    """'origin/data/macro' -> ('data/macro', 'refs/remotes/origin/data/macro'). That is the only ref
    accepted: any other data/* branch (a price branch, data/macro-v2, data/foo) raises ValueError, so
    this module can never copy another branch's files onto disk (red team, macro-loader). The allowed
    ref is bound as a default argument, so changing DEFAULT_REF does not widen it."""
    if not isinstance(ref, str) or ref != _refs[0]:
        raise ValueError(f"ref must be {_refs[0]!r} (the only branch this loader reads), got {ref!r}")
    return _refs[1], _refs[2]


def _repo(repo) -> Path:
    return Path(repo) if repo is not None else repo_root()


def _test_world(repo: Path) -> bool:
    """A test's own repo: outside this checkout, and no origin URL is the GitHub repo or a path into this
    checkout. Only then may a department's tests/ folder call fetch (loaders module docstring item 6)."""
    root = L.package_root().resolve()
    inside = lambda p: p == root or root in p.parents
    try:
        if inside(Path(repo).resolve()):
            return False
    except OSError:
        return False
    r = L._git_run(["remote", "get-url", "--all", "origin"], Path(repo))
    urls = [u.strip() for u in r.stdout.decode(errors="replace").splitlines() if u.strip()] if r.returncode == 0 else []
    for u in urls:
        if L.GITHUB_ORIGIN.fullmatch(u):
            return False
        path = u[len("file://"):] if u.startswith("file://") else u
        if "://" not in path and not re.match(r"^[\w.-]+@[^:]+:", path):
            try:
                if inside(Path(path).resolve()):
                    return False
            except OSError:
                return False
    return True


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


# ------------------------------------------------------------------------------------- listing
def parse_listing(raw: bytes) -> dict[str, str]:
    """SHA256.txt bytes -> {file name: sha256}. Lines are ``<64 hex>  <name>`` (a leading '*' on the
    name, sha256sum's binary mark, is dropped); blank lines and '#' lines are skipped. A malformed
    line, a name with a folder part, a duplicate name, a listed SHA256.txt, a name that is neither a
    ``*.csv`` table nor README.md (``x.csv.gz``, ``x.txt``, ``x.CSV``: files the content checks cannot
    read) or an empty listing raises MacroIntegrityError, so ``fetch`` writes nothing."""
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as e:
        raise MacroIntegrityError(f"{LISTING} is not UTF-8 text") from e
    out: dict[str, str] = {}
    for i, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        parts = s.split(None, 1)
        if len(parts) != 2 or not _SHA_RE.fullmatch(parts[0]):
            raise MacroIntegrityError(f"{LISTING} line {i} is not '<sha256>  <name>'")
        name = parts[1].strip()
        if name.startswith("*"):
            name = name[1:]
        if not _NAME_RE.fullmatch(name) or name == LISTING:
            raise MacroIntegrityError(f"{LISTING} line {i}: {name!r} is not a plain file name")
        if name != README and not _CSV_RE.fullmatch(name):
            raise MacroIntegrityError(f"{LISTING} line {i}: {name!r} is not a .csv table or {README}; "
                                      "the package holds nothing else")
        if name in out:
            raise MacroIntegrityError(f"{LISTING} lists {name} twice")
        out[name] = parts[0]
    if not out:
        raise MacroIntegrityError(f"{LISTING} lists no files")
    return out


# ------------------------------------------------------------------------------------- content checks
def _norm(col) -> str:
    """A column name as snake tokens: strip, split camelCase, lower case, and any run of characters
    that is not a-z or 0-9 becomes one '_' ('Obs Date' -> 'obs_date', 'releaseUTC' -> 'release_utc',
    'release_utc.1' -> 'release_utc_1', a BOM or other non-ASCII character -> a separator)."""
    s = _CAMEL.sub("_", str(col).strip()).lower()
    return "_".join(t for t in _NON_ALNUM.split(s) if t)


def _tokens(col: str) -> list[str]:
    return [t for t in _norm(col).split("_") if t]


def time_kind(col: str) -> str | None:
    """'instant' (ISO text), 'ts' (unix seconds), 'day' (calendar day), 'meta' (a retrieval stamp)
    or None, from the column name (rule in the module docstring)."""
    t = _tokens(col)
    if not t:
        return None
    if t[0] in _META_FIRST and all(x in _META_REST for x in t[1:]):
        return "meta"
    if "ts" in t:
        return "ts"
    if "utc" in t:
        return "instant"
    if _DAY_TOKENS.intersection(t) or t[-1] == "from":
        return "day"
    return None


def _present(s: pd.Series) -> pd.Series:
    """Non-empty cells (NaN, None and blank text count as empty)."""
    if pd.api.types.is_object_dtype(s.dtype) or pd.api.types.is_string_dtype(s.dtype):
        m = s.notna() & (s.astype("string").str.strip() != "")
        return m.fillna(False).astype(bool)
    return s.notna()


def _is_text(s: pd.Series) -> bool:
    return pd.api.types.is_object_dtype(s.dtype) or pd.api.types.is_string_dtype(s.dtype)


def _as_instants(s: pd.Series) -> pd.Series:
    if isinstance(s.dtype, pd.DatetimeTZDtype):
        return s.dt.tz_convert("UTC")
    return pd.to_datetime(s, utc=True, format="ISO8601", errors="coerce")


def _check_rows(df: pd.DataFrame, what: str, _cut=CUTOFF_TS) -> None:
    """Refuse a row at or after the cutoff in any time column, or a date-shaped text value at or after
    it in any other column except a retrieval stamp (MacroLateRow); a time value that does not parse,
    two columns with one name, or a calendar-day column with no release-time column
    (MacroIntegrityError). Messages give counts, never values."""
    cut = pd.Timestamp(_cut, unit="s", tz="UTC")
    norm = [_norm(c) for c in df.columns]
    if len(set(norm)) != len(norm) or "" in norm:
        raise MacroIntegrityError(f"{what}: a blank column name or two columns with one name; refused")
    released = dated = False
    for col in df.columns:
        kind = time_kind(col)
        if kind == "meta":
            continue
        s = df[col]
        has = _present(s)
        if not has.any():
            continue
        if kind is None:
            # second layer, whatever the name: whole-cell ISO dates or instants in a text column
            if not _is_text(s):
                continue
            txt = s.where(has).astype("string").str.strip()
            shaped = (has & txt.str.fullmatch(_DATE_SHAPE.pattern).fillna(False)).astype(bool)
            if shaped.any():
                v = pd.to_datetime(txt.where(shaped), utc=True, format="ISO8601", errors="coerce")
                late = shaped & v.notna() & (v >= cut)
                if late.any():
                    raise MacroLateRow(f"{what}: {int(late.sum())} date value(s) at or after ts_utc {_cut} "
                                       f"(2025-06-30 21:00 UTC) in column {col}; refused")
            continue
        if pd.api.types.is_bool_dtype(s.dtype):
            raise MacroIntegrityError(f"{what}: column {col} holds booleans, not times")
        if kind == "ts":
            v = pd.to_numeric(s.where(has), errors="coerce")
            bad = has & v.isna()
            late = has & v.notna() & (v >= _cut)
            released = True
        else:
            v = _as_instants(s.where(has))
            bad = has & v.isna()
            late = has & v.notna() & (v >= cut)
            if kind == "instant":
                released = True
            else:
                dated = True
        if bad.any():
            raise MacroIntegrityError(f"{what}: {int(bad.sum())} value(s) in time column {col} do not "
                                      "parse; the cutoff cannot be checked")
        if late.any():
            raise MacroLateRow(f"{what}: {int(late.sum())} row(s) at or after ts_utc {_cut} "
                               f"(2025-06-30 21:00 UTC) in column {col}; refused")
    if dated and not released:
        raise MacroIntegrityError(f"{what}: has calendar-day values but no release-time column (*_utc or "
                                  "*_ts) with a value; a day alone cannot show when a row was public")


def _row_latest(df: pd.DataFrame) -> np.ndarray:
    """Each row's latest time in unix seconds over the columns the cutoff check reads (time columns by name and
    whole-cell ISO dates in other text columns; retrieval stamps excluded; a calendar day at 00:00 UTC), or -inf
    for a row with none. Run on a frame that passed _check_rows."""
    out = np.full(len(df), -np.inf)
    epoch = pd.Timestamp(0, tz="UTC")
    for col in df.columns:
        kind = time_kind(col)
        if kind == "meta":
            continue
        s = df[col]
        has = _present(s)
        if not has.any():
            continue
        if kind is None:
            if not _is_text(s):
                continue
            txt = s.where(has).astype("string").str.strip()
            shaped = (has & txt.str.fullmatch(_DATE_SHAPE.pattern).fillna(False)).astype(bool)
            if not shaped.any():
                continue
            sec = (pd.to_datetime(txt.where(shaped), utc=True, format="ISO8601", errors="coerce") - epoch
                   ).dt.total_seconds().to_numpy(float)
        elif kind == "ts":
            sec = pd.to_numeric(s.where(has), errors="coerce").astype("float64").to_numpy(float)
        else:
            sec = (_as_instants(s.where(has)) - epoch).dt.total_seconds().to_numpy(float)
        out = np.fmax(out, np.where(np.isnan(sec), -np.inf, sec))
    return out


def _check_registered(raw: bytes, what: str) -> None:
    """Refuse bytes whose sha256 is a registered price data set (the registry, plus the package's own
    entries, which $FX_DATASETS_JSON cannot remove). Runs on every published blob, README.md too."""
    sha = _sha(raw)
    if sha in _PKG_PRICE_SHAS or sha in {d["sha256"] for d in L.registry().values()}:
        raise FL.PriceFileRefused(f"{what}: is a registered price data set; read it with load_m1 / load_bars")


def _check_not_price(df: pd.DataFrame, raw: bytes, what: str) -> None:
    cols = {str(c).strip().lower() for c in df.columns} | {_norm(c) for c in df.columns}
    if (cols & FL.PRICE_COLS or FL.BAR_COLS <= cols or _OHLC_LONG <= cols
            or any(_PRICE_PREFIX.fullmatch(c) for c in cols)):
        raise FL.PriceFileRefused(f"{what}: has price-bar columns; prices come only from load_m1 / load_bars")
    _check_registered(raw, what)


def _read_table(raw: bytes, what: str) -> pd.DataFrame:
    """Parse a CSV. Refused (MacroIntegrityError): unreadable bytes, a blank header cell, two header cells
    with one name (pandas would rename the second 'x.1'), or a row with more fields than the header
    (pandas would silently make the first column the index)."""
    try:
        head = pd.read_csv(io.BytesIO(raw), header=None, nrows=1, dtype=str, keep_default_na=False,
                           index_col=False)
        with warnings.catch_warnings():
            warnings.simplefilter("error", pd.errors.ParserWarning)
            df = pd.read_csv(io.BytesIO(raw), index_col=False)
    except (ValueError, pd.errors.ParserError, pd.errors.ParserWarning) as e:
        raise MacroIntegrityError(f"{what}: not a readable CSV ({type(e).__name__})") from e
    names = [str(x) for x in head.iloc[0].tolist()] if len(head) else []
    norm = [_norm(x) for x in names]
    if not names or "" in norm or len(set(norm)) != len(norm):
        raise MacroIntegrityError(f"{what}: a blank header cell or two columns with one name; refused")
    if not isinstance(df.index, pd.RangeIndex) or len(df.columns) != len(names):
        raise MacroIntegrityError(f"{what}: rows and header do not line up; refused")
    return df


def _check_blob(name: str, raw: bytes) -> pd.DataFrame | None:
    """The content checks for one published file, run before anything is written; returns the parsed
    table for a CSV. Every blob: not a registered price set. README.md: UTF-8 text of at most
    README_MAX_BYTES. A .csv: the header, price and cutoff checks. Any other name is refused."""
    _check_registered(raw, name)
    if name == README:
        if len(raw) > README_MAX_BYTES:
            raise MacroIntegrityError(f"{README} is {len(raw)} bytes, over {README_MAX_BYTES}; refused")
        try:
            raw.decode("utf-8")
        except UnicodeDecodeError as e:
            raise MacroIntegrityError(f"{README} is not UTF-8 text") from e
        return None
    if not _CSV_RE.fullmatch(name):
        raise MacroIntegrityError(f"{name} is not a .csv table or {README}; refused")
    df = _read_table(raw, name)
    _check_not_price(df, raw, name)
    _check_rows(df, name)
    return df


# ------------------------------------------------------------------------------------- git side
def _ref_listing(repo: Path, full: str) -> tuple[bytes, dict[str, str]] | None:
    raw = L._show(f"{full}:{LISTING}", repo)
    if raw is None:
        if L._ref_exists(full, repo):
            raise MacroIntegrityError(f"{full} has no {LISTING}")
        return None
    return raw, parse_listing(raw)


def _ref_blob(repo: Path, full: str, name: str, sha: str) -> bytes:
    raw = L._show(f"{full}:{name}", repo)
    if raw is None:
        raise MacroIntegrityError(f"{name} is listed in {LISTING} but missing on {full}")
    got = _sha(raw)
    if got != sha:
        raise MacroIntegrityError(f"{full}:{name} sha256 {got} != listed {sha}; refusing")
    return raw


def _pinned_blob(repo: Path, full: str, name: str, sha: str) -> tuple[str, bytes] | None:
    """(commit, bytes) of the newest commit in the history of ``full`` whose SHA256.txt lists ``name``
    with ``sha`` and whose blob hashes to it, or None. ``git rev-list --full-history <ref> -- SHA256.txt``
    (newest first; rev-list prints only ids, and --full-history keeps every commit that changed the
    listing, a merged side branch too). A commit whose listing is malformed, or whose blob does not hash
    to the pin, is skipped. The pin itself proves the bytes, so a forged history cannot change them."""
    r = L._git_run(["rev-list", "--full-history", full, "--", LISTING], repo)
    if r.returncode != 0:
        return None
    for c in r.stdout.decode(errors="replace").split():
        if not _COMMIT_RE.fullmatch(c):
            continue
        raw = L._show(f"{c}:{LISTING}", repo)
        if raw is None:
            continue
        try:
            entries = parse_listing(raw)
        except MacroIntegrityError:
            continue
        if entries.get(name) != sha:
            continue
        blob = L._show(f"{c}:{name}", repo)
        if blob is not None and _sha(blob) == sha:
            return c, blob
    return None


def _write_atomic(dest: Path, name: str, data: bytes) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{name}.", dir=dest)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.replace(tmp, dest / name)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _local_bytes(p: Path) -> bytes | None:
    try:
        return p.read_bytes()
    except (FileNotFoundError, IsADirectoryError, NotADirectoryError):
        return None


def fetch(repo=None, ref: str = DEFAULT_REF) -> Path:
    """Copy every file listed in the published SHA256.txt into <data root>/macro/ and return the
    folder (see the module docstring). Raises MacroNotPublished when origin has no such branch,
    MacroIntegrityError on a sha mismatch, MacroLateRow on a late row; nothing is written then."""
    repo = _repo(repo)
    L.require_internal_caller("macro.fetch", tests_ok=_test_world(repo))
    branch, full = _full_ref(ref)
    if not L._fetch_branch(branch, repo):
        r = L._git_run(["ls-remote", "origin", f"refs/heads/{branch}"], repo)
        if r.returncode == 0:
            if not r.stdout.strip():                  # origin answered: no such branch
                raise MacroNotPublished(f"origin has no branch {branch} (not published yet)")
            raise RuntimeError(f"git fetch origin {branch} failed although origin lists it: "
                               f"{r.stderr.decode(errors='replace').strip()[:200]}")
        if not L._ref_exists(full, repo):
            raise MacroNotPublished(f"cannot reach origin and no local {full}; fetch {branch} online first")
    got = _ref_listing(repo, full)
    if got is None:
        raise MacroNotPublished(f"no {full} in {repo}")
    raw_listing, entries = got
    blobs = {}
    for name, sha in entries.items():                 # verify everything before writing anything
        blobs[name] = _ref_blob(repo, full, name, sha)
        _check_blob(name, blobs[name])
    dest = macro_dir()
    for name, data in blobs.items():
        cur = _local_bytes(dest / name)
        if cur is None or _sha(cur) != entries[name]:
            _write_atomic(dest, name, data)
    _write_atomic(dest, LISTING, raw_listing)
    return dest


def listing(repo=None, ref: str = DEFAULT_REF) -> dict[str, str]:
    """{file name: sha256} of the published package in this checkout's ref (fetches once if the ref
    is missing). A frozen study records it (or the sha of each file it loads) in FROZEN.json."""
    repo = _repo(repo)
    _, full = _full_ref(ref)
    got = _ref_listing(repo, full)
    if got is None:
        fetch(repo, ref)
        got = _ref_listing(repo, full)
        if got is None:
            raise MacroNotPublished(f"no {full} after fetch")
    return dict(got[1])


# ------------------------------------------------------------------------------------- load
def _caller_study() -> tuple[Path, str, str] | None:
    """(study folder, DEPT, study) of the code that called load: the first stack frame outside research/common
    and the Python libraries, an existing file, sitting in research/departments/<DEPT>/<study>/ (a study's module,
    script or tests); None when that first frame is anywhere else."""
    common = Path(__file__).resolve().parent
    libs = L._library_prefixes()
    f = _getframe(1)
    while f is not None:
        cf = f.f_code.co_filename
        if cf.startswith("<") or "/site-packages/" in cf or "/dist-packages/" in cf or any(cf.startswith(x) for x in libs):
            f = f.f_back
            continue
        p = Path(cf).resolve()
        if p == common or common in p.parents:
            f = f.f_back
            continue
        if not p.is_file():
            return None                        # a compile() or exec() with a made-up file name
        parts = p.parts
        for i in range(len(parts) - 1):
            if parts[i] == "research" and parts[i + 1] == "departments":
                return (Path(*parts[:i + 4]), parts[i + 2], parts[i + 3]) if len(parts) - i >= 5 else None
        return None
    return None


def _main_dept() -> str | None:
    """The department whose folder holds the main script, or None (pytest, a tool outside research/departments)."""
    main = A.main_code_path()
    if not main:
        return None
    parts = Path(main).resolve().parts
    for i in range(len(parts) - 2):
        if parts[i] == "research" and parts[i + 1] == "departments":
            return parts[i + 2]
    return None


def _roots() -> tuple[Path, ...]:
    """The checkouts a FROZEN.json may be committed in: the one that holds research/common, and also $FX_REPO_ROOT
    when it points elsewhere (a test world; _pre_window then serves synthetic tables only)."""
    root, repo = L.package_root().resolve(), repo_root().resolve()
    return (root,) if repo == root else (root, repo)


def _repo_rel(path: Path) -> tuple[Path, str] | None:
    """(checkout root, path relative to it), or None unless the git repository that holds path is one of _roots()
    (red team of release 13: a repository made inside a study folder is not one)."""
    top = L._git_run(["rev-parse", "--show-toplevel"], path.parent)
    if top.returncode != 0:
        return None
    root = Path(top.stdout.decode(errors="replace").strip()).resolve()
    if root not in _roots():
        return None
    try:
        return root, path.resolve().relative_to(root).as_posix()
    except ValueError:
        return None


def _published_here(name: str, sha: str) -> bool:
    """True when sha is a version of name that this checkout's data/macro history publishes, or when that cannot be
    told (no ref, a git error): such bytes are the real table, so a redirected $FX_REPO_ROOT gets no window."""
    root = L.package_root().resolve()
    try:
        _, full = _full_ref(DEFAULT_REF)
        if _ref_listing(root, full) is None:
            return True
        return _pinned_blob(root, full, name, sha) is not None
    except Exception:                                # noqa: BLE001  (fail closed)
        return True


def _committed_at_head(path: Path, raw: bytes) -> bool:
    """True when path's bytes equal its blob at HEAD of this checkout."""
    got = _repo_rel(path)
    if got is None:
        return False
    shown = L._git_run(["show", f"HEAD:{got[1]}"], got[0])
    return shown.returncode == 0 and shown.stdout == raw


def _in(p: str, dirs) -> bool:
    return any(p == d or p.startswith(d.rstrip("/") + "/") for d in dirs)


def _stack_ok(folder: Path) -> bool:
    """Red team of release 13: the window is the study's own, so every frame of the call (from load's caller to
    the stack's start) must be a file of that study folder, research/common, or a Python library, and the stack
    must start at the main script, which is a file of that study or pytest (python -m pytest, or pytest's own
    launcher). A STATS test or a script elsewhere that runs a study's code, an exec() or compile() under a study's
    file name, a thread, an atexit or another callback with no caller: no window."""
    common = str(Path(__file__).resolve().parent)
    fold = str(folder.resolve())
    main_mod = sys.modules.get("__main__")
    main = A.main_code_path()
    f, root = _getframe(1), None
    while f is not None:
        if f.f_back is None:
            root = f
            break
        cf = f.f_code.co_filename
        if cf in _FROZEN_FRAMES or (cf.startswith("<frozen ") and cf.endswith(">") and _is_frozen(cf[8:-1])):
            f = f.f_back
            continue
        if not cf.startswith("/"):
            return False
        rp = str(Path(cf).resolve())
        if not Path(rp).is_file() or not (_in(rp, (common, fold)) or _in(rp, _LIB_DIRS)):
            return False
        f = f.f_back
    if root is None:
        return False
    if root.f_code is _RUN_AS_MAIN:                    # python -m <module>: only pytest
        mf = getattr(main_mod, "__file__", None)
        return bool(mf) and _PYTEST_DIR is not None and str(Path(mf).resolve()) == _PYTEST_DIR + "/__main__.py"
    if root.f_code.co_name != "<module>" or main_mod is None or root.f_globals is not vars(main_mod) or not main:
        return False
    rf = Path(root.f_code.co_filename).resolve()
    if rf != Path(main).resolve() or not rf.is_file():
        return False
    if _in(str(rf), (fold,)):
        return True                                    # the study's own script
    try:
        return _PYTEST_DIR is not None and _PYTEST_WRAPPER.fullmatch(rf.read_bytes()) is not None
    except OSError:
        return False


_MISSING = object()


def _amendment(folder: Path, fz: Path, raw: bytes):
    """The study's FROZEN_AMEND.json (STATS ruling 16 Oct 2026 about 4:04 am): (its first_build_decision or _MISSING,
    its sha256, valid) where valid means it names the study's own FROZEN.json ("FROZEN.json" or that file's repo
    path), records that file's exact sha256, and is committed unchanged at HEAD. None when there is no such file."""
    am = folder / "FROZEN_AMEND.json"
    try:
        araw = am.read_bytes()
    except FileNotFoundError:
        return None
    except OSError:
        return _MISSING, None, False
    try:
        adoc = json.loads(araw)
    except ValueError:
        return _MISSING, _sha(araw), False
    if not isinstance(adoc, dict):
        return _MISSING, _sha(araw), False
    rel = _repo_rel(fz)
    names = {"FROZEN.json"} | ({rel[1]} if rel is not None else set())
    named = adoc.get("frozen")
    valid = (type(named) is str and named in names and adoc.get("frozen_sha256") == _sha(raw)
             and _committed_at_head(am, araw))
    return adoc.get("first_build_decision", _MISSING), _sha(araw), valid


def _pre_window(name: str, sha: str) -> dict | None:
    """The PRE look-back this process may read, or None (module docstring: a frozen study's declared look-back)."""
    if os.environ.get(L.LOCKED_RUN_ENV):
        return None
    if len(_roots()) > 1 and _published_here(name, sha):
        return None                            # a test world never gets a window on the real table
    got = _caller_study()
    if got is None or got[1] == "STATS":
        return None
    folder, dept, study = got
    main_dept = _main_dept()
    if main_dept is not None and main_dept != dept:
        return None                            # STATS's code, or another department's, never borrows a window
    if not _stack_ok(folder):
        return None
    fz = folder / "FROZEN.json"
    try:
        raw = fz.read_bytes()
        doc = json.loads(raw)
    except (OSError, ValueError):
        return None
    days = doc.get("history_lookback_days") if isinstance(doc, dict) else None
    first = doc.get("first_build_decision", _MISSING) if isinstance(doc, dict) else _MISSING
    if type(days) is not int or not 1 <= days <= PRE_LOOKBACK_MAX_DAYS:
        return None
    am = _amendment(folder, fz, raw)
    amend_sha = None
    if first is _MISSING:                      # STATS ruling about 4:04 am: else from a matching FROZEN_AMEND.json
        if am is None or not am[2]:
            return None
        first, amend_sha = am[0], am[1]
    elif am is not None and am[0] is not _MISSING and (type(am[0]) is not type(first) or am[0] != first):
        return None                            # the two files disagree on the first BUILD decision
    if type(first) is not int or not E.BUILD_START <= first < E.BUILD_END:
        return None                            # STATS ruling 16 Oct 2026 about 3:44 am: the first BUILD decision
    lo, hi = first - days * _DAY, min(first, E.PRE_END)
    if lo >= hi:
        return None                            # the look-back starts in 2010 or later: no PRE row
    if L.frozen_problems(doc, dept, study) or not _committed_at_head(fz, raw):
        return None
    return {"lo": lo, "hi": hi, "dept": dept, "study": study, "days": days, "first_build_decision": first,
            "frozen_sha256": _sha(raw), "frozen_amend_sha256": amend_sha}


def _row_earliest(df: pd.DataFrame) -> np.ndarray:
    """Each row's earliest time in unix seconds over the same columns as _row_latest (an observation date or a
    release time); -inf for a row with none, so a row without a time counts as PRE."""
    out = np.full(len(df), np.inf)
    epoch = pd.Timestamp(0, tz="UTC")
    for col in df.columns:
        kind = time_kind(col)
        if kind == "meta":
            continue
        s = df[col]
        has = _present(s)
        if not has.any():
            continue
        if kind is None:
            if not _is_text(s):
                continue
            txt = s.where(has).astype("string").str.strip()
            shaped = (has & txt.str.fullmatch(_DATE_SHAPE.pattern).fillna(False)).astype(bool)
            if not shaped.any():
                continue
            sec = (pd.to_datetime(txt.where(shaped), utc=True, format="ISO8601", errors="coerce") - epoch
                   ).dt.total_seconds().to_numpy(float)
        elif kind == "ts":
            sec = pd.to_numeric(s.where(has), errors="coerce").astype("float64").to_numpy(float)
        else:
            sec = (_as_instants(s.where(has)) - epoch).dt.total_seconds().to_numpy(float)
        out = np.fmin(out, np.where(np.isnan(sec), np.inf, sec))
    out[np.isinf(out) & (out > 0)] = -np.inf
    return out


def _iso_of(ts: int) -> str:
    """Unix seconds as 'YYYY-MM-DDTHH:MM:SSZ' by integer arithmetic only (days to civil date, H. Hinnant)."""
    d, s = divmod(ts, _DAY)
    z = d + 719468
    era = z // 146097
    doe = z - era * 146097
    yoe = (doe - doe // 1460 + doe // 36524 - doe // 146096) // 365
    doy = doe - (365 * yoe + yoe // 4 - yoe // 100)
    mp = (5 * doy + 2) // 153
    day, month = doy - (153 * mp + 2) // 5 + 1, mp + 3 if mp < 10 else mp - 9
    year = yoe + era * 400 + (month <= 2)
    if not 1 <= year <= 9999:
        raise MacroIntegrityError("a time outside the years 0001-9999")
    return f"{year:04d}-{month:02d}-{day:02d}T{s // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}Z"


def _secs_of(iso: str) -> int:
    """The inverse of _iso_of (days from civil date)."""
    y, m, d = int(iso[0:4]), int(iso[5:7]), int(iso[8:10])
    y -= m <= 2
    era = y // 400
    yoe = y - era * 400
    doy = (153 * (m - 3 if m > 2 else m + 9) + 2) // 5 + d - 1
    days = era * 146097 + yoe * 365 + yoe // 4 - yoe // 100 + doy - 719468
    return days * _DAY + int(iso[11:13]) * 3600 + int(iso[14:16]) * 60 + int(iso[17:19])


_PRE_ISO = _iso_of(E.PRE_END)
if _PRE_ISO != "2010-01-01T00:00:00Z":
    raise ImportError("research.common.eras.PRE_END was changed")


def _iso_value(v: str, kind, what: str) -> str:
    """One time cell of a PRE-locked table as 'YYYY-MM-DDTHH:MM:SSZ' (UTC; fractions of a second dropped, so the
    value is never later than the cell): a day, a month, an instant with Z, +00:00 or no zone, or unix seconds for
    a 'ts' column. Any other shape refuses the table (MacroIntegrityError), so the gate never guesses."""
    shape = v.translate(_DIGITS)
    if kind == "ts":
        body = v[1:] if v[:1] == "-" else v
        if body and body.translate(_DIGITS) == "9" * len(body):
            return _iso_of(int(v))
        raise MacroIntegrityError(f"{what}: a unix-seconds cell the PRE gate cannot read; refused")
    if shape == "9999-99":
        return v + "-01T00:00:00Z"
    if shape == "9999-99-99":
        return v + "T00:00:00Z"
    head, sep, rest = v[:10], v[10:11], v[11:]
    if shape[:10] == "9999-99-99" and sep in ("T", " "):
        clock = rest.translate(_DIGITS)
        for zone in ("Z", "+00:00", "+0000", ""):
            if zone and not rest.endswith(zone):
                continue
            core = clock[:len(clock) - len(zone)] if zone else clock
            raw = rest[:len(rest) - len(zone)] if zone else rest
            if core == "99:99":
                return f"{head}T{raw}:00Z"
            if core == "99:99:99":
                return f"{head}T{raw}Z"
            if core[:9] == "99:99:99." and core[9:] and core[9:] == "9" * len(core[9:]):
                return f"{head}T{raw[:8]}Z"
    raise MacroIntegrityError(f"{what}: a time cell in a shape the PRE gate cannot read; refused")


def _pre_gate(name: str, data: bytes, pre_rows) -> dict:
    """The PRE lock on a PRE_LOCKED table's published bytes, before pandas reads them (red team of release 13): a
    record is PRE when its earliest time (over the same columns _row_earliest reads; a blank calendar-day cell or
    no time at all counts as PRE) is before 2010-01-01; PRE records are dropped unless they are in the caller's
    window (module docstring). Returns the bytes to parse (the header and the kept records, line for line), the
    counts and the window. Raises MacroPreLocked when PRE records exist, no window applies and pre_rows is not
    'exclude'."""
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as e:
        raise MacroIntegrityError(f"{name}: not UTF-8; refused") from e
    if text[:1] == "\ufeff":
        raise MacroIntegrityError(f"{name}: a byte-order mark; refused")
    pieces = text.split("\n")
    lines = [x + "\n" for x in pieces[:-1]] + ([pieces[-1]] if pieces[-1] else [])
    rd = _csv_reader(iter(lines), delimiter=",", quotechar='"', doublequote=True, escapechar=None,
                     skipinitialspace=False, strict=True, quoting=0)
    recs, prev = [], 0
    try:
        for row in rd:
            if row:
                recs.append((row, prev, rd.line_num))
            prev = rd.line_num
    except _csv.Error as e:
        raise MacroIntegrityError(f"{name}: not a readable CSV ({type(e).__name__}); refused") from e
    if not recs:
        raise MacroIntegrityError(f"{name}: no header; refused")
    header = recs[0][0]
    cols = [(k, time_kind(h)) for k, h in enumerate(header)]
    cols = [(k, kind) for k, kind in cols if kind != "meta"]
    keep, held, allowed, pre_iso = [], 0, [], []
    states = []
    for row, a, b in recs[1:]:
        if len(row) != len(header):
            raise MacroIntegrityError(f"{name}: rows and header do not line up; refused")
        vals, blank_day = [], False
        for k, kind in cols:
            v = row[k].strip()
            if not v:
                blank_day = blank_day or kind == "day"
                continue
            if kind is None:
                if _DATE_SHAPE.fullmatch(v) is None:
                    continue
            vals.append(_iso_value(v, kind, name))
        first = "" if blank_day or not vals else min(vals)
        states.append((first < _PRE_ISO, first, a, b))
    win = _pre_window(name, _sha(data)) if pre_rows != "exclude" and any(s[0] for s in states) else None
    if win is None and pre_rows != "exclude" and any(s[0] for s in states):
        raise MacroPreLocked(f"{name}: {sum(1 for s in states if s[0])} rows before 2010-01-01 (era PRE) are locked "
                             "until STATS rules on PRE (eras.PRE_OPEN); load(..., pre_rows='exclude') reads the table "
                             "without them, or read from a study whose committed FROZEN.json records "
                             f"history_lookback_days (1 to {PRE_LOOKBACK_MAX_DAYS}) and first_build_decision (ts_utc "
                             "inside BUILD; or a matching committed FROZEN_AMEND.json) with a look-back that starts "
                             "before 2010-01-01, run as the study's own script or under python -m pytest from its tests")
    lo, hi = (_iso_of(win["lo"]), _iso_of(win["hi"])) if win is not None else ("", "")
    out = lines[recs[0][1]:recs[0][2]]
    for is_pre, first, a, b in states:
        if is_pre and not (win is not None and lo <= first < hi):
            held += 1
            continue
        if is_pre:
            allowed.append(first)
        out.extend(lines[a:b])
    return {"bytes": "".join(out).encode("utf-8"), "records": len(states), "kept": len(states) - held,
            "held": held, "allowed": allowed, "win": win}


def _pre_verify(name: str, df: pd.DataFrame, sha: str, gate: dict) -> pd.DataFrame:
    """Second check of the PRE gate on the parsed table (any served PRE row must be inside the window the gate
    used, and no more of them than it allowed; else MacroIntegrityError), then the withheld count and the log."""
    win = gate["win"]
    first = _row_earliest(df)
    pre = first < E.PRE_END
    n = int(pre.sum())
    ok = n == 0 if win is None else (n <= len(gate["allowed"]) and bool(
        ((first[pre] >= win["lo"]) & (first[pre] < win["hi"])).all()))
    if not ok:
        raise MacroIntegrityError(f"{name}: the PRE gate and the parsed table disagree; read refused")
    df.attrs["pre_rows_withheld"] = gate["held"]
    if win is not None:
        got = sorted(gate["allowed"])
        A.log_access(win["dept"], win["study"], "BUILD", _secs_of(got[0]) if got else None,
                     _secs_of(got[-1]) if got else None, A.code_sha256_of_main(), win["frozen_sha256"],
                     kind="macro_pre_lookback", series=name, sha256=sha, pre_window=[win["lo"], win["hi"]],
                     first_build_decision=win["first_build_decision"], frozen_amend_sha256=win["frozen_amend_sha256"],
                     lookback_days=win["days"], rows=len(got), withheld=gate["held"], rows_era="PRE",
                     common_sha256=A.common_sha256())
    return df


def load(name: str, columns=None, *, sha256: str | None = None, repo=None,
         ref: str = DEFAULT_REF, frozen=None, pre_rows: str | None = None) -> pd.DataFrame:
    """One published CSV as a DataFrame (see the module docstring for every check). With ``sha256=``
    (the pin a frozen study recorded) the bytes with that sha are served: the tip's copy when the tip
    still publishes it, else the newest commit of the branch history that published it (after DATA
    republishes, a pinned study keeps its version); a pin that no commit published raises
    MacroIntegrityError. Without a pin, the tip of the checkout's ref is served. ``frozen=`` (a FROZEN.json path,
    passed by STATS's locked runner) checks the pin against that FROZEN's data/macro pins (release 5).
    ``pre_rows="exclude"`` reads a PRE-locked table without its rows before 2010-01-01 (module docstring)."""
    if not isinstance(name, str):
        raise TypeError("name is a file name such as 'meetings.csv'")
    name = str.__str__(name)                   # a plain str: a subclass's __eq__ or __hash__ cannot dodge PRE_LOCKED
    if pre_rows is not None and (type(pre_rows) is not str or pre_rows != "exclude"):
        raise ValueError("pre_rows is None or 'exclude'")
    pin = None
    if sha256 is not None:
        if not isinstance(sha256, str) or not _SHA_RE.fullmatch(sha256.strip().lower()):
            raise ValueError("sha256 is the 64-hex sha256 of the file, as listing() gives it")
        pin = sha256.strip().lower()
    repo = _repo(repo)
    _, full = _full_ref(ref)
    got = _ref_listing(repo, full)
    if got is None:
        fetch(repo, ref)
        got = _ref_listing(repo, full)
        if got is None:
            raise MacroNotPublished(f"no {full} after fetch")
    raw_listing, entries = got
    if name in entries and not _CSV_RE.fullmatch(name):
        raise ValueError(f"{name} is not a table; load reads the listed .csv files")
    if pin is not None and entries.get(name) != pin:
        if not _CSV_RE.fullmatch(name):
            raise KeyError(f"{name!r} is not a published .csv name")
        found = _pinned_blob(repo, full, name, pin)
        if found is None:
            raise MacroIntegrityError(f"{name}: pinned sha256 {pin} is published by no commit of {full} "
                                      f"(its tip publishes {entries.get(name, 'no such file')})")
        data = found[1]
        checked = _check_blob(name, data)            # the old version passes today's checks too
    else:
        if name not in entries:
            raise KeyError(f"{name!r} is not listed in the published {LISTING} ({', '.join(sorted(entries))})")
        want = entries[name]
        dest = macro_dir()
        data, checked = _local_bytes(dest / name), None
        if data is None or _sha(data) != want:
            data = _ref_blob(repo, full, name, want)
            checked = _check_blob(name, data)
            _write_atomic(dest, name, data)
        if _local_bytes(dest / LISTING) != raw_listing:
            _write_atomic(dest, LISTING, raw_listing)
    gate = _pre_gate(name, data, pre_rows) if name in PRE_LOCKED and E.PRE_OPEN is not True else None
    if checked is not None:
        df = checked                                 # parsed and checked from these very bytes
    else:
        df = _read_table(data, name)                 # parsed from the bytes that were hashed
        _check_not_price(df, data, name)
        _check_rows(df, name)
    if gate is not None:                             # the table is served from the gate's bytes only
        if len(df) != gate["records"]:
            raise MacroIntegrityError(f"{name}: the PRE gate and pandas count different rows; refused")
        df = _read_table(gate["bytes"], name)
        _check_rows(df, name)
        if len(df) != gate["kept"]:
            raise MacroIntegrityError(f"{name}: the PRE gate's bytes parse to a different row count; refused")
    # Inside a C, T or locked run (STATS macro-series rule, a0f8738f): the file must be pinned, only rows whose
    # latest time is at or before the run's era end are served, and the read is logged (L.macro_read). Release 5:
    # the same in a process that runs an open C or T look's code without a gated read of its own, and the pin must
    # be the one the look's FROZEN.json gives the file (L.macro_read refuses otherwise).
    if L.current_runs() and pin is None:
        raise MacroIntegrityError(f"{name}: a C, T or locked run reads macro files pinned by sha256 "
                                  "(load(name, sha256=<the pin its FROZEN.json records>))")
    keep = L.macro_read(name, _sha(data), _row_latest(df), pinned=pin is not None, frozen=frozen)
    if not keep.all():
        df = df[keep].reset_index(drop=True)
    if gate is not None:
        df = _pre_verify(name, df, _sha(data), gate)
    for col in df.columns:
        kind, s = time_kind(col), df[col]
        if kind in ("instant", "meta") and "utc" in _tokens(col):
            has = _present(s)
            t = _as_instants(s.where(has))
            if not (has & t.isna()).any():           # a retrieval stamp that does not parse stays text
                df[col] = t.dt.as_unit("us")
        elif kind == "ts" and pd.api.types.is_numeric_dtype(s.dtype) and not pd.api.types.is_bool_dtype(s.dtype):
            if (s.dropna() % 1 == 0).all():
                df[col] = s.astype("Int64")
    if columns is not None:
        cols = [columns] if isinstance(columns, str) else list(columns)
        missing = [c for c in cols if c not in df.columns]
        if missing:
            raise KeyError(f"{name} has no column(s) {missing}")
        df = df[cols].copy()
    return df


# ------------------------------------------------------------------------------------- release_ts
def release_ts(df: pd.DataFrame, col: str) -> np.ndarray:
    """int64 unix seconds of df[col] (see the module docstring); raises ValueError on a calendar-day
    column (time_kind 'day': asof_date, effective_date, period ...), a missing value, a naive datetime,
    a date without a time or offset, or a fractional or boolean number."""
    if col not in df.columns:
        raise KeyError(f"no column {col!r}")
    if time_kind(col) == "day":
        raise ValueError(f"{col} is a calendar-day column; a date is not a release time (use the file's "
                         "*_utc release column)")
    s = df[col]
    if isinstance(s.dtype, pd.DatetimeTZDtype):
        if s.isna().any():
            raise ValueError(f"{col}: {int(s.isna().sum())} missing value(s); drop or fill them first")
        return np.asarray(pd.DatetimeIndex(s.dt.tz_convert("UTC")).as_unit("s").asi8, dtype=np.int64)
    if pd.api.types.is_datetime64_dtype(s.dtype):
        raise ValueError(f"{col}: naive datetimes (no time zone); release times must be UTC-aware")
    if pd.api.types.is_bool_dtype(s.dtype):
        raise ValueError(f"{col}: booleans are not times")
    if pd.api.types.is_numeric_dtype(s.dtype):
        if s.isna().any():
            raise ValueError(f"{col}: {int(s.isna().sum())} missing value(s); drop or fill them first")
        if pd.api.types.is_integer_dtype(s.dtype):
            return s.to_numpy(dtype=np.int64)
        a = s.to_numpy(dtype=np.float64)
        if (~np.isfinite(a) | (a % 1 != 0)).any():
            raise ValueError(f"{col}: unix seconds must be whole numbers")
        return a.astype(np.int64)
    has = _present(s)
    if (~has).any():
        raise ValueError(f"{col}: {int((~has).sum())} missing value(s); drop or fill them first")
    text = s.astype("string")
    ok = text.str.fullmatch(_INSTANT_TEXT.pattern)
    if not ok.all():
        raise ValueError(f"{col}: {int((~ok).sum())} value(s) are not an ISO time with a UTC offset "
                         "(a calendar date is not a release time)")
    t = pd.to_datetime(text.str.strip(), utc=True, format="ISO8601", errors="coerce")
    if t.isna().any():
        raise ValueError(f"{col}: {int(t.isna().sum())} value(s) do not parse")
    return np.asarray(pd.DatetimeIndex(t).as_unit("s").asi8, dtype=np.int64)


# ------------------------------------------------------------------------------------- rate_fn
def _ts_seconds(ts) -> int:
    if isinstance(ts, (bool, np.bool_)):
        raise TypeError("ts is unix seconds, not a boolean")
    if isinstance(ts, (pd.Timestamp, datetime)):
        if ts.tzinfo is None:
            raise ValueError("ts datetime has no time zone")
        return int((pd.Timestamp(ts) - pd.Timestamp(0, tz="UTC")) // pd.Timedelta(seconds=1))
    if isinstance(ts, (int, np.integer)):
        return int(ts)
    if isinstance(ts, (float, np.floating)):
        f = float(ts)
        if not np.isfinite(f) or f != int(f):
            raise ValueError(f"ts must be whole unix seconds, got {ts!r}")
        return int(f)
    raise TypeError(f"ts must be unix seconds (int) or a tz-aware datetime, got {type(ts).__name__}")


def _days(s: pd.Series, col: str) -> np.ndarray:
    t = _as_instants(s.where(_present(s)))
    if t.isna().any():
        raise ValueError(f"{col}: {int(t.isna().sum())} value(s) are missing or not a date")
    sec = np.asarray(pd.DatetimeIndex(t).as_unit("s").asi8, dtype=np.int64)
    if (sec % _DAY != 0).any():
        raise ValueError(f"{col}: values must be calendar dates (00:00 UTC)")
    return sec // _DAY


class _Rates:
    """rate(ccy, ts): see rate_fn. Per currency: sorted day numbers, known-from times and rates."""

    def __init__(self, df: pd.DataFrame):
        need = ("ccy", "effective_date", "rate")
        miss = [c for c in need if c not in df.columns]
        if miss:
            raise KeyError(f"rate_fn needs columns {list(need)} (policy_rates_daily.csv); missing {miss}")
        if len(df) == 0:
            raise ValueError("rate_fn: empty table")
        ccy = df["ccy"].astype("string").str.strip().str.upper()
        if ccy.isna().any() or (ccy == "").any():
            raise ValueError("rate_fn: a row with no ccy")
        day = _days(df["effective_date"], "effective_date")
        known = (day + 1) * _DAY                                   # fallback: 00:00 UTC the next day
        if "release_utc_latest" in df.columns:
            s = df["release_utc_latest"]
            has = _present(s)
            if has.any():
                if pd.api.types.is_numeric_dtype(s.dtype) and not isinstance(s.dtype, pd.DatetimeTZDtype):
                    raise ValueError("release_utc_latest must be ISO text or a UTC datetime")
                t = _as_instants(s.where(has))
                bad = has & t.isna()
                if bad.any():
                    raise ValueError(f"release_utc_latest: {int(bad.sum())} value(s) do not parse")
                sec = np.full(len(df), -1, dtype=np.int64)
                ok = t.notna().to_numpy()
                sec[ok] = pd.DatetimeIndex(t[ok]).as_unit("s").asi8
                known = np.where(ok, sec, known)
        rate = pd.to_numeric(df["rate"], errors="coerce").to_numpy(dtype=np.float64)
        bad = _present(df["rate"]).to_numpy() & np.isnan(rate)
        if bad.any():
            raise ValueError(f"rate: {int(bad.sum())} non-numeric value(s)")
        self._by: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
        cc = ccy.to_numpy(dtype=object)
        for c in pd.unique(cc):
            m = cc == c
            o = np.argsort(day[m], kind="stable")
            d, k, r = day[m][o], known[m][o], rate[m][o]
            if (np.diff(d) == 0).any():
                raise ValueError(f"rate_fn: {c} has two rows for one effective_date")
            for a in (d, k, r):
                a.setflags(write=False)
            self._by[str(c)] = (d, k, r)
        self.coverage = {c: (str(np.datetime64(int(v[0][0]), "D")), str(np.datetime64(int(v[0][-1]), "D")))
                         for c, v in self._by.items()}

    def __call__(self, ccy, ts) -> float:
        t = _ts_seconds(ts)
        key = str(ccy).strip().upper()
        got = self._by.get(key)
        if got is None:
            raise RateMissing(f"no policy rate for {ccy!r} (have {sorted(self._by)})")
        d, k, r = got
        day = t // _DAY
        i = int(np.searchsorted(d, day, side="left"))
        if i >= len(d) or d[i] != day:
            raise RateMissing(f"{key}: no row for {np.datetime64(int(day), 'D')} "
                              f"(table covers {self.coverage[key][0]} to {self.coverage[key][1]})")
        j = i
        while j >= 0 and k[j] >= t:                  # the level in force today is not public yet
            j -= 1
        if j < 0:
            raise RateMissing(f"{key}: no level announced before ts {t}")
        v = r[j]
        if np.isnan(v):
            raise RateMissing(f"{key}: no policy-rate target on {np.datetime64(int(d[j]), 'D')} "
                              "(empty rate in the table)")
        return float(v)


def rate_fn(df_daily: pd.DataFrame | None = None):
    """A callable ``rate(ccy, ts) -> float``: the policy rate in % a year in force on the UTC
    calendar day of ``ts``, counting only levels announced before ``ts`` (no look-ahead).

    ``df_daily`` is policy_rates_daily.csv (one row per currency per calendar day: ccy,
    effective_date, rate and, if present, release_utc_latest); None loads it with ``load``. Each row
    is usable from its ``release_utc_latest`` (the conservative time the level in force that day was
    public), or, where that is empty or the column is absent, from 00:00 UTC of the day AFTER its
    effective_date, so such a row is never used on its own day. For ``ts``, take the row of
    ts's UTC day; while that row is not yet usable at ts (``release >= ts``: a level announced later
    that day, or later), step back to the previous day's row. So:
      - a change announced before ts but in force only from a later day is not returned early;
      - a same-day change is returned only after its release time;
      - the result never depends on anything released at or after ts.
    Raises RateMissing for an unknown currency, a day outside the table (or a gap in it), no usable
    row, or an empty rate (the bank had no target that day, e.g. JPY Apr 2013 - Feb 2016). ``ccy``
    is matched case-insensitively ("EUR" is the deposit facility rate; "EUR_MRO" is also listed in
    the file). ``ts`` is whole unix seconds or a tz-aware datetime. The callable's ``coverage`` maps
    each currency to its first and last day. This is the ``rate`` argument of COST's
    ``financing_rows``; the date of a 17:00 New York roll is its UTC date (21:00 or 22:00 UTC)."""
    if df_daily is None:
        df_daily = load("policy_rates_daily.csv", columns=["ccy", "effective_date", "rate",
                                                           "release_utc_latest"])
    return _Rates(df_daily)


__all__ = ["fetch", "load", "listing", "release_ts", "rate_fn", "macro_dir", "parse_listing", "time_kind",
           "MacroNotPublished", "MacroIntegrityError", "MacroLateRow", "RateMissing", "CUTOFF_TS",
           "DEFAULT_REF"]


# research.common.macro under the loaders' runtime guard (red team, 14 Oct 2026): a changed attribute of this
# module (its checks, L, _row_latest ...) refuses every read, as the loaders' own attributes do
L._guard_add((__name__, globals(), __file__, frozenset()))
