"""Bar simulator: market, limit and stop entries on 1-minute bid/ask bars, with the repo's
pessimistic fill rules (research/round4 r4_engine/r4_spec, Round 45 r45._exit_scan, Round 57
owner_rules.simulate_limit / exit_scan):

Entries (at the first bar opening at or after decision_ts; the order never reads a bar of a later
era than its decision, docs/EDGE_HUNT.md section 3):
  - market: the first bar opening within market_max_delay_s (default 300 s) of the decision; a long
    buys at that bar's ASK open, a short sells at its BID open (mid = mid open). Otherwise void.
  - limit at L: a long fills only when a bar's ASK low trades THROUGH L by through_pips (default
    0.1 pip: ask_l <= L - 0.1 pip); a short when BID high >= L + 0.1 pip. Fill at L (also when the
    bar opens beyond L), mid = L (Round 57). A limit already marketable at the decision (long L at or
    above the ask close of the last bar closed by the decision; short at or below the bid close) is
    rejected: the broker would not rest it (Round 23 limit_through_market).
  - stop at X: a long triggers when ASK high >= X and fills at max(X, ask open) (a gap fills worse);
    a short when BID low <= X, at min(X, bid open). Already through at the decision: rejected.
  Limit and stop orders live until min(cancel_ts, exit_ts) (bars opening before it).
Exits:
  - a long's stop S is hit when BID low <= S and fills at min(S, bid open) (a gap fills at the open);
    a short's when ASK high >= S, at max(S, ask open). Mid fill: min(S, mid open) / max(S, mid open).
  - a long's target T is hit when BID high >= T, a short's when ASK low <= T; fill at T (also on a
    gap beyond T), mid = T.
  - a stop and a target in the same bar count as the stop;
  - in the fill bar a stop touch counts (stopped in the fill bar); a target touch does not, unless
    target_in_fill_bar=True (Round 45 market entries scanned the entry bar for both).
  - time exit at exit_ts: time_exit_mode 'open_after' = the open of the first bar at or after
    exit_ts (bid for a long, ask for a short), stops and targets checked on the bars before it;
    'close_before' = the close of the last bar closing by exit_ts (Round 4 Part C).
  - cut: a position still open at its decision era's last bar is closed at that bar's bid (long) or
    ask (short) close and flagged cut (eras.cut_at_era_end). If the loaded data ends earlier (the
    market reopens before the era ends after the last loaded bar), the same at the last loaded
    bar, exit_reason 'data_end' (also cut=True).
  - with time_exit_mode='open_after' and exit_max_delay_s=None (the default), an exit_ts in the
    weekend close exits at the Sunday open and carries the weekend gap. Intraday rules that must
    be flat by Friday should set exit_ts before the close, or exit_max_delay_s.
Fill slippage: ``fill_slip`` (pips, by 'market_entry', 'stop_entry', 'stop_exit', 'time_exit',
'cut') moves the bid/ask fills against the trade. Default all 0: COST's model adds its own
slippage (market, stop, time and cut fills) in the cost hook, so fill_slip is refused with any cost
hook but LegacyFloor; pass it only to reproduce older rounds (0.2 pip).
Cost: ``cost.round_trip`` (research.common.cost) -> cost_pips, with the order's decision_ts, its
optional signal_ts (when the signal was taken, at or before decision_ts; both pay a 16:55-17:15
New York or release window) and the exit fill time (a 'close' exit fills at the bar's close); net_pips = pips_mid - cost_pips -
fin_pips; spread_paid = pips_mid - pips_ba. Financing: ``financing`` hook over the 17:00 NY rolls
held (research.common.sim_daily). Both are required arguments, so nobody forgets them.

R: r_pips = |entry fill - stop| (stop as a price, or stop_dist from the fill); R columns are NaN
without a stop. A stop at or beyond the fill (d <= 0) gives status 'skip_beyond'.

Orders: a DataFrame with decision_ts (unix s) and side (+1/-1), and optionally kind ('market',
'limit', 'stop'; default market), level (limit/stop price), stop, stop_dist, target, target_r,
exit_ts, cancel_ts, order_id, w, pair. Output: one row per order with a status ('filled',
'void_no_entry', 'rejected_marketable', 'expired', 'skip_beyond', 'skip_target', 'void_no_exit',
'void_no_time') and, for filled rows, entry/exit times, prices, pips, R, exit reason and cut flag.

Bar length: 1-minute bars only (audit findings #19 and #30). ``Bars`` carries ``bar_seconds``
(from_frame's ``granularity`` or ``bar_seconds``, else the smallest step between bar opens; 60 for a
single bar) and ``simulate`` refuses any bars that sim_daily.require_m1 does not accept as M1: on a
longer bar a fill, stop or target inside the bar has no known time, COST's 16:55-17:15 window and
the 17:00 New York roll can fall inside one bar, and the marketable check, 'close_before' exits and
close-exit times would read a bar that had not closed when the decision or exit was made. Every
"last bar closed by t" below is bar open <= t - bar_seconds, and the cost hook gets
bar_sec=bar_seconds. Pass the whole loaded M1 frame: a short slice of M1 with missing minutes (the
Sunday open, holidays) can look like longer bars and is accepted only with granularity='M1' stated
(require_m1's rule). Bars keeps ts as a read-only int64 copy, so require_m1's pass is cached on it
and a loop of simulate calls on one Bars pays the check once.

Prices are used as float64 internally. The loop is a plain Python loop over orders with numpy
first-hit searches on each order's bar slice (no numba).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from . import eras as E
from . import cost as _cost
from .cost import pip_size
from .sim_daily import DEFAULT_CALENDAR, M1_SECONDS, financing_pips, require_m1, ts_steps

SLIP_KEYS = ("market_entry", "stop_entry", "stop_exit", "time_exit", "cut")
OUT_COLS = ["order_id", "pair", "side", "kind", "w", "status", "decision_ts", "signal_ts", "era", "entry_i",
            "entry_ts", "entry_fill", "entry_mid", "stop", "target", "r_pips", "exit_i", "exit_ts",
            "exit_at", "exit_time", "exit_fill", "exit_mid", "exit_reason", "cut", "entry_kind",
            "exit_kind", "pips_ba", "pips_mid", "spread_paid", "cost_pips", "fin_pips", "net_pips",
            "R_ba", "R_mid", "net_R", "fin_rolls"]
# bar length of a granularity name (research/common/datasets.json granularities, and resample_m1's D17NY)
GRANULARITY_SECONDS = {"M1": 60, "M5": 300, "M15": 900, "M30": 1800, "H1": 3600, "H4": 14400,
                       "D": 86400, "D17NY": 86400}


@dataclass
class Bars:
    """Bid/ask bars of one pair as float64 numpy arrays (ts = bar open, unix s; kept as a read-only
    int64 copy). ``bar_seconds``: the bar length; None infers it from the smallest step between bar
    opens (60 with fewer than two bars). simulate and sim_daily accept M1 bars only
    (sim_daily.require_m1)."""
    pair: str
    ts: np.ndarray
    bo: np.ndarray
    bh: np.ndarray
    bl: np.ndarray
    bc: np.ndarray
    ao: np.ndarray
    ah: np.ndarray
    al: np.ndarray
    ac: np.ndarray
    pip: float = 1e-4
    bar_seconds: int | None = None
    _vol: np.ndarray | None = field(default=None, repr=False)
    _bar_seconds_inferred: bool = field(default=False, init=False, repr=False, compare=False)
    _m1_ok: tuple | None = field(default=None, init=False, repr=False, compare=False)

    def __post_init__(self):
        t = np.array(self.ts)                             # an owned copy: require_m1 caches its pass
        if t.dtype.kind == "f":
            if not np.all(np.isfinite(t)) or np.any(t != np.floor(t)):
                raise ValueError("ts must be whole unix seconds")
        elif t.dtype.kind not in "iu" and t.size:
            raise ValueError(f"ts must be whole unix seconds, not dtype {t.dtype}")
        t = t.astype(np.int64, copy=False)
        t.flags.writeable = False
        self.ts = t
        self._bar_seconds_inferred = self.bar_seconds is None
        if self.bar_seconds is None:
            smallest, _ = ts_steps(self.ts)
            self.bar_seconds = smallest if smallest is not None else M1_SECONDS
        b = self.bar_seconds
        if isinstance(b, bool) or not isinstance(b, (int, np.integer)) or int(b) <= 0:
            raise ValueError(f"bar_seconds must be a positive whole number of seconds, not {b!r}")
        self.bar_seconds = int(b)

    @classmethod
    def from_frame(cls, df: pd.DataFrame, pair: str, granularity: str | None = None,
                   bar_seconds: int | None = None) -> "Bars":
        """granularity ('M1', 'H1', ...; GRANULARITY_SECONDS) or bar_seconds states the bar length;
        neither: inferred from ts_utc (Bars)."""
        ts = df["ts_utc"].to_numpy(np.int64)
        if len(ts) > 1 and not np.all(np.diff(ts) > 0):
            raise ValueError("bars must be sorted by ts_utc with no duplicates")
        if granularity is not None:
            g = str(granularity).upper()
            if g not in GRANULARITY_SECONDS:
                raise ValueError(f"unknown granularity {granularity!r}; expected {sorted(GRANULARITY_SECONDS)}")
            if bar_seconds is not None and int(bar_seconds) != GRANULARITY_SECONDS[g]:
                raise ValueError(f"granularity {g} is {GRANULARITY_SECONDS[g]} s, not bar_seconds={bar_seconds}")
            bar_seconds = GRANULARITY_SECONDS[g]
        f = {c: df[c].to_numpy(np.float64) for c in
             ("bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")}
        return cls(pair, ts, f["bid_o"], f["bid_h"], f["bid_l"], f["bid_c"], f["ask_o"], f["ask_h"],
                   f["ask_l"], f["ask_c"], pip_size(pair), bar_seconds)

    def __len__(self):
        return len(self.ts)

    @property
    def mo(self):
        return (self.bo + self.ao) / 2

    @property
    def mc(self):
        return (self.bc + self.ac) / 2

    @property
    def vol(self) -> np.ndarray:
        if self._vol is None:
            # COST's volatility level (research/departments/COST/cost.py vol_from_mid_close): it bins the
            # floors, so it is COST's definition, not this module's
            self._vol = _cost.vol_from_mid_close(self.ts, self.mc, self.pip)
        return self._vol


def _next_open(t: int) -> int:
    """t, or the Sunday 17:00 New York reopen when t falls in the weekly close (Fri 17:00 - Sun
    17:00 New York)."""
    x = pd.Timestamp(int(t), unit="s", tz="UTC").tz_convert("America/New_York")
    dow, h = x.dayofweek, x.hour
    if (dow == 4 and h >= 17) or dow == 5 or (dow == 6 and h < 17):
        from .sim_daily import roll_ts                     # 17:00 New York on a date, DST-aware
        return roll_ts(x.date() + pd.Timedelta(days=int(6 - dow)).to_pytimedelta())
    return int(t)


def _first(mask: np.ndarray) -> int:
    return int(np.argmax(mask)) if mask.size and mask.any() else -1


def _get(o, k, default=np.nan):
    v = o.get(k, default)
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return default
    return v


def simulate(bars: Bars, orders: pd.DataFrame, *, cost, financing, calendar=None,
             through_pips: float = 0.1, market_max_delay_s: int = 300, exit_max_delay_s=None,
             target_in_fill_bar: bool = False, time_exit_mode: str = "open_after",
             fill_slip: dict | None = None, reject_marketable: bool = True,
             freezing: bool = False) -> pd.DataFrame:
    """Simulate orders on one pair's M1 bars. See the module docstring for every rule."""
    bs = require_m1(bars, "sim_bar.simulate")               # 60: the bar length every rule below uses
    if time_exit_mode not in ("open_after", "close_before"):
        raise ValueError("time_exit_mode must be 'open_after' or 'close_before'")
    slip = {k: 0.0 for k in SLIP_KEYS}
    for k, v in (fill_slip or {}).items():
        if k not in slip:
            raise KeyError(f"fill_slip key {k!r}; expected {SLIP_KEYS}")
        slip[k] = float(v)
    if any(slip.values()) and not isinstance(cost, _cost.LegacyFloor):
        # COST's model adds the fill slippage (EDGE_HUNT 4.3: fills at bid/ask plus COST's slippage);
        # the simulator's own fill_slip would charge it twice. It reproduces older rounds only.
        raise ValueError("fill_slip is for parity runs with LegacyFloor only; COST's cost model already "
                         "charges fill slippage")
    P = bars.pip
    sl = {k: v * P for k, v in slip.items()}
    thr = through_pips * P
    ts = bars.ts
    n = len(ts)
    mo, mc = bars.mo, bars.mc
    cal = calendar or DEFAULT_CALENDAR
    rows = []
    recs = orders.to_dict("records")
    for k, o in enumerate(recs):
        side = int(o["side"])
        if side not in (1, -1):
            raise ValueError("side must be +1 or -1")
        kind = _get(o, "kind", "market")
        t = int(o["decision_ts"])
        if o.get("pair") is not None and _cost.pair_key(str(o["pair"])) != _cost.pair_key(bars.pair):
            raise ValueError(f"order for {o['pair']} on {bars.pair} bars")
        row = {"order_id": _get(o, "order_id", k), "pair": bars.pair, "side": side, "kind": kind,
               "w": float(_get(o, "w", float(side))), "decision_ts": t, "era": E.era_of(t),
               "fin_rolls": ()}
        sig = _get(o, "signal_ts", None)
        if sig is not None:
            if int(sig) > t:
                raise ValueError("signal_ts after decision_ts")
            row["signal_ts"] = int(sig)
        rows.append(row)
        era_last = int(E.era_last_ts(t))
        hi = int(np.searchsorted(ts, era_last, side="right"))      # bars of the decision's era only
        i0 = int(np.searchsorted(ts, t, side="left"))
        x_ts = _get(o, "exit_ts", None)
        x_ts = None if x_ts is None else int(x_ts)
        if i0 >= hi:
            row["status"] = "void_no_entry"
            continue
        # ------------------------------------------------------------ entry
        if kind == "market":
            if ts[i0] >= t + market_max_delay_s or (x_ts is not None and ts[i0] >= x_ts):
                row["status"] = "void_no_entry"
                continue
            f = i0
            fill = bars.ao[f] + sl["market_entry"] if side == 1 else bars.bo[f] - sl["market_entry"]
            fmid = mo[f]
        elif kind in ("limit", "stop"):
            L = float(o["level"])
            if reject_marketable:
                kb = int(np.searchsorted(ts, t - bs, side="right")) - 1   # last bar closed by t
                if kb < 0:
                    row["status"] = "rejected_marketable"
                    continue
                a_c, b_c = bars.ac[kb], bars.bc[kb]
                bad = ((side == 1 and L >= a_c) or (side == -1 and L <= b_c)) if kind == "limit" \
                    else ((side == 1 and L <= a_c) or (side == -1 and L >= b_c))
                if bad:
                    row["status"] = "rejected_marketable"
                    continue
            live = _get(o, "cancel_ts", None)
            live = int(live) if live is not None else None
            if x_ts is not None:
                live = x_ts if live is None else min(live, x_ts)
            lb = hi if live is None else min(hi, int(np.searchsorted(ts, live, side="left")))
            if lb <= i0:
                row["status"] = "expired"
                continue
            if kind == "limit":
                m = bars.al[i0:lb] <= L - thr if side == 1 else bars.bh[i0:lb] >= L + thr
            else:
                m = bars.ah[i0:lb] >= L if side == 1 else bars.bl[i0:lb] <= L
            j = _first(m)
            if j < 0:
                row["status"] = "expired"
                continue
            f = i0 + j
            if kind == "limit":
                fill, fmid = L, L
            elif side == 1:
                fill, fmid = max(L, bars.ao[f]) + sl["stop_entry"], max(L, mo[f])
            else:
                fill, fmid = min(L, bars.bo[f]) - sl["stop_entry"], min(L, mo[f])
        else:
            raise ValueError(f"unknown order kind {kind!r}")
        # ------------------------------------------------------------ stop and target
        S = _get(o, "stop")
        sd = _get(o, "stop_dist")
        if not np.isnan(sd):
            S = fill - side * float(sd)
        S = float(S)
        d = side * (fill - S) if not np.isnan(S) else np.nan
        if not np.isnan(S) and not d > 0:
            row["status"] = "skip_beyond"
            continue
        T = float(_get(o, "target"))
        tr = _get(o, "target_r")
        if not np.isnan(tr):
            if np.isnan(d):
                raise ValueError("target_r needs a stop")
            T = fill + side * float(tr) * d
        if not np.isnan(T) and not side * (T - fill) > 0:
            row["status"] = "skip_target"
            continue
        # ------------------------------------------------------------ the last bar a trade may be open
        cut_reason = None
        if x_ts is not None and time_exit_mode == "open_after":
            j_x = int(np.searchsorted(ts, x_ts, side="left"))
            if j_x < hi:
                if exit_max_delay_s is not None and ts[j_x] >= x_ts + exit_max_delay_s:
                    row["status"] = "void_no_exit"
                    continue
                end = j_x                                   # scan [f, j_x); exit at the open of j_x
            else:
                end, cut_reason = hi, "cut"
        elif x_ts is not None:
            j_e = int(np.searchsorted(ts, x_ts - bs, side="right")) - 1   # last bar closed by x_ts
            if j_e < f:
                row["status"] = "void_no_time"
                continue
            if j_e >= hi:
                end, cut_reason = hi, "cut"
            else:
                end = j_e + 1                               # scan [f, j_e]; exit at the close of j_e
        else:
            end, cut_reason = hi, "cut"
        if cut_reason and hi == n and _next_open(int(ts[n - 1]) + bs) <= era_last:
            cut_reason = "data_end"                         # the loaded data ends before the era
        # ------------------------------------------------------------ scan
        seg = slice(f, end)
        if side == 1:
            hs = bars.bl[seg] <= S if not np.isnan(S) else np.zeros(end - f, bool)
            ht = bars.bh[seg] >= T if not np.isnan(T) else np.zeros(end - f, bool)
        else:
            hs = bars.ah[seg] >= S if not np.isnan(S) else np.zeros(end - f, bool)
            ht = bars.al[seg] <= T if not np.isnan(T) else np.zeros(end - f, bool)
        if len(ht) and not target_in_fill_bar:
            ht[0] = False
        hit = hs | ht
        jj = _first(hit)
        exit_at = "open"
        if jj >= 0:
            j = f + jj
            if hs[jj]:
                why, xk = "stop", "stop"
                if side == 1:
                    xf, xm = min(S, bars.bo[j]) - sl["stop_exit"], min(S, mo[j])
                else:
                    xf, xm = max(S, bars.ao[j]) + sl["stop_exit"], max(S, mo[j])
            else:
                why, xk, xf, xm = "target", "target", T, T
        elif cut_reason:
            j = end - 1
            why, xk, exit_at = cut_reason, "cut", "close"
            xf = bars.bc[j] - sl["cut"] if side == 1 else bars.ac[j] + sl["cut"]
            xm = mc[j]
        elif time_exit_mode == "open_after":
            j = end
            why, xk = "time", "time"
            xf = bars.bo[j] - sl["time_exit"] if side == 1 else bars.ao[j] + sl["time_exit"]
            xm = mo[j]
        else:
            j = end - 1
            why, xk, exit_at = "time", "time", "close"
            xf = bars.bc[j] - sl["time_exit"] if side == 1 else bars.ac[j] + sl["time_exit"]
            xm = mc[j]
        x_time = int(ts[j]) + (bs if exit_at == "close" else 0)
        pips_ba = side * (xf - fill) / P
        pips_mid = side * (xm - fmid) / P
        spread = pips_mid - pips_ba
        # a roll is held when entry fill bar open < roll <= exit time (a close exit's time is the
        # bar's close)
        fin, rolls = financing_pips(financing, bars.pair, side, int(ts[f]), x_time, fill, cal,
                                    freezing=freezing)
        r_pips = d / P if not np.isnan(d) else np.nan
        row.update({"status": "filled", "entry_i": f, "entry_ts": int(ts[f]), "entry_fill": fill,
                    "entry_mid": fmid, "stop": S, "target": T, "r_pips": r_pips, "exit_i": j,
                    "exit_ts": int(ts[j]), "exit_at": exit_at, "exit_time": x_time, "exit_fill": xf,
                    "exit_mid": xm, "exit_reason": why, "cut": why in ("cut", "data_end"),
                    "entry_kind": kind, "exit_kind": xk, "pips_ba": pips_ba, "pips_mid": pips_mid,
                    "spread_paid": spread, "fin_pips": fin,
                    "R_ba": pips_ba / r_pips, "R_mid": pips_mid / r_pips, "fin_rolls": rolls})
    out = pd.DataFrame(rows).reindex(columns=OUT_COLS)
    ok = (out.status == "filled").to_numpy()
    if ok.any():                                             # the cost hook, vectorised
        fi = out.loc[ok, "entry_i"].to_numpy(np.int64)
        xi = out.loc[ok, "exit_i"].to_numpy(np.int64)
        sg = out.loc[ok, "signal_ts"]
        sig_kw = {}
        if sg.notna().any():                                 # the signal's time pays its window too
            sig_kw["signal_ts"] = sg.fillna(out.loc[ok, "decision_ts"]).to_numpy(np.int64)
        c = np.asarray(cost.round_trip(
            bars.pair, ts[fi], ts[xi], out.loc[ok, "spread_paid"].to_numpy(float),
            entry_kind=out.loc[ok, "entry_kind"].to_numpy(object),
            exit_kind=out.loc[ok, "exit_kind"].to_numpy(object), vol_entry=bars.vol[fi],
            vol_exit=bars.vol[xi], decision_ts=out.loc[ok, "decision_ts"].to_numpy(np.int64),
            freezing=freezing, exit_time=out.loc[ok, "exit_time"].to_numpy(np.int64), bar_sec=bs,
            **sig_kw),
            dtype=float)
        if c.shape != (int(ok.sum()),):
            c = np.broadcast_to(c, (int(ok.sum()),)).astype(float)
        out.loc[ok, "cost_pips"] = c
        out.loc[ok, "net_pips"] = out.loc[ok, "pips_mid"].to_numpy(float) - c - \
            out.loc[ok, "fin_pips"].to_numpy(float)
        out.loc[ok, "net_R"] = out.loc[ok, "net_pips"].to_numpy(float) / out.loc[ok, "r_pips"].to_numpy(float)
    for col in ("entry_i", "exit_i"):
        out[col] = out[col].astype("Int64")
    out.attrs["cost"] = dict(getattr(cost, "info", {}) or {})
    out.attrs["financing"] = dict(getattr(financing, "info", {}) or {})
    out.attrs["rules"] = {"through_pips": through_pips, "market_max_delay_s": market_max_delay_s,
                          "exit_max_delay_s": exit_max_delay_s, "target_in_fill_bar": target_in_fill_bar,
                          "time_exit_mode": time_exit_mode, "fill_slip": slip,
                          "reject_marketable": reject_marketable, "bar_seconds": bs}
    return out


def filled(df: pd.DataFrame) -> pd.DataFrame:
    return df[df.status == "filled"].reset_index(drop=True)
