"""Daily-position simulator: the 17:00 New York roll, financing and the daily P&L unit
(docs/EDGE_HUNT.md section 4 items 3-4; STATS PASS_BAR.md section 2).

Trading day. The 17:00 New York day, labelled by the date it closes on: New York local time plus
7 hours, take the date (STATS judge.trading_day). Labels are Monday-Friday; a Sunday-evening bar
belongs to Monday. The roll of day d is 17:00 America/New_York on date d (zoneinfo, so DST-aware:
21:00 UTC in US summer time, 22:00 UTC in winter).

Financing (source: OANDA's official financing pages as quoted, fetched 2026-10-13, in COST's
research/departments/COST/sources/OANDA_FINANCING_SPREADS.md on dept/cost):
  - "at 5 p.m. (ET), the position is considered to be held overnight"; flat by 5 pm ET = no charge;
  - "If you hold a position on Wednesday at 5 p.m., the funding rate will typically be three times
    the amount" (T+2 settlement carries the weekend); "no financing charges or credits on Saturday
    or Sunday"; market holidays "can add days" (pass ``extra_days`` for them).
  So a position held over the roll of day d pays days_charged(d) = 3 on Wednesday, 1 on the other
  weekdays (+ extra_days[d]). A roll is "held" when entry < roll <= exit (Round 45's rule).
  Hooks: CostFinancing, COST's rule (research/departments/COST/cost.py financing_rows: its own roll
  count, Mon-Fri calendar rolls with Wednesday 3, the USD/CAD worse-of, and the COST_MODEL markup);
  this module keeps no financing formula. FlatPips (Round 45's 1 pip a night, 3 on Wednesday, over
  this module's Calendar) is for parity runs only and is refused on a frozen run. Pips positive =
  paid by the position.

Daily unit. ``position_days`` turns a long and a short simulation of the same orders (sim_bar
output) into STATS's position-day file: one row per position per trading day it is open, with
position_id, pair, day, decision_ts, w, pnl_long, pnl_short in STATS judge.COLS order (per unit
size, in R, return or pips). decision_ts is the own-side order's signal_ts when it has one (a weight
matrix: the 17:00 roll it was decided at), else its decision_ts; it sets the row's era in STATS's
judge.validate. Each version
is marked at every 17:00 NY roll it is held over at the bid (long) or ask (short) close of the last
bar closing by the roll; the entry day starts from the fill, the exit day ends at the exit fill; the
cost charged above the spread already paid (floor top-up and slippage) is booked on the entry day;
financing on the day whose roll was held. A version's rows sum exactly to its net_pips.
``daily_net`` sums |w| x pnl of the pick's own side over every label (0 on days with no position).

``positions_to_orders`` / ``simulate_positions`` cover a daily weight matrix (decided at a roll,
executed at the first bar at or after roll + exec_delay_s, default 15 min, outside the 16:55-17:15
window): each run of one constant signed weight becomes one market position closed at the roll +
delay that ends the run (a size change closes and reopens: conservative on cost). The roll is the
order's signal_ts, so the cost hook charges the 16:55-17:15 window floor on the entry leg
(EDGE_HUNT section 4 item 3: "decided or filled 16:55-17:15 New York").

1-minute bars only (audit findings #19 and #30). ``require_m1`` refuses bars that are not M1, and
sim_bar.simulate, trade_day_rows, position_days and simulate_positions call it. On a longer bar the
time of a fill or exit inside the bar is unknown, the 17:00 roll (inside a UTC-aligned H4 bar in US
summer time) or COST's 16:55-17:15 window can fall inside one bar, and "the last bar closing by t"
written as bar open <= t - 60 picks a bar that had not closed (an H4 mark of the 21:00 UTC roll
would read the 00:00 UTC close). The M1 test, on the bar opens only:
  - bar opens strictly increasing, every one on a whole minute, and bar_seconds 60 (stated through
    Bars(bar_seconds=60) or from_frame(granularity='M1'), or inferred as the smallest step);
  - 30 or more steps: the smallest step is 60 s, and steps of 60 s are at least as many as steps
    that are whole multiples of 5 minutes (the steps between M5, M15, H1, H4 or D bars on their
    grid), so a frame mostly of such bars is refused;
  - 1-29 steps (a short slice): the smallest step is at most 240 s, shorter than M5 (300 s), the
    shortest catalog bar above M1, so no set of M5 or longer bars passes;
  - any length: at most a third of the steps are an hour or longer.
  Steps over a weekly close (they always span Saturday 12:00 UTC) are left out of the counts.
Real M1 misses minutes at the Sunday open, before the roll, at night and on holidays (Good Friday),
so a short slice of it can have no 60 s step at all (Sunday open: steps of 6 and 2 minutes), and a
thin hour can have 2-minute steps as its most common. A slice with no 60 s step passes only with
bar_seconds stated as 60; inferred, its bar length is its smallest step and it is refused. Bars of
2-4 minutes (not in the catalog; resample_m1 can make them) stated as M1 pass below 30 steps.
Pass the whole frame from research.common.loaders.load_m1 rather than a slice.
Measured on every BUILD EUR/USD and GBP/USD window (2010-2021, windows of 2 minutes to a day starting
every 30 minutes, about 300,000 per length; stated as M1), the first version of this rule (476e5ee7)
refused 1,546 of the 15-minute windows and 58 of the first 15 minutes after a Sunday open; this one
refuses 139 and 3, all slices of under 30 steps whose bars are 5 minutes or more apart, which bar
times cannot tell from M5. No 17:00-17:00 trading day is refused. The 2016-2021 counts are pinned in
research/common/tests/test_sims_daily.py (M1_WINDOW_REFUSALS). Coarse sets (M5, M15, M30, H1, H4, D)
stated as M1 are refused at every length from 2 bars. Bar times cannot catch a mixed frame whose M1
part is the larger (an M1 week joined to a day of H1 bars) or H1 data forward-filled to minutes;
keep each frame from one loader call.
The check is cached on a Bars object (its ts is a read-only copy), so a loop of simulate calls on
the same Bars pays it once; position_days checks each pair's bars once.
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

NY = ZoneInfo("America/New_York")
M1_SECONDS = 60
FIN_WEEKDAY_DAYS = {0: 1, 1: 1, 2: 3, 3: 1, 4: 1}
# STATS judge.COLS (PASS_BAR v2, origin/dept/stats 530a9245; unchanged in the v3 draft 34f5f508)
POS_COLS = ("position_id", "pair", "day", "decision_ts", "w", "pnl_long", "pnl_short")


# ---------------------------------------------------------------------------- bar length
M1_MODE_MIN_STEPS = 30     # from 30 steps on: smallest step 60 s; minute steps >= 5-minute-grid steps
M1_SHORT_MAX_STEP = 240    # below that, the smallest step may be up to 240 s: shorter than M5 (300 s),
                           # the shortest catalog bar above M1 (datasets.json; Sunday open: 6, 2 min)
COARSE_MIN_STEP = 300               # M5, the shortest catalog bar above M1
HOUR_SECONDS, WEEK_SECONDS = 3600, 7 * 86400
SAT_NOON_UTC = int(datetime(2016, 1, 2, 12, tzinfo=timezone.utc).timestamp())   # a Saturday 12:00 UTC:
# always inside the weekly close (Fri 17:00 - Sun 17:00 New York = Fri 21:00/22:00 - Sun 21:00/22:00 UTC)


def _step_stats(d: np.ndarray) -> tuple[int, int]:
    """(smallest, most common) of a non-empty array of positive steps; a tie goes to the smaller."""
    mn = int(d.min())
    if 2 * int(np.count_nonzero(d == mn)) >= d.size:  # the smallest holds half the steps or more,
        return mn, mn                                 # so it is the most common (or ties, and wins)
    v, c = np.unique(d, return_counts=True)
    return int(v[0]), int(v[np.argmax(c)])


def ts_steps(ts) -> tuple[int | None, int | None]:
    """(smallest, most common) positive step between bar opens, in seconds; (None, None) with fewer
    than two distinct bar opens. A tie for the most common step goes to the smaller step."""
    d = np.diff(np.asarray(ts, dtype=np.int64))
    d = d[d > 0]
    if d.size == 0:
        return None, None
    return _step_stats(d)


def require_m1(bars, who: str) -> int:
    """M1_SECONDS (60), or ValueError when ``bars`` are not 1-minute bars (module docstring).
    A pass is cached on the bars object when its ts is a read-only int64 array it owns (Bars)."""
    ts_obj = bars.ts
    stated_bs = getattr(bars, "bar_seconds", None)
    hit = getattr(bars, "_m1_ok", None)
    if hit is not None and hit[0] is ts_obj and hit[1] == stated_bs and not ts_obj.flags.writeable:
        return M1_SECONDS
    t = np.asarray(ts_obj, dtype=np.int64)
    d = np.diff(t)
    if d.size and not bool(np.all(d > 0)):
        raise ValueError(f"{who}: bars must be sorted by ts with no duplicates (bar opens strictly "
                         "increasing)")
    smallest, common = _step_stats(d) if d.size else (None, None)
    inferred = bool(getattr(bars, "_bar_seconds_inferred", stated_bs is None))
    bs = stated_bs if stated_bs is not None else (smallest if smallest is not None else M1_SECONDS)
    aligned = bool(len(t) == 0 or not np.any(t % M1_SECONDS))
    hours = np.flatnonzero(d >= HOUR_SECONDS)
    wk = (t[hours + 1] - SAT_NOON_UTC) // WEEK_SECONDS > (t[hours] - SAT_NOON_UTC) // WEEK_SECONDS
    n_wk = int(wk.sum())                              # steps over a weekly close (all an hour or more)
    n_hour, n_base = int(hours.size) - n_wk, int(d.size) - n_wk
    n_min = int(np.count_nonzero(d == M1_SECONDS)) if d.size else 0
    # steps on the 5-minute grid: every step between M5, M15, H1, H4 or D bars is a whole multiple of
    # 300 s; the gaps in thin real M1 mostly are not (Memorial Day 2019: steps of 9, 14, 11, 7 minutes)
    grid = (d >= COARSE_MIN_STEP) & (d % COARSE_MIN_STEP == 0)
    n_coarse = int(np.count_nonzero(grid)) - int(np.count_nonzero(wk & grid[hours]))
    why = []
    if bs != M1_SECONDS:
        why.append(f"bar_seconds is not {M1_SECONDS}")
    if not aligned:
        why.append("a bar opens off a whole minute")
    if d.size >= M1_MODE_MIN_STEPS and smallest != M1_SECONDS:
        why.append(f"with {M1_MODE_MIN_STEPS} or more steps the smallest step must be {M1_SECONDS} s")
    if d.size >= M1_MODE_MIN_STEPS and n_coarse > n_min:
        why.append(f"with {M1_MODE_MIN_STEPS} or more steps, steps that are whole multiples of "
                   f"{COARSE_MIN_STEP} s outnumber steps of {M1_SECONDS} s")
    if 0 < d.size < M1_MODE_MIN_STEPS and smallest > M1_SHORT_MAX_STEP:
        why.append(f"with under {M1_MODE_MIN_STEPS} steps the smallest step must be at most "
                   f"{M1_SHORT_MAX_STEP} s")
    if 3 * n_hour > n_base:
        why.append("over a third of the steps are an hour or longer")
    if why:
        raise ValueError(
            f"{who} runs on 1-minute (M1) bars only; these {len(t)} bars: bar_seconds {bs} "
            f"({'inferred from the smallest step' if inferred else 'stated'}), smallest ts step "
            f"{smallest} s, most common {common} s, opens on whole minutes {aligned}; of {n_base} steps "
            f"(weekly closes left out) {n_min} of {M1_SECONDS} s, {n_coarse} whole multiples of "
            f"{COARSE_MIN_STEP} s, {n_hour} of an hour or more. Refused: {'; '.join(why)}. On longer "
            "bars a fill or exit inside a bar has no known time and a bar that had not closed would be "
            "read (audit findings #19, #30). Pass the whole frame from research.common.loaders.load_m1: "
            "a short slice of M1 with missing minutes (Sunday open, holidays) can look like longer bars; "
            "if you must slice, state the length (Bars.from_frame(df, pair, granularity='M1')). Or use a "
            "simulator written and red-teamed for your bar length.")
    if isinstance(ts_obj, np.ndarray) and ts_obj.dtype == np.int64 and ts_obj.base is None \
            and not ts_obj.flags.writeable:
        try:
            bars._m1_ok = (ts_obj, stated_bs)
        except AttributeError:
            pass
    return M1_SECONDS


# ---------------------------------------------------------------------------- calendar
def trading_day(ts) -> np.ndarray | date:
    """Trading-day label (datetime.date) of each ts: NY local time + 7 h, the date."""
    t = pd.to_datetime(np.atleast_1d(np.asarray(ts, dtype=np.int64)), unit="s", utc=True)
    d = (t.tz_convert(NY).tz_localize(None) + pd.Timedelta(hours=7)).date
    if np.ndim(ts) == 0:
        return d[0]
    return np.asarray(d)


def roll_ts(d) -> int:
    """17:00 New York on date d, as unix seconds."""
    if isinstance(d, str):
        d = date.fromisoformat(d)
    elif isinstance(d, (pd.Timestamp, np.datetime64)):
        d = pd.Timestamp(d).date()
    return int(datetime.combine(d, time(17, 0), NY).timestamp())


def weekdays_between(d0: date, d1: date) -> list:
    out, x = [], d0
    while x <= d1:
        if x.weekday() < 5:
            out.append(x)
        x += timedelta(days=1)
    return out


def trading_days_from_bars(ts, min_bars: int = 100) -> list:
    """Days present in the bars with at least min_bars bars (Round 45 daily_bars convention)."""
    s = pd.Series(trading_day(ts)).value_counts()
    return sorted(d for d, n in s.items() if n >= min_bars and d.weekday() < 5)


class Calendar:
    """Roll calendar. days=None: every Monday-Friday; else only the given days (e.g. from data)."""

    def __init__(self, days=None, extra_days: dict | None = None):
        self.days = None if days is None else sorted(pd.Timestamp(d).date() for d in days)
        self._ends = None if days is None else np.array([roll_ts(d) for d in self.days], np.int64)
        self.extra = {pd.Timestamp(k).date(): int(v) for k, v in (extra_days or {}).items()}

    def rolls(self, a: int, b: int) -> tuple[np.ndarray, list, np.ndarray]:
        """Rolls r with a < r <= b: (roll ts, day dates, days charged)."""
        a, b = int(a), int(b)
        if b <= a:
            return np.zeros(0, np.int64), [], np.zeros(0, np.int64)
        if self._ends is None:
            d0 = trading_day(a) - timedelta(days=1)
            d1 = trading_day(b) + timedelta(days=1)
            ds = [d for d in weekdays_between(d0, d1) if a < roll_ts(d) <= b]
            rt = np.array([roll_ts(d) for d in ds], np.int64)
        else:
            k0, k1 = np.searchsorted(self._ends, a, "right"), np.searchsorted(self._ends, b, "right")
            ds, rt = self.days[k0:k1], self._ends[k0:k1]
        n = np.array([FIN_WEEKDAY_DAYS[d.weekday()] + self.extra.get(d, 0) for d in ds], np.int64)
        return rt, list(ds), n


DEFAULT_CALENDAR = Calendar()


# ---------------------------------------------------------------------------- financing hooks
class FlatPips:
    """per_day pips for each day charged (Round 45: 1 pip a night, 3 on Wednesday). Both sides pay."""

    def __init__(self, per_day: float = 1.0):
        self.per_day = float(per_day)
        self.info = {"kind": "flat_pips", "per_day": self.per_day}

    def __call__(self, pair, side, roll_ts, days_charged, price) -> np.ndarray:
        return self.per_day * np.asarray(days_charged, dtype=float)


NO_FINANCING = FlatPips(0.0)


class CostFinancing:
    """COST's financing rule (research/departments/COST/cost.py ``financing_rows``; coordinator ruling,
    14 Oct 2026: one implementation, COST's). This hook holds no formula and counts no rolls: for each
    position it returns COST's rows (roll_ts, days charged, pips per unit of base, positive = paid).
    rate(ccy, ts) -> the policy rate in % a year announced before ts (from DATA's data/macro
    policy_rates_daily.csv, as-of); a missing rate raises in COST's code.
    The model is COST_MODEL.json and COST's cost.py comes from research.common.cost (both sha256 in .info).
    """

    def __init__(self, rate, model: dict, info: dict | None = None, repo=None, local: bool = True):
        from . import cost as C
        mod, cinfo = C.cost_module(repo, local=local)
        if not hasattr(mod, "financing_rows"):
            raise C.CostModelMissing(f"{cinfo['source']} has no financing_rows (COST ac9f8264 or later)")
        self._rows, self.rate, self.model = mod.financing_rows, rate, model
        self.info = {"kind": "cost_financing_rows", "model": dict(info or {}), "cost_py": cinfo}

    @classmethod
    def load(cls, rate, repo=None, local: bool = True):
        import json
        from . import cost as C
        b, info = C.load_model_bytes(repo, local=local)
        return cls(rate, json.loads(b), info=info, repo=repo, local=local)

    def rows(self, pair, side, entry_ts, exit_ts, price, freezing: bool = False):
        return self._rows(self.model, pair, int(side), int(entry_ts), int(exit_ts), float(price),
                          self.rate, freezing=freezing)


def financing_pips(financing, pair, side, entry_ts, exit_ts, price, calendar=None, freezing: bool = False):
    """(total pips, ((roll ts, pips), ...)) for a position held from entry_ts to exit_ts.
    A hook with ``rows`` (CostFinancing) counts its own rolls in COST's code; the calendar is used only
    by the per-roll parity hooks (FlatPips)."""
    if hasattr(financing, "rows"):
        rows = financing.rows(pair, side, entry_ts, exit_ts, price, freezing=freezing)
        return float(sum(r[2] for r in rows)), tuple((int(r[0]), float(r[2])) for r in rows)
    cal = calendar or DEFAULT_CALENDAR
    rt, _, n = cal.rolls(entry_ts, exit_ts)
    if len(rt) == 0:
        return 0.0, ()
    if freezing:
        raise ValueError("a judged (frozen) position held over a 17:00 New York roll is financed with "
                         "CostFinancing (COST's rule); FlatPips is for parity runs only")
    p = np.asarray(financing(pair, side, rt, n, price), dtype=float)
    return float(p.sum()), tuple((int(a), float(b)) for a, b in zip(rt, p))


# ---------------------------------------------------------------------------- position-day file
def _marks(bars, rolls: np.ndarray, side: int) -> np.ndarray:
    """Bid (long) / ask (short) close of the last bar closing by each roll (M1 bars only)."""
    require_m1(bars, "sim_daily._marks")
    return _marks_m1(bars, rolls, side)


def _marks_m1(bars, rolls: np.ndarray, side: int) -> np.ndarray:
    """_marks on bars the caller has passed through require_m1."""
    k = np.searchsorted(bars.ts, np.asarray(rolls, dtype=np.int64) - M1_SECONDS, side="right") - 1
    if np.any(k < 0):
        raise ValueError("no bar before a roll")
    return (bars.bc if side > 0 else bars.ac)[k]


def trade_day_rows(tr: dict, bars) -> list[tuple]:
    """[(day, pnl_pips), ...] for one filled sim_bar trade row, own side. Sums to net_pips.
    M1 bars only (require_m1)."""
    require_m1(bars, "sim_daily.trade_day_rows")
    return _trade_day_rows(tr, bars)


def _trade_day_rows(tr: dict, bars) -> list[tuple]:
    """trade_day_rows on bars the caller has passed through require_m1."""
    side = int(tr["side"])
    pip = bars.pip
    fr = tr["fin_rolls"] or ()          # every held roll of the calendar used, with its pips
    rolls = np.array([r for r, _ in fr], dtype=np.int64)
    fin = [p for _, p in fr]
    marks = _marks_m1(bars, rolls, side) if len(rolls) else np.zeros(0)
    pts = [float(tr["entry_fill"])] + [float(x) for x in marks] + [float(tr["exit_fill"])]
    days = [trading_day(int(r) - 1) for r in rolls] + [trading_day(int(tr["exit_ts"]))]
    rows = {}
    for d, a, b in zip(days, pts[:-1], pts[1:]):
        rows[d] = rows.get(d, 0.0) + side * (b - a) / pip
    d0 = trading_day(int(tr["entry_ts"]))
    rows[d0] = rows.get(d0, 0.0) - (float(tr["cost_pips"]) - float(tr["spread_paid"]))
    for r, f in zip(rolls, fin):
        d = trading_day(int(r) - 1)
        rows[d] = rows.get(d, 0.0) - f
    return sorted(rows.items())


def _unit_scale(tr: dict, unit: str, pip: float) -> float:
    if unit == "pips":
        return 1.0
    if unit == "R":
        r = float(tr["r_pips"])
        if not np.isfinite(r) or r <= 0:
            raise ValueError("unit='R' needs a stop (r_pips) on every trade; use unit='ret'")
        return 1.0 / r
    if unit == "ret":
        return pip / float(tr["entry_mid"])
    raise ValueError("unit must be 'R', 'ret' or 'pips'")


def position_days(long_tr: pd.DataFrame, short_tr: pd.DataFrame, bars_by_pair: dict,
                  w=None, unit: str = "R", sides=None) -> pd.DataFrame:
    """STATS position-day file from a long and a short simulation of the same orders.

    long_tr / short_tr: sim_bar.simulate outputs, row-aligned (row k of each = the same order with
    side +1 / -1; build them with baselines.mirror_orders or by setting the side). w: signed sizes
    (default: +-1 from ``sides``, the pick's own side per order). A position exists where the pick's
    own version filled; the other version's days are kept too (0 where it was flat). For unit='R'
    each version is scaled by its own r_pips. The bars of every pair used must be M1 (require_m1,
    checked once per pair)."""
    if len(long_tr) != len(short_tr):
        raise ValueError("long and short simulations must be row-aligned")
    if sides is None:
        sides = np.ones(len(long_tr), dtype=int)
    sides = np.asarray(sides, dtype=int)
    if w is None:
        w = sides.astype(float)
    w = np.asarray(w, dtype=float)
    out, checked = [], {}
    for k in range(len(long_tr)):
        own = long_tr.iloc[k] if sides[k] > 0 else short_tr.iloc[k]
        if own["status"] != "filled" or w[k] == 0:
            continue
        pid = own.get("order_id", k)
        sig = own.get("signal_ts")
        dec = int(sig) if sig is not None and pd.notna(sig) else int(own["decision_ts"])
        per = {}
        for col, tr in (("pnl_long", long_tr.iloc[k]), ("pnl_short", short_tr.iloc[k])):
            if tr["status"] != "filled":
                continue
            b = bars_by_pair[tr["pair"]]
            if checked.get(tr["pair"]) is not b:              # once per pair, not per trade
                require_m1(b, "sim_daily.position_days")
                checked[tr["pair"]] = b
            sc = _unit_scale(tr, unit, b.pip)
            for d, v in _trade_day_rows(tr, b):
                per.setdefault(d, {"pnl_long": 0.0, "pnl_short": 0.0})[col] += v * sc
        for d, v in sorted(per.items()):
            out.append({"position_id": pid, "pair": own["pair"], "day": d.isoformat(),
                        "decision_ts": dec, "w": w[k], "pnl_long": v["pnl_long"],
                        "pnl_short": v["pnl_short"]})
    return pd.DataFrame(out, columns=list(POS_COLS))


def daily_net(pos_days: pd.DataFrame, days=None) -> pd.Series:
    """Daily net = sum over rows of |w| x (pnl_long if w > 0 else pnl_short), over every label in
    days (default: every weekday from the first to the last row), 0 where flat."""
    if days is None:
        if len(pos_days) == 0:
            return pd.Series(dtype=float)
        ds = sorted(pos_days.day)
        days = [d.isoformat() for d in weekdays_between(date.fromisoformat(ds[0]),
                                                         date.fromisoformat(ds[-1]))]
    w = pos_days.w.to_numpy(float)
    v = np.abs(w) * np.where(w > 0, pos_days.pnl_long.to_numpy(float), pos_days.pnl_short.to_numpy(float))
    s = pd.Series(v, index=pos_days.day.astype(str)).groupby(level=0).sum()
    extra = set(s.index) - set(days)
    if extra:
        raise ValueError(f"rows on days outside the window: {sorted(extra)[:3]}")
    return s.reindex(list(days), fill_value=0.0)


# ---------------------------------------------------------------------------- weight matrices
def positions_to_orders(weights: pd.DataFrame, exec_delay_s: int = 900) -> pd.DataFrame:
    """Daily signed weights (index: decision-day labels, decided at that day's 17:00 NY roll;
    columns: pairs) -> market orders with time exits. Each run of one constant non-zero weight is one
    position: entered at roll(first day) + delay, closed at roll(the day the run ends) + delay, where
    that day is the next index label (or the next weekday after the last label)."""
    idx = [pd.Timestamp(d).date() for d in weights.index]
    if any(b <= a for a, b in zip(idx, idx[1:])):
        raise ValueError("weights index must be increasing trading days")
    nxt = idx[1:] + [weekdays_between(idx[-1] + timedelta(days=1), idx[-1] + timedelta(days=7))[0]] \
        if idx else []
    rows = []
    for pair in weights.columns:
        v = weights[pair].fillna(0.0).to_numpy(float)
        k = 0
        while k < len(v):
            if v[k] == 0:
                k += 1
                continue
            j = k
            while j + 1 < len(v) and v[j + 1] == v[k]:
                j += 1
            rows.append({"order_id": f"{pair}|{idx[k].isoformat()}", "pair": pair,
                         "decision_ts": roll_ts(idx[k]) + exec_delay_s, "side": int(np.sign(v[k])),
                         "w": float(v[k]), "kind": "market",
                         "exit_ts": roll_ts(nxt[j]) + exec_delay_s, "signal_ts": roll_ts(idx[k])})
            k = j + 1
    return pd.DataFrame(rows, columns=["order_id", "pair", "decision_ts", "side", "w", "kind",
                                       "exit_ts", "signal_ts"])


def simulate_positions(weights: pd.DataFrame, bars_by_pair: dict, cost, financing,
                       exec_delay_s: int = 900, unit: str = "ret", calendar=None, **sim_kw):
    """Weight matrix -> (orders, long sims, short sims, position-day file). Market fills with a
    long market_max_delay so a Sunday open executes a Friday decision. M1 bars only (require_m1)."""
    from .sim_bar import simulate
    orders = positions_to_orders(weights, exec_delay_s)
    sim_kw.setdefault("market_max_delay_s", 4 * 86400)
    L, S, sides = [], [], []
    for pair, o in orders.groupby("pair", sort=False):
        b = bars_by_pair[pair]
        ol, os_ = o.assign(side=1), o.assign(side=-1)
        L.append(simulate(b, ol, cost=cost, financing=financing, calendar=calendar, **sim_kw))
        S.append(simulate(b, os_, cost=cost, financing=financing, calendar=calendar, **sim_kw))
        sides.append(o.side.to_numpy())
    if not L:
        return orders, pd.DataFrame(), pd.DataFrame(), position_days(pd.DataFrame(), pd.DataFrame(), {})
    lt, st = pd.concat(L, ignore_index=True), pd.concat(S, ignore_index=True)
    sd = np.concatenate(sides)
    w = np.concatenate([o.w.to_numpy() for _, o in orders.groupby("pair", sort=False)])
    pdays = position_days(lt, st, bars_by_pair, w=w, unit=unit, sides=sd)
    return orders, lt, st, pdays
