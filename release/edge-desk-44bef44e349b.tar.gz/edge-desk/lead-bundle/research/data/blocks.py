"""One block rule for every DATA fetcher (docs/EDGE_HUNT.md section 5, coordinator 14 Oct 2026; red team 14 Oct).

The first HTTP 403 or 429 from a host stops every request to that host and its subdomains for 24 hours, in every
process; a block is never re-checked, retried or worked around. research/departments/DATA/macro/fetch_util.py and
research/data/oanda_download.py both ask `blocked()` before every request, over the same logs, so they cannot
disagree. Plain standard library: this module must not import research.common (its runtime audit hook would then
guard the downloader's own reads).

What counts as a block line, in any department fetch log (is_log_path: FETCH_LOG.jsonl, fetch_log_*.jsonl, a
fetch_logs/ folder, .gz too), in this checkout and on origin's dept/* and coordinator branches (pushed_logs)
(see block_events):
  - a JSON object whose "status" (or "code", "status_code") is 403, 407 or 429 (an int, a whole float or a digit
    string); 407 is a proxy refusal. Its host is its "url" host, else the hosts written in it;
  - a line with no numeric status whose text says so in an HTTP shape: "<host> 403", "HTTP 429", "status 403",
    "answered 407", "403 Forbidden" (a hand-written note such as "rbnz.govt.nz 403 (Cloudflare challenge)").
    sha256 fields are never read as text.
Its time is "utc" (ISO 8601: Z, +00:00 and fractions are read; a time with no zone is read as UTC, as every log
here writes UTC; a text that starts with a date only is read as the last instant of that date in any zone,
latest_utc). A block line whose time cannot be read refuses every request until the log is fixed; one that
names no host refuses every request for 24 hours from its time (fail closed).

Which hosts a block covers: the logged host without a leading "www." and all its subdomains, so a 403 from
www.rbnz.govt.nz also covers rbnz.govt.nz and api.rbnz.govt.nz (coordinator: "a host and its subdomains", taken
as the site; stricter than the host alone).
"""
from __future__ import annotations

import functools
import gzip
import json
import os
import re
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

BLOCK_S = 24 * 3600
BLOCK_STATUSES = (403, 407, 429)
_CODES = "403|407|429"
_HOST = r"(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}"
_HOST_RE = re.compile(rf"(?<![A-Za-z0-9.-])({_HOST})(?![A-Za-z0-9-])")
# free text counts only in these shapes (red team 14 Oct: a count such as "(429 req)" or a sha256 is not a block):
# "<host> 403", "<host>-403", "<host>: 429"; or an HTTP-status phrase such as "HTTP 403", "status 429",
# "answered 407", "403 Forbidden", "429 Too Many Requests"
_COUNT_WORDS = r"(?!\s*(?:rows?|lines?|bars?|trades?|files?|records?|requests?|req|items?|pages?|days?)\b)"
_HOST_CODE = re.compile(rf"(?<![A-Za-z0-9.-])({_HOST})\s*[:=-]?\s*({_CODES})(?![0-9]){_COUNT_WORDS}"
                        rf"|(?<![0-9.])({_CODES})\s+(?:from|for)\s+({_HOST})(?![A-Za-z0-9-])", re.I)
_PHRASE = re.compile(rf"(?:\b(?:HTTP(?:/\d(?:\.\d)?)?|status|answered|returned|error|code|got)\b[^0-9\n]{{0,15}}"
                     rf"({_CODES})(?![0-9]){_COUNT_WORDS}"
                     rf"|(?<![0-9.])({_CODES})\s*(?:Forbidden|Too Many Requests|Proxy Authentication))", re.I)
# names that look like hosts but are files ("FETCH_LOG.jsonl", "home.htm"): never a host (red team 14 Oct 2026)
_FILE_TLDS = {"json", "jsonl", "csv", "txt", "md", "py", "htm", "html", "pdf", "zip", "gz", "xml", "log", "xlsx",
              "xls", "series", "js", "png", "jpg", "tar", "bz2", "pkl", "parquet", "sh", "ipynb"}
_STATUS_KEYS = ("status", "code", "status_code")
_SKIP_KEYS = ("sha256", "sha", "hash", "digest")


def site(host: str) -> str:
    h = (host or "").strip().lower().rstrip(".")
    return h[4:] if h.startswith("www.") else h


def covers(blocked_host: str, host: str) -> bool:
    """True when a block of blocked_host covers a request to host (the site and every subdomain)."""
    b, h = site(blocked_host), (host or "").strip().lower().rstrip(".")
    return bool(b) and (h == b or h.endswith("." + b))


def parse_utc(v) -> float | None:
    if not isinstance(v, str) or not v.strip():
        return None
    s = v.strip()
    if s.endswith("Z") or s.endswith("z"):
        s = s[:-1] + "+00:00"
    try:
        t = datetime.fromisoformat(s)
    except ValueError:
        return None
    if t.tzinfo is None:
        t = t.replace(tzinfo=timezone.utc)
    return t.timestamp()


_DATE_ONLY = re.compile(r"\s*(\d{4})-(\d{2})-(\d{2})(?![0-9])")


def latest_utc(v) -> float | None:
    """The time of a block line: parse_utc, else, when the text starts with a date only (COST's "2026-10-13 (time
    not recorded; ...)"), the last instant that date can be in any zone (24:00 at UTC-12, so 12:00 UTC the next
    day, minus a second): the block then lasts at least as long as it would from the true time. None otherwise."""
    t = parse_utc(v)
    if t is not None or not isinstance(v, str):
        return t
    m = _DATE_ONLY.match(v)
    if not m:
        return None
    try:
        d = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), tzinfo=timezone.utc)
    except ValueError:
        return None
    return d.timestamp() + 86400 + 12 * 3600 - 1


def _status(v) -> int | None:
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, float) and v.is_integer():
        return int(v)
    if isinstance(v, str) and v.strip().isdigit():
        return int(v.strip())
    return None


def _strings(v, key=None):
    if isinstance(v, str):
        if key not in _SKIP_KEYS:
            yield v
    elif isinstance(v, dict):
        for k, x in v.items():
            yield from _strings(x, k if isinstance(k, str) else None)
    elif isinstance(v, list):
        for x in v:
            yield from _strings(x, key)


def _url_host(u, need_scheme: bool = False) -> str | None:
    if not isinstance(u, str) or not u.strip() or (need_scheme and "://" not in u):
        return None
    try:
        h = urlsplit(u if "://" in u else "//" + u).hostname
    except ValueError:
        return None
    h = h.lower().rstrip(".") if h else None
    return h if h and _is_host(h) else None


def _is_host(h: str) -> bool:
    return "." in h and h.rsplit(".", 1)[-1] not in _FILE_TLDS


def _hosts_in(texts) -> set:
    return {h.lower().rstrip(".") for t in texts for h in _HOST_RE.findall(t) if _is_host(h.lower().rstrip("."))}


def block_events(text: str):
    """(line number, time or None, hosts, status) for every block line of one log's text.

    A JSON object with a numeric status (under "status", "code" or "status_code") is a block only when it is
    403, 407 or 429, and its hosts are only its "url" host when it has one (red team 14 Oct: a path such as
    /web/2015/https://www.rba.gov.au/ named another host). Other lines are blocks only when their text has
    the shapes in _HOST_CODE or _PHRASE; their hosts are the hosts next to a code, else every host in the text."""
    for n, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if not s:
            continue
        try:
            obj = json.loads(s)
        except ValueError:
            obj = None
        status = None
        if isinstance(obj, dict):
            for k in _STATUS_KEYS:
                st = _status(obj.get(k))
                if st is not None:
                    status = st
                    break
        ts = latest_utc(obj.get("utc")) if isinstance(obj, dict) else None
        url_host = _url_host(obj.get("url")) if isinstance(obj, dict) else None
        if status is not None:
            if status not in BLOCK_STATUSES:
                continue
            if url_host:
                hosts = {url_host}
            else:
                # a source is a host only when it is a URL ("rbnz" or "reachability check" is not: red team 14
                # Oct 2026, such a line blocked nothing); else the hosts written in the line, or none
                src = _url_host(obj.get("source"), need_scheme=True)
                hosts = {src} if src else _hosts_in(_strings(obj))
            yield n, ts, frozenset(hosts), status
            continue
        texts = list(_strings(obj)) if obj is not None else [s]
        near = []
        for t in texts:
            for m in _HOST_CODE.finditer(t):
                h, c = (m.group(1), m.group(2)) if m.group(1) else (m.group(4), m.group(3))
                h = h.lower().rstrip(".")
                if _is_host(h):
                    near.append((h, int(c)))
        phrase = [m for t in texts for m in _PHRASE.finditer(t)]
        if not near and not phrase:
            continue
        if near:
            hosts = {h for h, _ in near}
            code = near[0][1]
        else:
            g = phrase[0]
            code = int(g.group(1) or g.group(2))
            hosts = {url_host} if url_host else _hosts_in(texts)
        yield n, ts, frozenset(hosts), code


# A department's fetch log is any file under research/departments/ named like one: FETCH_LOG.jsonl,
# fetch_log_<x>.jsonl, <x>-fetchlog.jsonl, or any .jsonl inside a fetch_log(s)/ folder; .gz too (red team 14 Oct
# 2026: EVENTS logs blocks in EVENTS-04/fetch_logs/*.jsonl and COST in sources/fetch_log_*.jsonl, both unread before)
_LOG_NAME = re.compile(r"(?i)(?:^|/)(?:[^/]*fetch[_-]?log[^/]*|fetch[_-]?logs?/(?:[^/]+/)*[^/]+)\.jsonl(?:\.gz)?$")


def is_log_path(rel: str) -> bool:
    """rel (a path relative to the repo, with /) is a department's fetch log."""
    return rel.startswith("research/departments/") and bool(_LOG_NAME.search(rel[len("research/departments/"):]))


def _decode(name: str, data: bytes) -> str:
    """A log's text; a .gz log is unpacked (a bad one raises ValueError, so the caller refuses)."""
    if name.lower().endswith(".gz"):
        try:
            data = gzip.decompress(data)
        except (OSError, EOFError) as e:
            raise ValueError(f"{name} is not a readable gzip file ({e})") from None
    return data.decode("utf-8", errors="replace")


@functools.lru_cache(maxsize=64)
def _events(text: str) -> tuple:
    """block_events of one pushed log's text, kept: the same pushed texts are asked before every request. Only
    pushed texts are kept (a local log can grow with every request, and every version would be kept)."""
    return tuple(block_events(text))


def blocked(host: str, logs, now: float, texts=()) -> str | None:
    """Why a request to host is refused now, or None. logs: paths of fetch logs in this checkout (missing ones are
    skipped; one that cannot be read refuses); texts: (label, text) pairs of logs read elsewhere, such as the
    departments' pushed logs (pushed_logs)."""
    sources = []
    for log in logs:
        try:
            sources.append((str(log), block_events(_decode(str(log), Path(log).read_bytes()))))
        except FileNotFoundError:
            continue
        except (OSError, ValueError) as e:
            return f"{log} cannot be read ({e}); every request is refused (docs/EDGE_HUNT.md section 5)"
    sources += [(label, _events(text)) for label, text in texts]
    for label, events in sources:
        for n, ts, hosts, status in events:
            if ts is None:
                return (f"{label} line {n} is a block line ({status}) whose time cannot be read; every request is "
                        "refused until the log is fixed (docs/EDGE_HUNT.md section 5)")
            if not hosts:
                if now - ts < BLOCK_S:
                    return (f"{label} line {n} is a block line ({status}) that names no host; every request is "
                            "refused for 24 hours from it (docs/EDGE_HUNT.md section 5)")
                continue
            if now - ts < BLOCK_S:
                for b in sorted(hosts):
                    if covers(b, host):
                        when = datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                        return (f"{b} answered HTTP {status} at {when} ({label} line {n}); no request to {host} for "
                                "24 hours (docs/EDGE_HUNT.md section 5)")
    return None


class PushedLogsUnreadable(RuntimeError):
    """The departments' pushed fetch logs could not be fetched or read: every request is refused."""


_GIT_ENV_DROP = ("GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY", "GIT_COMMON_DIR",
                 "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_NAMESPACE", "GIT_CEILING_DIRECTORIES")
# origin must be the GitHub repo, every URL of it with insteadOf expanded (the same pattern as
# research/common/loaders.py GITHUB_ORIGIN; a test checks they agree): a mirror, or an insteadOf rewrite, may lack
# the blocks the departments pushed (STATS locked-runner red team 2, 14 Oct 2026)
GITHUB_ORIGIN = re.compile(r"(?:https://github\.com/|git@github\.com:|ssh://git@github\.com/)"
                           r"macdarenz-droid/Forex-signal(?:\.git)?/?")
COORDINATOR_BRANCH = "ccr-3d8c8d4d-gy5b9o"       # docs/EDGE_HUNT.md: departments merge into it
# every branch must be on origin after the fetch, or every request is refused (red team 14 Oct 2026: a fetch that
# "succeeds" with a branch missing, or pruned after a merge, read fewer blocks)
REQUIRED_BRANCHES = ("dept/data", "dept/stats", "dept/cost", "dept/macro", "dept/events", "dept/owner",
                     "dept/funded", COORDINATOR_BRANCH)   # dept/funded: the seventh department (coordinator, 14 Oct 2026)
GIT_TIMEOUT_S = 600          # a hung git (a stalled proxy) refuses rather than stall the fetcher forever
LOCK_RETRY_S = (1, 3, 9)     # another git in this checkout holding a ref lock: wait and fetch again, then refuse
_LOCKED = re.compile(r"cannot lock ref|Unable to create '[^']*\.lock'|unable to update local ref|\.lock': File exists",
                     re.I)
_sleep = time.sleep


def _git(repo, *args, binary: bool = False):
    env = {k: v for k, v in os.environ.items() if k not in _GIT_ENV_DROP}
    env.update(GIT_NO_REPLACE_OBJECTS="1", GIT_TERMINAL_PROMPT="0")   # no replaced blobs; never wait on a prompt
    cmd = ["git", "--no-replace-objects", "-c", "http.lowSpeedLimit=1000", "-c", "http.lowSpeedTime=60",
           "-C", str(repo), *args]
    try:
        r = subprocess.run(cmd, capture_output=True, env=env, stdin=subprocess.DEVNULL, timeout=GIT_TIMEOUT_S)
    except subprocess.TimeoutExpired:
        raise PushedLogsUnreadable(f"git {args[0]} in {repo} gave no answer in {GIT_TIMEOUT_S} s") from None
    if r.returncode != 0:
        raise PushedLogsUnreadable(f"git {args[0]} in {repo} failed: "
                                   f"{r.stderr.decode(errors='replace').strip()[:300]}")
    return r.stdout if binary else r.stdout.decode("utf-8", errors="replace")


def origin_ok(repo) -> bool:
    """Every URL of repo's origin (git remote get-url --all expands insteadOf) is the GitHub repo."""
    urls = [u.strip() for u in _git(repo, "remote", "get-url", "--all", "origin").splitlines() if u.strip()]
    return bool(urls) and all(GITHUB_ORIGIN.fullmatch(u) for u in urls)


def _fetch(repo) -> None:
    """git fetch of origin's dept/* and coordinator branches (no prune: a stale ref only adds blocks); retried after
    LOCK_RETRY_S only while another git holds a lock in this checkout, never on any other failure."""
    args = ("fetch", "-q", "origin", "+refs/heads/dept/*:refs/remotes/origin/dept/*",
            f"+refs/heads/{COORDINATOR_BRANCH}:refs/remotes/origin/{COORDINATOR_BRANCH}")
    for n in range(len(LOCK_RETRY_S) + 1):
        try:
            _git(repo, *args)
            return
        except PushedLogsUnreadable as e:
            if n == len(LOCK_RETRY_S) or not _LOCKED.search(str(e)):
                raise
            _sleep(LOCK_RETRY_S[n])


def pushed_logs(repo) -> list[tuple[str, str]]:
    """(label, text) of every department fetch log (is_log_path) on every origin/dept/* branch and on the
    coordinator branch, read right after a git fetch of them (STATS red team 3, 14 Oct 2026: a block logged on
    another department's branch reached this checkout only after two merges). Each file is read once by its blob id.
    Raises PushedLogsUnreadable when origin is not the GitHub repo (origin_ok), the fetch fails, a REQUIRED_BRANCHES
    branch is missing, or any read fails, so the caller refuses every request rather than go on without them."""
    if not origin_ok(repo):
        raise PushedLogsUnreadable(f"origin of {repo} is not github.com/macdarenz-droid/Forex-signal (a mirror or "
                                   "an insteadOf rewrite may lack the departments' blocks)")
    _fetch(repo)
    have = set(_git(repo, "for-each-ref", "--format=%(refname)", "refs/remotes/origin/").split())
    missing = [b for b in REQUIRED_BRANCHES if f"refs/remotes/origin/{b}" not in have]
    if missing:
        raise PushedLogsUnreadable(f"origin has no branch {', '.join(missing)} after the fetch")
    refs = sorted(r for r in have if r.startswith("refs/remotes/origin/dept/"))
    refs.append(f"refs/remotes/origin/{COORDINATOR_BRANCH}")
    out, seen = [], set()
    for ref in refs:
        for entry in _git(repo, "ls-tree", "-r", "-z", ref, "--", "research/departments").split("\0"):
            meta, _, name = entry.partition("\t")
            parts = meta.split()
            if len(parts) != 3 or parts[1] != "blob" or not is_log_path(name) or parts[2] in seen:
                continue
            seen.add(parts[2])
            try:
                text = _decode(name, _git(repo, "cat-file", "blob", parts[2], binary=True))
            except ValueError as e:
                raise PushedLogsUnreadable(f"{ref.removeprefix('refs/remotes/')}:{e}") from None
            out.append((f"{ref.removeprefix('refs/remotes/')}:{name}", text))
    return out


def department_logs(repo: Path) -> list[Path]:
    """Every department fetch log in this checkout (is_log_path), .gz included."""
    root = Path(repo)
    base = root / "research" / "departments"
    if not base.is_dir():
        return []
    found = [p for pat in ("*.jsonl", "*.jsonl.gz", "*.JSONL", "*.JSONL.GZ") for p in base.rglob(pat)]
    return sorted({p for p in found if p.is_file() and is_log_path(p.relative_to(root).as_posix())})
