"""Download OANDA practice bid/ask candles (M1, M5, M15, H1, H4 or D) for FX pairs and CFDs.

Usage:  python3 -I oanda_download.py <data_dir> [--from 2023-12-01] [--to 2025-06-30T21:00:00]
                 [--pairs EURUSD,GBPUSD | --instruments EUR_USD,USD_JPY,...] [--granularity M1]
                 [--max-fail-cycles 0] [--locked-run <ledger id>]

Writes <data_dir>/<NAME>_<GRAN>_BA.csv, NAME = the OANDA instrument name without "_" (EUR_USD ->
EURUSD, so the old M1 files keep their names EURUSD_M1_BA.csv and GBPUSD_M1_BA.csv), with columns
ts_utc (unix seconds, bar open), bid_o, bid_h, bid_l, bid_c, ask_o, ask_h, ask_l, ask_c, volume.
Only complete candles are kept, and only bars before --to. A rerun resumes after the last saved bar
(a partial last line left by a crash is cut off first). Each run appends one line to
<data_dir>/DOWNLOAD_LOG.jsonl (instruments, granularity, period, ledger id of a locked run).

Every request is a window `from`..`to` (OANDA treats `to` as exclusive; checked 13 Oct 2026 on 2010
data) spanning at most COUNT bars of the granularity and ending at or before --to; `count` is never
sent (OANDA: "Count should not be specified if both the start and end parameters are provided").
--to must sit on a bar boundary (H4 and D: 17:00 New York, the documented daily alignment), so the
last bar requested ends by --to. The Fetcher also refuses any window past its limit.

Locked data: the default --to is 2025-06-30T21:00:00 UTC (ts_utc 1751317200, the start of
VALIDATION, docs/EDGE_HUNT.md section 3). A later --to is refused unless --locked-run <ledger id>
is given and that id is the run id of a pushed, unclosed STATS start line (validation_run_start or
holdout_run_start run_id, forward_run_start ledger_id; research.common.loaders.open_run_kind, the
rule a locked read uses); that is for STATS's logged locked runs only, and the id is printed and logged.

H4 and D send dailyAlignment=17 and alignmentTimezone=America/New_York explicitly. These are OANDA's
documented defaults (developer.oanda.com/rest-live-v20/pricing-ep/, candles endpoint parameter
table, read 13 Oct 2026: dailyAlignment "[default=17, minimum=0, maximum=23]", alignmentTimezone
"[default=America/New_York]"); sending them means a change of default cannot change the bars.
Granularity names and alignments: developer.oanda.com/rest-live-v20/instrument-df/
(CandlestickGranularity: M1 minute alignment, M5 and H1 hour alignment, H4 and D day alignment).

Auth: no token in this file. Either the environment's proxy adds it (only for
api-fxpractice.oanda.com/v3/instruments/, price data), or, when the environment
variable OANDA_API_TOKEN is set (the owner's environment secret, 13 Oct 2026), a
requests auth hook (``_BearerAuth``) reads it FROM THE ENVIRONMENT AT REQUEST TIME and
adds the Bearer header to that one request; the token is never stored on the Fetcher or
its session (audit finding #15: ``f.s.headers['Authorization']`` must not expose it), and
is never printed or written. The session only ever calls the candles endpoint below, so
the header goes nowhere else. This script reads candles only; it has no account or order calls.

Data-source rule (AGENTS.md, owner 2026-10-06): OANDA documents 2 new connections/s
and 100 requests/s on a persistent connection
(https://developer.oanda.com/rest-live-v20/best-practices/). One request starts at
most every 1.0 s, i.e. 50% of the stricter limit. The first HTTP 403 or 429 stops the run at
once, is written to the FETCH_LOG, and blocks every request to the host for 24 hours in every
process (docs/EDGE_HUNT.md section 5); it is never retried. A 5xx gateway error honours
Retry-After, backs off, and stops after 3 failures. With
--max-fail-cycles N, 3 failures that are all HTTP 5xx instead start a 5-minute cool-down and
the run resumes, at most N times (docs/EDGE_HUNT.md, CLAUDE.md "Edge hunt departments" (3));
never after a 4xx, a timeout or a dropped connection. The response is parsed as JSON only.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import requests

HOST = "https://api-fxpractice.oanda.com/v3/instruments/{inst}/candles"
PAIRS = {"EURUSD": "EUR_USD", "GBPUSD": "GBP_USD"}
FX = ["EUR_USD", "GBP_USD", "USD_JPY", "USD_CHF", "AUD_USD", "NZD_USD", "USD_CAD", "EUR_GBP",
      "EUR_JPY", "GBP_JPY", "AUD_JPY", "EUR_CHF"]
CFDS = ["BCO_USD", "SPX500_USD", "XAU_USD", "UK100_GBP", "NAS100_USD", "USB10Y_USD", "JP225_USD",
        "UK10YB_GBP", "USB02Y_USD", "DE10YB_EUR", "DE30_EUR"]
# Crosses requested by EVENTS-02 (13 Oct 2026); each was probed with a one-hour candles request before
# its first download (research/departments/DATA/FETCH_LOG.jsonl).
# Index CFDs requested by EVENTS-03 (14 Oct 2026); probed with a one-hour request before their first download.
CFDS += ["AU200_AUD", "CH20_CHF"]
# Non-FX CFDs requested by FUNDED (14 Oct 2026); each was probed with two short M15 requests before its first
# download (research/departments/DATA/FETCH_LOG.jsonl has no block; the probe log is in DATA's REPORT).
CFDS += ["XAG_USD", "US30_USD", "WTICO_USD"]
CFDS += ["XPT_USD", "XPD_USD", "US2000_USD", "EU50_EUR", "FR40_EUR", "XCU_USD", "NATGAS_USD"]   # FUNDED, same probe
CROSSES = ["GBP_CHF", "GBP_AUD", "GBP_NZD", "GBP_CAD", "CHF_JPY", "AUD_CHF", "NZD_CHF", "CAD_CHF",
           "NZD_JPY", "CAD_JPY", "AUD_NZD", "AUD_CAD", "NZD_CAD"]
# DATA-PRE-2 (owner go, 16 Oct 2026): the three EUR crosses the 28-pair set lacked; each was probed first with one
# one-candle request per granularity (research/departments/DATA/pre_era/first_bars.json, 15 Oct 2026).
CROSSES += ["EUR_AUD", "EUR_NZD", "EUR_CAD"]
# DATA-EXO (owner "Yes" to an exotic-pair cost check, 16 Oct 2026 about 4:30 pm Melbourne; coordinator 4:33 pm): the
# 40 exotic pairs this practice account lists (research/departments/DATA/exotics/exotic_list.py); each was probed first
# with one one-candle request at M15 and at D (exotics/first_bars_exotic.json, 16 Oct 2026: all 40 with bid and ask).
EXOTICS = ["AUD_HKD", "AUD_SGD", "CAD_HKD", "CAD_SGD", "CHF_HKD", "CHF_ZAR", "EUR_CZK", "EUR_DKK", "EUR_HKD", "EUR_HUF",
           "EUR_NOK", "EUR_PLN", "EUR_SEK", "EUR_SGD", "EUR_TRY", "EUR_ZAR", "GBP_HKD", "GBP_PLN", "GBP_SGD", "GBP_ZAR",
           "HKD_JPY", "NZD_HKD", "NZD_SGD", "SGD_CHF", "SGD_JPY", "TRY_JPY", "USD_CNH", "USD_CZK", "USD_DKK", "USD_HKD",
           "USD_HUF", "USD_MXN", "USD_NOK", "USD_PLN", "USD_SEK", "USD_SGD", "USD_THB", "USD_TRY", "USD_ZAR", "ZAR_JPY"]
INSTRUMENTS = FX + CFDS + CROSSES + EXOTICS
GRAN_S = {"M1": 60, "M5": 300, "M15": 900, "H1": 3600, "H4": 4 * 3600, "D": 86400}
DAY_ALIGNED = ("H4", "D")             # bars aligned to the trading day, not to the UTC clock
DAILY_ALIGNMENT = 17
ALIGNMENT_TZ = "America/New_York"
CUTOFF = 1751317200   # 2025-06-30 21:00 UTC: first VALIDATION second; nothing at or after it unless locked run
TOKEN_ENV = "OANDA_API_TOKEN"   # the owner's environment secret; read only by _BearerAuth, at request time
DEFAULT_TO = "2025-06-30T21:00:00"
COUNT = 5000          # documented maximum candles per request
MIN_GAP_S = 1.0       # 50% of the 2 new connections/s limit
MAX_FAILS = 3
COOLDOWN_S = 300      # 5-minute cool-down after 3 HTTP 5xx failures (only with --max-fail-cycles)
COLS = ["ts_utc", "bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c", "volume"]
LEDGER_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$")
# A --locked-run id must already be a whole string value in a line of one of these files as pushed
# on STATS's branch (docs/EDGE_HUNT.md sections 5-6: every locked read goes in STATS's
# ACCESS_LOG.jsonl; STATS also keeps the validation and holdout ledgers). Read with `git show`, so
# run `git fetch origin dept/stats` first. DOWNLOAD_LOG.jsonl in the data dir is not this log.
LEDGER_REF = "origin/dept/stats"
LEDGER_FILES = ("research/departments/STATS/ACCESS_LOG.jsonl", "research/VALIDATION2_LEDGER.jsonl",
                "research/HOLDOUT_LEDGER.jsonl")
REPO = Path(__file__).resolve().parents[2]
# docs/EDGE_HUNT.md section 5 (coordinator, 14 Oct 2026): the first 403 or 429 from a host stops every request to
# that host and its subdomains for 24 hours, in every process; a block is never re-checked or retried. One rule,
# research/data/blocks.py (fetch_util uses it too), read before every request over the running department's
# FETCH_LOG (DATA's by default; STATS's forward runner passes its own with Fetcher(block_log=...)) and every
# department's FETCH_LOG.jsonl in this checkout. A block is written to block_log.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import blocks  # noqa: E402

BLOCK_LOG = REPO / "research/departments/DATA/FETCH_LOG.jsonl"
OTHER_LOGS_ROOT = REPO                 # where every department's FETCH_LOG.jsonl is read
PUSHED_REPO = None                     # whose origin branches' fetch logs are read (None: REPO, at call time)
BLOCK_STATUSES = blocks.BLOCK_STATUSES
RECHECK_S = 300       # a locked run's ledger state is asked again after 5 minutes (red team 14 Oct: no cache)


def _now_s() -> float:
    return time.time()


def _host(url: str) -> str:
    return (urlsplit(url).hostname or "").lower().rstrip(".")


def record_block(log: Path, url: str, status: int, via: str = "answer") -> None:
    """One FETCH_LOG line for a block: the URL without its query (never a credential), the status."""
    u = urlsplit(url)
    rec = {"utc": datetime.fromtimestamp(_now_s(), timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "source": "oanda_download", "url": f"{u.scheme}://{u.netloc}{u.path}", "status": int(status),
           "bytes": 0, "via": via,
           "note": "block: no request to this host for 24 hours (docs/EDGE_HUNT.md section 5)"}
    Path(log).parent.mkdir(parents=True, exist_ok=True)
    with open(log, "a") as fh:
        fh.write(json.dumps(rec) + "\n")


_KIND_CHECK = """import json, sys
sys.path.insert(0, sys.argv[1])
from research.common import loaders
repo = loaders.Path(sys.argv[2])
k = loaders.open_run_kind(sys.argv[3], repo) if loaders._origin_ok(repo) else None
w = loaders.locked_window(k) if k else None
print(json.dumps({"kind": k, "lo": w[0], "hi": w[1]} if w else {}))
"""
CODE_ROOT = Path(__file__).resolve().parents[2]      # the checkout whose research/common answers


def locked_run_window(ledger_id: str) -> tuple[str, int, int] | None:
    """(kind, lo, hi) when ledger_id is the run id of a pushed, unclosed STATS start line: kind 'holdout',
    'validation' or 'forward_inputs' (research.common.loaders.open_run_kind) and [lo, hi) the ts_utc range that
    run may read past the cutoff (loaders.locked_window); None otherwise (integration check R1 and red team,
    14 Oct 2026), and None when REPO's origin is not the GitHub repo (loaders._origin_ok: a mirror or an
    insteadOf rewrite may hold any start line; STATS locked-runner red team 2).

    Asked in a child process, so this process never imports research.common (whose runtime audit hook would
    then guard every later open here, research/common/audit.py); any failure there means None (refused)."""
    if not isinstance(ledger_id, str) or not LEDGER_ID.match(ledger_id):
        return None
    r = subprocess.run([sys.executable, "-I", "-c", _KIND_CHECK, str(CODE_ROOT), str(REPO), ledger_id],
                       capture_output=True, text=True)
    try:
        d = json.loads(r.stdout.strip()) if r.returncode == 0 else {}
    except ValueError:
        return None
    if d.get("kind") not in ("holdout", "validation", "forward_inputs"):
        return None
    lo, hi = d.get("lo"), d.get("hi")
    if not (isinstance(lo, int) and isinstance(hi, int) and lo < hi):
        return None
    return d["kind"], lo, hi


def check_block_log(path) -> Path:
    """A block log must be a department's own FETCH_LOG.jsonl in this checkout
    (REPO/research/departments/<NAME>/FETCH_LOG.jsonl), where every fetcher here reads it (red team 14 Oct 2026: a
    block written anywhere else was not seen by the next run)."""
    p = Path(path)
    rp, base = p.resolve(), (Path(REPO) / "research" / "departments").resolve()
    if rp.name != "FETCH_LOG.jsonl" or rp.parent.parent != base:
        raise ValueError(f"block_log {p} is not {base}/<department>/FETCH_LOG.jsonl")
    return p


def locked_run_kind(ledger_id: str) -> str | None:
    """The kind of ledger_id's open STATS run, or None (locked_run_window)."""
    w = locked_run_window(ledger_id)
    return w[0] if w else None


def iso(ts: int) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_ts(s: str) -> int:
    # OANDA RFC3339 with nanoseconds, e.g. 2023-12-22T08:00:00.000000000Z
    return int(datetime.strptime(s[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc).timestamp())


def parse_arg_time(s: str) -> int:
    """ISO date or date-time; naive means UTC, an explicit offset is honoured."""
    dt = datetime.fromisoformat(s)
    dt = dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)
    return int(dt.timestamp())


def short_name(inst: str) -> str:
    """File-name stem: the OANDA name without underscores (EUR_USD -> EURUSD, UK10YB_GBP -> UK10YBGBP)."""
    return inst.replace("_", "")


def file_name(name: str, gran: str) -> str:
    return f"{name}_{gran}_BA.csv"


def on_boundary(ts: int, gran: str) -> bool:
    """True when ts is a bar boundary: a UTC multiple for M1/M5/H1, 17:00 New York for H4 and D."""
    if gran not in DAY_ALIGNED:
        return ts % GRAN_S[gran] == 0
    from zoneinfo import ZoneInfo   # stdlib; uses the system tz database
    local = datetime.fromtimestamp(ts, timezone.utc).astimezone(ZoneInfo(ALIGNMENT_TZ))
    return (local.hour, local.minute, local.second) == (DAILY_ALIGNMENT, 0, 0)


def ledger_lines() -> list[str]:
    """Lines of STATS's pushed ledgers (a file missing on the branch gives no lines)."""
    out: list[str] = []
    for rel in LEDGER_FILES:
        r = subprocess.run(["git", "-C", str(REPO), "show", f"{LEDGER_REF}:{rel}"],
                           capture_output=True, text=True)
        if r.returncode == 0:
            out += r.stdout.splitlines()
    return out


def _strings(v):
    if isinstance(v, str):
        yield v
    elif isinstance(v, dict):
        for x in v.values():
            yield from _strings(x)
    elif isinstance(v, list):
        for x in v:
            yield from _strings(x)


def ledger_has_id(ledger_id: str, lines) -> bool:
    """True when some JSON line holds ledger_id as a whole string value (not a substring). Kept for callers
    (STATS's fwd_io); the locked-run gate uses locked_run_kind, which is stricter."""
    for line in lines:
        try:
            obj = json.loads(line)
        except ValueError:
            continue
        if any(x == ledger_id for x in _strings(obj)):
            return True
    return False


def to_row(c: dict) -> list | None:
    if not c.get("complete"):
        return None
    b, a = c["bid"], c["ask"]
    row = [parse_ts(c["time"])] + [float(b[k]) for k in "ohlc"] + [float(a[k]) for k in "ohlc"] + [int(c["volume"])]
    if not (row[3] <= min(row[1], row[4]) and row[2] >= max(row[1], row[4])):
        raise ValueError(f"bad bid bar at {c['time']}")
    if not (row[7] <= min(row[5], row[8]) and row[6] >= max(row[5], row[8])):
        raise ValueError(f"bad ask bar at {c['time']}")
    return row


class _BearerAuth(requests.auth.AuthBase):
    """Adds the OANDA Bearer header at request time, read from OANDA_API_TOKEN then. The token is
    never stored on the Fetcher or its session, so no attribute of a Fetcher holds its value
    (audit finding #15). The session calls HOST (candles); research/departments/DATA/exotics/exotic_list.py also uses
    it for two read-only GETs on the same host (the account list and its instruments), and nowhere else."""

    def __call__(self, r):
        token = os.environ.get(TOKEN_ENV, "").strip()
        if token:
            r.headers["Authorization"] = f"Bearer {token}"
        return r


class Fetcher:
    def __init__(self, gran: str = "M1", max_to: int = CUTOFF, max_fail_cycles: int = 0,
                 locked_run: str | None = None, block_log: Path | None = None, expect_kind: str | None = None):
        if gran not in GRAN_S:
            raise ValueError(f"granularity {gran!r} not supported")
        self.gran = gran
        # Clamp to the locked-data cutoff: no window may end after it (audit finding #15). A window
        # past the cutoff is allowed only for a STATS locked run, whose ledger id must be the run id of a
        # pushed, unclosed STATS start line (locked_run_kind, as main() checks). A hunter who
        # constructs Fetcher("H1", max_to=2**40) is clamped back to the cutoff.
        self.max_to = int(max_to)
        if self.max_to > CUTOFF:
            if not locked_run:
                self.max_to = CUTOFF
            elif not LEDGER_ID.match(locked_run):
                raise ValueError("locked_run must be a plain ledger id (letters, digits, . _ : -)")
        if expect_kind not in (None, "holdout", "validation", "forward_inputs"):
            raise ValueError(f"expect_kind {expect_kind!r} is not holdout, validation or forward_inputs")
        self.expect_kind = expect_kind   # a caller (STATS's forward runner) may require the run's kind
        self._lock = None                 # (ledger id, kind, lo, hi, checked at), this instance only
        self._pushed = None               # (monotonic read time, [(label, text)] or the refusal): pushed logs
        if self.max_to > CUTOFF and locked_run:
            w = locked_run_window(locked_run)
            if w is None:
                raise RuntimeError(f"locked_run {locked_run} is not the run id of a pushed, unclosed STATS "
                                   f"start line ({LEDGER_REF}: {', '.join(LEDGER_FILES)}); refusing a "
                                   "window past the cutoff")
            if expect_kind is not None and w[0] != expect_kind:
                raise RuntimeError(f"locked_run {locked_run} is a {w[0]} run, not {expect_kind}; refused")
            self._lock = (locked_run, *w, _now_s())
        self.locked_run = locked_run if self.max_to > CUTOFF else None
        self.block_log = check_block_log(block_log) if block_log is not None else BLOCK_LOG
        self.max_fail_cycles = max_fail_cycles
        self.cycles = 0
        self.s = requests.Session()
        self.s.auth = _BearerAuth()       # token added per request from the environment, never stored
        self.last = 0.0
        self.fails = 0                    # failures in the whole run (reported at the end)
        self.streak: list[str] = []       # failure kinds since the last cool-down: "5xx" or other
        self.requests = 0

    def _locked_ok(self, start: int | None = None, stop: int | None = None) -> bool:
        """True only when this run carries the run id of an open STATS run and [start, stop)'s part past the
        cutoff lies inside the window that run may read (loaders.locked_window). Checked at REQUEST time (audit
        finding #15): self.locked_run and self.max_to are mutable. The ledger state is asked again when the id
        changed or after RECHECK_S; there is no shared cache (red team 14 Oct 2026)."""
        lr = self.locked_run
        if not lr or not LEDGER_ID.match(lr):
            return False
        lock = self._lock
        if lock is None or lock[0] != lr or _now_s() - lock[4] >= RECHECK_S:
            w = locked_run_window(lr)
            if w is None:
                self._lock = None
                return False
            lock = self._lock = (lr, *w, _now_s())
        _, kind, lo, hi, _t = lock
        if self.expect_kind is not None and kind != self.expect_kind:
            return False
        if start is None or stop is None:
            return True
        return max(int(start), CUTOFF) >= lo and int(stop) <= hi

    def _pushed_logs(self) -> list[tuple[str, str]]:
        """Every department's fetch logs on origin's dept/* and coordinator branches (blocks.pushed_logs: a git
        fetch, then a read of each), read before the first request and again after RECHECK_S; a failed read refuses,
        and the refusal is kept for RECHECK_S, so no git fetch runs again sooner (STATS red team 3, 14 Oct 2026: a
        block logged on another branch reached this checkout only after two merges)."""
        now = time.monotonic()
        if self._pushed is None or now - self._pushed[0] >= RECHECK_S:
            try:
                self._pushed = (now, blocks.pushed_logs(PUSHED_REPO if PUSHED_REPO is not None else REPO))
            except blocks.PushedLogsUnreadable as e:
                self._pushed = (now, f"cannot read the departments' pushed fetch logs ({e}); no request is sent "
                                     "(docs/EDGE_HUNT.md section 5)")
        if isinstance(self._pushed[1], str):
            raise RuntimeError(self._pushed[1])
        return self._pushed[1]

    def params(self, start: int, stop: int) -> dict:
        p = {"granularity": self.gran, "price": "BA", "from": iso(start), "to": iso(stop)}
        if self.gran in DAY_ALIGNED:
            p["dailyAlignment"] = DAILY_ALIGNMENT
            p["alignmentTimezone"] = ALIGNMENT_TZ
        return p

    def _failed(self, kind: str, what: str) -> bool:
        """Record a failure; True means cool down and retry, else raise when the streak is full."""
        self.fails += 1
        self.streak.append(kind)
        if len(self.streak) < MAX_FAILS:
            return False
        if all(k == "5xx" for k in self.streak) and self.cycles < self.max_fail_cycles:
            self.cycles += 1
            print(f"  {what}: {MAX_FAILS} server errors; cooling down {COOLDOWN_S}s "
                  f"(cycle {self.cycles} of {self.max_fail_cycles})", flush=True)
            time.sleep(COOLDOWN_S)
            self.streak = []
            return True
        raise RuntimeError(f"{what} (failure {len(self.streak)} of {MAX_FAILS}); stopping")

    def get(self, inst: str, start: int, stop: int) -> list[dict]:
        """Complete and incomplete candles with start <= time < stop (no `count`: OANDA refuses count with from+to)."""
        if start >= stop:
            raise RuntimeError(f"window {iso(start)}..{iso(stop)} is empty; refused")
        # The locked-data cutoff is a hard wall enforced HERE, per request, so a mutated self.max_to
        # or self.locked_run after construction cannot open it (audit finding #15, red team). A window
        # ending past the cutoff needs a locked-run id proven in a pushed STATS ledger line right now.
        if stop > CUTOFF and not self._locked_ok(start, stop):
            raise RuntimeError(f"window {iso(start)}..{iso(stop)} ends past the locked-data cutoff "
                               f"{iso(CUTOFF)} and is not inside an open STATS run's window; refused")
        if stop > self.max_to:
            raise RuntimeError(f"window {iso(start)}..{iso(stop)} is past this run's limit "
                               f"{iso(self.max_to)}; refused")
        wait = 30.0
        host = _host(HOST)
        logs = [self.block_log] + [p for p in blocks.department_logs(OTHER_LOGS_ROOT)
                                   if p.resolve() != Path(self.block_log).resolve()]
        while True:
            why = blocks.blocked(host, logs, _now_s(), self._pushed_logs())
            if why:
                raise RuntimeError(why)
            gap = self.last + MIN_GAP_S - time.monotonic()
            if gap > 0:
                time.sleep(gap)
            self.last = time.monotonic()
            self.requests += 1
            try:
                # redirects are not followed: a redirected request would skip the block check and the limit
                r = self.s.get(HOST.format(inst=inst), timeout=60, params=self.params(start, stop),
                               allow_redirects=False)
            # a connection reset while the answer is read (ChunkedEncodingError; 14 Oct 2026, GBP_JPY M1 request
            # 67) is a dropped connection too, not a crash
            except (requests.Timeout, requests.ConnectionError, requests.exceptions.ChunkedEncodingError) as e:
                m = re.search(r"Tunnel connection failed:\s*(\d{3})", str(e)) or \
                    re.search(r"\b(407) Proxy Authentication", str(e))
                if isinstance(e, requests.exceptions.ProxyError) and m and int(m.group(1)) in BLOCK_STATUSES:
                    # the egress proxy refused (/root/.ccr/README.md: never retry or route around it): a block
                    self.fails += 1
                    record_block(self.block_log, HOST.format(inst=inst), int(m.group(1)), via="proxy")
                    raise RuntimeError(f"the proxy answered {m.group(1)} for {host}; blocked, no request to it for "
                                       "24 hours (docs/EDGE_HUNT.md section 5); tell the coordinator") from e
                # a stalled or dropped connection counts as a failure and is retried after a back-off
                try:
                    self._failed("conn", f"{type(e).__name__} for {inst} from {iso(start)}")
                except RuntimeError as stop_err:
                    raise stop_err from e
                print(f"  {type(e).__name__}; waiting {wait:.0f}s (failure {len(self.streak)} of {MAX_FAILS})",
                      flush=True)
                time.sleep(wait)
                wait *= 2
                continue
            if r.status_code == 200:
                return r.json()["candles"]
            server = 500 <= r.status_code < 600
            what = f"HTTP {r.status_code} for {inst} from {iso(start)}"
            if r.status_code in BLOCK_STATUSES:
                # a block: never retried, never waited out here (Retry-After is not honoured by retrying)
                self.fails += 1
                record_block(self.block_log, HOST.format(inst=inst), r.status_code)
                raise RuntimeError(f"{what}: blocked; no request to {host} for 24 hours, logged in "
                                   f"{self.block_log} (docs/EDGE_HUNT.md section 5); tell the coordinator")
            if 300 <= r.status_code < 400:
                self.fails += 1
                raise RuntimeError(f"{what}: a redirect, not followed (only {host} candles are requested); stopping")
            if not server:
                self.fails += 1
                self.streak.append("4xx")
                raise RuntimeError(f"{what} (failure {len(self.streak)} of {MAX_FAILS}); stopping")
            if self._failed("5xx" if server else "4xx", what):
                wait = 30.0
                continue
            ra = r.headers.get("Retry-After")
            try:
                pause = max(wait, float(ra)) if ra else wait
            except ValueError:
                pause = wait
            print(f"  HTTP {r.status_code}; waiting {pause:.0f}s", flush=True)
            time.sleep(pause)
            wait *= 2


def last_saved(path: Path) -> int | None:
    """Timestamp of the last complete row. A partial last line (no trailing newline, e.g. after a
    crash mid-write) is cut off first, so a resume never appends to it."""
    if not path.exists() or path.stat().st_size == 0:
        return None
    with path.open("r+b") as f:
        size = f.seek(0, 2)
        pos, keep = size, None
        f.seek(size - 1)
        if f.read(1) == b"\n":
            keep = size
        while keep is None and pos > 0:          # search back for the last newline
            lo = max(0, pos - 4096)
            f.seek(lo)
            chunk = f.read(pos - lo)
            i = chunk.rfind(b"\n")
            if i >= 0:
                keep = lo + i + 1
            pos = lo
        keep = keep or 0
        if keep < size:
            f.truncate(keep)
            print(f"  {path.name}: dropped a partial last line ({size - keep} bytes)", flush=True)
        if keep == 0:
            return None
        f.seek(max(0, keep - 4096))
        lines = f.read(keep - max(0, keep - 4096)).decode().strip().splitlines()
    tail = lines[-1].split(",")[0] if lines else ""
    return int(tail) if tail.isdigit() else None


def download(fx, name: str, inst: str, out: Path, start: int, end: int) -> int:
    gran = getattr(fx, "gran", "M1")
    g = GRAN_S[gran]
    path = out / file_name(name, gran)
    prev = last_saved(path)
    new_file = prev is None and (not path.exists() or path.stat().st_size == 0)
    if prev is None and not new_file:
        with path.open(newline="") as f:
            body = list(csv.reader(f))
        if body != [COLS]:
            raise RuntimeError(f"{path.name}: last row unreadable; check the file by hand")
    # UTC-aligned bars resume at the next bar; day-aligned bars (H4, D) move with New York's clock,
    # so they resume one second after the last bar and the duplicate is filtered below.
    cur = start if prev is None else prev + (1 if gran in DAY_ALIGNED else g)
    n = 0
    with path.open("a", newline="") as f:
        w = csv.writer(f)
        if new_file:
            w.writerow(COLS)
        while cur < end:
            stop = min(end, cur + COUNT * g)       # at most COUNT candles of this granularity, never past --to
            candles = fx.get(inst, cur, stop)
            rows = [r for r in (to_row(c) for c in candles) if r is not None and r[0] < end]
            if gran != "M1":   # includeFirst returns the bar covering `from` (M1 kept as before, byte-identical)
                rows = [r for r in rows if r[0] >= start]
            if prev is not None:
                rows = [r for r in rows if r[0] > prev]
            w.writerows(rows)
            f.flush()
            n += len(rows)
            if rows:
                prev = rows[-1][0]
            if (candles and not candles[-1].get("complete")) or stop > time.time():
                break  # reached the live edge
            cur = stop
            done = min(1.0, max(0.0, ((prev or cur) - start) / max(1, end - start)))
            print(f"  {name}: {n} bars, up to {iso(prev or cur)} ({done:.0%} of the period, "
                  f"request {fx.requests})", flush=True)
    return n


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("data_dir")
    ap.add_argument("--from", dest="start", default="2023-12-01")
    ap.add_argument("--to", dest="end", default=DEFAULT_TO)
    ap.add_argument("--pairs", default=None, help=f"comma list of {', '.join(PAIRS)} (default both)")
    ap.add_argument("--instruments", default=None, help="comma list of OANDA names, e.g. EUR_USD,USD_JPY")
    ap.add_argument("--granularity", default="M1", choices=list(GRAN_S))
    ap.add_argument("--max-fail-cycles", type=int, default=0,
                    help="after 3 HTTP 5xx failures, cool down 5 minutes and resume, at most this many times")
    ap.add_argument("--locked-run", default=None, help="STATS ledger id; required for --to after the cutoff")
    ap.add_argument("--expect-kind", default=None, choices=["holdout", "validation", "forward_inputs"],
                    help="refuse unless --locked-run is an open run of this kind")
    ap.add_argument("--block-log", default=None,
                    help="the running department's FETCH_LOG.jsonl for a 403/429 block (default: DATA's)")
    a = ap.parse_args(argv)
    if a.pairs is not None and a.instruments is not None:
        ap.error("give --pairs or --instruments, not both")
    if a.instruments is not None:
        insts = [p.strip().upper() for p in a.instruments.split(",") if p.strip()]
        unknown = [p for p in insts if p not in INSTRUMENTS]
        if unknown or not insts:
            ap.error(f"--instruments takes a comma list of {', '.join(INSTRUMENTS)}; got {a.instruments!r}")
        jobs = [(short_name(i), i) for i in insts]
    else:
        pairs = a.pairs if a.pairs is not None else ",".join(PAIRS)
        names = [p.strip().upper() for p in pairs.split(",") if p.strip()]
        unknown = [p for p in names if p not in PAIRS]
        if unknown or not names:
            ap.error(f"--pairs takes a comma list of {', '.join(PAIRS)}; got {pairs!r}")
        jobs = [(n, PAIRS[n]) for n in names]
    if a.max_fail_cycles < 0:
        ap.error("--max-fail-cycles must be 0 or more")
    gran = a.granularity
    start, end = parse_arg_time(a.start), parse_arg_time(a.end)
    if start >= end:
        ap.error("--from must be before --to")
    if not on_boundary(end, gran):
        ap.error(f"--to {iso(end)} is not a {gran} bar boundary"
                 + (" (H4 and D need 17:00 New York)" if gran in DAY_ALIGNED else ""))
    if a.locked_run is not None and not LEDGER_ID.match(a.locked_run):
        ap.error("--locked-run takes a plain ledger id (letters, digits, . _ : -)")
    if end > CUTOFF and a.locked_run is None:
        ap.error(f"--to {iso(end)} is after the locked-data cutoff {iso(CUTOFF)}; "
                 "only STATS's logged locked runs may pass --locked-run <ledger id>")
    if end > CUTOFF:
        w = locked_run_window(a.locked_run)
        if w is None:
            ap.error(f"--locked-run {a.locked_run} is not the run id of a pushed, unclosed STATS start line "
                     f"({LEDGER_REF}: {', '.join(LEDGER_FILES)}); STATS pushes its start line first")
        kind, lo, hi = w
        if a.expect_kind is not None and kind != a.expect_kind:
            ap.error(f"--locked-run {a.locked_run} is a {kind} run, not {a.expect_kind}")
        if max(start, CUTOFF) < lo or end > hi:
            ap.error(f"--from {iso(start)} --to {iso(end)} is outside what a {kind} run may read past the cutoff "
                     f"({iso(lo)} .. {iso(hi)})")
    out = Path(a.data_dir)
    out.mkdir(parents=True, exist_ok=True)
    if a.locked_run is not None:
        print(f"LOCKED RUN, ledger id {a.locked_run}: window up to {iso(end)}", flush=True)
    with (out / "DOWNLOAD_LOG.jsonl").open("a") as log:
        log.write(json.dumps({"utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                              "instruments": [i for _, i in jobs], "granularity": gran,
                              "from_ts": start, "to_ts": end, "locked_run": a.locked_run}) + "\n")
    # end <= CUTOFF for a normal run; a locked run passes its validated id so the clamp keeps `end`.
    if a.block_log:
        try:
            check_block_log(a.block_log)
        except ValueError as exc:
            ap.error(str(exc))
    fx = Fetcher(gran=gran, max_to=end, max_fail_cycles=a.max_fail_cycles, locked_run=a.locked_run,
                 block_log=Path(a.block_log) if a.block_log else None, expect_kind=a.expect_kind)
    for name, inst in jobs:
        n = download(fx, name, inst, out, start, end)
        print(f"{name}: {n} new bars", flush=True)
    print(f"requests: {fx.requests}, failures: {fx.fails}, cool-downs: {fx.cycles}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
