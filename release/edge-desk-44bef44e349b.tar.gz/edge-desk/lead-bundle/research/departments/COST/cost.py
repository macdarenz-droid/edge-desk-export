"""COST: the cost hook's reference implementation for COST_MODEL.json (v2). Prices costs only; places no orders.

    from cost import CostModel
    cm = CostModel.load("research/departments/COST/COST_MODEL.json", release_ts={"EURUSD": [...], "GBPUSD": [...]})
    net = cm.net_pips("EURUSD", side=+1, entry_price=..., exit_price=..., entry_spread=..., exit_spread=...,
                      entry_ts=..., exit_ts=..., entry_kind="market", exit_kind="stop", freezing=True)

- entry_price / exit_price: the actual bid/ask fill prices (buy at ask, sell at bid), as the hunt's simulator fills them.
- entry_spread / exit_spread: ask - bid in pips of the quote at each fill moment (the bar open for an open fill,
  the fill bar's quote for a limit or stop). actual round-trip spread against mid = (entry_spread + exit_spread) / 2.
- net = side * (exit_price - entry_price) / pip - max(0, floor_total - actual) - slippage.
  So a hunter's bid/ask P&L is topped up to the floor when the floor is higher, and slippage is always added.
- Timestamps: unix seconds UTC of the fill bar's open. A close exit: pass exit_ts = the bar's open and
  exit_time = its real fill time (bar open + bar_sec); the window floor and slippage apply at exit_time too.
- signal_ts: when the signal was taken, if earlier than decision_ts (a 17:00 roll executed at 17:15). decision_ts (default entry_ts): the window rules apply
  if either the decision or the fill falls in a release or rollover window (docs/EDGE_HUNT.md section 4 item 3).
- release_ts: top-tier release times (EVENTS' calendar), one list for all pairs or a dict by pair. Record the
  calendar file's sha256 in FROZEN.json. An empty list is refused unless allow_no_releases=True.
"""
try:  # first: DATA's runtime audit hook is active before anything runs (research.common may exec this file: no __file__)
    import research.common  # noqa: F401
except ModuleNotFoundError:
    import os as _os
    import sys as _sys
    _sys.path.insert(1, _os.path.abspath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "..", "..")))
    import research.common  # noqa: F401
import bisect, json
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

NY = ZoneInfo("America/New_York")
KINDS = {"market", "limit", "stop", "target", "time", "cut"}  # time / cut: market exits at a set time or era end
SLIP_KINDS = {"market", "stop", "time", "cut"}
EURUSD_FLOOR = 2.0  # docs/EDGE_HUNT.md section 4 item 3: EUR/USD never below 2.0 pips a round trip, whatever the file says


def pair_key(pair):
    """'EUR_USD', 'eurusd', 'EUR/USD' -> 'EURUSD' (the model's keys)."""
    return str(pair).replace("_", "").replace("/", "").strip().upper()
ROLL_START, ROLL_END = 16 * 60 + 55, 17 * 60 + 15


class ClosedMarket(ValueError):
    pass


class FrozenPlaceholder(ValueError):
    pass


def vol_from_mid_close(ts, mid_close, pip):
    """Volatility level at each bar: mean |change of M1 mid close| (pips) over the previous 60 one-minute changes,
    using only changes between consecutive minutes (no weekend or gap jumps); needs 30; excludes the current bar."""
    ts = np.asarray(ts, dtype=np.int64)
    mid_close = np.asarray(mid_close, dtype=float)
    d = np.abs(np.diff(mid_close, prepend=np.nan)) / pip
    d[np.r_[True, np.diff(ts) != 60]] = np.nan
    return pd.Series(d).rolling(60, min_periods=30).mean().shift(1).to_numpy()


class CostModel:
    def __init__(self, model, release_ts, allow_no_releases=False, unmeasured_release_ts=(), info=None):
        if model.get("version", 1) < 2:
            raise ValueError("cost.py needs COST_MODEL.json version 2 or later")
        self.m = model
        self.info = dict(info or {})
        self.closed = set(model["closed_hows"])
        if isinstance(release_ts, dict):
            self.rel = {pair_key(k): sorted(int(x) for x in v) for k, v in release_ts.items()}
        else:
            lst = sorted(int(x) for x in release_ts)
            self.rel = {k: lst for k in model["pairs"]}
        if isinstance(unmeasured_release_ts, dict):
            self.unmeas = {pair_key(k): sorted(int(x) for x in v) for k, v in unmeasured_release_ts.items()}
        else:
            lst = sorted(int(x) for x in unmeasured_release_ts)
            self.unmeas = {k: lst for k in model["pairs"]}
        self.allow_no_releases = allow_no_releases
        if not allow_no_releases and not any(self.rel.get(k) for k in model["pairs"]):
            raise ValueError("release_ts is empty: pass EVENTS' calendar, or allow_no_releases=True for a non-judging run")

    @classmethod
    def load(cls, path, release_ts, allow_no_releases=False, unmeasured_release_ts=()):
        with open(path) as f:
            return cls(json.load(f), release_ts, allow_no_releases, unmeasured_release_ts)

    @staticmethod
    def how_mod(ts):
        t = datetime.fromtimestamp(int(ts), tz=timezone.utc).astimezone(NY)
        return t.weekday() * 24 + t.hour, t.hour * 60 + t.minute

    @staticmethod
    def _offset(r, ts, bar_sec=60):
        """Minutes from the nearest time in r (bar open - release), if within -5..+5, else None.
        For a bar longer than M5 stamped at its open, a release anywhere in [ts - 300, ts + bar_sec + 300) counts as 0."""
        ts = int(ts)
        if bar_sec > 300:
            i = bisect.bisect_left(r, ts - 300)
            if i < len(r) and r[i] < ts + bar_sec + 300:
                return 0
            return None
        i = bisect.bisect_left(r, ts)
        best = None
        for j in (i - 1, i):
            if 0 <= j < len(r):
                off = (ts - r[j]) // 60
                if -5 <= off <= 5 and (best is None or abs(off) < abs(best)):
                    best = off
        return best

    @staticmethod
    def _offsets(r, ts, bar_sec=60):
        """Every offset (minutes, -5..+5) to a time in r; [0] for a bar longer than M5 holding one (see _offset)."""
        ts = int(ts)
        if bar_sec > 300:
            return [0] if CostModel._offset(r, ts, bar_sec) is not None else []
        i, out = bisect.bisect_left(r, ts - 360), []
        while i < len(r) and r[i] <= ts + 360:
            off = (ts - r[i]) // 60
            if -5 <= off <= 5:
                out.append(off)
            i += 1
        return out

    def release_offset(self, pair, ts, bar_sec=60):
        return self._offset(self.rel.get(pair_key(pair), []), ts, bar_sec)

    def unmeasured_offset(self, pair, ts, bar_sec=60):
        """Offset to the nearest unmeasured event: the caller's unmeasured_release_ts, or a model rule window
        (unknown_event_windows: events with no dated times, e.g. RBNZ decisions, at every weekday's candidate times)."""
        off = self._offset(self.unmeas.get(pair_key(pair), []), ts, bar_sec)
        return off if off is not None else self._rule_hit(pair, ts, bar_sec)[0]

    def _rule_hit(self, pair, ts, bar_sec=60):
        """(offset, rule) for the first unknown_event_windows rule whose window holds ts, else (None, None)."""
        pair = pair_key(pair)
        for rule in self.m.get("unknown_event_windows", []):
            if rule["ccy"] not in (pair[:3], pair[3:]):
                continue
            tz = ZoneInfo(rule["tz"])
            local = datetime.fromtimestamp(int(ts), tz=timezone.utc).astimezone(tz)
            cands = []
            for dd in (-1, 0, 1):
                day = (local + pd.Timedelta(days=dd)).date()
                if day.weekday() >= 5:
                    continue
                for hm in rule["local_times"]:
                    h, mi = (int(x) for x in hm.split(":"))
                    cands.append(int(datetime(day.year, day.month, day.day, h, mi, tzinfo=tz).timestamp()))
            off = self._offset(sorted(cands), ts, bar_sec)
            if off is not None:
                return off, rule
        return None, None

    def _precoverage_hit(self, pair, t, b):
        """True when a fill (its bar's whole span) sits before a currency's calendar coverage start and within
        precoverage_pad_min minutes of one of that economy's local release times."""
        p = self.m["pairs"][pair]
        pad = 60 * int(self.m.get("precoverage_pad_min", 30))
        for c in p.get("coverage_by_ccy", {}).values():
            if t >= c["start_ts"]:
                continue
            tz = ZoneInfo(c["tz"])
            local = datetime.fromtimestamp(int(t), tz=timezone.utc).astimezone(tz)
            for dd in (-1, 0, 1):
                day = (local + pd.Timedelta(days=dd)).date()
                for hm in c["local_times"]:
                    h, mi = (int(x) for x in hm.split(":"))
                    r = int(datetime(day.year, day.month, day.day, h, mi, tzinfo=tz).timestamp())
                    if t - pad < r < t + max(int(b), 0) + pad:
                        return True
        return False

    def _precoverage_ok(self, pair, legs, charged=False):
        """Before a currency's calendar coverage starts, every leg before it must sit at least precoverage_pad_min
        minutes from each local release time of that economy (the fill bar's whole span counts). With
        precoverage_rule 'charge' (charged=True) such legs pay the precoverage floor instead; a currency with no
        local-time grid still fails closed."""
        p = self.m["pairs"][pair]
        if "coverage_by_ccy" not in p:
            return not (p.get("coverage_start_ts") and min(t for t, _ in legs) < p["coverage_start_ts"])
        missing = [c for c in (pair[:3], pair[3:]) if c != "USD" and c not in p["coverage_by_ccy"]]
        if missing and p.get("coverage_start_ts") and min(t for t, _ in legs) < p["coverage_start_ts"]:
            return False  # a currency with no local-time grid keeps the blanket refusal (fails closed)
        return charged or not any(self._precoverage_hit(pair, t, b) for t, b in legs)

    def _precoverage_floor(self, pair):
        """Spread floor inside a precoverage window (precoverage_rule 'charge'): the unmeasured-event multiplier times
        the pair's worst release-offset floor, or its worst unmeasured floor if higher (every weekday's local release
        times are charged, release or not)."""
        p = self.m["pairs"][pair]
        return max(self.m.get("unmeasured_event_multiplier", 2.0) * max(p["release_floor_by_offset"].values()),
                   max(p.get("unmeasured_floor_by_offset", {"x": 0.0}).values()))

    def _window_floor(self, pair, ts, bar_sec=60):
        pair = pair_key(pair)
        p = self.m["pairs"][pair]
        f = 0.0
        if p["status"] == "measured":
            for off in self._offsets(self.rel.get(pair, []), ts, bar_sec):  # red team v3.4: every release in reach,
                f = max(f, p["release_floor_by_offset"][str(off)])  # not only the nearest (denser lists never lower it)
            off = self.unmeasured_offset(pair, ts, bar_sec)
            if off is not None:
                f = max(f, self.m.get("unmeasured_event_multiplier", 2.0) * p["release_floor_by_offset"][str(off)],
                        p.get("unmeasured_floor_by_offset", {}).get(str(off), 0.0))
            off, rule = self._rule_hit(pair, ts, bar_sec)
            if off is not None and pair in rule.get("floor_by_pair", {}):
                f = max(f, float(rule["floor_by_pair"][pair]))
        if self.m.get("precoverage_rule") == "charge" and self._precoverage_hit(pair, ts, bar_sec):
            f = max(f, self._precoverage_floor(pair))  # any status (red team: fails closed on a missing floor)
        _, mod = self.how_mod(ts)
        if ROLL_START <= mod < ROLL_END:
            b = ROLL_START + 5 * ((mod - ROLL_START) // 5)
            f = max(f, p["rollover_floor_by_5min"].get(f"{b // 60:02d}:{b % 60:02d}", p["rollover_floor"])
                    if "rollover_floor_by_5min" in p else p["rollover_floor"])
        return f

    def leg(self, pair, ts, vol=None, decision_ts=None, bar_sec=60):
        pair = pair_key(pair)
        p = self.m["pairs"][pair]
        how, _ = self.how_mod(ts)
        if how in self.closed:
            raise ClosedMarket(f"{pair} {ts}: market closed (NY hour of week {how})")
        if p["status"] == "placeholder":
            f = p["flat_floor_all_hours"]
        else:
            f = p["floor_by_how"].get(str(how), p["max_floor"])
            cells = {k: v for k, v in p.get("floor_by_how_vol", {}).items() if k.split("|")[0] == str(how)}
            vb = self.vol_bin(p, vol)
            key = f"{how}|{vb}"
            if vb is not None and key in cells:
                f = max(f, cells[key])
            elif cells:  # unknown volatility, or a thin cell: the hour's worst volatility cell
                f = max(f, max(cells.values()))
            elif "vol_uplift_by_how" in p:  # no M1 cells for this pair: the M1 pairs' worst-cell ratio
                f = f * p["vol_uplift_by_how"].get(str(how), 1.0)
        f = max(f, self._window_floor(pair, ts, bar_sec))
        if decision_ts is not None:
            f = max(f, self._window_floor(pair, decision_ts))
        return 0.5 * f

    @staticmethod
    def vol_bin(p, vol):
        if vol is None or (isinstance(vol, float) and np.isnan(vol)) or "vol_cuts" not in p:
            return None
        a, b = p["vol_cuts"]
        return 0 if vol < a else (1 if vol < b else 2)

    def slip(self, pair, ts, kind, decision_ts=None, bar_sec=60, signal_ts=None):
        """Slippage (pips) for one fill. decision_ts / signal_ts (or a close exit's fill time): a release or
        rollover window at any of them gives that window's slippage."""
        if kind not in KINDS:
            raise ValueError(f"unknown fill kind {kind!r}; use one of {sorted(KINDS)}")
        if kind not in SLIP_KINDS:
            return 0.0
        pair = pair_key(pair)
        p = self.m["pairs"][pair]
        if p["status"] == "placeholder":
            return p.get("slip_placeholder", 1.0)
        times = [(ts, bar_sec)] + [(t, 60) for t in (decision_ts, signal_ts) if t is not None]
        pre = self.m.get("precoverage_rule") == "charge" and any(self._precoverage_hit(pair, x, b) for x, b in times)
        if pre or any(self.unmeasured_offset(pair, x, b) is not None for x, b in times):
            return max(p["slip_release"], p.get("slip_unmeasured", 0.0))  # precoverage: as an unmeasured event
        if any(self.release_offset(pair, x, b) is not None for x, b in times):
            return p["slip_release"]
        if any(ROLL_START <= self.how_mod(x)[1] < ROLL_END for x, _ in times):
            return p["slip_rollover"]
        return p["slip_normal"]

    def pair_min(self, pair):
        k = pair_key(pair)
        v = float(self.m["pairs"][k].get("pair_min", 0.0))
        return max(v, EURUSD_FLOOR) if k == "EURUSD" else v

    def charge(self, pair, entry_ts, exit_ts, actual_round_trip, *, entry_kind, exit_kind, freezing,
               decision_ts=None, vol_entry=None, vol_exit=None, bar_sec=60, signal_ts=None, exit_time=None):
        """Pips to charge per round trip: max(actual spread against mid, floor_total, pair_min) + slippage.
        bar_sec: the length of the bars whose open stamps the fills (60 for M1).
        decision_ts, signal_ts: window floors (release, rollover) on the entry leg if higher.
        exit_time: the exit's real fill time when it differs from exit_ts (a bar-close exit): window floor on the exit leg."""
        pair = pair_key(pair)
        dts = entry_ts if decision_ts is None else decision_ts
        extra = [t for t in (signal_ts, exit_time) if t is not None]
        self._guard(pair, [(entry_ts, bar_sec), (exit_ts, bar_sec), (dts, 60)] + [(t, 60) for t in extra], freezing)
        le = self.leg(pair, entry_ts, vol_entry, dts, bar_sec)
        if signal_ts is not None:
            le = max(le, 0.5 * self._window_floor(pair, signal_ts))
        lx = self.leg(pair, exit_ts, vol_exit, None, bar_sec)
        if exit_time is not None:
            lx = max(lx, 0.5 * self._window_floor(pair, exit_time))
        spread = max(float(actual_round_trip), le + lx, self.pair_min(pair))
        return spread + self.slip(pair, entry_ts, entry_kind, dts, bar_sec, signal_ts) + self.slip(pair, exit_ts, exit_kind, exit_time, bar_sec)

    def _guard(self, pair, legs, freezing):
        """Refusals shared by charge() and leg_charge(): unmeasured pair, release-list coverage, unmeasured events
        and provisional (hourly-only) windows when freezing. legs: [(ts, bar_sec), ...]."""
        p = self.m["pairs"][pair]
        if freezing and p["status"] != "measured":
            raise FrozenPlaceholder(f"{pair}: cost not measured; cannot freeze")
        if freezing and p.get("freeze_blocked"):
            raise FrozenPlaceholder(f"{pair}: {p['freeze_blocked']}")
        if freezing and not self._precoverage_ok(pair, legs, self.m.get("precoverage_rule") == "charge"):
            raise FrozenPlaceholder(f"{pair}: before its release calendar coverage starts and within "
                                    f"{self.m.get('precoverage_pad_min', 30)} minutes of a local release time; cannot freeze")
        rel = self.rel.get(pair, [])
        if freezing and not rel:
            raise ValueError(f"{pair}: no release list; a frozen pick needs one")
        if rel and max(t for t, _ in legs) > rel[-1] + 45 * 86400:
            raise ValueError(f"{pair}: trade after the release list ends ({rel[-1]}); pass a list that covers it")
        if freezing:
            for t, b in legs:
                if self._offset(self.unmeas.get(pair, []), t, b) is not None:
                    raise FrozenPlaceholder(f"{pair}: within 5 minutes of an unmeasured event; cannot freeze")
                off, rule = self._rule_hit(pair, t, b)
                if off is not None and pair not in rule.get("floor_by_pair", {}):
                    raise FrozenPlaceholder(f"{pair}: within 5 minutes of {rule['event']} (no measured worst-case floor); cannot freeze")
                if p.get("windows_provisional") and self._precoverage_hit(pair, t, b):  # red team: hourly floors only
                    raise FrozenPlaceholder(f"{pair}: precoverage window with only provisional (hourly) release floors; cannot freeze")
                if p.get("windows_provisional") and (self.release_offset(pair, t, b) is not None
                                                     or ROLL_START <= self.how_mod(t)[1] < ROLL_END):
                    raise FrozenPlaceholder(f"{pair}: release/rollover floor only provisional (hourly bars); cannot freeze a trade in that window")

    # ---- array interface (the shared hook research.common.cost re-exports this class) ----
    def round_trip(self, pair, entry_ts, exit_ts, spread_paid_pips, entry_kind="market", exit_kind="market",
                   vol_entry=None, vol_exit=None, decision_ts=None, freezing=False, signal_ts=None,
                   exit_time=None, bar_sec=60):
        """charge() over arrays (one value per trade); scalars broadcast. Returns a float array of pips."""
        e = np.atleast_1d(np.asarray(entry_ts, dtype=np.int64))
        n = len(e)

        def col(x, dtype=object):
            if x is None:
                return [None] * n
            a = np.atleast_1d(np.asarray(x, dtype=dtype))
            return list(np.broadcast_to(a, (n,)))
        x = col(exit_ts, np.int64)
        sp = col(spread_paid_pips, float)
        ek, xk = col(entry_kind), col(exit_kind)
        ve, vx = col(vol_entry, float), col(vol_exit, float)
        d, s, xt = col(decision_ts), col(signal_ts), col(exit_time)
        out = np.empty(n)
        for i in range(n):
            out[i] = self.charge(pair, int(e[i]), int(x[i]), float(sp[i]), entry_kind=ek[i], exit_kind=xk[i],
                                 freezing=freezing, decision_ts=None if d[i] is None else int(d[i]),
                                 vol_entry=None if ve[i] is None else float(ve[i]),
                                 vol_exit=None if vx[i] is None else float(vx[i]), bar_sec=bar_sec,
                                 signal_ts=None if s[i] is None else int(s[i]),
                                 exit_time=None if xt[i] is None else int(xt[i]))
        return out

    def leg_charge(self, pair, ts, half_spread_paid_pips, kind="market", vol=None, decision_ts=None,
                   signal_ts=None, bar_sec=60, freezing=False):
        """One leg (a size change in a position book), over arrays: max(actual half spread paid, leg floor
        with decision/signal windows, pair_min / 2) + slippage."""
        pair = pair_key(pair)
        t = np.atleast_1d(np.asarray(ts, dtype=np.int64))
        n = len(t)

        def col(x, dtype=object):
            if x is None:
                return [None] * n
            return list(np.broadcast_to(np.atleast_1d(np.asarray(x, dtype=dtype)), (n,)))
        h, k, v, d, s = col(half_spread_paid_pips, float), col(kind), col(vol, float), col(decision_ts), col(signal_ts)
        out = np.empty(n)
        for i in range(n):
            self._guard(pair, [(int(t[i]), bar_sec)] + [(int(z), 60) for z in (d[i], s[i]) if z is not None], freezing)
            f = self.leg(pair, int(t[i]), None if v[i] is None else float(v[i]),
                         None if d[i] is None else int(d[i]), bar_sec)
            if s[i] is not None:
                f = max(f, 0.5 * self._window_floor(pair, int(s[i])))
            out[i] = max(float(h[i]), f, 0.5 * self.pair_min(pair)) + self.slip(
                pair, int(t[i]), k[i], None if d[i] is None else int(d[i]), bar_sec, None if s[i] is None else int(s[i]))
        return out

    def net_pips(self, pair, *, side, entry_price, exit_price, entry_spread, exit_spread, entry_ts, exit_ts,
                 entry_kind, exit_kind, freezing, decision_ts=None, vol_entry=None, vol_exit=None, bar_sec=60,
                 signal_ts=None, exit_time=None):
        if side not in (1, -1):
            raise ValueError("side is +1 (long) or -1 (short)")
        pip = self.m["pairs"][pair_key(pair)]["pip"]
        bidask = side * (exit_price - entry_price) / pip
        actual = (float(entry_spread) + float(exit_spread)) / 2
        c = self.charge(pair, entry_ts, exit_ts, actual, entry_kind=entry_kind, exit_kind=exit_kind, freezing=freezing,
                        decision_ts=decision_ts, vol_entry=vol_entry, vol_exit=vol_exit, bar_sec=bar_sec,
                        signal_ts=signal_ts, exit_time=exit_time)
        return bidask - (c - actual)


def financing_rolls(entry_ts, exit_ts, triple_day=2):
    """The 17:00 New York rolls in (entry_ts, exit_ts], Monday to Friday, as (roll_ts, days charged): 3 at the
    triple_day roll (2 = Wednesday, OANDA; USD/CAD: also run 3 = Thursday and charge the worse), 1 otherwise.
    Holidays not modelled (the weekly total stays 7)."""
    t0 = datetime.fromtimestamp(int(entry_ts), tz=timezone.utc).astimezone(NY)
    t1 = datetime.fromtimestamp(int(exit_ts), tz=timezone.utc).astimezone(NY)
    day = t0.date()
    out = []
    while True:
        roll = datetime(day.year, day.month, day.day, 17, 0, tzinfo=NY)
        if roll > t1:
            break
        if roll > t0 and roll.weekday() < 5:
            out.append((int(roll.timestamp()), 3 if roll.weekday() == triple_day else 1))
        day = day + pd.Timedelta(days=1)
    return out


def financing_nights(entry_ts, exit_ts, triple_day=2):
    """Days of financing charged between entry_ts and exit_ts (see financing_rolls)."""
    return sum(d for _, d in financing_rolls(entry_ts, exit_ts, triple_day))


def financing_pips(model, pair, side, price, entry_ts, exit_ts, diff_against, markup_pct_year=None):
    """Financing cost in pips (positive = a cost, negative = a credit) for one unit held from entry_ts to exit_ts.
    diff_against(roll_ts) -> the policy-rate differential AGAINST the position's side, % a year, at that roll
    (positive when the side pays carry). Charged: days x price x (diff_against + markup) / 365 / pip, markup per
    position (COST_MODEL financing.markup_pct_year; markup_pct_year overrides it for a sensitivity row).
    USD/CAD: the worse of a Wednesday and a Thursday triple roll."""
    pair = pair_key(pair)
    if side not in (1, -1):
        raise ValueError("side is +1 (long) or -1 (short)")
    pip = model["pairs"][pair]["pip"]
    mk = float(model["financing"]["markup_pct_year"] if markup_pct_year is None else markup_pct_year)

    def total(triple_day):
        s = 0.0
        for roll, days in financing_rolls(entry_ts, exit_ts, triple_day):
            s += days * float(price) * (float(diff_against(roll)) + mk) / 100.0 / 365.0 / pip
        return s
    return max(total(2), total(3)) if pair == "USDCAD" else total(2)


def policy_rate_lookup(df):
    """Callables (rate, rate_range) over DATA's data/macro policy_rates_daily table (columns ccy, effective_date, rate,
    rate_lo, rate_hi, release_utc_latest): the value in force on ts's date as known at ts (released at or before ts).
    A currency or date with no released value returns None, so financing_rows raises instead of assuming."""
    d = df.copy()
    d["eff"] = (pd.to_datetime(d.effective_date, utc=True) - pd.Timestamp(0, tz="UTC")) // pd.Timedelta(seconds=1)
    d["rel"] = (pd.to_datetime(d.release_utc_latest, utc=True) - pd.Timestamp(0, tz="UTC")) // pd.Timedelta(seconds=1)
    by = {k: g.sort_values("eff") for k, g in d.groupby("ccy")}

    def _row(ccy, ts):
        g = by.get(ccy)
        if g is None:
            return None
        day = int(ts) - int(ts) % 86400
        ok = g[(g.eff <= day) & (g.rel <= int(ts))]
        return None if ok.empty else ok.iloc[-1]

    def rate(ccy, ts):
        r = _row(ccy, ts)
        return None if r is None else float(r.rate)

    def rate_range(ccy, ts):
        """The as-known range, widened by the range in force on ts's date (a rate change announced later that day,
        e.g. CAD at 10:00 Toronto with a next-day release stamp): a cost charged at the worse of the two."""
        r = _row(ccy, ts)
        if r is None:
            return None
        lo, hi = float(r.rate_lo), float(r.rate_hi)
        g = by.get(ccy)
        day = int(ts) - int(ts) % 86400
        same = g[g.eff == day]
        if not same.empty:
            lo, hi = min(lo, float(same.iloc[-1].rate_lo)), max(hi, float(same.iloc[-1].rate_hi))
        return lo, hi
    return rate, rate_range


def financing_rows(model, pair, side, entry_ts, exit_ts, price, rate, *, freezing=False, rate_range=None, markup_pct_year=None):
    """One row per 17:00 New York roll held in (entry_ts, exit_ts]: (roll_ts, days charged, pips), pips per unit of
    base currency, positive = paid by the position. rate(ccy, ts) -> the policy rate in % a year announced before ts
    (DATA's data/macro as-of series); a missing rate raises. Differential against the side: long pays the quote
    currency's rate and earns the base's, so diff_against = rate(quote) - rate(base); short the reverse.
    rate_range(ccy, ts) -> (lo, hi), if given: the end of each currency's range that hurts the position is used
    (EDGE_HUNT 4.3); policy_rate_lookup() builds both from DATA's policy_rates_daily.
    Charged: days x price x (diff_against + markup) / 365 / pip, markup = COST_MODEL financing.markup_pct_year (the pass
    case, 1.5% a year per position since v3.3), so a credit is at most differential - markup. markup_pct_year: a
    sensitivity row (financing.sensitivity_markups_pct_year, 1.0 and 2.0); never below the pass case when freezing.
    USD/CAD: the worse of a Wednesday and a Thursday triple."""
    pair = pair_key(pair)
    if side not in (1, -1):
        raise ValueError("side is +1 (long) or -1 (short)")
    p = model["pairs"][pair]
    if freezing and p["status"] != "measured":
        raise FrozenPlaceholder(f"{pair}: cost not measured; cannot freeze")
    if freezing and p.get("freeze_blocked"):
        raise FrozenPlaceholder(f"{pair}: {p['freeze_blocked']}")
    if freezing and rate_range is None:
        raise ValueError("freezing=True needs rate_range: financing is charged at the end of each rate's range that hurts")
    pip = p["pip"]
    mk = float(model["financing"]["markup_pct_year"] if markup_pct_year is None else markup_pct_year)
    if freezing and mk < float(model["financing"]["markup_pct_year"]):
        raise ValueError("a frozen pick is charged at least the pass-case markup; lower markups are sensitivity rows only")
    base, quote = pair[:3], pair[3:]

    def r(ccy, t):
        v = rate(ccy, t)
        if v is None or (isinstance(v, float) and np.isnan(v)):
            raise ValueError(f"no policy rate for {ccy} at {t}; financing cannot be priced")
        return float(v)

    def against(roll):
        if rate_range is None:
            return (r(quote, roll) - r(base, roll)) * side
        rq, rb = rate_range(quote, roll), rate_range(base, roll)
        if rq is None or rb is None:
            raise ValueError(f"no policy rate range for {quote if rq is None else base} at {roll}; financing cannot be priced")
        return rq[1] - rb[0] if side == 1 else rb[1] - rq[0]  # the end of each range that hurts the position

    def rows(triple_day):
        out = []
        for roll, days in financing_rolls(entry_ts, exit_ts, triple_day):
            diff = against(roll)
            out.append((roll, days, days * float(price) * (diff + mk) / 100.0 / 365.0 / pip))
        return out
    if pair == "USDCAD":
        a, b = rows(2), rows(3)
        return a if sum(x[2] for x in a) >= sum(x[2] for x in b) else b
    return rows(2)
