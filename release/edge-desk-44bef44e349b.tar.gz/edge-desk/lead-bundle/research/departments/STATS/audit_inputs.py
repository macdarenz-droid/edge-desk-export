"""STATS freeze and audit gate on a pick's pinned inputs (PASS_BAR.md section 3, "Inputs a freeze may pin").

check_frozen_inputs(frozen) returns the problems found in a FROZEN.json (a dict): any sha256 anywhere in it
that is on the refused list. An empty list means none was found; the audit also checks that every pinned
input is merged and reviewed on the coordinator branch.
"""
from __future__ import annotations

REFUSED = {
    # research/common/cost.py as merged with DATA 448f7ddd: reads none of COST v3's per-minute release floors
    "509c07fe135dd832b29980dc1694303f0267f7d55d3ec081c4866276b9936ebe":
        "pre-fix research/common/cost.py (charges no release cost); use COST's cost.py",
    # research/departments/COST/RELEASES.json built from EVENTS-04 work in progress: BUILD looks only
    "2e070a6f1676a9f431f8435d30e5de082c1807e193f49b1f205a545544d27cc0":
        "RELEASES.json built from EVENTS-04 work in progress (BUILD looks only until COST v3.1)",
    # data/macro nyse_calendar.csv, withdrawn by DATA at data/macro 767272d9 (ICE's terms bar robots and data mining;
    # coordinator 16 Oct 2026 about 5:23 am Melbourne): no new freeze or look; closed studies' recorded runs stand
    "b8906b3bb98486e4bf0766f4fde4761becc6630bb47c2fe2acd9c92ec7253d91":
        "data/macro nyse_calendar.csv, withdrawn (ICE's terms bar robots and data mining); no new freeze or look",
}

# Withdrawn inputs a study may not name (file stem: the CSV, DATA's builder nyse_calendar.py and any file named after
# them), whatever copy or sha it uses.
WITHDRAWN_NAMES = {
    "nyse_calendar": "data/macro nyse_calendar.csv, withdrawn (ICE's terms bar robots and data mining); no new freeze or look",
}


def _shas(x, path=""):
    if isinstance(x, dict):
        for k, v in x.items():
            yield from _shas(v, f"{path}.{k}" if path else str(k))
    elif isinstance(x, list):
        for i, v in enumerate(x):
            yield from _shas(v, f"{path}[{i}]")
    elif isinstance(x, str) and len(x) == 64 and all(c in "0123456789abcdef" for c in x.lower()):
        yield path, x.lower()


def check_frozen_inputs(frozen: dict) -> list[str]:
    return [f"{p}: {REFUSED[s]}" for p, s in _shas(frozen) if s in REFUSED]


def withdrawn_named(text: str) -> list[str]:
    """Withdrawn inputs named in a text (by file stem or by a withdrawn input's sha256, in any case)."""
    low = text.lower()
    out = [f"names {n}: {why}" for n, why in WITHDRAWN_NAMES.items() if n.lower() in low]
    out += [f"names {s[:12]}: {why}" for s, why in REFUSED.items() if s in low and why in WITHDRAWN_NAMES.values()]
    return out
