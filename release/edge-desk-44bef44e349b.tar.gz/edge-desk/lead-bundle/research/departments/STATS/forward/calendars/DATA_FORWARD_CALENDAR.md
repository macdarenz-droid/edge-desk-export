# DATA_FORWARD_CALENDAR.csv

Delivered by DATA to STATS by message on 14 Oct 2026 about 4:02 am Melbourne, under ledger id STATS-FWDCAL-20261014-01 (grant line in `../../ACCESS_LOG.jsonl`, c32c3339). sha256 104665307a10e0d3b72a87e8c9e9a6a6267101183fdcadf79f787e315cf19eca, 4,776 bytes, 37 rows, verified on receipt. Official pages only (federalreserve.gov, ecb.europa.eu, gov.uk), dates and times only; DATA keeps no copy on any branch.

What it does not give (DATA's notes): an FOMC time for 2026-09-16 and every 2027 meeting (only 2026-10-28 and 2026-12-09 have 14:00 from the Board's month pages); any ECB decision time (the press-conference time is not the decision time, so it was not used). The Fed lists each FOMC date as tentative until confirmed at the preceding meeting. A rule that needs an event's time cannot settle a trade on a row without one; the forward runner waits for a sourced time and never assumes one.

## Addendum (14 Oct 2026 about 4:05 am Melbourne)
`DATA_FORWARD_CALENDAR_ADDENDUM.csv`, same ledger id, sha256 2299b7feafd8c85d888fed8227f0d5fc6ac4693edbdd6e8b7776bec2573ea2bc, verified on receipt: the 2026-09-16 FOMC time (14:00 New York, Board's September 2026 page) and the ECB decision time 14:15 for the ten ECB rows (ECB "Monetary policy decisions" page: "published in a press release at 14:15 CET"). Where a row is in both files, the addendum's row wins.

STATS ruling on "CET": Frankfurt local time (Europe/Berlin, CEST in summer), as DATA stored it. The ECB uses "CET" for Frankfurt local time (its weekly schedule wrote "12:00 CET" on a summer-time date, 9 Oct 2026, per DATA), and the repo's historical ECB rows follow local time. The five summer-time 2027 dates would move one hour under a strict UTC+1 reading; if an official page later states otherwise, those rows are corrected under a new calendar pin. Still missing: the eight 2027 FOMC times (month pages not yet published).
