"""STATS forward paper log: the pure core (no network, no git). See ../FORWARD.md.

What it does, for each registered pick (picks/*.json, each pinned in PICKS.sha256):
- checks the sha256 of every frozen round file the pick runs, then imports that code UNCHANGED;
- gives the frozen code a world whose 1-minute bars are FORWARD bars only (ts_utc >= FORWARD_START), with
  New York daily bars built from up to MAX_LAG_DAYS of earlier bars as lagged inputs (ATR20, day ends);
- plans the pick's decisions from its floor (the first decision not settled at the last run) and logs, in order, every
  SETTLED one: its scheduled exit plus 15 minutes is inside the bars held, and every calendar row it depends on is
  final (held, with a source read after the event; or cancelled). A trade becomes one line with the PASS_BAR.md
  section 2 position-day rows at the pass-case cost known (fwd_cost); a planned decision without a trade becomes a
  no_exit_bar or no_trade line. The first unsettled decision waits, and so does everything after it.
- One pick's error (its calendar, its frozen code) becomes an error line; the other picks go on.

The log lives only on the never-merged branch dept/stats-locked (fwd_io.LockedLog); append_log refuses a path inside
this checkout. The guard (docs/EDGE_HUNT.md section 3): no outcome (fill, exit, P&L) is computed, printed or stored for a
bar before FORWARD_START. `outcome_bars`, `check_decision` and `check_trade` enforce it; tests/test_guard.py fails if
any of them is removed.
"""
from __future__ import annotations

import contextlib
import dataclasses
import hashlib
import importlib.util
import json
import math
import os
import sys
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parents[4]))      # this checkout's root (DATA's research/common)
import research.common  # noqa: E402,F401  (first: DATA's runtime audit hook, research/common/audit.py)
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import fwd_cost  # noqa: E402

HERE = Path(__file__).resolve().parent                 # research/departments/STATS/forward
STATS = HERE.parent
REPO = HERE.parents[3]
FORWARD_START = 1791493200                             # 17:00 New York 8 Oct 2026 = start of trading day 9 Oct
FORWARD_FIRST_DATE = date(2026, 10, 9)
MAX_LAG_DAYS = 400                                     # lagged inputs only (docs/EDGE_HUNT.md section 3)
FILL_LIMIT = 900                                       # the rounds' 15-minute fill rule
PIP = 1e-4
PAIR = "EUR_USD"
NY = ZoneInfo("America/New_York")
LON = ZoneInfo("Europe/London")
ERA = "FORWARD"                                        # era key lent to r47_engine.ERAS during a run
PICKS_DIR = HERE / "picks"
CAL_CSV = HERE / "calendars" / "FORWARD_EVENTS.csv"
CAL_META = HERE / "calendars" / "FORWARD_EVENTS.json"
LOG_NAME = "FORWARD_LOG.jsonl"                         # only in the dept/stats-locked worktree
DEPS = HERE / "DEPS.json"
COMMON = "research/common"
EVENT_TYPES = ("FOMC_STATEMENT", "ECB_DECISION")
TARGET_R = {"X1": 1.0, "X2": 1.5, "X3": 2.0, "X4": 3.0}    # research/round53/r53.py trade(); checked against R_ba
COST_BASIS = {"basis": "pass case (PASS_BAR.md section 3): the higher of the frozen convention and COST v3",
              "floor_pips_round_trip": 2.0, "slip_pips_per_market_fill": 0.2,
              "frozen": "min(side x mid move - 2.0, bid/ask result with 0.2 pip per market or stop fill) - financing",
              "financing": "Round 45's 1 pip a night (3 for a Wednesday close) on every calendar 17:00 New York close "
                           "held, holidays included; COST v3's rate-differential financing once rates are pinned",
              "cost_v3": "research/departments/COST/cost.py CostModel.net_pips (pinned in DEPS.json 'cost')",
              "rows": "each label carries its marks and Round 45's nightly financing; the rest of the pass-case cost "
                      "sits on the first label, so the rows sum to the pass-case net",
              "financing_2p0": "PASS_BAR.md v7 section 3: every line also carries the pass case with COST's financing "
                               "at 2.0% a year (net.*.pass_case_fin2p0; days[*].pnl_long_fin2p0, pnl_short_fin2p0, "
                               "the extra cost on the first label); it can only mark a pass financing-sensitive"}
EXIT_KIND = {"time": "market", "stop": "stop", "breakeven": "stop", "target": "target"}   # cost.py fill kinds


class OutcomeGuardError(RuntimeError):
    """An outcome for a bar before FORWARD_START was about to be computed or stored."""


class CalendarError(RuntimeError):
    """The forward calendar has no source, does not cover the run day, or is malformed."""


class PinError(RuntimeError):
    """A frozen file differs from the sha256 pinned in a pick."""


class Refused(RuntimeError):
    """A rule of the run was not met; nothing further is read (fwd_io.Refused is this class)."""


# ------------------------------------------------------------------ the guard

def outcome_bars(m1: dict) -> dict:
    """The only bars an outcome may read: rows with ts_utc >= FORWARD_START."""
    ts = np.asarray(m1["ts_utc"], dtype=np.int64)
    keep = ts >= FORWARD_START
    out = {k: np.asarray(v)[keep] for k, v in m1.items()}
    if len(out["ts_utc"]) and int(out["ts_utc"].min()) < FORWARD_START:
        raise OutcomeGuardError("an outcome bar before FORWARD_START")
    return out


def check_decision(ts: int) -> None:
    if int(ts) < FORWARD_START:
        raise OutcomeGuardError(f"decision {ts} is before FORWARD_START {FORWARD_START}")


def check_trade(tr: dict) -> None:
    for k in ("decision_ts", "entry_ts", "exit_ts"):
        if int(tr[k]) < FORWARD_START:
            raise OutcomeGuardError(f"{k} {tr[k]} is before FORWARD_START {FORWARD_START}")


def check_inputs_start(start_ts: int) -> None:
    if int(start_ts) < FORWARD_START - MAX_LAG_DAYS * 86400:
        raise OutcomeGuardError(f"lagged inputs start {start_ts} is more than {MAX_LAG_DAYS} days before the forward start")


LOCKED_ERAS = (("VALIDATION", 1751317200, 1774990800), ("HOLDOUT", 1774990800, FORWARD_START),
               ("FORWARD", FORWARD_START, 10 ** 11))


def era_string(start_ts: int) -> str:
    """The loaders' era argument for a read from start_ts onward, e.g. 'HOLDOUT+FORWARD'."""
    check_inputs_start(start_ts)
    return "+".join(n for n, lo, hi in LOCKED_ERAS if hi > int(start_ts))


def inputs_start(picks: list, floors: dict | None = None) -> int:
    """First lagged-input second: for each pick, 17:00 New York on the day before its floor's label less its lookback
    (the floor is FORWARD_START until a run settles decisions); the earliest of the picks. Settled trades' lag rows
    are never read again."""
    floors = floors or {}
    out = []
    for p in picks:
        f = max(FORWARD_START, int(floors.get(p.get("id"), FORWARD_START)))
        d = date.fromisoformat(label_of(f)) - timedelta(days=1 + int(p.get("lookback_days", 0)))
        out.append(int(datetime.combine(d, time(17, 0), NY).timestamp()))
    s = min(out) if out else int(datetime.combine(FORWARD_FIRST_DATE - timedelta(days=1), time(17, 0), NY).timestamp())
    check_inputs_start(s)
    return s


# ------------------------------------------------------------------ days and labels

def label_of(ts: int) -> str:
    """The 17:00 New York trading-day label of ts (judge.trading_day)."""
    t = datetime.fromtimestamp(int(ts), timezone.utc).astimezone(NY)
    return (t.replace(tzinfo=None) + timedelta(hours=7)).date().isoformat()


def bar_labels(ts) -> np.ndarray:
    t = pd.to_datetime(np.asarray(ts, dtype=np.int64), unit="s", utc=True).tz_convert(NY).tz_localize(None)
    return np.asarray((t + pd.Timedelta(hours=7)).strftime("%Y-%m-%d"))


def label_close_ts(day: date) -> int:
    """17:00 New York on `day`: the close of trading-day label `day`."""
    return int(datetime.combine(day, time(17, 0), NY).timestamp())


def weekday_labels(first: str, last: str) -> list:
    d, d1, out = date.fromisoformat(first), date.fromisoformat(last), []
    while d <= d1:
        if d.weekday() < 5:
            out.append(d.isoformat())
        d += timedelta(days=1)
    return out


# ------------------------------------------------------------------ git

# git environment variables that point git at another repository, work tree, index or object store (an exported GIT_DIR
# from a git hook or a gate, for one), or set configuration from the environment (GIT_CONFIG_PARAMETERS,
# GIT_CONFIG_COUNT with GIT_CONFIG_KEY_<n> and GIT_CONFIG_VALUE_<n>: an insteadOf there moves "origin"; red team 3,
# items 7 and 12): STATS's git calls run without them, so `git -C <checkout>` is always that checkout, a linked worktree
# (where .git is a file) included. The repository set is DATA's loaders' (research/common/loaders.py).
GIT_ENV_DROP = frozenset({
    "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY", "GIT_COMMON_DIR",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_NAMESPACE", "GIT_REPLACE_REF_BASE", "GIT_SHALLOW_FILE",
    "GIT_GRAFT_FILE", "GIT_QUARANTINE_PATH", "GIT_SSL_NO_VERIFY", "GIT_CEILING_DIRECTORIES",
    "GIT_DISCOVERY_ACROSS_FILESYSTEM", "GIT_NO_REPLACE_OBJECTS", "GIT_CONFIG_PARAMETERS", "GIT_CONFIG_COUNT"})
GIT_ENV_DROP_PREFIXES = ("GIT_CONFIG_KEY_", "GIT_CONFIG_VALUE_")
# every STATS git call: replace objects (refs/replace/*) are never honoured (red team 3, item 12; git docs:
# --no-replace-objects, GIT_NO_REPLACE_OBJECTS), and TLS is verified (red team 4, item 4: http.sslVerify=true here;
# a URL-specific http.<url>.sslVerify still wins in git 2.43, so fwd_io.check_origin also reads the value git uses for
# each https origin URL). Grafts (<git-common-dir>/info/grafts) are not turned off by either: fwd_io.worktree_check
# refuses a repository that has them.
GIT = ("git", "--no-replace-objects", "-c", "http.sslVerify=true")


def clean_process_env(environ=None) -> list:
    """Delete GIT_ENV_DROP and GIT_CONFIG_KEY_* / GIT_CONFIG_VALUE_* from the process environment (os.environ), so
    every child process inherits a clean one: DATA's loaders and downloader run git too, and an env insteadOf there
    would move their origin while STATS's own origin check passes (red team 4, item 5). Sets GIT_NO_REPLACE_OBJECTS=1
    and GIT_TERMINAL_PROMPT=0 for them as well (red team 7, N3: DATA's loaders' fetch and the downloader child fail
    rather than wait at a credential prompt while STATS's lock is held). run_forward.main calls it first. Returns the
    names deleted."""
    env = os.environ if environ is None else environ
    gone = sorted(k for k in env if k in GIT_ENV_DROP or k.startswith(GIT_ENV_DROP_PREFIXES))
    for k in gone:
        del env[k]
    env["GIT_NO_REPLACE_OBJECTS"] = "1"
    env["GIT_TERMINAL_PROMPT"] = "0"
    return gone


def git_env() -> dict:
    """os.environ without GIT_ENV_DROP and GIT_CONFIG_KEY_* / GIT_CONFIG_VALUE_*, with GIT_NO_REPLACE_OBJECTS=1 and
    GIT_TERMINAL_PROMPT=0 (a fetch, push or dry run fails rather than wait at a credential prompt; red team 6, F8):
    the environment of every STATS git call."""
    env = {k: v for k, v in os.environ.items() if k not in GIT_ENV_DROP and not k.startswith(GIT_ENV_DROP_PREFIXES)}
    env["GIT_NO_REPLACE_OBJECTS"] = "1"
    env["GIT_TERMINAL_PROMPT"] = "0"
    return env


# ------------------------------------------------------------------ picks and pins

def sha256_file(p) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


PICK_KEYS = ("id", "name", "adapter", "params", "unit", "lookback_days", "frozen_files", "rule", "sources", "status")


def load_picks(d: Path | None = None, deps: Path | None = None) -> list:
    """The registered picks. From the repo's picks/ folder (or with `deps` given), every json must match DEPS.json
    "picks" exactly (no file missing, changed or unlisted); PinError otherwise."""
    folder = Path(d or PICKS_DIR)
    if d is None or deps is not None:
        verify_pick_pins(folder, deps)
    picks = []
    for f in sorted(folder.glob("*.json")):
        p = json.loads(f.read_text())
        miss = [k for k in PICK_KEYS if k not in p]
        if miss:
            raise ValueError(f"{f.name}: missing {miss}")
        if p["adapter"] not in ("r53", "r47_cell", "r55_fc") or p["unit"] not in ("R", "pips"):
            raise ValueError(f"{f.name}: unknown adapter or unit")
        p["_sha256"] = sha256_file(f)
        picks.append(p)
    ids = [p["id"] for p in picks]
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate pick ids")
    return picks


def verify_pick_pins(folder: Path, deps: Path | None = None) -> None:
    """picks/*.json against DEPS.json "picks" ({"picks/<file>": sha256}): the same files, the same sha256."""
    want = json.loads(Path(deps or DEPS).read_text())["picks"]
    got = {f"picks/{f.name}": sha256_file(f) for f in sorted(Path(folder).glob("*.json"))}
    if got != want:
        bad = sorted(k for k in set(got) | set(want) if got.get(k) != want.get(k))
        raise PinError(f"picks differ from DEPS.json 'picks': {bad}")


def check_data_deps(deps: Path | None = None, repo: Path | None = None) -> dict:
    """DATA's code in this checkout must equal DEPS.json: every pinned file present with its sha256, and no
    research/common/*.py file that DEPS.json does not pin. Refused if a file is missing; PinError if one differs."""
    d = json.loads(Path(deps or DEPS).read_text())
    repo = Path(repo or REPO)
    at = f"DATA commit {d['data_commit']}"
    for rel, want in d["files"].items():
        p = repo / rel
        if not p.is_file():
            raise Refused(f"{rel} is not in this checkout (merge {at} first)")
        got = sha256_file(p)
        if got != want:
            raise PinError(f"{rel} sha256 {got} differs from DEPS.json ({at}); re-pin after a red team")
    extra = {q.relative_to(repo).as_posix() for q in (repo / COMMON).glob("*.py")} - set(d["files"])
    if extra:
        raise PinError(f"unpinned files in {COMMON}: {sorted(extra)}")
    return d


def checked_reader(name: str):
    """research.common.files.<name> (read_table, read_text or read_bytes), DATA's checked reader for non-price files (it refuses a
    file with price-bar columns or a registered price set's sha256), imported from this checkout after the DEPS.json
    pins pass. Every non-price file that forward/ reads by a path it was given goes through it (DATA guard)."""
    check_data_deps()
    root = str(REPO)
    if root not in sys.path:
        sys.path.insert(0, root)
    import research.common.files as F  # noqa: E402  (pinned in DEPS.json)
    if Path(F.__file__).resolve() != (REPO / COMMON / "files.py").resolve():
        raise PinError(f"research.common.files was imported from {F.__file__}, not from this checkout")
    return {"read_table": F.read_table, "read_text": F.read_text, "read_bytes": F.read_bytes}[name]


def verify_pins(picks: list, repo: Path = REPO) -> None:
    for p in picks:
        for rel, want in p["frozen_files"].items():
            got = sha256_file(repo / rel)
            if got != want:
                raise PinError(f"{p['id']}: {rel} sha256 {got} != pinned {want}")


# ------------------------------------------------------------------ the frozen code (imported unchanged)

_FZ: dict = {}


def _load_path(name: str, path: Path):
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


FROZEN_MODULES = {   # module name -> files it reads when imported (each must be pinned by a registered pick)
    "r45": (), "r47_engine": (), "r47_cal": (), "cells": (), "cells.fam_events": ("research/round47/CELLS.json",),
    "r49_run": (), "r51": (), "r53": (), "r55_batch_a": ("research/round55/CELLS.json", "research/round17/data/events.csv"),
    "r47_fam_events": ("research/round47/CELLS.json",), "r47_fam_rates_cross": ("research/round47/CELLS.json",)}


def _path_first(d: str) -> None:
    p = str(REPO / "research" / d)
    if p in sys.path:
        sys.path.remove(p)
    sys.path.insert(0, p)


def frozen(picks: list) -> SimpleNamespace:
    """Rounds 45-55 code, unchanged, for the registered picks' adapters. Call verify_pins first. Round 55's batch A
    is loaded by file path as 'r55_batch_a' (its own runner does the same), so Round 47's `cells` keeps its name."""
    ads = {p["adapter"] for p in picks}
    if "E" not in _FZ:
        _path_first("round47")
        import r47_engine as E  # noqa: E402  (imports r45)
        from cells import fam_events as F  # noqa: E402  (Round 47's package)
        _FZ.update(E=E, F=F)
    if "r53" in ads and "r53" not in _FZ:
        for d in ("round49", "round51", "round53"):
            _path_first(d)
        import r51  # noqa: E402  (imports r49_run, which imports Round 47's cells.fam_events)
        import r53  # noqa: E402
        _FZ.update(r51=r51, r53=r53)
    if "r55_fc" in ads and "A" not in _FZ:
        _FZ["A"] = _load_path("r55_batch_a", REPO / "research/round55/cells/batch_a.py")
    check_imported(picks)
    return SimpleNamespace(**_FZ)


def check_imported(picks: list, repo: Path = REPO) -> None:
    """Every frozen module now imported, and every file it read at import, is pinned by a pick and unchanged."""
    pinned = {}
    for p in picks:
        pinned.update(p["frozen_files"])
    for name, reads in FROZEN_MODULES.items():
        mod = sys.modules.get(name)
        if mod is None:
            continue
        rel = Path(mod.__file__).resolve().relative_to(Path(repo).resolve()).as_posix()
        for f in (rel,) + tuple(reads):
            if pinned.get(f) != sha256_file(Path(repo) / f):
                raise PinError(f"{f} (imported by {name}) is not pinned by a registered pick, or changed")


@contextlib.contextmanager
def lent_era(E, name: str, d_from: date, d_to: date, end_ts: int):
    """r47_engine.run_cell reads its decision dates from E.ERAS[era] (Round 49 added its era 'X' the same way)."""
    had = name in E.ERAS
    old = E.ERAS.get(name)
    E.ERAS[name] = {"from": d_from, "to": d_to, "warm": d_from, "end": int(end_ts)}
    try:
        yield name
    finally:
        if had:
            E.ERAS[name] = old
        else:
            E.ERAS.pop(name, None)


# ------------------------------------------------------------------ calendar

CAL_COLS = ("event_id", "type", "local_date", "local_time", "tz", "utc", "scheduled", "status", "source_url",
            "source_note", "source_read_utc")
CAL_STATUSES = ("held", "scheduled", "cancelled")


def _utc_ts(s) -> float:
    s = str(s).strip()
    return float(pd.Timestamp(s).timestamp()) if s else math.nan


def read_calendar(csv: Path | None = None, meta: Path | None = None, run_day: date | None = None) -> pd.DataFrame:
    """The forward FOMC and ECB calendar (and any release-only rows for the cost model). Refuses unless it is sourced,
    unchanged since its meta was written, and well formed: a held row needs a source read after the event. The meta
    is kept in df.attrs["meta"]. With run_day, check_coverage for both event types (a run checks each pick's own)."""
    csv, meta = Path(csv or CAL_CSV), Path(meta or CAL_META)
    m = json.loads(meta.read_text())
    if m.get("status") != "sourced":
        raise CalendarError(f"{Path(csv).name} needs a source (status {m.get('status')!r}); no dates are invented")
    if sha256_file(csv) != m.get("sha256"):
        raise CalendarError(f"{Path(csv).name} changed since its meta was written")
    read_table = checked_reader("read_table")
    df = read_table(csv, dtype=str, keep_default_na=False)
    check_calendar_rows(df, statuses=CAL_STATUSES, need_source=True)
    df.attrs["meta"] = m
    if run_day is not None:
        check_coverage(df, run_day, EVENT_TYPES)
    return df


def check_coverage(df: pd.DataFrame, run_day: date, types) -> None:
    """The calendar covers the run for these event types: through the run day; for FOMC, the last statement before
    9 Oct 2026 (the FOMC cycle anchor) and one after the run day; for ECB, one decision after the run day. So every
    window that can close by the run day is known. A row without a time (DATA leaves utc blank until the source states
    the time, red team 4 item 1) counts for nothing here, and every row of the type up to and including the next one
    after the run day must have its time: the run waits until DATA adds it."""
    m = df.attrs.get("meta") or {}
    if not m.get("covers_through") or date.fromisoformat(m["covers_through"]) < run_day:
        raise CalendarError(f"calendar covers through {m.get('covers_through')}, before the run day {run_day}")
    ev = calendar_rows(df)
    nyd = [datetime.fromtimestamp(t, NY).date() for t in ev.ts]
    fomc = [d for d, ty in zip(nyd, ev.type) if ty == "FOMC_STATEMENT"]
    ecb = [d for d, ty in zip(nyd, ev.type) if ty == "ECB_DECISION"]
    if "FOMC_STATEMENT" in types:
        if not any(d < FORWARD_FIRST_DATE for d in fomc) or date.fromisoformat(m["covers_from"]) > min(fomc):
            raise CalendarError("the calendar must start with the last FOMC statement before 9 Oct 2026")
    for ty, timed in (("FOMC_STATEMENT", fomc), ("ECB_DECISION", ecb)):
        if ty not in types:
            continue
        nxt = min((d for d in timed if d > run_day), default=None)
        late = sorted(d for d in untimed_dates(df, ty) if nxt is None or d <= nxt)
        if late:
            raise CalendarError(f"the {ty} row of {late[0]} has no time yet: every {ty} up to the next one after the "
                                f"run day {run_day} needs its time (DATA adds it); the run waits")
        if nxt is None:
            raise CalendarError(f"the calendar must hold the next {'FOMC statement' if ty == 'FOMC_STATEMENT' else 'ECB decision'} "
                                "after the run day")


def untimed_dates(df: pd.DataFrame, ty: str) -> list:
    """local_date of every scheduled, not cancelled row of this type without a time (blank utc)."""
    d = df[(df["type"] == ty) & (df["status"].astype(str) != "cancelled") & (pd.to_numeric(df["scheduled"]) == 1)
           & (df["utc"].astype(str).str.strip() == "")]
    return [date.fromisoformat(str(x).strip()) for x in d.get("local_date", pd.Series([], dtype=str))]


def _row_day(r) -> date | None:
    """The row's own day: the date of its utc in its time zone when it has a time, else its local_date."""
    u = str(r.get("utc", "")).strip()
    if u:
        try:
            return datetime.fromtimestamp(_utc_ts(u), ZoneInfo(str(r.get("tz", "")).strip())).date()
        except (KeyError, ValueError, TypeError):
            return None
    try:
        return date.fromisoformat(str(r.get("local_date", "")).strip())
    except ValueError:
        return None


def check_calendar_rows(df: pd.DataFrame, statuses, need_source: bool) -> None:
    """Well-formed rows. A row may have no time (blank utc) when it is cancelled, still scheduled (DATA leaves utc
    blank until the source states the time: the 2027 FOMC statements; red team 4 item 1), or of a type the rules do
    not trade on (a UK bank holiday is a whole day). Such a row needs a valid local_date and tz; a held FOMC or ECB row
    needs its time. A row with a time must fall on its local_date in its tz."""
    need = CAL_COLS if need_source else ("type", "utc", "scheduled", "status")
    miss = [c for c in need if c not in df.columns]
    if miss:
        raise CalendarError(f"calendar columns missing: {miss}")
    rows = df if need_source else df[df["type"].isin(EVENT_TYPES)]
    if need_source and df["event_id"].duplicated().any():
        raise CalendarError("duplicate event_id")
    for _, r in rows.iterrows():
        if str(r["status"]) not in statuses or str(r["scheduled"]) not in ("0", "1", "0.0", "1.0"):
            raise CalendarError(f"bad status or scheduled flag: {dict(r)}")
        timed = bool(str(r["utc"]).strip())
        if not timed and not need_source and str(r["status"]) != "cancelled":
            raise CalendarError(f"row without a time: {dict(r)}")
        if not timed and str(r["status"]) == "held" and str(r["type"]) in EVENT_TYPES:
            raise CalendarError(f"a held {r['type']} row needs its time: {dict(r)}")
        if not need_source:
            continue
        if not str(r["type"]).replace("_", "").isalnum() or not str(r["event_id"]).strip():
            raise CalendarError(f"bad type or event_id: {dict(r)}")
        try:
            day = date.fromisoformat(str(r["local_date"]).strip())
            ZoneInfo(str(r["tz"]).strip())
        except (ValueError, KeyError, TypeError) as e:
            raise CalendarError(f"row without a valid local_date and tz ({type(e).__name__}): {dict(r)}") from None
        if timed and _row_day(r) != day:
            raise CalendarError(f"utc {r['utc']} is not on local_date {day} in {r['tz']}: {dict(r)}")
        if not str(r.get("source_url", "")).startswith("https://"):
            raise CalendarError(f"row without an official source URL: {dict(r)}")
        try:
            read = _utc_ts(r["source_read_utc"])
        except ValueError:
            read = math.nan
        if not math.isfinite(read):
            raise CalendarError(f"row without source_read_utc (when its source was read): {dict(r)}")
        end = (_utc_ts(r["utc"]) if timed else
               datetime.combine(day + timedelta(days=1), time(0), ZoneInfo(str(r["tz"]).strip())).timestamp())
        if str(r["status"]) == "held" and not read > end:
            raise CalendarError(f"a held row needs a source read after the event: {dict(r)}")


def calendar_rows(df: pd.DataFrame, statuses=("held", "scheduled")) -> pd.DataFrame:
    """Scheduled FOMC statements and ECB decisions as (type, ts, scheduled, status, ny_date, event_id) for the frozen
    code, which only knows held rows: a forward row still 'scheduled' is planned as held (it is settled only when
    final, see calendar_all); a cancelled row is dropped."""
    d = df[df["type"].isin(EVENT_TYPES)].copy()
    d = d[d["status"].astype(str).isin(statuses) & (pd.to_numeric(d["scheduled"]) == 1)]
    d = d[d["utc"].astype(str).str.strip() != ""]
    ts = [int(pd.Timestamp(u).timestamp()) for u in d["utc"]]
    out = pd.DataFrame({"type": d["type"].to_numpy(), "ts": np.asarray(ts, dtype=np.int64)})
    out["scheduled"] = 1
    out["status"] = "held"
    out["ny_date"] = [datetime.fromtimestamp(int(t), NY).date() for t in out.ts]
    out["event_id"] = (d["event_id"].to_numpy() if "event_id" in d.columns
                       else [f"{a}@{b}" for a, b in zip(d["type"], d["utc"])])
    return out.sort_values("ts", kind="stable").reset_index(drop=True)


def calendar_all(df: pd.DataFrame) -> pd.DataFrame:
    """Every scheduled row (any status) as (type, ts, event_id, status, final, day). final: cancelled, or held with a
    source read after the event. Historic tables without source_read_utc count held rows as final. ts is NaN for a
    row without a time; day is the row's own day (_row_day; None when unknown)."""
    d = df[pd.to_numeric(df["scheduled"]) == 1]
    ts = np.array([_utc_ts(u) for u in d["utc"]], dtype=float)
    st = d["status"].astype(str).to_numpy()
    if "source_read_utc" in d.columns:
        read = np.array([_utc_ts(u) for u in d["source_read_utc"]], dtype=float)
        held_final = (st == "held") & np.isfinite(read) & np.isfinite(ts) & (read > ts)
    else:
        held_final = st == "held"
    eid = (d["event_id"].astype(str).to_numpy() if "event_id" in d.columns
           else np.array([f"{a}@{b}" for a, b in zip(d["type"], d["utc"])]))
    day = [_row_day(r) for _, r in d.iterrows()]
    return pd.DataFrame({"type": d["type"].to_numpy(), "ts": ts, "event_id": eid, "status": st,
                         "final": (st == "cancelled") | held_final, "day": pd.Series(day, dtype=object).to_numpy()})


def events_frame(cal: pd.DataFrame) -> pd.DataFrame:
    """World.events for the frozen code: (type, ts), as r47_engine.load_events returns."""
    return cal[["type", "ts"]].reset_index(drop=True)


def _live(allrows: pd.DataFrame, ty: str) -> pd.DataFrame:
    return allrows[(allrows.type == ty) & (allrows.status != "cancelled") & np.isfinite(allrows.ts)]


def _untimed(allrows: pd.DataFrame, ty: str) -> pd.DataFrame:
    """Not cancelled rows of this type without a time (red team 4 item 1)."""
    return allrows[(allrows.type == ty) & (allrows.status != "cancelled") & ~np.isfinite(allrows.ts)]


def deps_of(pick: dict, t: int, te: int, allrows: pd.DataFrame) -> dict | None:
    """The calendar rows a planned decision depends on, or None when they cannot be found. R53 and PA-F4: the event
    its exit is 5 minutes before. FC-1: every scheduled statement from the one before the decision (day 0 of its
    cycle) to the one after it (whose day -7 can cut the window); a row added inside that range changes the plan.
    None, too, when a row of the type without a time (or of an unknown day) falls within a day of that range: its
    time could move the plan (red team 4 item 1)."""
    ty = "FOMC_STATEMENT" if pick["adapter"] in ("r53", "r55_fc") else pick["calendar"][0]
    live = _live(allrows, ty)
    if pick["adapter"] == "r55_fc":
        before, after = live.ts[live.ts < t], live.ts[live.ts > t]
        if not len(before) or not len(after):
            return None
        lo, hi = float(before.max()), float(after.min())
    else:
        lo = hi = float(te + 300)
        if not (live.ts == lo).any():
            return None
    d_lo = datetime.fromtimestamp(lo, timezone.utc).date() - timedelta(days=1)
    d_hi = datetime.fromtimestamp(hi, timezone.utc).date() + timedelta(days=1)
    if any(d is None or d_lo <= d <= d_hi for d in _untimed(allrows, ty).day):
        return None
    r = live[(live.ts >= lo) & (live.ts <= hi)].sort_values("ts", kind="stable")
    return {"type": ty, "lo_ts": int(lo), "hi_ts": int(hi),
            "rows": [[str(e), int(x)] for e, x in zip(r.event_id, r.ts)], "final": bool(r.final.all())}


def calendar_sha(cal_df: pd.DataFrame) -> str | None:
    """The calendar CSV's sha256 (its pin's, as read_calendar checked it)."""
    return (getattr(cal_df, "attrs", {}).get("meta") or {}).get("sha256")


def calendar_snapshot(cal_df: pd.DataFrame) -> list:
    """[[type, ts, status, day]] of every scheduled FOMC statement and ECB decision, sorted: ts None for a row without
    a time; day its own day (the date of its time in its tz, else its local_date; _row_day). No event_id: rows are
    compared by time, day and status only (red team 3, item 1; red team 4, item 1)."""
    d = cal_df[cal_df["type"].isin(EVENT_TYPES) & (pd.to_numeric(cal_df["scheduled"]) == 1)]
    out = []
    for _, r in d.iterrows():
        t = _utc_ts(r["utc"])
        day = _row_day(r)
        out.append([str(r["type"]), int(t) if math.isfinite(t) else None, str(r["status"]),
                    day.isoformat() if day else None])
    return sorted(out, key=lambda r: (r[0], r[1] is None, r[1] or 0, r[3] or "", r[2]))


STATUS_UPDATES = {("scheduled", "held")}       # the calendar's normal update of a row; any other change is a change


def snapshot_changes(old: list, new: list, known_until: int | dict | None = None) -> list:
    """What changed between two calendar snapshots (calendar_snapshot), by type, time, day and status: a timed row
    moved, removed, cancelled or put back, a status changed other than scheduled -> held, a row added on or before
    the latest time or day known before (inside the known range), or a row without a time removed, changed or added
    inside that range (a cancelled one anywhere). Normal updates, not changes: scheduled -> held; rows added after
    the known range (the calendar growing); and a time added to a scheduled row without one (red team 4 item 1): the
    new timed row is on the same day, scheduled or held, and its time is after known_until, the last run's data end
    (so no run computed with that row's time unknown in its past; without known_until it is a change). Rows of an
    older snapshot ([type, ts, status], no day) are compared by time and status as before. known_until may be a dict
    {type: data end} (calendar_changes: ran_until): a type with no entry had no run of its picks, so no run computed
    with that row's time unknown (red team 5, item 3)."""
    from collections import Counter
    out = []
    by_type = known_until if isinstance(known_until, dict) else None
    for ty in sorted({r[0] for r in old} | {r[0] for r in new}):
        ku = (by_type.get(ty, -math.inf) if by_type is not None else known_until)
        o = [(r[1], r[2], r[3] if len(r) > 3 else None) for r in old if r[0] == ty]
        n = [(r[1], r[2], r[3] if len(r) > 3 else None) for r in new if r[0] == ty]
        o_ts, n_ts = Counter(t for t, _, _ in o if t is not None), Counter(t for t, _, _ in n if t is not None)
        o_st, n_st = {t: s for t, s, _ in o if t is not None}, {t: s for t, s, _ in n if t is not None}
        days = [d for _, _, d in o if d is not None]
        top_day = max(days) if days else None
        top = max(o_ts) if o_ts else None
        # a time added to a scheduled row without one: each new timed row explains at most one such row
        fresh = [(t, s, d) for t, s, d in n if t is not None and t not in o_ts]
        o_u = Counter((s, d) for t, s, d in o if t is None)
        n_u = Counter((s, d) for t, s, d in n if t is None)
        for (s, d), k in sorted(o_u.items(), key=lambda x: (x[0][1] or "", x[0][0])):
            for _ in range(k - min(k, n_u.get((s, d), 0))):
                hit = next((x for x in fresh if s == "scheduled" and d is not None and x[2] == d and ku
                            is not None and x[0] > ku and ("scheduled", x[1]) in
                            STATUS_UPDATES | {("scheduled", "scheduled")}), None)
                if hit is None:
                    out.append(f"{ty} {d}: a {s} row without a time removed, moved, changed, or given a time not "
                               "after the last run's data end")
                else:
                    fresh.remove(hit)
        for (s, d), k in sorted(n_u.items(), key=lambda x: (x[0][1] or "", x[0][0])):
            extra = k - o_u.get((s, d), 0)
            if extra > 0 and (s == "cancelled" or d is None or top_day is None or d <= top_day):
                out.append(f"{ty} {d}: {extra} {s} row(s) without a time added"
                           + ("" if s == "cancelled" else " inside the known range"))
        for t in sorted(o_ts):
            when = datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%dT%H:%MZ")
            if n_ts.get(t, 0) != o_ts[t]:
                out.append(f"{ty} {when}: {o_ts[t]} row(s) before, {n_ts.get(t, 0)} now (moved, removed or added)")
            elif n_st[t] != o_st[t] and (o_st[t], n_st[t]) not in STATUS_UPDATES:
                out.append(f"{ty} {when}: status {o_st[t]} -> {n_st[t]}")
        for t, s, d in sorted(fresh, key=lambda x: x[0]):
            if (top is not None and t <= top) or (top_day is not None and (d is None or d <= top_day)):
                when = datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%dT%H:%MZ")
                out.append(f"{ty} {when}: a row added inside the known range")
    return out


def last_run_state(log: list) -> dict | None:
    return next((r for r in reversed(log) if kind_of(r) == "run_state"), None)


def calendar_changes(log: list, cal_df: pd.DataFrame) -> list:
    """Changes of the forward calendar since the last run (its run_state's snapshot), by time and status. Any change
    may move a row behind a logged position or an open decision (one decided by the last run's data end, not yet
    settled), so the run refuses until a pushed STATS ruling allows it (fwd_io.calendar_ruling, append_run): the
    simplest strict form (red team 3, items 1 and 5). [] on the first run."""
    st = last_run_state(log)
    if st is None:
        return []
    if "calendar_rows" not in st:
        return ["the last run_state holds no calendar snapshot (an older runner); rule on the calendar"]
    return snapshot_changes(st["calendar_rows"], calendar_snapshot(cal_df), ran_until(log))


def ran_until(log: list) -> dict:
    """{event type: the highest data end of a run in which a pick of that type ran} over every run_state (red team
    5, item 3 and note N1): a time added to a row of a type whose picks did not run (check_coverage refused them while
    the row had no time) is a normal update. A run_state without ran_types (an older runner) counts for every type."""
    out = {}
    for r in log:
        if kind_of(r) != "run_state" or r.get("data_end_ts") is None:
            continue
        for ty in r.get("ran_types", EVENT_TYPES):
            out[ty] = max(out.get(ty, int(r["data_end_ts"])), int(r["data_end_ts"]))
    return out


class CalendarChanged(Refused):
    """The forward calendar changed since the last run and no pushed STATS ruling allows the change."""


# ------------------------------------------------------------------ the rules (frozen code, forward world)

def mirror_m1(m1: dict) -> dict:
    """Prices negated with bid and ask swapped: a long here is the original short, on the same bars (exact)."""
    return {"ts_utc": m1["ts_utc"], "bid_o": -m1["ask_o"], "bid_h": -m1["ask_l"], "bid_l": -m1["ask_h"],
            "bid_c": -m1["ask_c"], "ask_o": -m1["bid_o"], "ask_h": -m1["bid_l"], "ask_l": -m1["bid_h"],
            "ask_c": -m1["bid_c"], **({"volume": m1["volume"]} if "volume" in m1 else {})}


def make_cell(fz, pick: dict, cal: pd.DataFrame):
    p = pick["params"]
    if pick["adapter"] == "r47_cell":
        return next(c for c in fz.F.CELLS if c.id == p["cell"])
    if pick["adapter"] == "r55_fc":
        days = fz.A.fomc_days(cal[cal.type == "FOMC_STATEMENT"])
        plan = fz.A.fc_plan(days, tuple(p["weeks"]))[0]
        cal_ns = SimpleNamespace(plan=lambda cid, _p=plan: _p if fz.A.base(cid) == p["cell"] else {})
        return dataclasses.replace(fz.A.BY_ID[p["cell"]], decide_ts=fz.A.plan_decide(p["cell"], cal_ns),
                                  exit_ts=fz.A.plan_exit(p["cell"], cal_ns))
    raise ValueError(pick["adapter"])


def plan_r53(fz, w, params: dict) -> list:
    out = []
    for S in fz.r51.statements(w, all_times=bool(params.get("all_times", False))):
        d1 = fz.r51.prev_weekday(datetime.fromtimestamp(S, fz.r51.NY).date(), 1)
        out.append((fz.r51.ny_ts(d1, "14:00"), S - 300, S))
    return out


def simulate(fz, pick: dict, w, cal: pd.DataFrame, era: str, d_from: date, d_to: date, floor_ts: int) -> tuple:
    """(trades, plan) of one pick on world w, decisions on d_from..d_to at or after floor_ts.
    trades: the frozen code's dicts plus decision_ts and sched_exit_ts; plan: [(decision_ts, sched_exit_ts)].
    The forward path passes the pick's floor (>= FORWARD_START); the parity tests pass a BUILD floor."""
    p = pick["params"]
    lo = int(datetime.combine(d_from, time(0), timezone.utc).timestamp())
    hi = int(datetime.combine(d_to + timedelta(days=1), time(0), timezone.utc).timestamp())
    trades, plan = [], []
    if pick["adapter"] == "r53":
        for t, te, S in plan_r53(fz, w, p):
            if not (lo <= t < hi) or t < floor_ts:
                continue
            plan.append((t, te))
            x = fz.r53.trade(w, S, p["stop"], p["target"])
            if x:
                trades.append({**x, "decision_ts": t, "sched_exit_ts": te, "statement_ts": S})
    else:
        cell = make_cell(fz, pick, cal)
        decide = cell.decide_ts

        def floored(w_, d, _decide=decide):          # a decision before the floor is no decision (no busy either)
            t = _decide(w_, d)
            return t if t is not None and t >= floor_ts else None
        cell = dataclasses.replace(cell, decide_ts=floored)
        fz.F._EV_CACHE.clear()
        own = era in fz.E.ERAS and era != ERA            # a round's own era (parity tests) keeps its own dates
        with contextlib.nullcontext() if own else lent_era(fz.E, era, d_from, d_to, w.end_ts):
            for d in fz.E.decision_dates(era, cell.weekdays):
                t = cell.decide_ts(w, d)
                if t is not None:
                    plan.append((int(t), int(cell.exit_ts(w, d, t))))
            for x in fz.E.run_cell(w, cell, era):
                d = date.fromisoformat(x["date"])
                t = int(cell.decide_ts(w, d))
                trades.append({**x, "decision_ts": t, "sched_exit_ts": int(cell.exit_ts(w, d, t))})
        fz.F._EV_CACHE.clear()
    for x in trades:
        if x["decision_ts"] < floor_ts:
            raise OutcomeGuardError(f"{pick['id']}: a decision before the floor reached the trade list")
    return trades, plan


def settled_horizon(plan: list, data_end: int) -> float:
    """The first planned decision whose scheduled exit (plus the 15-minute fill limit) is not yet inside the data."""
    open_ = [t for t, te in plan if te + FILL_LIMIT > data_end]
    return min(open_) if open_ else math.inf


# ------------------------------------------------------------------ position-day rows (PASS_BAR.md section 2)

def _idx(ts: np.ndarray, v: int) -> int:
    i = int(np.searchsorted(ts, int(v)))
    if i >= len(ts) or int(ts[i]) != int(v):
        raise RuntimeError(f"bar {v} not in the world")
    return i


def _bar_after(ts: np.ndarray, t: int) -> int:
    i = int(np.searchsorted(ts, int(t)))
    return i if i < len(ts) and int(ts[i]) < int(t) + FILL_LIMIT else -1


def fin_nights(a: int, b: int) -> dict:
    """{label: nights} for every 17:00 New York close, Monday to Friday, in (a, b]: 3 nights on a Wednesday close,
    else 1 (COST's financing_nights). Read from the calendar, not from the bars, so a holiday close is charged."""
    d, out = datetime.fromtimestamp(int(a), NY).date() - timedelta(days=1), {}
    while True:
        c = label_close_ts(d)
        if c > int(b):
            return out
        if c > int(a) and d.weekday() < 5:
            out[d.isoformat()] = 3 if d.weekday() == 2 else 1
        d += timedelta(days=1)


def split_days(m: dict, labels: np.ndarray, i: int, j: int, side: int, entry: float, exit_: float, scale: float,
               fin: dict, net: float) -> tuple:
    """({label: P&L}, {label: gross mark}) of one side from bar i (entry) to bar j (exit): marked at each 17:00 New
    York close at the bid (long) or ask (short); financing (pips) on the label whose close was held; the rest of the
    cost (<= 0) on the first label, so the labels sum to `net` exactly."""
    days = weekday_labels(labels[i], labels[j])
    if not set(fin) <= set(days):
        raise RuntimeError("a financing label outside the position's labels")
    col = "bid_c" if side > 0 else "ask_c"
    out, prev = {}, entry
    for L in days[:-1]:
        k = int(np.searchsorted(labels[i:j], L, side="right")) - 1 + i      # last bar of label L before the exit bar
        mark = m[col][k] if k >= i and labels[k] == L else prev
        out[L] = float(side * (mark - prev) / scale)
        prev = mark
    out[days[-1]] = float(side * (exit_ - prev) / scale)
    gross = dict(out)
    for L, f in fin.items():
        out[L] -= f * PIP / scale
    top = net - sum(out.values())
    if top > 1e-9:
        raise RuntimeError("cost top-up above 0: the marks do not match the net")
    out[days[0]] += top
    return out, gross


def _merge(long_d: dict, short_d: dict, a: str = "pnl_long", b: str = "pnl_short") -> list:
    """Rows from the entry label to the later of the two exits; a side already closed has 0 that day."""
    keys = weekday_labels(min(min(long_d), min(short_d)), max(max(long_d), max(short_d)))
    return [{"day": k, a: float(long_d.get(k, 0.0)), b: float(short_d.get(k, 0.0))} for k in keys]


def _r53_fill(fz, w, x: dict, stop_v: str, tgt_v: str, t: int) -> dict:
    """A Round 53 long's entry, stop, target, fills (with and without the 0.2 pip) and mid exit, from its own helpers,
    checked against the frozen trade."""
    m, ts = w.m1, w.m1["ts_utc"]
    i, jj = _idx(ts, x["entry_ts"]), _idx(ts, x["exit_ts"])
    entry = m["ask_o"][i] + fz.E.SLIP
    sp = fz.r53.stop_px(w, stop_v, t, entry)
    r_px = entry - sp
    tgt = entry + TARGET_R[tgt_v] * r_px if tgt_v in TARGET_R else None
    mid_j = (m["bid_o"][jj] + m["ask_o"][jj]) / 2
    raw, midf = {"target": (tgt, tgt), "stop": (min(sp, m["bid_o"][jj]), min(sp, mid_j)),
                 "time": (m["bid_o"][jj], mid_j)}[x["why"]]
    fill = raw if x["why"] == "target" else raw - fz.E.SLIP
    if abs(r_px / PIP - x["r_pips"]) > 1e-9 or abs((fill - entry) / r_px - x["R_ba"]) > 1e-9:
        raise RuntimeError("Round 53 fill does not match the frozen trade")
    return {"entry": entry, "stop": sp, "target": tgt, "fill": fill, "raw": raw, "mid_exit": midf, "i": i, "jj": jj,
            "r_px": r_px, "why": x["why"]}


def _spread(m: dict, k: int, kind: str, at_open: bool = False) -> float:
    """ask - bid in pips at a fill: the bar's open for a market fill, and for a stop filled at the bar's open (a gap
    through the stop); the smaller of its open and close quotes for a stop or target filled inside the bar (the quote
    at the fill moment is not known, and cost.py tops the spread up to its floor, so the smaller one is the strict
    side; red team 3, item 4)."""
    o = (m["ask_o"][k] - m["bid_o"][k]) / PIP
    if kind in ("stop", "target") and not at_open:
        o = min(o, (m["ask_c"][k] - m["bid_c"][k]) / PIP)
    return float(o)


def _vol(vol, k: int):
    if vol is None or not np.isfinite(vol[k]):
        return None
    return float(vol[k])


def side_rec(wx, sign: int, f: dict, t: int, vol) -> dict:
    """One side's re-costing inputs (fwd_cost.price_side). f is in world wx's prices (the mirrored world for the
    short); the stored prices are real (sign x world)."""
    m, ts = wx.m1, wx.m1["ts_utc"]
    i, jj = f["i"], f["jj"]
    mid0 = (m["bid_o"][i] + m["ask_o"][i]) / 2
    kind = EXIT_KIND[f["why"]]
    gap = kind == "stop" and float(f["raw"]) == float(m["bid_o"][jj])     # filled at the open, through the stop
    return {"side": sign, "decision_ts": int(t), "entry_ts": int(ts[i]), "exit_ts": int(ts[jj]),
            "entry_kind": "market", "exit_kind": kind, "entry_price": float(sign * m["ask_o"][i]),
            "exit_price": float(sign * f["raw"]), "entry_spread": _spread(m, i, "market"),
            "exit_spread": _spread(m, jj, kind, gap), "vol_entry": _vol(vol, i), "vol_exit": _vol(vol, jj),
            "mid_entry": float(sign * mid0), "mid_exit": float(sign * f["mid_exit"]),
            "move_mid_pips": float((f["mid_exit"] - mid0) / PIP), "ba_slip_pips": float((f["fill"] - f["entry"]) / PIP),
            "fin_nights": fin_nights(int(ts[i]), int(ts[jj]))}


def _cell_fill(fz, wx, x: dict) -> dict:
    m, ts = wx.m1, wx.m1["ts_utc"]
    i, jj = _idx(ts, x["entry_ts"]), _idx(ts, x["exit_ts"])
    return {"entry": m["ask_o"][i] + fz.E.SLIP, "fill": m["bid_o"][jj] - fz.E.SLIP, "raw": m["bid_o"][jj],
            "mid_exit": (m["bid_o"][jj] + m["ask_o"][jj]) / 2, "i": i, "jj": jj, "why": "time",
            "stop": None, "target": None}


def _frozen_check(rec: dict, frozen_net_pips: float, frozen_fin_pips: float, what: str) -> None:
    """The 2.0-pip net before financing equals the frozen code's (its financing is Round 45's on the bars' days)."""
    pre = min(rec["move_mid_pips"] - fwd_cost.FLOOR_PASS, rec["ba_slip_pips"])
    if abs(pre - (frozen_net_pips + frozen_fin_pips)) > 1e-9:
        raise RuntimeError(f"{what}: the 2.0-pip net does not match the frozen trade")


def log_line(fz, pick: dict, w, w_mir, labels: np.ndarray, x: dict, run_id: str, cost=None, vol=None,
             deps: dict | None = None) -> dict:
    """position_line, refused for any time before FORWARD_START (the only builder the forward path uses)."""
    check_trade(x)
    line = position_line(fz, pick, w, w_mir, labels, x, run_id, cost, vol, deps)
    check_trade(line)
    return line


def position_line(fz, pick: dict, w, w_mir, labels: np.ndarray, x: dict, run_id: str, cost=None, vol=None,
                  deps: dict | None = None) -> dict:
    """One log line: the trade, its fills, its nets (fwd_cost), its re-costing inputs, the calendar rows it depends
    on, and its position-day rows. No era check here (parity tests use BUILD)."""
    p, m, ts = pick["params"], w.m1, w.m1["ts_utc"]
    t = int(x["decision_ts"])
    fin45 = (lambda f: fz.E.r45.financing_pips(int(ts[f["i"]]), int(ts[f["jj"]]), w.days))
    if pick["adapter"] == "r53":
        L = _r53_fill(fz, w, x, p["stop"], p["target"], t)
        xm = fz.r53.trade(w_mir, x["statement_ts"], p["stop"], p["target"])
        if not xm or xm["entry_ts"] != x["entry_ts"] or abs(xm["R_20"] - x["R_20_short"]) > 1e-9:
            raise RuntimeError("mirrored Round 53 trade does not match R_20_short")
        M = _r53_fill(fz, w_mir, xm, p["stop"], p["target"], t)
        scale, r_pips, reason = L["r_px"], x["r_pips"], x["why"]
        rec_l, rec_s = side_rec(w, 1, L, t, vol), side_rec(w_mir, -1, M, t, vol)
        _frozen_check(rec_l, x["R_20"] * r_pips, fin45(L), "Round 53 long")
        _frozen_check(rec_s, x["R_20_short"] * r_pips, fin45(M), "Round 53 mirrored short")
    else:
        if x["side"] != 1 or x["net"] != x["net_long"]:
            raise RuntimeError("the forward picks are long-only")
        L, M = _cell_fill(fz, w, x), _cell_fill(fz, w_mir, x)
        scale, r_pips, reason = PIP, None, "time"
        rec_l, rec_s = side_rec(w, 1, L, t, vol), side_rec(w_mir, -1, M, t, vol)
        _frozen_check(rec_l, x["net_long"], x["fin"], f"{pick['id']} long")
        _frozen_check(rec_s, x["net_short"], x["fin"], f"{pick['id']} short")
        if abs(min(rec_l["move_mid_pips"] - fwd_cost.FLOOR_INFO, rec_l["ba_slip_pips"]) - (x["net16"] + x["fin"])) > 1e-9:
            raise RuntimeError(f"{pick['id']}: the 1.6-pip net does not match the frozen trade")
    nl, why_l = fwd_cost.price_side(cost, rec_l)
    ns, why_s = fwd_cost.price_side(cost, rec_s)
    reasons = sorted(set(why_l) | set(why_s))
    unit = r_pips if r_pips else 1.0
    fin_l = {k: n * fwd_cost.FIN_R45_PIPS for k, n in rec_l["fin_nights"].items()}
    fin_s = {k: n * fwd_cost.FIN_R45_PIPS for k, n in rec_s["fin_nights"].items()}
    long_d, gl = split_days(m, labels, L["i"], L["jj"], 1, L["entry"], L["fill"], scale, fin_l, nl["pass_case"] / unit)
    short_d, gs = split_days(m, labels, M["i"], M["jj"], -1, -M["entry"], -M["fill"], scale, fin_s,
                             ns["pass_case"] / unit)
    long2, _ = split_days(m, labels, L["i"], L["jj"], 1, L["entry"], L["fill"], scale, fin_l,
                          nl["pass_case_fin2p0"] / unit)
    short2, _ = split_days(m, labels, M["i"], M["jj"], -1, -M["entry"], -M["fill"], scale, fin_s,
                           ns["pass_case_fin2p0"] / unit)
    days = _merge(long_d, short_d)
    for row, r2 in zip(days, _merge(long2, short2, "pnl_long_fin2p0", "pnl_short_fin2p0"), strict=True):
        if row["day"] != r2["day"]:
            raise RuntimeError("the 2.0% financing rows are on other labels than the pass-case rows")
        row.update(pnl_long_fin2p0=r2["pnl_long_fin2p0"], pnl_short_fin2p0=r2["pnl_short_fin2p0"])
    mid0 = (m["bid_o"][L["i"]] + m["ask_o"][L["i"]]) / 2
    i, jj = L["i"], L["jj"]
    return {"kind": "trade", "pick_id": pick["id"], "position_id": f"{pick['id']}@{t}", "pair": PAIR, "side": 1,
            "w": 1.0, "unit": pick["unit"], "decision_ts": t, "decision_label": label_of(t),
            "sched_exit_ts": int(x["sched_exit_ts"]), "entry_ts": int(x["entry_ts"]), "entry": float(L["entry"]),
            "stop": None if L["stop"] is None else float(L["stop"]),
            "target": None if L["target"] is None else float(L["target"]),
            "exit_ts": int(x["exit_ts"]), "exit": float(L["fill"]), "exit_reason": reason,
            "r_pips": None if r_pips is None else float(r_pips),
            "net_pips": float(nl["pass_case"]), "net_R": None if r_pips is None else float(nl["pass_case"] / r_pips),
            "net_short": float(ns["pass_case"] / unit), "net_ret_1x": float(nl["pass_case"] * PIP / mid0),
            "net": {"long": nl, "short": ns}, "below_pass_case": bool(reasons), "below_pass_case_reasons": reasons,
            "fills": {"entry_bid": float(m["bid_o"][i]), "entry_ask": float(m["ask_o"][i]),
                      "exit_bid": float(m["bid_o"][jj]), "exit_ask": float(m["ask_o"][jj])},
            "recost": {"long": rec_l, "short": rec_s}, "gross_days": _merge(gl, gs, "long", "short"),
            "cost": COST_BASIS,
            "cost_model": None if cost is None else {"cost_commit": getattr(cost, "commit", None),
                                                     "model_sha256": cost.model_sha256},
            "events": None if deps is None else {k: v for k, v in deps.items() if k != "final"},
            "days": days, "run_ledger_id": run_id, "pick_sha256": pick["_sha256"]}


def no_trade_line(pick: dict, w, t: int, te: int, deps: dict, run_id: str) -> dict:
    """A settled planned decision without a trade: no entry bar within 15 minutes (the rule's own 'no trade'), no exit
    bar within 15 minutes of the scheduled exit (logged as no_exit_bar, never dropped silently), or the rule skipped it
    (one position at a time, no ATR). Times only."""
    check_decision(t)
    ts = w.m1["ts_utc"]
    why = "no_entry_bar" if _bar_after(ts, t) < 0 else ("no_exit_bar" if _bar_after(ts, te) < 0 else "rule")
    return {"kind": "no_exit_bar" if why == "no_exit_bar" else "no_trade", "reason": why, "pick_id": pick["id"],
            "position_id": f"{pick['id']}@{int(t)}", "decision_ts": int(t), "decision_label": label_of(t),
            "sched_exit_ts": int(te), "events": {k: v for k, v in deps.items() if k != "final"},
            "run_ledger_id": run_id, "pick_sha256": pick["_sha256"]}


# ------------------------------------------------------------------ one run

@dataclasses.dataclass
class RunResult:
    lines: list                 # trade, no_trade, no_exit_bar and error lines, in pick and decision order
    floors: dict                # pick -> the floor this run started from
    horizons: dict              # pick -> its first unsettled planned decision (inf: none); errored picks absent
    errors: dict                # pick -> error type name
    waiting: dict               # pick -> event ids of past rows not yet final (the calendar needs updating)
    data_end: int
    run_id: str
    calendar_errors: dict = dataclasses.field(default_factory=dict)  # pick -> its CalendarError (dates only)
    ran_types: list = dataclasses.field(default_factory=list)        # event types of the picks that ran (no error)


def compute_run(picks: list, cal_df: pd.DataFrame, all_m1: dict, data_end: int, run_id: str, floors: dict | None = None,
                cost=None, run_day: date | None = None) -> RunResult:
    """Every pick on forward bars from its floor. all_m1 holds the lagged inputs and the forward bars; cal_df is the
    forward calendar as read_calendar returns it. A pick's error (its calendar coverage, its frozen code) becomes an
    error line and the other picks go on; a guard or pin error stops the run."""
    fz = frozen(picks)
    floors = {p["id"]: max(FORWARD_START, int((floors or {}).get(p["id"], FORWARD_START))) for p in picks}
    res = RunResult([], floors, {}, {}, {}, int(data_end), run_id)
    if len(all_m1["ts_utc"]):
        check_inputs_start(int(np.min(all_m1["ts_utc"])))
    days = fz.E.r45.daily_bars(all_m1)                       # lagged inputs: ATR20 and the 17:00 closes
    m_out = outcome_bars(all_m1)                             # the guard: forward bars only from here on
    if not len(m_out["ts_utc"]):
        return res
    cal, allrows = calendar_rows(cal_df), calendar_all(cal_df)
    events = events_frame(cal)
    w = fz.E.World(m_out, {}, events, days, int(data_end))
    w_mir = fz.E.World(mirror_m1(m_out), {}, events, fz.E.r45.daily_bars(mirror_m1(all_m1)), int(data_end))
    labels = bar_labels(m_out["ts_utc"])
    vol = None if cost is None else cost.vol(m_out["ts_utc"], (m_out["bid_c"] + m_out["ask_c"]) / 2)
    d_to = date.fromisoformat(label_of(int(data_end) - 60))
    run_day = run_day or d_to
    for pick in picks:
        pid = pick["id"]
        try:
            check_coverage(cal_df, run_day, pick.get("calendar", EVENT_TYPES))
            floor = floors[pid]
            d_from = datetime.fromtimestamp(floor, timezone.utc).date() - timedelta(days=2)
            trades, plan = simulate(fz, pick, w, cal, ERA, d_from, d_to, floor)
            by_t = {int(x["decision_ts"]): x for x in trades}
            if not set(by_t) <= {int(t) for t, _ in plan}:
                raise RuntimeError(f"{pid}: a trade outside the plan")
            out, horizon = [], math.inf
            for t, te in sorted({(int(a), int(b)) for a, b in plan}):
                dep = deps_of(pick, t, te, allrows)
                if te + FILL_LIMIT > int(data_end) or dep is None or not dep["final"]:
                    horizon = t
                    break
                x = by_t.get(t)
                out.append(log_line(fz, pick, w, w_mir, labels, x, run_id, cost, vol, dep) if x is not None
                           else no_trade_line(pick, w, t, te, dep, run_id))
            types = pick_types(pick)
            past = allrows[allrows.type.isin(types) & (allrows.status != "cancelled") & (allrows.ts < int(data_end))
                           & (allrows.ts >= FORWARD_START - 60 * 86400) & ~allrows.final]
            res.lines += out
            res.horizons[pid] = horizon
            res.waiting[pid] = sorted(past.event_id)
        except (OutcomeGuardError, PinError):
            raise
        except Exception as e:                                # one pick's error never stops the others
            res.errors[pid] = type(e).__name__
            if isinstance(e, CalendarError):                  # a calendar reason: dates only (red team 5, item 6)
                res.calendar_errors[pid] = str(e)[:300]
            res.lines.append({"kind": "error", "pick_id": pid, "error": type(e).__name__, "message": str(e)[:500],
                              "run_ledger_id": run_id, "data_end_ts": int(data_end)})
    res.ran_types = sorted({t for p in picks if p["id"] not in res.errors for t in pick_types(p)})
    return res


def pick_types(pick: dict) -> list:
    """The event types a pick's plan depends on (deps_of): FOMC for R53 and FC-1, its calendar for the others."""
    return ["FOMC_STATEMENT"] if pick["adapter"] in ("r53", "r55_fc") else list(pick.get("calendar", EVENT_TYPES))


def compute(picks: list, cal_df: pd.DataFrame, all_m1: dict, data_end: int, run_id: str, floors: dict | None = None,
            cost=None, run_day: date | None = None) -> list:
    """compute_run's lines."""
    return compute_run(picks, cal_df, all_m1, data_end, run_id, floors, cost, run_day).lines


# ------------------------------------------------------------------ the log (append-only, idempotent; dept/stats-locked)

POSITION_KINDS = ("trade", "no_trade", "no_exit_bar")


class BelowPassCase(RuntimeError):
    """A trade line was priced below PASS_BAR.md section 3 (its reasons are on the line)."""


def kind_of(r: dict) -> str:
    return r.get("kind", "trade")


def check_log_path(path: Path) -> Path:
    """The log is never written inside this checkout (dept/stats is merged; the log lives on dept/stats-locked)."""
    p, repo = Path(path).resolve(), REPO.resolve()
    if p == repo or repo in p.parents:
        raise Refused(f"{p} is inside this checkout; the forward log lives only on dept/stats-locked")
    return p


def read_log(path: Path) -> list:
    path = Path(path)
    if not path.exists():
        return []
    read_text = checked_reader("read_text")
    return [json.loads(l) for l in read_text(path).splitlines() if l.strip()]


def _canon(r: dict) -> str:
    return json.dumps(json.loads(json.dumps({k: v for k, v in r.items() if k != "run_ledger_id"})), sort_keys=True)


def _write(path: Path, rows: list) -> None:
    check_log_path(path)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        for r in rows:
            f.write(json.dumps(r, sort_keys=True) + "\n")
        f.flush()
        os.fsync(f.fileno())


def append_log(lines: list, path: Path, windows: dict | None = None) -> int:
    """Append the lines not yet logged; returns the number of new trade lines. A logged position is never removed or
    voided (a calendar change refuses the run instead: calendar_changes, append_run).
    - A logged position recomputed differently in any field but run_ledger_id, or a new trade decided before a logged
      trade of the same pick, stops the run (the bars never change, so either is a bug).
    - With windows {pick: (floor, horizon)}: a logged position in that range that the recomputation no longer gives
      stops the run (it disappeared)."""
    check_log_path(path)
    log = read_log(path)
    new = []
    active = {r["position_id"]: r for r in log if kind_of(r) in POSITION_KINDS}
    last = {}
    for r in active.values():
        if kind_of(r) == "trade":
            last[r["pick_id"]] = max(last.get(r["pick_id"], -1), r["decision_ts"])
    seen = set()
    for r in lines:
        k = kind_of(r)
        if k == "error":
            new.append(r)
            continue
        if k not in POSITION_KINDS:
            raise ValueError(f"unknown line kind {k!r}")
        pid = r["position_id"]
        seen.add(pid)
        o = active.get(pid)
        if o is not None:
            if _canon(o) != _canon(r):
                raise RuntimeError(f"{pid} recomputed differently from its logged line")
            continue
        if k == "trade":
            if r["decision_ts"] <= last.get(r["pick_id"], -1):
                raise RuntimeError(f"{pid} is decided before a logged position of {r['pick_id']}")
            last[r["pick_id"]] = r["decision_ts"]
        new.append(r)
    for pick, (lo, hi) in (windows or {}).items():
        gone = sorted(p for p, r in active.items() if r["pick_id"] == pick and lo <= r["decision_ts"] < hi
                      and p not in seen)
        if gone:
            raise RuntimeError(f"logged positions of {pick} disappeared from the recomputation: {gone}")
    if new:
        _write(path, new)
    return sum(1 for r in new if kind_of(r) == "trade")


NOTE_KINDS = ("discarded_uncommitted", "calendar_ruled")


def append_note(path: Path, row: dict) -> None:
    """A note line in the log (no position): e.g. that a crashed run's uncommitted lines were dropped."""
    if kind_of(row) not in NOTE_KINDS:
        raise ValueError(f"unknown note kind {kind_of(row)!r}")
    _write(path, [row])


def floors_from_log(log: list, picks: list) -> dict:
    """Each pick's floor from the last run_state line (FORWARD_START before the first run)."""
    st = last_run_state(log)
    nf = (st or {}).get("next_floor", {})
    return {p["id"]: max(FORWARD_START, int(nf.get(p["id"], FORWARD_START))) for p in picks}


def append_run(res: RunResult, path: Path, cal_df: pd.DataFrame, ruling: dict | None = None) -> dict:
    """append_log for a run, then its run_state line: each pick's next floor = the later of its first unsettled
    decision (the data end when none) and its last logged trade's exit (the one-position rule), never below its floor.
    An errored pick keeps its floor. The run_state holds the calendar's sha256 and snapshot (calendar_snapshot).
    Refused (CalendarChanged) before anything is written when the calendar changed since the last run
    (calendar_changes) and no ruling is given; with the pushed ruling (fwd_io.calendar_ruling) a calendar_ruled note
    records it and the changes, and every logged position stays as it is (red team 3, items 1 and 5)."""
    check_log_path(path)
    changes = calendar_changes(read_log(path), cal_df)
    if changes and ruling is None:
        raise CalendarChanged(f"the forward calendar changed since the last run: {changes[:5]}; nothing is logged "
                              "until a pushed STATS ruling allows the change")
    if changes:
        _write(path, [{"kind": "calendar_ruled", "run_ledger_id": res.run_id, "changes": changes, "ruling": ruling,
                       "calendar_sha256": calendar_sha(cal_df)}])
    windows = {p: (res.floors[p], h) for p, h in res.horizons.items()}
    n = append_log(res.lines, path, windows)
    log = read_log(path)
    nxt = {}
    for p, f in res.floors.items():
        if p not in res.horizons:
            nxt[p] = f
            continue
        h = res.horizons[p]
        exits = [r["exit_ts"] for r in log if kind_of(r) == "trade" and r["pick_id"] == p]
        nxt[p] = int(max([f, res.data_end if math.isinf(h) else h] + exits))
    state = {"kind": "run_state", "run_ledger_id": res.run_id, "data_end_ts": res.data_end, "floors_used": res.floors,
             "next_floor": nxt, "errors": res.errors, "waiting_on_events": res.waiting,
             "calendar_sha256": calendar_sha(cal_df), "calendar_rows": calendar_snapshot(cal_df),
             "ran_types": res.ran_types}
    _write(path, [state])
    return {"new_trades": n, "next_floor": nxt, "errors": res.errors, "waiting": res.waiting,
            "calendar_errors": res.calendar_errors}


FIN_SERIES = {"pass": ("pnl_long", "pnl_short"), "2.0": ("pnl_long_fin2p0", "pnl_short_fin2p0")}

# ------------------------------------------------------------------ forward numbers: refused until the forward judge
# PASS_BAR.md section 11 (a declared forward test, k and alpha 0.05/2^k, power and length, whole positions, forward
# shift copies, one logged look) is a later build with its own red team. Until it exists, forward_table,
# forward_verdict and forward_verdicts return no number outside a test (red team 3, item 2): no forward test can be
# declared yet, so every call is refused. Tests reach them only through _TEST_ONLY_LOOKS, which tests set (a list
# that records each look before any number is computed) and which counts only when the main program is pytest
# (research.common.access.main_info), the pytest module is loaded and a test is running (PYTEST_CURRENT_TEST; red
# team 4, item 6): run_forward never sets it, and any other main is refused even if it does. A convention against
# mistakes only: a script that sets it on purpose can fake all three signs (FORWARD.md "Forward numbers").
_TEST_ONLY_LOOKS = None


def forward_look(what: str, test_id: str | None) -> None:
    """The gate in front of every forward number (red team 3, item 2). Refused unless a test, with the main program
    pytest, the pytest module loaded and a test running (PYTEST_CURRENT_TEST set; red team 4, item 6), has set
    _TEST_ONLY_LOOKS (then the look is recorded there first). This is a convention against mistakes, not a security
    boundary: code that sets _TEST_ONLY_LOOKS on purpose can also fake these signs. Only the forward judge
    (PASS_BAR.md section 11) may compute a forward number for a decision."""
    from research.common import access as A
    looks = _TEST_ONLY_LOOKS
    info = A.main_info()
    if (looks is not None and info is not None and info.get("pytest") and "pytest" in sys.modules
            and os.environ.get("PYTEST_CURRENT_TEST")):
        looks.append({"what": what, "test_id": test_id})
        return
    raise Refused(f"{what}: no forward number before the forward judge (PASS_BAR.md section 11) exists: it needs a "
                  "declared forward test with a pushed declaration line and a pushed look line, and none can be "
                  f"declared yet (test id {test_id!r}); refused")


def _current_pins(pick_id: str) -> tuple:
    """(pick sha256, cost pin) as DEPS.json holds them now: the pick's file and COST's commit and model sha256."""
    pick = next((p for p in load_picks() if p["id"] == pick_id), None)
    if pick is None:
        raise Refused(f"{pick_id} is not a registered pick")
    d = fwd_cost.pin()
    model = next(v for k, v in d["files"].items() if k.endswith(".json"))
    return pick["_sha256"], {"cost_commit": d["cost_commit"], "model_sha256": model}


def forward_table(pick_id: str, path: Path, allow_below_pass_case: bool = False, markup: str = "pass",
                  window: tuple | None = None, test_id: str | None = None) -> pd.DataFrame:
    """judge.py's position-day table (PASS_BAR.md section 2) for one pick, from the log: trade lines only, every logged
    position kept (no calendar change removes one). Refused before reading the log unless forward_look allows it (no
    forward number outside a test until the forward judge exists). Refused (BelowPassCase) while any line is priced
    below the pass case, unless allow_below_pass_case (tests only, format checks, never a judgement). Refused when the
    lines carry more than one pick or cost pin, or an older one than DEPS.json's (red team 3, item 10; a re-pricing
    line kind comes with the forward judge). markup="pass" (the pass case, COST_MODEL financing.markup_pct_year) or
    "2.0" (the same rows with COST's financing at 2.0% a year; PASS_BAR.md v7 section 3): only pnl_long and pnl_short
    differ, never upward. A line without the 2.0% series is refused. window (lo_ts, hi_ts): the positions decided in
    [lo_ts, hi_ts), each with ALL its day rows, also those after hi_ts: a position is never cut, so its financing and
    costs on any label stay with it (red team 3, item 6)."""
    if markup not in FIN_SERIES:
        raise ValueError(f"markup is 'pass' or '2.0', not {markup!r}")
    forward_look(f"forward_table {pick_id}", test_id)
    lc, sc = FIN_SERIES[markup]
    log = read_log(path)
    mine = [r for r in log if kind_of(r) == "trade" and r["pick_id"] == pick_id
            and (window is None or int(window[0]) <= int(r["decision_ts"]) < int(window[1]))]
    if mine:
        picks_seen = {r.get("pick_sha256") for r in mine}
        costs_seen = {json.dumps(r.get("cost_model"), sort_keys=True) for r in mine}
        if len(picks_seen) > 1 or len(costs_seen) > 1:
            raise Refused(f"{pick_id}: the lines carry mixed pins (pick {sorted(map(str, picks_seen))}, cost "
                          f"{sorted(costs_seen)}); a re-pricing line kind comes with the forward judge")
        cur_pick, cur_cost = _current_pins(pick_id)
        if picks_seen != {cur_pick}:
            raise Refused(f"{pick_id}: the lines were logged with an older pick pin than DEPS.json's")
        if costs_seen not in ({json.dumps(cur_cost, sort_keys=True)}, {"null"}):
            raise Refused(f"{pick_id}: the lines were priced with an older COST pin than DEPS.json's")
    rows = []
    for r in mine:
        if r.get("below_pass_case", True) and not allow_below_pass_case:
            raise BelowPassCase(f"{r['position_id']} is priced below the pass case: {r.get('below_pass_case_reasons')}")
        for d in r["days"]:
            if lc not in d or sc not in d:
                raise Refused(f"{r['position_id']} has no {lc} and {sc} series (logged before PASS_BAR.md v7); "
                              "price it again from its recost inputs")
            rows.append({"position_id": r["position_id"], "pair": r["pair"], "day": d["day"],
                         "decision_ts": r["decision_ts"], "w": r["w"], "pnl_long": d[lc], "pnl_short": d[sc]})
    return pd.DataFrame(rows, columns=["position_id", "pair", "day", "decision_ts", "w", "pnl_long", "pnl_short"])


# ------------------------------------------------------------------ forward test verdicts (PASS_BAR.md sections 3, 11)

FIN2_MARK = "financing-sensitive"


def forward_verdict(r: dict, alpha: float, test_id: str | None = None) -> tuple:
    """PASS_BAR.md section 11 on one judged window (judge.judge_window on a forward_table, shift copies from forward
    labels): PASS when net is above 0 and p_net, p_random_side, p_same_tilt and p_shift are each <= alpha_k (or its
    look share). A missing p is not a pass. Refused unless forward_look allows it (tests only, until the forward judge
    exists)."""
    forward_look("forward_verdict", test_id)
    le = (lambda p: p is not None and p <= alpha)
    items = {"net_above_0": r["net_total"] > 0, "p_net_le_alpha": le(r.get("p_net")),
             "p_random_side_le_alpha": le(r.get("p_random_side")), "p_same_tilt_le_alpha": le(r.get("p_same_tilt")),
             "p_shift_le_alpha": le(r.get("p_shift"))}
    return ("PASS" if all(items.values()) else "FAIL"), items


def forward_verdicts(r_pass: dict, r_fin2p0: dict, alpha: float, test_id: str | None = None) -> dict:
    """The forward verdict at the pass case and at 2.0% financing (forward_table(markup="2.0"), judged with the same
    call, alpha, block and seeds). The verdict is the pass-case one; a PASS that fails at 2.0% (net at or below 0, or a
    p above alpha) is financing-sensitive (PASS_BAR.md v7 section 3). A FAIL is never marked, whatever the 2.0% row
    says. Refused unless forward_look allows it (tests only, until the forward judge exists)."""
    forward_look("forward_verdicts", test_id)
    if r_fin2p0.get("block") != r_pass.get("block"):
        raise ValueError("the 2.0% financing table was judged at another block length")
    word, items = forward_verdict(r_pass, alpha, test_id)
    word2, items2 = forward_verdict(r_fin2p0, alpha, test_id)
    sens = word == "PASS" and word2 != "PASS"
    return {"verdict": word, "items": items, "verdict_at_2p0": word2, "items_fin2p0": items2,
            "financing_sensitive": sens, "mark": FIN2_MARK if sens else None}
