"""STATS forward log: COST's model (COST_MODEL.json v3 and cost.py, pinned in DEPS.json "cost") on the forward paper
trades, and the pass-case net of PASS_BAR.md section 3. Prices costs only; places no orders.

COST's two files are imported from this checkout only (they reach dept/stats with its merge of the coordinator
branch), after their sha256 match DEPS.json. Per side of every trade (the long, and the mirrored short):
- floor_2p0: the frozen rounds' convention, min(mid move - 2.0, bid/ask result with 0.2 pip per market or stop fill),
  less Round 45's financing (1 pip a night, 3 for a Wednesday close) on every calendar 17:00 New York close held;
- floor_1p6: the same at 1.6 pips (information only);
- cost_v3_ex_financing: cost.py's CostModel.net_pips at the actual bid/ask fills (freezing=True): spread charged at
  max(actual, half the hour-of-week floor at each leg with the release and rollover windows, pair_min 2.0), plus
  0.35 pip per market or stop fill (1.4 within 5 minutes of a listed release, 0.6 in 16:55-17:15 New York);
- financing_v3: COST's own financing_rows (rate differential against the side, at the end of each rate's range that
  hurts, + COST_MODEL financing.markup_pct_year, the pass case: 1.5% a year per position since COST v3.3; per 17:00
  New York roll), only with a rate(ccy, ts) input, DATA's as-of policy-rate series; none is released or pinned yet;
- pass_case = min(floor_2p0, cost_v3_ex_financing - financing), financing = financing_v3 when known, else Round 45's;
- financing_v3_2p0_pips and pass_case_fin2p0: the same at 2.0% a year (financing_rows with markup_pct_year=2.0,
  freezing=True; PASS_BAR.md v7 section 3, "Financing-sensitive"), with the same Round 45 fallback, so without rates
  the two pass cases are equal. pass_case_fin2p0 <= pass_case always; a verdict at 2.0% only marks a pass
  financing-sensitive (fwd_core.forward_verdicts).
While any part of COST's model cannot be applied, the line is below_pass_case with the reasons, and
fwd_core.forward_table refuses it. `rec` (one per side, stored on the line) holds every input needed to price it again.
"""
from __future__ import annotations

import importlib.util
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[4]))      # this checkout's root (DATA's research/common)
import research.common  # noqa: E402,F401  (first, before COST's cost.py: DATA's runtime audit hook)

PIP = 1e-4
COST_PAIR = "EURUSD"
HERE = Path(__file__).resolve().parent
DEPS = HERE / "DEPS.json"
MODULE = "stats_forward_cost_v3"                 # COST's cost.py under its own name (research.common.cost is DATA's)
FLOOR_PASS, FLOOR_INFO = 2.0, 1.6
FIN_R45_PIPS = 1.0                               # per night held; a Wednesday close counts 3 nights
FIN_SENS_MARKUP = 2.0                            # % a year per position: PASS_BAR.md v7 section 3 sensitivity row


def pin(deps: Path | None = None) -> dict:
    return json.loads(Path(deps or DEPS).read_text())["cost"]


def audit_inputs():
    """research/departments/STATS/audit_inputs.py (STATS's freeze and audit gate), from this checkout only."""
    import fwd_core as C
    want = (C.STATS / "audit_inputs.py").resolve()
    mod = sys.modules.get("audit_inputs")
    if mod is None or Path(mod.__file__).resolve() != want:
        spec = importlib.util.spec_from_file_location("audit_inputs", want)
        mod = importlib.util.module_from_spec(spec)
        sys.modules["audit_inputs"] = mod
        spec.loader.exec_module(mod)
    return mod


def check(repo: Path, deps: Path | None = None) -> dict:
    """COST's pinned files in `repo`: none on STATS's refused list (audit_inputs.REFUSED, e.g. a cost.py that charges
    no release cost), each present with its sha256. Refused if refused or missing, PinError if changed."""
    import fwd_core as C
    d = pin(deps)
    bad = audit_inputs().check_frozen_inputs({"cost": d})
    if bad:
        raise C.Refused(f"DEPS.json cost pin refused by audit_inputs.REFUSED: {bad}")
    for rel, want in d["files"].items():
        p = Path(repo) / rel
        if not p.is_file():
            raise C.Refused(f"{rel} is not in this checkout (merge COST commit {d['cost_commit'][:8]} through "
                            "origin/ccr-3d8c8d4d-gy5b9o first)")
        got = C.sha256_file(p)
        if got != want:
            raise C.PinError(f"{rel} sha256 {got} differs from DEPS.json cost pin; re-pin after a red team")
    return d


def _import(path: Path):
    path = Path(path).resolve()
    mod = sys.modules.get(MODULE)
    if mod is not None and Path(mod.__file__).resolve() == path:
        return mod
    spec = importlib.util.spec_from_file_location(MODULE, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[MODULE] = mod
    spec.loader.exec_module(mod)
    return mod


def release_rows(cal_df) -> dict:
    """Release times for cost.py: every scheduled, not cancelled forward-calendar row with a time (FOMC, ECB and any
    release-only row), the types present, and the types with a row still without a time (red team 4, item 1: its
    release window cannot be charged)."""
    import pandas as pd
    d = cal_df[(cal_df["status"].astype(str) != "cancelled") & (pd.to_numeric(cal_df["scheduled"]) == 1)]
    blank = d["utc"].astype(str).str.strip() == ""
    timed = d[~blank]
    return {"ts": sorted(int(pd.Timestamp(u).timestamp()) for u in timed["utc"]), "types": sorted(set(timed["type"])),
            "untimed_types": sorted(set(d[blank]["type"]))}


def load(repo: Path, cal_df, rates: tuple | None = None, deps: Path | None = None) -> "CostV3":
    """COST's model from this checkout (pins checked), with the forward calendar's release list."""
    d = check(repo, deps)
    code = next(r for r in d["files"] if r.endswith(".py"))
    model_rel = next(r for r in d["files"] if r.endswith(".json"))
    mod = _import(Path(repo) / code)
    model = json.loads((Path(repo) / model_rel).read_text())
    if model.get("version") != d["model_version"]:
        import fwd_core as C
        raise C.PinError(f"COST_MODEL.json version {model.get('version')} != pinned {d['model_version']}")
    meta = dict(getattr(cal_df, "attrs", {}).get("meta") or {})
    cv = CostV3(mod, model, d["files"][model_rel], release_rows(cal_df), meta, rates)
    cv.commit = d["cost_commit"]
    return cv


class CostV3:
    """cost.py's CostModel on EUR/USD with the forward release list. reasons: why lines priced with it are still
    below the pass case (empty only when the release list is complete for this model and the rates are known)."""

    def __init__(self, mod, model: dict, model_sha256: str, release: dict, meta: dict, rates: tuple | None = None):
        self.mod, self.model, self.model_sha256, self.rates = mod, model, model_sha256, rates
        self.commit = None
        self.release_ts = list(release["ts"])
        self.cm = mod.CostModel(model, {COST_PAIR: self.release_ts}) if self.release_ts else None
        self.reasons = []
        if self.cm is None:
            self.reasons.append("cost.py: the forward calendar holds no release row")
        missing = sorted(set(model.get("events_types_measured", [])) - set(release["types"]))
        if missing or meta.get("release_list_complete_for") != model_sha256:
            self.reasons.append(
                "release list: COST v3's EUR/USD list has every tier-1 US and euro-area release (EVENTS-04); the forward "
                f"calendar lacks {missing or 'no measured type'} and is not marked complete for COST_MODEL sha256 "
                f"{model_sha256[:12]} (meta release_list_complete_for), so release-window floors and slippage near "
                "unlisted releases are not charged")
        untimed = sorted(set(model.get("events_types_measured", [])) & set(release.get("untimed_types", [])))
        if untimed:
            self.reasons.append(f"release list: rows of {untimed} have no time yet, so their release-window floors and "
                                "slippage are not charged")
        if rates is None:
            self.reasons.append("financing: COST's financing_rows needs DATA's as-of policy-rate series (data/macro "
                                "policy_rates_daily.csv), which has no released loader or pin yet; Round 45's 1 pip a "
                                "night (3 on a Wednesday close) is charged on every calendar 17:00 New York close held")

    def vol(self, ts, mid_close):
        """cost.vol_from_mid_close on the bars given (the forward bars)."""
        return self.mod.vol_from_mid_close(ts, mid_close, PIP)

    def net_ex_fin(self, rec: dict) -> float:
        if self.cm is None:
            raise ValueError("no release list")
        v = (lambda x: None if x is None else float(x))
        return float(self.cm.net_pips(
            COST_PAIR, side=int(rec["side"]), entry_price=rec["entry_price"], exit_price=rec["exit_price"],
            entry_spread=rec["entry_spread"], exit_spread=rec["exit_spread"], entry_ts=int(rec["entry_ts"]),
            exit_ts=int(rec["exit_ts"]), entry_kind=rec["entry_kind"], exit_kind=rec["exit_kind"], freezing=True,
            decision_ts=int(rec["decision_ts"]), vol_entry=v(rec["vol_entry"]), vol_exit=v(rec["vol_exit"]),
            bar_sec=60))

    def nights(self, rec: dict) -> int:
        """COST's own count of nights charged (financing_nights): must equal the line's calendar nights."""
        return int(self.mod.financing_nights(int(rec["entry_ts"]), int(rec["exit_ts"])))

    def fin_v3(self, rec: dict) -> float | None:
        """COST's financing_rows summed (pips per unit, positive = paid), at the entry mid, at the pass-case markup
        (COST_MODEL financing.markup_pct_year); None without rates."""
        return self.fin_v3_at(rec, None)

    def fin_v3_at(self, rec: dict, markup: float | None) -> float | None:
        """The same with markup_pct_year=markup (None: the pass case). freezing=True, so COST refuses a markup below
        the pass case: 2.0 (the sensitivity row) is allowed, 1.0 is not. None without rates."""
        if self.rates is None:
            return None
        # rates = (rate, rate_range) as COST's policy_rate_lookup returns; at the freeze COST charges the end of each
        # rate's range that hurts (rate_range is required with freezing=True since COST v3.1)
        rate, rate_range = self.rates
        kw = {} if markup is None else {"markup_pct_year": float(markup)}
        rows = self.mod.financing_rows(self.model, COST_PAIR, int(rec["side"]), int(rec["entry_ts"]),
                                       int(rec["exit_ts"]), abs(float(rec["mid_entry"])), rate, freezing=True,
                                       rate_range=rate_range, **kw)
        return float(sum(r[2] for r in rows))


def r45_fin_pips(nights: dict) -> float:
    return FIN_R45_PIPS * float(sum(nights.values()))


def price_side(cost: CostV3 | None, rec: dict) -> tuple:
    """(nets in pips, reasons) of one side. rec holds move_mid_pips and ba_slip_pips (the frozen convention's inputs)
    and cost.py's inputs."""
    fin45 = r45_fin_pips(rec["fin_nights"])
    move, ba = float(rec["move_mid_pips"]), float(rec["ba_slip_pips"])
    out = {"floor_2p0": min(move - FLOOR_PASS, ba) - fin45, "floor_1p6": min(move - FLOOR_INFO, ba) - fin45,
           "financing_r45_pips": fin45, "cost_v3_ex_financing": None, "financing_v3_pips": None,
           "financing_v3_2p0_pips": None, "fin2p0_markup_pct_year": FIN_SENS_MARKUP}
    reasons = []
    if cost is None:
        reasons.append("COST v3 model not loaded")
    else:
        reasons += cost.reasons
        if cost.nights(rec) != sum(rec["fin_nights"].values()):
            raise ValueError("the line's financing nights differ from COST's financing_nights")
        try:
            out["cost_v3_ex_financing"] = cost.net_ex_fin(rec)
        except Exception as e:                                   # cost.py refuses (coverage, closed market, ...)
            reasons.append(f"cost.py refused: {type(e).__name__}: {e}")
        try:
            out["financing_v3_pips"] = cost.fin_v3(rec)
        except (AttributeError, KeyError, TypeError, ValueError) as e:
            reasons.append(f"financing v3 refused: {type(e).__name__}: {e}")
        try:
            out["financing_v3_2p0_pips"] = cost.fin_v3_at(rec, FIN_SENS_MARKUP)
        except (AttributeError, KeyError, TypeError, ValueError) as e:
            reasons.append(f"financing v3 at {FIN_SENS_MARKUP}% refused: {type(e).__name__}: {e}")
        if (out["financing_v3_pips"] is None) != (out["financing_v3_2p0_pips"] is None):
            reasons.append("financing v3: priced at one markup but not the other")
    v3 = out["cost_v3_ex_financing"]
    fin = out["financing_v3_pips"] if out["financing_v3_pips"] is not None else fin45
    both = out["financing_v3_pips"] is not None and out["financing_v3_2p0_pips"] is not None
    fin2 = out["financing_v3_2p0_pips"] if both else fin          # the pass case's own fallback: the two are equal
    out["pass_case"] = out["floor_2p0"] if v3 is None else min(out["floor_2p0"], v3 - fin)
    out["pass_case_fin2p0"] = out["floor_2p0"] if v3 is None else min(out["floor_2p0"], v3 - fin2)
    if not all(math.isfinite(x) for x in (out["floor_2p0"], out["floor_1p6"], out["pass_case"], out["pass_case_fin2p0"])):
        raise ValueError("a net is not finite")
    if out["pass_case_fin2p0"] > out["pass_case"] + 1e-12:
        raise ValueError("the net at 2.0% financing is above the pass case: more financing never pays more")
    return out, reasons
