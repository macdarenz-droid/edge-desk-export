"""STATS forward paper log: git, the gate, the two OANDA locks, the request budget, the locked log's branch, and
DATA's pinned downloader and loaders.

- The runner runs from a dedicated linked worktree of dept/stats whose HEAD equals origin/dept/stats and which is
  clean (`worktree_check`); it pushes only its own commits there (HEAD:dept/stats), and never a path under
  STATS/locked/ or a FORWARD_LOG (`Git.commit_push`).
- The gate refuses unless the forward/ tree is committed, equal to origin/dept/stats, and its sha256 is approved in
  forward/RED_TEAM.md, and the DATA and COST commits pinned in DEPS.json are on the coordinator branch.
- The locked log lives only in its own worktree of dept/stats-locked, an orphan branch that is never merged
  (`LockedLog`); it is created from an empty root on the first run.
- DATA's research/common and research/data/oanda_download.py are imported from this checkout (repo root on sys.path).
  research.common itself is imported first, at module import (its runtime audit hook must be active before anything
  runs: research/common/tests/test_core_guard.py, import order); its loaders and the downloader are used only after
  every file matches DEPS.json. Prices are read only through research.common.loaders.load_m1 with the
  'forward_inputs' override, so the era guard and ACCESS_LOG.jsonl cover every read; fwd_register.py holds the data
  root and the registry entry. Nothing here computes an outcome.

The OANDA token (OANDA_API_TOKEN) is read only by DATA's Fetcher, which sends it to the candles endpoint; this file
never reads, prints, logs or writes it. Candles only: no account or order call.
"""
from __future__ import annotations

import fcntl
import hashlib
import importlib
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

sys.path.insert(0, str(Path(__file__).resolve().parents[4]))      # this checkout's root (DATA's research/common)
import research.common  # noqa: E402,F401  (first: DATA's runtime audit hook, research/common/audit.py)
import fwd_core as C  # noqa: E402
import fwd_cost  # noqa: E402
import fwd_register as REG  # noqa: E402

DEPS = C.DEPS
BRANCH = "dept/stats"
DATA_BRANCH = "dept/data"
LOCKED_BRANCH = "dept/stats-locked"
COORD_BRANCH = "ccr-3d8c8d4d-gy5b9o"
DATA_STATUS = "research/departments/DATA/STATUS.json"
STATS_STATUS_REL = "research/departments/STATS/STATUS.json"
ACCESS_LOG_REL = "research/departments/STATS/ACCESS_LOG.jsonl"
FWD_REL = "research/departments/STATS/forward"
STATS_STATUS = C.STATS / "STATUS.json"
ACCESS_LOG = C.STATS / "ACCESS_LOG.jsonl"
# STATS's FETCH_LOG (docs/EDGE_HUNT.md section 5): DATA's Fetcher writes a 403, 407 or 429 from OANDA here and refuses
# every later request to that host for 24 hours; the run's commits carry it to dept/stats (run_forward.py).
FETCH_LOG_REL = "research/departments/STATS/FETCH_LOG.jsonl"
FETCH_LOG = C.STATS / "FETCH_LOG.jsonl"
FETCH_LOG_NAME = "FETCH_LOG.jsonl"        # also kept in the data dir: a block line survives a dropped local commit
DEPT_FETCH_LOG = re.compile(r"^research/departments/[^/]+/FETCH_LOG\.jsonl$")
# STATS's freeze and audit gate, run by fwd_cost.check: hashed with the forward tree (red team 3, item 8)
AUDIT_INPUTS_REL = "research/departments/STATS/audit_inputs.py"
# STATS's rulings on forward-calendar changes (red team 3, items 1 and 5), read only as pushed on origin/dept/stats
RULINGS_REL = "research/departments/STATS/FORWARD_RULINGS.jsonl"
CLOSING_KINDS = ("forward_run_done", "forward_stale_lock_cleared")    # ACCESS_LOG lines of a runner's closing commit
CLOSING_TRIES = 3                          # a rejected closing push is rebuilt on origin and pushed again, this often
CLOSING_WAIT_S = 5.0                       # between those tries
RECOVER = "run_forward.py --push-closing"  # the recovery command for a closing commit that origin lacks
# a run killed inside its start step (red team 7, item 1): its start line and lock never left the worktree
READ_NOTHING = ("this run read nothing: restore ACCESS_LOG.jsonl and STATUS.json (git checkout -- "
                "research/departments/STATS/ACCESS_LOG.jsonl research/departments/STATS/STATUS.json)")
# Git.started_here reads the runner worktree's HEAD reflog (red team 8, N-a): the gate and --check need one
REFLOG_NEEDED = "the runner needs a HEAD reflog for its closing push: git config core.logAllRefUpdates true"
READ_NOTHING_STAGED = ("this run read nothing: restore ACCESS_LOG.jsonl and STATUS.json from HEAD, since a change is "
                       "staged (git checkout HEAD -- research/departments/STATS/ACCESS_LOG.jsonl "
                       "research/departments/STATS/STATUS.json)")
# keys of DATA's loaders read line (research/common/access.py log_access with the loaders' _gate fields), and of DATA's
# FETCH_LOG block line (research/data/oanda_download.py record_block): a killed run's leftovers must be these (item F5)
LOADER_KEYS = frozenset({"utc", "dept", "study", "era", "first_ts", "last_ts", "code_sha256", "frozen_sha256", "run_id",
                         "common_sha256", "instrument", "granularity", "datasets", "override", "ledger_id", "fetch_ok",
                         "synthetic", "main_path", "origin_commit", "decision_ts"})
FETCH_KEYS = frozenset({"utc", "source", "url", "status", "bytes", "via", "note"})
# keys of DATA's macro.load read line (research/common/loaders.py _log_macro: kind "macro"; since DATA release 6 also
# "linked", true on a linked look's read, passed through **extra), plus the run's ledger id under override
# forward_inputs, which a run's own macro line must carry (red team 7, N6; red team 8, F1). The runner never calls
# macro.load today; DATA's line carries neither of those two keys yet, so such a line is still refused until a re-pin
# adds them.
MACRO_KEYS = frozenset({"utc", "dept", "study", "era", "first_ts", "last_ts", "code_sha256", "frozen_sha256", "run_id",
                        "kind", "series", "sha256", "asof_bound", "rows", "rows_dropped", "before_run",
                        "common_sha256", "linked", "override", "ledger_id"})

DATA_SOURCE_PREFIX = "research/departments/DATA/"   # a sourced calendar pin's source.path (red team 4, item 7)
LOCKED_WT_ENV = "STATS_LOCKED_WT"
LOCKED_LOG_REL = "research/departments/STATS/locked/" + C.LOG_NAME     # on dept/stats-locked only (as locked_runner)
FORBIDDEN_ON_STATS = re.compile(r"(^|/)research/departments/STATS/locked(/|$)|FORWARD_LOG")
CAL_PIN_RELS = (f"{FWD_REL}/calendars/FORWARD_EVENTS.csv", f"{FWD_REL}/calendars/FORWARD_EVENTS.json")
STALE_AFTER_S = 6 * 3600
MAX_FILE_LEAD_S = 60 * 86400              # a local candle file starting this long before the needed start is rotated
MAX_REQUESTS_PER_DAY = 30
MIN_GAP_S = 5.0
CANDLES_URL = re.compile(r"^https://api-fxpractice\.oanda\.com/v3/instruments/EUR_USD/candles$")
APPROVED = re.compile(r"^approved_tree_sha256:[ \t]*([0-9a-f]{64})[ \t]*$", re.M)
COMMON = C.COMMON
DOWNLOADER = "research/data/oanda_download.py"
ACCESS_KEYS = {"utc", "dept", "study", "ledger_id", "override", "era", "kind", "status", "first_ts", "last_ts",
               "outcomes_from_ts", "picks", "code_sha256", "tree_sha256", "budget", "requests", "requests_by_utc_day",
               "data_end_ts", "pick_errors", "waiting_on_events", "locked_commit", "cleared_ledger_id",
               "job_started_utc", "reason", "calendar_sha256", "locked_leftovers_discarded", "calendar_errors",
               "rebuild_note"}
Refused = C.Refused                     # a rule of the run was not met; nothing further is read


class BudgetExceeded(Refused):
    """The day's OANDA requests are used up."""


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def locked_dir() -> Path:
    """The stats_locked folder under the loaders' data root: STATS's scratch for locked rows, never in the repo."""
    return REG.locked_dir(loaders())


# ------------------------------------------------------------------ git

class Git:
    def __init__(self, repo: Path = C.REPO):
        self.repo = Path(repo)

    def _run(self, *a):
        return subprocess.run([*C.GIT, "-C", str(self.repo), *a], capture_output=True, text=True, env=C.git_env())

    def fetch(self, branch: str) -> bool:
        return self._run("fetch", "-q", "origin", f"+refs/heads/{branch}:refs/remotes/origin/{branch}").returncode == 0

    def remote_has(self, branch: str) -> bool | None:
        """True or False from origin; None when origin cannot be read."""
        r = self._run("ls-remote", "--heads", "origin", f"refs/heads/{branch}")
        return None if r.returncode else bool(r.stdout.strip())

    def show(self, ref: str, path: str) -> str | None:
        r = self._run("show", f"{ref}:{path}")
        return r.stdout if r.returncode == 0 else None

    def show_bytes(self, ref: str, path: str) -> bytes | None:
        r = subprocess.run([*C.GIT, "-C", str(self.repo), "show", f"{ref}:{path}"], capture_output=True,
                           env=C.git_env())
        return r.stdout if r.returncode == 0 else None

    def origin_urls(self) -> list:
        """Every fetch and push URL of origin, as git uses them (insteadOf and pushInsteadOf applied, GIT_CONFIG_*
        included); [] when git cannot tell."""
        out = []
        for extra in ((), ("--push",)):
            r = self._run("remote", "get-url", "--all", *extra, "origin")
            if r.returncode:
                return []
            out += [u.strip() for u in r.stdout.splitlines() if u.strip()]
        return out

    def grafts(self) -> list:
        """Every info/grafts file git would honour here (in the git dir and the common git dir; red team 4, item 4:
        git 2.43 still reads it, and neither --no-replace-objects nor GIT_NO_REPLACE_OBJECTS turns it off);
        ['<git rev-parse failed>'] when git cannot tell."""
        out = set()
        for flag in ("--absolute-git-dir", "--git-common-dir"):
            r = self._run("rev-parse", flag)
            if r.returncode or not r.stdout.strip():
                return ["<git rev-parse failed>"]
            d = Path(r.stdout.strip())
            f = (d if d.is_absolute() else self.repo / d) / "info" / "grafts"
            if f.exists() or f.is_symlink():
                out.add(str(f.resolve() if f.exists() else f))
        return sorted(out)

    def ssl_verify(self, url: str) -> str:
        """The http.sslVerify value git uses for this URL (git config --type=bool --get-urlmatch, with C.GIT's
        http.sslVerify=true): 'true' or 'false'; '<unknown>' when git cannot tell."""
        r = self._run("config", "--type=bool", "--get-urlmatch", "http.sslVerify", url)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else "<unknown>"

    def replace_refs(self) -> list:
        """Every ref under refs/replace/ (git for-each-ref); ['<git for-each-ref failed>'] when git cannot tell."""
        r = self._run("for-each-ref", "--format=%(refname)", "refs/replace/")
        return ["<git for-each-ref failed>"] if r.returncode else [x for x in r.stdout.splitlines() if x]

    def remote_heads(self, prefix: str) -> list | None:
        """Branch names on origin starting with prefix (git ls-remote --heads); None when origin cannot be read."""
        r = self._run("ls-remote", "--heads", "origin")
        if r.returncode:
            return None
        names = [ln.split("\t", 1)[1][len("refs/heads/"):] for ln in r.stdout.splitlines() if "\trefs/heads/" in ln]
        return sorted(n for n in names if n.startswith(prefix))

    def ls_tree(self, ref: str, path: str) -> list | None:
        """Every file path under path at ref (git ls-tree -r --name-only); None when git cannot read ref."""
        r = self._run("ls-tree", "-r", "--name-only", ref, "--", path)
        return None if r.returncode else [x for x in r.stdout.splitlines() if x]

    def rev(self, ref: str) -> str | None:
        r = self._run("rev-parse", "--verify", "-q", f"{ref}^{{commit}}")
        return r.stdout.strip() or None if r.returncode == 0 else None

    def head(self) -> str | None:
        return self.rev("HEAD")

    def branch(self) -> str:
        return self._run("rev-parse", "--abbrev-ref", "HEAD").stdout.strip()

    def toplevel(self) -> Path:
        return Path(self._run("rev-parse", "--show-toplevel").stdout.strip()).resolve()

    def common_root(self) -> Path:
        """The main checkout of this repository (the parent of the common git dir)."""
        c = Path(self._run("rev-parse", "--git-common-dir").stdout.strip())
        return (c if c.is_absolute() else self.repo / c).resolve().parent

    def is_linked_worktree(self) -> bool:
        g = self._run("rev-parse", "--absolute-git-dir").stdout.strip()
        c = Path(self._run("rev-parse", "--git-common-dir").stdout.strip())
        c = c if c.is_absolute() else self.repo / c
        return bool(g) and Path(g).resolve() != c.resolve()

    def status(self, paths=()) -> str:
        return self._run("status", "--porcelain", "--untracked-files=all", "--", *map(str, paths)).stdout.strip()

    def dirty(self, paths) -> bool:
        return bool(self.status(paths))

    def unclean(self, paths=()) -> list:
        """Every uncommitted, untracked or ignored entry, except compiled files inside __pycache__/ (a stray
        numpy.pyc or .pth next to the code could shadow a library under an approved tree hash)."""
        out = self._run("status", "--porcelain", "--ignored", "--untracked-files=all", "--", *map(str, paths))
        if out.returncode:
            return ["<git status failed>"]
        bad = []
        for line in out.stdout.splitlines():
            q = Path(line[3:].strip('"'))
            if line.startswith("!! ") and q.parent.name == "__pycache__" and q.suffix == ".pyc":
                continue
            bad.append(line)
        return bad

    def is_ancestor(self, a: str, b: str) -> bool:
        return self._run("merge-base", "--is-ancestor", a, b).returncode == 0

    def shares_history(self, a: str, b: str) -> bool:
        return self._run("merge-base", a, b).returncode == 0

    def ls_files(self, path: str) -> list:
        return [f for f in self._run("ls-files", "-z", "--", path).stdout.split("\0") if f]

    def diff_names(self, ref: str, path: str) -> list:
        """Tracked files under path that differ between the working tree and ref."""
        r = self._run("diff", "--name-only", ref, "--", path)
        return r.stdout.split() if r.returncode == 0 else ["<git diff failed>"]

    def staged(self) -> list:
        return self._run("diff", "--cached", "--name-only").stdout.split()

    def commit_push(self, paths, msg: str, rebuild: bool = False, now: float | None = None) -> bool:
        """Commit only `paths` and push HEAD to dept/stats (this worktree's commits only). Refused for any path under
        research/departments/STATS/locked/ or named FORWARD_LOG, given or already staged: locked numbers live only on
        dept/stats-locked. False if the push fails (the commit stays local). rebuild (the closing and clearing
        commits): a rejected push is retried by `rebuild_push` (red team 5, item 1), with the clock `now` (the
        clearing's; check_closes)."""
        rels = []
        for p in paths:
            try:
                rels.append(Path(p).resolve().relative_to(self.repo.resolve()).as_posix())
            except ValueError:
                raise Refused(f"{p} is outside the runner's worktree")
        bad = [r for r in rels if FORBIDDEN_ON_STATS.search(r)]
        if bad:
            raise Refused(f"refused to stage {bad} on {BRANCH}: locked numbers live only on {LOCKED_BRANCH}")
        rels = [r for r in rels if (self.repo / r).exists()]
        self._run("add", "--", *rels)
        bad = [s for s in self.staged() if FORBIDDEN_ON_STATS.search(s)]
        if bad:
            self._run("reset", "-q", "--", *bad)
            raise Refused(f"refused: {bad} staged on {BRANCH}; locked numbers live only on {LOCKED_BRANCH}")
        r = self._run("commit", "-q", "-m", msg, "--", *rels)
        if r.returncode and "nothing" not in (r.stdout + r.stderr):
            return False
        if self._run("push", "-q", "origin", f"HEAD:refs/heads/{BRANCH}").returncode == 0:
            return True
        return rebuild and self.rebuild_push(self.head(), rels, msg, now=now)

    def rebuild_push(self, old: str, rels, msg: str, tries: int | None = None, now: float | None = None) -> bool:
        """Push commit `old` (the runner's closing or clearing commit) to dept/stats after a rejected push: up to
        CLOSING_TRIES times, CLOSING_WAIT_S apart, fetch origin/dept/stats and check `old` against it (`_parted`):
        it may change no path besides `rels` since it parted from origin (also on a fast-forward; red team 6, F4),
        and it may only release a lock (red team 7, N1). When every line `old` adds is already on origin and origin's
        lock is not this run's (`landed`: a try that landed, though reported failed), move the worktree there (git
        reset --keep) and stop. Else the runs it closes must be open on origin and tied to it (check_closes; red team
        7, N2). If origin is behind `old` and its lock is free or this run's, push `old`;
        else rebuild it on origin (`_rebuilt`; red team 6, F1 and F3): STATUS.json is origin's, with oanda_job
        released only when origin's is null, missing or this run's (else origin's lock is kept and only the lines are
        appended, with a warning); ACCESS_LOG.jsonl and FETCH_LOG.jsonl are origin's bytes plus the lines `old` added
        since the merge base that origin does not already hold. Then move the worktree to the pushed commit (git reset
        --keep). True when origin holds the commit; False after the last try (HEAD stays `old`, which worktree_check
        names with RECOVER)."""
        for n in range(tries or CLOSING_TRIES):
            if n:
                time.sleep(CLOSING_WAIT_S)
            if not self.fetch(BRANCH):
                continue
            base = self.rev(f"origin/{BRANCH}")
            if not base:
                continue
            mb = self._run("merge-base", old, f"origin/{BRANCH}").stdout.strip()
            run_ids = self._parted(old, mb, rels)
            if landed(self, old, base):                 # a try that landed (red team 7, N5: origin's lock not ours)
                if self._run("reset", "-q", "--keep", base).returncode:
                    print(f"warning: the closing commit is on origin as {base[:8]}; move the runner's worktree to it: "
                          f"git reset --keep {base}", file=sys.stderr)
                return True
            check_closes(self, old, mb, base, run_ids, now)
            if mb == base and lock_owned(self.show_bytes(base, STATS_STATUS_REL), run_ids):
                if self._run("push", "-q", "origin", f"{old}:refs/heads/{BRANCH}").returncode == 0:
                    return True
                continue
            new = self._rebuilt(old, base, mb, rels, msg, run_ids)
            if new and self._run("push", "-q", "origin", f"{new}:refs/heads/{BRANCH}").returncode == 0:
                if self._run("reset", "-q", "--keep", new).returncode:
                    print(f"warning: the closing commit was pushed as {new[:8]}; move the runner's worktree to it: "
                          f"git reset --keep {new}", file=sys.stderr)
                return True
        return False

    def _parted(self, old: str, mb: str, rels) -> set:
        """Refused unless `old`, since the merge base `mb`, changes only `rels` (git diff --no-renames: a rename names
        both paths), appends to ACCESS_LOG.jsonl and FETCH_LOG.jsonl only (added_bytes), and changes STATUS.json in
        oanda_job alone, to null (release_only) (red team 7, N1); returns the run ids its ACCESS_LOG lines close
        (closing_ids)."""
        changed = self._run("diff", "--name-only", "--no-renames", mb, old).stdout.split() if mb else \
            ["<no merge base>"]
        extra = sorted(set(changed) - set(rels))
        if extra:
            raise Refused(f"the closing commit {old[:8]} changes {extra[:5]} besides {sorted(rels)}; it is not pushed "
                          "or rebuilt: sort it by hand")
        ours = self.show_bytes(old, STATS_STATUS_REL)
        if ours is not None and job_of(ours) is not None:
            raise Refused(f"the closing commit {old[:8]} sets STATS's oanda_job; a closing or clearing commit only "
                          "releases it: sort it by hand")
        release_only(self.show_bytes(mb, STATS_STATUS_REL), ours, old[:8])
        added_bytes(self.show_bytes(mb, FETCH_LOG_REL) or b"", self.show_bytes(old, FETCH_LOG_REL) or b"",
                    FETCH_LOG_REL)
        added = added_bytes(self.show_bytes(mb, ACCESS_LOG_REL) or b"", self.show_bytes(old, ACCESS_LOG_REL) or b"",
                            ACCESS_LOG_REL)
        return closing_ids(added)

    def _with_index(self, index: Path, *a, input=None):
        env = {**C.git_env(), "GIT_INDEX_FILE": str(index)}       # a private index: the worktree is never touched
        return subprocess.run([*C.GIT, "-C", str(self.repo), *a], capture_output=True, input=input, env=env)

    def _rebuilt(self, old: str, base: str, mb: str, rels, msg: str, run_ids: set) -> str | None:
        """A commit on `base` whose `rels` are merged from `old` (rebuild_push), built in a private index."""
        with tempfile.TemporaryDirectory(prefix="stats_closing_") as tmp:
            idx = Path(tmp) / "index"
            if self._with_index(idx, "read-tree", base).returncode:
                return None
            for rel in rels:
                ours = self.show_bytes(old, rel)
                if ours is None:
                    continue
                theirs = self.show_bytes(base, rel)
                if rel == STATS_STATUS_REL:
                    merged = ours if theirs is None else merge_status(theirs, ours, run_ids)
                else:
                    merged = merge_lines(theirs or b"", ours, self.show_bytes(mb, rel) or b"", rel)
                h = self._with_index(idx, "hash-object", "-w", "--stdin", input=merged)
                blob = h.stdout.decode().strip()
                if h.returncode or self._with_index(idx, "update-index", "--add", "--cacheinfo",
                                                    f"100644,{blob},{rel}").returncode:
                    return None
            tree = self._with_index(idx, "write-tree")
            if tree.returncode:
                return None
            c = self._run("commit-tree", tree.stdout.decode().strip(), "-p", base, "-m", msg)
            return c.stdout.strip() if c.returncode == 0 else None

    def started_here(self, lid: str, base: str) -> bool:
        """True when run `lid`'s forward_run_start line reached origin (`base`) in a commit made in this worktree: a
        "commit:" entry of this worktree's HEAD reflog whose commit appends that line to ACCESS_LOG.jsonl and is on
        `base` (red team 7, N2). A hand-made closing line for a run started elsewhere has no such entry."""
        r = self._run("log", "-g", "--format=%H %gs", "HEAD")
        if r.returncode:
            return False
        for line in r.stdout.splitlines():
            sha, _, subject = line.partition(" ")
            if not subject.startswith("commit: "):
                continue
            parent = self.rev(f"{sha}^")
            try:
                add = added_bytes(self.show_bytes(parent, ACCESS_LOG_REL) or b"" if parent else b"",
                                  self.show_bytes(sha, ACCESS_LOG_REL) or b"", ACCESS_LOG_REL)
            except Refused:
                continue
            if any(x.get("kind") == "forward_run_start" and x.get("ledger_id") == lid for x in rows_of(add)) and \
                    self.is_ancestor(sha, base):
                return True
        return False

    def head_reflog(self) -> str:
        """'' when this worktree's HEAD has a reflog and core.logAllRefUpdates resolves to true ("always" included;
        unset is git's default, true outside a bare repository); else what is wrong (red team 8, N-a)."""
        r = self._run("config", "--get", "core.logAllRefUpdates")
        val = r.stdout.strip()
        if r.returncode == 1:
            on = self._run("rev-parse", "--is-bare-repository").stdout.strip() == "false"
        elif r.returncode == 0 and val.lower() == "always":
            on = True
        elif r.returncode == 0:
            on = self._run("config", "--type=bool", "--get", "core.logAllRefUpdates").stdout.strip() == "true"
        else:
            on, val = False, "unreadable"
        if not on:
            return f"core.logAllRefUpdates resolves to {val or 'false'}"
        if self._run("reflog", "exists", "HEAD").returncode:
            return "this worktree's HEAD has no reflog"
        return ""

    def push_dry_run(self) -> str:
        """git push --dry-run of HEAD to dept/stats: '' when origin would take a push, else git's message."""
        r = self._run("push", "--dry-run", "-q", "origin", f"HEAD:refs/heads/{BRANCH}")
        return "" if r.returncode == 0 else (r.stderr or r.stdout).strip()[:300] or "push --dry-run failed"


def added_bytes(base: bytes, ours: bytes, rel: str = "a log") -> bytes:
    """The bytes `ours` appended to `base` (red team 6, F3 and F5): `ours` must start with `base`, which ends in a
    newline (or is empty), and the addition must end in one. Refused otherwise (a changed line is never an append)."""
    if (base and not base.endswith(b"\n")) or not ours.startswith(base):
        raise Refused(f"{rel}: the commit changes committed lines (not an append); it is not rebuilt")
    add = ours[len(base):]
    if add and not add.endswith(b"\n"):
        raise Refused(f"{rel}: the commit's last line has no newline; it is not rebuilt")
    return add


def merge_lines(theirs: bytes, ours: bytes, base: bytes = b"", rel: str = "a log") -> bytes:
    """origin's bytes as they are, then the lines `ours` added since the merge base (`base`; added_bytes), split on
    b"\n" only, less those origin already gained since the merge base (a try that landed): no line of origin is
    changed, comes back or doubles, and none of ours is dropped (red team 6, F3)."""
    from collections import Counter
    add = added_bytes(base, ours, rel).split(b"\n")[:-1]
    if not add:
        return theirs
    have = Counter(theirs.split(b"\n")) - Counter(base.split(b"\n"))
    out = []
    for line in add:
        if have[line] > 0:
            have[line] -= 1
        else:
            out.append(line + b"\n")
    head = theirs if not theirs or theirs.endswith(b"\n") else theirs + b"\n"
    return head + b"".join(out)


def job_of(status: bytes | None):
    """STATUS.json's oanda_job (None when null, missing or the file is absent); Refused when it is not JSON."""
    if status is None:
        return None
    try:
        s = json.loads(status)
    except ValueError:
        raise Refused("STATUS.json is not JSON; the closing commit is not pushed") from None
    if not isinstance(s, dict):
        raise Refused("STATUS.json is not a JSON object; the closing commit is not pushed")
    return s.get("oanda_job")


def closing_ids(added: bytes) -> set:
    """The runs a commit's added ACCESS_LOG lines close: a forward_run_done line's ledger_id, a
    forward_stale_lock_cleared line's cleared_ledger_id."""
    ids = set()
    for line in added.split(b"\n"):
        try:
            r = json.loads(line)
        except ValueError:
            continue
        if isinstance(r, dict) and r.get("kind") == "forward_run_done":
            ids.add(r.get("ledger_id"))
        if isinstance(r, dict) and r.get("kind") == "forward_stale_lock_cleared":
            ids.add(r.get("cleared_ledger_id"))
    ids.discard(None)
    return ids


def rows_of(text: bytes) -> list:
    """The JSON object lines of a log's bytes (a line that does not parse, or is not an object, is left out)."""
    out = []
    for line in text.split(b"\n"):
        try:
            r = json.loads(line)
        except ValueError:
            continue
        if isinstance(r, dict):
            out.append(r)
    return out


def release_only(base: bytes | None, ours: bytes | None, what: str) -> None:
    """Refused unless STATUS.json `ours` equals `base` (as of the merge base) apart from oanda_job (red team 7, N1):
    a closing or clearing commit changes nothing else there."""
    if ours == base:
        return
    try:
        b = None if base is None else json.loads(base)
        o = None if ours is None else json.loads(ours)
    except ValueError:
        b = o = None
    if not (isinstance(b, dict) and isinstance(o, dict)) or \
            {k: v for k, v in b.items() if k != "oanda_job"} != {k: v for k, v in o.items() if k != "oanda_job"}:
        raise Refused(f"the closing commit {what} changes STATUS.json besides oanda_job since it parted from origin; "
                      "it is not pushed or rebuilt: sort it by hand")


def check_closes(git, old: str, mb: str, base: str, run_ids: set, now: float | None = None) -> None:
    """Red team 7, N2: each run a closing or clearing commit closes (run_ids) must be open on origin (`base`): its
    forward_run_start line is there and no closing line of it yet (its forward_run_done line, or a
    forward_stale_lock_cleared line naming it). When origin's oanda_job is one of these runs' (the commit releases
    it), the commit must also be tied to that run: a forward_stale_lock_cleared line for it while its lock on origin
    is older than STALE_AFTER_S (at `now`, the clearing's clock; else this moment), or else the run's start commit was
    made in this worktree (Git.started_here). Refused otherwise: a hand-made line never frees another run's lock."""
    log = git.show_bytes(base, ACCESS_LOG_REL) or b""
    started = {r.get("ledger_id") for r in rows_of(log) if r.get("kind") == "forward_run_start"}
    closed = closing_ids(log)
    for i in sorted(run_ids):
        if i not in started:
            raise Refused(f"the closing commit {old[:8]} closes run {i}, which has no forward_run_start line on "
                          f"origin/{BRANCH}: it is not pushed or rebuilt; sort it by hand")
        if i in closed:
            raise Refused(f"run {i} already has a closing line on origin/{BRANCH}; the closing commit {old[:8]} is "
                          "not pushed or rebuilt: sort it by hand (if origin still holds that run's lock, the STATS "
                          "session releases it on dept/stats by hand)")
    job = job_of(git.show_bytes(base, STATS_STATUS_REL))
    held = job.get("ledger_id") if isinstance(job, dict) else None
    if held is None or held not in run_ids:
        return
    added = rows_of(added_bytes(git.show_bytes(mb, ACCESS_LOG_REL) or b"", git.show_bytes(old, ACCESS_LOG_REL) or b"",
                                ACCESS_LOG_REL))
    if any(r.get("kind") == "forward_stale_lock_cleared" and r.get("cleared_ledger_id") == held for r in added):
        try:
            began = datetime.strptime(job["started_utc"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        except (KeyError, TypeError, ValueError):
            raise Refused(f"origin's oanda_job of run {held} has no readable started_utc; the clearing commit "
                          f"{old[:8]} is not pushed or rebuilt: sort it by hand") from None
        age = (time.time() if now is None else now) - began.timestamp()
        if age < STALE_AFTER_S:
            raise Refused(f"the clearing commit {old[:8]} would release run {held}'s lock on origin/{BRANCH}, which "
                          f"started {age / 3600:.1f} h ago (stale only after {STALE_AFTER_S // 3600} h): it is not "
                          "pushed or rebuilt")
        return
    if not git.started_here(held, base):
        raise Refused(f"the closing commit {old[:8]} would release run {held}'s lock on origin/{BRANCH}, but that "
                      "run's start commit was not made in this worktree (its HEAD reflog): it is not pushed or "
                      "rebuilt; a closing line is pushed only from the worktree of its run")


def lock_owned(status: bytes | None, run_ids: set) -> bool:
    """True when STATS's lock in this STATUS.json is null, missing, or one of run_ids' (red team 6, F1)."""
    job = job_of(status)
    return job is None or (isinstance(job, dict) and job.get("ledger_id") in run_ids)


def status_bytes(obj: dict) -> bytes:
    """STATUS.json in its own format: indent 2, non-ASCII as is, a trailing newline (red team 6, F8). Refused when
    the text cannot be written as UTF-8 (a lone surrogate escape such as \\ud83d in origin's or the worktree's
    STATUS.json; red team 7, N4): never a traceback."""
    text = json.dumps(obj, indent=2, ensure_ascii=False) + "\n"
    try:
        return text.encode()
    except UnicodeEncodeError as e:
        bad = text[e.start:e.end].encode("unicode_escape").decode()
        raise Refused(f"STATUS.json holds text that UTF-8 cannot write (a lone surrogate escape, {bad}, near "
                      f"{text[max(0, e.start - 40):e.start].strip()!r}): the STATS session fixes that value on "
                      f"dept/stats by hand, then run again; nothing was pushed") from None


def merge_status(theirs: bytes, ours: bytes, run_ids: set = frozenset()) -> bytes:
    """origin's STATUS.json with STATS's lock released (rebuild_push): only when origin's oanda_job is null, missing
    or one of run_ids' (this commit's run; red team 6, F1). Another job's lock on origin is kept, with a warning: the
    commit's lines are still appended. Origin's bytes when nothing changes; else its own format (status_bytes)."""
    if job_of(ours) is not None:
        raise Refused("the closing commit sets STATS's oanda_job; a closing or clearing commit only releases it")
    job = job_of(theirs)
    t = json.loads(theirs)
    if "oanda_job" in t and job is None:
        return theirs
    if not lock_owned(theirs, run_ids):
        owner = job.get("ledger_id") if isinstance(job, dict) else job
        print(f"warning: origin's oanda_job belongs to {owner!r}, not to this commit's run {sorted(run_ids)}; it is "
              "kept, and only this commit's lines are appended", file=sys.stderr)
        return theirs
    t["oanda_job"] = None
    return status_bytes(t)


def origin_pattern():
    """The one allowed origin: DATA's pattern for github.com/macdarenz-droid/Forex-signal
    (research.common.loaders.GITHUB_ORIGIN, pinned in DEPS.json)."""
    return loaders().GITHUB_ORIGIN


def check_origin(git) -> list:
    """Refused unless every fetch and push URL of origin, as git resolves it (an insteadOf from GIT_CONFIG_* or a
    config file included), is the GitHub repo (red team 3, item 7), and git verifies TLS for each https one: the
    http.sslVerify git uses for that URL is true (red team 4, item 4; a URL-specific http.<url>.sslVerify=false in a
    config file would win over C.GIT's -c http.sslVerify=true). Run before any read of origin."""
    urls = git.origin_urls()
    pat = origin_pattern()
    if not urls or not all(pat.fullmatch(u) for u in urls):
        raise Refused(f"origin resolves to {urls or 'nothing'}, not github.com/macdarenz-droid/Forex-signal "
                      "(check insteadOf settings and GIT_CONFIG_* variables); nothing is read from it")
    off = [u for u in urls if u.lower().startswith(("https://", "http://")) and git.ssl_verify(u) != "true"]
    if off:
        raise Refused(f"git would not verify TLS for {off} (http.sslVerify, a URL-specific http.<url>.sslVerify "
                      "included, is not true); nothing is read from origin")
    return urls


def check_import_roots(repo: Path | None = None) -> None:
    """research.common is this checkout's (red team 3, item 8), and the checkout's root, first on sys.path, holds no
    module that could shadow a library: no *.py, *.pyc, *.so or *.pyd file and no folder with an __init__.py."""
    repo = Path(repo or C.REPO).resolve()
    rc = sys.modules.get("research.common")
    f = getattr(rc, "__file__", None)
    if not f or Path(f).resolve() != repo / C.COMMON / "__init__.py":
        raise C.PinError(f"research.common was imported from {f}, not from this checkout ({repo})")
    bad = sorted(p.name for p in repo.iterdir()
                 if (p.is_file() and p.suffix in (".py", ".pyc", ".so", ".pyd"))
                 or (p.is_dir() and (p / "__init__.py").exists()))
    if bad:
        raise Refused(f"the checkout's root holds importable modules {bad}: they would shadow libraries for the runner")


def runner_lines(lines: list) -> tuple:
    """(starts, closing, other) of unpushed ACCESS_LOG lines. closing: the closing or clearing lines (CLOSING_KINDS)
    and every line of the same run: DATA's loaders read line has no kind, override forward_inputs and the run's
    ledger id (red team 5, item 1(a)); DATA's macro.load read line has kind "macro", override forward_inputs, the
    run's ledger id and MACRO_KEYS only (red team 7, N6); a clearing commit also carries its killed run's lines
    (cleared_ledger_id, item 5). other: the kinds of anything else ('None' for a line without a kind that is not such
    a read line)."""
    ids = set()
    for r in lines:
        if r.get("kind") in CLOSING_KINDS:
            ids.add(r.get("ledger_id"))
            if r.get("kind") == "forward_stale_lock_cleared":
                ids.add(r.get("cleared_ledger_id"))
    ids.discard(None)
    starts = [str(r.get("ledger_id")) for r in lines if r.get("kind") == "forward_run_start"]
    closing, other = [], set()
    for r in lines:
        k = r.get("kind")
        if k in CLOSING_KINDS:
            closing.append(r)
        elif k is None and "kind" not in r and r.get("override") == "forward_inputs" and r.get("ledger_id") in ids:
            closing.append(r)
        elif k == "macro" and macro_line(r) and r.get("ledger_id") in ids:
            closing.append(r)
        elif k != "forward_run_start":
            other.add(str(k))
    return starts, closing, sorted(other)


def macro_line(r: dict) -> bool:
    """DATA's macro.load read line of a forward run (red team 7, N6): kind "macro", override forward_inputs, a ledger
    id, and MACRO_KEYS only."""
    return r.get("kind") == "macro" and not (set(r) - MACRO_KEYS) and r.get("override") == "forward_inputs" and \
        isinstance(r.get("ledger_id"), str)


def unpushed_lines(git, remote: str) -> list:
    """The lines of HEAD's ACCESS_LOG that origin/dept/stats's (at `remote`) lacks, parsed; a line that does not
    parse becomes {"kind": "<unreadable>"}."""
    mine = (git.show("HEAD", ACCESS_LOG_REL) or "").splitlines()
    theirs = set((git.show(remote, ACCESS_LOG_REL) or "").splitlines())
    out = []
    for line in mine:
        if not line.strip() or line in theirs:
            continue
        try:
            r = json.loads(line)
        except ValueError:
            r = None
        out.append(r if isinstance(r, dict) else {"kind": "<unreadable>"})
    return out


def worktree_check(git, allow_appended=(), allow_status: bool = False, allow_behind: bool = False) -> str:
    """The runner's checkout: a dedicated linked worktree (not the session checkout), origin the GitHub repo with TLS
    verified, no replace refs and no grafts, HEAD equal to the freshly fetched origin/dept/stats, nothing uncommitted
    or untracked. Returns HEAD. A HEAD holding commits origin lacks is refused, never dropped: "push them" when they
    are a closing commit (a failed closing push, maybe with a FETCH_LOG block line); "drop it" when they hold a
    forward_run_start line origin lacks (a failed start push: that run read nothing, so its start line and lock must
    never be published; red team 4, item 2). A HEAD behind origin is told to fast-forward (git merge --ff-only), which
    never drops a commit (red team 4, item 3). For clear_stale (red team 5 item 5; red team 6 F2 and F6):
    allow_appended, worktree paths whose uncommitted (or staged) change may be lines appended to the committed file
    (appended_lines); allow_status, STATUS.json changed in oanda_job only (status_lock_only); allow_behind, a HEAD
    behind origin (the clearing commit is then rebuilt on origin). When every line HEAD adds is already on origin (a
    rebuilt push that landed, though reported failed), the advice is git reset --keep origin/dept/stats (F7), unless
    origin still holds that run's lock (red team 7, N5). An uncommitted start line refuses (killed_start; red team 7,
    item 1)."""
    if not git.is_linked_worktree():
        raise Refused("run from a dedicated worktree of dept/stats, e.g. git worktree add --detach ../stats-fwd-wt "
                      "origin/dept/stats (never from the session checkout)")
    check_origin(git)
    rep = git.replace_refs()
    if rep:
        raise Refused(f"the repository holds replace refs {rep[:3]}: git could show replaced objects; remove them "
                      "(git replace -d) before a run")
    grafts = git.grafts()
    if grafts:
        raise Refused(f"the repository has a grafts file {grafts[:2]}: git would rewrite history (an unmerged commit "
                      "could pass as merged); remove it before a run")
    if not git.fetch(BRANCH):
        raise Refused(f"cannot fetch origin/{BRANCH}")
    head, remote = git.head(), git.rev(f"origin/{BRANCH}")
    if remote and head and head != remote and not git.is_ancestor(head, remote):
        starts, closing, other = runner_lines(unpushed_lines(git, f"origin/{BRANCH}"))
        if starts and (closing or other):
            raise Refused(f"the worktree's HEAD {str(head)[:8]} holds the start line of run(s) {starts[:3]} that "
                          f"origin/{BRANCH} lacks, and other unpushed lines: sort them by hand (git log "
                          f"origin/{BRANCH}..HEAD); never push the start line of a run that read nothing")
        if starts:
            raise Refused(f"the worktree's HEAD {str(head)[:8]} holds the start line of run(s) {starts[:3]} that "
                          f"origin/{BRANCH} lacks (a start push failed; that run read nothing): drop it, never push "
                          f"it: git reset --keep origin/{BRANCH} in the runner's worktree, then run again")
        ids = None if starts or closing or other else landed_ids(git, head, f"origin/{BRANCH}")
        if ids is not None:
            held = origin_holder(git, f"origin/{BRANCH}", ids)
            if held is not None:
                raise Refused(f"every line the worktree's HEAD {str(head)[:8]} adds is already on origin/{BRANCH}, but "
                              f"origin still holds run {held}'s lock, whose closing line is there (red team 7, N5): "
                              f"the STATS session releases it on {BRANCH} by hand (oanda_job null in STATUS.json), "
                              f"then runs this check again for the next step; do not move this worktree before that")
            raise Refused(f"every line the worktree's HEAD {str(head)[:8]} adds is already on origin/{BRANCH} (a "
                          f"rebuilt push landed although it was reported failed): move the worktree there: git reset "
                          f"--keep origin/{BRANCH}")
        gone = sorted(closing_ids(b"".join(json.dumps(r).encode() + b"\n" for r in closing)) &
                      closing_ids(git.show_bytes(f"origin/{BRANCH}", ACCESS_LOG_REL) or b""))
        if closing and not other and gone:
            raise Refused(f"the worktree's HEAD {str(head)[:8]} holds a closing commit not on origin/{BRANCH} for run(s) "
                          f"{gone[:3]}, which already have a closing line there (cleared as stale; red team 7, N2): "
                          f"the runner never pushes it. The STATS session appends the lines it adds to ACCESS_LOG.jsonl "
                          f"and FETCH_LOG.jsonl on {BRANCH} by hand (git diff origin/{BRANCH}...HEAD; never "
                          f"STATUS.json), then git reset --keep origin/{BRANCH} here")
        if closing and not other:
            raise Refused(f"the worktree's HEAD {str(head)[:8]} holds a closing commit not on origin/{BRANCH} (its "
                          f"push failed; STATS's lock and the run's forward window stay open on origin until it "
                          f"lands): push it with `python3 research/departments/STATS/forward/{RECOVER}` from this "
                          f"worktree, which rebuilds it on origin/{BRANCH} if origin has moved; never check out over it")
        raise Refused(f"the worktree's HEAD {str(head)[:8]} holds commits origin/{BRANCH} {str(remote)[:8]} lacks that "
                      f"are not a runner's closing commit (ACCESS_LOG lines {other[:3] or 'none'}): inspect them by "
                      f"hand (git log origin/{BRANCH}..HEAD); never check out over them")
    behind = bool(allow_behind and remote and head and git.is_ancestor(head, remote))
    if not remote or (head != remote and not behind):
        raise Refused(f"the worktree's HEAD {str(head)[:8]} is not origin/{BRANCH} {str(remote)[:8]}; "
                      f"git merge --ff-only origin/{BRANCH} there first")
    killed_start(git, f"origin/{BRANCH}")               # red team 7, item 1
    bad = []
    for b in git.unclean():
        xy, rel = b[:2], b[3:].strip('"')
        if (rel in allow_appended and xy in LEFTOVER_XY and appended_lines(git, rel) is not None) or \
                (allow_status and rel == STATS_STATUS_REL and xy in LEFTOVER_XY and status_lock_only(git)):
            continue
        bad.append(b)
    if bad:
        raise Refused(f"the runner's worktree has uncommitted, untracked or ignored files: {bad[:5]}")
    return head


LEFTOVER_XY = (" M", "M ", "MM", "A ", "AM", "??")     # git status codes of an unstaged, staged or new leftover


def killed_start(git, remote: str) -> None:
    """Red team 7, item 1: a run killed inside its start step leaves its forward_run_start line (and maybe its lock)
    in the worktree, never committed. When that line is the only line appended to ACCESS_LOG.jsonl, STATUS.json is
    unchanged or changed in oanda_job alone (null or that run's), nothing else is uncommitted, and origin (`remote`)
    has neither a line of that run nor its lock, that run read nothing: Refused with READ_NOTHING (restore the two
    files; READ_NOTHING_STAGED, from HEAD, when a change is staged: a run killed between its git add and its commit).
    Any other uncommitted start line is Refused ("sort it by hand"); a start line is never published."""
    left = {b[3:].strip('"'): b[:2] for b in git.unclean()}
    if ACCESS_LOG_REL not in left:
        return
    lines = appended_lines(git, ACCESS_LOG_REL)
    rows = []
    for x in lines or []:
        try:
            r = json.loads(x)
        except ValueError:
            r = None
        rows.append(r if isinstance(r, dict) else {})
    starts = [r for r in rows if r.get("kind") == "forward_run_start"]
    if not starts:
        return
    lid = starts[0].get("ledger_id")
    why = "while ACCESS_LOG.jsonl is untracked" if left[ACCESS_LOG_REL] == "??" else "with other uncommitted changes"
    ok = len(rows) == 1 and isinstance(lid, str)
    if ok:
        ok = set(left) <= {ACCESS_LOG_REL, STATS_STATUS_REL} and left[ACCESS_LOG_REL] != "??" and \
            all(xy in LEFTOVER_XY for xy in left.values())
        if ok and STATS_STATUS_REL in left:
            try:
                job = json.loads(C.checked_reader("read_bytes")(git.repo / STATS_STATUS_REL)).get("oanda_job")
            except (ValueError, AttributeError, OSError):
                job = "unreadable"
            ok = status_lock_only(git) and (job is None or (isinstance(job, dict) and job.get("ledger_id") == lid))
    if ok:
        on_origin = any(r.get("ledger_id") == lid for r in rows_of(git.show_bytes(remote, ACCESS_LOG_REL) or b""))
        try:
            job = job_of(git.show_bytes(remote, STATS_STATUS_REL))
        except Refused:
            job = "unreadable"
        held = job == "unreadable" or (isinstance(job, dict) and job.get("ledger_id") == lid)
        if not on_origin and not held:
            staged = any(xy[0] != " " for xy in left.values())
            raise Refused(f"the worktree holds the uncommitted start line of run {lid} (killed inside its start step), "
                          f"and {remote} has neither that line nor its lock: "
                          f"{READ_NOTHING_STAGED if staged else READ_NOTHING}")
        why = f"and {remote} holds {'a line of that run' if on_origin else 'its lock (or is unreadable)'}"
    raise Refused(f"the worktree holds an uncommitted forward_run_start line (run {str(lid)[:40]}) {why}: sort it by "
                  f"hand (copy the changed files out and compare with {remote}); a start line is never published")


def appended_lines(git, rel: str) -> list | None:
    """The lines appended to `rel` in the worktree since HEAD (red team 6, F5): the file's bytes start with the
    committed bytes, which end in a newline (or are empty), and the addition ends in one; split on b"\n" only. None
    when the change is anything else."""
    committed = git.show_bytes("HEAD", rel) or b""
    p = git.repo / rel
    now = C.checked_reader("read_bytes")(p) if p.exists() else b""
    try:
        add = added_bytes(committed, now, rel)
    except Refused:
        return None
    try:
        return [x.decode() for x in add.split(b"\n")[:-1]]
    except UnicodeDecodeError:
        return None


def status_lock_only(git) -> bool:
    """STATUS.json in the worktree differs from HEAD's in oanda_job alone (a run killed after it released its lock
    and before its commit; red team 6, F6)."""
    p = git.repo / STATS_STATUS_REL
    try:
        now = json.loads(C.checked_reader("read_bytes")(p)) if p.exists() else None
        old = json.loads(git.show_bytes("HEAD", STATS_STATUS_REL) or b"null")
    except ValueError:
        return False
    if not isinstance(now, dict) or not isinstance(old, dict):
        return False
    return {k: v for k, v in now.items() if k != "oanda_job"} == {k: v for k, v in old.items() if k != "oanda_job"}


def landed_ids(git, head: str, remote: str) -> set | None:
    """The run ids HEAD's lines close (closing_ids) when HEAD's commits since it parted from `remote` touch only the
    closing commit's files (git diff --no-renames), append to the logs only, change STATUS.json in oanda_job alone
    (release_only; red team 7, N1), and every log line they add is already on `remote` (a rebuilt push landed; red
    team 6, F7). None otherwise."""
    from collections import Counter
    mb = git._run("merge-base", head, remote).stdout.strip()
    rels = (ACCESS_LOG_REL, STATS_STATUS_REL, FETCH_LOG_REL)
    if not mb or set(git._run("diff", "--name-only", "--no-renames", mb, head).stdout.split()) - set(rels):
        return None
    try:
        release_only(git.show_bytes(mb, STATS_STATUS_REL), git.show_bytes(head, STATS_STATUS_REL), head[:8])
    except Refused:
        return None
    ids = set()
    for rel in (ACCESS_LOG_REL, FETCH_LOG_REL):
        try:
            add = added_bytes(git.show_bytes(mb, rel) or b"", git.show_bytes(head, rel) or b"", rel)
        except Refused:
            return None
        if Counter(add.split(b"\n")[:-1]) - Counter((git.show_bytes(remote, rel) or b"").split(b"\n")):
            return None
        if rel == ACCESS_LOG_REL:
            ids = closing_ids(add)
    return ids


def origin_holder(git, remote: str, ids: set):
    """The run of `ids` whose lock origin (`remote`) holds, or None (free, another job's, or unreadable)."""
    try:
        job = job_of(git.show_bytes(remote, STATS_STATUS_REL))
    except Refused:
        return None
    held = job.get("ledger_id") if isinstance(job, dict) else None
    return held if held is not None and held in ids else None


def landed(git, head: str, remote: str) -> bool:
    """True when every line HEAD adds is already on `remote` (landed_ids) and `remote`'s lock is free or not this
    run's (red team 7, N5): only then is git reset --keep the way forward."""
    ids = landed_ids(git, head, remote)
    return ids is not None and origin_holder(git, remote, ids) is None


def check_head_reflog(git) -> str:
    """Refused unless the runner's worktree keeps a HEAD reflog (Git.head_reflog): the run's own rebuilt closing push
    and --push-closing tie a lock release to the run's start commit through it (check_closes; red team 8, N-a)."""
    why = git.head_reflog()
    if why:
        again = "" if why.startswith("core.") else (
            "; this worktree has none yet: while it is clean and equal to origin, make it again (git worktree remove "
            "<it>, then git worktree add --detach <it> origin/dept/stats), which starts one")
        raise Refused(f"{REFLOG_NEEDED} ({why}){again}")
    return "kept (core.logAllRefUpdates on)"


def check_leftovers(left: dict, lid: str) -> None:
    """A killed run's leftover lines, before clear_stale commits them (red team 6, F5): each ACCESS_LOG line is a JSON
    object of run `lid`: a forward_run_done line that check_access_row takes, DATA's loaders read line (no kind,
    override forward_inputs, LOADER_KEYS only) or DATA's macro.load read line (macro_line; red team 7, N6); each
    FETCH_LOG line is DATA's block line (record_block: FETCH_KEYS
    only, source oanda_download, an int status). Refused otherwise."""
    for x in left.get(ACCESS_LOG_REL, []):
        try:
            r = json.loads(x)
        except ValueError:
            r = None
        ok = isinstance(r, dict) and r.get("ledger_id") == lid
        if ok and r.get("kind") == "macro":
            ok = macro_line(r)                                 # red team 7, N6
        elif ok and "kind" in r:
            try:
                ok = r["kind"] == "forward_run_done" and bool(check_access_row(r))
            except ValueError:
                ok = False
        elif ok:
            ok = not (set(r) - LOADER_KEYS) and r.get("override") == "forward_inputs"
        if not ok:
            raise Refused(f"an uncommitted ACCESS_LOG line is not run {lid}'s closing or read line: {x[:200]}; sort "
                          "it by hand")
    for x in left.get(FETCH_LOG_REL, []):
        try:
            r = json.loads(x)
        except ValueError:
            r = None
        if not (isinstance(r, dict) and not (set(r) - FETCH_KEYS) and r.get("source") == "oanda_download"
                and isinstance(r.get("status"), int)):
            raise Refused(f"an uncommitted FETCH_LOG line is not DATA's block line: {x[:200]}; sort it by hand")


def push_closing(git, now: float | None = None) -> str:
    """`run_forward.py --push-closing`: the recovery of a closing (or clearing) commit that origin lacks (red team 5,
    item 1(c)). The worktree checks of worktree_check; HEAD must hold commits origin lacks whose ACCESS_LOG lines are
    a runner's closing commit only (runner_lines), and nothing may be uncommitted. Then rebuild_push, whose checks
    (_parted, check_closes: the runs it closes are open on origin and tied to it; red team 7, N1 and N2) apply to
    every try. `now`: the clock for a clearing commit's staleness (this moment by default). Returns the commit origin
    now holds."""
    if not git.is_linked_worktree():
        raise Refused("run from the runner's worktree of dept/stats")
    check_origin(git)
    if git.replace_refs() or git.grafts():
        raise Refused("the repository holds replace refs or a grafts file; remove them first")
    if not git.fetch(BRANCH):
        raise Refused(f"cannot fetch origin/{BRANCH}")
    head, remote = git.head(), git.rev(f"origin/{BRANCH}")
    if not head or not remote or head == remote or git.is_ancestor(head, remote):
        raise Refused(f"HEAD {str(head)[:8]} holds no commit that origin/{BRANCH} lacks; nothing to push")
    starts, closing, other = runner_lines(unpushed_lines(git, f"origin/{BRANCH}"))
    if starts or other or not closing:
        raise Refused(f"HEAD's unpushed ACCESS_LOG lines are not a runner's closing commit only (start lines "
                      f"{starts[:3]}, other {other[:3]}): sort them by hand (git log origin/{BRANCH}..HEAD)")
    if git.unclean():
        raise Refused("the runner's worktree has uncommitted, untracked or ignored files")
    rels = [ACCESS_LOG_REL, STATS_STATUS_REL, FETCH_LOG_REL]
    if not git.rebuild_push(head, rels, f"STATS forward log: closing commit {head[:8]} pushed by --push-closing",
                            now=now):
        raise Refused(f"the closing commit could not be pushed after {CLOSING_TRIES} tries; try again later")
    return git.rev(f"origin/{BRANCH}")


# ------------------------------------------------------------------ the gate (RED_TEAM.md approval, pins, ancestors)

def tree_sha256(repo: Path, files) -> str:
    """sha256 of '<file sha256>  <path>' lines, sorted by path: the forward tree (RED_TEAM.md left out, since it
    holds the approvals)."""
    h = hashlib.sha256()
    for f in sorted(files):
        h.update(f"{C.sha256_file(Path(repo) / f)}  {f}\n".encode())
    return h.hexdigest()


def forward_files(git) -> list:
    """The hashed forward tree: every tracked file under forward/ except RED_TEAM.md (it holds the approvals) and the
    calendar and its pin (a calendar update needs a new pin, not a code re-approval; check_calendar_pin), plus
    STATS/audit_inputs.py, which the runner runs (fwd_cost.check; red team 3, item 8)."""
    fwd = [f for f in git.ls_files(FWD_REL) if f != f"{FWD_REL}/RED_TEAM.md" and f not in CAL_PIN_RELS]
    return fwd + [f for f in git.ls_files(AUDIT_INPUTS_REL) if f == AUDIT_INPUTS_REL]


def check_calendar_pin(git, repo: Path) -> str:
    """The calendar is outside the hashed tree but pinned: both files committed (checked with forward/), the CSV's
    sha256 equal to the pin's, and a sourced pin naming the DATA commit it came from. Returns the pin's sha256 (for
    the access line). read_calendar refuses a pin still marked needs_source.
    A sourced pin names source.data_commit (40 hex), a commit on origin/dept/data (DATA's own branch) that is merged
    on the coordinator branch, both freshly fetched, and source.path, a file under research/departments/DATA/ (red team
    4, item 7: never STATS's own copy). That file's bytes in that commit (git show <data_commit>:<path>) must have the
    CSV's sha256, so the calendar is DATA's published file, byte for byte (red team 3, item 1)."""
    pin_path = Path(repo) / CAL_PIN_RELS[1]
    pin = json.loads(pin_path.read_text())
    csv_sha = C.sha256_file(Path(repo) / CAL_PIN_RELS[0])
    if pin.get("sha256") != csv_sha:
        raise Refused("forward calendar CSV differs from its pin (FORWARD_EVENTS.json sha256)")
    if pin.get("status") == "sourced":
        src = pin.get("source") or {}
        c = str(src.get("data_commit", ""))
        if not re.fullmatch(r"[0-9a-f]{40}", c):
            raise Refused("a sourced calendar pin needs source.data_commit: DATA's official-source calendar commit "
                          f"(40 hex), on origin/{DATA_BRANCH} and merged on origin/{COORD_BRANCH}")
        rel = str(src.get("path") or "")
        parts = rel.split("/")
        if not rel:
            raise Refused("the calendar pin names no source.path (DATA's calendar file in source.data_commit)")
        if (not rel.startswith(DATA_SOURCE_PREFIX) or any(x in ("", ".", "..") for x in parts) or "\\" in rel
                or len(parts) < 4):
            raise Refused(f"source.path {rel!r} is not a file under {DATA_SOURCE_PREFIX}: the calendar must be "
                          "DATA's published file, never another department's copy")
        for b in (DATA_BRANCH, COORD_BRANCH):
            if not git.fetch(b):
                raise Refused(f"cannot fetch origin/{b} to check the calendar pin's source.data_commit")
        if not git.is_ancestor(c, f"origin/{DATA_BRANCH}"):
            raise Refused(f"the calendar pin's source.data_commit {c[:8]} is not on origin/{DATA_BRANCH}: only "
                          "DATA's own commit is accepted")
        if not git.is_ancestor(c, f"origin/{COORD_BRANCH}"):
            raise Refused(f"the calendar pin's source.data_commit {c[:8]} is not merged on origin/{COORD_BRANCH} yet; "
                          "the runner waits until the coordinator merges it")
        data = git.show_bytes(c, rel)
        if data is None or hashlib.sha256(data).hexdigest() != csv_sha:
            raise Refused(f"the calendar CSV is not the file at source.data_commit {c[:8]}:{rel or '<no source.path>'} "
                          "(its sha256 differs, or the pin names no source.path)")
    return C.sha256_file(pin_path)


def approved_trees(repo: Path) -> set:
    """Tree sha256s listed as 'approved_tree_sha256: <hex>' lines in forward/RED_TEAM.md (only a passing red team
    adds one)."""
    red = Path(repo) / FWD_REL / "RED_TEAM.md"
    return set(APPROVED.findall(red.read_text())) if red.exists() else set()


def gate(git, repo: Path | None = None, check_code: bool = True) -> dict:
    """Refused unless: the worktree check passes and the worktree keeps a HEAD reflog (check_head_reflog; red team 8,
    N-a); every file under forward/ and STATS/audit_inputs.py is committed and equal to origin/dept/stats;
    research.common is this checkout's and the root shadows no library; the forward tree's sha256 (forward_files) is
    approved in RED_TEAM.md; DEPS.json's DATA and COST commits are on
    origin/<coordinator branch>; and (check_code) DATA's and COST's pinned files and the picks match DEPS.json."""
    repo = Path(repo or C.REPO)
    head = worktree_check(git)
    check_head_reflog(git)                              # red team 8, N-a
    if (git.unclean([FWD_REL, AUDIT_INPUTS_REL]) or git.diff_names(f"origin/{BRANCH}", FWD_REL)
            or git.diff_names(f"origin/{BRANCH}", AUDIT_INPUTS_REL)):
        raise Refused(f"forward/ or {AUDIT_INPUTS_REL} differs from origin/{BRANCH} or has uncommitted, untracked or "
                      "ignored files")
    files = forward_files(git)
    if AUDIT_INPUTS_REL not in files:
        raise Refused(f"{AUDIT_INPUTS_REL} is not tracked: the runner runs it, so it is part of the hashed tree")
    check_import_roots()
    tree = tree_sha256(repo, files)
    if tree not in approved_trees(repo):
        raise Refused(f"forward tree sha256 {tree} is not approved in forward/RED_TEAM.md (a red team adds it)")
    deps = json.loads((repo / FWD_REL / "DEPS.json").read_text())
    if not git.fetch(COORD_BRANCH):
        raise Refused(f"cannot fetch origin/{COORD_BRANCH}")
    for what, c in (("DATA data_commit", deps["data_commit"]), ("COST cost_commit", deps["cost"]["cost_commit"])):
        if not git.is_ancestor(c, f"origin/{COORD_BRANCH}"):
            raise Refused(f"DEPS.json {what} {c[:8]} is not on origin/{COORD_BRANCH}; pin a merged commit")
    cal = check_calendar_pin(git, repo)
    if check_code:
        C.check_data_deps(repo / FWD_REL / "DEPS.json", repo)
        fwd_cost.check(repo, repo / FWD_REL / "DEPS.json")
        C.verify_pick_pins(repo / FWD_REL / "picks", repo / FWD_REL / "DEPS.json")
    return {"head": head, "tree_sha256": tree, "calendar_sha256": cal}


# ------------------------------------------------------------------ the locks and STATS's own files

def data_lock_free(git) -> bool:
    """True only when origin/dept/data's STATUS.json reads "oanda_job": null. Anything unreadable counts as busy."""
    if not git.fetch(DATA_BRANCH):
        return False
    t = git.show(f"origin/{DATA_BRANCH}", DATA_STATUS)
    try:
        return t is not None and json.loads(t).get("oanda_job", "missing") is None
    except ValueError:
        return False


def stats_job(git):
    """(read, oanda_job) of the PUSHED origin/dept/stats STATUS.json."""
    if not git.fetch(BRANCH):
        return False, None
    t = git.show(f"origin/{BRANCH}", STATS_STATUS_REL)
    try:
        return t is not None, json.loads(t).get("oanda_job", "missing") if t is not None else None
    except ValueError:
        return False, None


def stats_lock_free(git) -> bool:
    """True only when the pushed STATS STATUS.json reads "oanda_job": null (another STATS run, a validation or holdout
    download, or a killed run holds it otherwise)."""
    ok, job = stats_job(git)
    return ok and job is None


def pushed_access_lines(git) -> list:
    out = []
    for line in (git.show(f"origin/{BRANCH}", ACCESS_LOG_REL) or "").splitlines():
        try:
            out.append(json.loads(line))
        except ValueError:
            continue
    return out


def start_state(git, ledger_id: str) -> str | None:
    """Where run ledger_id's forward_run_start line is, read from origin only (red team 3, item 13): "pushed" when
    origin/dept/stats's ACCESS_LOG holds it, "absent" when origin was read and does not, None when origin cannot be
    read (unknown)."""
    if not git.fetch(BRANCH):
        return None
    names = git.ls_tree(f"origin/{BRANCH}", ACCESS_LOG_REL)
    if names is None:
        return None
    if ACCESS_LOG_REL not in names:
        return "absent"                                   # origin read; it holds no ACCESS_LOG at all
    text = git.show(f"origin/{BRANCH}", ACCESS_LOG_REL)
    if text is None:
        return None
    for line in text.splitlines():
        try:
            r = json.loads(line)
        except ValueError:
            continue
        if isinstance(r, dict) and r.get("kind") == "forward_run_start" and r.get("ledger_id") == ledger_id:
            return "pushed"
    return "absent"


def discard_start(git, paths) -> bool:
    """After a start line that origin does not hold: drop this run's local start commit and changes, so the worktree is
    origin/dept/stats again and no later push can carry that line (git reset --keep to origin, then the run's paths as
    origin holds them). True when HEAD equals origin/dept/stats and those paths are clean."""
    rels = [Path(p).resolve().relative_to(git.repo.resolve()).as_posix() for p in paths]
    git._run("reset", "-q", "--keep", f"origin/{BRANCH}")
    on_origin = [r for r in rels if git.show(f"origin/{BRANCH}", r) is not None]
    if on_origin:
        git._run("checkout", "-q", f"origin/{BRANCH}", "--", *on_origin)
    for r in rels:
        if r not in on_origin and (git.repo / r).exists() and not git.ls_files(r):
            (git.repo / r).unlink()                          # a file this run created, never on origin
    return git.head() == git.rev(f"origin/{BRANCH}") and not git.unclean(rels)


def stale_job(git, now: float) -> dict:
    """The pushed STATS oanda_job, if it may be cleared: a forward runner job (its ledger id) started more than
    STALE_AFTER_S ago whose ledger id has no forward_run_done line in the pushed ACCESS_LOG. Refused otherwise."""
    ok, job = stats_job(git)
    if not ok:
        raise Refused(f"cannot read origin/{BRANCH} STATUS.json")
    if job is None:
        raise Refused("oanda_job is not set; nothing to clear")
    lid = job.get("ledger_id") if isinstance(job, dict) else None
    if not lid or not str(lid).startswith("STATS-FWD-"):
        raise Refused(f"oanda_job {job!r} is not a forward runner job; its owner clears it")
    started = datetime.strptime(job["started_utc"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc).timestamp()
    if now - started < STALE_AFTER_S:
        raise Refused(f"the job started {(now - started) / 3600:.1f} h ago; it is stale only after "
                      f"{STALE_AFTER_S // 3600} h")
    if any(r.get("kind") == "forward_run_done" and r.get("ledger_id") == lid for r in pushed_access_lines(git)):
        raise Refused(f"run {lid} has a closing line; the job was set by another run")
    return job


def calendar_ruling(git, from_sha: str | None, to_sha: str | None) -> dict | None:
    """The pushed STATS ruling that allows the forward calendar to change from from_sha to to_sha (the CSV sha256s of
    the last run's calendar and this run's): a line of RULINGS_REL on origin/dept/stats with kind
    "forward_calendar_ruling", from_calendar_sha256 and to_calendar_sha256. None when there is none (red team 3,
    items 1 and 5)."""
    if not from_sha or not to_sha or not git.fetch(BRANCH):
        return None
    for line in (git.show(f"origin/{BRANCH}", RULINGS_REL) or "").splitlines():
        try:
            r = json.loads(line)
        except ValueError:
            continue
        if (isinstance(r, dict) and r.get("kind") == "forward_calendar_ruling"
                and r.get("from_calendar_sha256") == from_sha and r.get("to_calendar_sha256") == to_sha):
            return r
    return None


def set_oanda_job(job, path: Path | None = None) -> None:
    path = Path(path or STATS_STATUS)
    s = json.loads(path.read_text())
    s["oanda_job"] = job
    Path(path).write_bytes(status_bytes(s))              # the file's own format (red team 6, F8)


def check_access_row(row: dict) -> dict:
    """The runner's ACCESS_LOG.jsonl lines (on dept/stats, merged) carry ids, times, counts of requests and code
    hashes only: any other key is refused, so no P&L, fill or trade field can reach the branch."""
    extra = set(row) - ACCESS_KEYS
    if extra:
        raise ValueError(f"access-log keys not allowed on {BRANCH}: {sorted(extra)}")
    return row


def append_access(row: dict, path: Path | None = None) -> None:
    check_access_row(row)
    path = Path(path or ACCESS_LOG)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        f.write(json.dumps(row) + "\n")


# ------------------------------------------------------------------ the locked log (dept/stats-locked)

class LockedLog:
    """The forward log's own worktree of dept/stats-locked: an orphan branch (no history shared with dept/stats),
    never merged. Path: $STATS_LOCKED_WT, else <runner worktree>/../stats-locked-wt; it must lie outside every
    checkout of the repository. open() creates it on the first run (from origin, or from an empty orphan root that is
    pushed), syncs it with origin and returns the log path; publish() commits the log and pushes it there."""

    def __init__(self, main_git: Git, path: Path | None = None):
        self.main = main_git
        self.path = Path(path or os.environ.get(LOCKED_WT_ENV) or (main_git.toplevel().parent / "stats-locked-wt"))
        self.path = self.path.resolve()
        roots = REG.checkout_roots(C.REPO) | {main_git.toplevel(), main_git.common_root()}
        hit = REG.inside_a_checkout(self.path, roots)
        if hit is not None:
            raise Refused(f"the locked worktree {self.path} must lie outside every checkout ({hit})")
        self.git = Git(self.path)
        self.discarded = 0

    def _orphan_ok(self, g, ref: str) -> None:
        """Refused unless `ref` shares no history with origin/dept/stats. Run before every push and every merge of
        dept/stats-locked."""
        if not g.rev(f"origin/{BRANCH}") and not g.fetch(BRANCH):
            raise Refused(f"cannot read origin/{BRANCH} to check that {LOCKED_BRANCH} is an orphan branch")
        if g.shares_history(ref, f"origin/{BRANCH}"):
            raise Refused(f"{ref} shares history with {BRANCH}; {LOCKED_BRANCH} must be an orphan branch")

    def _create(self, on_origin: bool) -> None:
        local = self.main.rev(f"refs/heads/{LOCKED_BRANCH}")
        if on_origin:
            self.main.fetch(LOCKED_BRANCH)
            self._orphan_ok(self.main, f"origin/{LOCKED_BRANCH}")
            r = (self.main._run("worktree", "add", str(self.path), LOCKED_BRANCH) if local else
                 self.main._run("worktree", "add", "-b", LOCKED_BRANCH, str(self.path), f"origin/{LOCKED_BRANCH}"))
        elif local:
            r = self.main._run("worktree", "add", str(self.path), LOCKED_BRANCH)
        else:
            r = self.main._run("worktree", "add", "--orphan", "-b", LOCKED_BRANCH, str(self.path))
            if r.returncode == 0:
                r = self.git._run("commit", "-q", "--allow-empty", "-m",
                                  "STATS locked: empty orphan root (dept/stats-locked is never merged)")
        if r.returncode:
            raise Refused(f"cannot create the locked worktree: {(r.stderr or r.stdout).strip()[:300]}")
        if not on_origin:
            self._orphan_ok(self.git, "HEAD")
            if self.git._run("push", "-q", "origin", f"HEAD:refs/heads/{LOCKED_BRANCH}").returncode:
                raise Refused(f"cannot push the new {LOCKED_BRANCH}")

    def open(self) -> Path:
        on_origin = self.main.remote_has(LOCKED_BRANCH)
        if on_origin is None:
            raise Refused("cannot read origin")
        if not (self.path / ".git").exists():
            if self.path.exists() and any(self.path.iterdir()):
                raise Refused(f"{self.path} exists and is not a worktree")
            self._create(bool(on_origin))
        if self.git.branch() != LOCKED_BRANCH:
            raise Refused(f"{self.path} is not on {LOCKED_BRANCH}")
        self._orphan_ok(self.git, "HEAD")
        self._discard_leftovers()
        if not self.git.fetch(LOCKED_BRANCH):
            raise Refused(f"cannot fetch origin/{LOCKED_BRANCH}")
        local, remote = self.git.head(), self.git.rev(f"origin/{LOCKED_BRANCH}")
        if local != remote:
            if remote and self.git.is_ancestor(local, remote):              # another writer pushed since
                self._orphan_ok(self.git, f"origin/{LOCKED_BRANCH}")
                if self.git._run("merge", "-q", "--ff-only", f"origin/{LOCKED_BRANCH}").returncode:
                    raise Refused(f"cannot fast-forward {LOCKED_BRANCH}")
            elif not self._sync_push():                                     # this worktree's unpushed commits
                raise Refused(f"cannot push the earlier unpushed {LOCKED_BRANCH} commits")
        return self.path / LOCKED_LOG_REL

    def _discard_leftovers(self) -> None:
        """A run that stopped between appending to the log and committing it leaves uncommitted lines. They are
        dropped (the committed run_state floors recompute them; fwd_core.append_note records how many); anything else
        uncommitted in the worktree is refused."""
        st = self.git._run("status", "--porcelain", "--untracked-files=all").stdout
        if not st.strip():
            return
        if [line[3:].strip('"') for line in st.splitlines() if line.strip()] != [LOCKED_LOG_REL]:
            raise Refused(f"the locked worktree {self.path} has uncommitted files other than the log: {st[:200]}")
        log = self.path / LOCKED_LOG_REL
        committed = self.git.show("HEAD", LOCKED_LOG_REL)
        n_committed = 0 if committed is None else sum(1 for x in committed.splitlines() if x.strip())
        self.discarded = max(1, len(C.read_log(log)) - n_committed)
        if committed is None:
            log.unlink()
        elif self.git._run("checkout", "-q", "--", LOCKED_LOG_REL).returncode:
            raise Refused("cannot restore the committed forward log")
        if self.git.status():
            raise Refused(f"the locked worktree {self.path} is still not clean")

    def _sync_push(self) -> bool:
        """Push HEAD to dept/stats-locked; if another writer (locked_runner) pushed first, merge origin (a merge commit
        on this data-only branch, never a rebase) and push again. True when origin then holds HEAD."""
        self._orphan_ok(self.git, "HEAD")
        if self.git._run("push", "-q", "origin", f"HEAD:refs/heads/{LOCKED_BRANCH}").returncode:
            if not self.git.fetch(LOCKED_BRANCH):
                return False
            self._orphan_ok(self.git, f"origin/{LOCKED_BRANCH}")
            if self.git._run("merge", "-q", "--no-edit", f"origin/{LOCKED_BRANCH}").returncode:
                self.git._run("merge", "--abort")
                return False
            self._orphan_ok(self.git, "HEAD")
            if self.git._run("push", "-q", "origin", f"HEAD:refs/heads/{LOCKED_BRANCH}").returncode:
                return False
        return self.git.fetch(LOCKED_BRANCH) and self.git.rev(f"origin/{LOCKED_BRANCH}") == self.git.head()

    def publish(self, msg: str) -> tuple:
        """(pushed, head sha) after committing the log on dept/stats-locked and checking origin holds it."""
        if (self.path / LOCKED_LOG_REL).exists():
            self.git._run("add", "--", LOCKED_LOG_REL)
            r = self.git._run("commit", "-q", "-m", msg, "--", LOCKED_LOG_REL)
            if r.returncode and "nothing" not in (r.stdout + r.stderr):
                return False, self.git.head()
        return self._sync_push(), self.git.head()


# ------------------------------------------------------------------ DATA's code, pinned (DEPS.json)

def check_deps(deps: Path | None = None, repo: Path | None = None) -> dict:
    """fwd_core.check_data_deps: DATA's pinned code in this checkout (Refused if missing, PinError if changed)."""
    return C.check_data_deps(deps, repo)


def _import_from_checkout(module: str, rel: str):
    """Import `module` with this checkout's root first on sys.path; refuse a copy from anywhere else."""
    check_deps()
    root = str(C.REPO)
    if root not in sys.path:
        sys.path.insert(0, root)
    mod = importlib.import_module(module)
    if Path(mod.__file__).resolve() != (C.REPO / rel).resolve():
        raise C.PinError(f"{module} was imported from {mod.__file__}, not from this checkout")
    return mod


def loaders(repo_root: Path | None = None):
    """research.common.loaders from this checkout (pinned); FX_REPO_ROOT (this checkout) is where it logs reads."""
    os.environ["FX_REPO_ROOT"] = str(repo_root or C.REPO)
    return _import_from_checkout("research.common.loaders", f"{COMMON}/loaders.py")


def downloader():
    """DATA's downloader, research/data/oanda_download.py from this checkout (pinned)."""
    return _import_from_checkout("research.data.oanda_download", DOWNLOADER)


# ------------------------------------------------------------------ the request budget

def _days(a: str, b: str) -> list:
    out, d = [], datetime.strptime(a, "%Y-%m-%d").date()
    end = max(d, datetime.strptime(b, "%Y-%m-%d").date())
    while d <= end:
        out.append(d.isoformat())
        d = d.fromordinal(d.toordinal() + 1)
    return out


def pushed_requests_by_day(lines: list, exclude: str | None = None, today: str | None = None) -> dict:
    """OANDA requests per UTC day from the pushed ACCESS_LOG lines:
    - a forward_run_done line: its requests_by_utc_day (or its requests on its own day); requests null (unknown)
      counts the whole budget on every UTC day from its start line to it;
    - a forward_run_start line with no closing line (a killed run; `exclude` is the current run): the whole budget
      on every UTC day from its start to its forward_stale_lock_cleared line, or to `today` while not cleared."""
    start = {r.get("ledger_id"): str(r.get("utc", ""))[:10] for r in lines if r.get("kind") == "forward_run_start"}
    done = {r.get("ledger_id") for r in lines if r.get("kind") == "forward_run_done"}
    cleared = {r.get("cleared_ledger_id"): str(r.get("utc", ""))[:10] for r in lines
               if r.get("kind") == "forward_stale_lock_cleared"}
    out = {}

    def add(day, n):
        out[day] = out.get(day, 0) + int(n)
    for r in lines:
        k, lid = r.get("kind"), r.get("ledger_id")
        if k == "forward_run_done":
            day = str(r.get("utc", ""))[:10]
            per = r.get("requests_by_utc_day")
            if isinstance(per, dict) and (per or r.get("requests") == 0):
                for d, n in per.items():
                    add(d, n)
            elif r.get("requests") is None:                       # unknown: the whole budget, every day it ran
                for d in _days(start.get(lid, day), day):
                    add(d, MAX_REQUESTS_PER_DAY)
            else:
                add(day, r["requests"])
        elif k == "forward_run_start" and lid not in done and lid != exclude:
            day = str(r.get("utc", ""))[:10]
            for d in _days(day, cleared.get(lid) or today or day):
                add(d, MAX_REQUESTS_PER_DAY)
    return out


class BudgetSession:
    """Wraps the Fetcher's requests.Session. Candle URLs only; at most max_per_day requests per UTC day, counted on
    disk before each request is sent (failures and retries included, across runs), and never below the pushed count
    for that day (`seed`, so a fresh container keeps the budget); at least min_gap_s apart. An exclusive flock on
    <state>.lock is held from the read of the count to the end of the send, so two processes never interleave."""

    def __init__(self, inner, state: Path, max_per_day: int = MAX_REQUESTS_PER_DAY, min_gap_s: float = MIN_GAP_S,
                 clock=None, sleep=None, seed: dict | None = None):
        self.inner, self.state, self.max, self.gap = inner, Path(state), int(max_per_day), float(min_gap_s)
        self.clock, self.sleep, self.used = clock or time.time, sleep or time.sleep, 0
        self.seed, self.by_day = dict(seed or {}), {}

    @property
    def headers(self):
        return self.inner.headers

    @property
    def lock_path(self) -> Path:
        return self.state.with_suffix(".lock")

    @staticmethod
    def _day(t: float) -> str:
        return datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%d")

    def _read(self) -> dict:
        try:
            return json.loads(self.state.read_text())
        except (OSError, ValueError):
            return {"day": None, "count": 0, "last": 0.0}

    def _count(self, s: dict, day: str) -> int:
        return max(s["count"] if s["day"] == day else 0, int(self.seed.get(day, 0)))

    def remaining(self) -> int:
        return self.max - self._count(self._read(), self._day(self.clock()))

    def get(self, url, **kw):
        if not CANDLES_URL.match(str(url)):
            raise Refused("the forward runner reads EUR_USD candles only")
        self.state.parent.mkdir(parents=True, exist_ok=True)
        with open(self.lock_path, "a") as lk:
            fcntl.flock(lk.fileno(), fcntl.LOCK_EX)
            try:
                s = self._read()
                wait = s["last"] + self.gap - self.clock()
                if wait > 0:
                    self.sleep(wait)
                now = self.clock()
                day = self._day(now)
                count = self._count(s, day)
                if count >= self.max:
                    raise BudgetExceeded(f"{self.max} OANDA requests already used on {day} (UTC)")
                tmp = self.state.with_suffix(".tmp")
                tmp.write_text(json.dumps({"day": day, "count": count + 1, "last": now}))
                os.replace(tmp, self.state)
                self.used += 1
                self.by_day[day] = self.by_day.get(day, 0) + 1
                return self.inner.get(url, **kw)
            finally:
                fcntl.flock(lk.fileno(), fcntl.LOCK_UN)


# ------------------------------------------------------------------ download and load

def _rotate(path: Path, why: str) -> None:
    """Set a local candle file aside (read-only, never read again by the runner) so a new one starts at the window."""
    old = path.with_suffix(f".rotated-{int(time.time())}-{why}")
    path.rename(old)
    old.chmod(0o444)


def block_logs(git, D, data_dir: Path, tmp: Path) -> list:
    """Every FETCH_LOG a block may be in (red team 3, items 3 and 9): this checkout's (DATA's block rule,
    blocks.department_logs), STATS's copy in the data dir (outside the repo, kept when a local commit is dropped), and
    each research/departments/*/FETCH_LOG.jsonl on every origin/dept/* branch and the coordinator branch, freshly
    fetched and read with git show (written under tmp for blocks.blocked). Refused when origin cannot be read."""
    logs = [FETCH_LOG, Path(data_dir) / FETCH_LOG_NAME] + list(D.blocks.department_logs(D.OTHER_LOGS_ROOT))
    heads = git.remote_heads("dept/")
    if heads is None:
        raise Refused("cannot list origin's branches to read their FETCH_LOGs; nothing downloaded")
    for b in heads + [COORD_BRANCH]:
        if not git.fetch(b):
            raise Refused(f"cannot fetch origin/{b} to read its FETCH_LOGs; nothing downloaded")
        names = git.ls_tree(f"origin/{b}", "research/departments")
        if names is None:
            raise Refused(f"cannot list origin/{b}; nothing downloaded")
        for rel in names:
            if DEPT_FETCH_LOG.match(rel):
                text = git.show(f"origin/{b}", rel)
                if text is None:
                    raise Refused(f"cannot read origin/{b}:{rel}; nothing downloaded")
                p = Path(tmp) / b.replace("/", "_") / rel
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(text)
                logs.append(p)
    return logs


def check_blocks(git, D, data_dir: Path) -> None:
    """Refused before any request when DATA's block rule (research/data/blocks.py blocked) finds a 403, 407 or 429
    from the candles host under 24 hours old in any FETCH_LOG of block_logs."""
    host = urlsplit(D.HOST).hostname
    with tempfile.TemporaryDirectory(prefix="stats_fetch_logs_") as tmp:
        why = D.blocks.blocked(host, block_logs(git, D, data_dir, Path(tmp)), time.time())
    if why:
        raise Refused(f"blocked: {why}; nothing downloaded")


def preflight_blocks(git, data_dir: Path | None = None) -> str:
    """Before the start push, and in --check (red team 5, item 2): check_blocks over every FETCH_LOG (this
    checkout's, the data dir's copy, every origin/dept/* branch's and the coordinator branch's), and DATA's own
    pushed-logs read (blocks.pushed_logs: origin is the GitHub repo, every REQUIRED_BRANCHES branch is there, no live
    block in any department's fetch log). Refused otherwise; nothing is spent."""
    D = downloader()
    data_dir = Path(data_dir or locked_dir() / "forward")
    check_blocks(git, D, data_dir)
    repo = D.PUSHED_REPO if getattr(D, "PUSHED_REPO", None) is not None else D.REPO
    try:
        texts = D.blocks.pushed_logs(repo)
    except D.blocks.PushedLogsUnreadable as e:
        raise Refused(f"DATA's pushed-logs check refuses: {e}; nothing is started") from None
    why = D.blocks.blocked(urlsplit(D.HOST).hostname, [], time.time(), texts)
    if why:
        raise Refused(f"blocked: {why}; nothing is started")
    return f"no live block in {len(texts)} pushed fetch log(s); every required branch on origin"


def _log_lines(p: Path) -> list:
    """A FETCH_LOG's lines, read through DATA's checked reader (research.common.files.read_text)."""
    return C.checked_reader("read_text")(p).splitlines() if Path(p).exists() else []


def download_step(git, ledger_id: str, start: int, end: int, data_dir: Path | None = None,
                  meter: dict | None = None) -> dict:
    """EUR_USD M1 bid/ask from start to end (resumes the local file), with DATA's Fetcher and download(), under the
    budget (seeded from the pushed ACCESS_LOG). Downloads only whole 5,000-bar windows that fit the day's budget.
    covered_to is the end of the last bar actually saved (never past the windows asked for), so trades settle only
    inside the bars held. `meter` gets the requests sent and their UTC days even when DATA's Fetcher raises.
    The local file is set aside and started again at `start` when it does not reach `start`, starts after it, or
    starts more than MAX_FILE_LEAD_S before it (FILE_STATE.json holds its first second).
    Before any request, no FETCH_LOG on any origin/dept/* branch, the coordinator branch, this checkout or the data dir
    may hold a live block of the candles host (check_blocks), and the ledger id must be an open forward run whose
    window holds [start, end): DATA's
    locked_run_window(id) is ('forward_inputs', lo, hi), the id of a forward_run_start line pushed on origin/dept/stats
    with no closing line (research.common.loaders.open_run_kind, the rule of the 'forward_inputs' read) and
    lo <= start, end <= hi (FORWARD_START - 400 days to now). DATA's Fetcher checks the same again on every request
    (expect_kind='forward_inputs'), follows no redirect, and writes a 403, 407 or 429 to STATS's FETCH_LOG."""
    meter = {} if meter is None else meter
    meter.update(requests=0, requests_by_utc_day={})
    D = downloader()
    data_dir = Path(data_dir or locked_dir() / "forward")
    if not D.LEDGER_ID.match(ledger_id) or not D.on_boundary(end, "M1") or start % 60:
        raise Refused("bad ledger id or window")
    git.fetch(BRANCH)
    lines = []
    for rel in D.LEDGER_FILES:
        lines += (git.show(f"origin/{BRANCH}", rel) or "").splitlines()
    if not D.ledger_has_id(ledger_id, lines):
        raise Refused(f"ledger id {ledger_id} is not in a pushed STATS ledger line; nothing downloaded")
    w = D.locked_run_window(ledger_id)
    if w is None or w[0] != "forward_inputs":
        raise Refused(f"ledger id {ledger_id} is not an open forward run (a forward_run_start line pushed on "
                      f"origin/{BRANCH} with no forward_run_done or forward_stale_lock_cleared line); nothing downloaded")
    if max(int(start), D.CUTOFF) < w[1] or int(end) > w[2]:
        raise Refused(f"the window {int(start)} .. {int(end)} is outside what run {ledger_id} may read ({w[1]} .. "
                      f"{w[2]}); nothing downloaded")
    data_dir.mkdir(parents=True, exist_ok=True)
    check_blocks(git, D, data_dir)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    seed = pushed_requests_by_day(pushed_access_lines(git), exclude=ledger_id, today=today)
    n_logged = len(_log_lines(FETCH_LOG))
    path = data_dir / D.file_name("EURUSD", "M1")
    state = data_dir / "FILE_STATE.json"
    fx = None
    if path.exists():
        path.chmod(0o644)
    try:
        prev = D.last_saved(path)
        try:
            first = json.loads(state.read_text()).get("first_ts") if state.exists() else None
        except ValueError:
            first = None
        if path.exists() and (prev is None or first is None or prev + 60 < start or first > start
                              or first < start - MAX_FILE_LEAD_S):
            _rotate(path, "from" + str(first))
            prev = None
        if not path.exists():
            state.write_text(json.dumps({"file": path.name, "first_ts": int(start)}))
        cur = start if prev is None else prev + 60
        if prev is None and math.ceil((end - cur) / (D.COUNT * 60)) > MAX_REQUESTS_PER_DAY:
            meter["rebuild_note"] = (f"cannot rebuild within one day's budget: {math.ceil((end - cur) / (D.COUNT * 60))} "
                                     f"windows from ts {int(cur)} > {MAX_REQUESTS_PER_DAY} a UTC day (red team 5, "
                                     "item 4; run from a persistent container)")
        fx = D.Fetcher(gran="M1", max_to=end, max_fail_cycles=0, locked_run=ledger_id, expect_kind="forward_inputs",
                       block_log=FETCH_LOG)
        fx.s = BudgetSession(fx.s, data_dir / "REQUESTS.json", MAX_REQUESTS_PER_DAY, MIN_GAP_S, seed=seed)
        step = D.COUNT * 60
        need = math.ceil((end - cur) / step) if cur < end else 0
        end_eff = end if need <= fx.s.remaining() else cur + max(0, fx.s.remaining()) * step
        with open(data_dir / "DOWNLOAD_LOG.jsonl", "a") as log:
            log.write(json.dumps({"utc": utc_now(), "instruments": ["EUR_USD"], "granularity": "M1", "from_ts": cur,
                                  "to_ts": end_eff, "locked_run": ledger_id}) + "\n")
        if end_eff > cur:
            print(f"LOCKED RUN, ledger id {ledger_id}: {need} window(s) wanted, budget {fx.s.remaining()}", flush=True)
            try:
                D.download(fx, "EURUSD", "EUR_USD", data_dir, start, end_eff)
            except BudgetExceeded:
                pass
        last = D.last_saved(path)
        if last is None:
            raise Refused(f"{path.name} holds no bars")
        covered = min(end_eff, last + 60)
        return {"path": path, "covered_to": int(covered), "requests": fx.s.used,
                "requests_by_utc_day": dict(fx.s.by_day)}
    finally:
        if fx is not None:
            meter.update(requests=fx.s.used, requests_by_utc_day=dict(fx.s.by_day))
        if path.exists():
            path.chmod(0o444)
        added = _log_lines(FETCH_LOG)[n_logged:]
        if added:                                       # a block line, also kept in the data dir (item 9)
            with open(data_dir / FETCH_LOG_NAME, "a") as f:
                f.write("\n".join(added) + "\n")


def carry_blocks(data_dir: Path | None = None) -> int:
    """Append to STATS's FETCH_LOG.jsonl (in the repo) every line of the data dir's copy that it lacks, in order: a
    block line whose local commit was dropped reaches origin with the run's closing commit (red team 4, item 3).
    Returns the number of lines added."""
    data_dir = Path(data_dir or locked_dir() / "forward")
    have = set(_log_lines(FETCH_LOG))
    add = [x for x in _log_lines(data_dir / FETCH_LOG_NAME) if x.strip() and x not in have]
    if add:
        FETCH_LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(FETCH_LOG, "a") as f:
            f.write("\n".join(add) + "\n")
    return len(add)


def load_step(ledger_id: str, start: int, end: int, path: Path, repo_root: Path | None = None) -> dict:
    """Bars start..end through DATA's loaders (override 'forward_inputs', logged in ACCESS_LOG.jsonl), float64.
    Refused when the bars start more than 4 days after `start` (the file must hold the lagged inputs)."""
    L = loaders(repo_root)
    REG.register(L, path, int(start), int(end) - 1)
    df = L.load_m1("EUR_USD", era=C.era_string(start), dtype="float64", start=int(start), end=int(end),
                   override=("forward_inputs", ledger_id), dept="STATS", study="FORWARD")
    ts = df["ts_utc"].to_numpy()
    if not len(ts):
        raise Refused(f"{Path(path).name} holds no bars from ts {int(start)}")
    if int(ts.min()) > int(start) + 4 * 86400:
        raise Refused("the local forward file starts after the lagged-input start; rebuild it")
    return {c: df[c].to_numpy() for c in df.columns}
