"""STATS forward log: where the locked forward candles live, and how DATA's loaders find them.

The only runtime file of forward/ that uses the loaders' data root and registry fields. It never reads a file
(research/common/tests/test_core_guard.py allows those names in STATS only in a file with no raw reader): it writes
the registry JSON with Path.write_text and takes each sha256 from fwd_core. Every price row is read by
research.common.loaders.load_m1, which checks that sha256 and logs a locked read in ACCESS_LOG.jsonl.
`L` below is research.common.loaders imported from this checkout by fwd_io.loaders() (pinned in DEPS.json).
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[4]))      # this checkout's root (DATA's research/common)
import research.common  # noqa: E402,F401  (first: DATA's runtime audit hook, research/common/audit.py)
import fwd_core as C  # noqa: E402

DATASET = "STATS_FORWARD_EUR_USD_M1_BA"
DATASETS_ENV = "FX_DATASETS_JSON"


def checkout_roots(repo: Path | None = None) -> set:
    """Every checkout a locked path must stay out of: this checkout (the runner's worktree), its git toplevel, and the
    main checkout that holds the git common dir (the session checkout). Refused when git cannot tell."""
    repo = Path(repo or C.REPO)
    roots = {repo.resolve()}
    for arg in ("--show-toplevel", "--git-common-dir"):
        r = subprocess.run([*C.GIT, "-C", str(repo), "rev-parse", arg], capture_output=True, text=True, env=C.git_env())
        out = r.stdout.strip()
        if r.returncode or not out:
            raise C.Refused(f"git cannot tell the checkouts of {repo} ({arg})")
        q = Path(out) if Path(out).is_absolute() else repo / out
        roots.add(q.resolve() if arg == "--show-toplevel" else q.resolve().parent)
    return roots


def inside_a_checkout(path: Path, roots) -> Path | None:
    p = Path(path).expanduser().resolve()
    return next((r for r in roots if p == r or r in p.parents), None)


def locked_dir(L) -> Path:
    """<the loaders' data root>/stats_locked: STATS's scratch for locked rows, outside this checkout, its toplevel and
    the session checkout (checkout_roots)."""
    d = L.data_root().expanduser().resolve() / "stats_locked"
    hit = inside_a_checkout(d, checkout_roots())
    if hit is not None:
        raise C.Refused(f"locked data must live outside the repo ({d} is inside {hit})")
    return d


def register(L, path: Path, first_ts: int, last_ts: int) -> Path:
    """Register the forward candles file as a STATS local locked set (locked=true, no branch) in a datasets.json
    next to it, and point $FX_DATASETS_JSON at that file. first_ts and last_ts are the read's window bounds."""
    path = Path(path).resolve()
    entry = {"name": DATASET, "instrument": "EUR_USD", "granularity": "M1", "price": "BA",
             "first_ts": int(first_ts), "last_ts": int(last_ts), "sha256": C.sha256_file(path),
             "relpath": path.relative_to(L.data_root().expanduser().resolve()).as_posix(),
             "locked": True, "branch": None, "packing": "none"}
    reg = path.parent / "datasets.json"
    reg.write_text(json.dumps([entry], indent=1))
    os.environ[DATASETS_ENV] = str(reg)
    return reg


def held_locally(L, instrument: str, start: int, end: int) -> bool:
    """True when every unlocked registered M1 bid/ask set of `instrument` overlapping [start, end) is already a file
    under the data root, so load_m1 reads it without fetching a data branch. Tests skip on False; never fetch."""
    sets = [e for e in L.registry().values()
            if e["instrument"] == instrument and e["granularity"] == "M1" and e["price"] == "BA"
            and not e["locked"] and e["first_ts"] <= int(end) - 1 and e["last_ts"] >= int(start)]
    root = L.data_root()
    return bool(sets) and all((root / e["relpath"]).exists() for e in sets)
