#!/usr/bin/env python3
"""STATS forward paper log, one run a day (research/departments/STATS/FORWARD.md).

    python3 <runner worktree>/research/departments/STATS/forward/run_forward.py --day YYYY-MM-DD   # trades closed by then
    python3 .../run_forward.py --check               # every gate piece, both locks; reads nothing locked
    python3 .../run_forward.py --clear-stale-lock    # clear a killed run's STATS oanda_job (older than 6 h, no closing line)
    python3 .../run_forward.py --push-closing        # push a closing commit whose push failed (rebuilt on origin if moved)

Run it from a dedicated worktree of dept/stats (git worktree add --detach ../stats-fwd-wt origin/dept/stats), never
from the session checkout. --day is a trading-day label; the run reads bars up to its close (17:00 New York) and
refuses a day not yet closed. First, every GIT_CONFIG_* and repository variable is deleted from the process
environment (fwd_core.clean_process_env), so DATA's git calls in this run see the origin STATS checked. Order of a run:
 1. refuse unless the picks, frozen files and calendar check out and the calendar covers at least one pick;
 2. the gate: dedicated worktree; origin the GitHub repo (every fetch and push URL as git resolves it, TLS verified);
    no replace refs and no grafts; HEAD = origin/dept/stats (refused, never dropped, while HEAD holds unpushed
    commits: "push it with --push-closing" for a closing commit, "drop it" for a start line origin lacks), clean;
    forward/ and
    STATS/audit_inputs.py committed, equal to origin and their tree sha256 approved in forward/RED_TEAM.md;
    research.common from this checkout; DEPS.json's DATA and COST commits on the coordinator branch; DATA's and COST's
    pinned files and the picks unchanged; the calendar pin's CSV byte-equal to DATA's file at source.data_commit (a
    file under research/departments/DATA/, the commit on origin/dept/data and merged on the coordinator branch);
 3. refuse if STATS's own oanda_job is set on origin/dept/stats, or DATA's on origin/dept/data; refuse if any FETCH_LOG
    (this checkout, the data dir, every origin/dept/* branch, the coordinator branch) holds a live block, or DATA's
    pushed-logs check refuses (origin not GitHub, a required branch missing), before anything is pushed;
 4. load COST's model; open the locked log's worktree (dept/stats-locked) and read each pick's floor from it; refuse
    when the forward calendar changed since the last run (by time and status) unless a pushed STATS ruling line
    (FORWARD_RULINGS.jsonl) allows that change;
 5. append the ledger line to ACCESS_LOG.jsonl and set STATS's oanda_job, commit and PUSH; then read origin back and
    decide from origin only: the line is there -> go on; origin read and the line is not there -> drop the local start
    commit (back to origin, lock never published) and refuse, nothing read; origin unreadable -> refuse, keep the lock
    as it is (no failure path ever pushes the start line later);
 6. check DATA's lock again; refuse if any FETCH_LOG on origin/dept/*, the coordinator branch, this checkout or the
    data dir holds a live block of the candles host; download from the earliest floor less its lookback (at most 30
    requests a UTC day, 5 s apart, seeded from the pushed ACCESS_LOG); load through DATA's loaders (logged);
 7. compute (one pick's error never stops the others); append to the locked log; commit and push dept/stats-locked;
 8. always add the closing line (with each pick's calendar reason, dates only, and a note when a rebuild of the
    candle file cannot fit one day's budget), clear oanda_job, commit and push dept/stats (with STATS's FETCH_LOG.jsonl
    when DATA's Fetcher logged a 403 or 429 block there, plus any block line of the data dir's copy the repo's lacks).
    A rejected push is rebuilt on origin/dept/stats and pushed again (3 tries); if it never lands the run's status is
    "failed: closing push", the exit code is 3, and --push-closing is the recovery. Prints counts only, no P&L.
"""
from __future__ import annotations

import argparse
import secrets
import sys
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[4]))      # this checkout's root (DATA's research/common)
import research.common  # noqa: E402,F401  (first: DATA's runtime audit hook, research/common/audit.py)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import fwd_core as C  # noqa: E402
import fwd_cost  # noqa: E402
import fwd_io as IO  # noqa: E402

STUDY = "FORWARD"


def new_ledger_id(now: datetime | None = None) -> str:
    now = now or datetime.now(timezone.utc)
    return f"STATS-FWD-{now:%Y%m%dT%H%M%SZ}-{secrets.token_hex(3)}"


def code_sha() -> dict:
    fs = sorted(C.HERE.glob("*.py")) + [IO.DEPS]
    return {f.relative_to(C.REPO).as_posix(): C.sha256_file(f) for f in fs}


class Ops:
    """The steps with side effects. Tests pass a fake with the same methods."""

    def __init__(self, git=None):
        self.git = git or IO.Git()
        self._locked = None

    def gate(self):
        return IO.gate(self.git)

    def worktree(self, allow=(), allow_status=False, allow_behind=False):
        return IO.worktree_check(self.git, allow_appended=allow, allow_status=allow_status, allow_behind=allow_behind)

    def leftovers(self, rels):
        """{rel: lines appended since HEAD} (Refused when a change is anything but appended lines)."""
        out = {}
        for rel in rels:
            lines = IO.appended_lines(self.git, rel)
            if lines is None:
                raise IO.Refused(f"{rel} has uncommitted changes other than appended lines; sort them by hand")
            out[rel] = lines
        return out

    def blocks(self):
        return IO.preflight_blocks(self.git)

    def stats_lock_free(self):
        return IO.stats_lock_free(self.git)

    def stale_job(self, now):
        return IO.stale_job(self.git, now)

    def lock_free(self):
        return IO.data_lock_free(self.git)

    def cost_model(self, cal):
        return fwd_cost.load(C.REPO, cal)

    def start_state(self, lid):
        return IO.start_state(self.git, lid)

    def discard_start(self, paths):
        return IO.discard_start(self.git, paths)

    def locked_open(self):
        self._locked = IO.LockedLog(self.git)
        return self._locked.open()

    def locked_publish(self, msg):
        return self._locked.publish(msg)

    def calendar_ruling(self, from_sha, to_sha):
        return IO.calendar_ruling(self.git, from_sha, to_sha)

    def locked_discarded(self):
        return self._locked.discarded

    def access(self, row):
        IO.append_access(row)

    def set_job(self, job):
        IO.set_oanda_job(job)

    def publish(self, paths, msg, rebuild=False, now=None):
        return self.git.commit_push(paths, msg, rebuild=rebuild, now=now)

    def download(self, lid, start, end, meter):
        return IO.download_step(self.git, lid, start, end, meter=meter)

    def carry_blocks(self):
        return IO.carry_blocks()

    def load(self, lid, start, end, path):
        return IO.load_step(lid, start, end, path)


def preflight(day: date | None, now: float):
    """Checks that read nothing locked: (picks, calendar, end). Picks pinned in DEPS.json, frozen files pinned."""
    picks = C.load_picks()
    C.verify_pins(picks)
    end = None
    if day is not None:
        if day < C.FORWARD_FIRST_DATE:
            raise IO.Refused(f"--day {day} is before the forward start {C.FORWARD_FIRST_DATE}")
        end = C.label_close_ts(day)
        if end > now:
            raise IO.Refused(f"trading day {day} has not closed yet")
    cal = C.read_calendar()
    if day is not None:
        errs = {}
        for p in picks:
            try:
                C.check_coverage(cal, day, p.get("calendar", C.EVENT_TYPES))
            except C.CalendarError as e:
                errs[p["id"]] = str(e)
        if len(errs) == len(picks):
            raise C.CalendarError(f"the calendar covers no pick on {day}: {errs}")
    return picks, cal, end


def run(day: date, ops: Ops, now: float | None = None) -> dict:
    picks, cal, end = preflight(day, time.time() if now is None else now)
    g = ops.gate()
    if not ops.stats_lock_free():
        raise IO.Refused("STATS's oanda_job is set on origin/dept/stats (another run, or a killed one: "
                         "--clear-stale-lock after 6 hours)")
    if not ops.lock_free():
        raise IO.Refused("DATA's oanda_job is set or unreadable; try later")
    ops.blocks()                                       # red team 5, item 2: before the start push opens a window
    cost = ops.cost_model(cal)
    log_path = ops.locked_open()
    discarded = ops.locked_discarded()                 # a crashed run's uncommitted lines, dropped by locked_open
    log = C.read_log(log_path)
    floors = C.floors_from_log(log, picks)
    ruling = None
    changes = C.calendar_changes(log, cal)                 # red team 3, items 1 and 5: before anything is spent
    if changes:
        prev, cur = (C.last_run_state(log) or {}).get("calendar_sha256"), C.calendar_sha(cal)
        ruling = ops.calendar_ruling(prev, cur)
        if ruling is None:
            raise C.CalendarChanged(
                f"the forward calendar changed since the last run ({str(prev)[:12]} -> {str(cur)[:12]}): {changes[:5]}. "
                "A row behind a logged position or an open decision may have moved; nothing runs until a pushed "
                f"STATS ruling line in {IO.RULINGS_REL} (kind forward_calendar_ruling, from_calendar_sha256 {prev}, "
                f"to_calendar_sha256 {cur}) allows it")
    start = C.inputs_start(picks, floors)
    paths = [IO.ACCESS_LOG, IO.STATS_STATUS, IO.FETCH_LOG]   # FETCH_LOG: a 403/429 block reaches dept/stats
    lid = new_ledger_id()
    base = {"dept": "STATS", "study": STUDY, "ledger_id": lid, "override": "forward_inputs",
            "era": C.era_string(start)}
    ops.access({"utc": IO.utc_now(), **base, "kind": "forward_run_start", "status": "started", "first_ts": start,
                "last_ts": end - 1, "outcomes_from_ts": C.FORWARD_START, "picks": [p["id"] for p in picks],
                "code_sha256": code_sha(), "tree_sha256": g["tree_sha256"],
                "calendar_sha256": g.get("calendar_sha256"), "locked_leftovers_discarded": bool(discarded),
                "budget": {"max_requests_per_day": IO.MAX_REQUESTS_PER_DAY, "min_gap_s": IO.MIN_GAP_S}})
    ops.set_job({"what": f"STATS forward log download {lid}", "started_utc": IO.utc_now(), "ledger_id": lid})
    pushed = ops.publish(paths, f"STATS forward log: run {lid} started (ledger line pushed before any download)")
    state = ops.start_state(lid)                       # origin only (red team 3, item 13)
    if state != "pushed":
        if state == "absent" and not pushed:
            clean = ops.discard_start(paths)
            raise IO.Refused("the ledger line could not be pushed (origin does not hold it); nothing downloaded or read"
                             + ("" if clean else "; the local start commit could not be dropped: reset the runner's "
                                                 f"worktree to origin/{IO.BRANCH} by hand before the next run"))
        raise IO.Refused(f"the start line's state on origin is unknown (push {'reported done' if pushed else 'failed'}, "
                         f"origin {'unreadable' if state is None else 'without it'}); nothing downloaded or read. "
                         "STATS's lock is left as it is: if origin holds the line, --clear-stale-lock closes the run "
                         "after 6 hours")
    status, data_end, summary, locked_sha = "failed", None, {}, None
    meter = {"requests": 0, "requests_by_utc_day": {}}  # filled by the download even when DATA's Fetcher raises
    try:
        if not ops.lock_free():
            raise IO.Refused("DATA started a job; stopped before any download")
        dl = ops.download(lid, start, end, meter)
        data_end = min(end, dl["covered_to"])
        m1 = ops.load(lid, start, data_end, dl["path"])
        if discarded:
            C.append_note(log_path, {"kind": "discarded_uncommitted", "lines": int(discarded), "run_ledger_id": lid,
                                     "reason": "a stopped run's uncommitted lines; recomputed from the committed "
                                               "floors"})
        res = C.compute_run(picks, cal, m1, data_end, lid, floors=floors, cost=cost, run_day=day)
        summary = C.append_run(res, log_path, cal, ruling=ruling)
        ok, locked_sha = ops.locked_publish(f"STATS forward log: run {lid}")
        status = "done" if ok else "failed: locked push"
    except Exception as e:
        status = f"failed: {type(e).__name__}"
        raise
    finally:
        req, by_day = meter.get("requests"), dict(meter.get("requests_by_utc_day") or {})
        ops.access({"utc": IO.utc_now(), **base, "kind": "forward_run_done", "status": status, "requests": req,
                    "requests_by_utc_day": by_day, "data_end_ts": data_end,
                    "pick_errors": summary.get("errors", {}), "waiting_on_events": summary.get("waiting", {}),
                    "calendar_errors": summary.get("calendar_errors", {}), "rebuild_note": meter.get("rebuild_note"),
                    "locked_commit": locked_sha})
        ops.set_job(None)
        try:
            ops.carry_blocks()                         # data-dir block lines into the closing commit (red team 4, 3)
        except Exception as e:                         # never stops the closing line and the lock's release
            print(f"warning: the data dir's FETCH_LOG lines were not carried ({type(e).__name__}); the next run's "
                  "block check still reads them there", file=sys.stderr)
        try:
            pushed = ops.publish(paths, f"STATS forward log: run {lid} {status}", rebuild=True)
        except IO.Refused as e:                        # red team 6, F7: the run's result and exit code stay
            pushed = False
            print(f"the closing commit was not rebuilt: {e}", file=sys.stderr)
        if not pushed:
            status = "failed: closing push"
            print(f"failed: closing push: the closing commit of run {lid} is not on origin/{IO.BRANCH}, so STATS's "
                  f"oanda_job and this run's forward window stay open there. Recover from the runner's worktree: "
                  f"python3 research/departments/STATS/forward/{IO.RECOVER} (it rebuilds the commit on "
                  f"origin/{IO.BRANCH} and pushes it); the next run and --clear-stale-lock refuse until then",
                  file=sys.stderr)
    return {"ledger_id": lid, "new_lines": summary.get("new_trades", 0), "requests": req, "data_end_ts": data_end,
            "pick_errors": summary.get("errors", {}), "calendar_errors": summary.get("calendar_errors", {}),
            "rebuild_note": meter.get("rebuild_note"), "status": status}


def clear_stale(ops: Ops, now: float | None = None) -> dict:
    """Clear STATS's oanda_job left by a killed forward run: only a forward runner job older than 6 hours whose ledger
    id has no closing line on origin/dept/stats. Logs a forward_stale_lock_cleared line and pushes it with the killed
    run's uncommitted lines (red team 5, item 5): ACCESS_LOG lines appended since HEAD, each the killed run's closing
    or DATA loaders read line, and FETCH_LOG lines appended since HEAD, each DATA's block line (fwd_io.check_leftovers,
    red team 6 F5). STATUS.json may differ from HEAD's in oanda_job alone, unstaged or staged (a run killed after it
    released its lock; F6). The worktree may be behind origin (F2): the clearing commit is made on HEAD and rebuilt
    on origin, which keeps another job's lock (F1); a rebuild checks the lock's age with the same clock (red team 7,
    N2). A run killed inside its start step refuses with "this run read nothing" (red team 7, item 1:
    fwd_io.killed_start, in the worktree check). Any other uncommitted change refuses."""
    now = time.time() if now is None else now
    left = ops.leftovers((IO.ACCESS_LOG_REL, IO.FETCH_LOG_REL))
    ops.worktree(allow=tuple(r for r, lines in left.items() if lines), allow_status=True, allow_behind=True)
    job = ops.stale_job(now)
    IO.check_leftovers(left, job["ledger_id"])        # red team 6, F5
    lid = new_ledger_id()
    ops.set_job(None)                                  # first (red team 7, N4): a STATUS.json it cannot write refuses
    ops.access({"utc": IO.utc_now(), "dept": "STATS", "study": STUDY, "ledger_id": lid,   # before a line is written
                "kind": "forward_stale_lock_cleared", "status": "cleared", "cleared_ledger_id": job["ledger_id"],
                "job_started_utc": job["started_utc"],
                "reason": f"older than {IO.STALE_AFTER_S // 3600} h with no closing line"})
    if not ops.publish([IO.ACCESS_LOG, IO.STATS_STATUS, IO.FETCH_LOG],
                       f"STATS forward log: stale lock of {job['ledger_id']} cleared", rebuild=True, now=now):
        raise IO.Refused(f"the clearing commit could not be pushed: python3 research/departments/STATS/forward/"
                         f"{IO.RECOVER} from the runner's worktree pushes it")
    return {"cleared": job["ledger_id"], "ledger_id": lid, "committed_lines": sum(len(v) for v in left.values())}





def _pins() -> list:
    picks = C.load_picks()
    C.verify_pins(picks)
    return picks


def _free(ok: bool) -> str:
    if not ok:
        raise IO.Refused("oanda_job is set or unreadable")
    return "free"


def _stats_lock(git) -> str:
    """STATS's lock on origin/dept/stats: "free", or refused with "taken by <its ledger id>" (red team 6, F1)."""
    ok, job = IO.stats_job(git)
    if not ok:
        raise IO.Refused("origin/dept/stats STATUS.json cannot be read")
    if job is not None:
        who = job.get("ledger_id") or job.get("what") if isinstance(job, dict) else job
        raise IO.Refused(f"taken by {who} (oanda_job is set on origin/{IO.BRANCH})")
    return "free"


def _pushable(git) -> str:
    why = git.push_dry_run()
    if why:
        raise IO.Refused(f"origin would not take a push of dept/stats: {why}")
    return "origin would take a push"


def last_closed_day(now: float) -> date:
    """The latest trading-day label whose close (17:00 New York) is at or before now."""
    d = date.fromisoformat(C.label_of(int(now)))
    while C.label_close_ts(d) > now:
        d -= timedelta(days=1)
    return d


def coverage(picks, cal, day: date) -> tuple:
    """({pick: 'covered'}, {pick: its CalendarError message, dates only}) on a run day (red team 5, item 6)."""
    ok, bad = {}, {}
    for p in picks:
        try:
            C.check_coverage(cal, day, p.get("calendar", C.EVENT_TYPES))
            ok[p["id"]] = "covered"
        except C.CalendarError as e:
            bad[p["id"]] = str(e)[:300]
    return ok, bad


def check(git=None, now: float | None = None) -> int:
    """Every gate piece, reported one by one; reads nothing locked. 0 when the runner could start now. When the
    worktree step fails (its origin, TLS, replace-ref or graft check among them), the steps that read origin (the gate,
    the blocks, both locks and the push check) are skipped, so nothing more is read from an origin that was refused
    (red team 4, item 8). Each pick's calendar coverage on the last closed day is listed; a pick not covered is a
    note ("note"), the run still goes for the others, and only no pick covered fails (red team 5, item 6)."""
    git = git or IO.Git()
    fails = 0

    def step(name, fn) -> bool:
        nonlocal fails
        try:
            print(f"ok    {name}: {fn()}")
            return True
        except Exception as e:
            fails += 1
            print(f"FAIL  {name}: {type(e).__name__}: {e}")
            return False

    step("picks (DEPS.json) and frozen files", lambda: [p["id"] for p in _pins()])
    step("forward calendar", lambda: f"{len(C.read_calendar())} rows")
    try:
        day = last_closed_day(time.time() if now is None else now)
        ok, bad = coverage(C.load_picks(), C.read_calendar(), day)
        for pid in sorted(ok):
            print(f"ok    calendar coverage {pid} on {day}: covered")
        for pid in sorted(bad):
            print(f"note  calendar coverage {pid} on {day}: not covered, its run would be an error line: {bad[pid]}")
        if not ok:
            fails += 1
            print(f"FAIL  calendar coverage on {day}: no pick is covered; the run is refused")
    except Exception as e:
        fails += 1
        print(f"FAIL  calendar coverage: {type(e).__name__}: {e}")
    step("DATA's code (DEPS.json)", lambda: IO.check_deps()["data_commit"][:8])
    step("COST's model (DEPS.json cost)", lambda: fwd_cost.check(C.REPO)["cost_commit"][:8])
    wt_ok = step("worktree", lambda: IO.worktree_check(git)[:8])
    step("HEAD reflog (closing push)", lambda: IO.check_head_reflog(git))    # red team 8, N-a
    step("forward tree sha256", lambda: IO.tree_sha256(C.REPO, IO.forward_files(git)))
    origin_steps = (("gate (worktree, tree approval, DEPS pins, calendar pin)", lambda: IO.gate(git)["tree_sha256"]),
                    ("STATS lock", lambda: _stats_lock(git)),
                    ("DATA lock", lambda: _free(IO.data_lock_free(git))),
                    ("blocks (every FETCH_LOG; DATA's pushed-logs check)", lambda: IO.preflight_blocks(git)),
                    ("push access (git push --dry-run)", lambda: _pushable(git)))
    for name, fn in origin_steps:
        if wt_ok:
            step(name, fn)
        else:
            fails += 1
            print(f"SKIP  {name}: the worktree step failed; nothing more is read from origin")
    return 1 if fails else 0


def main(argv=None) -> int:
    C.clean_process_env()                              # red team 4, item 5: before any git call, DATA's included
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--day", type=date.fromisoformat, help="trading-day label YYYY-MM-DD (closed)")
    g.add_argument("--check", action="store_true", help="every gate piece and both locks; reads nothing locked")
    g.add_argument("--clear-stale-lock", action="store_true",
                   help="clear a killed forward run's STATS oanda_job (older than 6 h, no closing line); logs a line")
    g.add_argument("--push-closing", action="store_true",
                   help="push the runner's closing commit whose push failed (rebuilt on origin/dept/stats if it moved)")
    a = ap.parse_args(argv)
    if a.check:
        return check()
    if a.push_closing:
        print(f"closing commit pushed: origin/{IO.BRANCH} is {IO.push_closing(IO.Git())[:8]}")
        return 0
    if a.clear_stale_lock:
        r = clear_stale(Ops())
        print(f"cleared the oanda_job of {r['cleared']} (line {r['ledger_id']})")
        return 0
    r = run(a.day, Ops())
    print_result(r)
    return exit_code(r)


def print_result(r: dict) -> None:
    """Counts, each pick's calendar reason (dates only; red team 5, item 6) and the rebuild note; never a P&L."""
    print(f"run {r['ledger_id']} {r['status']}: {r['new_lines']} new trade line(s) on dept/stats-locked, "
          f"{r['requests']} OANDA request(s), bars to ts {r['data_end_ts']}, pick errors {r['pick_errors'] or 'none'}")
    for pid, msg in sorted((r.get("calendar_errors") or {}).items()):
        print(f"  {pid}: {msg}")
    if r.get("rebuild_note"):
        print(f"  note: {r['rebuild_note']}")


def exit_code(r: dict) -> int:
    """0 only for a run whose status is "done"; 3 otherwise (a locked push or the closing push failed)."""
    return 0 if r.get("status") == "done" else 3


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (IO.Refused, C.CalendarError, C.PinError, C.OutcomeGuardError) as e:   # CalendarChanged is a Refused
        print(f"refused: {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(2)
