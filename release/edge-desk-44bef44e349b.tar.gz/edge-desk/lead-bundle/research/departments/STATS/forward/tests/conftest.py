import json
import os
import sys
from pathlib import Path

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
FWD = os.path.dirname(HERE)
STATS = os.path.dirname(FWD)
for p in (HERE, FWD, STATS):
    if p not in sys.path:
        sys.path.insert(0, p)
os.environ.pop("OANDA_API_TOKEN", None)          # the tests never send a request; no token in their process
REPO = os.path.dirname(os.path.dirname(os.path.dirname(STATS)))
HAVE_COMMON = os.path.isfile(os.path.join(REPO, "research", "common", "files.py"))


def pytest_collection_modifyitems(config, items):
    """forward/ reads every non-price file through DATA's research.common.files (pinned in DEPS.json). Without DATA's
    research/common in this checkout nothing here can run: every test is skipped with the reason. Run them in a
    scratch worktree of dept/stats merged with the DATA commit pinned in DEPS.json (FORWARD.md "Tests")."""
    if HAVE_COMMON:
        return
    skip = pytest.mark.skip(reason="DATA's research/common is not in this checkout (merge the DEPS.json data_commit)")
    for it in items:
        it.add_marker(skip)


@pytest.fixture
def fx_root(tmp_path, monkeypatch):
    """A temporary data root for DATA's loaders, and FX_REPO_ROOT / FX_DATASETS_JSON restored after the test.
    Kept here, in a file with no raw reader, so the test modules that read files never name the data root."""
    root = tmp_path / "fxroot"
    monkeypatch.setenv("FX_DATA_ROOT", str(root))
    monkeypatch.setenv("FX_REPO_ROOT", os.environ.get("FX_REPO_ROOT", ""))       # restored at teardown
    monkeypatch.setenv("FX_DATASETS_JSON", os.environ.get("FX_DATASETS_JSON", ""))
    return root


REAL_DEPS = Path(FWD) / "DEPS.json"


def fixture_deps(path: Path) -> Path:
    """A DEPS.json built from the files present in this checkout (DATA's research/common/*.py and downloader, COST's
    two files, the picks), with the real file's commits and notes. Every forward test but one runs on it, so a DATA or
    COST update fails only test_io.py::test_deps_json_matches_the_checkout, the one test of the real pins."""
    import fwd_core as C
    real = json.loads(REAL_DEPS.read_text())
    repo = Path(REPO)
    files = {q.relative_to(repo).as_posix(): C.sha256_file(q) for q in sorted((repo / "research/common").glob("*.py"))}
    for rel in ("research/data/oanda_download.py", "research/data/blocks.py"):     # the downloader and its imports
        if (repo / rel).is_file():
            files[rel] = C.sha256_file(repo / rel)
    cost = {**real["cost"], "files": {rel: C.sha256_file(repo / rel) for rel in real["cost"]["files"]
                                      if (repo / rel).is_file()}}
    picks = {f"picks/{q.name}": C.sha256_file(q) for q in sorted((Path(FWD) / "picks").glob("*.json"))}
    path.write_text(json.dumps({**real, "files": files, "cost": cost, "picks": picks,
                                "fixture": "built by tests/conftest.py from the files present"}, indent=1))
    return path


@pytest.fixture(scope="session", autouse=True)
def deps_from_the_checkout(tmp_path_factory):
    if not HAVE_COMMON:
        yield None
        return
    import fwd_core as C
    import fwd_cost
    mp = pytest.MonkeyPatch()
    path = fixture_deps(tmp_path_factory.mktemp("deps") / "DEPS.json")
    mp.setattr(C, "DEPS", path)
    mp.setattr(fwd_cost, "DEPS", path)
    yield path
    mp.undo()


REAL_FETCH_LOG = Path(STATS) / "FETCH_LOG.jsonl"


def _stamp(p: Path):
    """(size, mtime_ns) of a file, or None: enough to see a write, without reading it."""
    try:
        st = os.stat(p)
    except FileNotFoundError:
        return None
    return st.st_size, st.st_mtime_ns


@pytest.fixture(scope="session", autouse=True)
def _real_fetch_log_untouched():
    """No test writes STATS's real FETCH_LOG.jsonl (a fake 403 must never land in the department's log)."""
    before = _stamp(REAL_FETCH_LOG)
    yield
    assert _stamp(REAL_FETCH_LOG) == before, f"a test wrote to {REAL_FETCH_LOG}"


@pytest.fixture(autouse=True)
def _temporary_fetch_log(tmp_path, monkeypatch):
    """DATA's Fetcher writes a 403, 407 or 429 to fwd_io.FETCH_LOG (STATS's FETCH_LOG); in a test it is a temporary
    file (data_code puts it in its temporary checkout, where DATA's check_block_log wants it)."""
    if not HAVE_COMMON:
        return
    import fwd_io as IO
    monkeypatch.setattr(IO, "FETCH_LOG", tmp_path / "FETCH_LOG.jsonl")


@pytest.fixture(autouse=True)
def _git_points_at_its_checkout(monkeypatch):
    """Every test runs with the git variables that would point git at another repository or work tree removed
    (fwd_core.GIT_ENV_DROP: an exported GIT_DIR, as a git hook or a gate may set, made `git init`, clones and fetches
    in the temporary repositories act on the outer checkout). Tests that check the runner without them set them."""
    if not HAVE_COMMON:
        return
    import fwd_core as C
    for k in C.GIT_ENV_DROP:
        monkeypatch.delenv(k, raising=False)


@pytest.fixture(autouse=True)
def _forward_numbers_test_only(monkeypatch):
    """forward_table, forward_verdict and forward_verdicts refuse outside a test until the forward judge exists
    (fwd_core.forward_look). Tests reach them through fwd_core._TEST_ONLY_LOOKS, a list of the looks taken (it counts
    only when the main program is pytest); test_rt3.py proves that production cannot."""
    if not HAVE_COMMON:
        return
    import fwd_core as C
    monkeypatch.setattr(C, "_TEST_ONLY_LOOKS", [])

