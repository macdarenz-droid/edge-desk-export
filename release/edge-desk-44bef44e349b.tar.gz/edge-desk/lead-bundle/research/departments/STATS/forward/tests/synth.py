"""Synthetic bars and a synthetic calendar for the forward runner's tests. Every date and price here is made up for
the tests; none is a claim about a real meeting or a real price.

Bars: every minute from 17:00 New York Sunday to 17:00 New York Friday; flat bars (o = h = l = c = mid), spread
0.8 pip. Each New York day the mid is +20 pips from 20:00 to 21:00 New York and -20 pips from 08:00 to 09:00
New York, so every daily true range is 40 pips and ATR20 = 40 pips. Bumps add known moves inside the trades.
"""
from __future__ import annotations

import json
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

NY = ZoneInfo("America/New_York")
PIP = 1e-4
BASE = 1.10000
HALF = 0.4 * PIP


def ny(d: str, hhmm: str) -> int:
    h, m = map(int, hhmm.split(":"))
    return int(datetime.combine(date.fromisoformat(d), time(h, m), NY).timestamp())


def utc(s: str) -> int:
    return int(datetime.fromisoformat(s).replace(tzinfo=timezone.utc).timestamp())


# (from_ts, to_ts, pips): mid += pips on bars with from_ts <= ts < to_ts
BUMPS = [
    (ny("2026-10-20", "15:00"), ny("2026-10-20", "16:00"), 100.0),   # R53: target hit at 15:00 New York
    (utc("2026-10-22T06:00:00"), utc("2026-10-22T12:30:00"), 50.0),  # PA-F4: +50 before the exit
    (utc("2026-11-04T00:00:00"), utc("2026-11-12T00:00:00"), 60.0),  # FC-1: first trade +60
    (ny("2026-10-08", "15:00"), ny("2026-10-08", "15:30"), 100.0),   # guard case: a pre-forward R53 target
]


def mid_at(ts: np.ndarray) -> np.ndarray:
    t = pd.to_datetime(ts, unit="s", utc=True).tz_convert(NY)
    m = ((t.hour - 17) % 24) * 60 + t.minute                 # minutes since 17:00 New York
    m = np.asarray(m)
    mid = np.full(len(ts), BASE)
    mid += np.where((m >= 180) & (m < 240), 20 * PIP, 0.0)
    mid += np.where((m >= 900) & (m < 960), -20 * PIP, 0.0)
    for a, b, p in BUMPS:
        mid += np.where((ts >= a) & (ts < b), p * PIP, 0.0)
    return mid


def bars(first: int, last_excl: int) -> dict:
    ts = np.arange(first - first % 60, last_excl, 60, dtype=np.int64)
    t = pd.to_datetime(ts, unit="s", utc=True).tz_convert(NY)
    wd, hr = np.asarray(t.weekday), np.asarray(t.hour)
    open_ = ~((wd == 5) | ((wd == 4) & (hr >= 17)) | ((wd == 6) & (hr < 17)))
    ts = ts[open_]
    mid = mid_at(ts)
    out = {"ts_utc": ts}
    for s, sgn in (("bid", -1), ("ask", 1)):
        for k in "ohlc":
            out[f"{s}_{k}"] = mid + sgn * HALF
    out["volume"] = np.ones(len(ts), dtype=np.int64)
    return out


CAL_ROWS = [  # synthetic: (type, utc)
    ("FOMC_STATEMENT", "2026-09-16T18:00:00Z"),
    ("FOMC_STATEMENT", "2026-10-09T18:00:00Z"),   # guard case: its R53 decision (8 Oct 14:00 New York) is pre-forward
    ("FOMC_STATEMENT", "2026-10-21T18:00:00Z"),
    ("FOMC_STATEMENT", "2026-12-02T19:00:00Z"),
    ("FOMC_STATEMENT", "2027-01-27T19:00:00Z"),
    ("ECB_DECISION", "2026-10-22T12:15:00Z"),
    ("ECB_DECISION", "2026-12-10T13:15:00Z"),
]
RUN_DAY = "2026-12-07"                            # the default run: every pick has settled trades by then


def held_by(run_day: str) -> int:
    """Rows before this second are 'held' (their source read an hour after the event): the run day's close."""
    return ny(run_day, "17:00")


def write_calendar(d: Path, rows=CAL_ROWS, covers=("2026-09-01", "2026-12-31"), run_day: str = RUN_DAY,
                   overrides: dict | None = None, meta_extra: dict | None = None) -> tuple:
    """A sourced synthetic calendar. Events before the run day's close are held (source read 1 hour after), later
    ones scheduled. overrides: {(type, utc): {column: value}} to make a row cancelled, moved or late-sourced."""
    import hashlib
    recs, cut = [], held_by(run_day)
    for ty, u in rows:
        ts = utc(u.rstrip("Z"))
        tz = "America/New_York" if ty.startswith("FOMC") else "Europe/Berlin"
        lt = datetime.fromtimestamp(ts, ZoneInfo(tz))
        held = ts < cut
        rec = {"event_id": f"{ty}-{lt.date()}", "type": ty, "local_date": lt.date().isoformat(),
               "local_time": lt.strftime("%H:%M"), "tz": tz, "utc": u, "scheduled": 1,
               "status": "held" if held else "scheduled", "source_url": "https://example.invalid/synthetic-test-row",
               "source_note": "synthetic test row",
               "source_read_utc": datetime.fromtimestamp(ts + 3600 if held else utc("2026-09-01T00:00:00"),
                                                         timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
        rec.update((overrides or {}).get((ty, u), {}))
        recs.append(rec)
    d.mkdir(parents=True, exist_ok=True)
    csv = d / "FORWARD_EVENTS.csv"
    pd.DataFrame(recs).to_csv(csv, index=False)
    meta = d / "FORWARD_EVENTS.json"
    meta.write_text(json.dumps({"status": "sourced", "sha256": hashlib.sha256(csv.read_bytes()).hexdigest(),
                                "covers_from": covers[0], "covers_through": covers[1], "sources": ["synthetic"],
                                **(meta_extra or {})}))
    return csv, meta
