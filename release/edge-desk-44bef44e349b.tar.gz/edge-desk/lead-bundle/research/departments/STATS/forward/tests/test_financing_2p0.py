"""PASS_BAR.md v7 section 3, "Financing-sensitive", in the forward log: every side is also priced with COST's financing
at 2.0% a year, the per-day rows carry that series, forward_table(markup="2.0") returns it, and a forward verdict at
2.0% can only mark a pass financing-sensitive. Synthetic bars and calendars; test policy rates, no real ones."""
import json

import pytest

import fwd_core as C
import fwd_cost
import synth as S
from test_io import DAY

RATES = {"USD": 4.0, "EUR": 2.0}                       # a test series, % a year, no range width


def _rates():
    return (lambda ccy, ts: RATES[ccy]), (lambda ccy, ts: (RATES[ccy], RATES[ccy]))


def priced(tmp_path, full: bool):
    """The run's lines priced with COST's model as loaded (no rates: Round 45 financing stands in), or with a complete
    release list and test rates (full: nothing below the pass case)."""
    picks = C.load_picks()
    csv, meta = S.write_calendar(tmp_path / "cal", run_day="2026-12-07")
    cal = C.read_calendar(csv, meta)
    cm = fwd_cost.load(C.REPO, cal)
    if full:
        if not hasattr(cm.mod, "financing_rows"):
            pytest.skip("COST's cost.py in this checkout predates financing_rows")
        cm2 = fwd_cost.CostV3(cm.mod, cm.model, cm.model_sha256,
                              {"ts": cm.release_ts, "types": cm.model["events_types_measured"]},
                              {"release_list_complete_for": cm.model_sha256}, rates=_rates())
        cm2.commit = cm.commit
        cm = cm2
    end = C.label_close_ts(DAY)
    res = C.compute_run(picks, cal, S.bars(C.inputs_start(picks), end), end, "T5", cost=cm, run_day=DAY)
    lines = [l for l in res.lines if l.get("kind") == "trade"]
    assert lines
    return lines, cm


@pytest.mark.parametrize("full", [False, True])
def test_both_pass_cases_price_again_from_the_stored_inputs(tmp_path, full):
    lines, cm = priced(tmp_path, full)
    log = tmp_path / "log.jsonl"
    C.append_log(lines, log)
    for l in C.read_log(log):
        if l.get("kind") != "trade":
            continue
        unit = l["r_pips"] or 1.0
        for side, col in (("long", "pnl_long"), ("short", "pnl_short")):
            again, _ = fwd_cost.price_side(cm, l["recost"][side])
            assert again == l["net"][side]                                 # both pass cases, from the line alone
            assert sum(d[col] for d in l["days"]) == pytest.approx(again["pass_case"] / unit, abs=1e-9)
            assert sum(d[col + "_fin2p0"] for d in l["days"]) == pytest.approx(again["pass_case_fin2p0"] / unit,
                                                                               abs=1e-9)
        assert l["below_pass_case"] is (not full)


def test_pass_case_fin2p0_is_never_above_the_pass_case(tmp_path):
    lines, _ = priced(tmp_path, False)                                    # no rates: Round 45 for both, equal
    for l in lines:
        for side in ("long", "short"):
            n = l["net"][side]
            assert n["financing_v3_2p0_pips"] is None and n["pass_case_fin2p0"] == n["pass_case"]
            assert n["fin2p0_markup_pct_year"] == 2.0
        assert all(d["pnl_long_fin2p0"] == d["pnl_long"] and d["pnl_short_fin2p0"] == d["pnl_short"] for d in l["days"])
    lines, full = priced(tmp_path / "f", True)
    mk = float(full.model["financing"]["markup_pct_year"])
    assert mk < fwd_cost.FIN_SENS_MARKUP == 2.0
    lower = 0
    for l in lines:
        for side in ("long", "short"):
            n, rec = l["net"][side], l["recost"][side]
            assert n["pass_case_fin2p0"] <= n["pass_case"] + 1e-12
            assert n["financing_v3_2p0_pips"] >= n["financing_v3_pips"]
            assert n["pass_case_fin2p0"] == pytest.approx(
                min(n["floor_2p0"], n["cost_v3_ex_financing"] - n["financing_v3_2p0_pips"]), abs=1e-12)
            nights = sum(rec["fin_nights"].values())
            diff = RATES["USD"] - RATES["EUR"] if side == "long" else RATES["EUR"] - RATES["USD"]
            want = nights * abs(rec["mid_entry"]) * (diff + 2.0) / 100 / 365 / 1e-4
            assert n["financing_v3_2p0_pips"] == pytest.approx(want, rel=1e-12, abs=1e-12)
            lower += n["pass_case_fin2p0"] < n["pass_case"] - 1e-12
    assert lower > 0                                                      # positions held overnight pay more at 2.0%
    rec = lines[0]["recost"]["long"]
    with pytest.raises(ValueError, match="pass-case markup"):
        full.fin_v3_at(rec, 1.0)                                          # freezing=True: never below the pass case


def test_a_side_priced_at_one_markup_only_is_below_the_pass_case(tmp_path):
    lines, full = priced(tmp_path, True)
    rec = lines[0]["recost"]["long"]

    class Half(fwd_cost.CostV3):
        def fin_v3_at(self, rec, markup):
            if markup is not None:
                raise ValueError("test: 2.0% refused")
            return super().fin_v3_at(rec, markup)
    half = Half(full.mod, full.model, full.model_sha256, {"ts": full.release_ts, "types": full.model["events_types_measured"]},
                {"release_list_complete_for": full.model_sha256}, rates=_rates())
    n, why = fwd_cost.price_side(half, rec)
    assert any("at 2.0% refused" in w for w in why) and n["pass_case_fin2p0"] == n["pass_case"]


def test_forward_table_at_2p0_differs_from_the_pass_case_only_by_financing(tmp_path):
    lines, _ = priced(tmp_path, True)
    log = tmp_path / "log.jsonl"
    C.append_log(lines, log)
    by_id = {l["position_id"]: l for l in lines}
    some_lower = False
    for pid in sorted({l["pick_id"] for l in lines}):
        t, t2 = C.forward_table(pid, log), C.forward_table(pid, log, markup="2.0")
        assert len(t) == len(t2) > 0 and list(t.columns) == list(t2.columns)
        for c in ("position_id", "pair", "day", "decision_ts", "w"):
            assert t[c].tolist() == t2[c].tolist()
        for c in ("pnl_long", "pnl_short"):
            assert (t2[c] <= t[c] + 1e-12).all()
        for pos, g in t.groupby("position_id", sort=False):
            g2 = t2[t2["position_id"] == pos]
            l = by_id[pos]
            unit = l["r_pips"] or 1.0
            for side, c in (("long", "pnl_long"), ("short", "pnl_short")):
                n = l["net"][side]
                d = g2[c].to_numpy() - g[c].to_numpy()
                assert d.sum() == pytest.approx((n["pass_case_fin2p0"] - n["pass_case"]) / unit, abs=1e-9)
                assert (d[1:] == 0).all()                                 # the extra financing sits on the first label
                some_lower |= bool(d[0] < 0)
    assert some_lower
    with pytest.raises(ValueError, match="'pass' or '2.0'"):
        C.forward_table(lines[0]["pick_id"], log, markup="1.0")


def test_forward_table_refuses_a_line_without_the_2p0_series(tmp_path):
    lines, _ = priced(tmp_path, True)
    old = json.loads(json.dumps(lines[0]))
    for d in old["days"]:
        del d["pnl_long_fin2p0"], d["pnl_short_fin2p0"]
    log = tmp_path / "log.jsonl"
    C.append_log([old], log)
    assert len(C.forward_table(old["pick_id"], log)) == len(old["days"])  # the pass case still reads
    with pytest.raises(C.Refused, match="pnl_long_fin2p0"):
        C.forward_table(old["pick_id"], log, markup="2.0")


def test_without_rates_the_2p0_table_equals_the_pass_case(tmp_path):
    lines, _ = priced(tmp_path, False)
    log = tmp_path / "log.jsonl"
    C.append_log(lines, log)
    for pid in sorted({l["pick_id"] for l in lines}):
        t = C.forward_table(pid, log, allow_below_pass_case=True)
        assert t.equals(C.forward_table(pid, log, allow_below_pass_case=True, markup="2.0"))
        with pytest.raises(C.BelowPassCase):
            C.forward_table(pid, log, markup="2.0")                        # still below the pass case


# ------------------------------------------------------------------ the forward verdict at both

OK = {"net_total": 3.0, "p_net": 0.001, "p_random_side": 0.002, "p_same_tilt": 0.003, "p_shift": 0.004, "block": 7}


@pytest.mark.parametrize("bad", [{"net_total": 0.0}, {"net_total": -1.0}, {"p_net": 0.5}, {"p_random_side": 0.03},
                                 {"p_same_tilt": 0.9}, {"p_shift": None}])
def test_a_forward_pass_failing_at_2p0_is_pass_and_financing_sensitive(bad):
    v = C.forward_verdicts(OK, {**OK, **bad}, 0.025)
    assert v["verdict"] == "PASS" and v["verdict_at_2p0"] == "FAIL"
    assert v["financing_sensitive"] is True and v["mark"] == "financing-sensitive"


def test_a_forward_pass_holding_at_2p0_is_not_marked():
    v = C.forward_verdicts(OK, {**OK, "net_total": 0.5}, 0.025)
    assert v["verdict"] == "PASS" and v["financing_sensitive"] is False and v["mark"] is None


@pytest.mark.parametrize("fin2", [OK, {**OK, "net_total": -1.0}])
def test_a_forward_fail_stays_fail_whatever_the_2p0_row_says(fin2):
    v = C.forward_verdicts({**OK, "p_shift": 0.2}, fin2, 0.025)
    assert v["verdict"] == "FAIL" and v["financing_sensitive"] is False and v["mark"] is None


def test_the_2p0_forward_verdict_uses_the_same_block():
    with pytest.raises(ValueError, match="block"):
        C.forward_verdicts(OK, {**OK, "block": 8}, 0.025)
