"""The forward guard: no outcome for a bar before FORWARD_START (docs/EDGE_HUNT.md section 3). Each guard layer has a
test that fails if that layer is removed; the last two show the synthetic data really holds pre-forward trades."""
from datetime import date, timedelta

import numpy as np
import pytest

import fwd_core as C
import synth as S

FS = C.FORWARD_START
END = C.label_close_ts(date(2026, 11, 25))


@pytest.fixture(scope="module")
def world(tmp_path_factory):
    picks = C.load_picks()
    C.verify_pins(picks)
    csv, meta = S.write_calendar(tmp_path_factory.mktemp("cal"), run_day="2026-11-25")
    cal = C.read_calendar(csv, meta, run_day=date(2026, 11, 25))
    start = C.inputs_start(picks)
    return picks, cal, S.bars(start, END), start


def test_forward_start_is_the_documented_second():
    assert FS == 1791493200
    assert C.label_of(FS) == "2026-10-09" and C.label_of(FS - 1) == "2026-10-08"


def test_outcome_bars_drop_every_pre_forward_row():
    m = S.bars(FS - 3 * 86400, FS + 2 * 86400)
    out = C.outcome_bars(m)
    assert len(out["ts_utc"]) == int((m["ts_utc"] >= FS).sum()) > 0
    assert int(out["ts_utc"].min()) >= FS
    assert all(len(v) == len(out["ts_utc"]) for v in out.values())


@pytest.mark.parametrize("key", ["decision_ts", "entry_ts", "exit_ts"])
def test_check_trade_refuses_a_pre_forward_time(key):
    tr = {"decision_ts": FS + 60, "entry_ts": FS + 120, "exit_ts": FS + 600}
    C.check_trade(tr)
    tr[key] = FS - 60
    with pytest.raises(C.OutcomeGuardError):
        C.check_trade(tr)


def test_check_decision():
    C.check_decision(FS)
    with pytest.raises(C.OutcomeGuardError):
        C.check_decision(FS - 1)


def test_lagged_inputs_at_most_400_days(world):
    picks, _, _, start = world
    assert start == S.ny("2026-09-03", "17:00")                    # 35 days of lookback, a 17:00 New York edge
    assert C.era_string(start) == "HOLDOUT+FORWARD"
    C.check_inputs_start(FS - 400 * 86400)
    with pytest.raises(C.OutcomeGuardError):
        C.check_inputs_start(FS - 400 * 86400 - 1)
    with pytest.raises(C.OutcomeGuardError):
        C.inputs_start([{"lookback_days": 401}])


def test_simulate_floor_refuses_pre_forward_decisions_on_a_full_world(world):
    """On a world that still holds the lagged bars (outcome_bars skipped) and a window from 4 Sep, the floor alone
    keeps every decision before the forward start out (the FC-1 trade of 28 Sep and the R53 trade of 8 Oct)."""
    picks, cal, m1, _ = world
    fz = C.frozen(picks)
    rows = C.calendar_rows(cal)
    w = fz.E.World(m1, {}, C.events_frame(rows), fz.E.r45.daily_bars(m1), END)
    for p in picks:
        trades, plan = C.simulate(fz, p, w, rows, C.ERA, date(2026, 9, 4), date(2026, 11, 25), FS)
        assert all(t >= FS for t, _ in plan)
        assert all(x["decision_ts"] >= FS for x in trades)


def test_the_synthetic_data_holds_pre_forward_trades(world):
    """Sanity: without the guard the frozen code WOULD trade before the forward start on these bars, so the guard
    tests above test something real."""
    picks, cal, m1, _ = world
    fz = C.frozen(picks)
    rows = C.calendar_rows(cal)
    w = fz.E.World(m1, {}, C.events_frame(rows), fz.E.r45.daily_bars(m1), END)
    pre = fz.r53.trade(w, S.utc("2026-10-09T18:00:00"), "S3", "X3")     # decided 8 Oct 14:00 New York
    assert pre is not None and pre["entry_ts"] < FS and pre["why"] == "target"
    fc = next(p for p in picks if p["id"] == "FC-1")
    with C.lent_era(fz.E, "EARLY", date(2026, 9, 4), date(2026, 11, 25), END):
        early = fz.E.run_cell(w, C.make_cell(fz, fc, rows), "EARLY")
    assert any(x["entry_ts"] < FS for x in early)


def test_compute_logs_nothing_before_the_forward_start(world):
    picks, cal, m1, _ = world
    lines = C.compute(picks, cal, m1, END, "TEST")
    assert lines and all(l["kind"] == "trade" for l in lines)
    for l in lines:
        assert min(l["decision_ts"], l["entry_ts"], l["exit_ts"]) >= FS
        assert min(d["day"] for d in l["days"]) >= "2026-10-09"
