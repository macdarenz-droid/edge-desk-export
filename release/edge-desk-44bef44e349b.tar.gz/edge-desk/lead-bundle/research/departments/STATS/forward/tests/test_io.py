"""Request budget and spacing, the DATA lock, the order of a run (ledger line pushed before any download), the DEPS.json
pins on DATA's code in this checkout, and DATA's downloader and loaders on a fake HTTP layer. No test touches the
network."""
import json
import os
import subprocess
import sys
import types
from datetime import date, datetime, timezone
from pathlib import Path

import numpy as np
import pytest
import requests

import fwd_core as C
import fwd_cost
import fwd_io as IO
import fwd_register as REG
import run_forward as RF
import synth as S

URL = "https://api-fxpractice.oanda.com/v3/instruments/EUR_USD/candles"


# ------------------------------------------------------------------ budget and spacing

class Inner:
    headers = {}

    def __init__(self):
        self.calls = []

    def get(self, url, **kw):
        self.calls.append(url)
        return "ok"


class Clock:
    def __init__(self, t):
        self.t, self.slept = t, []

    def __call__(self):
        return self.t

    def sleep(self, s):
        self.slept.append(s)
        self.t += s


def session(tmp_path, clock, inner=None, **kw):
    return IO.BudgetSession(inner or Inner(), tmp_path / "REQUESTS.json", clock=clock, sleep=clock.sleep, **kw)


def test_thirty_a_day_then_refused_before_sending(tmp_path):
    clk = Clock(S.utc("2026-10-20T10:00:00"))
    inner = Inner()
    s = session(tmp_path, clk, inner)
    for _ in range(30):
        s.get(URL)
    with pytest.raises(IO.BudgetExceeded):
        s.get(URL)
    assert len(inner.calls) == 30 and s.remaining() == 0


def test_budget_persists_across_runs_and_resets_next_utc_day(tmp_path):
    clk = Clock(S.utc("2026-10-20T10:00:00"))
    for _ in range(3):
        s = session(tmp_path, clk)
        for _ in range(10):
            s.get(URL)
    with pytest.raises(IO.BudgetExceeded):
        session(tmp_path, clk).get(URL)
    clk.t = S.utc("2026-10-21T00:00:01")
    assert session(tmp_path, clk).remaining() == 30


def test_requests_at_least_five_seconds_apart(tmp_path):
    clk = Clock(S.utc("2026-10-20T10:00:00"))
    sent = []

    class Rec(Inner):
        def get(self, url, **kw):
            sent.append(clk.t)

    s = session(tmp_path, clk, Rec())
    for _ in range(6):
        clk.t += 1.0                                    # the caller asks again after only 1 second
        s.get(URL)
    assert min(np.diff(sent)) >= 5.0
    s2 = session(tmp_path, clk, Rec())                   # a second run straight after keeps the spacing
    s2.get(URL)
    assert sent[-1] - sent[-2] >= 5.0


@pytest.mark.parametrize("url", ["https://api-fxpractice.oanda.com/v3/accounts", URL.replace("EUR_USD", "GBP_USD"),
                                 "https://api-fxtrade.oanda.com/v3/instruments/EUR_USD/candles",
                                 "https://api-fxpractice.oanda.com/v3/accounts/x/orders"])
def test_only_eur_usd_candles(tmp_path, url):
    inner = Inner()
    with pytest.raises(IO.Refused):
        session(tmp_path, Clock(0.0), inner).get(url)
    assert not inner.calls


# ------------------------------------------------------------------ the DATA lock

class FakeGit:
    def __init__(self, data_status=None, fetch_ok=True, stats_access="", fetch_logs=None):
        self.data_status, self.fetch_ok, self.stats_access = data_status, fetch_ok, stats_access
        self.fetch_logs = dict(fetch_logs or {})          # {(branch, rel): text} of pushed FETCH_LOG copies
        self.log = []

    def fetch(self, branch):
        self.log.append(("fetch", branch))
        return self.fetch_ok

    def remote_heads(self, prefix):
        return sorted({b for b, _ in self.fetch_logs if b.startswith(prefix)})

    def ls_tree(self, ref, path):
        return sorted(rel for b, rel in self.fetch_logs if f"origin/{b}" == ref and rel.startswith(path))

    def show(self, ref, path):
        self.log.append(("show", ref, path))
        for (b, rel), text in self.fetch_logs.items():
            if ref == f"origin/{b}" and path == rel:
                return text
        if path == IO.DATA_STATUS:
            return self.data_status
        if path.endswith("ACCESS_LOG.jsonl") and ref == f"origin/{IO.BRANCH}":
            return self.stats_access
        return None


@pytest.mark.parametrize("status,fetch_ok,free", [
    ('{"oanda_job": null}', True, True),
    ('{"oanda_job": {"what": "H1 12 pairs", "started_utc": "2026-10-13T12:32:50Z"}}', True, False),
    ('{"phase": "x"}', True, False),                     # no oanda_job key: busy
    ("not json", True, False),
    (None, True, False),                                 # no STATUS.json on the branch
    ('{"oanda_job": null}', False, False),               # cannot fetch: cannot verify
])
def test_data_lock(status, fetch_ok, free):
    assert IO.data_lock_free(FakeGit(status, fetch_ok)) is free


# ------------------------------------------------------------------ the order of a run

class FakeOps:
    def __init__(self, tmp_path, lock=(True, True), push=True, stats_free=True, gate_error=None, locked_push=True,
                 log=None, cost=None, discarded=0, download_error=None, ruling=None, start_seen="auto"):
        self.calls, self.lock, self.push, self.tmp = [], list(lock), push, tmp_path
        self.access_rows, self.job, self.stats_free, self.gate_error = [], "unset", stats_free, gate_error
        self.locked_push, self.cost, self.downloads, self.published = locked_push, cost, [], []
        self.log = log or tmp_path / "locked_wt" / IO.LOCKED_LOG_REL
        self.discarded, self.download_error, self.ruling = discarded, download_error, ruling
        self.start_seen = start_seen          # what origin shows after the start push: "pushed", "absent" or None

    def gate(self):
        self.calls.append("gate")
        if self.gate_error:
            raise self.gate_error
        return {"head": "0" * 40, "tree_sha256": "a" * 64, "calendar_sha256": "c" * 64}

    def worktree(self, allow=(), **kw):
        self.calls.append("worktree")
        self.allowed = tuple(allow)
        return "0" * 40

    def leftovers(self, rels):
        self.calls.append("leftovers")
        return {r: list(getattr(self, "left", {}).get(r, [])) for r in rels}

    def blocks(self):
        self.calls.append("blocks")
        if getattr(self, "blocks_error", None):
            raise self.blocks_error
        return "no block"

    def stats_lock_free(self):
        self.calls.append("stats_lock")
        return self.stats_free

    def lock_free(self):
        self.calls.append("lock")
        return self.lock.pop(0) if self.lock else True

    def cost_model(self, cal):
        self.calls.append("cost")
        return self.cost(cal) if self.cost else None

    def locked_open(self):
        self.calls.append("locked_open")
        return self.log

    def locked_publish(self, msg):
        self.calls.append("locked_publish")
        return self.locked_push, "b" * 40

    def locked_discarded(self):
        return self.discarded

    def start_state(self, lid):
        self.calls.append("start_state")
        if self.start_seen == "auto":
            return "pushed" if self.push else "absent"
        return self.start_seen

    def discard_start(self, paths):
        self.calls.append("discard_start")
        self.job = None                        # back to origin's STATUS: the lock was never published
        return True

    def calendar_ruling(self, from_sha, to_sha):
        self.calls.append("ruling")
        return self.ruling

    def access(self, row):
        IO.check_access_row(row)
        self.calls.append(f"access:{row['kind']}:{row['status']}")
        self.access_rows.append(row)

    def set_job(self, job):
        self.calls.append("job:set" if job else "job:clear")
        self.job = job

    def publish(self, paths, msg, rebuild=False, now=None):
        self.calls.append("publish")
        self.published.append([str(p) for p in paths])
        self.rebuilds = getattr(self, "rebuilds", []) + [rebuild]
        return self.push.pop(0) if isinstance(self.push, list) else self.push

    def download(self, lid, start, end, meter):
        self.calls.append("download")
        self.downloads.append((start, end))
        assert any(r["ledger_id"] == lid and r["kind"] == "forward_run_start" for r in self.access_rows)
        meter.update(requests=3, requests_by_utc_day={"2026-12-08": 2, "2026-12-09": 1})
        if self.download_error:
            raise self.download_error
        return {"path": self.tmp / "x.csv", "covered_to": end, "requests": 3,
                "requests_by_utc_day": dict(meter["requests_by_utc_day"])}

    def load(self, lid, start, end, path):
        self.calls.append("load")
        return S.bars(start, end)

    def carry_blocks(self):
        self.calls.append("carry_blocks")
        return 0


@pytest.fixture
def sandbox(tmp_path, monkeypatch):
    csv, meta = S.write_calendar(tmp_path / "cal", run_day="2026-12-07")
    monkeypatch.setattr(C, "CAL_CSV", csv)
    monkeypatch.setattr(C, "CAL_META", meta)
    return tmp_path


DAY = date(2026, 12, 7)
NOW = S.utc("2026-12-08T12:00:00")
ORDER = ["gate", "stats_lock", "lock", "blocks", "cost", "locked_open", "access:forward_run_start:started", "job:set", "publish",
         "start_state", "lock", "download", "load", "locked_publish", "access:forward_run_done:done", "job:clear",
         "carry_blocks", "publish"]
PNL = ("net", "pnl", "days", "fill", "entry", "exit", "stop", "target", "gross", "move", "ret", "_r")


def test_run_order_ledger_pushed_before_download(sandbox):
    ops = FakeOps(sandbox)
    r = RF.run(DAY, ops, now=NOW)
    assert ops.calls == ORDER
    log = C.read_log(ops.log)
    assert r["new_lines"] == 5 and sum(1 for l in log if l["kind"] == "trade") == 5 and ops.job is None
    assert log[-1]["kind"] == "run_state" and set(log[-1]["next_floor"]) == {"R53-S3X3", "PA-F4", "FC-1"}
    start = ops.access_rows[0]
    assert start["override"] == "forward_inputs" and start["era"] == "HOLDOUT+FORWARD"
    assert start["outcomes_from_ts"] == C.FORWARD_START and start["budget"] == {"max_requests_per_day": 30,
                                                                               "min_gap_s": 5.0}
    assert start["tree_sha256"] == "a" * 64 and ops.access_rows[-1]["locked_commit"] == "b" * 40
    assert ops.access_rows[-1]["requests_by_utc_day"] == {"2026-12-08": 2, "2026-12-09": 1}
    assert start["calendar_sha256"] == "c" * 64 and start["locked_leftovers_discarded"] is False
    for row in ops.access_rows:                           # no forward number in the (mergeable) access log
        assert set(row) <= IO.ACCESS_KEYS
        assert not [k for k in row if any(w in k.lower() for w in PNL) and k not in ("first_ts", "last_ts")]
    for paths in ops.published:                           # only ACCESS_LOG, STATUS and STATS's FETCH_LOG go to dept/stats
        assert paths == [str(IO.ACCESS_LOG), str(IO.STATS_STATUS), str(IO.FETCH_LOG)]


def test_stats_own_lock_refused_before_anything(sandbox):
    ops = FakeOps(sandbox, stats_free=False)
    with pytest.raises(IO.Refused, match="STATS's oanda_job"):
        RF.run(DAY, ops, now=NOW)
    assert ops.calls == ["gate", "stats_lock"]


def test_gate_refusal_reads_and_writes_nothing(sandbox):
    ops = FakeOps(sandbox, gate_error=IO.Refused("forward tree sha256 x is not approved"))
    with pytest.raises(IO.Refused, match="not approved"):
        RF.run(DAY, ops, now=NOW)
    assert ops.calls == ["gate"]


def test_lock_refusal_reads_nothing(sandbox):
    ops = FakeOps(sandbox, lock=(False,))
    with pytest.raises(IO.Refused, match="oanda_job"):
        RF.run(DAY, ops, now=NOW)
    assert ops.calls == ["gate", "stats_lock", "lock"]


def test_push_failure_means_no_download(sandbox):
    """Red team 3, item 13: a failed start push that origin confirms did not land drops the local start commit (no
    later push can carry it, no closing line is pushed); nothing is downloaded or read."""
    ops = FakeOps(sandbox, push=False)
    with pytest.raises(IO.Refused, match="could not be pushed"):
        RF.run(DAY, ops, now=NOW)
    assert ops.calls[-4:] == ["job:set", "publish", "start_state", "discard_start"]
    assert "download" not in ops.calls and ops.job is None and ops.published == [ops.published[0]]


def test_data_job_started_after_our_push_stops_before_download(sandbox):
    ops = FakeOps(sandbox, lock=(True, False))
    with pytest.raises(IO.Refused, match="DATA started"):
        RF.run(DAY, ops, now=NOW)
    assert "download" not in ops.calls and ops.calls[-4:] == ["access:forward_run_done:failed: Refused",
                                                              "job:clear", "carry_blocks", "publish"]


def test_locked_push_failure_is_the_runs_status(sandbox):
    ops = FakeOps(sandbox, locked_push=False)
    r = RF.run(DAY, ops, now=NOW)
    assert r["status"] == "failed: locked push" and ops.access_rows[-1]["status"] == "failed: locked push"


def test_second_run_downloads_only_from_the_saved_floors(sandbox):
    """Item 5: the second run starts its download at the earliest unsettled decision less 35 days, read from the
    locked log's run_state line, not at 3 Sep 2026 again."""
    ops = FakeOps(sandbox)
    RF.run(DAY, ops, now=NOW)
    picks = C.load_picks()
    floors = C.floors_from_log(C.read_log(ops.log), picks)
    ops2 = FakeOps(sandbox, log=ops.log)
    RF.run(DAY, ops2, now=NOW)
    first, second = ops.downloads[0][0], ops2.downloads[0][0]
    assert first == S.ny("2026-09-03", "17:00") and second == C.inputs_start(picks, floors) > first
    assert min(floors.values()) > C.FORWARD_START
    assert ops2.access_rows[0]["first_ts"] == second and ops2.access_rows[0]["era"] == "FORWARD"


def test_unclosed_or_pre_forward_day_and_unsourced_calendar_refused(sandbox, monkeypatch):
    with pytest.raises(IO.Refused, match="not closed"):
        RF.run(date(2026, 12, 8), FakeOps(sandbox), now=NOW)
    with pytest.raises(IO.Refused, match="before the forward start"):
        RF.run(date(2026, 10, 8), FakeOps(sandbox), now=NOW)
    csv, meta = S.write_calendar(sandbox / "unsourced", run_day="2026-12-07",
                                 meta_extra={"status": "needs_source"})                # a pin not yet sourced
    monkeypatch.setattr(C, "CAL_CSV", csv)
    monkeypatch.setattr(C, "CAL_META", meta)
    ops = FakeOps(sandbox)
    with pytest.raises(C.CalendarError, match="needs a source"):
        RF.run(DAY, ops, now=NOW)
    assert ops.calls == []


def test_repo_calendar_is_datas_published_file():
    """The repo calendar is DATA's FORWARD_EVENTS.csv at DATA commit a23f65c0 (release 3), byte for byte, with a sourced pin
    naming that commit and path (red team 4: the rows come only from DATA's published file)."""
    meta = json.loads((C.HERE / "calendars" / "FORWARD_EVENTS.json").read_text())
    assert meta["status"] == "sourced" and meta["covers_from"] == "2026-09-16" and meta["covers_through"] == "2027-12-31"
    assert meta["source"]["data_commit"] == "a23f65c013d5ee79049548e38f90912e54e663fd"
    assert meta["source"]["path"] == "research/departments/DATA/forward/FORWARD_EVENTS.csv"
    assert meta["sha256"] == C.sha256_file(C.HERE / "calendars" / "FORWARD_EVENTS.csv")
    assert meta["release_list_complete_for"] is None
    assert "round17/data/events.csv" in meta["rules"] and "Never" in meta["rules"]
    data = IO.Git(C.REPO).show_bytes(meta["source"]["data_commit"], meta["source"]["path"])
    assert data is not None, "DATA's commit a23f65c0 is not in this repository: git fetch origin dept/data"
    assert data == (C.HERE / "calendars" / "FORWARD_EVENTS.csv").read_bytes()


def test_ledger_ids_are_fresh_and_accepted_by_the_downloader_pattern():
    a, b = RF.new_ledger_id(), RF.new_ledger_id()
    assert a != b and a.startswith("STATS-FWD-") and len(a) <= 64


# ------------------------------------------------------------------ DEPS.json: DATA's code in this checkout

def fake_checkout(tmp_path):
    repo = tmp_path / "co"
    files = {"research/common/__init__.py": "", "research/common/loaders.py": "x = 1\n",
             "research/data/oanda_download.py": "y = 2\n"}
    for rel, text in files.items():
        (repo / rel).parent.mkdir(parents=True, exist_ok=True)
        (repo / rel).write_text(text)
    deps = tmp_path / "DEPS.json"
    deps.write_text(json.dumps({"data_commit": "c0ffee", "files": {r: C.sha256_file(repo / r) for r in files}}))
    return repo, deps


def test_deps_refuse_a_changed_extra_or_missing_file(tmp_path):
    repo, deps = fake_checkout(tmp_path)
    assert IO.check_deps(deps, repo)["data_commit"] == "c0ffee"
    (repo / "research/common/sneak.py").write_text("")             # an unpinned shared module
    with pytest.raises(C.PinError, match="unpinned"):
        IO.check_deps(deps, repo)
    (repo / "research/common/sneak.py").unlink()
    (repo / "research/data/oanda_download.py").write_text("y = 3\n")
    with pytest.raises(C.PinError, match="oanda_download.py"):
        IO.check_deps(deps, repo)
    (repo / "research/data/oanda_download.py").unlink()
    with pytest.raises(IO.Refused, match="not in this checkout"):
        IO.check_deps(deps, repo)


def test_deps_json_matches_the_checkout():
    """THE test of the real pins: forward/DEPS.json against the checked-out files (DATA's research/common and
    downloader, COST's cost.py and model, the picks). Every other forward test runs on a fixture DEPS built from the
    files present (conftest.py), so a DATA or COST update that is not yet re-pinned fails here, and only here."""
    REAL_DEPS = C.HERE / "DEPS.json"          # the real pins (not via conftest: module names clash across test folders)
    d = json.loads(REAL_DEPS.read_text())
    assert len(d["data_commit"]) == 40 and len(d["cost"]["cost_commit"]) == 40
    assert "research/common/loaders.py" in d["files"] and "research/common/files.py" in d["files"]
    assert "research/common/audit.py" in d["files"] and "research/common/macro.py" in d["files"]   # DATA's audit fix
    assert "research/data/oanda_download.py" in d["files"] and "research/data/blocks.py" in d["files"]
    assert all(r.startswith("research/common/") or r in ("research/data/oanda_download.py", "research/data/blocks.py")
               for r in d["files"])
    assert set(d["cost"]["files"]) == {"research/departments/COST/cost.py", "research/departments/COST/COST_MODEL.json"}
    C.check_data_deps(REAL_DEPS, C.REPO)
    fwd_cost.check(C.REPO, REAL_DEPS)
    C.verify_pick_pins(C.PICKS_DIR, REAL_DEPS)


# ------------------------------------------------------------------ DATA's downloader and loaders, from this checkout

OPEN_LID = "STATS-FWD-20261126T000000Z-abc123"       # the open forward run of the downloader tests


def _git(cwd, *a):
    r = subprocess.run(["git", "-C", str(cwd), "-c", "user.name=t", "-c", "user.email=t@t", "-c", "commit.gpgsign=false",
                        *a], capture_output=True, text=True, env=C.git_env())
    assert r.returncode == 0, r.stderr
    return r.stdout


class StatsOrigin:
    """The runner's checkout as it runs: a linked worktree (`.git` is a file) of a clone on dept/stats, detached at
    origin/dept/stats, with a temporary bare origin (no network): the pushed STATS ledgers that DATA's Fetcher and the
    loaders' 'forward_inputs' read check (research.common.loaders.open_run_kind: a pushed start line, no closing
    line). Every git call is `git -C <checkout>`; nothing assumes `<checkout>/.git` is a directory."""

    def __init__(self, tmp, branches=()):
        self.origin, self.main, self.work = tmp / "origin.git", tmp / "main", tmp / "work"
        _git(tmp.parent, "init", "-q", "--bare", str(self.origin))
        _git(tmp.parent, "clone", "-q", str(self.origin), str(self.main))
        _git(self.main, "checkout", "-q", "-b", IO.BRANCH)
        _git(self.main, "commit", "-q", "--allow-empty", "-m", "dept/stats root")
        _git(self.main, "push", "-q", "origin", f"HEAD:refs/heads/{IO.BRANCH}")
        _git(self.main, "push", "-q", "origin", f"HEAD:refs/heads/{IO.COORD_BRANCH}")   # read for its FETCH_LOGs
        for b in branches:                     # e.g. DATA's blocks.REQUIRED_BRANCHES (its pushed-logs check)
            if b not in (IO.BRANCH, IO.COORD_BRANCH):
                _git(self.main, "push", "-q", "origin", f"HEAD:refs/heads/{b}")
        _git(self.main, "fetch", "-q", "origin")
        _git(self.main, "worktree", "add", "-q", "--detach", str(self.work), f"origin/{IO.BRANCH}")
        assert (self.work / ".git").is_file()                       # a linked worktree, as the runner's

    def push(self, rel, *rows):
        p = self.work / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "a") as fh:
            for r in rows:
                fh.write(json.dumps(r) + "\n")
        _git(self.work, "add", "-A")
        _git(self.work, "commit", "-q", "-m", "ledger line")
        _git(self.work, "push", "-q", "origin", f"HEAD:refs/heads/{IO.BRANCH}")


def test_git_runs_on_its_checkout_from_a_worktree_even_with_git_dir_exported(tmp_path, monkeypatch):
    """STATS's git calls are `git -C <checkout>` without the variables that point git elsewhere (fwd_core.GIT_ENV_DROP):
    from a linked worktree (`.git` is a file) with GIT_DIR and GIT_WORK_TREE exported at another repository,
    fwd_io.Git and fwd_register.checkout_roots still read that worktree and its main checkout, and the other repository
    is untouched."""
    so = StatsOrigin(tmp_path / "so")
    decoy = tmp_path / "decoy"
    _git(tmp_path, "init", "-q", str(decoy))
    _git(decoy, "commit", "-q", "--allow-empty", "-m", "decoy")
    head, decoy_head = _git(so.work, "rev-parse", "HEAD").strip(), _git(decoy, "rev-parse", "HEAD").strip()
    monkeypatch.setenv("GIT_DIR", str(decoy / ".git"))
    monkeypatch.setenv("GIT_WORK_TREE", str(decoy))
    g = IO.Git(so.work)
    assert g.head() == head and g.is_linked_worktree() and g.status() == ""
    assert g.toplevel() == so.work.resolve() and g.common_root() == so.main.resolve()
    roots = REG.checkout_roots(so.work)
    assert {so.work.resolve(), so.main.resolve()} <= roots and decoy.resolve() not in roots
    assert g.fetch(IO.BRANCH) and g.rev(f"origin/{IO.BRANCH}") == head and g.remote_has(IO.BRANCH)
    monkeypatch.delenv("GIT_DIR")
    monkeypatch.delenv("GIT_WORK_TREE")
    assert _git(decoy, "rev-parse", "HEAD").strip() == decoy_head
    assert not _git(decoy, "for-each-ref", "refs/remotes").strip()


@pytest.fixture
def data_code(fx_root, monkeypatch, tmp_path):
    """DATA's downloader and loaders from this checkout. The downloader's repo (where its Fetcher asks whether a locked
    run is open, and where every department's FETCH_LOG is read) is a temporary dept/stats checkout whose local origin
    holds OPEN_LID's pushed forward_run_start line and every branch DATA's pushed-logs check needs
    (blocks.REQUIRED_BRANCHES); STATS's FETCH_LOG is that checkout's (DATA's check_block_log). DATA's origin checks
    want the GitHub repo: its test helper's git (testguard.github_origin_git, first on PATH) answers `git remote
    get-url` with the GitHub URL, while every fetch still reads the local origin (DATA release 3)."""
    try:
        D = IO.downloader()
    except IO.Refused as e:
        pytest.skip(f"DATA's research/common is not in this checkout: {e}")
    L = IO.loaders()
    assert Path(D.__file__).resolve() == (C.REPO / "research/data/oanda_download.py").resolve()
    assert Path(L.__file__).resolve() == (C.REPO / "research/common/loaders.py").resolve()
    import testguard                                                    # research/data, beside D's blocks module
    assert testguard.blocks is D.blocks
    monkeypatch.setenv("PATH", f"{testguard.github_origin_git(tmp_path / 'bin')}{os.pathsep}{os.environ['PATH']}")
    so = StatsOrigin(tmp_path / "stats_origin", branches=D.blocks.REQUIRED_BRANCHES)
    so.push(IO.ACCESS_LOG_REL, {"kind": "forward_run_start", "ledger_id": OPEN_LID, "status": "started"})
    monkeypatch.setattr(D, "REPO", so.work)
    monkeypatch.setattr(D, "OTHER_LOGS_ROOT", so.work)                  # every department's FETCH_LOG read there
    monkeypatch.setattr(D, "BLOCK_LOG", so.work / "research/departments/DATA/FETCH_LOG.jsonl")  # never written here
    monkeypatch.setattr(IO, "FETCH_LOG", so.work / IO.FETCH_LOG_REL)
    monkeypatch.setattr(D, "stats_origin", so, raising=False)
    monkeypatch.setattr(IO.time, "sleep", lambda s: None)          # the loaders' fetch retries: not slept
    return D


def test_shared_code_from_elsewhere_is_refused(data_code, monkeypatch, tmp_path):
    fake = types.ModuleType("research.common.loaders")
    fake.__file__ = str(tmp_path / "research" / "common" / "loaders.py")
    monkeypatch.setitem(sys.modules, "research.common.loaders", fake)
    with pytest.raises(C.PinError, match="not from this checkout"):
        IO.loaders()


def fake_candles(monkeypatch, D, fail_from=None, incomplete_at=None, fail_status=404):
    """OANDA's candles endpoint on synthetic bars (3 bars a window). fail_from: from that call on, HTTP fail_status
    (404: DATA's Fetcher stops at once; 403, 407 or 429: a block, logged in STATS's FETCH_LOG; 302: a redirect, never
    followed); incomplete_at: that call's last candle is incomplete (the live edge: download stops). Every request
    must ask requests not to follow a redirect (allow_redirects=False)."""
    calls = []

    def get(self, url, timeout=None, params=None, **kw):
        assert kw.get("allow_redirects") is False, kw
        calls.append((url, dict(params)))
        r = requests.models.Response()
        if fail_from is not None and len(calls) >= fail_from:
            r.status_code = fail_status
            r._content = b"{}"
            return r
        a, b = D.parse_arg_time(params["from"].rstrip("Z")), D.parse_arg_time(params["to"].rstrip("Z"))
        cs = []
        for t in range(a, min(b, a + 180), 60):
            q = S.bars(t, t + 60)
            if len(q["ts_utc"]):
                cs.append({"time": datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000000000Z"),
                           "complete": True, "volume": 1,
                           "bid": {k: str(q[f"bid_{k}"][0]) for k in "ohlc"},
                           "ask": {k: str(q[f"ask_{k}"][0]) for k in "ohlc"}})
        if incomplete_at is not None and len(calls) == incomplete_at and cs:
            cs[-1]["complete"] = False
        r.status_code = 200
        r._content = json.dumps({"candles": cs}).encode()
        return r

    monkeypatch.setattr(requests.Session, "get", get)
    monkeypatch.setattr(IO.time, "sleep", lambda s: None)
    return calls


def test_download_refuses_an_unpushed_ledger_id(data_code, monkeypatch, tmp_path):
    D = data_code
    calls = fake_candles(monkeypatch, D)
    start = S.ny("2026-09-03", "17:00")
    with pytest.raises(IO.Refused, match="not in a pushed STATS ledger line"):
        IO.download_step(FakeGit(stats_access=""), "STATS-FWD-X", start, start + 86400 * 2, tmp_path / "dl")
    assert calls == []


def test_download_within_budget_then_load_logs_the_read(data_code, monkeypatch, tmp_path):
    D = data_code
    calls = fake_candles(monkeypatch, D)
    lid = OPEN_LID                                        # pushed on the downloader's dept/stats origin (data_code)
    git = FakeGit(stats_access=json.dumps({"kind": "forward_run_start", "ledger_id": lid}) + "\n")
    start = S.ny("2026-09-03", "17:00")
    end = start + 10 * 5000 * 60                          # 10 windows wanted
    dl_dir = Path(IO.locked_dir()) / "forward"
    dl_dir.mkdir(parents=True)
    (dl_dir / "REQUESTS.json").write_text(json.dumps({"day": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
                                                       "count": 26, "last": 0.0}))
    dl = IO.download_step(git, lid, start, end, dl_dir)
    assert dl["requests"] == 4 and len(calls) == 4                          # 30 - 26 left today
    last = data_code.last_saved(dl["path"])                                 # the fake serves 3 bars a window
    assert dl["covered_to"] == last + 60 < start + 4 * 5000 * 60
    assert all(u == URL and p["price"] == "BA" and p["granularity"] == "M1" for u, p in calls)
    assert all(D.parse_arg_time(p["to"].rstrip("Z")) <= start + 4 * 5000 * 60 for _, p in calls)   # budgeted windows
    assert json.loads((dl_dir / "DOWNLOAD_LOG.jsonl").read_text().splitlines()[-1])["locked_run"] == lid
    assert not (dl["path"].stat().st_mode & 0o222)                          # read-only after the run
    repo = data_code.stats_origin.work                    # the loaders check the pushed, unclosed start line there
    m = IO.load_step(lid, start, dl["covered_to"], dl["path"], repo_root=repo)
    assert m["bid_o"].dtype == np.float64 and int(m["ts_utc"].min()) >= start
    assert int(m["ts_utc"].max()) < dl["covered_to"]
    row = json.loads((repo / "research/departments/STATS/ACCESS_LOG.jsonl").read_text().splitlines()[-1])
    assert row["override"] == "forward_inputs" and row["ledger_id"] == lid and row["study"] == "FORWARD"
    assert row["datasets"] == ["STATS_FORWARD_EUR_USD_M1_BA"] and row["first_ts"] >= start
    with pytest.raises(IO.Refused, match="starts after the lagged-input start"):    # the file must hold the lag
        IO.load_step(lid, start - 5 * 86400, dl["covered_to"], dl["path"], repo_root=repo)


def test_the_read_needs_an_open_forward_run_on_origin(data_code, monkeypatch, tmp_path):
    """The loaders' 'forward_inputs' read (no offline fallback): refused for an id with no pushed start line, and once
    its closing line is pushed."""
    fake_candles(monkeypatch, data_code)
    so, start = data_code.stats_origin, S.ny("2026-09-03", "17:00")
    git = FakeGit(stats_access=json.dumps({"kind": "forward_run_start", "ledger_id": OPEN_LID}) + "\n")
    dl = IO.download_step(git, OPEN_LID, start, start + 2 * 5000 * 60, Path(IO.locked_dir()) / "forward")
    end = dl["covered_to"]
    with pytest.raises(PermissionError, match="no pushed 'forward_run_start' line"):
        IO.load_step("STATS-FWD-NEVER-PUSHED", start, end, dl["path"], repo_root=so.work)
    IO.load_step(OPEN_LID, start, end, dl["path"], repo_root=so.work)
    so.push(IO.ACCESS_LOG_REL, {"kind": "forward_run_done", "ledger_id": OPEN_LID, "status": "done"})
    with pytest.raises(PermissionError, match="already closed"):
        IO.load_step(OPEN_LID, start, end, dl["path"], repo_root=so.work)


def test_download_refuses_a_closed_or_non_forward_run_before_any_request(data_code, monkeypatch, tmp_path):
    """The ledger id must be an OPEN FORWARD run (loaders.open_run_kind 'forward_inputs', the rule of DATA's Fetcher and
    of the read): a forward run with its closing line pushed, a run cleared as a stale lock, and an open validation run
    are refused before any request, although each id is a whole value of a pushed ledger line (ledger_has_id)."""
    calls = fake_candles(monkeypatch, data_code)
    so, start = data_code.stats_origin, S.ny("2026-09-03", "17:00")
    t = "2026-10-01T00:00:00Z"
    so.push(IO.ACCESS_LOG_REL,
            {"utc": t, "kind": "forward_run_start", "ledger_id": "STATS-FWD-DONE"},
            {"utc": t, "kind": "forward_run_done", "ledger_id": "STATS-FWD-DONE", "requests": 0, "requests_by_utc_day": {}},
            {"utc": t, "kind": "forward_run_start", "ledger_id": "STATS-FWD-KILLED"},
            {"utc": t, "kind": "forward_stale_lock_cleared", "ledger_id": "STATS-FWD-CLR",
             "cleared_ledger_id": "STATS-FWD-KILLED"})
    so.push("research/VALIDATION2_LEDGER.jsonl", {"event": "validation_run_start", "run_id": "STATS-VAL-OPEN"})
    git = IO.Git(so.work)
    for lid in ("STATS-FWD-DONE", "STATS-FWD-KILLED", "STATS-VAL-OPEN"):
        with pytest.raises(IO.Refused, match="not an open forward run"):
            IO.download_step(git, lid, start, start + 2 * 5000 * 60, tmp_path / "dl")
    assert calls == [] and not (tmp_path / "dl" / "EURUSD_M1_BA.csv").exists()
    assert IO.download_step(git, OPEN_LID, start, start + 2 * 5000 * 60, tmp_path / "dl")["requests"] == 2


@pytest.mark.parametrize("status", [403, 407, 429])
def test_a_block_goes_to_stats_fetch_log_and_stops_the_next_download(data_code, monkeypatch, tmp_path, status):
    """DATA's Fetcher gets STATS's FETCH_LOG (docs/EDGE_HUNT.md section 5): the first 403, 407 or 429 stops the download at
    once (the requests sent are still metered), is logged there (URL without its query, the status), and a later
    download is refused before any request."""
    calls = fake_candles(monkeypatch, data_code, fail_from=2, fail_status=status)
    start = S.ny("2026-09-03", "17:00")
    git = FakeGit(stats_access=json.dumps({"kind": "forward_run_start", "ledger_id": OPEN_LID}) + "\n")
    meter = {}
    with pytest.raises(RuntimeError, match="24 hours"):
        IO.download_step(git, OPEN_LID, start, start + 4 * 5000 * 60, tmp_path / "dl", meter=meter)
    assert len(calls) == 2 and meter["requests"] == 2
    assert IO.FETCH_LOG == data_code.REPO / "research/departments/STATS/FETCH_LOG.jsonl"
    rows = [json.loads(x) for x in IO.FETCH_LOG.read_text().splitlines()]
    assert len(rows) == 1 and rows[0]["status"] == status and rows[0]["url"] == URL
    with pytest.raises(RuntimeError, match="24 hours"):
        IO.download_step(git, OPEN_LID, start, start + 4 * 5000 * 60, tmp_path / "dl")
    assert len(calls) == 2 and not data_code.BLOCK_LOG.exists()       # STATS's log, not DATA's default


def test_stats_fetch_log_is_statss_own():
    """The runner's FETCH_LOG is STATS's (research/departments/STATS/FETCH_LOG.jsonl in the runner's worktree), not
    DATA's default, and the run's commits may carry it to dept/stats (FORBIDDEN_ON_STATS does not refuse it)."""
    real = C.STATS / "FETCH_LOG.jsonl"
    assert IO.FETCH_LOG_REL == real.relative_to(C.REPO).as_posix() == "research/departments/STATS/FETCH_LOG.jsonl"
    assert not IO.FORBIDDEN_ON_STATS.search(IO.FETCH_LOG_REL)
    assert IO.FETCH_LOG != real                         # conftest: every test writes a temporary FETCH_LOG


def test_a_redirect_is_not_followed(data_code, monkeypatch, tmp_path):
    """DATA's Fetcher asks requests not to follow a redirect (fake_candles checks allow_redirects=False on every call)
    and stops at a 3xx answer; nothing is logged as a block."""
    calls = fake_candles(monkeypatch, data_code, fail_from=1, fail_status=302)
    start = S.ny("2026-09-03", "17:00")
    git = FakeGit(stats_access=json.dumps({"kind": "forward_run_start", "ledger_id": OPEN_LID}) + "\n")
    with pytest.raises(RuntimeError, match="redirect, not followed"):
        IO.download_step(git, OPEN_LID, start, start + 2 * 5000 * 60, tmp_path / "dl")
    assert len(calls) == 1 and not IO.FETCH_LOG.exists()


def test_a_window_outside_the_forward_runs_window_is_refused_before_any_request(data_code, monkeypatch, tmp_path):
    """DATA's locked_run_window: a forward run may read from FORWARD_START - 400 days to now. A download that starts
    earlier, or ends after now, is refused before any request, though the run is open."""
    calls = fake_candles(monkeypatch, data_code)
    git = FakeGit(stats_access=json.dumps({"kind": "forward_run_start", "ledger_id": OPEN_LID}) + "\n")
    early = C.FORWARD_START - 401 * 86400 - (C.FORWARD_START - 401 * 86400) % 60
    with pytest.raises(IO.Refused, match="outside what run"):
        IO.download_step(git, OPEN_LID, early, early + 2 * 5000 * 60, tmp_path / "dl")
    late = S.ny("2026-09-03", "17:00")
    future = int(datetime.now(timezone.utc).timestamp()) // 60 * 60 + 7 * 86400
    with pytest.raises(IO.Refused, match="outside what run"):
        IO.download_step(git, OPEN_LID, late, future, tmp_path / "dl")
    assert calls == []
