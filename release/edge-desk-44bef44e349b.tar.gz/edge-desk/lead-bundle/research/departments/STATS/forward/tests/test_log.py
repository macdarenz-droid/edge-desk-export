"""The log: append-only, idempotent, stable as days are added (each run starting from the floors the last one saved),
compared line by line in full, and in judge.py's format (PASS_BAR.md section 2)."""
import json
from datetime import date

import pytest

import fwd_core as C
import judge as J
import synth as S


def run_to(day: str, tmp_path, log=None, floors=None):
    """One run as the runner does it: the calendar as known on `day`, bars from the floors' lagged start."""
    picks = C.load_picks()
    csv, meta = S.write_calendar(tmp_path / f"cal_{day}", run_day=day)
    cal = C.read_calendar(csv, meta)
    d = date.fromisoformat(day)
    end = C.label_close_ts(d)
    if log is not None and floors is None:
        floors = C.floors_from_log(C.read_log(log), picks)
    start = C.inputs_start(picks, floors)
    res = C.compute_run(picks, cal, S.bars(start, end), end, f"TEST-{day}", floors=floors, run_day=d)
    return res, cal, start


def lines_to(day: str, tmp_path):
    return run_to(day, tmp_path)[0].lines


def trades(rows):
    return [r for r in rows if C.kind_of(r) == "trade"]


def test_rerun_same_day_adds_nothing(tmp_path):
    log = tmp_path / "FORWARD_LOG.jsonl"
    first = lines_to("2026-12-07", tmp_path)
    assert C.append_log(first, log) == 5
    before = log.read_bytes()
    assert C.append_log(lines_to("2026-12-07", tmp_path), log) == 0
    assert log.read_bytes() == before


def test_day_by_day_equals_one_run(tmp_path):
    """Runs on 23 Oct, 10 Nov, 25 Nov and 7 Dec, each from the floors the last run saved (so each reads only bars from
    its earliest unsettled decision less 35 days), log exactly what one run on 7 Dec logs, in the same order."""
    a, b = tmp_path / "a.jsonl", tmp_path / "b.jsonl"
    starts = []
    for day in ("2026-10-23", "2026-11-10", "2026-11-25", "2026-12-07"):
        res, cal, start = run_to(day, tmp_path, log=a)
        C.append_run(res, a, cal)
        starts.append(start)
    assert starts == sorted(starts) and starts[-1] > starts[0]           # lag rows of settled trades never re-read
    res, cal, _ = run_to("2026-12-07", tmp_path)
    C.append_run(res, b, cal)
    key = lambda r: (r["pick_id"], r["decision_ts"])
    strip = lambda rows: sorted(({k: v for k, v in r.items() if k != "run_ledger_id"} for r in trades(rows)), key=key)
    assert len(trades(C.read_log(b))) == 5 and strip(C.read_log(a)) == strip(C.read_log(b))


@pytest.mark.parametrize("path", [("net_pips",), ("days", 0, "pnl_long"), ("fills", "entry_bid"), ("exit_ts",),
                                  ("recost", "long", "exit_spread"), ("net", "short", "floor_1p6")])
def test_any_changed_field_stops_the_run(tmp_path, path):
    """The whole stored line is compared (only run_ledger_id may differ), nested fields included."""
    log = tmp_path / "FORWARD_LOG.jsonl"
    lines = lines_to("2026-12-07", tmp_path)
    C.append_log(lines, log)
    bad = json.loads(json.dumps(lines))
    obj = bad[0]
    for k in path[:-1]:
        obj = obj[k]
    obj[path[-1]] = obj[path[-1]] + 1
    with pytest.raises(RuntimeError, match="differently"):
        C.append_log(bad, log)
    rerun = json.loads(json.dumps(lines))
    rerun[0]["run_ledger_id"] = "ANOTHER-RUN"
    assert C.append_log(rerun, log) == 0


def test_an_out_of_order_position_stops_the_run(tmp_path):
    log = tmp_path / "FORWARD_LOG.jsonl"
    fc = sorted((l for l in lines_to("2026-12-07", tmp_path) if l["pick_id"] == "FC-1"), key=lambda l: l["decision_ts"])
    C.append_log([fc[1]], log)
    with pytest.raises(RuntimeError, match="before a logged position"):
        C.append_log([fc[0]], log)


def test_a_disappearing_position_stops_the_run(tmp_path):
    """A logged position inside the recomputed window that the recomputation no longer gives is reported."""
    log = tmp_path / "FORWARD_LOG.jsonl"
    lines = lines_to("2026-12-07", tmp_path)
    C.append_log(lines, log)
    rest = [l for l in lines if not (l["pick_id"] == "FC-1" and C.label_of(l["decision_ts"]) == "2026-11-02")]
    with pytest.raises(RuntimeError, match="disappeared"):
        C.append_log(rest, log, windows={"FC-1": (C.FORWARD_START, float("inf"))})
    assert C.append_log(rest, log) == 0                                   # without a window: nothing to compare


def test_lines_hold_no_pre_forward_label_and_pass_judge_validate(tmp_path):
    log = tmp_path / "FORWARD_LOG.jsonl"
    C.append_log(lines_to("2026-12-07", tmp_path), log)
    for pid in ("R53-S3X3", "PA-F4", "FC-1"):
        with pytest.raises(C.BelowPassCase):                                 # no COST model in these lines
            C.forward_table(pid, log)
        df = C.forward_table(pid, log, allow_below_pass_case=True)
        assert len(df) and (df["day"] >= "2026-10-09").all()
        days = J.trading_days("2026-10-09", "2026-12-07")
        v = J.validate(df, days, {"FORWARD"})
        assert set(v["era"]) == {"FORWARD"}
    for r in C.read_log(log):
        json.dumps(r)                                     # plain JSON
        assert r["cost"]["floor_pips_round_trip"] == 2.0 and r["pair"] == "EUR_USD" and r["w"] == 1.0
        assert r["below_pass_case"] and "COST v3 model not loaded" in r["below_pass_case_reasons"]


def test_append_log_refuses_a_path_inside_the_checkout(tmp_path, monkeypatch):
    """dept/stats is merged everywhere: the log may only be written outside the checkout (dept/stats-locked)."""
    lines = lines_to("2026-12-07", tmp_path)
    fake_repo = tmp_path / "repo"
    monkeypatch.setattr(C, "REPO", fake_repo)
    inside = fake_repo / "research/departments/STATS/locked" / C.LOG_NAME
    with pytest.raises(C.Refused, match="dept/stats-locked"):
        C.append_log(lines, inside)
    assert not inside.exists()
