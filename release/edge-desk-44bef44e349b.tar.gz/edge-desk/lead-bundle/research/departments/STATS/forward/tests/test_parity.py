"""Parity with the rounds' own published trade files.

1. Schedule parity (no prices; always runs): the runner's calendar path and the frozen decide/exit functions, fed the
   rounds' own calendars, give every published trade's decision and scheduled exit, and Round 55's declared FC-1
   calendar counts (96, 32, 25). Only timestamps of the published files are read.
2. Price parity (runs only when DATA's research/common is in this checkout and the BUILD 2016-2021 EUR/USD M1 set is
   already under the loaders' data root, else SKIPPED; a test never fetches a data branch): BUILD bars read with
   research.common.loaders.load_m1(era="BUILD") only; the runner's adapters on them reproduce the published BUILD
   trades to 1e-9, and every trade's log line passes its own checks (fills, mirrored short, financing split, day rows
   summing to the frozen net). No C, T or locked price is read.
"""
import io
from datetime import date, datetime, timezone

import numpy as np
import pandas as pd
import pytest

import fwd_core as C
import fwd_io as IO
import fwd_register as REG

R = C.REPO / "research"
PICKS = {p["id"]: p for p in C.load_picks()}


@pytest.fixture(scope="module")
def fz():
    C.verify_pins(list(PICKS.values()))
    return C.frozen(list(PICKS.values()))


def rows_events_csv():
    return C.calendar_rows(pd.read_csv(R / "round17/data/events.csv", dtype=str, keep_default_na=False), ("held",))


def rows_2010_2015():
    return C.calendar_rows(pd.read_csv(R / "round49/data/events_2010_2015.csv", dtype=str, keep_default_na=False),
                           ("held",))


def empty_world(fz, rows, end):
    m = {k: np.zeros(0) for k in ("bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")}
    m["ts_utc"] = np.zeros(0, dtype=np.int64)
    return fz.E.World(m, {}, C.events_frame(rows), None, end)


def plan_of(fz, pick, rows, era, d_from, d_to, end):
    return C.simulate(fz, pick, empty_world(fz, rows, end), rows, era, d_from, d_to, 0)[1]


def match(plan, pub, exits_early=False):
    """Every published trade sits in a planned window: entry within 15 minutes after the decision, exit within 15
    minutes after the scheduled exit (or before it, for stop and target exits)."""
    dec = np.array(sorted(t for t, _ in plan))
    sched = dict(plan)
    for e, x in zip(pub.entry_ts, pub.exit_ts):
        k = int(np.searchsorted(dec, e, side="right")) - 1
        assert k >= 0 and 0 <= e - dec[k] < 900, f"entry {e} has no planned decision"
        te = sched[int(dec[k])]
        assert (x < te + 900) if exits_early else (0 <= x - te < 900), f"exit {x} vs scheduled {te}"


ERA = {"B": (date(2016, 3, 1), date(2021, 12, 31), 1640995200),
       "C": (date(2022, 1, 3), date(2023, 11, 30), 1701388800),
       "T": (date(2023, 12, 1), date(2025, 6, 27), 1751317200)}


@pytest.mark.parametrize("era", ["B", "C", "T"])
def test_schedule_pa_f4_round47(fz, era):
    a, b, end = ERA[era]
    pub = pd.read_csv(R / f"round47/results/trades_{era}.csv.gz")
    pub = pub[pub.cell == "PA-F4"]
    plan = plan_of(fz, PICKS["PA-F4"], rows_events_csv(), era, a, b, end)
    assert len(pub) and len(pub) <= len(plan)
    match(plan, pub)


def test_schedule_pa_f4_round49_2010_2015(fz):
    pub = pd.read_csv(R / "round49/trades_2010_2015.csv.gz")
    pub = pub[pub.cell == "PA-F4"]
    plan = plan_of(fz, PICKS["PA-F4"], rows_2010_2015(), "X49", date(2010, 4, 1), date(2015, 12, 31), 1451606400)
    assert len(pub) == 65 and len(pub) <= len(plan)
    match(plan, pub)


@pytest.mark.parametrize("era,count", [("B", 96), ("C", 32), ("T", 25)])
def test_schedule_fc_1_round55(fz, era, count):
    a, b, end = ERA[era]
    plan = plan_of(fz, PICKS["FC-1"], rows_events_csv(), era, a, b, end)
    assert sum(1 for t, te in plan if te < end) == count          # DECLARATION section 5 counts
    pub = pd.read_csv(R / f"round55/results/trades_A-{era}.csv.gz")
    pub = pub[pub.cell == "FC-1"]
    assert set(zip(pub.dec_ts, pub.sched_exit_ts)) <= set(plan)
    match(plan, pub)


@pytest.mark.parametrize("src,period,era,all_times", [
    ("trades_build", "y2016_21", (date(2016, 1, 4), date(2021, 12, 31), 1640995200), False),
    ("trades_judge", "C", (date(2022, 1, 3), date(2023, 11, 30), 1701388800), False),
    ("trades_judge", "T", (date(2023, 12, 1), date(2025, 6, 27), 1751317200), False),
    ("trades_build", "y2010_15", (date(2010, 4, 1), date(2015, 12, 31), 1451606400), True)])
def test_schedule_r53(fz, src, period, era, all_times):
    pub = pd.read_csv(R / f"round53/{src}.csv.gz")
    pub = pub[(pub.period == period) & (pub.stop_v == "S3") & (pub.tgt_v == "X3")]
    pick = {**PICKS["R53-S3X3"], "params": {**PICKS["R53-S3X3"]["params"], "all_times": all_times}}
    rows = rows_2010_2015() if period == "y2010_15" else rows_events_csv()
    plan = plan_of(fz, pick, rows, "R53", era[0], era[1], era[2])
    assert len(pub) and len(pub) <= len(plan)
    match(plan, pub, exits_early=True)
    if period in ("C", "T"):
        assert len(pub) == {"C": 15, "T": 13}[period]                # research/round53/results_judge.json


# ------------------------------------------------------------------ price parity (BUILD bars only; skipped without them)

BUILD_FROM = int(datetime(2016, 1, 3, tzinfo=timezone.utc).timestamp())    # Round 47's B world: warm-up from 3 Jan
BUILD_END = 1640995200


@pytest.fixture(scope="module")
def build_world(fz):
    try:
        L = IO.loaders()
    except IO.Refused as e:
        pytest.skip(f"DATA's research/common is not in this checkout ({e}); price parity not run")
    if not REG.held_locally(L, "EUR_USD", BUILD_FROM, BUILD_END):
        pytest.skip("BUILD EUR/USD M1 not under the loaders' data root; price parity not run")
    try:
        df = L.load_m1("EUR_USD", era="BUILD", dtype="float64", start=BUILD_FROM, end=BUILD_END)
    except FileNotFoundError as e:
        pytest.skip(f"BUILD EUR/USD M1 unavailable ({e}); price parity not run")
    assert int(df["ts_utc"].max()) < BUILD_END
    m1 = {c: df[c].to_numpy() for c in df.columns}
    rows = rows_events_csv()                                          # the whole calendar, as Round 55's CAL
    ev = C.events_frame(rows[rows.ts < 1640995200])                   # World.events as r47_engine.load_events(end)
    w = fz.E.World(m1, {}, ev, fz.E.r45.daily_bars(m1), 1640995200)
    w_mir = fz.E.World(C.mirror_m1(m1), {}, ev, fz.E.r45.daily_bars(C.mirror_m1(m1)), 1640995200)
    return w, w_mir, rows, C.bar_labels(m1["ts_utc"])


def compare(mine, pub, cols, key="entry_ts"):
    a = pd.DataFrame(mine).sort_values(key).reset_index(drop=True)
    b = pub.sort_values(key).reset_index(drop=True)
    assert len(a) == len(b)
    for c in cols:
        if not pd.api.types.is_numeric_dtype(b[c]):      # text: object, or pandas 3.x's "str" dtype from read_csv
            assert (a[c].astype(str) == b[c].astype(str)).all(), c
        else:
            assert np.allclose(a[c].to_numpy(float), b[c].to_numpy(float), rtol=0, atol=1e-9), c


def test_compare_takes_text_columns_as_text():
    """compare() on a published table read with read_csv: a text column ("why") is compared as text, numbers within
    1e-9. Under pandas 3.x read_csv gives text the "str" dtype, not object (DATA release 3 gate, 14 Oct 2026), and a
    dtype == object test sent "why" to to_numpy(float). Synthetic rows, no data."""
    pub = pd.read_csv(io.StringIO("entry_ts,why,r_pips\n100,target,12.5\n200,stop,-8.25\n"))
    mine = [{"entry_ts": 200, "why": "stop", "r_pips": -8.25 + 1e-12}, {"entry_ts": 100, "why": "target", "r_pips": 12.5}]
    compare(mine, pub, ["entry_ts", "why", "r_pips"])
    with pytest.raises(AssertionError, match="why"):
        compare([{**mine[0], "why": "time"}, mine[1]], pub, ["entry_ts", "why", "r_pips"])
    with pytest.raises(AssertionError, match="r_pips"):
        compare([{**mine[0], "r_pips": -8.0}, mine[1]], pub, ["entry_ts", "why", "r_pips"])


@pytest.mark.parametrize("pid,src,cell,cols", [
    ("PA-F4", "round47/results/trades_B.csv.gz", "PA-F4",
     ["entry_ts", "exit_ts", "move_pips", "net_ba", "fin", "net", "net16", "net_long", "net_short"]),
    ("FC-1", "round55/results/trades_A-B.csv.gz", "FC-1",
     ["entry_ts", "exit_ts", "move_pips", "net_ba", "fin", "net", "net16", "net_long", "net_short"])])
def test_price_parity_cells_build(fz, build_world, pid, src, cell, cols):
    w, w_mir, rows, labels = build_world
    trades, _ = C.simulate(fz, PICKS[pid], w, rows, "B", date(2016, 3, 1), date(2021, 12, 31), 0)
    pub = pd.read_csv(R / src)
    compare(trades, pub[pub.cell == cell], cols)
    for x in trades:
        C.position_line(fz, PICKS[pid], w, w_mir, labels, x, "PARITY")


def test_price_parity_r53_build(fz, build_world):
    w, w_mir, rows, labels = build_world
    trades, _ = C.simulate(fz, PICKS["R53-S3X3"], w, rows, "R53", date(2016, 1, 4), date(2021, 12, 31), 0)
    pub = pd.read_csv(R / "round53/trades_build.csv.gz")
    pub = pub[(pub.period == "y2016_21") & (pub.stop_v == "S3") & (pub.tgt_v == "X3")]
    compare(trades, pub, ["entry_ts", "exit_ts", "r_pips", "why", "R_ba", "R_20", "R_20_short"])
    for x in trades:
        C.position_line(fz, PICKS["R53-S3X3"], w, w_mir, labels, x, "PARITY")
