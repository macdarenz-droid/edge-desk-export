"""One test (or more) per finding of RED_TEAM.md red team 1; each fails if its fix is removed. Git tests run on local
bare repositories under tmp_path (no network); the forward tests on synthetic bars and calendars."""
import fcntl
import hashlib
import json
import re
import shutil
import subprocess
from datetime import date, timedelta
from types import SimpleNamespace

import numpy as np
import pytest

import fwd_core as C
import fwd_cost
import fwd_io as IO
import run_forward as RF
import synth as S
from test_io import NOW, DAY, URL, Clock, FakeOps, Inner, session
from test_log import run_to, trades

STATUS_REL = "research/departments/STATS/STATUS.json"


# ------------------------------------------------------------------ local git sandboxes

def git(cwd, *a, check=True):
    r = subprocess.run(["git", "-C", str(cwd), *a], capture_output=True, text=True)
    if check and r.returncode:
        raise RuntimeError(f"git {a}: {r.stderr}")
    return r.stdout.strip()


@pytest.fixture
def repos(tmp_path, monkeypatch):
    """origin (bare), the session checkout `main` on dept/stats, and the runner's linked worktree `wt` at
    origin/dept/stats."""
    home = tmp_path / "home"
    home.mkdir()
    for k, v in {"HOME": str(home), "GIT_CONFIG_NOSYSTEM": "1", "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
                 "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t"}.items():
        monkeypatch.setenv(k, v)
    origin, main, wt = tmp_path / "origin.git", tmp_path / "main", tmp_path / "stats-fwd-wt"
    git(tmp_path, "init", "-q", "--bare", str(origin))
    git(tmp_path, "clone", "-q", str(origin), str(main))
    git(main, "checkout", "-q", "-b", "dept/stats")
    (main / "research/departments/STATS").mkdir(parents=True)
    (main / STATUS_REL).write_text('{"oanda_job": null}\n')
    (main / ".gitignore").write_text("__pycache__/\n*.pyc\n.pytest_cache/\n")
    git(main, "add", "-A")
    git(main, "commit", "-q", "-m", "init")
    git(main, "push", "-q", "origin", "dept/stats")
    git(main, "fetch", "-q", "origin")
    git(main, "worktree", "add", "-q", "--detach", str(wt), "origin/dept/stats")
    # these repositories' origin is a local bare repo: the origin check (test_rt3.py proves it with GitHub's pattern)
    # takes this one exact path here
    monkeypatch.setattr(IO, "origin_pattern", lambda: re.compile(re.escape(str(origin))))
    return SimpleNamespace(origin=origin, main=main, wt=wt, tmp=tmp_path)


# ------------------------------------------------------------------ item 1: locked numbers only on dept/stats-locked

def test_1_dept_stats_never_stages_a_locked_path(repos):
    g = IO.Git(repos.wt)
    locked = repos.wt / "research/departments/STATS/locked" / C.LOG_NAME
    locked.parent.mkdir(parents=True)
    locked.write_text('{"net_pips": 1}\n')
    head = git(repos.origin, "rev-parse", "dept/stats")
    with pytest.raises(IO.Refused, match="dept/stats-locked"):
        g.commit_push([locked], "x")
    with pytest.raises(IO.Refused):                                  # any FORWARD_LOG name, anywhere
        g.commit_push([repos.wt / "FORWARD_LOG.jsonl"], "x")
    git(repos.wt, "add", "-f", str(locked))                           # staged by someone else: still refused
    (repos.wt / STATUS_REL).write_text('{"oanda_job": {"what": "x"}}\n')
    with pytest.raises(IO.Refused, match="staged"):
        g.commit_push([repos.wt / STATUS_REL], "status")
    assert not [f for f in g.staged() if "locked" in f] and git(repos.origin, "rev-parse", "dept/stats") == head


def test_1_access_rows_carry_no_pnl():
    IO.check_access_row({"utc": "x", "kind": "forward_run_done", "requests": 3, "data_end_ts": 1})
    for k in ("net_pips", "days", "pnl_long", "exit", "fills", "net_R"):
        with pytest.raises(ValueError, match="not allowed"):
            IO.check_access_row({"kind": "forward_run_done", k: 1})


def test_1_locked_log_is_an_orphan_worktree_pushed_to_its_own_branch(repos):
    g = IO.Git(repos.wt)
    for inside in (repos.wt / "lk", repos.main / "lk", C.REPO / "lk"):
        with pytest.raises(IO.Refused, match="outside every checkout"):
            IO.LockedLog(g, inside)
    ll = IO.LockedLog(g, repos.tmp / "stats-locked-wt")
    log = ll.open()                                                   # first run: empty orphan root, pushed
    assert git(repos.origin, "rev-parse", "dept/stats-locked")
    assert subprocess.run(["git", "-C", str(repos.origin), "merge-base", "dept/stats", "dept/stats-locked"],
                          capture_output=True).returncode == 1        # no shared history with dept/stats
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text('{"kind": "trade"}\n')
    ok, sha = ll.publish("STATS forward log: test")
    assert ok and git(repos.origin, "rev-parse", "dept/stats-locked") == sha
    assert git(repos.origin, "show", f"dept/stats-locked:{IO.LOCKED_LOG_REL}") == '{"kind": "trade"}'
    assert "locked" not in git(repos.origin, "ls-tree", "-r", "--name-only", "dept/stats")   # nothing locked there
    other = repos.tmp / "other-writer"                                # locked_runner pushes in between
    git(repos.main, "worktree", "add", "-q", "--detach", str(other), "origin/dept/stats-locked")
    (other / "v.json").write_text("{}\n")
    git(other, "add", "v.json")
    git(other, "commit", "-q", "-m", "other")
    git(other, "push", "-q", "origin", "HEAD:refs/heads/dept/stats-locked")
    log.write_text('{"kind": "trade"}\n{"kind": "run_state"}\n')
    ok, sha = ll.publish("STATS forward log: second")                 # merged, never rebased, then pushed
    assert ok and git(repos.origin, "rev-parse", "dept/stats-locked") == sha
    assert git(repos.origin, "show", "dept/stats-locked:v.json") == "{}"
    ll2 = IO.LockedLog(g, repos.tmp / "stats-locked-wt")
    assert ll2.open() == log                                          # reopens, synced


# ------------------------------------------------------------------ items 2 and 9: STATS's own lock, flock, seed, stale

class LockGit:
    def __init__(self, status, access=""):
        self.status_text, self.access = status, access

    def fetch(self, branch):
        return True

    def show(self, ref, path):
        return {STATUS_REL: self.status_text, IO.ACCESS_LOG_REL: self.access}.get(path)


JOB = {"what": "STATS forward log download STATS-FWD-20261208T010000Z-abc123", "started_utc": "2026-12-08T01:00:00Z",
       "ledger_id": "STATS-FWD-20261208T010000Z-abc123"}


def test_2_pushed_stats_lock():
    assert IO.stats_lock_free(LockGit('{"oanda_job": null}'))
    assert not IO.stats_lock_free(LockGit(json.dumps({"oanda_job": JOB})))
    assert not IO.stats_lock_free(LockGit("not json")) and not IO.stats_lock_free(LockGit(None))


def test_9_stale_lock_clear_rules():
    st = json.dumps({"oanda_job": JOB})
    t0 = S.utc("2026-12-08T01:00:00")
    assert IO.stale_job(LockGit(st), t0 + 7 * 3600)["ledger_id"] == JOB["ledger_id"]
    with pytest.raises(IO.Refused, match="stale only after 6 h"):
        IO.stale_job(LockGit(st), t0 + 5 * 3600)
    done = json.dumps({"kind": "forward_run_done", "ledger_id": JOB["ledger_id"]}) + "\n"
    with pytest.raises(IO.Refused, match="closing line"):
        IO.stale_job(LockGit(st, done), t0 + 7 * 3600)
    with pytest.raises(IO.Refused, match="not a forward runner job"):
        IO.stale_job(LockGit(json.dumps({"oanda_job": {"what": "holdout", "started_utc": "2026-12-01T00:00:00Z"}})),
                     t0 + 7 * 3600)
    with pytest.raises(IO.Refused, match="nothing to clear"):
        IO.stale_job(LockGit('{"oanda_job": null}'), t0)


def test_9_clear_stale_logs_a_line_and_pushes(tmp_path):
    class Ops(FakeOps):
        def stale_job(self, now):
            self.calls.append("stale")
            return JOB
    ops = Ops(tmp_path)
    r = RF.clear_stale(ops, now=S.utc("2026-12-08T08:00:00"))
    assert ops.calls == ["leftovers", "worktree", "stale", "job:clear", "access:forward_stale_lock_cleared:cleared",
                         "publish"]                    # the lock released first (red team 7, N4)
    assert r["cleared"] == JOB["ledger_id"] and ops.access_rows[0]["cleared_ledger_id"] == JOB["ledger_id"]


def test_2_flock_held_while_sending(tmp_path):
    clk = Clock(S.utc("2026-12-08T10:00:00"))
    seen = []

    class Probe(Inner):
        def get(self, url, **kw):
            with open(tmp_path / "REQUESTS.lock", "a") as f:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    seen.append("free")
                except BlockingIOError:
                    seen.append("held")
            return "ok"
    session(tmp_path, clk, Probe()).get(URL)
    assert seen == ["held"]


def test_2_budget_seeded_from_the_pushed_access_log(tmp_path):
    clk = Clock(S.utc("2026-12-08T10:00:00"))
    lines = [{"kind": "forward_run_start", "ledger_id": "A", "utc": "2026-12-08T01:00:00Z"},
             {"kind": "forward_run_done", "ledger_id": "A", "utc": "2026-12-08T01:05:00Z",
              "requests_by_utc_day": {"2026-12-08": 20}},
             {"kind": "forward_run_done", "ledger_id": "B", "utc": "2026-12-08T02:00:00Z", "requests": 6},
             {"kind": "forward_run_start", "ledger_id": "KILLED", "utc": "2026-12-07T23:00:00Z"},
             {"kind": "forward_run_start", "ledger_id": "NOW", "utc": "2026-12-08T09:59:00Z"}]
    seed = IO.pushed_requests_by_day(lines, exclude="NOW")
    assert seed == {"2026-12-08": 26, "2026-12-07": 30}
    inner = Inner()
    s = IO.BudgetSession(inner, tmp_path / "REQUESTS.json", clock=clk, sleep=clk.sleep, seed=seed)
    assert s.remaining() == 4                                         # a fresh container: no local count
    for _ in range(4):
        s.get(URL)
    with pytest.raises(IO.BudgetExceeded):
        s.get(URL)
    assert len(inner.calls) == 4 and s.by_day == {"2026-12-08": 4}


# ------------------------------------------------------------------ item 3: the gate

GITHUB = "https://github.com/macdarenz-droid/Forex-signal"


class GateGit:
    def __init__(self, files, linked=True, head="h", remote="h", status="", diff=(), ancestor=True, ahead=False,
                 urls=(GITHUB, GITHUB), blobs=None):
        self.files, self.linked, self.h, self.r, self.st, self.diff, self.anc = files, linked, head, remote, status, \
            list(diff), ancestor
        self.ahead, self.urls, self.blobs = ahead, list(urls), dict(blobs or {})

    def origin_urls(self):
        return self.urls

    def replace_refs(self):
        return list(getattr(self, "replaced", []))

    def show_bytes(self, ref, path):
        return self.blobs.get((ref, path))

    def show(self, ref, path):
        b = self.blobs.get((ref, path))
        return None if b is None else b.decode()

    def grafts(self):
        return list(getattr(self, "grafted", []))

    def ssl_verify(self, url):
        return getattr(self, "tls", "true")

    def is_linked_worktree(self):
        return self.linked

    def head_reflog(self):
        return getattr(self, "reflog_why", "")

    def fetch(self, branch):
        return True

    def head(self):
        return self.h

    def rev(self, ref):
        return self.r

    def status(self, paths=()):
        return self.st

    def diff_names(self, ref, path):
        return self.diff

    def unclean(self, paths=()):
        return [self.st] if self.st else []

    def ls_files(self, path):
        return [f for f in self.files if f == path or f.startswith(path.rstrip("/") + "/")]

    def is_ancestor(self, a, b):
        if (a, b) == (self.r, self.h):                    # origin/dept/stats behind HEAD: unpushed commits
            return self.ahead
        if (a, b) == (self.h, self.r):                    # HEAD behind origin/dept/stats: never when HEAD is ahead
            return not self.ahead and self.anc
        return self.anc


@pytest.fixture
def fwd_tree(tmp_path):
    repo = tmp_path / "repo"
    d = repo / IO.FWD_REL
    d.mkdir(parents=True)
    (d / "run_forward.py").write_text("print('x')\n")
    (d / "DEPS.json").write_text(json.dumps({"data_commit": "d" * 40, "cost": {"cost_commit": "c" * 40}}))
    (d / "RED_TEAM.md").write_text("# red team\n\napproved_tree_sha256:\n")
    (d / "calendars").mkdir()
    (d / "calendars/FORWARD_EVENTS.csv").write_text("event_id,type\n")
    (d / "calendars/FORWARD_EVENTS.json").write_text(json.dumps(
        {"status": "needs_source", "sha256": C.sha256_file(d / "calendars/FORWARD_EVENTS.csv")}))
    (repo / IO.AUDIT_INPUTS_REL).write_text("REFUSED = {}\n")         # STATS/audit_inputs.py: hashed with forward/
    files = [f"{IO.FWD_REL}/run_forward.py", f"{IO.FWD_REL}/DEPS.json", f"{IO.FWD_REL}/RED_TEAM.md", *IO.CAL_PIN_RELS,
             IO.AUDIT_INPUTS_REL]
    return repo, files


def hashed(files):
    return [f for f in files if not f.endswith("RED_TEAM.md") and f not in IO.CAL_PIN_RELS]


def test_3_gate_needs_an_approved_tree(fwd_tree):
    repo, files = fwd_tree
    g = GateGit(files)
    with pytest.raises(IO.Refused, match="not approved"):
        IO.gate(g, repo, check_code=False)
    tree = IO.tree_sha256(repo, hashed(files))
    red = repo / IO.FWD_REL / "RED_TEAM.md"
    red.write_text(red.read_text() + f"approved_tree_sha256: {tree}\n")   # RED_TEAM.md is outside the hash
    assert IO.gate(g, repo, check_code=False)["tree_sha256"] == tree
    (repo / IO.FWD_REL / "run_forward.py").write_text("print('changed')\n")
    with pytest.raises(IO.Refused, match="not approved"):
        IO.gate(g, repo, check_code=False)


@pytest.mark.parametrize("kw,msg", [({"diff": ["x"]}, "differs from origin"), ({"status": "?? x"}, "uncommitted"),
                                    ({"ancestor": False}, "not on origin/ccr"), ({"linked": False}, "dedicated"),
                                    ({"remote": "other"}, "is not origin/dept/stats")])
def test_3_10_gate_refusals(fwd_tree, kw, msg):
    repo, files = fwd_tree
    tree = IO.tree_sha256(repo, hashed(files))
    (repo / IO.FWD_REL / "RED_TEAM.md").write_text(f"approved_tree_sha256: {tree}\n")
    with pytest.raises(IO.Refused, match=msg):
        IO.gate(GateGit(files, **kw), repo, check_code=False)


def test_3_every_approval_line_is_well_formed():
    """Every approved_tree_sha256 line in RED_TEAM.md holds 64 lowercase hex characters (or is the one empty
    placeholder), so a typo cannot pass unnoticed, and the gate reads exactly those lines. A red team adding its line
    keeps this test green."""
    lines = [l for l in (C.HERE / "RED_TEAM.md").read_text().splitlines() if l.startswith("approved_tree_sha256:")]
    values = [l.split(":", 1)[1].strip() for l in lines]
    assert lines and values.count("") <= 1
    good = [v for v in values if v]
    assert all(len(v) == 64 and set(v) <= set("0123456789abcdef") for v in good), good
    assert IO.approved_trees(C.REPO) == set(good)


def test_3_picks_pinned_in_deps(tmp_path):
    C.verify_pick_pins(C.PICKS_DIR)                                   # the repo's picks match DEPS.json
    d = tmp_path / "picks"
    shutil.copytree(C.PICKS_DIR, d)
    C.load_picks(d, C.DEPS)
    (d / "PA-F4.json").write_text((d / "PA-F4.json").read_text().replace("12:00 London", "12:01 London"))
    with pytest.raises(C.PinError, match="PA-F4"):
        C.load_picks(d, C.DEPS)
    shutil.copy(C.PICKS_DIR / "PA-F4.json", d / "PA-F4.json")
    (d / "EXTRA.json").write_text("{}")
    with pytest.raises(C.PinError, match="EXTRA"):
        C.load_picks(d, C.DEPS)


def test_10_worktree_rules_on_real_git(repos):
    with pytest.raises(IO.Refused, match="dedicated worktree"):
        IO.worktree_check(IO.Git(repos.main))                         # the session checkout
    g = IO.Git(repos.wt)
    head = IO.worktree_check(g)
    (repos.wt / STATUS_REL).write_text('{"oanda_job": {"what": "x"}}\n')
    with pytest.raises(IO.Refused, match="uncommitted"):
        IO.worktree_check(g)
    assert g.commit_push([repos.wt / STATUS_REL], "runner commit")    # only its own commit, HEAD -> dept/stats
    assert git(repos.origin, "rev-parse", "dept/stats") == git(repos.wt, "rev-parse", "HEAD") != head
    (repos.main / "x.txt").write_text("other session\n")              # someone else pushes: HEAD is behind
    git(repos.main, "pull", "-q", "origin", "dept/stats")
    git(repos.main, "add", "x.txt")
    git(repos.main, "commit", "-q", "-m", "other")
    git(repos.main, "push", "-q", "origin", "dept/stats")
    with pytest.raises(IO.Refused, match="is not origin/dept/stats"):
        IO.worktree_check(g)


# ------------------------------------------------------------------ item 4: COST's model, the pass case

@pytest.fixture
def sandbox_cal(tmp_path, monkeypatch):
    csv, meta = S.write_calendar(tmp_path / "cal", run_day="2026-12-07")
    monkeypatch.setattr(C, "CAL_CSV", csv)
    monkeypatch.setattr(C, "CAL_META", meta)
    return tmp_path


def cost_lines(tmp_path, cost=True, rates=None):
    picks = C.load_picks()
    csv, meta = S.write_calendar(tmp_path / "c4", run_day="2026-12-07")
    cal = C.read_calendar(csv, meta)
    cm = fwd_cost.load(C.REPO, cal, rates=rates) if cost else None
    end = C.label_close_ts(DAY)
    res = C.compute_run(picks, cal, S.bars(C.inputs_start(picks), end), end, "T4", cost=cm, run_day=DAY)
    return {(l["pick_id"], C.label_of(l["decision_ts"])): l for l in res.lines}, cm


def test_4_cost_v3_applied_and_lines_marked_below_pass_case(tmp_path):
    lines, cm = cost_lines(tmp_path)
    assert cm.commit == json.loads(C.DEPS.read_text())["cost"]["cost_commit"]
    for l in lines.values():
        for side in ("long", "short"):
            n = l["net"][side]
            fin = n["financing_r45_pips"]
            assert n["cost_v3_ex_financing"] is not None
            assert n["pass_case"] == pytest.approx(min(n["floor_2p0"], n["cost_v3_ex_financing"] - fin), abs=1e-12)
        assert l["below_pass_case"] and any(r.startswith("financing") for r in l["below_pass_case_reasons"])
        assert any(r.startswith("release list") for r in l["below_pass_case_reasons"])
        assert l["cost_model"]["model_sha256"] == cm.model_sha256
    pa = lines[("PA-F4", "2026-10-21")]                               # out 5 minutes before the ECB decision
    rec = pa["recost"]["long"]
    assert cm.cm.slip("EURUSD", rec["exit_ts"], "market") == cm.model["pairs"]["EURUSD"]["slip_release"]
    assert pa["net"]["long"]["pass_case"] < pa["net"]["long"]["floor_2p0"]       # COST's cost binds here
    assert pa["net_pips"] == pa["net"]["long"]["pass_case"]


def test_4_forward_table_refuses_below_pass_case_and_lines_recost(tmp_path):
    lines, cm = cost_lines(tmp_path)
    log = tmp_path / "log.jsonl"
    C.append_log(list(lines.values()), log)
    with pytest.raises(C.BelowPassCase, match="financing"):
        C.forward_table("R53-S3X3", log)
    for l in C.read_log(log):                                         # the stored inputs price the line again
        for side in ("long", "short"):
            again, _ = fwd_cost.price_side(cm, l["recost"][side])
            assert again == l["net"][side]
        assert sum(d["pnl_long"] for d in l["days"]) == pytest.approx(l["net_pips"] / (l["r_pips"] or 1.0), abs=1e-9)


def test_4_complete_release_list_and_rates_clear_the_mark(tmp_path):
    lines, cm = cost_lines(tmp_path)
    _r = {"USD": 4.0, "EUR": 2.0}                                    # a test series, % a year, no range width
    rate = ((lambda ccy, ts: _r[ccy]), (lambda ccy, ts: (_r[ccy], _r[ccy])))   # (rate, rate_range) as COST's lookup
    full = fwd_cost.CostV3(cm.mod, cm.model, cm.model_sha256,
                           {"ts": cm.release_ts, "types": cm.model["events_types_measured"]},
                           {"release_list_complete_for": cm.model_sha256}, rates=rate)
    assert full.reasons == []
    assert fwd_cost.CostV3(cm.mod, cm.model, cm.model_sha256, {"ts": cm.release_ts, "types": ["FOMC_STATEMENT"]},
                           {"release_list_complete_for": cm.model_sha256}, rates=rate).reasons
    if not hasattr(cm.mod, "financing_rows"):
        pytest.skip("COST's cost.py in this checkout predates financing_rows (ac9f8264)")
    # COST's own financing_rows: long EUR/USD pays (USD - EUR) + the pass-case markup a year on the mid, per night held
    mk = float(cm.model["financing"]["markup_pct_year"])
    assert mk >= 1.5                                                   # PASS_BAR v7 section 3: the end that hurts
    assert mk == max(cm.model["financing"].get("markup_range_pct_year", [mk]))
    fc = lines[("FC-1", "2026-11-16")]
    rec = fc["recost"]["long"]
    want = sum(rec["fin_nights"].values()) * rec["mid_entry"] * (4.0 - 2.0 + mk) / 100 / 365 / 1e-4
    assert full.fin_v3(rec) == pytest.approx(want, rel=1e-12)
    n, why = fwd_cost.price_side(full, rec)
    assert why == [] and n["financing_v3_pips"] == pytest.approx(want, rel=1e-12)
    assert n["pass_case"] == pytest.approx(min(n["floor_2p0"], n["cost_v3_ex_financing"] - want), abs=1e-12)
    assert full.fin_v3(fc["recost"]["short"]) < want                    # the short earns the differential


def test_4_cost_pins(tmp_path):
    d = json.loads(C.DEPS.read_text())["cost"]
    repo = tmp_path / "repo"
    for rel in d["files"]:
        (repo / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(C.REPO / rel, repo / rel)
    fwd_cost.check(repo)
    with open(repo / "research/departments/COST/cost.py", "a") as f:
        f.write("\n# changed\n")
    with pytest.raises(C.PinError):
        fwd_cost.check(repo)
    (repo / "research/departments/COST/cost.py").unlink()
    with pytest.raises(C.Refused, match="not in this checkout"):
        fwd_cost.check(repo)


# ------------------------------------------------------------------ item 6: settle only on final calendar rows

def compute_with(tmp_path, name, run_day="2026-12-07", m1=None, **cal_kw):
    picks = C.load_picks()
    csv, meta = S.write_calendar(tmp_path / name, run_day=run_day, **cal_kw)
    cal = C.read_calendar(csv, meta)
    d = date.fromisoformat(run_day)
    end = C.label_close_ts(d)
    m1 = m1 if m1 is not None else S.bars(C.inputs_start(picks), end)
    return C.compute_run(picks, cal, m1, end, f"T-{name}", run_day=d), cal


def test_6_scheduled_rows_never_settle(tmp_path):
    """On 7 Dec the 2 Dec statement is still 'scheduled' (no source read after it): R53's 1 Dec trade and both FC-1
    trades (their cycle ends at 2 Dec) wait; the 2 Dec row is reported as waiting."""
    res, _ = compute_with(tmp_path, "sched",
                          overrides={("FOMC_STATEMENT", "2026-12-02T19:00:00Z"): {"status": "scheduled"}})
    got = {(l["pick_id"], C.label_of(l["decision_ts"])) for l in res.lines}
    assert got == {("R53-S3X3", "2026-10-20"), ("PA-F4", "2026-10-21")}
    assert "FOMC_STATEMENT-2026-12-02" in res.waiting["FC-1"]
    assert res.horizons["FC-1"] == S.utc("2026-11-02T16:00:00")


def test_6_held_needs_a_source_read_after_the_event(tmp_path):
    with pytest.raises(C.CalendarError, match="source read after"):
        compute_with(tmp_path, "early", overrides={("ECB_DECISION", "2026-10-22T12:15:00Z"):
                                                   {"source_read_utc": "2026-10-22T12:00:00Z"}})


def test_6_a_moved_row_refuses_the_run_and_never_drops_the_logged_trade(tmp_path):
    """Red team 3, items 1 and 5 (replaces red team 1's void_after_log): a row behind a logged trade moves; the next
    run refuses (nothing is written) until a ruling is given; with it the logged trade stays in the table."""
    log = tmp_path / "log.jsonl"
    res, cal = compute_with(tmp_path, "first")
    C.append_run(res, log, cal)
    logged = C.forward_table("PA-F4", log, allow_below_pass_case=True)
    moved = {("ECB_DECISION", "2026-10-22T12:15:00Z"): {"utc": "2026-10-23T12:15:00Z", "source_read_utc":
                                                         "2026-10-23T14:00:00Z", "local_date": "2026-10-23"}}
    picks = C.load_picks()
    csv, meta = S.write_calendar(tmp_path / "moved", run_day="2026-12-07", overrides=moved)
    cal2 = C.read_calendar(csv, meta)
    fl = C.floors_from_log(C.read_log(log), picks)
    end = C.label_close_ts(DAY)
    res2 = C.compute_run(picks, cal2, S.bars(C.inputs_start(picks, fl), end), end, "T-moved", floors=fl, run_day=DAY)
    before = log.read_bytes()
    with pytest.raises(C.CalendarChanged, match="ECB_DECISION 2026-10-22T12:15Z"):
        C.append_run(res2, log, cal2)
    assert log.read_bytes() == before
    C.append_run(res2, log, cal2, ruling={"kind": "forward_calendar_ruling", "test": True})
    rows = C.read_log(log)
    assert not [r for r in rows if r["kind"] == "void_after_log"]
    assert [r["kind"] for r in rows if r["kind"] == "calendar_ruled"] == ["calendar_ruled"]
    assert C.forward_table("PA-F4", log, allow_below_pass_case=True).equals(logged)    # kept, whole


# ------------------------------------------------------------------ item 7: calendar financing, no_exit_bar lines

def test_7_financing_nights_from_the_calendar():
    a, b = S.utc("2026-11-16T16:00:00"), S.utc("2026-11-23T16:00:00")
    assert C.fin_nights(a, b) == {"2026-11-16": 1, "2026-11-17": 1, "2026-11-18": 3, "2026-11-19": 1, "2026-11-20": 1}
    # 25 Nov is a Wednesday (3 nights); 26 Nov, US Thanksgiving, is charged although the frozen code's daily bars
    # may drop a thin holiday
    assert C.fin_nights(S.utc("2026-11-25T20:00:00"), S.utc("2026-11-27T20:00:00")) == {"2026-11-25": 3,
                                                                                           "2026-11-26": 1}


def test_7_a_holiday_close_without_bars_is_charged(tmp_path):
    """Bars of the 18 Nov label (a Wednesday) removed: the frozen code's daily bars lose that close (Round 45 charges
    4 pips over FC-1's 16-23 Nov window); the log charges the calendar's 7."""
    picks = C.load_picks()
    end = C.label_close_ts(DAY)
    m1 = S.bars(C.inputs_start(picks), end)
    keep = C.bar_labels(m1["ts_utc"]) != "2026-11-18"
    m1 = {k: v[keep] for k, v in m1.items()}
    res, _ = compute_with(tmp_path, "hol", m1=m1)
    fc = next(l for l in res.lines if l["pick_id"] == "FC-1" and C.label_of(l["decision_ts"]) == "2026-11-16")
    assert fc["net"]["long"]["financing_r45_pips"] == 7.0
    assert fc["net"]["long"]["floor_2p0"] == pytest.approx(-2.0 - 7.0, abs=1e-9)    # flat mid: -2.0 floor


def test_7_a_missing_exit_bar_is_logged(tmp_path):
    picks = C.load_picks()
    end = C.label_close_ts(DAY)
    m1 = S.bars(C.inputs_start(picks), end)
    hole = (m1["ts_utc"] >= S.utc("2026-10-22T12:05:00")) & (m1["ts_utc"] < S.utc("2026-10-22T12:40:00"))
    m1 = {k: v[~hole] for k, v in m1.items()}
    res, _ = compute_with(tmp_path, "hole", m1=m1)
    pa = [l for l in res.lines if l["pick_id"] == "PA-F4"]
    assert [(l["kind"], l["reason"]) for l in pa] == [("no_exit_bar", "no_exit_bar")]
    assert pa[0]["sched_exit_ts"] == S.utc("2026-10-22T12:10:00") and "net_pips" not in pa[0]


# ------------------------------------------------------------------ item 11: per-pick isolation, 1.6 and 2.0 logged

def test_11_one_picks_calendar_error_does_not_stop_the_others(tmp_path):
    rows = [r for r in S.CAL_ROWS if r != ("ECB_DECISION", "2026-12-10T13:15:00Z")]   # no ECB decision after 7 Dec
    res, _ = compute_with(tmp_path, "noecb", rows=rows)
    assert res.errors == {"PA-F4": "CalendarError"}
    err = [l for l in res.lines if l["kind"] == "error"]
    assert len(err) == 1 and err[0]["pick_id"] == "PA-F4" and "ECB" in err[0]["message"]
    assert {l["pick_id"] for l in trades(res.lines)} == {"R53-S3X3", "FC-1"}


def test_11_runner_goes_on_with_a_pick_error(tmp_path, monkeypatch):
    rows = [r for r in S.CAL_ROWS if r != ("ECB_DECISION", "2026-12-10T13:15:00Z")]
    csv, meta = S.write_calendar(tmp_path / "cal", rows=rows, run_day="2026-12-07")
    monkeypatch.setattr(C, "CAL_CSV", csv)
    monkeypatch.setattr(C, "CAL_META", meta)
    ops = FakeOps(tmp_path)
    r = RF.run(DAY, ops, now=NOW)
    assert r["pick_errors"] == {"PA-F4": "CalendarError"} and r["new_lines"] == 4
    assert ops.access_rows[-1]["pick_errors"] == {"PA-F4": "CalendarError"}
    state = C.read_log(ops.log)[-1]
    assert state["next_floor"]["PA-F4"] == C.FORWARD_START               # an errored pick keeps its floor


def test_11_nets_at_1_6_and_2_0_logged(tmp_path):
    lines = {(l["pick_id"], C.label_of(l["decision_ts"])): l for l in run_to("2026-12-07", tmp_path)[0].lines}
    pa = lines[("PA-F4", "2026-10-21")]["net"]["long"]
    assert pa["floor_2p0"] == pytest.approx(25.0, abs=1e-9) and pa["floor_1p6"] == pytest.approx(25.4, abs=1e-9)


# ------------------------------------------------------------------ item 5: downloads start at the floors

def test_5_floors_move_the_download_start(tmp_path):
    log = tmp_path / "log.jsonl"
    res, cal, start1 = run_to("2026-11-10", tmp_path, log=log)
    C.append_run(res, log, cal)
    picks = C.load_picks()
    floors = C.floors_from_log(C.read_log(log), picks)
    start2 = C.inputs_start(picks, floors)
    assert start1 == S.ny("2026-09-03", "17:00") < start2
    lag = {p["id"]: p["lookback_days"] for p in picks}
    assert start2 == min(C.label_close_ts(date.fromisoformat(C.label_of(f)) - timedelta(days=1 + lag[p]))
                         for p, f in floors.items())
    with pytest.raises(C.OutcomeGuardError):                               # the 400-day cap stays
        C.inputs_start([{"id": "X", "lookback_days": 401}])
    assert np.isfinite(start2)


def test_3_tree_hash_recipe(tmp_path):
    """The tree hash is the documented recipe: sha256 of '<file sha256>  <path>' lines sorted by path."""
    (tmp_path / "a").write_text("1")
    (tmp_path / "b").write_text("2")
    want = hashlib.sha256(("".join(f"{hashlib.sha256(t.encode()).hexdigest()}  {n}\n"
                                   for n, t in (("a", "1"), ("b", "2")))).encode()).hexdigest()
    assert IO.tree_sha256(tmp_path, ["b", "a"]) == want
