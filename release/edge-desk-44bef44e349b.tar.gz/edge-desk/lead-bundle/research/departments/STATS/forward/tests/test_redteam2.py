"""One test (or more) per finding of RED_TEAM.md red team 2; each fails if its fix is removed. Git tests run on local
bare repositories under tmp_path (no network); the downloader tests on DATA's code with a fake HTTP layer."""
import json
import os
from datetime import datetime, timezone

import pytest

import fwd_core as C
import fwd_cost
import fwd_io as IO
import fwd_register as REG
import run_forward as RF
import synth as S
from test_io import DAY, NOW, FakeGit, FakeOps, data_code, fake_candles, sandbox  # noqa: F401  (fixtures)
from test_redteam import fwd_tree, git, hashed, repos, GateGit  # noqa: F401  (fixtures)
from test_register import fake_loaders

LID = "STATS-FWD-20261126T000000Z-abc123"


def pushed(lid=LID):
    return FakeGit(stats_access=json.dumps({"kind": "forward_run_start", "ledger_id": lid}) + "\n")


# ------------------------------------------------------------------ 1: requests counted when the Fetcher raises

def test_r2_1_requests_reach_the_meter_when_the_fetcher_raises(data_code, monkeypatch, tmp_path):
    """DATA's Fetcher stops on an HTTP 404 at the 3rd request: the meter still holds the 3 requests sent and their UTC
    day, so the closing line counts them."""
    calls = fake_candles(monkeypatch, data_code, fail_from=3)
    start = S.ny("2026-09-03", "17:00")
    meter = {}
    with pytest.raises(RuntimeError, match="HTTP 404"):
        IO.download_step(pushed(), LID, start, start + 10 * 5000 * 60, tmp_path / "dl", meter=meter)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    assert len(calls) == 3 and meter == {"requests": 3, "requests_by_utc_day": {today: 3}}


def test_r2_1_the_closing_line_carries_the_meter_on_failure(sandbox):
    ops = FakeOps(sandbox, download_error=RuntimeError("HTTP 500 x3"))
    with pytest.raises(RuntimeError):
        RF.run(DAY, ops, now=NOW)
    done = ops.access_rows[-1]
    assert done["kind"] == "forward_run_done" and done["status"] == "failed: RuntimeError"
    assert done["requests"] == 3 and done["requests_by_utc_day"] == {"2026-12-08": 2, "2026-12-09": 1}


def test_r2_1_unknown_or_killed_runs_count_every_day_they_touched():
    lines = [{"kind": "forward_run_start", "ledger_id": "K", "utc": "2026-12-07T23:59:00Z"},
             {"kind": "forward_stale_lock_cleared", "cleared_ledger_id": "K", "utc": "2026-12-08T08:00:00Z"},
             {"kind": "forward_run_start", "ledger_id": "U", "utc": "2026-12-09T23:58:00Z"},
             {"kind": "forward_run_done", "ledger_id": "U", "utc": "2026-12-10T00:03:00Z", "requests": None},
             {"kind": "forward_run_start", "ledger_id": "OPEN", "utc": "2026-12-11T10:00:00Z"}]
    got = IO.pushed_requests_by_day(lines, exclude="NOW", today="2026-12-12")
    assert got == {"2026-12-07": 30, "2026-12-08": 30, "2026-12-09": 30, "2026-12-10": 30,
                   "2026-12-11": 30, "2026-12-12": 30}


# ------------------------------------------------------------------ 3: ignored files in the runner's worktree

def test_r2_3_ignored_files_refused_except_pycache(repos):
    g = IO.Git(repos.wt)
    d = repos.wt / IO.FWD_REL
    (d / "__pycache__").mkdir(parents=True)
    (d / "__pycache__" / "fwd_core.cpython-313.pyc").write_bytes(b"x")
    IO.worktree_check(g)                                              # compiled caches are allowed
    (d / "numpy.pyc").write_bytes(b"x")                               # would shadow numpy for code in forward/
    with pytest.raises(IO.Refused, match="ignored"):
        IO.worktree_check(g)
    assert g.unclean([IO.FWD_REL]) == [f"!! {IO.FWD_REL}/numpy.pyc"]
    (d / "numpy.pyc").unlink()
    (repos.wt / ".pytest_cache").mkdir()
    (repos.wt / ".pytest_cache" / "v").write_text("x")
    with pytest.raises(IO.Refused, match="ignored"):
        IO.worktree_check(g)


# ------------------------------------------------------------------ 4: orphan check before any push

def test_r2_4_no_push_of_a_locked_branch_that_shares_history(repos):
    """A local dept/stats-locked made from dept/stats history is refused before anything reaches origin."""
    git(repos.main, "branch", "dept/stats-locked", "origin/dept/stats")
    ll = IO.LockedLog(IO.Git(repos.wt), repos.tmp / "stats-locked-wt")
    with pytest.raises(IO.Refused, match="orphan"):
        ll.open()
    assert git(repos.origin, "ls-remote", "--heads", ".", "dept/stats-locked") == ""


def test_r2_4_no_merge_or_push_onto_an_origin_that_shares_history(repos):
    ll = IO.LockedLog(IO.Git(repos.wt), repos.tmp / "stats-locked-wt")
    log = ll.open()
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text('{"kind": "trade"}\n')
    git(repos.main, "push", "-q", "-f", "origin", "origin/dept/stats:refs/heads/dept/stats-locked")   # tampered
    head = git(repos.origin, "rev-parse", "dept/stats-locked")
    with pytest.raises(IO.Refused, match="orphan"):
        ll.publish("x")
    assert git(repos.origin, "rev-parse", "dept/stats-locked") == head


# ------------------------------------------------------------------ 5: locked_dir outside every checkout

def test_r2_5_locked_dir_refuses_the_session_checkout(repos, monkeypatch):
    monkeypatch.setattr(C, "REPO", repos.wt)                          # the runner's worktree
    assert REG.locked_dir(fake_loaders(repos.tmp / "fxroot")) == (repos.tmp / "fxroot/stats_locked").resolve()
    with pytest.raises(C.Refused, match="outside the repo"):
        REG.locked_dir(fake_loaders(repos.main / "fxroot"))           # inside the session checkout


# ------------------------------------------------------------------ 6: a stopped run's uncommitted lines

def test_r2_6_uncommitted_leftovers_are_discarded_and_noted(repos):
    g = IO.Git(repos.wt)
    ll = IO.LockedLog(g, repos.tmp / "stats-locked-wt")
    log = ll.open()
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text('{"kind": "trade", "x": 1}\n')
    assert ll.publish("first")[0]
    with open(log, "a") as f:                                         # a run stopped before its commit
        f.write('{"kind": "trade", "x": 2}\n{"kind": "run_state"}\n')
    ll2 = IO.LockedLog(g, repos.tmp / "stats-locked-wt")
    assert ll2.open() == log and ll2.discarded == 2
    assert C.read_log(log) == [{"kind": "trade", "x": 1}] and not ll2.git.status()
    (log.parent / "stray.txt").write_text("x")
    with pytest.raises(IO.Refused, match="other than the log"):
        IO.LockedLog(g, repos.tmp / "stats-locked-wt").open()


def test_r2_6_the_run_records_the_discard(sandbox):
    ops = FakeOps(sandbox, discarded=2)
    RF.run(DAY, ops, now=NOW)
    note = [l for l in C.read_log(ops.log) if l["kind"] == "discarded_uncommitted"]
    assert len(note) == 1 and note[0]["lines"] == 2
    assert ops.access_rows[0]["locked_leftovers_discarded"] is True


# ------------------------------------------------------------------ 7: covered = saved bars; rotation

def test_r2_7_covered_ends_at_the_last_saved_bar(data_code, monkeypatch, tmp_path):
    """The download stops early at an incomplete candle (the live edge): covered_to is the last saved bar + 60, not
    the end of the windows asked for."""
    fake_candles(monkeypatch, data_code, incomplete_at=2)
    start = S.ny("2026-09-03", "17:00")
    dl = IO.download_step(pushed(), LID, start, start + 4 * 5000 * 60, tmp_path / "dl")
    assert dl["covered_to"] == data_code.last_saved(dl["path"]) + 60 < start + 2 * 5000 * 60


def test_r2_7_a_file_starting_long_before_the_window_is_rotated(data_code, monkeypatch, tmp_path):
    """A contiguous local file whose first bar is more than 60 days before the needed start is set aside and the
    window fetched again, so the runner never keeps reading settled trades' lag rows."""
    fake_candles(monkeypatch, data_code)
    d = tmp_path / "dl"
    start = S.ny("2026-09-03", "17:00")
    IO.download_step(pushed(), LID, start, start + 2 * 5000 * 60, d)
    assert not list(d.glob("EURUSD_M1_BA.rotated-*"))
    (d / "FILE_STATE.json").write_text(json.dumps({"file": "EURUSD_M1_BA.csv", "first_ts": start - 61 * 86400}))
    dl = IO.download_step(pushed(), LID, start, start + 3 * 5000 * 60, d)
    assert len(list(d.glob("EURUSD_M1_BA.rotated-*"))) == 1
    assert json.loads((d / "FILE_STATE.json").read_text())["first_ts"] == start
    assert dl["covered_to"] > start


# ------------------------------------------------------------------ 8: the calendar outside the hashed tree, pinned

def test_r2_8_calendar_outside_the_hash_but_pinned(fwd_tree):
    repo, files = fwd_tree
    g = GateGit(files)
    tree = IO.tree_sha256(repo, hashed(files))
    (repo / IO.FWD_REL / "RED_TEAM.md").write_text(f"approved_tree_sha256: {tree}\n")
    cal = repo / IO.CAL_PIN_RELS[0]
    pin = repo / IO.CAL_PIN_RELS[1]
    assert IO.gate(g, repo, check_code=False)["calendar_sha256"] == C.sha256_file(pin)
    cal.write_text("event_id,type\nA,FOMC_STATEMENT\n")              # a calendar update: the code hash is unchanged
    assert IO.tree_sha256(repo, IO.forward_files(g)) == tree
    with pytest.raises(IO.Refused, match="differs from its pin"):
        IO.gate(g, repo, check_code=False)
    pin.write_text(json.dumps({"status": "sourced", "sha256": C.sha256_file(cal), "source": {}}))
    with pytest.raises(IO.Refused, match="data_commit"):
        IO.gate(g, repo, check_code=False)
    src = {"data_commit": "d" * 40, "path": "research/departments/DATA/forward/FORWARD_EVENTS.csv"}
    pin.write_text(json.dumps({"status": "sourced", "sha256": C.sha256_file(cal), "source": src}))
    with pytest.raises(IO.Refused, match="not the file at source.data_commit"):     # DATA's file not shown
        IO.gate(g, repo, check_code=False)
    g.blobs[("d" * 40, src["path"])] = b"event_id,type\nA,FOMC_STATEMENT\n"          # the calendar written above
    assert IO.gate(g, repo, check_code=False)["tree_sha256"] == tree  # a new pin, no new code approval
    g.anc = False
    with pytest.raises(IO.Refused):
        IO.gate(g, repo, check_code=False)


# ------------------------------------------------------------------ COST pins refused by audit_inputs

def test_r2_cost_pin_refused_by_audit_inputs(monkeypatch):
    fwd_cost.check(C.REPO)
    ai = fwd_cost.audit_inputs()
    assert ai.__file__ and os.path.samefile(ai.__file__, C.STATS / "audit_inputs.py")
    sha = json.loads(C.DEPS.read_text())["cost"]["files"]["research/departments/COST/cost.py"]
    monkeypatch.setitem(ai.REFUSED, sha, "test: COST cost.py v3 superseded by v3.1")
    with pytest.raises(C.Refused, match="audit_inputs.REFUSED"):
        fwd_cost.check(C.REPO)
