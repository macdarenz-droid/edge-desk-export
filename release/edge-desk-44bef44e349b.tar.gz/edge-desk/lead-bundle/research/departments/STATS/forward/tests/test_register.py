"""fwd_register.py, the only forward/ file that uses the loaders' data root and registry fields. Like it, this file
calls no raw reader (research/common/tests/test_core_guard.py); the end-to-end read is in test_io.py."""
import os
from types import SimpleNamespace

import pytest

import fwd_core as C
import fwd_register as REG


def fake_loaders(root, entries=()):
    return SimpleNamespace(data_root=lambda: root, registry=lambda: {e["name"]: dict(e) for e in entries})


def test_locked_dir_is_outside_the_repo(tmp_path):
    assert REG.locked_dir(fake_loaders(tmp_path)) == tmp_path.resolve() / "stats_locked"
    for inside in (C.REPO, C.REPO / "research", C.REPO / "research/departments/STATS"):
        with pytest.raises(C.Refused, match="outside the repo"):
            REG.locked_dir(fake_loaders(inside))


def test_register_points_the_loaders_at_a_file_under_the_root(tmp_path, monkeypatch):
    monkeypatch.setenv(REG.DATASETS_ENV, "")
    f = tmp_path / "stats_locked" / "forward" / "bars.txt"
    f.parent.mkdir(parents=True)
    f.write_text("ts_utc\n")
    reg = REG.register(fake_loaders(tmp_path), f, 1786830000, 1791579599)
    assert reg == f.parent / "datasets.json" and reg.is_file() and os.environ[REG.DATASETS_ENV] == str(reg)
    with pytest.raises(ValueError):                                     # a file outside the data root
        REG.register(fake_loaders(tmp_path / "elsewhere"), f, 1786830000, 1791579599)


def test_held_locally_needs_every_overlapping_unlocked_set(tmp_path):
    a = {"name": "A", "instrument": "EUR_USD", "granularity": "M1", "price": "BA", "locked": False,
         "first_ts": 0, "last_ts": 99, "relpath": "a/A.txt"}
    b = {**a, "name": "B", "first_ts": 100, "last_ts": 199, "relpath": "b/B.txt"}
    c = {**a, "name": "C", "first_ts": 200, "last_ts": 299, "relpath": "c/C.txt", "locked": True}
    m5 = {**a, "name": "M5", "granularity": "M5", "relpath": "m5/M5.txt"}
    L = fake_loaders(tmp_path, [a, b, c, m5])
    assert not REG.held_locally(L, "EUR_USD", 0, 100)
    (tmp_path / "a").mkdir()
    (tmp_path / "a/A.txt").write_text("")
    assert REG.held_locally(L, "EUR_USD", 0, 100)                       # only A overlaps [0, 100); M5 is not M1
    assert not REG.held_locally(L, "EUR_USD", 50, 150)                  # B overlaps and is missing
    (tmp_path / "b").mkdir()
    (tmp_path / "b/B.txt").write_text("")
    assert REG.held_locally(L, "EUR_USD", 50, 300)                      # the locked set C is never counted
    assert not REG.held_locally(L, "GBP_USD", 0, 300)                   # nothing registered
