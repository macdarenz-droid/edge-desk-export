"""Red team 3 (forward/RED_TEAM.md): one test (or more) per finding, each failing if its fix is removed. The red team's
proofs (rt3_forward/test_rt3_poc.py) restated as repo tests. Synthetic bars and calendars, temporary git repositories
with local bare origins; no network, no real data, no token."""
import ast
import json
import os
import re
import subprocess
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path

import numpy as np
import pytest

import fwd_core as C
import fwd_cost
import fwd_io as IO
import run_forward as RF
import synth as S
from test_io import (DAY, NOW, OPEN_LID, URL, FakeGit, FakeOps, StatsOrigin, _git, data_code, fake_candles,  # noqa: F401
                     sandbox)
from test_redteam import GITHUB, GateGit, fwd_tree, git, hashed, repos  # noqa: F401  (fixtures)

ECB_MOVED = {("ECB_DECISION", "2026-10-22T12:15:00Z"): {"utc": "2026-10-23T12:15:00Z",
                                                        "source_read_utc": "2026-10-23T14:00:00Z",
                                                        "local_date": "2026-10-23"}}
RENAMED = {("FOMC_STATEMENT", "2026-10-21T18:00:00Z"): {"event_id": "FOMC-20261021"},
           ("ECB_DECISION", "2026-10-22T12:15:00Z"): {"event_id": "ECB-20261022"}}


def run(tmp, name, overrides=None, floors=None, run_day=DAY):
    picks = C.load_picks()
    csv, meta = S.write_calendar(tmp / name, run_day=run_day.isoformat(), overrides=overrides)
    cal = C.read_calendar(csv, meta)
    end = C.label_close_ts(run_day)
    res = C.compute_run(picks, cal, S.bars(C.inputs_start(picks, floors), end), end, f"RT3-{name}", floors=floors,
                        run_day=run_day)
    return res, cal


def second_run(tmp, log, overrides, name, run_day=DAY):
    floors = C.floors_from_log(C.read_log(log), C.load_picks())        # the runner's way: floors from the last run_state
    return run(tmp, name, overrides=overrides, floors=floors, run_day=run_day)


def positions(log, pick):
    return sorted(C.forward_table(pick, log, allow_below_pass_case=True).position_id.unique())


# ------------------------------------------------------------------ 1 and 5: a calendar change never drops a position

def test_rt3_1_a_moved_row_refuses_until_ruled_and_the_logged_trade_stays(tmp_path):
    """PoC f1 (moved ECB row): the logged PA-F4 trade was voided and never replaced. Now the run refuses before
    writing anything, and with a ruling the trade stays in the table, unchanged."""
    log = tmp_path / "log.jsonl"
    res, cal = run(tmp_path, "first")
    C.append_run(res, log, cal)
    before = positions(log, "PA-F4")
    assert len(before) == 1
    res2, cal2 = second_run(tmp_path, log, ECB_MOVED, "moved")
    with pytest.raises(C.CalendarChanged, match="ECB_DECISION 2026-10-22"):
        C.append_run(res2, log, cal2)
    C.append_run(res2, log, cal2, ruling={"kind": "forward_calendar_ruling", "id": "test"})
    rows = C.read_log(log)
    assert positions(log, "PA-F4") == before
    assert not [r for r in rows if r["kind"] == "void_after_log"]
    ruled = [r for r in rows if r["kind"] == "calendar_ruled"]
    assert len(ruled) == 1 and ruled[0]["ruling"]["id"] == "test" and ruled[0]["changes"]


def test_rt3_1_an_event_id_rename_alone_changes_nothing(tmp_path):
    """PoC f1 (rename): same times and statuses, new event ids. Rows are compared by time and status only: no change,
    no refusal, every logged position kept."""
    log = tmp_path / "log.jsonl"
    res, cal = run(tmp_path, "first")
    C.append_run(res, log, cal)
    table = {p: positions(log, p) for p in ("R53-S3X3", "PA-F4", "FC-1")}
    assert table["R53-S3X3"] and table["PA-F4"] and table["FC-1"]
    res2, cal2 = second_run(tmp_path, log, RENAMED, "renamed")
    assert C.calendar_changes(C.read_log(log), cal2) == []
    C.append_run(res2, log, cal2)
    assert {p: positions(log, p) for p in table} == table


def test_rt3_1_snapshot_changes_by_time_and_status():
    """scheduled -> held and rows added after the known range are the calendar's normal updates; a moved, removed,
    cancelled, re-scheduled or inserted row is a change; event ids are not compared."""
    f, e = "FOMC_STATEMENT", "ECB_DECISION"
    old = [[f, 100, "held"], [f, 200, "scheduled"], [e, 150, "scheduled"]]
    assert C.snapshot_changes(old, [[f, 100, "held"], [f, 200, "held"], [f, 300, "scheduled"], [e, 150, "held"]]) == []
    for new, what in ((old[:1] + [[f, 201, "scheduled"], old[2]], "moved"),
                      ([old[0], old[2]], "removed"),
                      ([old[0], [f, 200, "cancelled"], old[2]], "cancelled"),
                      ([[f, 100, "scheduled"], old[1], old[2]], "held back to scheduled"),
                      (old + [[f, 150, "scheduled"]], "inserted inside the range"),
                      (old + [[e, None, "cancelled"]], "a cancelled row without a time")):
        assert C.snapshot_changes(old, new), what


def test_rt3_5_a_row_behind_an_open_decision_refuses(tmp_path):
    """Red team 3, item 5: on 20 Oct (run after the close) R53's decision of 20 Oct 14:00 is open (its 21 Oct statement
    is ahead). The statement then moves to 28 Oct: the decision really taken would silently vanish from the plan.
    The next run refuses instead."""
    log = tmp_path / "log.jsonl"
    d1 = date(2026, 10, 20)
    res, cal = run(tmp_path, "day1", run_day=d1)
    C.append_run(res, log, cal)
    assert res.horizons["R53-S3X3"] == S.ny("2026-10-20", "14:00")          # open: not yet settled
    moved = {("FOMC_STATEMENT", "2026-10-21T18:00:00Z"): {"utc": "2026-10-28T18:00:00Z", "local_date": "2026-10-28",
                                                          "status": "scheduled", "source_read_utc": "2026-09-01T00:00:00Z"}}
    res2, cal2 = second_run(tmp_path, log, moved, "day2", run_day=date(2026, 10, 23))
    with pytest.raises(C.CalendarChanged, match="FOMC_STATEMENT 2026-10-21"):
        C.append_run(res2, log, cal2)


def test_rt3_1_the_runner_refuses_a_changed_calendar_before_spending(sandbox, monkeypatch):
    """run_forward: the change is found right after the locked log is opened, before the start line: nothing pushed,
    nothing downloaded. A pushed ruling (here FakeOps') lets the run go on, and append_run records it."""
    ops = FakeOps(sandbox)
    RF.run(DAY, ops, now=NOW)
    csv, meta = S.write_calendar(sandbox / "cal2", run_day="2026-12-07", overrides=ECB_MOVED)
    monkeypatch.setattr(C, "CAL_CSV", csv)
    monkeypatch.setattr(C, "CAL_META", meta)
    ops2 = FakeOps(sandbox, log=ops.log)
    with pytest.raises(C.CalendarChanged, match="FORWARD_RULINGS.jsonl"):
        RF.run(DAY, ops2, now=NOW)
    assert ops2.calls == ["gate", "stats_lock", "lock", "blocks", "cost", "locked_open", "ruling"]
    ops3 = FakeOps(sandbox, log=ops.log, ruling={"kind": "forward_calendar_ruling", "id": "R-1"})
    RF.run(DAY, ops3, now=NOW)
    assert any(r["kind"] == "calendar_ruled" and r["ruling"]["id"] == "R-1" for r in C.read_log(ops.log))


def test_rt3_1_a_ruling_counts_only_pushed_and_for_the_exact_change(tmp_path):
    so = StatsOrigin(tmp_path / "so")
    g = IO.Git(so.work)
    line = {"kind": "forward_calendar_ruling", "from_calendar_sha256": "a" * 64, "to_calendar_sha256": "b" * 64}
    p = so.work / IO.RULINGS_REL
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(line) + "\n")                                   # written, not pushed
    assert IO.calendar_ruling(g, "a" * 64, "b" * 64) is None
    p.unlink()
    so.push(IO.RULINGS_REL, line)
    assert IO.calendar_ruling(g, "a" * 64, "b" * 64) == line
    assert IO.calendar_ruling(g, "a" * 64, "c" * 64) is None and IO.calendar_ruling(g, None, "b" * 64) is None


def test_rt3_1_the_calendar_pin_is_datas_file_byte_for_byte(fwd_tree):
    repo, files = fwd_tree
    tree = IO.tree_sha256(repo, hashed(files))
    (repo / IO.FWD_REL / "RED_TEAM.md").write_text(f"approved_tree_sha256: {tree}\n")
    cal, pin = repo / IO.CAL_PIN_RELS[0], repo / IO.CAL_PIN_RELS[1]
    cal.write_text("event_id,type\nA,FOMC_STATEMENT\n")
    src = {"data_commit": "d" * 40, "path": "research/departments/DATA/forward/FORWARD_EVENTS.csv"}
    pin.write_text(json.dumps({"status": "sourced", "sha256": C.sha256_file(cal), "source": src}))
    g = GateGit(files, blobs={("d" * 40, src["path"]): b"event_id,type\nA,FOMC_STATEMENT\nB,ECB_DECISION\n"})
    with pytest.raises(IO.Refused, match="not the file at source.data_commit"):     # an edited copy
        IO.gate(g, repo, check_code=False)
    g.blobs[("d" * 40, src["path"])] = b"event_id,type\nA,FOMC_STATEMENT\n"          # the calendar written above
    IO.gate(g, repo, check_code=False)
    pin.write_text(json.dumps({"status": "sourced", "sha256": C.sha256_file(cal), "source": {"data_commit": "d" * 40}}))
    with pytest.raises(IO.Refused, match="no source.path"):
        IO.gate(g, repo, check_code=False)


# ------------------------------------------------------------------ 2: no forward number outside a test

def test_rt3_2_forward_numbers_are_refused_outside_the_test_path(tmp_path, monkeypatch):
    """PoC f2: forward_table returned forward rows with no declaration and no look, and a verdict took any alpha.
    Without the test-only path every call is refused, before the log is read (here a folder: reading it would raise
    something else), whatever test id is given."""
    monkeypatch.setattr(C, "_TEST_ONLY_LOOKS", None)
    r = {"net_total": 1.0, "p_net": 0.04, "p_random_side": 0.04, "p_same_tilt": 0.04, "p_shift": 0.04, "block": 5}
    for tid in (None, "FWD-TEST-1"):
        with pytest.raises(C.Refused, match="no forward number"):
            C.forward_table("R53-S3X3", tmp_path, allow_below_pass_case=True, test_id=tid)
        with pytest.raises(C.Refused, match="no forward number"):
            C.forward_verdict(r, 0.05, test_id=tid)
        with pytest.raises(C.Refused, match="no forward number"):
            C.forward_verdicts(r, r, 0.05, test_id=tid)


def test_rt3_2_the_look_is_recorded_before_any_number(tmp_path):
    with pytest.raises(IsADirectoryError):
        C.forward_table("R53-S3X3", tmp_path, allow_below_pass_case=True, test_id="T")
    assert C._TEST_ONLY_LOOKS == [{"what": "forward_table R53-S3X3", "test_id": "T"}]


def test_rt3_2_a_non_pytest_main_is_refused_even_with_the_test_path_set(tmp_path):
    """A plain python3 main that sets fwd_core._TEST_ONLY_LOOKS gets no forward number: the path counts only when the
    main program is pytest (research.common.access.main_info)."""
    script = tmp_path / "try_forward.py"
    script.write_text(f"""import sys
sys.path.insert(0, {str(C.HERE)!r})
import fwd_core as C
C._TEST_ONLY_LOOKS = []
r = {{"net_total": 1.0, "p_net": 0.0, "p_random_side": 0.0, "p_same_tilt": 0.0, "p_shift": 0.0, "block": 5}}
out = []
for f in (lambda: C.forward_verdict(r, 0.05, "T"), lambda: C.forward_verdicts(r, r, 0.05, "T"),
          lambda: C.forward_table("R53-S3X3", {str(tmp_path)!r}, True, test_id="T")):
    try:
        f()
        out.append("NUMBER")
    except C.Refused:
        out.append("refused")
print(",".join(out), len(C._TEST_ONLY_LOOKS))
""")
    env = {k: v for k, v in os.environ.items() if not k.startswith("OANDA_")}
    r = subprocess.run([sys.executable, str(script)], capture_output=True, text=True, env=env, timeout=300)
    assert r.returncode == 0, r.stderr
    assert r.stdout.split() == ["refused,refused,refused", "0"]


def test_rt3_2_production_code_never_reaches_the_test_path():
    """No runner file names the test-only path or calls the forward number functions: only fwd_core defines them and
    only the tests' conftest sets _TEST_ONLY_LOOKS."""
    names = {"_TEST_ONLY_LOOKS", "forward_table", "forward_verdict", "forward_verdicts", "forward_look"}
    for f in sorted(C.HERE.glob("*.py")):
        if f.name == "fwd_core.py":
            continue
        used = {n.id for n in ast.walk(ast.parse(f.read_text())) if isinstance(n, ast.Name)} | \
               {n.attr for n in ast.walk(ast.parse(f.read_text())) if isinstance(n, ast.Attribute)}
        assert not used & names, (f.name, used & names)
    setters = [f.name for f in (C.HERE / "tests").glob("*.py") if "_TEST_ONLY_LOOKS\", []" in f.read_text()]
    assert setters == ["conftest.py"]


# ------------------------------------------------------------------ 3 and 9: blocks on any origin branch, and kept

def _push_branch_file(so, branch, rel, text):
    _git(so.main, "checkout", "-q", "-B", branch)
    p = so.main / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)
    _git(so.main, "add", "-A")
    _git(so.main, "commit", "-q", "-m", f"{rel} on {branch}")
    _git(so.main, "push", "-q", "-f", "origin", f"HEAD:refs/heads/{branch}")


def _block_line(host_url, status=429, age_s=3600):
    when = datetime.fromtimestamp(time.time() - age_s, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return json.dumps({"utc": when, "source": "oanda_download", "url": host_url, "status": status}) + "\n"


@pytest.mark.parametrize("branch,rel", [("dept/data", "research/departments/DATA/FETCH_LOG.jsonl"),
                                        ("dept/events", "research/departments/EVENTS/FETCH_LOG.jsonl"),
                                        (IO.COORD_BRANCH, "research/departments/MACRO/FETCH_LOG.jsonl")])
def test_rt3_3_a_block_on_another_origin_branch_refuses_before_any_request(data_code, monkeypatch, tmp_path, branch,
                                                                          rel):
    """PoC f3: DATA's 429 from the candles host, an hour old, on origin/dept/data only. The Fetcher read only the
    checkout's logs. Now every FETCH_LOG on origin/dept/* and the coordinator branch is read first."""
    calls = fake_candles(monkeypatch, data_code)
    so, start = data_code.stats_origin, S.ny("2026-09-03", "17:00")
    _push_branch_file(so, branch, rel, _block_line("https://api-fxpractice.oanda.com/v3/instruments/USD_JPY/candles"))
    with pytest.raises(IO.Refused, match="blocked: .*api-fxpractice.oanda.com"):
        IO.download_step(IO.Git(so.work), OPEN_LID, start, start + 2 * 5000 * 60, tmp_path / "dl")
    assert calls == []


def test_rt3_3_an_old_block_or_another_host_does_not_refuse(data_code, monkeypatch, tmp_path):
    calls = fake_candles(monkeypatch, data_code)
    so, start = data_code.stats_origin, S.ny("2026-09-03", "17:00")
    _push_branch_file(so, "dept/data", "research/departments/DATA/FETCH_LOG.jsonl",
                      _block_line("https://api-fxpractice.oanda.com/v3/instruments/USD_JPY/candles", age_s=25 * 3600)
                      + _block_line("https://www.bls.gov/x"))
    assert IO.download_step(IO.Git(so.work), OPEN_LID, start, start + 2 * 5000 * 60, tmp_path / "dl")["requests"] == 2
    assert len(calls) == 2


def test_rt3_9_a_block_line_is_kept_in_the_data_dir(data_code, monkeypatch, tmp_path):
    """A 403 is written to STATS's FETCH_LOG and also to the data dir's copy: if the commit holding it is dropped (the
    checkout's file goes), the next download is still refused before any request."""
    calls = fake_candles(monkeypatch, data_code, fail_from=2, fail_status=403)
    start, dl = S.ny("2026-09-03", "17:00"), tmp_path / "dl"
    g = FakeGit(stats_access=json.dumps({"kind": "forward_run_start", "ledger_id": OPEN_LID}) + "\n")
    with pytest.raises(RuntimeError, match="24 hours"):
        IO.download_step(g, OPEN_LID, start, start + 4 * 5000 * 60, dl)
    read_text = C.checked_reader("read_text")
    kept = read_text(dl / IO.FETCH_LOG_NAME).splitlines()
    assert kept == read_text(IO.FETCH_LOG).splitlines() and json.loads(kept[0])["status"] == 403
    IO.FETCH_LOG.unlink()                                                   # the local commit dropped
    with pytest.raises(IO.Refused, match="blocked"):
        IO.download_step(g, OPEN_LID, start, start + 4 * 5000 * 60, dl)
    assert len(calls) == 2


def test_rt3_9_unpushed_commits_refuse_the_start(repos):
    g = IO.Git(repos.wt)
    IO.worktree_check(g)
    (repos.wt / "research/departments/STATS/FETCH_LOG.jsonl").write_text('{"status": 403}\n')
    (repos.wt / IO.ACCESS_LOG_REL).write_text(json.dumps({"kind": "forward_run_done", "ledger_id": OPEN_LID}) + "\n")
    git(repos.wt, "add", "-A")
    git(repos.wt, "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", "closing commit, push failed")
    with pytest.raises(IO.Refused, match="closing commit not on origin/dept/stats .*push it"):
        IO.worktree_check(g)


def test_rt3_9_gate_refuses_a_head_ahead_of_origin(fwd_tree):
    repo, files = fwd_tree
    closing = json.dumps({"kind": "forward_run_done", "ledger_id": OPEN_LID}).encode() + b"\n"
    g = GateGit(files, remote="r", head="h", ahead=True, blobs={("HEAD", IO.ACCESS_LOG_REL): closing})
    with pytest.raises(IO.Refused, match="closing commit not on origin"):
        IO.gate(g, repo, check_code=False)


# ------------------------------------------------------------------ 4: the exit spread of an intrabar fill

def _bar(open_spread, close_spread):
    return {"bid_o": np.array([1.1]), "ask_o": np.array([1.1 + open_spread * C.PIP]),
            "bid_c": np.array([1.1]), "ask_c": np.array([1.1 + close_spread * C.PIP])}


def test_rt3_4_intrabar_exits_record_the_smaller_spread_and_a_gap_the_open():
    m = _bar(0.6, 0.2)
    assert C._spread(m, 0, "stop") == pytest.approx(0.2) and C._spread(m, 0, "target") == pytest.approx(0.2)
    assert C._spread(m, 0, "stop", at_open=True) == pytest.approx(0.6)       # filled at the open, through the stop
    assert C._spread(m, 0, "market") == pytest.approx(0.6)
    assert C._spread(_bar(0.2, 0.6), 0, "target") == pytest.approx(0.2)


def test_rt3_4_side_rec_takes_the_open_for_a_gap_through_the_stop():
    ts = np.array([0, 60], dtype=np.int64) + C.FORWARD_START
    m = {"ts_utc": ts, "bid_o": np.array([1.1, 1.09]), "ask_o": np.array([1.1 + 0.2e-4, 1.09 + 0.9e-4]),
         "bid_c": np.array([1.1, 1.09]), "ask_c": np.array([1.1 + 0.2e-4, 1.09 + 0.3e-4])}
    from types import SimpleNamespace
    w = SimpleNamespace(m1=m)
    base = {"i": 0, "jj": 1, "entry": 1.1 + 0.2e-4, "fill": 1.09 - 0.2e-4, "mid_exit": 1.09}
    gap = C.side_rec(w, 1, {**base, "why": "stop", "raw": 1.09}, int(ts[0]), None)          # raw = the bar's bid open
    inside = C.side_rec(w, 1, {**base, "why": "stop", "raw": 1.0905}, int(ts[0]), None)    # the stop, inside the bar
    assert gap["exit_spread"] == pytest.approx(0.9) and inside["exit_spread"] == pytest.approx(0.3)


def test_rt3_4_the_smaller_exit_spread_is_the_strict_side(tmp_path):
    """PoC f4: with cost.py's floor top-up, a larger recorded exit spread gives a larger pass case (a cost not
    charged). The runner records the smaller one."""
    d = json.loads(C.DEPS.read_text())["cost"]
    code = next(r for r in d["files"] if r.endswith(".py"))
    model_rel = next(r for r in d["files"] if r.endswith(".json"))
    mod = fwd_cost._import(C.REPO / code)
    model = json.loads((C.REPO / model_rel).read_text())
    rel = {"ts": [S.utc("2026-10-21T18:00:00"), S.utc("2027-01-27T19:00:00")], "types": ["FOMC_STATEMENT"]}
    cost = fwd_cost.CostV3(mod, model, d["files"][model_rel], rel, {}, None)
    e_ts, x_ts = S.ny("2026-11-10", "14:00"), S.ny("2026-11-11", "10:00")
    ask0 = 1.10004
    base = {"side": 1, "decision_ts": e_ts, "entry_ts": e_ts, "exit_ts": x_ts, "entry_kind": "market",
            "exit_kind": "target", "entry_price": ask0, "exit_price": ask0 + 0.2e-4 + 80e-4,
            "entry_spread": 0.2, "vol_entry": None, "vol_exit": None, "mid_entry": ask0 - 0.1e-4,
            "mid_exit": ask0 + 0.2e-4 + 80e-4, "move_mid_pips": 80.3, "ba_slip_pips": 80.0,
            "fin_nights": C.fin_nights(e_ts, x_ts)}
    lo, _ = fwd_cost.price_side(cost, {**base, "exit_spread": C._spread(_bar(0.6, 0.2), 0, "target")})
    hi, _ = fwd_cost.price_side(cost, {**base, "exit_spread": 0.6})
    assert lo["pass_case"] < hi["pass_case"]


# ------------------------------------------------------------------ 6: whole positions only

def test_rt3_6_a_window_never_cuts_a_position(tmp_path):
    """A multi-night FC-1 position decided inside a window that ends before its exit keeps all its day rows (its later
    financing included), and its rows sum to its logged net; positions decided outside the window are left out."""
    log = tmp_path / "log.jsonl"
    res, cal = run(tmp_path, "first")
    C.append_run(res, log, cal)
    fc = [r for r in C.read_log(log) if r.get("kind") == "trade" and r["pick_id"] == "FC-1" and len(r["days"]) > 1]
    assert fc
    r = fc[0]
    t = C.forward_table("FC-1", log, allow_below_pass_case=True, window=(r["decision_ts"], r["decision_ts"] + 60))
    assert set(t.position_id) == {r["position_id"]}
    assert list(t.day) == [d["day"] for d in r["days"]]
    assert t.pnl_long.sum() == pytest.approx(r["net_pips"]) and t.pnl_short.sum() == pytest.approx(r["net_short"])


# ------------------------------------------------------------------ 7: origin is the GitHub repo

def test_rt3_7_origin_must_be_the_github_repo(fwd_tree):
    repo, files = fwd_tree
    for urls in ([], ["/tmp/elsewhere.git"], [GITHUB, "https://github.com/someone/Forex-signal"]):
        with pytest.raises(IO.Refused, match="not github.com/macdarenz-droid/Forex-signal"):
            IO.gate(GateGit(files, urls=urls), repo, check_code=False)
    assert IO.check_origin(GateGit(files)) == [GITHUB, GITHUB]


def _two_origins(repos):
    """A second bare repo whose STATUS says the lock is free, while the real origin's says it is set."""
    fake = repos.tmp / "fake.git"
    git(repos.tmp, "clone", "-q", "--bare", str(repos.origin), str(fake))
    (repos.main / "research/departments/STATS/STATUS.json").write_text('{"oanda_job": {"what": "a job"}}\n')
    git(repos.main, "commit", "-q", "-am", "job set")
    git(repos.main, "push", "-q", "origin", "dept/stats")
    return fake


def test_rt3_7_an_insteadof_in_git_config_env_is_dropped(repos, monkeypatch):
    """PoC f7: GIT_CONFIG_COUNT / KEY / VALUE could rewrite origin's URL (an insteadOf), so STATS read another
    repository's STATUS. The runner's git now runs without them (item 12): the real origin is read."""
    fake = _two_origins(repos)
    g = IO.Git(repos.wt)
    assert IO.stats_lock_free(g) is False
    monkeypatch.setenv("GIT_CONFIG_COUNT", "1")
    monkeypatch.setenv("GIT_CONFIG_KEY_0", f"url.{fake}.insteadOf")
    monkeypatch.setenv("GIT_CONFIG_VALUE_0", str(repos.origin))
    monkeypatch.setenv("GIT_CONFIG_PARAMETERS", f"'url.{fake}.insteadof'='{repos.origin}'")
    env = C.git_env()
    assert not [k for k in env if k in ("GIT_CONFIG_COUNT", "GIT_CONFIG_PARAMETERS")
                or k.startswith(("GIT_CONFIG_KEY_", "GIT_CONFIG_VALUE_"))] and env["GIT_NO_REPLACE_OBJECTS"] == "1"
    assert g.origin_urls() == [str(repos.origin)] * 2 and IO.stats_lock_free(g) is False


def test_rt3_7_an_insteadof_in_a_config_file_refuses(repos):
    """An insteadOf in the repository's config (or any config file git reads) moves origin too: the origin check sees
    the URL git would use and refuses before any read of origin."""
    fake = _two_origins(repos)
    git(repos.main, "config", f"url.{fake}.insteadOf", str(repos.origin))
    g = IO.Git(repos.wt)
    assert g.origin_urls() == [str(fake)] * 2
    with pytest.raises(IO.Refused, match="origin resolves to"):
        IO.worktree_check(g)


def test_rt3_12_replace_refs_refuse_and_are_never_honoured(repos):
    """Locked runner red team 2, M3, in the forward runner: every git call passes --no-replace-objects with
    GIT_NO_REPLACE_OBJECTS=1, and a repository holding refs/replace/* is refused."""
    g = IO.Git(repos.wt)
    IO.worktree_check(g)
    head = git(repos.wt, "rev-parse", "HEAD")
    other = git(repos.wt, "commit-tree", git(repos.wt, "rev-parse", "HEAD^{tree}"), "-m", "replacement")
    git(repos.wt, "replace", head, other)
    assert git(repos.wt, "log", "-1", "--format=%s") == "replacement"         # plain git honours it
    assert g._run("log", "-1", "--format=%s").stdout.strip() == "init"       # the runner's git does not
    with pytest.raises(IO.Refused, match="replace refs"):
        IO.worktree_check(g)


def test_rt3_12_every_git_call_passes_no_replace_objects(repos, monkeypatch):
    """Both layers on every forward git call: the --no-replace-objects flag and GIT_NO_REPLACE_OBJECTS=1."""
    import fwd_register as REG
    seen, real = [], subprocess.run

    def spy(args, *a, **kw):
        if args and args[0] == "git":
            seen.append((list(args), (kw.get("env") or {}).get("GIT_NO_REPLACE_OBJECTS")))
        return real(args, *a, **kw)
    monkeypatch.setattr(subprocess, "run", spy)
    g = IO.Git(repos.wt)
    g.head(), g.fetch(IO.BRANCH), g.show_bytes("HEAD", IO.STATS_STATUS_REL), g.origin_urls(), g.replace_refs()
    REG.checkout_roots(repos.wt)
    assert len(seen) >= 7 and all(a[:2] == ["git", "--no-replace-objects"] and e == "1" for a, e in seen), seen


def test_rt3_12_gate_refuses_replace_refs(fwd_tree):
    repo, files = fwd_tree
    g = GateGit(files)
    g.replaced = ["refs/replace/" + "a" * 40]
    with pytest.raises(IO.Refused, match="replace refs"):
        IO.gate(g, repo, check_code=False)


def test_rt3_7_the_real_pattern_refuses_a_local_origin(repos, monkeypatch):
    monkeypatch.setattr(IO, "origin_pattern", lambda: IO.loaders().GITHUB_ORIGIN)   # DATA's pattern, not the fixture's
    with pytest.raises(IO.Refused, match="not github.com/macdarenz-droid/Forex-signal"):
        IO.worktree_check(IO.Git(repos.wt))


# ------------------------------------------------------------------ 8: audit_inputs.py hashed; imports from here

def test_rt3_8_audit_inputs_is_part_of_the_hashed_tree(fwd_tree):
    repo, files = fwd_tree
    assert IO.AUDIT_INPUTS_REL in IO.forward_files(GateGit(files))
    tree = IO.tree_sha256(repo, hashed(files))
    (repo / IO.FWD_REL / "RED_TEAM.md").write_text(f"approved_tree_sha256: {tree}\n")
    IO.gate(GateGit(files), repo, check_code=False)
    (repo / IO.AUDIT_INPUTS_REL).write_text("REFUSED = {}  # changed\n")
    with pytest.raises(IO.Refused, match="not approved"):
        IO.gate(GateGit(files), repo, check_code=False)
    with pytest.raises(IO.Refused, match="audit_inputs.py is not tracked"):
        IO.gate(GateGit([f for f in files if f != IO.AUDIT_INPUTS_REL]), repo, check_code=False)


def test_rt3_8_the_real_tree_holds_audit_inputs():
    assert IO.AUDIT_INPUTS_REL in IO.forward_files(IO.Git(C.REPO))


def test_rt3_8_research_common_from_this_checkout_and_no_root_module(tmp_path, monkeypatch):
    IO.check_import_roots()
    (tmp_path / "research" / "common").mkdir(parents=True)
    with pytest.raises(C.PinError, match="not from this checkout"):
        IO.check_import_roots(tmp_path)
    from types import ModuleType
    fake = ModuleType("research.common")
    fake.__file__ = str(tmp_path / "research" / "common" / "__init__.py")
    monkeypatch.setitem(sys.modules, "research.common", fake)
    (tmp_path / "numpy.py").write_text("")
    with pytest.raises(IO.Refused, match=r"importable modules \['numpy.py'\]"):
        IO.check_import_roots(tmp_path)


# ------------------------------------------------------------------ 10: mixed or older pins refused

def test_rt3_10_mixed_or_older_pins_are_refused(tmp_path):
    log = tmp_path / "log.jsonl"
    res, cal = run(tmp_path, "first")
    C.append_run(res, log, cal)
    rows = C.read_log(log)
    pid = "R53-S3X3"
    mine = [i for i, r in enumerate(rows) if r.get("kind") == "trade" and r["pick_id"] == pid]
    assert len(mine) >= 2 and positions(log, pid)
    cur = C._current_pins(pid)[1]

    def rewrite(tag, edit):
        out = [dict(r) for r in rows]
        edit(out)
        p = tmp_path / f"{tag}.jsonl"
        p.write_text("".join(json.dumps(r) + "\n" for r in out))
        return p
    older_pick = rewrite("pick", lambda out: [out[i].update(pick_sha256="0" * 64) for i in mine])
    with pytest.raises(C.Refused, match="older pick pin"):
        positions(older_pick, pid)
    mixed = rewrite("mixed", lambda out: out[mine[0]].update(cost_model=cur))
    with pytest.raises(C.Refused, match="mixed pins"):
        positions(mixed, pid)
    older_cost = rewrite("cost", lambda out: [out[i].update(cost_model={**cur, "model_sha256": "1" * 64}) for i in mine])
    with pytest.raises(C.Refused, match="older COST pin"):
        positions(older_cost, pid)
    current = rewrite("current", lambda out: [out[i].update(cost_model=cur) for i in mine])
    assert positions(current, pid) == positions(log, pid)


# ------------------------------------------------------------------ 11: notes name the pins

def test_rt3_11_deps_notes_and_forward_md_name_the_current_pins():
    d = json.loads((C.HERE / "DEPS.json").read_text())
    data, cost = d["data_commit"][:8], d["cost"]["cost_commit"][:8]
    files = d["cost"]["files"]
    code = next(v for k, v in files.items() if k.endswith(".py"))[:8]
    model = next(v for k, v in files.items() if k.endswith(".json"))[:8]
    assert data in d["note"] and cost in d["cost"]["note"] and code in d["cost"]["note"] and model in d["cost"]["note"]
    md = (C.STATS / "FORWARD.md").read_text()
    assert data in md and cost in md and code in md and model in md
    assert not re.search(r"a6e11676|ac9f8264|6b3ffb38|4b110866", md + d["note"] + d["cost"]["note"])


# ------------------------------------------------------------------ 13: the start line, decided from origin only

def test_rt3_13_a_push_reported_failed_but_on_origin_goes_on(sandbox):
    ops = FakeOps(sandbox, push=False, start_seen="pushed")
    RF.run(DAY, ops, now=NOW)
    assert "download" in ops.calls and "discard_start" not in ops.calls


@pytest.mark.parametrize("push,seen", [(True, None), (False, None), (True, "absent")])
def test_rt3_13_an_unknown_state_reads_nothing_and_keeps_the_lock(sandbox, push, seen):
    """Origin unreadable after the push, or a reported push that origin does not show: nothing is downloaded or read,
    no closing line is pushed (so no failure path pushes the start line later), the local lock stays."""
    ops = FakeOps(sandbox, push=push, start_seen=seen)
    with pytest.raises(IO.Refused, match="unknown"):
        RF.run(DAY, ops, now=NOW)
    assert ops.calls[-3:] == ["job:set", "publish", "start_state"]
    assert len(ops.published) == 1 and ops.job and not [r for r in ops.access_rows if r["kind"] == "forward_run_done"]


def test_rt3_13_a_rejected_start_push_is_dropped_on_real_git(repos):
    """origin refuses the push (a pre-receive hook): origin is read back, does not hold the line, so the local start
    commit and the lock are dropped. The worktree is origin again and a later push carries no start line."""
    g = IO.Git(repos.wt)
    access, status = repos.wt / IO.ACCESS_LOG_REL, repos.wt / IO.STATS_STATUS_REL
    hook = repos.origin / "hooks" / "pre-receive"
    hook.write_text("#!/bin/sh\nexit 1\n")
    hook.chmod(0o755)
    IO.append_access({"utc": "2026-12-08T00:00:00Z", "kind": "forward_run_start", "ledger_id": "STATS-FWD-X"}, access)
    IO.set_oanda_job({"what": "x", "ledger_id": "STATS-FWD-X"}, status)
    assert g.commit_push([access, status], "start") is False
    assert IO.start_state(g, "STATS-FWD-X") == "absent"
    assert IO.discard_start(g, [access, status]) is True
    assert g.head() == g.rev(f"origin/{IO.BRANCH}") and not access.exists()
    assert json.loads(status.read_text())["oanda_job"] is None
    IO.worktree_check(g)
    hook.unlink()
    IO.set_oanda_job({"what": "later"}, status)
    assert g.commit_push([access, status], "a later commit")
    assert "STATS-FWD-X" not in (g.show(f"origin/{IO.BRANCH}", IO.ACCESS_LOG_REL) or "")


def test_rt3_13_start_state_reads_origin(repos):
    g = IO.Git(repos.wt)
    access = repos.wt / IO.ACCESS_LOG_REL
    IO.append_access({"utc": "2026-12-08T00:00:00Z", "kind": "forward_run_start", "ledger_id": "STATS-FWD-Y"}, access)
    assert IO.start_state(g, "STATS-FWD-Y") == "absent"                     # written, not pushed
    assert g.commit_push([access], "start")
    assert IO.start_state(g, "STATS-FWD-Y") == "pushed"
    git(repos.wt, "remote", "set-url", "origin", str(repos.tmp / "gone.git"))
    assert IO.start_state(g, "STATS-FWD-Y") is None                         # origin unreadable: unknown


# ------------------------------------------------------------------ 14: DATA's downloader is never resumed

def test_rt3_14_the_forward_fetcher_never_cools_down_or_resumes(data_code, monkeypatch, tmp_path):
    """Locked runner red team 2, M2, in the forward runner: fwd_io builds DATA's Fetcher with max_fail_cycles=0 and has
    no retry loop, so a stop (here three 503s, DATA's own retries) ends the download: no 5-minute cool-down, no
    second attempt; the meter holds the 3 requests."""
    built = []
    real = data_code.Fetcher

    def spy(*a, **kw):
        built.append(kw)
        return real(*a, **kw)
    monkeypatch.setattr(data_code, "Fetcher", spy)
    calls = fake_candles(monkeypatch, data_code, fail_from=1, fail_status=503)
    slept = []
    monkeypatch.setattr(IO.time, "sleep", slept.append)
    start = S.ny("2026-09-03", "17:00")
    g = FakeGit(stats_access=json.dumps({"kind": "forward_run_start", "ledger_id": OPEN_LID}) + "\n")
    meter = {}
    with pytest.raises(RuntimeError, match="HTTP 503"):
        IO.download_step(g, OPEN_LID, start, start + 4 * 5000 * 60, tmp_path / "dl", meter=meter)
    assert [kw["max_fail_cycles"] for kw in built] == [0] and len(calls) == 3 and meter["requests"] == 3
    assert data_code.COOLDOWN_S not in slept
