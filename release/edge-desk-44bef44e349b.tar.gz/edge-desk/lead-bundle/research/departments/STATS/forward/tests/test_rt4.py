"""Red team 4 (forward/RED_TEAM.md): one test (or more) per finding, each failing if its fix is removed. The red team's
proofs (rt4_forward/) restated as repo tests. DATA's published forward calendar (DATA release 3 a23f65c0; dates and
times only, no prices) is read from this repository with git show; everything else is synthetic bars and calendars
and temporary git repositories with local bare origins. No network, no real data, no token."""
import csv
import hashlib
import io
import json
import os
import subprocess
import sys
from datetime import date
from pathlib import Path

import pytest

import fwd_core as C
import fwd_cost
import fwd_io as IO
import run_forward as RF
import synth as S
from test_io import DAY, NOW, OPEN_LID, FakeOps, StatsOrigin, _git, data_code, sandbox  # noqa: F401  (fixtures)
from test_redteam import GITHUB, GateGit, fwd_tree, git, hashed, repos  # noqa: F401  (fixtures)

DATA_COMMIT = "a23f65c013d5ee79049548e38f90912e54e663fd"          # DATA release 3 (FORWARD_EVENTS.csv)
DATA_CAL = "research/departments/DATA/forward/FORWARD_EVENTS.csv"
F, E = "FOMC_STATEMENT", "ECB_DECISION"


def data_bytes() -> bytes:
    """DATA's published calendar, read only (git show <a23f65c0>:<path>); the repo must hold that commit."""
    b = IO.Git(C.REPO).show_bytes(DATA_COMMIT, DATA_CAL)
    assert b is not None, "DATA's commit a23f65c0 is not in this repository: git fetch origin dept/data"
    return b


def write_cal(d: Path, raw: bytes) -> tuple:
    """A sourced calendar (the CSV bytes as given, and its meta) in d."""
    d.mkdir(parents=True, exist_ok=True)
    (d / "FORWARD_EVENTS.csv").write_bytes(raw)
    (d / "FORWARD_EVENTS.json").write_text(json.dumps({"status": "sourced", "sha256": hashlib.sha256(raw).hexdigest(),
                                                        "covers_from": "2026-09-16", "covers_through": "2027-12-31"}))
    return d / "FORWARD_EVENTS.csv", d / "FORWARD_EVENTS.json"


def edited(raw: bytes, edits: dict | None = None, add: list | None = None) -> bytes:
    """DATA's file with rows edited ({event_id: {column: value}}) or added (dicts; missing columns copied from the
    first row of the same type): a later DATA version."""
    rows = list(csv.DictReader(io.StringIO(raw.decode())))
    for r in rows:
        r.update((edits or {}).get(r["event_id"], {}))
    for a in add or []:
        base = next(r for r in rows if r["type"] == a["type"])
        rows.append({**base, **a})
    out = io.StringIO()
    w = csv.DictWriter(out, fieldnames=list(C.CAL_COLS), lineterminator="\n")
    w.writeheader()
    w.writerows(rows)
    return out.getvalue().encode()


TIME_ADDED = {"FOMC_STATEMENT-2027-01-27": {"local_time": "14:00", "utc": "2027-01-27T19:00:00Z"}}
UNTIMED = {"type": F, "local_time": "", "utc": "", "status": "scheduled",
           "source_url": "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm"}


# ------------------------------------------------------------------ 1 (MAJOR): DATA's calendar, rows without a time

def test_rt4_1_datas_published_calendar_is_accepted_byte_equal(tmp_path):
    """PoC poc_datacal: read_calendar refused DATA's file (18 of 31 rows have no time on purpose), and STATS cannot drop
    rows (byte-equal pin). Now the file is accepted as it is; rows without a time count for nothing in a plan."""
    raw = data_bytes()
    csv_p, meta = write_cal(tmp_path / "data", raw)
    cal = C.read_calendar(csv_p, meta)
    assert len(cal) == 31 and csv_p.read_bytes() == raw
    blank = cal[cal.utc.str.strip() == ""]
    assert len(blank) == 18 and set(blank.type) == {F, "UK_BANK_HOLIDAY_EW"}
    assert sorted(blank[blank.type == F].local_date)[0] == "2027-01-27" and (blank.status == "scheduled").all()
    ev = C.calendar_rows(cal)
    assert len(ev) == 13 and set(ev.type) == {F, E}                     # 3 FOMC and 10 ECB rows with a time
    assert C.calendar_snapshot(cal)[-1] == [F, None, "scheduled", "2027-12-08"]
    for ty in ((F,), (E,)):
        C.check_coverage(cal, date(2026, 10, 13), ty)
        C.check_coverage(cal, date(2026, 12, 8), ty)
    C.check_coverage(cal, date(2026, 12, 9), (E,))
    with pytest.raises(C.CalendarError, match="FOMC_STATEMENT row of 2027-01-27 has no time yet"):
        C.check_coverage(cal, date(2026, 12, 9), (F,))                  # the next statement's time is not known yet


def test_rt4_1_the_repo_calendar_is_datas_file_and_reads():
    meta = json.loads(C.CAL_META.read_text())
    assert (meta["source"]["data_commit"], meta["source"]["path"]) == (DATA_COMMIT, DATA_CAL)
    assert C.CAL_CSV.read_bytes() == data_bytes()
    assert len(C.read_calendar(run_day=date(2026, 10, 13))) == 31


def _run(cal_dir: Path, run_day: date, log: Path, name: str):
    picks = C.load_picks()
    cal = C.read_calendar(cal_dir / "FORWARD_EVENTS.csv", cal_dir / "FORWARD_EVENTS.json")
    floors = C.floors_from_log(C.read_log(log), picks) if log.exists() else None
    end = C.label_close_ts(run_day)
    res = C.compute_run(picks, cal, S.bars(C.inputs_start(picks, floors), end), end, name, floors=floors,
                        run_day=run_day)
    return res, cal


def test_rt4_1_a_time_added_to_a_scheduled_row_is_a_normal_update(tmp_path):
    """DATA adds the 2027-01-27 statement's time (14:00 New York) to its row: the next run goes on without a ruling.
    Before, the row without a time counted as cancelled, so the added time was a calendar change."""
    log = tmp_path / "log.jsonl"
    raw = data_bytes()
    write_cal(tmp_path / "a", raw)
    res, cal = _run(tmp_path / "a", date(2026, 10, 13), log, "RT4-A")
    C.append_run(res, log, cal)
    raw_b = edited(raw, TIME_ADDED)
    write_cal(tmp_path / "b", raw_b)
    res2, cal2 = _run(tmp_path / "b", date(2026, 10, 20), log, "RT4-B")
    assert C.calendar_changes(C.read_log(log), cal2) == []
    C.append_run(res2, log, cal2)                                       # no CalendarChanged, no ruling
    assert not [r for r in C.read_log(log) if r["kind"] == "calendar_ruled"]
    # anything else done to a row without a time is still a change (against run 2's calendar)
    for what, new in (("moved a day", edited(raw_b, {"FOMC_STATEMENT-2027-03-17": {
                          "local_time": "14:00", "utc": "2027-03-18T18:00:00Z", "local_date": "2027-03-18"}})),
                      ("cancelled", edited(raw_b, {"FOMC_STATEMENT-2027-03-17": {"status": "cancelled"}})),
                      ("added inside", edited(raw_b, add=[{**UNTIMED, "event_id": "FOMC_STATEMENT-2027-02-15",
                                                            "local_date": "2027-02-15"}])),
                      ("time removed", raw)):
        write_cal(tmp_path / what, new)
        cal3 = C.read_calendar(tmp_path / what / "FORWARD_EVENTS.csv", tmp_path / what / "FORWARD_EVENTS.json")
        assert C.calendar_changes(C.read_log(log), cal3), what
    grown = edited(raw_b, add=[{**UNTIMED, "event_id": "FOMC_STATEMENT-2028-01-26", "local_date": "2028-01-26"}])
    write_cal(tmp_path / "grown", grown)
    cal4 = C.read_calendar(tmp_path / "grown" / "FORWARD_EVENTS.csv", tmp_path / "grown" / "FORWARD_EVENTS.json")
    assert C.calendar_changes(C.read_log(log), cal4) == []              # the calendar growing


def test_rt4_1_snapshot_changes_with_rows_without_a_time():
    t916, t1028, t127 = S.utc("2026-09-16T18:00:00"), S.utc("2026-10-28T18:00:00"), S.utc("2027-01-27T19:00:00")
    old = [[F, t916, "held", "2026-09-16"], [F, t1028, "scheduled", "2026-10-28"],
           [F, None, "scheduled", "2027-01-27"], [F, None, "scheduled", "2027-03-17"], [E, t1028, "scheduled", "2026-10-29"]]
    before = t1028 + 86400                                              # the last run's data end

    def swap(i, row):
        return old[:i] + [row] + old[i + 1:]
    timed = swap(2, [F, t127, "scheduled", "2027-01-27"])
    assert C.snapshot_changes(old, timed, before) == []                 # a time added
    assert C.snapshot_changes(old, swap(2, [F, t127, "held", "2027-01-27"]), before) == []
    assert C.snapshot_changes(old, old + [[F, None, "scheduled", "2028-01-26"]], before) == []         # growing
    assert C.snapshot_changes(old, old + [[F, t127 + 400 * 86400, "scheduled", "2028-03-01"]], before) == []
    for new, known, what in (
            (timed, None, "no data end known"),
            (timed, t127, "time not after the last run's data end"),
            (swap(2, [F, t127 + 86400, "scheduled", "2027-01-28"]), before, "time on another day"),
            (swap(2, [F, t127, "cancelled", "2027-01-27"]), before, "time added to a cancelled row"),
            (swap(2, [F, None, "cancelled", "2027-01-27"]), before, "a row without a time cancelled"),
            (swap(2, [F, None, "scheduled", "2027-01-26"]), before, "a row without a time moved"),
            (old[:2] + old[3:], before, "a row without a time removed"),
            (old + [[F, None, "scheduled", "2027-02-15"]], before, "a row without a time added inside"),
            (old + [[F, t127 + 19 * 86400, "scheduled", "2027-02-15"]], before, "a timed row added inside by day"),
            (swap(1, [F, None, "scheduled", "2026-10-28"]), before, "a time removed"),
            (old + [[E, None, "cancelled", "2028-01-01"]], before, "a cancelled row without a time added")):
        assert C.snapshot_changes(old, new, known), what


def test_rt4_1_release_rows_without_a_time_keep_lines_below_the_pass_case(tmp_path):
    cal = C.read_calendar(*write_cal(tmp_path / "c", data_bytes()))
    rel = fwd_cost.release_rows(cal)
    assert rel["untimed_types"] == [F, "UK_BANK_HOLIDAY_EW"] and len(rel["ts"]) == 13
    cm = fwd_cost.load(C.REPO, cal)
    assert any("rows of ['FOMC_STATEMENT'] have no time yet" in r for r in cm.reasons), cm.reasons


def test_rt4_1_rows_without_a_time_stay_strict(tmp_path):
    raw = data_bytes()
    for what, edit, msg in (
            ("held FOMC without a time", {"FOMC_STATEMENT-2027-01-27": {"status": "held"}}, "needs its time"),
            ("bad local_date", {"FOMC_STATEMENT-2027-01-27": {"local_date": "2027-13-01"}}, "valid local_date and tz"),
            ("bad tz", {"UK_BANK_HOLIDAY_EW-2026-12-25": {"tz": "Mars/Base"}}, "valid local_date and tz"),
            ("utc off its local_date", {"FOMC_STATEMENT-2026-10-28": {"local_date": "2026-10-27"}}, "is not on local_date"),
            ("holiday held, read on the day", {"UK_BANK_HOLIDAY_EW-2026-12-25": {
                "status": "held", "source_read_utc": "2026-12-25T12:00:00Z"}}, "source read after the event")):
        csv_p, meta = write_cal(tmp_path / what, edited(raw, edit))
        with pytest.raises(C.CalendarError, match=msg):
            C.read_calendar(csv_p, meta)
    csv_p, meta = write_cal(tmp_path / "ok", edited(raw, {"UK_BANK_HOLIDAY_EW-2026-12-25": {
        "status": "held", "source_read_utc": "2026-12-26T00:30:00Z"}}))
    C.read_calendar(csv_p, meta)                                        # a whole day, read after it ended (London)


def test_rt4_1_a_row_without_a_time_inside_a_plans_range_is_no_dependency(tmp_path):
    """deps_of: a not cancelled row of the type without a time inside a decision's range (here a statement between
    two timed ones) leaves the decision unsettled (None): its time could move the plan."""
    raw = edited(data_bytes(), add=[{**UNTIMED, "event_id": "FOMC_STATEMENT-2026-11-18", "local_date": "2026-11-18"}])
    csv_p, meta = write_cal(tmp_path / "c", raw)
    allrows = C.calendar_all(C.read_calendar(csv_p, meta))
    fc1 = next(p for p in C.load_picks() if p["id"] == "FC-1")
    t = S.utc("2026-11-05T16:00:00")                                    # between 28 Oct and 9 Dec
    assert C.deps_of(fc1, t, t + 5 * 86400, allrows) is None
    allrows2 = C.calendar_all(C.read_calendar(*write_cal(tmp_path / "d", data_bytes())))
    assert C.deps_of(fc1, t, t + 5 * 86400, allrows2)["rows"][-1][0] == "FOMC_STATEMENT-2026-12-09"


# ------------------------------------------------------------------ 7: the calendar's source is DATA's own commit

class RefGit(GateGit):
    """GateGit whose ancestor answer depends on the branch: `off` holds the refs a commit is not on."""

    def __init__(self, files, off=(), **kw):
        super().__init__(files, **kw)
        self.off = set(off)

    def is_ancestor(self, a, b):
        return b not in self.off and super().is_ancestor(a, b)


def _approved(fwd_tree):
    repo, files = fwd_tree
    tree = IO.tree_sha256(repo, hashed(files))
    (repo / IO.FWD_REL / "RED_TEAM.md").write_text(f"approved_tree_sha256: {tree}\n")
    cal, pin = repo / IO.CAL_PIN_RELS[0], repo / IO.CAL_PIN_RELS[1]
    cal.write_text("event_id,type\nA,FOMC_STATEMENT\n")
    return repo, files, cal, pin


def test_rt4_7_source_path_under_data_and_commit_on_dept_data(fwd_tree):
    repo, files, cal, pin = _approved(fwd_tree)
    body = b"event_id,type\nA,FOMC_STATEMENT\n"
    c = "d" * 40
    for rel, msg in ((f"{IO.FWD_REL}/calendars/FORWARD_EVENTS.csv", "not a file under research/departments/DATA/"),
                     ("research/departments/DATA/../STATS/forward/calendars/FORWARD_EVENTS.csv", "not a file under"),
                     ("research/data/forward_calendar/FORWARD_EVENTS.csv", "not a file under")):
        pin.write_text(json.dumps({"status": "sourced", "sha256": C.sha256_file(cal),
                                   "source": {"data_commit": c, "path": rel}}))
        with pytest.raises(IO.Refused, match=msg):
            IO.gate(GateGit(files, blobs={(c, rel): body}), repo, check_code=False)
    pin.write_text(json.dumps({"status": "sourced", "sha256": C.sha256_file(cal),
                               "source": {"data_commit": c, "path": DATA_CAL}}))
    g = RefGit(files, off={f"origin/{IO.DATA_BRANCH}"}, blobs={(c, DATA_CAL): body})
    with pytest.raises(IO.Refused, match="not on origin/dept/data"):
        IO.gate(g, repo, check_code=False)
    g = RefGit(files, off={f"origin/{IO.COORD_BRANCH}"}, blobs={(c, DATA_CAL): body})
    with pytest.raises(IO.Refused, match="not merged on origin/ccr-3d8c8d4d-gy5b9o yet"):
        IO.check_calendar_pin(g, repo)                                  # (the gate refuses DEPS.json's pins first)
    assert IO.gate(RefGit(files, blobs={(c, DATA_CAL): body}), repo, check_code=False)


class Branches:
    """origin (bare) with the coordinator branch, dept/data and dept/stats, and the session checkout `main`."""

    def __init__(self, tmp):
        self.origin, self.main = tmp / "origin.git", tmp / "main"
        _git(tmp, "init", "-q", "--bare", str(self.origin))
        _git(tmp, "clone", "-q", str(self.origin), str(self.main))
        _git(self.main, "checkout", "-q", "-b", IO.COORD_BRANCH)
        _git(self.main, "commit", "-q", "--allow-empty", "-m", "c0")
        for b in (IO.COORD_BRANCH, IO.DATA_BRANCH, IO.BRANCH):
            _git(self.main, "push", "-q", "origin", f"HEAD:refs/heads/{b}")

    def commit_on(self, branch, rel, data: bytes, msg) -> str:
        _git(self.main, "fetch", "-q", "origin")
        _git(self.main, "checkout", "-q", "-B", branch, f"origin/{branch}")
        p = self.main / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
        _git(self.main, "add", "-A")
        _git(self.main, "commit", "-q", "-m", msg)
        _git(self.main, "push", "-q", "origin", f"HEAD:refs/heads/{branch}")
        return _git(self.main, "rev-parse", "HEAD").strip()

    def merge_into_coord(self, branch):
        _git(self.main, "fetch", "-q", "origin")
        _git(self.main, "checkout", "-q", "-B", IO.COORD_BRANCH, f"origin/{IO.COORD_BRANCH}")
        _git(self.main, "merge", "-q", "--no-edit", f"origin/{branch}")
        _git(self.main, "push", "-q", "origin", f"HEAD:refs/heads/{IO.COORD_BRANCH}")


def _pin(d: Path, data: bytes, commit: str, rel: str) -> Path:
    for p in IO.CAL_PIN_RELS:
        (d / p).parent.mkdir(parents=True, exist_ok=True)
    (d / IO.CAL_PIN_RELS[0]).write_bytes(data)
    (d / IO.CAL_PIN_RELS[1]).write_text(json.dumps({"status": "sourced", "sha256": hashlib.sha256(data).hexdigest(),
                                                     "source": {"data_commit": commit, "path": rel}}))
    return d


def test_rt4_7_the_pin_waits_for_the_coordinators_merge_and_never_takes_statss_copy(tmp_path):
    """On real git with a local origin: DATA's calendar commit on dept/data is refused until the coordinator merges it
    (the state of DATA's first publication 6db4764c on 14 Oct 2026), then accepted. PoC poc_pin_provenance: STATS's own edited copy, merged by the
    coordinator, is refused, at STATS's path and also at a DATA path inside a STATS commit."""
    b = Branches(tmp_path)
    raw = data_bytes()
    d1 = b.commit_on(IO.DATA_BRANCH, DATA_CAL, raw, "DATA: forward calendar")
    pin_dir = _pin(tmp_path / "runner", raw, d1, DATA_CAL)
    g = IO.Git(b.main)
    with pytest.raises(IO.Refused, match=f"source.data_commit {d1[:8]} is not merged on origin/{IO.COORD_BRANCH} yet"):
        IO.check_calendar_pin(g, pin_dir)
    b.merge_into_coord(IO.DATA_BRANCH)
    assert IO.check_calendar_pin(g, pin_dir) == C.sha256_file(pin_dir / IO.CAL_PIN_RELS[1])
    mine = raw.replace(b"ECB_DECISION-2026-10-29,", b"ECB_DECISION-2026-10-30,")
    own = f"{IO.FWD_REL}/calendars/FORWARD_EVENTS.csv"
    s1 = b.commit_on(IO.BRANCH, own, mine, "STATS: my own calendar edit")
    forged = "research/departments/DATA/forward/FORWARD_EVENTS_STATS.csv"
    s2 = b.commit_on(IO.BRANCH, forged, mine, "STATS: a copy at a DATA path")
    b.merge_into_coord(IO.BRANCH)
    with pytest.raises(IO.Refused, match="not a file under research/departments/DATA/"):
        IO.check_calendar_pin(g, _pin(tmp_path / "own", mine, s1, own))
    with pytest.raises(IO.Refused, match="not on origin/dept/data"):
        IO.check_calendar_pin(g, _pin(tmp_path / "forged", mine, s2, forged))


# ------------------------------------------------------------------ 2 and 3: unpushed commits; the daily step

def _commit_local(wt, rows=(), files=None, msg="local"):
    if rows:
        IO.append_access(rows[0], wt / IO.ACCESS_LOG_REL)
        for r in rows[1:]:
            IO.append_access(r, wt / IO.ACCESS_LOG_REL)
    for rel, text in (files or {}).items():
        (wt / rel).parent.mkdir(parents=True, exist_ok=True)
        (wt / rel).write_text(text)
    git(wt, "add", "-A")
    git(wt, "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", msg)


START = {"utc": "2026-12-08T00:00:00Z", "kind": "forward_run_start", "ledger_id": "STATS-FWD-20261208T000000Z-aaaaaa",
         "status": "started"}
DONE = {"utc": "2026-12-08T01:00:00Z", "kind": "forward_run_done", "ledger_id": "STATS-FWD-20261207T000000Z-bbbbbb",
        "status": "done"}


def test_rt4_2_an_unpushed_start_line_is_dropped_never_pushed(repos):
    """Item 13's gap: a start commit whose push failed while origin was unreadable stays local. The next run said
    "push them", which would publish the start line and lock of a run that read nothing. Now: "drop it", and the
    command it gives makes the worktree origin again; origin never holds the line."""
    g = IO.Git(repos.wt)
    IO.worktree_check(g)
    _commit_local(repos.wt, [START], {IO.STATS_STATUS_REL: '{"oanda_job": {"what": "x"}}\n'}, "start, push failed")
    with pytest.raises(IO.Refused, match=r"start line of run\(s\) \['STATS-FWD-20261208T000000Z-aaaaaa'\].*drop it, "
                                         r"never push it: git reset --keep origin/dept/stats") as e:
        IO.worktree_check(g)
    assert "push it (git push" not in str(e.value)
    git(repos.wt, "reset", "--keep", "origin/dept/stats")               # the command the refusal gives
    assert IO.worktree_check(g) == g.rev("origin/dept/stats")
    assert "aaaaaa" not in (g.show("origin/dept/stats", IO.ACCESS_LOG_REL) or "")


def test_rt4_2_push_only_for_a_closing_commit(repos):
    g = IO.Git(repos.wt)
    _commit_local(repos.wt, [DONE], {"research/departments/STATS/FETCH_LOG.jsonl": '{"status": 403}\n'}, "closing")
    with pytest.raises(IO.Refused, match="holds a closing commit not on origin/dept/stats .*push it"):
        IO.worktree_check(g)
    _commit_local(repos.wt, [START], msg="and a start")
    with pytest.raises(IO.Refused, match="sort them by hand"):
        IO.worktree_check(g)
    git(repos.wt, "reset", "-q", "--hard", "origin/dept/stats")
    _commit_local(repos.wt, files={"research/departments/STATS/notes.txt": "x\n"}, msg="someone's commit")
    with pytest.raises(IO.Refused, match="not a runner's closing commit .*inspect them by hand"):
        IO.worktree_check(g)


def test_rt4_2_a_diverged_closing_commit_is_pushed_by_push_closing_not_checked_out_over(repos):
    """Origin moved past a closing commit whose push failed: the refusal names --push-closing (red team 5, item 1),
    which rebuilds it on origin; origin's own commit stays. The run's start line is on origin (red team 7, N2)."""
    g = IO.Git(repos.wt)
    _commit_local(repos.wt, [{**START, "ledger_id": DONE["ledger_id"]}], msg="start")
    git(repos.wt, "push", "-q", "origin", "HEAD:refs/heads/dept/stats")
    _commit_local(repos.wt, [DONE], msg="closing, push failed")
    git(repos.main, "fetch", "-q", "origin")
    git(repos.main, "reset", "-q", "--hard", "origin/dept/stats")
    (repos.main / "research/departments/STATS/other.txt").write_text("moved on\n")
    git(repos.main, "add", "-A")
    git(repos.main, "commit", "-q", "-m", "origin moved")
    git(repos.main, "push", "-q", "origin", "dept/stats")
    with pytest.raises(IO.Refused, match="push it with .*--push-closing"):
        IO.worktree_check(g)
    IO.push_closing(g)
    assert IO.worktree_check(g) == g.rev("origin/dept/stats")
    assert git(repos.origin, "show", "dept/stats:research/departments/STATS/other.txt") == "moved on"


def daily_refresh() -> str:
    """FORWARD.md's daily refresh command (the code line marked '# daily refresh')."""
    lines = [ln for ln in (C.STATS / "FORWARD.md").read_text().splitlines() if ln.rstrip().endswith("# daily refresh")]
    assert len(lines) == 1, lines
    return lines[0].rsplit("#", 1)[0].strip()


def test_rt4_3_the_daily_step_never_drops_an_unpushed_commit(repos):
    """Item 9 was defeated by FORWARD.md's own daily step (checkout --detach origin/dept/stats), which dropped an
    unpushed closing commit holding a FETCH_LOG block. The documented refresh now only fast-forwards: an unpushed
    commit stays (and the runner refuses with "push it"), a diverged worktree stops the step, a behind one moves."""
    text = (C.STATS / "FORWARD.md").read_text()
    assert "checkout --detach origin/dept/stats" not in text
    cmd = daily_refresh()
    assert "--ff-only" in cmd

    def refresh():
        return subprocess.run(["bash", "-c", cmd.replace("../stats-fwd-wt", str(repos.wt))], capture_output=True,
                              text=True, env=C.git_env())
    _commit_local(repos.wt, [DONE], {"research/departments/STATS/FETCH_LOG.jsonl": '{"status": 429}\n'}, "closing")
    head = git(repos.wt, "rev-parse", "HEAD")
    assert refresh().returncode == 0 and git(repos.wt, "rev-parse", "HEAD") == head      # kept
    with pytest.raises(IO.Refused, match="push it"):
        IO.worktree_check(IO.Git(repos.wt))
    (repos.main / "research/departments/STATS/other.txt").write_text("moved on\n")
    git(repos.main, "add", "-A")
    git(repos.main, "commit", "-q", "-m", "origin moved")
    git(repos.main, "push", "-q", "origin", "dept/stats")
    assert refresh().returncode != 0 and git(repos.wt, "rev-parse", "HEAD") == head     # diverged: stops, kept
    git(repos.wt, "reset", "-q", "--hard", "HEAD~1")                     # (a test reset: behind origin now)
    assert refresh().returncode == 0
    assert git(repos.wt, "rev-parse", "HEAD") == git(repos.origin, "rev-parse", "dept/stats")


def test_rt4_3_data_dir_block_lines_go_into_the_closing_commit(tmp_path):
    dd = tmp_path / "data_dir"
    dd.mkdir()
    a, b = json.dumps({"status": 429, "n": 1}), json.dumps({"status": 403, "n": 2})
    (dd / IO.FETCH_LOG_NAME).write_text(f"{a}\n{b}\n")
    IO.FETCH_LOG.write_text(f"{a}\n")                                   # the repo copy lost b (a dropped commit)
    assert IO.carry_blocks(dd) == 1
    assert IO.FETCH_LOG.read_text().splitlines() == [a, b]
    assert IO.carry_blocks(dd) == 0                                     # idempotent


def test_rt4_3_the_runner_carries_them_before_the_closing_push_even_if_carrying_fails(sandbox):
    class Ops(FakeOps):
        def carry_blocks(self):
            self.calls.append("carry_blocks")
            raise OSError("disk")
    ops = Ops(sandbox)
    RF.run(DAY, ops, now=NOW)
    assert ops.calls[-3:] == ["job:clear", "carry_blocks", "publish"] and ops.job is None


# ------------------------------------------------------------------ 4: grafts and TLS

def test_rt4_4_grafts_are_refused(repos):
    """PoC graft/poc_graft: git 2.43 still honours <git-common-dir>/info/grafts under --no-replace-objects and
    GIT_NO_REPLACE_OBJECTS, so an unmerged commit can pass as an ancestor. The worktree check refuses it."""
    g = IO.Git(repos.wt)
    head = git(repos.wt, "rev-parse", "HEAD")
    rogue = git(repos.wt, "commit-tree", git(repos.wt, "rev-parse", "HEAD^{tree}"), "-m", "unmerged")
    assert not g.is_ancestor(rogue, "HEAD")
    common = Path(git(repos.wt, "rev-parse", "--git-common-dir"))
    common = common if common.is_absolute() else repos.wt / common
    (common / "info").mkdir(exist_ok=True)
    (common / "info" / "grafts").write_text(f"{head} {rogue}\n")
    assert g.is_ancestor(rogue, "HEAD")                                 # the runner's git honours it
    with pytest.raises(IO.Refused, match="grafts file"):
        IO.worktree_check(g)
    (common / "info" / "grafts").unlink()
    IO.worktree_check(g)


def test_rt4_4_gate_refuses_grafts_and_unverified_tls(fwd_tree):
    repo, files = fwd_tree
    tree = IO.tree_sha256(repo, hashed(files))
    (repo / IO.FWD_REL / "RED_TEAM.md").write_text(f"approved_tree_sha256: {tree}\n")
    g = GateGit(files)
    g.grafted = ["/x/.git/info/grafts"]
    with pytest.raises(IO.Refused, match="grafts file"):
        IO.gate(g, repo, check_code=False)
    g = GateGit(files)
    g.tls = "false"
    with pytest.raises(IO.Refused, match="would not verify TLS"):
        IO.gate(g, repo, check_code=False)


def test_rt4_4_tls_is_verified_for_the_github_origin(repos, monkeypatch):
    """Every git call passes -c http.sslVerify=true; a URL-specific http.<url>.sslVerify=false in a config file
    still wins in git, so the origin check reads the value git uses for the https origin and refuses."""
    monkeypatch.setattr(IO, "origin_pattern", lambda: IO.loaders().GITHUB_ORIGIN)
    r = repos.tmp / "gh"
    git(repos.tmp, "init", "-q", str(r))
    git(r, "remote", "add", "origin", GITHUB)
    seen, real = [], subprocess.run

    def spy(args, *a, **kw):
        if args and args[0] == "git":
            seen.append(list(args))
        return real(args, *a, **kw)
    monkeypatch.setattr(subprocess, "run", spy)
    g = IO.Git(r)
    assert IO.check_origin(g) == [GITHUB, GITHUB]
    assert seen and all(a[:4] == ["git", "--no-replace-objects", "-c", "http.sslVerify=true"] for a in seen), seen
    git(r, "config", "http.https://github.com/.sslVerify", "false")
    with pytest.raises(IO.Refused, match="would not verify TLS"):
        IO.check_origin(g)


# ------------------------------------------------------------------ 5: DATA's git calls in the same run

def test_rt4_5_main_cleans_the_process_environment_for_datas_git(data_code, monkeypatch, tmp_path):
    """PoC poc_data_env: an env insteadOf (GIT_CONFIG_COUNT/KEY/VALUE) moved DATA's loaders' and downloader's origin
    to a fake one holding a fabricated open run, while STATS's own origin check passed. run_forward.main deletes those
    variables from os.environ first, so DATA's git calls in the run read the real origin."""
    so = data_code.stats_origin
    fake = tmp_path / "fake.git"
    _git(tmp_path, "clone", "-q", "--bare", str(so.origin), str(fake))
    lid = "STATS-FWD-20261127T000000Z-def456"
    tmpc = tmp_path / "fakework"
    _git(tmp_path, "clone", "-q", "-b", IO.BRANCH, str(fake), str(tmpc))
    with open(tmpc / IO.ACCESS_LOG_REL, "a") as fh:
        fh.write(json.dumps({"kind": "forward_run_start", "ledger_id": lid, "status": "started"}) + "\n")
    _git(tmpc, "commit", "-q", "-am", "fabricated open run")
    _git(tmpc, "push", "-q", "origin", IO.BRANCH)
    L = IO.loaders()
    assert L.open_run_kind(lid, so.work) is None
    for k in [k for k in os.environ if k.startswith("GIT_")]:          # main deletes them: each restored after the test
        monkeypatch.setenv(k, os.environ[k])
    monkeypatch.setenv("GIT_NO_REPLACE_OBJECTS", "0")
    monkeypatch.setenv("GIT_CONFIG_COUNT", "1")
    monkeypatch.setenv("GIT_CONFIG_KEY_0", f"url.{fake}.insteadOf")
    monkeypatch.setenv("GIT_CONFIG_VALUE_0", str(so.origin))
    monkeypatch.setenv("GIT_CONFIG_PARAMETERS", f"'url.{fake}.insteadof'='{so.origin}'")
    assert L.open_run_kind(lid, so.work) == "forward_inputs"            # the hazard: DATA reads the fake origin
    got = []
    monkeypatch.setattr(RF, "check", lambda git=None: got.append((L.open_run_kind(lid, so.work),
                                                                   data_code.locked_run_window(lid))) or 0)
    assert RF.main(["--check"]) == 0
    assert got == [(None, None)]
    assert not [k for k in os.environ if k.startswith("GIT_CONFIG_")]


# ------------------------------------------------------------------ 6: the test-only path needs a running pytest

PYTEST_NAMED = """import sys
sys.path.insert(0, {fwd!r})
import fwd_core as C
C._TEST_ONLY_LOOKS = []
r = {{"net_total": 1.0, "p_net": 0.04, "p_random_side": 0.04, "p_same_tilt": 0.04, "p_shift": 0.04, "block": 5}}
try:
    print(C.forward_verdict(r, 0.05, "any")[0])
except C.Refused:
    print("refused")
"""


@pytest.mark.parametrize("current", [None, "fake::test (call)"])
def test_rt4_6_a_script_named_pytest_is_refused(tmp_path, current):
    """PoC notpytest: a plain script whose file name is `pytest` got a forward verdict. Now the pytest module must be
    loaded and a test running (PYTEST_CURRENT_TEST) too; a convention only (FORWARD.md), but a plain script fails it."""
    d = tmp_path / "notpytest"
    d.mkdir()
    script = d / "pytest"
    script.write_text(PYTEST_NAMED.format(fwd=str(C.HERE)))
    env = {k: v for k, v in os.environ.items() if not k.startswith("OANDA_") and k != "PYTEST_CURRENT_TEST"}
    if current:
        env["PYTEST_CURRENT_TEST"] = current
    r = subprocess.run([sys.executable, str(script)], capture_output=True, text=True, env=env, timeout=300)
    assert r.returncode == 0, r.stderr
    assert r.stdout.split() == ["refused"]


def test_rt4_6_in_process_both_signs_are_needed(monkeypatch):
    r = {"net_total": 1.0, "p_net": 0.04, "p_random_side": 0.04, "p_same_tilt": 0.04, "p_shift": 0.04, "block": 5}
    assert C.forward_verdict(r, 0.05, "T")[0]                           # inside a running test: allowed
    with monkeypatch.context() as m:
        m.delenv("PYTEST_CURRENT_TEST")
        with pytest.raises(C.Refused):
            C.forward_verdict(r, 0.05, "T")
    with monkeypatch.context() as m:
        m.delitem(sys.modules, "pytest")
        with pytest.raises(C.Refused):
            C.forward_verdict(r, 0.05, "T")


# ------------------------------------------------------------------ 8: --check reads nothing more after a refusal

def test_rt4_8_check_skips_the_origin_steps_after_the_worktree_refuses(repos, monkeypatch, capsys):
    """PoC poc_check_reads_origin: --check fetched dept/stats and dept/data (both locks) after its own origin check
    had refused origin. Now the gate and lock steps are skipped."""
    monkeypatch.setattr(IO, "origin_pattern", lambda: IO.loaders().GITHUB_ORIGIN)   # the local origin is refused
    fetched, real = [], IO.Git.fetch
    monkeypatch.setattr(IO.Git, "fetch", lambda self, b: fetched.append(b) or real(self, b))
    assert RF.check(IO.Git(repos.wt)) == 1
    out = capsys.readouterr().out
    assert "FAIL  worktree: Refused: origin resolves to" in out
    assert fetched == []
    for name in ("gate (worktree, tree approval, DEPS pins, calendar pin)", "STATS lock", "DATA lock",
                 "blocks (every FETCH_LOG; DATA's pushed-logs check)", "push access (git push --dry-run)"):
        assert f"SKIP  {name}: the worktree step failed" in out


# ------------------------------------------------------------------ 9: the docs say what the code does

def test_rt4_9_forward_md_and_the_pin_are_current():
    md = (C.STATS / "FORWARD.md").read_text()
    for stale in ("void_after_log", "/r<n>", "the larger of that bar's open and close spreads", "red team 3 pending",
                  "once red team 2 approves", "the void check", "leaves voided positions out",
                  "checkout --detach origin/dept/stats"):
        assert stale not in md, stale
    for needed in ("FORWARD_RULINGS.jsonl", "forward_calendar_ruling", "source.path", "research/departments/DATA/",
                   "origin/dept/data", "--ff-only", "grafts", "shallow", "PYTEST_CURRENT_TEST", "a23f65c0",
                   "no time"):
        assert needed in md, needed
    pin = (C.HERE / "calendars" / "FORWARD_EVENTS.json").read_text()
    assert "source.path" in pin and "research/departments/DATA/" in pin
    red = (C.HERE / "RED_TEAM.md").read_text()
    rt4 = red[red.index("## Red team 4"):red.index("## Red team 5")]
    rows = [ln for ln in rt4.splitlines() if ln.startswith("| ") and ln.split("|")[1].strip().isdigit()]
    assert len(rows) == 9 and all(ln.rstrip(" |").split("|")[-1].strip().startswith(("fixed:", "documented:"))
                                  for ln in rows), rows
