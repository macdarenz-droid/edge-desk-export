"""Red team 5 (forward/RED_TEAM.md): one test (or more) per finding, each failing if its fix is removed. The red team's
proofs (rt5_forward/: poc_status_merge.sh, test_rt5_poc.py, the e2e walk) restated as repo tests. Real git on local
bare origins, synthetic bars and calendars; DATA's published forward calendar (dates and times only) read with git
show. No network, no token, no real price or locked data, no forward number."""
import ast
import json
from datetime import date, datetime, timezone
from pathlib import Path

import pytest

import fwd_core as C
import fwd_io as IO
import run_forward as RF
import synth as S
from test_io import DAY, NOW, OPEN_LID, FakeOps, StatsOrigin, _git, data_code, fake_candles, sandbox  # noqa: F401
from test_redteam import git, repos  # noqa: F401  (fixtures)
from test_rt3 import _block_line, _push_branch_file
from test_rt4 import DATA_CAL, DATA_COMMIT, data_bytes, edited, write_cal  # noqa: F401

F, E = "FOMC_STATEMENT", "ECB_DECISION"
LID = "STATS-FWD-20261208T000000Z-aaaaaa"
START = {"utc": "2026-12-08T00:00:00Z", "kind": "forward_run_start", "ledger_id": LID, "status": "started"}
READ = {"utc": "2026-12-08T00:05:00Z", "dept": "STATS", "study": "FORWARD", "era": "HOLDOUT+FORWARD",
        "override": "forward_inputs", "ledger_id": LID, "datasets": ["STATS_FORWARD_EUR_USD_M1_BA"]}   # loaders' line
DONE = {"utc": "2026-12-08T01:00:00Z", "kind": "forward_run_done", "ledger_id": LID, "status": "done"}
STATUS = {"dept": "STATS", "phase": "serving", "next": "the forward log", "oanda_job": None, "blockers": []}
BLOCK = {"utc": "2026-12-08T00:30:00Z", "source": "oanda_download", "url": "https://api-fxpractice.oanda.com/x",
         "status": 429, "bytes": 0, "via": "answer", "note": "block: no request to this host for 24 hours"}  # DATA's
HELD = {"FOMC_STATEMENT-2026-10-28": {"status": "held", "source_read_utc": "2026-10-28T20:00:00Z"},
        "ECB_DECISION-2026-10-29": {"status": "held", "source_read_utc": "2026-10-29T15:00:00Z"},
        "FOMC_STATEMENT-2026-12-09": {"status": "held", "source_read_utc": "2026-12-09T21:00:00Z"}}


# ------------------------------------------------------------------ real-git runner worktree (repos fixture)

@pytest.fixture
def runner(repos, monkeypatch):
    """repos with a realistic STATUS.json on origin (keys around oanda_job, as the real file) and the runner's files
    pointed at the runner worktree; closing retries without waiting."""
    st = repos.main / IO.STATS_STATUS_REL
    st.write_text(json.dumps(STATUS, indent=1) + "\n")
    git(repos.main, "add", "-A")
    git(repos.main, "commit", "-q", "-m", "a real-looking STATUS.json")
    git(repos.main, "push", "-q", "origin", "dept/stats")
    git(repos.wt, "fetch", "-q", "origin")
    git(repos.wt, "merge", "-q", "--ff-only", "origin/dept/stats")
    for name, rel in (("ACCESS_LOG", IO.ACCESS_LOG_REL), ("STATS_STATUS", IO.STATS_STATUS_REL),
                      ("FETCH_LOG", IO.FETCH_LOG_REL)):
        monkeypatch.setattr(IO, name, repos.wt / rel)
    monkeypatch.setattr(IO, "CLOSING_WAIT_S", 0.0)
    return repos


def paths():
    return [IO.ACCESS_LOG, IO.STATS_STATUS, IO.FETCH_LOG]


def start_run(r, job_started="2026-12-08T00:00:00Z"):
    """The run's start commit, pushed: start line and STATS's oanda_job."""
    g = IO.Git(r.wt)
    IO.append_access(START, IO.ACCESS_LOG)
    IO.set_oanda_job({"what": f"STATS forward log download {LID}", "started_utc": job_started, "ledger_id": LID},
                     IO.STATS_STATUS)
    assert g.commit_push(paths(), "start")
    return g


def close_run(g, rebuild=True):
    """The closing commit: DATA's loaders read line (no kind), the closing line, the lock cleared, a block line."""
    _append(IO.ACCESS_LOG, READ)
    IO.append_access(DONE, IO.ACCESS_LOG)
    IO.set_oanda_job(None, IO.STATS_STATUS)
    _append(IO.FETCH_LOG, BLOCK)
    return g.commit_push(paths(), "closing", rebuild=rebuild)


def _append(p, row):
    with open(p, "a") as f:
        f.write(json.dumps(row) + "\n")


def session(r, what):
    """The STATS session pushes an edit to dept/stats while the run is going (rt5 poc_status_merge.sh)."""
    git(r.main, "fetch", "-q", "origin")
    git(r.main, "reset", "-q", "--hard", "origin/dept/stats")
    if what == "access":
        _append(r.main / IO.ACCESS_LOG_REL, {"utc": "2026-12-08T00:20:00Z", "dept": "STATS", "study": "AUDIT",
                                              "era": "BUILD", "note": "session read"})
    else:
        p = r.main / IO.STATS_STATUS_REL
        s = json.loads(p.read_text())
        s[what] = "edited by the session during the run" if what == "next" else ["a new blocker"]
        p.write_text(json.dumps(s, indent=1) + "\n")
    git(r.main, "add", "-A")
    git(r.main, "commit", "-q", "-m", f"session: {what}")
    git(r.main, "push", "-q", "origin", "dept/stats")


def origin_text(r, rel):
    return git(r.origin, "show", f"dept/stats:{rel}")


def hook(r, script):
    h = r.origin / "hooks" / "pre-receive"
    h.write_text("#!/bin/sh\n" + script)
    h.chmod(0o755)
    return h


# ------------------------------------------------------------------ 1 (MAJOR): the closing push

def test_rt5_1a_the_runs_read_line_is_part_of_its_closing_commit(runner):
    """PoC test_b: a closing commit of a run that read data also holds DATA's loaders read line (no kind). It was
    'not a runner's closing commit (ACCESS_LOG lines ['None'])'; now it is, and the refusal names --push-closing."""
    g = start_run(runner)
    hook(runner, "exit 1\n")
    assert close_run(g) is False
    with pytest.raises(IO.Refused, match=r"holds a closing commit not on origin/dept/stats .*push it with "
                                         r"`python3 research/departments/STATS/forward/run_forward.py --push-closing`"):
        IO.worktree_check(g)
    starts, closing, other = IO.runner_lines([READ, DONE])
    assert not starts and len(closing) == 2 and other == []
    for line in ({**READ, "ledger_id": "STATS-FWD-other"}, {**READ, "override": "validation"},
                 {**READ, "kind": None}):                               # another run's, another override, a null kind
        assert IO.runner_lines([line, DONE])[2] == ["None"], line


@pytest.mark.parametrize("what", ["next", "blockers", "access"])
def test_rt5_1b_a_session_edit_during_the_run_still_lands_the_closing_commit(runner, what):
    """PoC poc_status_merge.sh: a session edit to STATUS.json next or blockers, or an appended ACCESS_LOG line,
    pushed during the run made the closing merge conflict, so the lock stayed set. Now the closing commit is rebuilt
    on origin: the session's edit stays, oanda_job is cleared, every line is there once."""
    g = start_run(runner)
    session(runner, what)
    assert close_run(g) is True
    st = json.loads(origin_text(runner, IO.STATS_STATUS_REL))
    assert st["oanda_job"] is None and st["phase"] == "serving"
    if what == "next":
        assert st["next"] == "edited by the session during the run"
    if what == "blockers":
        assert st["blockers"] == ["a new blocker"]
    lines = origin_text(runner, IO.ACCESS_LOG_REL).splitlines()
    kinds = [json.loads(x).get("kind", json.loads(x).get("note")) for x in lines]
    assert kinds.count("forward_run_start") == 1 and kinds.count("forward_run_done") == 1
    assert sum(1 for x in lines if json.loads(x) == READ) == 1
    assert ("session read" in kinds) == (what == "access") and len(lines) == len(set(lines))
    assert "429" in origin_text(runner, IO.FETCH_LOG_REL)
    assert IO.worktree_check(g) == g.rev("origin/dept/stats")             # the worktree moved to the pushed commit


def test_rt5_1b_one_rejected_push_lands_on_retry(runner):
    g = start_run(runner)
    marker = runner.tmp / "reject_once"
    marker.write_text("x")
    hook(runner, f"if [ -f {marker} ]; then rm -f {marker}; exit 1; fi\nexit 0\n")
    assert close_run(g) is True and not marker.exists()
    assert "forward_run_done" in origin_text(runner, IO.ACCESS_LOG_REL)
    assert IO.worktree_check(g)


def test_rt5_1c_never_landing_fails_the_run_and_push_closing_recovers(runner):
    """Every push rejected: False after CLOSING_TRIES; the next run (worktree_check) and --clear-stale-lock (which
    starts with the same check) refuse with the recovery; once origin takes pushes again, --push-closing lands it,
    rebuilt on a session edit made meanwhile, and the worktree passes again."""
    g = start_run(runner)
    tries = runner.tmp / "tries"
    hook(runner, f"echo x >> {tries}\nexit 1\n")
    assert close_run(g) is False
    assert len(C.checked_reader("read_text")(tries).splitlines()) == 1 + IO.CLOSING_TRIES   # the first push, then retries
    with pytest.raises(IO.Refused, match="--push-closing"):
        IO.worktree_check(g)
    (runner.origin / "hooks" / "pre-receive").unlink()
    session(runner, "next")
    IO.push_closing(g)
    st = json.loads(origin_text(runner, IO.STATS_STATUS_REL))
    assert st["oanda_job"] is None and st["next"] == "edited by the session during the run"
    assert "forward_run_done" in origin_text(runner, IO.ACCESS_LOG_REL)
    assert IO.worktree_check(g) == g.rev("origin/dept/stats")
    with pytest.raises(IO.Refused, match="nothing to push"):
        IO.push_closing(g)
    IO.append_access({**START, "ledger_id": "STATS-FWD-20261209T000000Z-cccccc"}, IO.ACCESS_LOG)
    git(runner.wt, "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-qam", "a start whose push failed")
    with pytest.raises(IO.Refused, match="not a runner's closing commit only"):
        IO.push_closing(g)                                               # a start line is never pushed by it


def test_rt5_1c_the_run_reports_failed_closing_push_and_exits_non_zero(sandbox, capsys):
    ops = FakeOps(sandbox, push=[True, False])                    # the start push lands, the closing push never does
    r = RF.run(DAY, ops, now=NOW)
    assert r["status"] == "failed: closing push" and RF.exit_code(r) == 3
    assert ops.rebuilds == [False, True]                          # only the closing commit is rebuilt
    err = capsys.readouterr().err
    assert "failed: closing push" in err and "run_forward.py --push-closing" in err
    ok = RF.run(DAY, FakeOps(sandbox), now=NOW)
    assert ok["status"] == "done" and RF.exit_code(ok) == 0
    assert RF.exit_code({"status": "failed: locked push"}) == 3


def test_rt5_1b_rebuild_refuses_other_paths_and_merges_lines_exactly(runner):
    g = start_run(runner)
    hook(runner, "exit 1\n")
    (runner.wt / "research/departments/STATS/notes.txt").write_text("not the runner's\n")
    git(runner.wt, "add", "-A")
    git(runner.wt, "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", "another path")
    (runner.origin / "hooks" / "pre-receive").unlink()
    session(runner, "next")
    with pytest.raises(IO.Refused, match="besides"):
        g.rebuild_push(g.head(), [IO.ACCESS_LOG_REL, IO.STATS_STATUS_REL, IO.FETCH_LOG_REL], "x")
    # red team 6 (F1, F3): lines are the ones ours added since the merge base, after origin's bytes; the lock is
    # released only when origin's is free or this commit's run's (the old "always release" is gone)
    assert IO.merge_lines(b"a\nb\nx\n", b"a\nb\nc\nd\n", b"a\nb\n") == b"a\nb\nx\nc\nd\n"
    assert IO.merge_lines(b"a\nc\n", b"a\nc\n", b"a\n") == b"a\nc\n"       # c already landed: not twice
    assert IO.merge_lines(b"", b"") == b""
    theirs = json.dumps({"next": "n", "oanda_job": {"what": "x", "ledger_id": LID}}, indent=1).encode() + b"\n"
    ours = json.dumps({"next": "old", "oanda_job": None}, indent=1).encode() + b"\n"
    assert json.loads(IO.merge_status(theirs, ours, {LID})) == {"next": "n", "oanda_job": None}
    assert IO.merge_status(theirs, ours, {"STATS-FWD-other"}) == theirs     # another run's lock is kept
    assert IO.merge_status(ours, ours) == ours
    with pytest.raises(IO.Refused):
        IO.merge_status(b"{", ours)


# ------------------------------------------------------------------ 2: blocks before the start push, and in --check

def test_rt5_2_blocks_are_checked_before_the_start_push(data_code, monkeypatch, tmp_path):
    """A fresh 429 in another department's FETCH_LOG on origin, or a missing required branch, refused only after the
    start push opened a window. preflight_blocks refuses first; the run calls it before the start line."""
    so = data_code.stats_origin
    g = IO.Git(so.work)
    dd = tmp_path / "dd"
    dd.mkdir()
    assert "no live block" in IO.preflight_blocks(g, dd)
    url = f"https://{data_code.blocks.site('api-fxpractice.oanda.com')}/v3/x"
    (dd / IO.FETCH_LOG_NAME).write_text(_block_line(url))                 # the data dir's copy (check_blocks)
    with pytest.raises(IO.Refused, match="blocked"):
        IO.preflight_blocks(g, dd)
    (dd / IO.FETCH_LOG_NAME).unlink()
    _push_branch_file(so, "dept/macro", "research/departments/MACRO/fetch_logs/2026-12.jsonl", _block_line(url))
    with pytest.raises(IO.Refused, match="blocked"):                     # a log only DATA's pushed-logs read sees
        IO.preflight_blocks(g, dd)
    _push_branch_file(so, "dept/macro", "research/departments/MACRO/FETCH_LOG.jsonl", _block_line(url))
    with pytest.raises(IO.Refused, match="blocked"):
        IO.preflight_blocks(g, dd)
    _git(so.main, "push", "-q", "origin", ":refs/heads/dept/macro")      # the block gone, and a required branch too
    with pytest.raises(IO.Refused, match="pushed-logs check refuses"):
        IO.preflight_blocks(g, dd)


def test_rt5_2_the_run_refuses_on_a_block_before_anything_is_pushed(sandbox):
    ops = FakeOps(sandbox)
    ops.blocks_error = IO.Refused("blocked: a 429")
    with pytest.raises(IO.Refused, match="blocked"):
        RF.run(DAY, ops, now=NOW)
    assert ops.calls == ["gate", "stats_lock", "lock", "blocks"] and not ops.access_rows and not ops.published


def test_rt5_2_check_runs_the_blocks_and_the_push_dry_run(repos, monkeypatch, capsys):
    seen = []
    monkeypatch.setattr(IO, "preflight_blocks", lambda git: seen.append("blocks") or "no live block")
    monkeypatch.setattr(IO, "gate", lambda git: {"tree_sha256": "t"})
    monkeypatch.setattr(IO, "stats_job", lambda git: (True, None))
    monkeypatch.setattr(IO, "data_lock_free", lambda git: True)
    RF.check(IO.Git(repos.wt), now=NOW)
    out = capsys.readouterr().out
    assert seen == ["blocks"] and "ok    blocks (every FETCH_LOG; DATA's pushed-logs check)" in out
    assert "ok    push access (git push --dry-run): origin would take a push" in out
    git(repos.wt, "config", "remote.origin.receivepack", "/bin/false")     # origin takes no push now
    assert IO.Git(repos.wt).push_dry_run()
    RF.check(IO.Git(repos.wt), now=NOW)
    assert "FAIL  push access (git push --dry-run): Refused: origin would not take a push" in capsys.readouterr().out


# ------------------------------------------------------------------ 3 and N1: a time added late to a blank row

def _late(raw):
    return edited(raw, {"FOMC_STATEMENT-2027-01-27": {"local_time": "14:00", "utc": "2027-01-27T19:00:00Z",
                                                      "status": "held", "source_read_utc": "2027-01-28T09:00:00Z"}})


def test_rt5_3_a_late_time_on_a_row_whose_picks_never_ran_is_a_normal_update(tmp_path):
    """PoC test_c: DATA adds the 27 Jan 2027 time after the runner's data end passed it. PA-F4 (ECB) kept running;
    the FOMC picks were refused by check_coverage the whole time, so no run computed with that row blank. That used
    to refuse every pick until a ruling; now it is a normal update. If an FOMC pick had run past it, still a change."""
    raw = edited(data_bytes(), HELD)
    csv_a, meta_a = write_cal(tmp_path / "a", raw)
    cal_a = C.read_calendar(csv_a, meta_a)
    picks, log, day = C.load_picks(), tmp_path / "log.jsonl", date(2027, 1, 28)
    end = C.label_close_ts(day)
    res = C.compute_run(picks, cal_a, S.bars(C.inputs_start(picks), end), end, "RT5-3", run_day=day)
    assert set(res.errors) == {"R53-S3X3", "FC-1"} and res.ran_types == [E]
    C.append_run(res, log, cal_a)
    assert C.last_run_state(C.read_log(log))["ran_types"] == [E]
    cal_b = C.read_calendar(*write_cal(tmp_path / "b", _late(raw)))
    assert C.calendar_changes(C.read_log(log), cal_b) == []
    snap = C.calendar_snapshot(cal_a)
    ran = {"kind": "run_state", "data_end_ts": end, "calendar_rows": snap, "ran_types": [F, E]}
    assert C.calendar_changes([ran], cal_b)                               # an FOMC pick ran past it: a change
    older = {"kind": "run_state", "data_end_ts": end, "calendar_rows": snap}   # an older runner: every type ran
    assert C.calendar_changes([older], cal_b)


def test_rt5_n1_the_highest_data_end_counts(tmp_path):
    """PoC note: a later run with a shorter download no longer lowers the bar for a time added late."""
    raw = edited(data_bytes(), HELD)
    snap = C.calendar_snapshot(C.read_calendar(*write_cal(tmp_path / "a", raw)))
    cal_b = C.read_calendar(*write_cal(tmp_path / "b", edited(raw, {"FOMC_STATEMENT-2027-01-27": {
        "local_time": "14:00", "utc": "2027-01-27T19:00:00Z"}})))
    hi = {"kind": "run_state", "data_end_ts": C.label_close_ts(date(2027, 1, 28)), "calendar_rows": snap,
          "ran_types": [F, E]}
    lo = {**hi, "data_end_ts": C.label_close_ts(date(2027, 1, 20))}
    assert C.calendar_changes([hi], cal_b) and C.calendar_changes([hi, lo], cal_b)
    assert C.calendar_changes([lo], cal_b) == []
    assert C.ran_until([hi, lo]) == {F: hi["data_end_ts"], E: hi["data_end_ts"]}


# ------------------------------------------------------------------ 4: a rebuild that cannot fit one day's budget

def test_rt5_4_the_closing_line_says_when_a_rebuild_cannot_fit_a_days_budget(data_code, monkeypatch, tmp_path):
    D = data_code
    calls = fake_candles(monkeypatch, D)
    git = IO.Git(D.stats_origin.work)
    start = S.ny("2026-05-04", "17:00")                                   # a Monday; 40 windows end before today
    dl_dir = Path(IO.locked_dir()) / "forward"
    dl_dir.mkdir(parents=True)
    (dl_dir / "REQUESTS.json").write_text(json.dumps({"day": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
                                                       "count": 29, "last": 0.0}))
    meter = {}
    IO.download_step(git, OPEN_LID, start, start + 40 * 5000 * 60, dl_dir, meter=meter)
    assert len(calls) == 1                                               # what is downloaded is unchanged
    assert meter["rebuild_note"].startswith("cannot rebuild within one day's budget: 40 windows")
    meter2 = {}
    IO.download_step(git, OPEN_LID, start, start + 40 * 5000 * 60, dl_dir, meter=meter2)
    assert "rebuild_note" not in meter2                                  # a resumed file is no rebuild


def test_rt5_4_the_note_reaches_the_closing_line_and_stdout(sandbox, capsys):
    class Ops(FakeOps):
        def download(self, lid, start, end, meter):
            out = super().download(lid, start, end, meter)
            meter["rebuild_note"] = "cannot rebuild within one day's budget: 40 windows"
            return out
    ops = Ops(sandbox)
    r = RF.run(DAY, ops, now=NOW)
    assert ops.access_rows[-1]["rebuild_note"].startswith("cannot rebuild within one day's budget")
    RF.print_result(r)
    assert "note: cannot rebuild within one day's budget" in capsys.readouterr().out


# ------------------------------------------------------------------ 5: --clear-stale-lock and a killed run's lines

def test_rt5_5_clear_stale_commits_the_killed_runs_lines(runner):
    """A killed run leaves DATA's loaders read line (and maybe a block line) uncommitted; --clear-stale-lock used to
    refuse until `git checkout -- .` deleted the record of a locked read. Now it commits them with its line."""
    g = start_run(runner)
    _append(IO.ACCESS_LOG, READ)                                         # the read line, never committed
    _append(IO.FETCH_LOG, BLOCK)
    r = RF.clear_stale(RF.Ops(g), now=S.utc("2026-12-08T08:00:00"))
    assert r["cleared"] == LID and r["committed_lines"] == 2
    lines = [json.loads(x) for x in origin_text(runner, IO.ACCESS_LOG_REL).splitlines()]
    assert READ in lines and lines[-1]["kind"] == "forward_stale_lock_cleared"
    assert "429" in origin_text(runner, IO.FETCH_LOG_REL)
    assert json.loads(origin_text(runner, IO.STATS_STATUS_REL))["oanda_job"] is None
    assert IO.worktree_check(g) == g.rev("origin/dept/stats")


def test_rt5_5_clear_stale_refuses_lines_of_another_run_or_an_edit(runner):
    g = start_run(runner)
    _append(IO.ACCESS_LOG, {**READ, "ledger_id": "STATS-FWD-20261201T000000Z-bbbbbb"})
    with pytest.raises(IO.Refused, match="is not run .*'s closing or read line"):
        RF.clear_stale(RF.Ops(g), now=S.utc("2026-12-08T08:00:00"))
    git(runner.wt, "checkout", "-q", "--", IO.ACCESS_LOG_REL)
    text = IO.ACCESS_LOG.read_text()
    IO.ACCESS_LOG.write_text(text.replace('"status": "started"', '"status": "edited"'))
    with pytest.raises(IO.Refused, match="other than appended lines"):
        RF.clear_stale(RF.Ops(g), now=S.utc("2026-12-08T08:00:00"))
    with pytest.raises(IO.Refused, match="uncommitted"):
        IO.worktree_check(g, allow_appended=(IO.ACCESS_LOG_REL,))          # an edit is never allowed


def test_rt5_5_a_rejected_clearing_push_is_recognised_and_pushed_by_push_closing(runner):
    g = start_run(runner)
    _append(IO.ACCESS_LOG, READ)
    hook(runner, "exit 1\n")
    with pytest.raises(IO.Refused, match="--push-closing"):
        RF.clear_stale(RF.Ops(g), now=S.utc("2026-12-08T08:00:00"))
    with pytest.raises(IO.Refused, match="push it with"):
        IO.worktree_check(g)                                             # the read line counts (cleared_ledger_id)
    (runner.origin / "hooks" / "pre-receive").unlink()
    IO.push_closing(g, now=S.utc("2026-12-08T08:00:00"))               # the clearing's clock (red team 7, N2)
    assert "forward_stale_lock_cleared" in origin_text(runner, IO.ACCESS_LOG_REL)


# ------------------------------------------------------------------ 6: calendar reasons in the closing line and --check

def test_rt5_6_calendar_reasons_reach_the_closing_line_and_stdout(sandbox, monkeypatch, capsys):
    """From the day a blank FOMC row comes up, the FOMC picks are error lines every run. The closing line and stdout
    now give each one's CalendarError message (dates only), not just its class."""
    csv_p, meta = S.write_calendar(sandbox / "blank", run_day="2026-12-07", overrides={
        ("FOMC_STATEMENT", "2026-12-02T19:00:00Z"): {"utc": "", "local_time": "", "status": "scheduled"}})
    monkeypatch.setattr(C, "CAL_CSV", csv_p)
    monkeypatch.setattr(C, "CAL_META", meta)
    ops = FakeOps(sandbox)
    r = RF.run(DAY, ops, now=NOW)
    closing = ops.access_rows[-1]
    assert set(closing["calendar_errors"]) == {"R53-S3X3", "FC-1"} == set(r["calendar_errors"])
    assert all("2026-12-02 has no time yet" in m for m in closing["calendar_errors"].values())
    assert closing["pick_errors"] == {"R53-S3X3": "CalendarError", "FC-1": "CalendarError"}
    RF.print_result(r)
    out = capsys.readouterr().out
    assert "R53-S3X3: the FOMC_STATEMENT row of 2026-12-02 has no time yet" in out


def test_rt5_6_check_lists_each_picks_coverage(repos, monkeypatch, capsys, tmp_path):
    csv_p, meta = write_cal(tmp_path / "cal", edited(data_bytes(), HELD))
    monkeypatch.setattr(C, "CAL_CSV", csv_p)
    monkeypatch.setattr(C, "CAL_META", meta)
    monkeypatch.setattr(IO, "origin_pattern", lambda: IO.loaders().GITHUB_ORIGIN)   # origin steps skipped
    RF.check(IO.Git(repos.wt), now=S.utc("2026-12-10T23:00:00"))
    out = capsys.readouterr().out
    assert "ok    calendar coverage PA-F4 on 2026-12-10: covered" in out
    assert "note  calendar coverage R53-S3X3 on 2026-12-10: not covered" in out and "2027-01-27 has no time yet" in out
    assert "FAIL  calendar coverage" not in out
    assert RF.last_closed_day(S.utc("2026-12-10T21:30:00")) == date(2026, 12, 9)      # 16:30 New York: not closed


# ------------------------------------------------------------------ N4: testguard.py is a test helper only

def test_rt5_n4_no_runner_file_names_testguard():
    for f in sorted(C.HERE.glob("*.py")):
        names = {n.id for n in ast.walk(ast.parse(f.read_text())) if isinstance(n, ast.Name)}
        mods = {a.name for n in ast.walk(ast.parse(f.read_text())) if isinstance(n, ast.Import) for a in n.names}
        assert "testguard" not in names | mods and "testguard" not in f.read_text(), f.name
    assert "testguard.py" in (C.STATS / "FORWARD.md").read_text()
