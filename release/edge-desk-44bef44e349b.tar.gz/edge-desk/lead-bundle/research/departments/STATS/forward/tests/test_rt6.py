"""Red team 6 (forward/RED_TEAM.md): one test (or more) per finding, each failing if its fix is removed. The red team's
proofs (rt6_forward/: test_rt6_poc.py, poc_lock_theft.py, poc_killed_moved.py) restated as repo tests. Real git on
local bare origins, synthetic lines only. No network, no token, no prices, no forward number."""
import json

import pytest

import fwd_core as C
import fwd_io as IO
import run_forward as RF
import synth as S
from test_io import DAY, NOW, FakeOps, sandbox  # noqa: F401  (fixtures)
from test_redteam import git, repos  # noqa: F401  (fixtures)
from test_rt5 import (BLOCK, DONE, LID, READ, START, _append, close_run, hook, origin_text, paths, runner,  # noqa: F401
                      session, start_run)

B_LID = "STATS-FWD-20261208T070000Z-bbbbbb"
B_JOB = {"what": f"STATS forward log download {B_LID}", "started_utc": "2026-12-08T07:00:00Z", "ledger_id": B_LID}
LATER = S.utc("2026-12-08T08:00:00")                      # 8 h after run A's start: its lock is stale
RELS = [IO.ACCESS_LOG_REL, IO.STATS_STATUS_REL, IO.FETCH_LOG_REL]


def push_from_main(r, mutate, msg):
    git(r.main, "fetch", "-q", "origin")
    git(r.main, "checkout", "-q", "-B", "dept/stats", "origin/dept/stats")
    mutate(r.main)
    git(r.main, "add", "-A")
    git(r.main, "commit", "-q", "-m", msg)
    git(r.main, "push", "-q", "origin", "HEAD:refs/heads/dept/stats")


def b_takes_the_lock(m):
    with open(m / IO.ACCESS_LOG_REL, "a") as f:
        f.write(json.dumps({**START, "ledger_id": B_LID}) + "\n")
    IO.set_oanda_job(B_JOB, m / IO.STATS_STATUS_REL)


def origin_job(r):
    return json.loads(origin_text(r, IO.STATS_STATUS_REL))["oanda_job"]


def origin_lines(r, rel=IO.ACCESS_LOG_REL):
    return [json.loads(x) for x in origin_text(r, rel).split("\n") if x]


# ------------------------------------------------------------------ F1 (MAJOR): another job's lock is kept

def test_rt6_f1_merge_status_keeps_another_runs_lock(capsys):
    theirs = IO.status_bytes({"next": "n", "oanda_job": B_JOB})
    ours = IO.status_bytes({"next": "n", "oanda_job": None})
    assert IO.merge_status(theirs, ours, {LID}) == theirs                 # PoC test_f1_unit: B's lock was dropped
    assert "belongs to 'STATS-FWD-20261208T070000Z-bbbbbb'" in capsys.readouterr().err
    a_job = {**B_JOB, "ledger_id": LID}
    assert IO.job_of(IO.merge_status(IO.status_bytes({"oanda_job": a_job}), ours, {LID})) is None   # its own: released
    assert IO.job_of(IO.merge_status(IO.status_bytes({"next": "n"}), ours, set())) is None          # missing: free
    with pytest.raises(IO.Refused, match="only releases it"):
        IO.merge_status(theirs, IO.status_bytes({"oanda_job": B_JOB}), {B_LID})


def test_rt6_f1_the_runs_own_closing_rebuild_keeps_another_jobs_lock(runner, capsys):
    """PoC test_f1_the_runs_own_closing_rebuild: origin moved because another job took the lock meanwhile; the
    rebuilt closing commit keeps that lock and appends run A's lines."""
    g = start_run(runner)
    push_from_main(runner, lambda m: IO.set_oanda_job(B_JOB, m / IO.STATS_STATUS_REL), "another job took the lock")
    assert close_run(g) is True
    assert origin_job(runner)["ledger_id"] == B_LID
    assert DONE in origin_lines(runner) and READ in origin_lines(runner)
    assert "kept" in capsys.readouterr().err


def test_rt6_f1_lock_theft_chain_push_closing_leaves_bs_lock_and_check_says_taken(runner, monkeypatch, capsys):
    """PoC poc_lock_theft: A's closing push never lands; a fresh container clears A's lock as stale; run B takes the
    lock; A's --push-closing then used to set origin's oanda_job to null while B ran, and --check said "free". Now
    B's lock stays and --check's STATS lock step says "taken by" B. Since red team 7 (N2) A's --push-closing is
    refused outright, because origin already holds a closing line for A (the clearing line): A's lines are sorted by
    hand (FORWARD.md "Stale lock"), never pushed by the runner."""
    g = start_run(runner)
    hook(runner, "exit 1\n")
    assert close_run(g) is False                                          # run A: "failed: closing push"
    (runner.origin / "hooks" / "pre-receive").unlink()
    fresh_main, fresh_wt = runner.tmp / "fresh_main", runner.tmp / "fresh_wt"   # a fresh container
    git(runner.tmp, "clone", "-q", str(runner.origin), str(fresh_main))
    git(fresh_main, "worktree", "add", "-q", "--detach", str(fresh_wt), "origin/dept/stats")
    w1 = {n: getattr(IO, n) for n in ("ACCESS_LOG", "STATS_STATUS", "FETCH_LOG")}
    for n, rel in (("ACCESS_LOG", IO.ACCESS_LOG_REL), ("STATS_STATUS", IO.STATS_STATUS_REL),
                   ("FETCH_LOG", IO.FETCH_LOG_REL)):
        monkeypatch.setattr(IO, n, fresh_wt / rel)
    r = RF.clear_stale(RF.Ops(IO.Git(fresh_wt)), now=LATER)              # the fresh container clears A, 8 h later
    assert r["cleared"] == LID and origin_job(runner) is None
    for n, v in w1.items():
        monkeypatch.setattr(IO, n, v)
    push_from_main(runner, b_takes_the_lock, "run B started")             # B takes the lock
    assert origin_job(runner)["ledger_id"] == B_LID
    with pytest.raises(IO.Refused, match=f"run {LID} already has a closing line"):
        IO.push_closing(g)                                                # A's documented recovery
    assert origin_job(runner)["ledger_id"] == B_LID                       # B's lock stays
    assert DONE not in origin_lines(runner) and READ not in origin_lines(runner)   # by hand, never by the runner
    assert not IO.stats_lock_free(g)
    with pytest.raises(IO.Refused, match=r"already have a closing line there .*by hand .*never STATUS\.json"):
        IO.worktree_check(g)
    mb = git(runner.wt, "merge-base", "HEAD", "origin/dept/stats")

    def hand_step(m):                                                     # FORWARD.md "Stale lock": the lines only
        for rel in (IO.ACCESS_LOG_REL, IO.FETCH_LOG_REL):
            with open(m / rel, "ab") as f:
                f.write(IO.added_bytes(g.show_bytes(mb, rel) or b"", g.show_bytes("HEAD", rel) or b"", rel))
    push_from_main(runner, hand_step, "session: run A's closing lines, by hand")
    with pytest.raises(IO.Refused, match="already on origin/dept/stats .*git reset --keep origin/dept/stats"):
        IO.worktree_check(g)                                              # origin's lock is B's, not A's
    git(runner.wt, "reset", "-q", "--keep", "origin/dept/stats")
    assert DONE in origin_lines(runner) and READ in origin_lines(runner) and origin_job(runner)["ledger_id"] == B_LID
    monkeypatch.setattr(IO, "gate", lambda git: {"tree_sha256": "t"})
    monkeypatch.setattr(IO, "preflight_blocks", lambda git: "no live block")
    capsys.readouterr()
    RF.check(g, now=NOW)
    assert f"FAIL  STATS lock: Refused: taken by {B_LID}" in capsys.readouterr().out


# ------------------------------------------------------------------ F2: --clear-stale-lock with origin moved

def test_rt6_f2_clear_stale_works_with_origin_moved(runner):
    """PoC poc_killed_moved: after a killed run, a session line on origin left the worktree behind, and the clear
    refused ("merge --ff-only first"); merging failed on the leftovers. Now the clearing commit is made on HEAD and
    rebuilt on origin: the session line, the killed run's read line and the clearing line are all there."""
    g = start_run(runner)
    _append(IO.ACCESS_LOG, READ)                                          # killed after its locked read
    session(runner, "access")                                             # origin's ACCESS_LOG moves
    r = RF.clear_stale(RF.Ops(g), now=LATER)
    assert r["cleared"] == LID
    lines = origin_lines(runner)
    assert READ in lines and any(x.get("note") == "session read" for x in lines)
    assert lines[-1]["kind"] == "forward_stale_lock_cleared" and lines[-1]["cleared_ledger_id"] == LID
    assert origin_job(runner) is None
    assert IO.worktree_check(g) == g.rev("origin/dept/stats")             # moved to the pushed commit


def test_rt6_f2_a_head_ahead_or_diverged_is_still_refused(runner):
    g = start_run(runner)
    git(runner.wt, "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "--allow-empty", "-m", "ahead")
    with pytest.raises(IO.Refused):
        RF.clear_stale(RF.Ops(g), now=LATER)


# ------------------------------------------------------------------ F3: merge_lines keeps origin's bytes

def test_rt6_f3_a_line_origin_corrected_does_not_come_back():
    old = b'{"kind":"x","ledger_id":"L1","era":"VALIDATIN"}\n'
    fixed = b'{"kind":"x","ledger_id":"L1","era":"VALIDATION"}\n'
    done = b'{"kind":"forward_run_done","ledger_id":"A"}\n'
    assert IO.merge_lines(fixed, old + done, old) == fixed + done          # PoC: the corrected line came twice


@pytest.mark.parametrize("odd", [" ", "\u0085", "\r", " \x0c"])
def test_rt6_f3_odd_characters_inside_a_json_line_stay_one_line(odd):
    line = json.dumps({"note": f"pasted{odd}text"}, ensure_ascii=False).encode() + b"\n"
    done = b'{"kind":"forward_run_done","ledger_id":"A"}\n'
    out = IO.merge_lines(line, line + done, line)
    assert out == line + done and json.loads(out.split(b"\n")[0]) == {"note": f"pasted{odd}text"}
    mine = json.dumps({"ledger_id": "A", "main_path": f"x{odd}y"}, ensure_ascii=False).encode() + b"\n"
    out = IO.merge_lines(b"", mine + done, b"")                           # ours: split on b"\n" only, too
    assert out == mine + done and len(out.split(b"\n")) == 3


def test_rt6_f3_crlf_lines_are_kept_and_changed_lines_refuse():
    crlf = b'{"a":1}\r\n{"b":2}\r\n'
    assert IO.merge_lines(crlf, crlf + b'{"c":3}\n', crlf) == crlf + b'{"c":3}\n'   # PoC: every line was rewritten
    with pytest.raises(IO.Refused, match="not an append"):
        IO.merge_lines(crlf, b'{"a":9}\r\n{"b":2}\r\n{"c":3}\n', crlf)


def test_rt6_f3_a_rebuilt_closing_commit_keeps_a_session_line_with_a_line_separator(runner):
    g = start_run(runner)

    def odd(m):
        with open(m / IO.ACCESS_LOG_REL, "ab") as f:
            f.write(json.dumps({"dept": "STATS", "note": "a b"}, ensure_ascii=False).encode() + b"\n")
    push_from_main(runner, odd, "session: a line with U+2028")
    assert close_run(g) is True
    raw = git(runner.origin, "show", f"dept/stats:{IO.ACCESS_LOG_REL}")
    assert [json.loads(x) for x in raw.split("\n") if x][-3]["note"] == "a b"


# ------------------------------------------------------------------ F4: push_closing's fast-forward path

def test_rt6_f4_the_fast_forward_path_checks_paths_and_the_lock(runner):
    """PoC test_f4: a fast-forward pushed any path and any oanda_job. Now: another path refuses, a commit that sets
    a lock refuses, and a fast-forward over another run's lock is rebuilt, which keeps that lock."""
    g = start_run(runner)
    hook(runner, "exit 1\n")
    _append(IO.ACCESS_LOG, READ)
    _append(IO.ACCESS_LOG, DONE)
    IO.set_oanda_job(B_JOB, IO.STATS_STATUS)                              # a lock, not a release
    (runner.wt / "research/departments/STATS/forward_note.txt").write_text("any other file\n")
    git(runner.wt, "add", "-A")
    git(runner.wt, "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", "closing + other path")
    (runner.origin / "hooks" / "pre-receive").unlink()
    with pytest.raises(IO.Refused, match="besides"):
        IO.push_closing(g)
    git(runner.wt, "rm", "-q", "research/departments/STATS/forward_note.txt")
    git(runner.wt, "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", "drop the other path")
    with pytest.raises(IO.Refused, match="sets STATS's oanda_job"):
        IO.push_closing(g)


def test_rt6_f4_a_fast_forward_over_another_runs_lock_keeps_it(runner):
    g = start_run(runner)
    push_from_main(runner, lambda m: IO.set_oanda_job(B_JOB, m / IO.STATS_STATUS_REL), "B's lock (by hand)")
    git(runner.wt, "fetch", "-q", "origin")
    git(runner.wt, "merge", "-q", "--ff-only", "origin/dept/stats")
    hook(runner, "exit 1\n")
    assert close_run(g) is False                                          # built on B's lock: a fast-forward
    (runner.origin / "hooks" / "pre-receive").unlink()
    IO.push_closing(g)
    assert origin_job(runner)["ledger_id"] == B_LID and DONE in origin_lines(runner)


# ------------------------------------------------------------------ F5: clear_stale's leftover lines

def test_rt6_f5_leftover_lines_outside_the_whitelists_refuse(runner):
    g = start_run(runner)
    _append(IO.ACCESS_LOG, {"ledger_id": LID, "kind": "forward_run_start", "net_r": 2.5})    # PoC test_f5
    with pytest.raises(IO.Refused, match="uncommitted forward_run_start line .*sort it by hand"):   # red team 7, 1
        RF.clear_stale(RF.Ops(g), now=LATER)
    git(runner.wt, "checkout", "-q", "--", IO.ACCESS_LOG_REL)
    for bad in ({**READ, "net_r": 2.5}, {**READ, "override": "validation"}, {**DONE, "net_r": 1}):
        _append(IO.ACCESS_LOG, bad)
        with pytest.raises(IO.Refused, match="closing or read line"):
            RF.clear_stale(RF.Ops(g), now=LATER)
        git(runner.wt, "checkout", "-q", "--", IO.ACCESS_LOG_REL)
    _append(IO.FETCH_LOG, {"utc": "2026-12-08T00:30:00Z", "url": "https://x", "status": 429, "net": 1})
    with pytest.raises(IO.Refused, match="not DATA's block line"):
        RF.clear_stale(RF.Ops(g), now=LATER)


def test_rt6_f5_an_in_line_edit_is_not_an_append(runner):
    """PoC test_f5_append_check: U+2028 plus a line glued onto the last committed line passed as appended."""
    g = start_run(runner)
    raw = C.checked_reader("read_bytes")(IO.ACCESS_LOG)
    IO.ACCESS_LOG.write_bytes(raw[:-1] + " ".encode() + json.dumps(READ).encode() + b"\n")
    assert IO.appended_lines(g, IO.ACCESS_LOG_REL) is None
    with pytest.raises(IO.Refused, match="uncommitted"):
        RF.clear_stale(RF.Ops(g), now=LATER)


# ------------------------------------------------------------------ F6: killed after releasing its lock

@pytest.mark.parametrize("staged", [False, True])
def test_rt6_f6_a_run_killed_after_its_lock_release_can_be_cleared(runner, staged):
    """PoC test_f5_killed_after_the_lock_release_line: STATUS.json changed in oanda_job alone (unstaged, or staged
    by a git add before the kill) no longer blocks the clear; the killed run's lines are committed."""
    g = start_run(runner)
    _append(IO.ACCESS_LOG, READ)
    _append(IO.ACCESS_LOG, DONE)
    IO.set_oanda_job(None, IO.STATS_STATUS)
    if staged:
        git(runner.wt, "add", "-A")
    RF.clear_stale(RF.Ops(g), now=LATER)
    lines = origin_lines(runner)
    assert READ in lines and DONE in lines and lines[-1]["kind"] == "forward_stale_lock_cleared"
    assert origin_job(runner) is None and IO.worktree_check(g)


def test_rt6_f6_any_other_status_change_refuses(runner):
    g = start_run(runner)
    st = json.loads(IO.STATS_STATUS.read_text())
    IO.STATS_STATUS.write_bytes(IO.status_bytes({**st, "oanda_job": None, "next": "edited by hand"}))
    with pytest.raises(IO.Refused, match="uncommitted"):
        RF.clear_stale(RF.Ops(g), now=LATER)


# ------------------------------------------------------------------ F7: a refused rebuild, a push that landed

def test_rt6_f7_a_refused_closing_rebuild_keeps_the_result_and_exit_3(sandbox, capsys):
    class Ops(FakeOps):
        def publish(self, paths, msg, rebuild=False):
            if rebuild:
                self.calls.append("publish")
                raise IO.Refused("the closing commit changes ['x'] besides ...")
            return super().publish(paths, msg, rebuild)
    ops = Ops(sandbox)
    r = RF.run(DAY, ops, now=NOW)
    assert r["status"] == "failed: closing push" and RF.exit_code(r) == 3 and r["new_lines"] == 5
    err = capsys.readouterr().err
    assert "not rebuilt" in err and "--push-closing" in err


def test_rt6_f7_a_landed_rebuild_names_reset_keep(runner):
    g = start_run(runner)
    session(runner, "next")
    hook(runner, "exit 1\n")
    assert close_run(g) is False
    (runner.origin / "hooks" / "pre-receive").unlink()
    old, base = g.head(), g.rev("origin/dept/stats")
    mb = git(runner.wt, "merge-base", old, base)
    new = g._rebuilt(old, base, mb, RELS, "landed, reported failed", {LID})
    git(runner.wt, "push", "-q", "origin", f"{new}:refs/heads/dept/stats")          # landed; the worktree not moved
    with pytest.raises(IO.Refused, match="already on origin/dept/stats .*git reset --keep origin/dept/stats"):
        IO.worktree_check(g)
    git(runner.wt, "reset", "-q", "--keep", "origin/dept/stats")
    assert IO.worktree_check(g) == new


# ------------------------------------------------------------------ F8: no prompt; STATUS.json's own format

def test_rt6_f8_git_never_prompts_and_status_json_keeps_its_format(monkeypatch):
    monkeypatch.setenv("GIT_TERMINAL_PROMPT", "1")                       # whatever the caller's environment says
    assert C.git_env()["GIT_TERMINAL_PROMPT"] == "0"
    real = C.checked_reader("read_bytes")(C.STATS / "STATUS.json")              # the real file's format
    assert IO.status_bytes(json.loads(real)) == real
    theirs = IO.status_bytes({"next": "café ✓", "oanda_job": {**B_JOB, "ledger_id": LID}})
    merged = IO.merge_status(theirs, IO.status_bytes({"oanda_job": None}), {LID})
    assert merged == IO.status_bytes({"next": "café ✓", "oanda_job": None}) and "café ✓".encode() in merged
    assert merged.startswith(b'{\n  "next"')


# ------------------------------------------------------------------ held: dry run moves nothing; ran_until

def test_rt6_dry_run_pushes_nothing_and_moves_no_ref(repos):
    g = IO.Git(repos.wt)
    (repos.wt / "x.txt").write_text("x\n")
    git(repos.wt, "add", "-A")
    git(repos.wt, "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", "ahead")
    before = (git(repos.origin, "rev-parse", "dept/stats"), g.rev("origin/dept/stats"))
    assert g.push_dry_run() == ""
    assert (git(repos.origin, "rev-parse", "dept/stats"), g.rev("origin/dept/stats")) == before


def test_rt6_ran_until_per_type():
    def st(end, types=None):
        return {"kind": "run_state", "data_end_ts": end, **({} if types is None else {"ran_types": types})}
    assert C.ran_until([st(100, ["FOMC_STATEMENT", "ECB_DECISION"]), st(200, ["ECB_DECISION"])]) == \
        {"FOMC_STATEMENT": 100, "ECB_DECISION": 200}
    assert C.ran_until([st(300), st(200, ["ECB_DECISION"])]) == {"FOMC_STATEMENT": 300, "ECB_DECISION": 300}
    assert C.ran_until([st(300, []), st(50, ["FOMC_STATEMENT"])]) == {"FOMC_STATEMENT": 50}
