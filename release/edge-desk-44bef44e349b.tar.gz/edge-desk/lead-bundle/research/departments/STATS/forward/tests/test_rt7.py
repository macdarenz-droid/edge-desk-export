"""Red team 7 (forward/RED_TEAM.md): one test (or more) per finding, each failing if its fix is removed. The red team's
proofs (rt7_forward/test_rt7_poc.py, 7 tests) restated as repo tests of the fixed behaviour. Real git on local bare
origins, synthetic lines only. No network, no token, no prices, no forward number."""
import ast
import inspect
import json
import os
import re
import subprocess
import sys
import textwrap

import pytest

import fwd_core as C
import fwd_io as IO
import run_forward as RF
import synth as S
from test_io import DAY, NOW, FakeOps, sandbox  # noqa: F401  (fixtures)
from test_redteam import git, repos  # noqa: F401  (fixtures)
from test_rt5 import (BLOCK, DONE, LID, READ, START, _append, close_run, hook, origin_text, runner,  # noqa: F401
                      start_run)
from test_rt6 import B_JOB, B_LID, LATER, RELS, b_takes_the_lock, origin_job, origin_lines, push_from_main

RULINGS = "research/departments/STATS/FORWARD_RULINGS.jsonl"
MACRO = {"utc": "2026-12-08T00:06:00Z", "dept": "STATS", "study": "FORWARD", "era": "HOLDOUT+FORWARD",
         "first_ts": None, "last_ts": None, "code_sha256": "c", "frozen_sha256": "f", "run_id": "r", "kind": "macro",
         "series": "US_10Y", "sha256": "s", "asof_bound": 1, "rows": 3, "rows_dropped": 0, "before_run": False,
         "common_sha256": "m", "override": "forward_inputs", "ledger_id": LID}    # DATA's macro line, of run A


def hand_commit(r, msg):
    git(r.wt, "add", "-A")
    git(r.wt, "commit", "-q", "-m", msg)


def ff(r):
    git(r.wt, "fetch", "-q", "origin")
    git(r.wt, "merge", "-q", "--ff-only", "origin/dept/stats")


def tracked_log(r):
    """ACCESS_LOG.jsonl tracked on origin with an earlier line, as on the real dept/stats."""
    push_from_main(r, lambda m: _append(m / IO.ACCESS_LOG_REL, {"utc": "2026-12-01T00:00:00Z", "dept": "STATS",
                                                                "study": "AUDIT", "era": "BUILD"}), "a session line")
    ff(r)


def killed_in_start_step(r, lock=True):
    """A run killed between its start line and its start commit: line (and lock) in the worktree only."""
    IO.append_access(START, IO.ACCESS_LOG)
    if lock:
        IO.set_oanda_job({"what": "x", "started_utc": START["utc"], "ledger_id": LID}, IO.STATS_STATUS)
    return IO.Git(r.wt)


# ------------------------------------------------------------------ 1 (MINOR): a run killed inside its start step

@pytest.mark.parametrize("lock,staged", [(True, False), (False, False), (True, True)])
def test_rt7_1_a_start_killed_before_its_commit_says_this_run_read_nothing(runner, lock, staged):
    """PoC test_m1: `run` refused "uncommitted" and --clear-stale-lock said "nothing to clear", with no advice, and the
    hand step would publish the start line. Now both (and the gate, which `run` calls first) refuse with the restore
    step, and doing it makes the worktree origin again; origin never holds the line or the lock. Killed between its
    git add and its commit (staged), the step restores from HEAD."""
    tracked_log(runner)
    g = killed_in_start_step(runner, lock)
    if staged:
        git(runner.wt, "add", "--", IO.ACCESS_LOG_REL, IO.STATS_STATUS_REL)
    text = IO.READ_NOTHING_STAGED if staged else IO.READ_NOTHING
    msg = re.escape(text)
    with pytest.raises(IO.Refused, match=msg):
        IO.worktree_check(g)
    with pytest.raises(IO.Refused, match=msg):
        IO.gate(g)                                                        # run()'s first step
    with pytest.raises(IO.Refused, match=msg):
        RF.clear_stale(RF.Ops(g), now=4e9)
    assert IO.start_state(g, LID) == "absent" and IO.stats_lock_free(g)
    step = text[text.index("(git ") + 1:-1].split()                     # the command the message gives
    git(runner.wt, *step[1:])
    assert IO.worktree_check(g) == g.rev("origin/dept/stats")


def test_rt7_1_the_message_is_forward_mds():
    """FORWARD.md's "Stale lock" step quotes the runner's message and says the hand step never carries a start line."""
    doc = C.checked_reader("read_text")(C.STATS / "FORWARD.md")
    assert IO.READ_NOTHING in doc and IO.READ_NOTHING_STAGED in doc
    assert "never carries a start line" in doc


@pytest.mark.parametrize("case", ["origin_line", "origin_lock", "two_lines", "other_file", "other_lock", "untracked"])
def test_rt7_1_any_other_uncommitted_start_line_is_sorted_by_hand(runner, case):
    """Only the exact shape (one start line, STATUS.json lock-only with this run's lock or none, nothing else, origin
    without that run's line and lock) gets the restore step; anything else refuses "sort it by hand"."""
    if case == "origin_line":
        push_from_main(runner, lambda m: _append(m / IO.ACCESS_LOG_REL, READ), "a line of run A on origin")
    if case == "origin_lock":
        push_from_main(runner, lambda m: IO.set_oanda_job({"what": "x", "started_utc": "2026-12-08T00:00:00Z",
                                                            "ledger_id": LID}, m / IO.STATS_STATUS_REL), "A's lock")
    if case != "untracked":                                               # untracked: `git checkout --` cannot restore it
        tracked_log(runner)
    g = killed_in_start_step(runner, lock=case != "other_lock")
    if case == "two_lines":
        _append(IO.ACCESS_LOG, READ)
    if case == "other_file":
        _append(IO.FETCH_LOG, BLOCK)
    if case == "other_lock":
        IO.set_oanda_job(B_JOB, IO.STATS_STATUS)
    with pytest.raises(IO.Refused, match="uncommitted forward_run_start line .*sort it by hand") as e:
        IO.worktree_check(g)
    assert IO.READ_NOTHING not in str(e.value)


# ------------------------------------------------------------------ N1: the fast-forward path checks every file

def test_rt7_n1_a_fast_forward_refuses_a_fetch_log_rewrite(runner):
    """PoC test_n1: a hand-made closing commit that dropped origin's FETCH_LOG block line was fast-forwarded."""
    push_from_main(runner, lambda m: _append(m / IO.FETCH_LOG_REL, BLOCK), "a live block line on origin")
    ff(runner)
    g = start_run(runner)
    _append(IO.ACCESS_LOG, READ)
    _append(IO.ACCESS_LOG, DONE)
    IO.set_oanda_job(None, IO.STATS_STATUS)
    IO.FETCH_LOG.write_text("")                                           # the block line removed
    hand_commit(runner, "closing commit, hand-made")
    with pytest.raises(IO.Refused, match="FETCH_LOG.jsonl: the commit changes committed lines"):
        IO.push_closing(g)
    assert json.loads(origin_text(runner, IO.FETCH_LOG_REL)) == BLOCK


def test_rt7_n1_a_fast_forward_refuses_a_status_edit_besides_the_lock(runner):
    """PoC test_n1: a hand-made closing commit that edited STATUS.json `next` was fast-forwarded."""
    g = start_run(runner)
    _append(IO.ACCESS_LOG, DONE)
    st = json.loads(IO.STATS_STATUS.read_text())
    st["oanda_job"], st["next"] = None, "hand edit"
    IO.STATS_STATUS.write_text(json.dumps(st, indent=2) + "\n")
    hand_commit(runner, "closing commit, hand-made")
    with pytest.raises(IO.Refused, match="changes STATUS.json besides oanda_job"):
        IO.push_closing(g)
    assert json.loads(origin_text(runner, IO.STATS_STATUS_REL))["next"] != "hand edit"


def _rulings(m):
    (m / RULINGS).write_text("".join(json.dumps({"kind": "forward_calendar_ruling", "n": i}) + "\n"
                                     for i in range(20)))


def test_rt7_n1_a_rename_onto_fetch_log_names_the_deleted_file(runner):
    """PoC test_n1b: `git diff --name-only` (renames detected) named only FETCH_LOG.jsonl, so a rename of the rulings
    file onto it passed the path check and the fast-forward deleted the rulings on origin."""
    push_from_main(runner, _rulings, "a rulings file")
    ff(runner)
    g = start_run(runner)
    _append(IO.ACCESS_LOG, READ)
    _append(IO.ACCESS_LOG, DONE)
    IO.set_oanda_job(None, IO.STATS_STATUS)
    git(runner.wt, "mv", RULINGS, IO.FETCH_LOG_REL)
    hand_commit(runner, "closing commit with a rename")
    with pytest.raises(IO.Refused, match=f"changes \\['{re.escape(RULINGS)}'\\] besides"):
        IO.push_closing(g)
    assert origin_text(runner, RULINGS).count("forward_calendar_ruling") == 20


def test_rt7_n1_landed_needs_no_renames_and_a_lock_only_status(runner):
    """landed() (F7's reset advice) uses the same checks: a rename hidden by rename detection, or a STATUS.json edit
    besides the lock, is not 'landed' even when every log line is on origin."""
    push_from_main(runner, _rulings, "a rulings file")
    ff(runner)
    g = start_run(runner)
    mb = g.head()
    _append(IO.ACCESS_LOG, DONE)
    IO.set_oanda_job(None, IO.STATS_STATUS)
    git(runner.wt, "mv", RULINGS, IO.FETCH_LOG_REL)
    hand_commit(runner, "a rename")
    head = g.head()

    def copy(m):                                                          # every line on origin, and the release
        for rel in (IO.ACCESS_LOG_REL, IO.FETCH_LOG_REL):
            with open(m / rel, "ab") as f:
                f.write(IO.added_bytes(g.show_bytes(mb, rel) or b"", g.show_bytes(head, rel) or b"", rel))
        IO.set_oanda_job(None, m / IO.STATS_STATUS_REL)
    push_from_main(runner, copy, "session: the lines by hand")
    git(runner.wt, "fetch", "-q", "origin")
    assert IO.landed_ids(g, head, "origin/dept/stats") is None and not IO.landed(g, head, "origin/dept/stats")
    git(runner.wt, "reset", "-q", "--hard", mb)                           # the same, with a STATUS.json edit
    _append(IO.ACCESS_LOG, DONE)
    st = json.loads(IO.STATS_STATUS.read_text())
    st["oanda_job"], st["next"] = None, "hand edit"
    IO.STATS_STATUS.write_text(json.dumps(st, indent=2) + "\n")
    hand_commit(runner, "a STATUS.json edit")
    assert IO.landed_ids(g, g.head(), "origin/dept/stats") is None


# ------------------------------------------------------------------ N2: a closing line must close an open run of ours

def test_rt7_n2_a_done_line_naming_a_run_started_elsewhere_never_frees_its_lock(runner):
    """PoC test_n2: a hand-made commit with B's done line, pushed by --push-closing while B runs from another
    container, dropped B's lock. B's start is on origin and B has no closing line there, but B's start commit was not
    made in this worktree: refused, B's lock stays."""
    push_from_main(runner, b_takes_the_lock, "W2: run B started")
    ff(runner)
    g = IO.Git(runner.wt)
    _append(IO.ACCESS_LOG, {**DONE, "ledger_id": B_LID})
    IO.set_oanda_job(None, IO.STATS_STATUS)
    hand_commit(runner, "B's closing line, written in W1")
    with pytest.raises(IO.Refused, match=f"release run {B_LID}'s lock .*not made in this worktree"):
        IO.push_closing(g)
    assert origin_job(runner)["ledger_id"] == B_LID
    assert not g.started_here(B_LID, g.rev("origin/dept/stats"))


def test_rt7_n2_a_done_line_for_a_run_with_no_start_line_on_origin(runner):
    """A done line naming a job that is not a forward run (no forward_run_start on origin, e.g. a validation
    download's lock) is refused."""
    val = {"what": "STATS validation download", "started_utc": "2026-12-08T00:00:00Z", "ledger_id": "STATS-VAL-1"}
    push_from_main(runner, lambda m: IO.set_oanda_job(val, m / IO.STATS_STATUS_REL), "a validation job's lock")
    ff(runner)
    g = IO.Git(runner.wt)
    _append(IO.ACCESS_LOG, {**DONE, "ledger_id": "STATS-VAL-1"})
    IO.set_oanda_job(None, IO.STATS_STATUS)
    hand_commit(runner, "a done line for the validation job")
    with pytest.raises(IO.Refused, match="closes run STATS-VAL-1, which has no forward_run_start line"):
        IO.push_closing(g)
    assert origin_job(runner)["ledger_id"] == "STATS-VAL-1"


def test_rt7_n2_a_done_line_for_a_run_already_closed_on_origin(runner):
    g = start_run(runner)
    assert close_run(g) is True                                           # A closed on origin
    _append(IO.ACCESS_LOG, {**DONE, "utc": "2026-12-08T02:00:00Z"})
    hand_commit(runner, "a second closing line for A")
    with pytest.raises(IO.Refused, match=f"run {LID} already has a closing line"):
        IO.push_closing(g)


def _clearing(lid):
    return {"utc": "2026-12-08T08:00:00Z", "dept": "STATS", "study": "FORWARD", "ledger_id": "STATS-FWD-clear",
            "kind": "forward_stale_lock_cleared", "status": "cleared", "cleared_ledger_id": lid,
            "job_started_utc": B_JOB["started_utc"], "reason": "older than 6 h with no closing line"}


def test_rt7_n2_a_clearing_line_releases_a_lock_only_when_it_is_stale(runner):
    """A hand-made clearing line naming running B (started 1 h before the clock) is refused; the same commit at a
    clock 7 h after B's start is pushed (the age rule of --clear-stale-lock, checked again on the rebuild)."""
    push_from_main(runner, b_takes_the_lock, "W2: run B started at 07:00")
    ff(runner)
    g = IO.Git(runner.wt)
    _append(IO.ACCESS_LOG, _clearing(B_LID))
    IO.set_oanda_job(None, IO.STATS_STATUS)
    hand_commit(runner, "a clearing line for B")
    with pytest.raises(IO.Refused, match=f"release run {B_LID}'s lock .*started 1.0 h ago"):
        IO.push_closing(g, now=S.utc("2026-12-08T08:00:00"))
    assert origin_job(runner)["ledger_id"] == B_LID
    IO.push_closing(g, now=S.utc("2026-12-08T14:00:00"))
    assert origin_job(runner) is None


def test_rt7_n2_a_landed_try_stops_without_a_new_commit(runner):
    """A rebuilt push that landed though reported failed: the next try finds every line on origin and its lock not
    this run's, moves the worktree there and stops (no N2 refusal for the run's own closing line, no new commit)."""
    g = start_run(runner)
    push_from_main(runner, lambda m: (m / "x.txt").write_text("x\n"), "origin moved")
    hook(runner, "exit 1\n")
    assert close_run(g) is False
    (runner.origin / "hooks" / "pre-receive").unlink()
    old, base = g.head(), g.rev("origin/dept/stats")
    new = g._rebuilt(old, base, git(runner.wt, "merge-base", old, base), RELS, "landed, reported failed", {LID})
    git(runner.wt, "push", "-q", "origin", f"{new}:refs/heads/dept/stats")
    assert g.rebuild_push(old, RELS, "again") is True
    assert git(runner.origin, "rev-parse", "dept/stats") == new and g.head() == new


# ------------------------------------------------------------------ N3: DATA's git children never prompt either

def test_rt7_n3_the_process_env_tells_every_git_child_not_to_prompt(monkeypatch):
    """PoC test_n3: GIT_TERMINAL_PROMPT=0 was only in STATS's git_env; DATA's loaders' fetch and the downloader child
    inherit os.environ. clean_process_env (run_forward.main's first step) now sets it there."""
    for k in [k for k in os.environ if k.startswith("GIT_")]:              # clean_process_env deletes some: restored
        monkeypatch.setenv(k, os.environ[k])
    monkeypatch.setenv("GIT_NO_REPLACE_OBJECTS", os.environ.get("GIT_NO_REPLACE_OBJECTS", "1"))   # restored after
    monkeypatch.setenv("GIT_TERMINAL_PROMPT", "1")                          # whatever the caller's environment says
    C.clean_process_env()
    assert os.environ["GIT_TERMINAL_PROMPT"] == "0"
    assert IO.loaders()._git_env()["GIT_TERMINAL_PROMPT"] == "0"
    child = subprocess.run([sys.executable, "-c", "import os; print(os.environ.get('GIT_TERMINAL_PROMPT'))"],
                           capture_output=True, text=True)
    assert child.stdout.strip() == "0"
    env = {"GIT_TERMINAL_PROMPT": "1"}
    C.clean_process_env(env)
    assert env["GIT_TERMINAL_PROMPT"] == "0"


# ------------------------------------------------------------------ N4: a lone surrogate is a refusal, not a crash

def _surrogate(m):
    p = m / IO.STATS_STATUS_REL
    s = json.loads(p.read_text())
    s["next"] = "\ud83d"                                                    # json.dumps writes the escape \\ud83d
    p.write_text(json.dumps(s, indent=2) + "\n")


def test_rt7_n4_a_lone_surrogate_in_origins_status_json_is_refused_everywhere(runner):
    """PoC test_n4: status_bytes raised UnicodeEncodeError, which got past F7's catch (a traceback, the lock left
    set) and crashed --push-closing and --clear-stale-lock the same way. Now each refuses with the reason."""
    with pytest.raises(IO.Refused, match=r"lone surrogate escape, \\ud83d"):
        IO.status_bytes({"next": "\ud83d", "oanda_job": None})
    g = start_run(runner)
    push_from_main(runner, _surrogate, "session: next (a broken emoji)")
    with pytest.raises(IO.Refused, match="lone surrogate"):
        close_run(g)                                                      # the run's closing push (F7 catches Refused)
    assert origin_job(runner)["ledger_id"] == LID
    with pytest.raises(IO.Refused, match="lone surrogate"):
        IO.push_closing(g)


def test_rt7_n4_clear_stale_refuses_too(runner):
    g = start_run(runner)
    push_from_main(runner, _surrogate, "session: next (a broken emoji)")
    with pytest.raises(IO.Refused, match="lone surrogate"):
        RF.clear_stale(RF.Ops(g), now=LATER)
    assert origin_job(runner)["ledger_id"] == LID


def test_rt7_n4_clear_stale_writes_no_line_when_its_own_status_json_cannot_be_written(runner):
    """The worktree at origin's tip with the escape: --clear-stale-lock refuses before it writes its clearing line,
    so no leftover is left behind (it releases the lock in the worktree first, then writes the line)."""
    g = start_run(runner)
    push_from_main(runner, _surrogate, "session: next (a broken emoji)")
    ff(runner)
    before = IO.ACCESS_LOG.read_bytes()
    with pytest.raises(IO.Refused, match="lone surrogate"):
        RF.clear_stale(RF.Ops(g), now=LATER)
    assert IO.ACCESS_LOG.read_bytes() == before and not g.unclean()


def test_rt7_n4_the_runs_closing_push_ends_failed_with_exit_3(sandbox, capsys):
    """Through run(): status_bytes's refusal in the closing rebuild is caught by F7's except, so the run ends
    "failed: closing push" (exit 3) with the reason on stderr, not a traceback."""
    class Ops(FakeOps):
        def publish(self, paths, msg, rebuild=False, now=None):
            if rebuild:                                                   # the rebuild's merge with origin's file
                IO.merge_status((json.dumps({"next": "\ud83d", "oanda_job": {"ledger_id": LID}}) + "\n").encode(),
                                IO.status_bytes({"oanda_job": None}), {LID})
            return super().publish(paths, msg, rebuild)
    r = RF.run(DAY, Ops(sandbox), now=NOW)
    assert r["status"] == "failed: closing push" and RF.exit_code(r) == 3
    assert "lone surrogate" in capsys.readouterr().err


# ------------------------------------------------------------------ N5: the reset advice needs origin's lock free

def test_rt7_n5_lines_landed_but_the_lock_did_not_is_not_reset_advice(runner):
    """PoC test_n5: the lines reached origin by hand but the lock release did not; worktree_check said reset --keep,
    after which nothing could free A's lock. Now it says the lock is released by hand first, then reset."""
    g = start_run(runner)
    hook(runner, "exit 1\n")
    assert close_run(g) is False
    (runner.origin / "hooks" / "pre-receive").unlink()
    lines = C.checked_reader("read_bytes")(runner.wt / IO.ACCESS_LOG_REL)
    fl = C.checked_reader("read_bytes")(runner.wt / IO.FETCH_LOG_REL)

    def copy(m):                                                          # the session copies the lines, not the lock
        (m / IO.ACCESS_LOG_REL).write_bytes(lines)
        (m / IO.FETCH_LOG_REL).write_bytes(fl)
    push_from_main(runner, copy, "session: run A's lines copied by hand")
    git(runner.wt, "fetch", "-q", "origin")
    head, remote = g.head(), "origin/dept/stats"
    assert IO.landed_ids(g, head, remote) == {LID} and not IO.landed(g, head, remote)
    with pytest.raises(IO.Refused, match=f"origin still holds run {LID}'s lock.*by hand .*runs this check again") as e:
        IO.worktree_check(g)
    assert "reset --keep" not in str(e.value)                             # no reset before the lock is released
    push_from_main(runner, lambda m: IO.set_oanda_job(None, m / IO.STATS_STATUS_REL), "session: A's lock released")
    with pytest.raises(IO.Refused, match="already on origin/dept/stats .*git reset --keep origin/dept/stats"):
        IO.worktree_check(g)
    assert IO.landed(g, head, remote)


# ------------------------------------------------------------------ N6: DATA's macro.load read line of the run

def test_rt7_n6_the_runs_macro_line_is_its_own(runner):
    """If a re-pin wires macro.load, its read lines (kind "macro", the run's ledger id under override forward_inputs,
    MACRO_KEYS only) are part of the run's closing commit: runner_lines, check_leftovers and push_closing take them."""
    starts, closing, other = IO.runner_lines([READ, MACRO, DONE])
    assert not starts and len(closing) == 3 and other == []
    IO.check_leftovers({IO.ACCESS_LOG_REL: [json.dumps(MACRO), json.dumps(DONE)]}, LID)
    g = start_run(runner)
    hook(runner, "exit 1\n")
    _append(IO.ACCESS_LOG, MACRO)
    assert close_run(g) is False
    (runner.origin / "hooks" / "pre-receive").unlink()
    IO.push_closing(g)
    assert MACRO in origin_lines(runner) and origin_job(runner) is None


@pytest.mark.parametrize("line", [
    {**MACRO, "ledger_id": B_LID},                                         # another run's
    {**MACRO, "override": "validation"},                                   # another override
    {**MACRO, "net_r": 1.0},                                               # a key DATA's line does not have
    {k: v for k, v in MACRO.items() if k not in ("override", "ledger_id")},   # DATA's line as written today
])
def test_rt7_n6_other_macro_lines_are_not_the_runs(line):
    assert IO.runner_lines([line, DONE])[2] == ["macro"]
    with pytest.raises(IO.Refused, match="closing or read line"):
        IO.check_leftovers({IO.ACCESS_LOG_REL: [json.dumps(line)]}, LID)


def macro_line_keys(log_macro_src: str, log_access_src: str) -> set:
    """Every key DATA's macro line can carry (red team 8, F1): log_access's row (its dict literal and constant-key
    item assignments) and every keyword _log_macro passes, each **name resolved to the dict literals the function
    binds it to (a conditional of them included). Anything it cannot resolve fails: a new key is read, never missed."""
    def literal(node) -> set:
        if isinstance(node, ast.IfExp):
            return literal(node.body) | literal(node.orelse)
        assert isinstance(node, ast.Dict) and all(isinstance(k, ast.Constant) and isinstance(k.value, str)
                                                  for k in node.keys), f"cannot read the keys of {ast.dump(node)[:120]}"
        return {k.value for k in node.keys}

    def bound(fn, name) -> list:
        return [n.value for n in ast.walk(fn) if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]

    fn = ast.parse(textwrap.dedent(log_macro_src)).body[0]
    calls = [n for n in ast.walk(fn) if isinstance(n, ast.Call) and getattr(n.func, "id", "") == "log_access"]
    assert len(calls) == 1, "_log_macro must call log_access once"
    params = {a.arg for a in fn.args.posonlyargs + fn.args.args + fn.args.kwonlyargs}
    params |= {a.arg for a in (fn.args.vararg, fn.args.kwarg) if a is not None}
    keys = set()
    for kw in calls[0].keywords:
        if kw.arg is not None:
            keys.add(kw.arg)
            continue
        assert isinstance(kw.value, ast.Name) and kw.value.id not in params, "a ** argument that is not a local dict"
        name = kw.value.id
        touched = [n for n in ast.walk(fn) if isinstance(n, (ast.Subscript, ast.Attribute))
                   and isinstance(n.value, ast.Name) and n.value.id == name]
        touched += [n for n in ast.walk(fn) if isinstance(n, (ast.AugAssign, ast.AnnAssign))
                    and isinstance(n.target, ast.Name) and n.target.id == name]
        assert bound(fn, name) and not touched, f"**{name} is not only bound to dict literals in _log_macro"
        for b in bound(fn, name):
            keys |= literal(b)
    acc = ast.parse(textwrap.dedent(log_access_src)).body[0]
    rows = bound(acc, "row")
    assert len(rows) == 1, "log_access must build its row once"
    keys |= literal(rows[0])
    for n in ast.walk(acc):
        for t in (n.targets if isinstance(n, ast.Assign) else []):
            if isinstance(t, ast.Subscript) and isinstance(t.value, ast.Name) and t.value.id == "row" and \
                    isinstance(t.slice, ast.Constant):
                keys.add(t.slice.value)
    return keys


def assert_macro_keys(keys: set) -> None:
    assert keys <= IO.MACRO_KEYS, f"DATA's macro line can carry {sorted(keys - IO.MACRO_KEYS)}, not in MACRO_KEYS"
    assert IO.MACRO_KEYS - keys == {"override", "ledger_id"}


def _sources():
    L = IO.loaders()
    return inspect.getsource(L._log_macro), inspect.getsource(sys.modules[L.log_access.__module__].log_access)


def test_rt7_n6_macro_keys_cover_datas_macro_line():
    """MACRO_KEYS holds every key DATA's pinned loaders can write on a macro line (log_access's row, _log_macro's
    keywords and the dict behind its **extra: "linked" since DATA release 6), plus override and ledger_id: a re-pin
    that adds a key fails here first (red team 8, F1: the keyword names alone missed **extra)."""
    macro, access = _sources()
    keys = macro_line_keys(macro, access)
    assert {"kind", "series", "run_id", "linked"} <= keys
    assert_macro_keys(keys)


@pytest.mark.parametrize("old,new", [
    ('{"linked": True}', '{"linked": True, "net_r": 1}'),                  # a new key behind **extra
    ("common_sha256=common_sha256()", "common_sha256=common_sha256(), pnl=0"),   # a new keyword
    ("before_run=False, linked=False)", "before_run=False, linked=False, **more)"),   # **more: a parameter
    ('    extra = {"linked": True} if linked else {}\n',
     '    extra = {"linked": True} if linked else {}\n    extra["x"] = 1\n'),  # a key set on the dict
])
def test_rt7_n6_the_key_reader_fails_on_any_new_key(old, new):
    macro, access = _sources()
    assert macro.count(old) == 1
    macro = macro.replace(old, new)
    if "**more" in new:
        macro = macro.replace("**extra)", "**more)")
    with pytest.raises(AssertionError):
        assert_macro_keys(macro_line_keys(macro, access))
