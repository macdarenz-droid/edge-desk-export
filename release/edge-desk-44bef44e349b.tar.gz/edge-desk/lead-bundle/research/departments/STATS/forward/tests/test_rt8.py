"""Red team 8 (forward/RED_TEAM.md): one test (or more) per finding, each failing if its fix is removed. F1's test is
test_rt7.py's macro-key test, rewritten; the red team's proofs (rt8_forward/test_rt8_poc.py) are restated here. Real git
on local bare origins, synthetic lines only. No network, no token, no prices, no forward number."""
import json
import re
from pathlib import Path

import pytest

import fwd_core as C
import fwd_io as IO
import run_forward as RF
from test_io import NOW
from test_redteam import git, repos  # noqa: F401  (fixtures)
from test_rt5 import DONE, LID, close_run, runner, session, start_run  # noqa: F401
from test_rt6 import B_LID, b_takes_the_lock, origin_job, push_from_main

NEEDED = re.escape(IO.REFLOG_NEEDED)


# ------------------------------------------------------------------ N-a: the gate and --check need a HEAD reflog

def _no_reflog(r, how):
    admin = Path(git(r.wt, "rev-parse", "--absolute-git-dir"))
    if how == "false":
        git(r.main, "config", "core.logAllRefUpdates", "false")           # the repository's config, the worktree's too
    elif how == "zero":
        git(r.main, "config", "core.logAllRefUpdates", "0")
    else:
        (admin / "logs" / "HEAD").unlink()                                # the setting on, but no reflog kept
    return IO.Git(r.wt)


@pytest.mark.parametrize("how", ["false", "zero", "missing"])
def test_rt8_na_the_gate_and_check_refuse_a_worktree_with_no_head_reflog(runner, monkeypatch, capsys, how):
    """PoC test_na: with no HEAD reflog, started_here() is False for the run's own start commit, so its rebuilt
    closing push and --push-closing are refused and only the 6-hour clear closes the window. Now the gate (before
    anything is pushed) and --check refuse such a worktree with the fix."""
    g = _no_reflog(runner, how)
    with pytest.raises(IO.Refused, match=NEEDED):
        IO.check_head_reflog(g)
    with pytest.raises(IO.Refused, match=NEEDED):
        IO.gate(g)
    monkeypatch.setattr(IO, "preflight_blocks", lambda git: "no live block")
    capsys.readouterr()
    RF.check(g, now=NOW)
    out = capsys.readouterr().out
    assert f"FAIL  HEAD reflog (closing push): Refused: {IO.REFLOG_NEEDED}" in out
    assert f"FAIL  gate (worktree, tree approval, DEPS pins, calendar pin): Refused: {IO.REFLOG_NEEDED}" in out


@pytest.mark.parametrize("value", [None, "true", "always"])
def test_rt8_na_the_default_true_and_always_keep_a_reflog(runner, value):
    """Control: unset (git's default outside a bare repository), true and "always" pass, and the gate goes on to its
    next check; the closing rebuild then lands as before."""
    if value is None:
        git(runner.main, "config", "--unset", "core.logAllRefUpdates", check=False)
    else:
        git(runner.main, "config", "core.logAllRefUpdates", value)
    g = IO.Git(runner.wt)
    assert IO.check_head_reflog(g).startswith("kept")
    with pytest.raises(IO.Refused) as e:                                  # a later gate check, not the reflog's
        IO.gate(g)
    assert IO.REFLOG_NEEDED not in str(e.value)
    g = start_run(runner)
    session(runner, "next")                                               # origin moves: the rebuild ties the lock
    assert close_run(g) is True and origin_job(runner) is None


# ------------------------------------------------------------------ N-b: started_here's is_ancestor check

def test_rt8_nb_a_hand_commit_re_adding_another_runs_start_line_never_frees_its_lock(runner):
    """PoC test_nc: a hand-made pair of commits in the runner's worktree: H1 re-appends B's start line (copied from
    origin), H2 adds B's done line and releases the lock. started_here(B) finds H1, a "commit:" entry that appends B's
    start line; only is_ancestor(H1, origin) refuses it (mutation M5 passed the rt5-rt7 suites)."""
    push_from_main(runner, b_takes_the_lock, "B starts elsewhere")
    git(runner.wt, "fetch", "-q", "origin")
    git(runner.wt, "merge", "-q", "--ff-only", "origin/dept/stats")
    g = IO.Git(runner.wt)
    start_b = next(x for x in C.checked_reader("read_text")(runner.wt / IO.ACCESS_LOG_REL).splitlines()
                   if '"forward_run_start"' in x and B_LID in x)
    with open(IO.ACCESS_LOG, "a") as f:
        f.write(start_b + "\n")
    git(runner.wt, "commit", "-qam", "H1")
    with open(IO.ACCESS_LOG, "a") as f:
        f.write(json.dumps({**DONE, "ledger_id": B_LID}) + "\n")
    IO.set_oanda_job(None, IO.STATS_STATUS)
    git(runner.wt, "commit", "-qam", "H2")
    assert any(s.startswith("commit: H1") for s in git(runner.wt, "log", "-g", "--format=%gs", "HEAD").splitlines())
    assert not g.started_here(B_LID, g.rev("origin/dept/stats"))
    with pytest.raises(IO.Refused, match="start commit was not made in this worktree"):
        IO.push_closing(g)
    assert origin_job(runner)["ledger_id"] == B_LID


# ------------------------------------------------------------------ N-c: FORWARD.md names every re-pin since red team 7

def test_rt8_nc_forward_md_names_the_data_and_cost_re_pins():
    status = C.checked_reader("read_text")(C.STATS / "FORWARD.md").splitlines()[2]
    for sha in ("7dad9167", "826cec92", "1026cd45"):
        assert sha in status, sha
    assert "core.logAllRefUpdates" in C.checked_reader("read_text")(C.STATS / "FORWARD.md")
