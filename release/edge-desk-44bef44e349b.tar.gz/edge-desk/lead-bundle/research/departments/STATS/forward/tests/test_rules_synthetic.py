"""The three picks on synthetic forward bars, against a reference written here from the rule text (not from the
frozen code): decision and exit times, fills, net at the 2.0-pip floor with financing, and the day rows."""
from datetime import date, datetime, timedelta

import numpy as np
import pandas as pd
import pytest

import fwd_core as C
import synth as S

PIP, SLIP = 1e-4, 0.2e-4
END = C.label_close_ts(date(2026, 12, 7))


@pytest.fixture(scope="module")
def run(tmp_path_factory):
    picks = C.load_picks()
    C.verify_pins(picks)
    csv, meta = S.write_calendar(tmp_path_factory.mktemp("cal"), run_day="2026-12-07")
    cal = C.read_calendar(csv, meta, run_day=date(2026, 12, 7))
    m1 = S.bars(C.inputs_start(picks), END)
    return m1, {(l["pick_id"], l["decision_ts"]): l for l in C.compute(picks, cal, m1, END, "TEST")}


def bar_at(m1, t):
    i = int(np.searchsorted(m1["ts_utc"], t))
    assert m1["ts_utc"][i] - t < 900
    return i


def fin(a, b):
    """1 pip per 17:00 New York close in (a, b], 3 when that close ends a Wednesday."""
    d, out = datetime.fromtimestamp(a, C.NY).date() - timedelta(days=1), 0.0
    while True:
        close = C.label_close_ts(d)
        if close > b:
            return out
        if close > a and d.weekday() < 5:
            out += 3.0 if d.weekday() == 2 else 1.0
        d += timedelta(days=1)


def time_trade(m1, t, te):
    i, j = bar_at(m1, t), bar_at(m1, te)
    mid = lambda k: (m1["bid_o"][k] + m1["ask_o"][k]) / 2
    move = (mid(j) - mid(i)) / PIP
    f = fin(m1["ts_utc"][i], m1["ts_utc"][j])
    long_ba = ((m1["bid_o"][j] - SLIP) - (m1["ask_o"][i] + SLIP)) / PIP
    short_ba = ((m1["bid_o"][i] - SLIP) - (m1["ask_o"][j] + SLIP)) / PIP
    return {"entry_ts": int(m1["ts_utc"][i]), "exit_ts": int(m1["ts_utc"][j]),
            "net": min(move - 2.0, long_ba) - f, "net_short": min(-move - 2.0, short_ba) - f}


def check_days(line, net, net_short):
    days = [d["day"] for d in line["days"]]
    assert days[0] == C.label_of(line["decision_ts"])
    assert days == C.weekday_labels(days[0], days[-1])
    assert abs(sum(d["pnl_long"] for d in line["days"]) - net) < 1e-9
    assert abs(sum(d["pnl_short"] for d in line["days"]) - net_short) < 1e-9


def test_exactly_the_expected_trades(run):
    _, lines = run
    want = {("R53-S3X3", S.ny("2026-10-20", "14:00")), ("R53-S3X3", S.ny("2026-12-01", "14:00")),
            ("PA-F4", S.utc("2026-10-21T11:00:00")),
            ("FC-1", S.utc("2026-11-02T16:00:00")), ("FC-1", S.utc("2026-11-16T16:00:00"))}
    assert set(lines) == want and all(l["kind"] == "trade" for l in lines.values())


def test_pa_f4(run):
    m1, lines = run
    t = S.utc("2026-10-21T11:00:00")                 # 12:00 London on the London business day before the decision
    te = S.utc("2026-10-22T12:15:00") - 300            # decision time minus 5 minutes
    ref = time_trade(m1, t, te)
    l = lines[("PA-F4", t)]
    assert (l["entry_ts"], l["exit_ts"], l["sched_exit_ts"]) == (ref["entry_ts"], ref["exit_ts"], te)
    assert abs(l["net_pips"] - ref["net"]) < 1e-9 and abs(l["net_short"] - ref["net_short"]) < 1e-9
    assert abs(l["net_pips"] - 25.0) < 1e-9          # +30 pips mid, -2.0 floor, -3 for the Wednesday close
    assert l["net_R"] is None and l["unit"] == "pips" and l["exit_reason"] == "time"
    check_days(l, ref["net"], ref["net_short"])


@pytest.mark.parametrize("a,b", [("2026-11-02", "2026-11-09"), ("2026-11-16", "2026-11-23")])
def test_fc_1(run, a, b):
    """Statements 21 Oct and 2 Dec (synthetic): week 2 = days 8-13 (2 to 9 Nov), week 4 = days 18-23 (16 to 23 Nov,
    day 23 = day -7 of 2 Dec), week 6 starts on day 28 (30 Nov), not before day -7, so no trade."""
    m1, lines = run
    t = S.utc(f"{a}T16:00:00")
    te = S.utc(f"{b}T16:00:00")
    ref = time_trade(m1, t, te)
    l = lines[("FC-1", t)]
    assert (l["entry_ts"], l["exit_ts"], l["sched_exit_ts"]) == (ref["entry_ts"], ref["exit_ts"], te)
    assert abs(l["net_pips"] - ref["net"]) < 1e-9 and abs(l["net_short"] - ref["net_short"]) < 1e-9
    assert len(l["days"]) == 6
    check_days(l, ref["net"], ref["net_short"])


def atr20(m1, t):
    ts = m1["ts_utc"]
    lab = C.bar_labels(ts)
    mid = pd.DataFrame({"lab": lab, "h": (m1["bid_h"] + m1["ask_h"]) / 2, "l": (m1["bid_l"] + m1["ask_l"]) / 2,
                        "c": (m1["bid_c"] + m1["ask_c"]) / 2, "ts": ts})
    g = mid.groupby("lab").agg(h=("h", "max"), l=("l", "min"), c=("c", "last"))
    g = g[[C.label_close_ts(date.fromisoformat(x)) <= t for x in g.index]]
    pc = g.c.shift(1)
    tr = np.maximum(g.h - g.l, np.maximum((g.h - pc).abs(), (g.l - pc).abs()))
    return float(tr.iloc[-20:].mean())


def test_r53_s3_x3(run):
    m1, lines = run
    t, S_ts = S.ny("2026-10-20", "14:00"), S.ny("2026-10-21", "14:00")
    i, j = bar_at(m1, t), bar_at(m1, S_ts - 300)
    entry = m1["ask_o"][i] + SLIP
    r = atr20(m1, t)
    assert abs(r / PIP - 44.0) < 1e-6                 # 19 days of 40 pips and the 8 Oct day of 120 pips
    stop, tgt = entry - r, entry + 2 * r
    k = next(k for k in range(i, j) if m1["bid_l"][k] <= stop or m1["bid_h"][k] >= tgt)
    assert m1["bid_h"][k] >= tgt and m1["bid_l"][k] > stop             # the target at the 15:00 bump
    entry_mid = (m1["bid_o"][i] + m1["ask_o"][i]) / 2
    R20 = min((tgt - entry_mid) / r - 2.0 / (r / PIP), 2.0)
    s_entry = m1["bid_o"][i] - SLIP                                     # the mirrored short: stop at s_entry + r
    sf = max(s_entry + r, m1["ask_o"][k]) + SLIP
    smid = max(s_entry + r, (m1["bid_o"][k] + m1["ask_o"][k]) / 2)
    R20s = min((entry_mid - smid) / r - 2.0 / (r / PIP), (s_entry - sf) / r)
    l = lines[("R53-S3X3", t)]
    assert l["exit_reason"] == "target" and l["exit_ts"] == int(m1["ts_utc"][k]) and l["sched_exit_ts"] == S_ts - 300
    assert abs(l["entry"] - entry) < 1e-12 and abs(l["stop"] - stop) < 1e-12 and abs(l["target"] - tgt) < 1e-12
    assert abs(l["net_R"] - R20) < 1e-9 and abs(l["net_short"] - R20s) < 1e-9
    assert abs(l["net_pips"] - R20 * r / PIP) < 1e-6 and l["unit"] == "R"
    check_days(l, R20, R20s)


def test_settled_horizon_waits_for_open_windows(tmp_path):
    """With bars only to 20 Nov (the calendar of 7 Dec, so every row is final), FC-1's 16-23 Nov window is open: it
    waits, and nothing after it is logged."""
    picks = C.load_picks()
    csv, meta = S.write_calendar(tmp_path, run_day="2026-12-07")
    cal = C.read_calendar(csv, meta, run_day=date(2026, 11, 20))
    end = C.label_close_ts(date(2026, 11, 20))
    lines = C.compute(picks, cal, S.bars(C.inputs_start(picks), end), end, "TEST")
    assert sorted((l["pick_id"], C.label_of(l["decision_ts"])) for l in lines) == [
        ("FC-1", "2026-11-02"), ("PA-F4", "2026-10-21"), ("R53-S3X3", "2026-10-20")]
    assert C.settled_horizon([(100, 200), (300, 400)], 400 + 899) == 300
    assert C.settled_horizon([(100, 200), (300, 400)], 400 + 900) == float("inf")
