"""Round 45: swing test (DECLARATION.md). Data, signals, simulator and statistics.

Everything here follows DECLARATION.md sections 2-6. Prices are EUR/USD 1-minute bid/ask; bonds are 15-minute mids.
Nothing at or after CUT (1751317200, validation's start) is ever returned by a loader.
"""
from __future__ import annotations

import hashlib
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
SCRATCH = Path("/tmp/claude-0/-home-user-Forex-signal/d84e5419-5c29-52e4-b3cc-ef8fdff50214/scratchpad")
OLD = SCRATCH / "fxdata_old_locked" / "OLD_EURUSD_M1_BA_2016_2023.csv"
NEW = SCRATCH / "fxdata_dec2023_jun2025" / "EURUSD_M1_BA_to_2025-06-30.csv"
XA = {"d2": SCRATCH / "fxdata_xasset_d2", "era3": SCRATCH / "fxdata_xasset_era3"}
BONDS = ("USB10Y_USD", "DE10YB_EUR")
CUT = 1751317200
NEW_START = 1701388800                      # first row of the Dec 2023 - Jun 2025 file
PIP = 1e-4
SLIP = 0.2 * PIP
NY, LON = ZoneInfo("America/New_York"), ZoneInfo("Europe/London")

ERAS = {   # DECLARATION section 5: decisions (London dates), warm-up start, end (UTC, exclusive)
    "B": {"from": date(2016, 4, 1), "to": date(2021, 12, 31), "warm": date(2016, 1, 3), "end": 1640995200},
    "C": {"from": date(2022, 1, 3), "to": date(2023, 11, 30), "warm": date(2021, 6, 1), "end": 1701388800},
    "T": {"from": date(2023, 12, 1), "to": date(2025, 6, 27), "warm": date(2023, 6, 1), "end": CUT},
}
SIGNALS = ("TS60", "DON55", "RG20", "TSRG")
EXITS = ("E3", "ET")
CONFIGS = [f"{s}_{e}" for s in SIGNALS for e in EXITS]
STOP_ATR, TRAIL_ATR, TARGET_R = 2.0, 3.0, 3.0
TIME_EXIT = {"E3": 30, "ET": 60}
COST_PIPS, FIN_PIPS, FIN_WED_PIPS = 2.0, 1.0, 3.0


# ------------------------------------------------------------------ data

def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 22), b""):
            h.update(b)
    return h.hexdigest()


def listed(hash_file: Path, name: str) -> str:
    for line in hash_file.read_text().splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[-1].lstrip("*") == name:
            return parts[0]
    raise RuntimeError(f"{name} not listed in {hash_file}")


def check(p: Path, hash_file: Path) -> None:
    got, want = sha256(p), listed(hash_file, p.name)
    if got != want:
        raise RuntimeError(f"sha256 mismatch for {p}: {got} != {want}")


def load_m1(end_ts: int, start_ts: int = 0) -> dict:
    """EUR/USD M1 bid/ask with start_ts <= ts < min(end_ts, CUT), hash-checked. Arrays keyed by column."""
    end_ts = min(int(end_ts), CUT)
    frames = []
    check(OLD, REPO / "research/round10/OLD_DATA_HASHES.txt")
    frames.append(pd.read_csv(OLD))
    if end_ts > NEW_START:
        check(NEW, NEW.parent / "SHA256_UNCOMPRESSED.txt")
        frames.append(pd.read_csv(NEW))
    m = pd.concat(frames, ignore_index=True)
    m = m[(m.ts_utc >= start_ts) & (m.ts_utc < end_ts)].drop_duplicates("ts_utc").sort_values("ts_utc")
    if len(m) and int(m.ts_utc.max()) >= CUT:
        raise RuntimeError("a row at or after the validation cut")
    return {c: m[c].to_numpy() for c in m.columns}


def load_bonds(end_ts: int) -> dict:
    """{series: DataFrame(ts_close, c)} of 15-minute mid closes known before min(end_ts, CUT); ts_close = bar open + 900."""
    end_ts = min(int(end_ts), CUT)
    out = {}
    for s in BONDS:
        parts = []
        for k, d in XA.items():
            f = d / f"{s}_M15_M.csv"
            check(f, d / "HASHES.txt")
            parts.append(pd.read_csv(f, usecols=["ts_utc", "c"]))
        b = pd.concat(parts, ignore_index=True).drop_duplicates("ts_utc").sort_values("ts_utc")
        b["ts_close"] = b.ts_utc + 900
        out[s] = b[b.ts_close <= end_ts][["ts_close", "c"]].reset_index(drop=True)
    return out


# ------------------------------------------------------------------ days and decisions

def ny_day_key(ts: np.ndarray) -> np.ndarray:
    """The trading day a 1-minute bar belongs to: the New York date of (bar open + 7 h), so a day ends 17:00 New York."""
    t = pd.to_datetime(ts, unit="s", utc=True).tz_convert(NY) + pd.Timedelta(hours=7)
    return np.array(t.date)


def day_end_ts(d: date) -> int:
    return int(datetime.combine(d, time(17, 0), NY).timestamp())


def daily_bars(m1: dict, min_bars: int = 100) -> pd.DataFrame:
    """Mid daily OHLC by New York trading day (DECLARATION section 3); stub days under min_bars bars are dropped."""
    mid = {k: (m1[f"bid_{k}"] + m1[f"ask_{k}"]) / 2 for k in "ohlc"}
    df = pd.DataFrame({"day": ny_day_key(m1["ts_utc"]), **mid})
    g = df.groupby("day", sort=True)
    d = pd.DataFrame({"o": g.o.first(), "h": g.h.max(), "l": g.l.min(), "c": g.c.last(), "n": g.o.size()})
    d = d[d.n >= min_bars].copy()
    d["end"] = [day_end_ts(x) for x in d.index]
    prev_c = d.c.shift(1)
    tr = np.maximum(d.h - d.l, np.maximum((d.h - prev_c).abs(), (d.l - prev_c).abs()))
    tr.iloc[0] = d.h.iloc[0] - d.l.iloc[0]
    d["atr20"] = tr.rolling(20).mean()
    return d.reset_index()


def decision_times(era: str) -> list:
    """(london_date, ts_utc of 07:00 London) for Monday-Friday decision dates of the era."""
    e = ERAS[era]
    out, x = [], e["from"]
    while x <= e["to"]:
        if x.weekday() < 5:
            out.append((x, int(datetime.combine(x, time(7, 0), LON).timestamp())))
        x += timedelta(days=1)
    return out


# ------------------------------------------------------------------ signals (known at a decision)

def signal_table(days: pd.DataFrame, bonds: dict) -> pd.DataFrame:
    """Per completed day k: each signal's side as known after day k's 17:00 New York close."""
    c, h, l = days.c.to_numpy(), days.h.to_numpy(), days.l.to_numpy()
    n = len(days)
    ts60 = np.zeros(n)
    ts60[60:] = np.sign(c[60:] - c[:-60])
    don = np.zeros(n)
    state = 0.0
    for k in range(n):
        if k >= 55:
            hi, lo = h[k - 55:k].max(), l[k - 55:k].min()
            if c[k] > hi:
                state = 1.0
            elif c[k] < lo:
                state = -1.0
        don[k] = state
    ends = days.end.to_numpy()
    x = np.full(n, np.nan)
    us, de = bonds["USB10Y_USD"], bonds["DE10YB_EUR"]
    iu = np.searchsorted(us.ts_close.to_numpy(), ends, side="right") - 1
    idd = np.searchsorted(de.ts_close.to_numpy(), ends, side="right") - 1
    ok = (iu >= 0) & (idd >= 0)
    x[ok] = np.log(us.c.to_numpy()[iu[ok]]) - np.log(de.c.to_numpy()[idd[ok]])
    rg = np.zeros(n)
    dx = x[20:] - x[:-20]
    rg[20:] = np.where(np.isfinite(dx), np.sign(dx), 0.0)
    tsrg = np.where(ts60 == rg, ts60, 0.0)
    return pd.DataFrame({"TS60": ts60, "DON55": don, "RG20": rg, "TSRG": tsrg})


# ------------------------------------------------------------------ simulator

def _exit_scan(m1: dict, i0: int, i_cap: int, side: int, stop0: float, target, trail_dist, days, entry_ts):
    """First stop or target hit in bars [i0, i_cap). Returns (bar index, fill, mid fill, why) or None.

    Trail (ET): the stop only moves in the trade's favour, to best mid close since entry minus trail_dist
    (plus for a sell), from the first bar after each completed day's 17:00 New York close."""
    if i_cap <= i0:
        return None
    sl = slice(i0, i_cap)
    ts = m1["ts_utc"][sl]
    if side == 1:
        lo, op, hi = m1["bid_l"][sl], m1["bid_o"][sl], m1["bid_h"][sl]
    else:
        lo, op, hi = m1["ask_h"][sl], m1["ask_o"][sl], m1["ask_l"][sl]   # mirrored names: lo = adverse, hi = favourable
    mid_o = (m1["bid_o"][sl] + m1["ask_o"][sl]) / 2
    stop = np.full(len(ts), stop0)
    if trail_dist is not None:
        ends, closes = days.end.to_numpy(), days.c.to_numpy()
        k0 = np.searchsorted(ends, entry_ts, side="right")           # first day ending after the entry
        kk = np.searchsorted(ends, ts, side="right") - 1               # last day completed at each bar's open
        best = np.full(len(ts), np.nan)
        if k0 < len(ends):
            run = closes[k0:].copy()
            run = np.maximum.accumulate(run) if side == 1 else np.minimum.accumulate(run)
            have = kk >= k0
            best[have] = run[kk[have] - k0]
        trail = best - side * trail_dist
        if side == 1:
            stop = np.where(np.isfinite(trail), np.maximum(stop0, trail), stop0)
        else:
            stop = np.where(np.isfinite(trail), np.minimum(stop0, trail), stop0)
    if side == 1:
        hit_s = lo <= stop
        hit_t = (hi >= target) if target is not None else np.zeros(len(ts), bool)
    else:
        hit_s = lo >= stop
        hit_t = (hi <= target) if target is not None else np.zeros(len(ts), bool)
    any_hit = hit_s | hit_t
    if not any_hit.any():
        return None
    j = int(np.argmax(any_hit))
    if hit_s[j]:                                                       # a stop in the same bar as a target counts
        s = stop[j]
        if side == 1:
            fill = min(s, op[j]) - SLIP
            midf = min(s, mid_o[j])
        else:
            fill = max(s, op[j]) + SLIP
            midf = max(s, mid_o[j])
        return i0 + j, fill, midf, "stop" if s == stop0 else "trail"
    return i0 + j, target, target, "target"


def _market_fill(m1: dict, i: int, side_closing: int, at_close: bool = False):
    """Market order at bar i's open (or close): a buy at the ask plus slippage, a sell at the bid minus slippage."""
    f = "c" if at_close else "o"
    mid = (m1[f"bid_{f}"][i] + m1[f"ask_{f}"][i]) / 2
    if side_closing == 1:
        return m1[f"ask_{f}"][i] + SLIP, mid
    return m1[f"bid_{f}"][i] - SLIP, mid


def financing_pips(entry_ts: int, exit_ts: int, days: pd.DataFrame) -> float:
    """1 pip per 17:00 New York close held over, 3 for a Wednesday close (DECLARATION section 4)."""
    ends = days.end.to_numpy()
    held = days[(ends > entry_ts) & (ends <= exit_ts)]
    return float(sum(FIN_WED_PIPS if d.weekday() == 2 else FIN_PIPS for d in held.day))


def run_config(m1: dict, days: pd.DataFrame, sig: pd.DataFrame, decisions: list, signal: str, exit_style: str,
               era_end: int, side_override=None) -> list:
    """Trades of one configuration (DECLARATION sections 3-4). side_override: {decision index: side} for the null."""
    ts = m1["ts_utc"]
    ends = days.end.to_numpy()
    # usable decisions: an entry bar within 3 hours of 07:00 London and a completed day with ATR20
    dec = []
    for dt, t in decisions:
        i = int(np.searchsorted(ts, t, side="left"))
        if i >= len(ts) or ts[i] >= t + 3 * 3600 or ts[i] >= era_end:
            continue
        k = int(np.searchsorted(ends, t, side="right")) - 1
        if k < 0 or not np.isfinite(days.atr20.iloc[k]):
            continue
        dec.append((dt, t, i, k))
    last_bar = int(np.searchsorted(ts, era_end, side="left")) - 1
    trades = []
    di = 0
    while di < len(dec):
        dt, t, i, k = dec[di]
        side = int(sig[signal].iloc[k])
        if side_override is not None:
            side = side_override.get(di, 0)
        if side == 0:
            di += 1
            continue
        entry, entry_mid = _market_fill(m1, i, side)
        atr = float(days.atr20.iloc[k])
        r_px = STOP_ATR * atr
        stop0 = entry - side * r_px
        target = entry + side * TARGET_R * r_px if exit_style == "E3" else None
        trail = TRAIL_ATR * atr if exit_style == "ET" else None
        # caps: time exit decision, signal exit decision (opposite side), era end
        cap_di = min(di + TIME_EXIT[exit_style], len(dec))
        if side_override is None:
            for dj in range(di + 1, cap_di):
                if int(sig[signal].iloc[dec[dj][3]]) == -side:
                    cap_di, why_cap = dj, "signal"
                    break
            else:
                why_cap = "time"
        else:
            why_cap = "time"
        if cap_di < len(dec):
            i_cap, why = dec[cap_di][2], why_cap
        else:
            i_cap, why = last_bar + 1, "era_end"
        cap_kind = why                                                  # the planned cap (amendment A2): its kind and bar
        cap_bar = i_cap
        hit = _exit_scan(m1, i, i_cap, side, stop0, target, trail, days, t)
        if hit is not None:
            j, fill, midf, why = hit
            next_di = int(np.searchsorted([d[2] for d in dec], j, side="right"))
        elif why == "era_end":
            j = last_bar
            fill, midf = _market_fill(m1, j, -side, at_close=True)
            next_di = len(dec)
        else:
            j = i_cap
            fill, midf = _market_fill(m1, j, -side)
            next_di = cap_di                                           # re-entry allowed at the same decision
        r_pips = r_px / PIP
        R_ba = side * (fill - entry) / r_px
        R_mid = side * (midf - entry_mid) / r_px
        R_20 = min(R_mid - COST_PIPS / r_pips, R_ba)
        exit_ts = int(ts[j])
        fin = financing_pips(t, exit_ts, days)
        trades.append({
            "config": f"{signal}_{exit_style}", "date": str(dt), "entry_ts": int(ts[i]), "exit_ts": exit_ts,
            "side": side, "entry": entry, "exit": fill, "r_pips": r_pips, "why": why,
            "R_ba": R_ba, "R_mid": R_mid, "R_20": R_20, "fin_pips": fin, "R_safe": R_20 - fin / r_pips,
            "dec_index": di, "decision_ts": int(t), "atr20": atr, "cap_kind": cap_kind, "cap_bar": int(cap_bar),
        })
        di = max(next_di, di + 1) if why != "signal" else next_di
    return trades


def both_sides(m1, days, decisions, trade, exit_style, era_end) -> tuple:
    """R_safe of a long and of a short entered at the trade's entry (amendment A2). Each side runs its own full rule
    (stop, target or trail) up to the real trade's PLANNED cap: its signal-exit or time-exit decision bar, or the era end
    (closed at the last bar's close). The real side therefore reproduces the real trade exactly."""
    out = []
    ts = m1["ts_utc"]
    i = int(np.searchsorted(ts, trade["entry_ts"], side="left"))
    atr = float(trade["atr20"])
    r_px = STOP_ATR * atr
    t_dec = int(trade["decision_ts"])
    for side in (1, -1):
        entry, entry_mid = _market_fill(m1, i, side)
        stop0 = entry - side * r_px
        target = entry + side * TARGET_R * r_px if exit_style == "E3" else None
        trail = TRAIL_ATR * atr if exit_style == "ET" else None
        hit = _exit_scan(m1, i, int(trade["cap_bar"]), side, stop0, target, trail, days, t_dec)
        if hit is not None:
            j, fill, midf, _ = hit
        elif trade["cap_kind"] == "era_end":
            j = int(trade["cap_bar"]) - 1
            fill, midf = _market_fill(m1, j, -side, at_close=True)
        else:
            j = int(trade["cap_bar"])
            fill, midf = _market_fill(m1, j, -side)
        r_pips = r_px / PIP
        R_ba = side * (fill - entry) / r_px
        R_mid = side * (midf - entry_mid) / r_px
        R_20 = min(R_mid - COST_PIPS / r_pips, R_ba)
        fin = financing_pips(t_dec, int(ts[j]), days)
        out.append(R_20 - fin / r_pips)
    return tuple(out)


# ------------------------------------------------------------------ statistics

def era_months(era: str) -> list:
    e = ERAS[era]
    out, y, m = [], e["from"].year, e["from"].month
    while (y, m) <= (e["to"].year, e["to"].month):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


def summarize(trades: list, era: str, null_pairs: list, seed_boot: int = 4545, seed_null: int = 4546, n: int = 2000) -> dict:
    months = era_months(era)
    if not trades:
        return {"trades": 0, "per_month": 0.0, "months": len(months)}
    df = pd.DataFrame(trades)
    df["month"] = df.date.str[:7]
    r = df.R_safe.to_numpy()
    out = {
        "trades": len(df), "months": len(months), "per_month": len(df) / len(months),
        "win_rate": float((df.R_ba > 0).mean()),
        "avg_win_safe": float(df.R_safe[df.R_safe > 0].mean()) if (df.R_safe > 0).any() else None,
        "avg_loss_safe": float(df.R_safe[df.R_safe <= 0].mean()) if (df.R_safe <= 0).any() else None,
        "mean_R_ba": float(df.R_ba.mean()), "mean_R_20": float(df.R_20.mean()), "mean_R_safe": float(r.mean()),
        "R_safe_month": float(r.sum() / len(months)), "R_20_month": float(df.R_20.sum() / len(months)),
        "mean_r_pips": float(df.r_pips.mean()), "mean_fin_pips": float(df.fin_pips.mean()),
        "by_year_R_safe": {str(y): round(float(g.R_safe.sum()), 3) for y, g in df.groupby(df.date.str[:4])},
        "exits": df.why.value_counts().to_dict(),
        "longs": int((df.side == 1).sum()), "shorts": int((df.side == -1).sum()),
    }
    srt = np.sort(r)
    out["mean_R_safe_without_best5"] = float(srt[:-5].mean()) if len(srt) > 5 else None
    # month-block bootstrap of the mean R_safe a trade (all era months, empty ones included)
    by_m = {mo: df.R_safe[df.month == mo].to_numpy() for mo in months}
    rng = np.random.default_rng(seed_boot)
    means = []
    for _ in range(n):
        pick = rng.integers(0, len(months), len(months))
        vals = np.concatenate([by_m[months[p]] for p in pick])
        means.append(vals.mean() if len(vals) else 0.0)
    out["boot90"] = [float(np.percentile(means, 5)), float(np.percentile(means, 95))]
    # random-side null on the same entries (both sides precomputed)
    pairs = np.array(null_pairs)                                       # (n_trades, 2): long, short
    rng2 = np.random.default_rng(seed_null)
    pick = rng2.integers(0, 2, (n, len(pairs)))
    null_means = np.where(pick == 0, pairs[:, 0], pairs[:, 1]).mean(axis=1)
    out["null_p"] = float((null_means >= r.mean() - 1e-12).mean())
    out["null_mean"] = float(null_means.mean())
    out["usd_month_15k_1pct"] = round(out["R_safe_month"] * 150.0, 2)
    return out


def bh(pvals: list) -> list:
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    m = len(p)
    q = np.empty(m)
    prev = 1.0
    for rank, idx in reversed(list(enumerate(order, start=1))):
        prev = min(prev, p[idx] * m / rank)
        q[idx] = prev
    return [float(x) for x in q]
