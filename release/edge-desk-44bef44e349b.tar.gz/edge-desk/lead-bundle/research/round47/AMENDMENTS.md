# Round 47 amendments

Each one is made before the look it affects.

## A1 (before the B look): Part B's first judged day, and the newbie port

- **First judged day.** The 2016 file starts on 3 Jan 2016 at 22:00 UTC. tide2's daily trend needs about 120 calendar days of daily bars (about 85 bars). So Part B's B window starts on **2 May 2016** for all six rules, the first day every rule has full history (research/round47/newbie_leads/PORT.md). Part A's B window is unchanged (from 1 Mar 2016; cells with longer windows simply fire later).
- **The port** (research/round47/newbie_leads/, PORT.md, SOURCES.sha256):
  - The rule and engine files are copied byte for byte (all six declared sha256 values match). Only the data layer is swapped, at run time.
  - The six rules are `tide2`, `soup1` (version B parameters: poke 5, stop 20, target 3x), `C`, `E`, `G3` and `N2`.
  - R at 2.0 pips = min(R_mid - 2.0 / stop pips, R_ba). Each engine's own figure is reported beside it.
  - The random-side null uses each newbie's own mirror code (same levels, side flipped).
  - 16 tests pass on synthetic prices. One smoke run on 4-8 Jan 2016 (before the judged window) was done and is not interpreted.
- **Where the report text and the code differ** (the code wins, PORT.md section 4):
  - tide2's "120 days" means calendar days;
  - soup1 takes the sell if both sides trigger at once;
  - E compares the box high, strictly;
  - ATR is a simple 14-day mean;
  - N2's stop and target are measured from the 06:00 price.

## A2 (before the B look): from the cell reviews

1. **Back-to-back trades.** A decision at the exact exit minute of the cell's previous trade may now trade (`t < busy_until`, was `<=`). The conventions say only "signals that fire while a trade is open are skipped". The old rule made 1-day cells trade every other day, CT-U weekly cells every third Monday, and TS-T1 lose months.
2. **Fills are at most 15 minutes late.** The COMMON CONVENTIONS say "a missing bar means no trade; never forward-fill across more than 15 minutes". The entry bar and the exit bar must both start within 15 minutes of their times, else there is no trade. Before this, the entry was allowed up to 3 hours late and the exit any amount.
3. **Controls that one cell serves for several cells**, added in the runner's EXTRA_CONTROLS:
   - PA-F2P also controls PA-F3;
   - LV-Q2 also controls NN-P1 and EX-L3;
   - FN-C1, the fixed-side control named in its own rule, controls ME-A3.
   A pick must beat each of its controls on B, by whole-sample mean net per trade (not matched dates).
4. **Cell-level fixes the reviewers made, before any look:**
   - COT rows released at or after 1751317200 are dropped at load (the file runs to 2025-12-30);
   - the FOMC placebo weeks are defined from scheduled statements only, per the rule text.
5. **Disclosures:**
   - DF-O1 and DF-O2 build GBP/USD as EUR/USD divided by EUR/GBP (no GBP/USD series in the world).
   - Cells with prior windows (120-250 engine days) start trading only from about June 2016 on B.
   - DE30 is a total-return index and SPX500 a price index.
   - The COT release times marked "announcement_expected" (the 2019 shutdown catch-up) are used as listed. Their actual publication times are not verified.

## A3 (after the B look, before C): Part B stops at B

All six newbie rules lost on B at 2.0 pips (mean R a trade from -0.09 to -0.21, random-side p from 0.34 to 0.90). Part B passes only with B > 0 (section 5), so no lead can pass, and C and T are not read for them. The runner skips the leads on C and T when no lead had B > 0. This saves looks and changes no verdict.
