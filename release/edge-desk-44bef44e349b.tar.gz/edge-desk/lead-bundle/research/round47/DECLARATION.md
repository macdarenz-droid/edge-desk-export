# Round 47: Stage 1 bias census, plus the newbies' best rules

Declared by the second agent on 12 Oct 2026, before any EUR/USD result of these cells or rules exists. The sha256 is in DECLARATION.sha256, and the time comes from the commit. A later change is a numbered amendment in AMENDMENTS.md, made before the look it affects.

## 1. Why

**The owner's asks** (12 Oct, Melbourne):
- 09:52: "1 agent, studies bias only ... 1 agent entry only ... sl only ... tp only ... Then we mix all if we find and edge?". The reply was stages, bias first.
- About 09:56, he chose "I run it here after the swing test (Recommended)".
- He also chose "Stop 3 and 5, finish 4 and redo (Recommended)", so the stopped newbies' best rules are tested here once.

**What is already known.** Direction at the London open was a coin flip in every earlier round. Swing trend and the US-German rate gap failed on 2016-2021 (Round 45).

**This round** asks where EUR/USD direction is predictable at any holding time from 1 hour to 20 days, with no stop and no target.

## 2. Part A: the census (61 cells)

**The cells and their rules.** CELLS.json, sha256 in CELLS.sha256, holds the cells, their exact rules and the "COMMON CONVENTIONS" in its notes. It came from three independent Opus designers (order flow, macro, quant), one critic and one synthesis. The inputs and the critic's kills are in DESIGN_INPUTS.json.

**Groups (21):**
- month-end equity hedge;
- daily fix;
- turn-of-month dollar funding;
- policy-shock follow;
- data-release rate follow;
- pre-announcement drift;
- position squaring;
- option pinning;
- intraday momentum;
- 2-year rate-spread momentum;
- rate-FX divergence;
- extreme move, rate-conditioned;
- equity stress;
- equity rebalancing;
- dollar factor;
- news versus no news;
- volatility-conditioned moves;
- weekend gap;
- overnight unwind;
- 12-month trend;
- futures positioning (COT).

**Selectable cells:** 51. The 10 controls are reported only: ME-A1P, ME-A2P, ME-A3P, ME-A4P, FN-C1P, FN-C3P, PA-F1P, PA-F2P, LV-Q2 and EX-L2.

**Measure**, per trade, with each cell's declared side:
- net pips = min(side x mid move - 2.0, the bid/ask result with 0.2 pip slippage on each market fill), minus financing;
- financing: 1 pip for each 17:00 New York close held over, 3 for a Wednesday close (Round 45's rule).

Also reported:
- the 1.6-pip result;
- zero-financing figures for multi-day cells;
- pips a trade and a month, hit rate, t, by year and years positive;
- the 90% bootstrap: month blocks for daily cells, trade blocks for event cells;
- the random-side p (2,000 runs, the side flipped per trade);
- calendar cells minus their placebo on matched months;
- conditioned cells minus their control.

**Calendar.** England and Wales bank holidays are rule-coded in r47_cal.py. For 2019-2025 they equal gov.uk's list exactly (test).

**Look-ahead.** For every cell, a leak test checks that the side computed on `World.cut(decision)` equals the side on the full world.

## 3. Part B: the newbies' rules (6, exact)

Ported unchanged, or with only the data layer replaced (research/round47/newbie_leads/PORT.md), and judged at R:
- Newbie 3: tide2 (10:00 London daily-trend market entry, 20-pip stop, 2R) and soup1 B (fade a failed break of yesterday's high or low, 20-pip stop, 3R);
- Newbie 5: fix C, fix E, G3 (night-box break on the 5-day trend side) and N2 (night-move follow).

All 2016 - Jun 2025 data is unseen to these rules. Each is judged once, with no choice and no tuning.

## 4. Eras and look order

| Era | Decisions | Warm-up (prices only) |
|---|---|---|
| B | 2016-03-01 to 2021-12-31 | from 2015 data where present, else 2016-01-03 |
| C | 2022-01-03 to 2023-11-30 | from 2020-11-01 |
| T | 2023-12-01 to 2025-06-27; nothing at or after 1751317200 | from 2022-11-01 |

- The order is B (Part A and Part B), then FROZEN_B.json committed and pushed, then C once, then T once.
- The runner commits and pushes its own "started" mark before reading each era's data (Round 45's runner rules).

## 5. Picks and verdicts (fixed now)

**Part A picks (S10: B ranks and does not veto).**
- Eligible: selectable, at least 30 trades on B, and mean net > 0 at the 2.0-pip cost with financing.
- The picks are up to 3 eligible cells with the highest B 90% lower bound.
- Calendar cells must also beat their placebo on B, and conditioned cells their control.
- The B gate, reported for information:
  - lower bound > 0;
  - random-side p ≤ 0.05;
  - 4 or more of 6 years positive;
  - BH q ≤ 0.10 over the 61 cells. A global BH figure over this census plus both fast-screen registers is also reported.
- If no cell is eligible, Part A ends and C and T stay unread for it.

**Part A pass**, per pick:
- mean net > 0 on C and on T;
- pooled C+T random-side p ≤ 0.05;
- BH q ≤ 0.10 over the picks.

Promising = C and T both > 0 without the p. A pass is a stage-1 bias component: it goes to stage 2 (entry), then stage 3 (stop) and stage 4 (target). It is not yet an edge.

**Part B pass**, per rule:
- mean R at 2.0 pips > 0 on each of B, C and T;
- pooled B+C+T mirrored-side p ≤ 0.05;
- BH q ≤ 0.10 over the 6 rules.

## 6. Never

Validation, the holdout, 2010-2015 prices, the main agent's running rounds. No price download (the gov.uk holiday list is the only outside read), no order code, no secrets, no risk-size rules.
