"""Round 47 census, groups D (policy-shock follow), E (data-release rate follow), F (pre-announcement drift) and
G (position squaring).

Cells: PS-D1, PS-D2, DR-E1, DR-E2, PA-F1, PA-F2, PA-F3, PA-F4, placebos PA-F1P and PA-F2P, SQ-G1, SQ-G2.
Rule and family text come verbatim from CELLS.json; the COMMON CONVENTIONS apply. Event dates are carried by
decide_ts / exit_ts (the release schedule is known in advance); signal() carries only the side and reads only data
closed by the decision time.

Readings of the rule text (where it could be read more than one way; the most conservative causal reading is used):
- Events. World.events holds held rows only. FOMC = FOMC_STATEMENT rows whose New York local time is 14:00 (in
  events.csv every held 14:00 row is scheduled==1; the 3 unscheduled rows are at 10:00, 11:00 and 17:00 and drop
  out; checked in the tests). ECB = ECB_DECISION rows (all scheduled and held), time from the row's ts. Data
  releases = US_NFP and US_CPI rows at 08:30 New York.
- "The bar closing T" (15-min USB02Y_USD, DE10YB_EUR) is the World.xa row whose close time equals T exactly. A
  missing bar at either end, a non-positive price or a zero change gives no trade (no forward fill at all).
- A 1-min "mid at T" is the close mid of the last 1-min bar opening at or before T-1 min, and at most 15 minutes
  stale (convention: never forward-fill across more than 15 minutes); otherwise no trade.
- "Engine trading day" = Monday-Friday, as in r47_engine.run_cell (hold_days). The engine day of a time is the New
  York date of (time + 7 h). "The next engine trading day" / "the Nth engine trading day after entry" counts weekdays
  after the engine day of the decision (the entry bar is at or just after it).
- PS-D1, PS-D2: FOMC decision = statement + 90 min; ECB decision = decision + 105 min. If an FOMC and an ECB
  decision fell on one date, the earlier one is used (the later one would be skipped by the one-position rule
  anyway). Exit 16:00 London on the 1st (D1) or 5th (D2) engine trading day after the entry's engine day.
- DR-E1, DR-E2: one decision per New York date with an NFP or CPI release; exit 09:30 New York on the 1st / 3rd
  weekday after the decision date.
- PA-F1: "the engine trading day before the statement date" = the previous weekday. Exit = statement ts - 5 min.
- PA-F4: decision 12:00 London on the London business day (r47_cal) before the ECB decision's London date; exit
  decision ts - 5 min.
- PA-F1P, PA-F2P ("weeks without a scheduled FOMC statement"): read literally, on the scheduled==1 rows of
  events.csv. A week (Monday-Sunday) qualifies only if it holds no scheduled FOMC statement: no held 14:00 New York
  FOMC_STATEMENT row in World.events and not the cancelled scheduled meeting of 2020-03-18 (FOMC_CANCELLED, checked
  against events.csv in the tests; World.events does not carry cancelled rows). Unscheduled statements (scheduled==0:
  2019-10-11, 2020-03-03, 2020-03-15) do not make a week an FOMC week; World.events (held rows only) never carries
  them, and an unscheduled row at another time in a synthetic table is ignored the same way. The placebo weekday is
  Wednesday (the FOMC weekday; PA-F2P names it). PA-F1P: entry 14:00 New York on the Tuesday, exit 13:55 New York on
  the Wednesday. PA-F2P: 09:00 to 13:45 New York on the Wednesday. PA-F2P also serves PA-F3 (CELLS.json notes);
  control_of holds one id, so it names PA-F2.
- SQ-G1: only US_NFP releases on a Friday (New York date) are used; an NFP on another weekday (e.g. Thursday
  2020-07-02) gives no trade, because "enter 07:00 London Friday" would then be after the release. "Monday ... or
  the first engine day after it if a holiday": the holiday calendar is the round's declared one (England and Wales,
  r47_cal), since the reference time is 07:00 London; the reference day is the first London business day from that
  week's Monday up to Thursday. "The 1-min bar closing 07:00 London" = mid at 07:00 London (reading above). Exit at
  the bar opening release ts - 1 min.
- SQ-G2: "the first 1-min mid after Sunday 17:00 New York" = the open mid of the first 1-min bar opening at or after
  Sunday 17:00 New York of that week (before the decision). ATR14 = r47_engine.wilder_atr(w, decision, 14), i.e.
  engine days completed by Friday 08:00 New York (through Thursday). |r| >= 2.0 x ATR14 -> side = -sign(r).
- DR-E1 "(NFP Friday -> Monday, weekend nights charged)": financing is the engine's (Round 45 rule: 1 pip per
  17:00 New York close held, 3 for a Wednesday close), so a Friday-to-Monday hold pays the Friday close; the
  weekend is carried by the Wednesday triple, as declared in DECLARATION section 2. Not changed here.
- One position per cell (engine): a decision at exactly the open trade's exit time is skipped (e.g. DR-E2 from a
  Tuesday CPI exits Friday 09:30 New York, so an NFP decision that Friday is skipped).
- The 1-min exit bars ("the bar opening X") are passed to the engine as time X; the engine takes the first bar at
  or after it (shared engine behaviour, not re-checked here).
"""
from __future__ import annotations

import json
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import r47_cal as K  # noqa: E402
from r47_engine import LON, NY, Cell, local_ts, wilder_atr  # noqa: E402

_SPEC = {c["id"]: c for c in json.loads((HERE.parent / "CELLS.json").read_text())["cells"]}
FOMC_CANCELLED = (date(2020, 3, 18),)   # scheduled FOMC statement cancelled (events.csv status 'cancelled')


# ------------------------------------------------------------------ time and price helpers

def ny_date(ts: int) -> date:
    return datetime.fromtimestamp(int(ts), NY).date()


def lon_date(ts: int) -> date:
    return datetime.fromtimestamp(int(ts), LON).date()


def ny_hhmm(ts: int) -> str:
    return datetime.fromtimestamp(int(ts), NY).strftime("%H:%M")


def engine_date(ts: int) -> date:
    """The engine (17:00 New York to 17:00 New York) day a time belongs to."""
    return (datetime.fromtimestamp(int(ts), NY) + timedelta(hours=7)).date()


def add_weekdays(d: date, n: int) -> date:
    """The n-th weekday after d (n > 0) or before d (n < 0)."""
    step, left, x = (1 if n > 0 else -1), abs(n), d
    while left:
        x += timedelta(days=step)
        if x.weekday() < 5:
            left -= 1
    return x


def xa_close(w, s: str, T: int) -> float:
    """Close of the 15-min bar of series s closing exactly at T, known at T; nan if missing or not positive."""
    a, c = w.xa[s]
    k = int(np.searchsorted(a, T, side="right")) - 1
    if k < 0 or int(a[k]) != int(T) or not np.isfinite(c[k]) or c[k] <= 0:
        return np.nan
    return float(c[k])


def mid_at(w, T: int) -> float:
    """Close mid of the last 1-min bar opening at or before T-60 (closed by T), at most 15 minutes stale."""
    ts = w.m1["ts_utc"]
    k = int(np.searchsorted(ts, T - 60, side="right")) - 1
    if k < 0 or (T - 60) - int(ts[k]) > 900:
        return np.nan
    return float((w.m1["bid_c"][k] + w.m1["ask_c"][k]) / 2)


def first_open_mid(w, a: int, b: int) -> float:
    """Open mid of the first 1-min bar opening at or after a and before b; nan if none."""
    ts = w.m1["ts_utc"]
    i = int(np.searchsorted(ts, a, side="left"))
    if i >= len(ts) or int(ts[i]) >= b:
        return np.nan
    return float((w.m1["bid_o"][i] + w.m1["ask_o"][i]) / 2)


def _sign_change(a: float, b: float) -> int:
    if not (np.isfinite(a) and np.isfinite(b)) or a == b:
        return 0
    return 1 if b > a else -1


# ------------------------------------------------------------------ event index (cached per events table)

_EV_CACHE: dict = {}   # id(events) -> (events, info); the strong reference stops id reuse


def ev_index(w) -> dict:
    e = w.events
    hit = _EV_CACHE.get(id(e))
    if hit is not None and hit[0] is e:
        return hit[1]
    types, tss = e.type.to_numpy(), e.ts.to_numpy()
    fomc, ecb, data, nfp_fri, fomc_weeks = {}, {}, {}, {}, set()
    for ty, t in zip(types, tss):
        t = int(t)
        if ty == "FOMC_STATEMENT":
            dn = ny_date(t)
            if ny_hhmm(t) == "14:00":         # scheduled statements only (also for the placebo weeks)
                fomc[dn] = t
                fomc_weeks.add(dn - timedelta(days=dn.weekday()))
        elif ty == "ECB_DECISION":
            ecb[lon_date(t)] = t
        elif ty in ("US_NFP", "US_CPI") and ny_hhmm(t) == "08:30":
            dn = ny_date(t)
            data[dn] = min(t, data.get(dn, t))
            if ty == "US_NFP" and dn.weekday() == 4:
                nfp_fri[dn] = t
    for dc in FOMC_CANCELLED:
        fomc_weeks.add(dc - timedelta(days=dc.weekday()))
    ps = {}    # decision date -> (decision ts, kind, event ts) for PS-D1/D2
    for dn, t in fomc.items():
        ps[dn] = (t + 90 * 60, "FOMC", t)
    for dl, t in ecb.items():
        cand = (t + 105 * 60, "ECB", t)
        dd = lon_date(cand[0])
        if dd not in ps or cand[0] < ps[dd][0]:
            ps[dd] = cand
    info = {
        "fomc": fomc, "ecb": ecb, "data": data, "nfp_fri": nfp_fri, "fomc_weeks": fomc_weeks,
        "ps": ps, "ps_by_ts": {v[0]: v for v in ps.values()},
        "fomc_prev": {add_weekdays(dn, -1): t for dn, t in fomc.items()},
        "ecb_prev": {K.london_bd_offset(dl, -1): t for dl, t in ecb.items()},
    }
    _EV_CACHE[id(e)] = (e, info)
    return info


def _no_fomc_week(info, d: date) -> bool:
    return (d - timedelta(days=d.weekday())) not in info["fomc_weeks"]


# ------------------------------------------------------------------ D policy-shock follow

def ps_decide(w, d):
    v = ev_index(w)["ps"].get(d)
    return v[0] if v else None


def ps_signal(w, t):
    v = ev_index(w)["ps_by_ts"].get(int(t))
    if v is None:
        return 0
    _, kind, te = v
    if kind == "FOMC":    # USB02Y price up -> long
        return _sign_change(xa_close(w, "USB02Y_USD", te - 15 * 60), xa_close(w, "USB02Y_USD", te + 90 * 60))
    # ECB: Bund price down (yield up) -> long
    return -_sign_change(xa_close(w, "DE10YB_EUR", te - 15 * 60), xa_close(w, "DE10YB_EUR", te + 105 * 60))


def ps_exit(n):
    return lambda w, d, t: local_ts(add_weekdays(engine_date(t), n), "16:00", "London")


# ------------------------------------------------------------------ E data-release rate follow

def dr_decide(w, d):
    return local_ts(d, "09:30", "NewYork") if d in ev_index(w)["data"] else None


def dr_signal(w, t):
    d = ny_date(t)
    if d not in ev_index(w)["data"]:
        return 0
    a = xa_close(w, "USB02Y_USD", local_ts(d, "08:15", "NewYork"))
    b = xa_close(w, "USB02Y_USD", local_ts(d, "09:30", "NewYork"))
    return _sign_change(a, b)       # 2y price down (yield up) -> short; up -> long


def dr_exit(n):
    return lambda w, d, t: local_ts(add_weekdays(d, n), "09:30", "NewYork")


# ------------------------------------------------------------------ F pre-announcement drift

def long_only(w, t):
    return 1


def f1_decide(w, d):
    return local_ts(d, "14:00", "NewYork") if d in ev_index(w)["fomc_prev"] else None


def f1_exit(w, d, t):
    return ev_index(w)["fomc_prev"][d] - 5 * 60


def f23_decide(w, d):
    return local_ts(d, "09:00", "NewYork") if d in ev_index(w)["fomc"] else None


def f4_decide(w, d):
    return local_ts(d, "12:00", "London") if d in ev_index(w)["ecb_prev"] else None


def f4_exit(w, d, t):
    return ev_index(w)["ecb_prev"][d] - 5 * 60


def f1p_decide(w, d):
    if d.weekday() != 1 or not _no_fomc_week(ev_index(w), d):
        return None
    return local_ts(d, "14:00", "NewYork")


def f1p_exit(w, d, t):
    return local_ts(d + timedelta(days=1), "13:55", "NewYork")


def f2p_decide(w, d):
    if d.weekday() != 2 or not _no_fomc_week(ev_index(w), d):
        return None
    return local_ts(d, "09:00", "NewYork")


def same_day_exit(hhmm, tz="NewYork"):
    return lambda w, d, t: local_ts(d, hhmm, tz)


# ------------------------------------------------------------------ G position squaring

def g1_decide(w, d):
    return local_ts(d, "07:00", "London") if d in ev_index(w)["nfp_fri"] else None


def g1_ref_day(fri: date):
    """The first London business day from that week's Monday up to Thursday (None if there is none)."""
    x = fri - timedelta(days=4)
    while x < fri:
        if K.is_london_bd(x):
            return x
        x += timedelta(days=1)
    return None


def g1_signal(w, t):
    fri = lon_date(t)
    if fri.weekday() != 4 or ny_date(t) != fri:
        return 0
    ref = g1_ref_day(fri)
    if ref is None:
        return 0
    a, b = mid_at(w, local_ts(ref, "07:00", "London")), mid_at(w, local_ts(fri, "07:00", "London"))
    return -_sign_change(a, b)


def g1_exit(w, d, t):
    return ev_index(w)["nfp_fri"][d] - 60


def g2_signal(w, t):
    fri = ny_date(t)
    if fri.weekday() != 4:
        return 0
    start = first_open_mid(w, local_ts(fri - timedelta(days=5), "17:00", "NewYork"), int(t))
    end = mid_at(w, int(t))
    atr = wilder_atr(w, int(t), 14)
    if not (np.isfinite(start) and np.isfinite(end) and np.isfinite(atr)) or atr <= 0:
        return 0
    r = end - start
    if abs(r) < 2.0 * atr or r == 0:
        return 0
    return -1 if r > 0 else 1


# ------------------------------------------------------------------ cells

def _cell(cid, **kw):
    s = _SPEC[cid]
    return Cell(cid, s["family"], rule=s["rule"], **kw)


CELLS = [
    _cell("PS-D1", tz="NewYork", at="15:30", signal=ps_signal, decide_ts=ps_decide, exit_ts=ps_exit(1)),
    _cell("PS-D2", tz="NewYork", at="15:30", signal=ps_signal, decide_ts=ps_decide, exit_ts=ps_exit(5)),
    _cell("DR-E1", tz="NewYork", at="09:30", signal=dr_signal, decide_ts=dr_decide, exit_ts=dr_exit(1)),
    _cell("DR-E2", tz="NewYork", at="09:30", signal=dr_signal, decide_ts=dr_decide, exit_ts=dr_exit(3)),
    _cell("PA-F1", tz="NewYork", at="14:00", signal=long_only, decide_ts=f1_decide, exit_ts=f1_exit),
    _cell("PA-F2", tz="NewYork", at="09:00", signal=long_only, decide_ts=f23_decide, exit_ts=same_day_exit("13:45")),
    _cell("PA-F3", tz="NewYork", at="09:00", signal=long_only, decide_ts=f23_decide, exit_ts=same_day_exit("15:55")),
    _cell("PA-F4", tz="London", at="12:00", signal=long_only, decide_ts=f4_decide, exit_ts=f4_exit),
    _cell("PA-F1P", tz="NewYork", at="14:00", signal=long_only, decide_ts=f1p_decide, exit_ts=f1p_exit,
          weekdays=(1,), selectable=False, control_of="PA-F1"),
    _cell("PA-F2P", tz="NewYork", at="09:00", signal=long_only, decide_ts=f2p_decide, exit_ts=same_day_exit("13:45"),
          weekdays=(2,), selectable=False, control_of="PA-F2"),
    _cell("SQ-G1", tz="London", at="07:00", signal=g1_signal, decide_ts=g1_decide, exit_ts=g1_exit, weekdays=(4,)),
    _cell("SQ-G2", tz="NewYork", at="08:00", signal=g2_signal, exit_ts=same_day_exit("15:55"), weekdays=(4,)),
]
