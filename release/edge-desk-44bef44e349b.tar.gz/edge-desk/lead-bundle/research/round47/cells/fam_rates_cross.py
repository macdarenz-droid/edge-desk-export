"""Round 47 census, groups J (US 2y - Bund rate-spread momentum), K (rate-FX divergence catch-up), L (extreme move,
rate-conditioned), M (reversal after equity stress), N (equity-performance rebalancing) and O (EUR residual against
the dollar factor).

Cells: RS-J1, RS-J2, RS-J3, RD-K1, RD-K2, RD-K3, EX-L1, EX-L2 (control of EX-L1, not selectable), EX-L3, EX-L4, ES-M1,
EQ-N1, EQ-N2, EQ-N3, DF-O1, DF-O2. Rule and family text come verbatim from CELLS.json; the COMMON CONVENTIONS apply.
Every cell decides at 16:00 London on Monday-Friday and exits at 16:00 London N engine days later through the
engine's hold_days (no decide_ts / exit_ts needed). signal() reads only EUR/USD 1-minute bars and 15-minute
cross-asset bars closed by the decision; no events and no COT are used by these groups.

Readings of the rule text (where it could be read more than one way; the most conservative causal reading is used):
- Engine-day calendar. "Engine day" counts Monday-Friday dates, the same calendar r47_engine.run_cell uses for
  hold_days, so "5 engine days apart" and "exit on the 5th engine day" count the same days. Each engine day d has one
  observation time T_d = 16:00 London on d (16:00 London is inside the 17:00-to-17:00 New York engine day dated d).
  A weekday with no data at T_d (e.g. 25 December, a closed bond market) has a missing value; any change, return or
  spread that needs it is missing and gives no trade (no forward fill across days).
- "Bar closing 16:00 London" (15-minute World.xa series) = the row whose close time equals T_d exactly; a missing
  bar or a non-positive price gives a missing value (no forward fill at all, as in fam_events).
- "1-min mid" at T_d = the close mid of the 1-minute bar opening at T_d - 1 min, else the last bar opening within the
  15 minutes before it (the conventions' 15-minute forward-fill limit); else missing.
- dy = -(P_t / P_{t-n} - 1) / D, D = 1.9 (USB02Y_USD) and 8.5 (DE10YB_EUR), fixed. dS_n = dy_US2 - dy_Bund with P_t
  and P_{t-n} the 16:00 London closes n engine days apart (point to point, so dS5 and dS20 use the same duration
  approximation as dS1, not a sum of daily changes). Side sign(-dS): US yields up relative -> short EUR/USD.
- Returns r_n (EUR/USD, SPX500, DE30, the dollar legs) are ln(X_t / X_{t-n}) on the same 16:00 London observations.
- Prior window ("expanding from 120 to 250 engine days, then rolling, always excluding today"): the statistic's own
  values on the up to 250 engine days before today; the finite values in it must number at least 120, else no trade.
  Percentiles use numpy's default (linear interpolation); "above the 80th percentile" is strict (>); "at least the
  median" (EX-L1 rate-backing) is >=. "sd" is the sample standard deviation (ddof=1) of the prior window's daily
  16:00-to-16:00 log returns.
- EX-L1 / EX-L3 / EX-L4: "rate-backed" needs dS (5-day or 1-day) and its prior-window median; if either is missing
  the rate condition cannot be read and there is no trade (missing data = no trade). sign(-dS) = 0 is not backed.
  EX-L2 (the control) has no rate condition and so does not need the bond bars.
- RD-K1/K2/K3: "strictly opposite sign" = sign(r_n) == -sign(-dS_n) with r_n != 0 and dS_n != 0.
- ES-M1: SPX500 r5 < -2 x sd(SPX500 daily, prior window) x sqrt(5) (strict) and |r5 EUR/USD| > 1 x sd(EUR/USD daily,
  prior window) x sqrt(5) (strict); side -sign(r5 EUR/USD).
- DF-O1/O2: World has no GBP/USD series, so GBP/USD at T_d is derived by the exact cross EUR/USD 1-min mid / EUR_GBP
  15-minute close at T_d: -r5(GBP/USD) = r5(EUR_GBP) - r5(EUR/USD). DOL5 = the equal-weight mean of the five legs;
  any missing leg gives no trade. RES5 = r5(EUR/USD) + DOL5; side -sign(RES5) when |RES5| > its prior-window 80th
  percentile.
- EQ-N3: RS-J3's side (filtered dS5) is non-zero and equals sign(REL20) -> that side.
- Engine behaviour, not changed here (the shared engine is frozen): a decision at exactly the minute the open trade
  exits is skipped (t <= busy_until), so with a 16:00 London exit a 1-day-hold cell can trade at most every other
  engine day, a 3-day hold every 4th, a 5-day hold every 6th and a 10-day hold every 11th.
"""
from __future__ import annotations

import json
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from r47_engine import LON, Cell, local_ts  # noqa: E402

_SPEC = {c["id"]: c for c in json.loads((HERE.parent / "CELLS.json").read_text())["cells"]}
FF = 15 * 60                 # forward-fill limit for a 1-minute mid (COMMON CONVENTIONS)
WIN_MAX, WIN_MIN = 250, 120  # prior window, engine days
AT = "16:00"
D_US2, D_BUND = 1.9, 8.5
XA_USED = {"us2": "USB02Y_USD", "bund": "DE10YB_EUR", "spx": "SPX500_USD", "dax": "DE30_EUR", "jpy": "USD_JPY",
           "chf": "USD_CHF", "cad": "USD_CAD", "aud": "AUD_USD", "eurgbp": "EUR_GBP"}
SQ5 = float(np.sqrt(5.0))


def lon_date(ts: int) -> date:
    return datetime.fromtimestamp(int(ts), LON).date()


def _sgn(x: float) -> int:
    if x is None or not np.isfinite(x) or x == 0:
        return 0
    return 1 if x > 0 else -1


def _lag(x: np.ndarray, n: int) -> np.ndarray:
    y = np.full(len(x), np.nan)
    if n < len(x):
        y[n:] = x[: len(x) - n]
    return y


def _lr(x: np.ndarray, n: int) -> np.ndarray:
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.log(x / _lag(x, n))


def _dy(x: np.ndarray, D: float, n: int) -> np.ndarray:
    with np.errstate(invalid="ignore", divide="ignore"):
        return -(x / _lag(x, n) - 1.0) / D


# ------------------------------------------------------------------ per-world panel of 16:00 London observations

class Panel:
    """Values at 16:00 London on every Monday-Friday date from the world's first bar to the world's end. A value on
    date d uses only data closed by T_d, so the panel of World.cut(t) equals the full world's panel up to t."""

    def __init__(self, w):
        ts = w.m1["ts_utc"]
        d0 = lon_date(int(ts[0])) if len(ts) else lon_date(int(w.end_ts))
        d1 = lon_date(int(w.end_ts))
        dates, x = [], d0
        while x <= d1:
            if x.weekday() < 5:
                dates.append(x)
            x += timedelta(days=1)
        self.dates = dates
        self.pos = {d: i for i, d in enumerate(dates)}
        T = np.array([local_ts(d, AT, "London") for d in dates], dtype=np.int64)
        self.T = T
        v = {"eur": self._mid(w, T)}
        for k, s in XA_USED.items():
            v[k] = self._xa(w, s, T)
        with np.errstate(invalid="ignore", divide="ignore"):
            v["gbpusd"] = v["eur"] / v["eurgbp"]
        self.v = v
        eur, us2, bund = v["eur"], v["us2"], v["bund"]
        s = {}
        for n in (1, 5, 20):
            s[f"r{n}"] = _lr(eur, n)
            s[f"dS{n}"] = _dy(us2, D_US2, n) - _dy(bund, D_BUND, n)
        s["spx1"], s["spx5"] = _lr(v["spx"], 1), _lr(v["spx"], 5)
        s["rel20"] = _lr(v["spx"], 20) - _lr(v["dax"], 20)
        dol5 = (_lr(v["jpy"], 5) + _lr(v["chf"], 5) + _lr(v["cad"], 5) - _lr(v["aud"], 5) - _lr(v["gbpusd"], 5)) / 5.0
        s["res5"] = s["r5"] + dol5
        self.s = s
        self.memo = {}

    @staticmethod
    def _mid(w, T: np.ndarray) -> np.ndarray:
        ts = w.m1["ts_utc"]
        out = np.full(len(T), np.nan)
        if len(ts) == 0 or len(T) == 0:
            return out
        k = np.searchsorted(ts, T - 60, side="right") - 1
        kk = np.maximum(k, 0)
        ok = (k >= 0) & (ts[kk] >= T - 60 - FF)
        mid = (w.m1["bid_c"][kk] + w.m1["ask_c"][kk]) / 2.0
        ok &= np.isfinite(mid) & (mid > 0)
        out[ok] = mid[ok]
        return out

    @staticmethod
    def _xa(w, s: str, T: np.ndarray) -> np.ndarray:
        a, c = w.xa[s]
        out = np.full(len(T), np.nan)
        if len(a) == 0 or len(T) == 0:
            return out
        k = np.searchsorted(a, T, side="right") - 1
        kk = np.maximum(k, 0)
        cc = np.asarray(c, dtype=float)[kk]
        ok = (k >= 0) & (np.asarray(a)[kk] == T) & np.isfinite(cc) & (cc > 0)
        out[ok] = cc[ok]
        return out

    def stat(self, name: str, kind: str, i: int) -> float:
        """Prior-window statistic of series `name` for today = index i: 'q80' and 'med' of |x|, 'sd' of x."""
        key = (name, kind, i)
        if key in self.memo:
            return self.memo[key]
        win = self.s[name][max(0, i - WIN_MAX): i]
        win = win[np.isfinite(win)]
        if len(win) < WIN_MIN:
            out = np.nan
        elif kind == "q80":
            out = float(np.percentile(np.abs(win), 80))
        elif kind == "med":
            out = float(np.median(np.abs(win)))
        elif kind == "sd":
            out = float(np.std(win, ddof=1))
        else:
            raise ValueError(kind)
        self.memo[key] = out
        return out


_PANELS: dict = {}   # id(world) -> (world, Panel); the strong reference stops id reuse


def panel(w) -> Panel:
    hit = _PANELS.get(id(w))
    if hit is not None and hit[0] is w:
        return hit[1]
    p = Panel(w)
    if len(_PANELS) >= 64:
        _PANELS.pop(next(iter(_PANELS)))
    _PANELS[id(w)] = (w, p)
    return p


def _today(w, ts: int):
    """(panel, index of today's engine day) if today's 16:00 London observation is known at ts, else (panel, None)."""
    p = panel(w)
    i = p.pos.get(lon_date(ts))
    if i is None or int(p.T[i]) > int(ts):
        return p, None
    return p, i


def _above(p: Panel, name: str, i: int, kind: str = "q80") -> bool:
    x, thr = p.s[name][i], p.stat(name, kind, i)
    return bool(np.isfinite(x) and np.isfinite(thr) and abs(x) > thr)


# ------------------------------------------------------------------ J rate-spread momentum

def sig_rs_j1(w, ts):
    p, i = _today(w, ts)
    return 0 if i is None else -_sgn(p.s["dS1"][i])


def sig_rs_j2(w, ts):
    p, i = _today(w, ts)
    if i is None or not _above(p, "dS1", i):
        return 0
    return -_sgn(p.s["dS1"][i])


def sig_rs_j3(w, ts):
    p, i = _today(w, ts)
    if i is None or not _above(p, "dS5", i):
        return 0
    return -_sgn(p.s["dS5"][i])


# ------------------------------------------------------------------ K rate-FX divergence

def rd_signal(n: int):
    ds, r = f"dS{n}", f"r{n}"

    def sig(w, ts):
        p, i = _today(w, ts)
        if i is None or not _above(p, ds, i):
            return 0
        rate = -_sgn(p.s[ds][i])
        fx = _sgn(p.s[r][i])
        return rate if rate != 0 and fx == -rate else 0
    return sig


# ------------------------------------------------------------------ L extreme move, rate-conditioned

def _extreme(p: Panel, i: int, n: int) -> int:
    """sign(r_n) if |r_n| > 2 x prior-window daily sd x sqrt(n), else 0."""
    r, sd = p.s[f"r{n}"][i], p.stat("r1", "sd", i)
    if not (np.isfinite(r) and np.isfinite(sd)) or not abs(r) > 2.0 * sd * np.sqrt(n):
        return 0
    return _sgn(r)


def _backed(p: Panel, i: int, n: int, rs: int):
    """True / False whether a move of sign rs is rate-backed (dS_n), None if the rate data is missing."""
    ds, med = p.s[f"dS{n}"][i], p.stat(f"dS{n}", "med", i)
    if not (np.isfinite(ds) and np.isfinite(med)):
        return None
    return bool(-_sgn(ds) == rs and abs(ds) >= med)


def ex_signal(n: int, mode: str):
    """mode 'fade_unbacked' (EX-L1, EX-L3), 'fade_all' (EX-L2), 'follow_backed' (EX-L4)."""
    def sig(w, ts):
        p, i = _today(w, ts)
        if i is None:
            return 0
        rs = _extreme(p, i, n)
        if rs == 0:
            return 0
        if mode == "fade_all":
            return -rs
        b = _backed(p, i, n, rs)
        if b is None:
            return 0
        if mode == "fade_unbacked":
            return -rs if not b else 0
        return rs if b else 0
    return sig


# ------------------------------------------------------------------ M equity stress

def sig_es_m1(w, ts):
    p, i = _today(w, ts)
    if i is None:
        return 0
    spx5, sd_spx = p.s["spx5"][i], p.stat("spx1", "sd", i)
    r5, sd_eur = p.s["r5"][i], p.stat("r1", "sd", i)
    if not all(np.isfinite(x) for x in (spx5, sd_spx, r5, sd_eur)):
        return 0
    if not spx5 < -2.0 * sd_spx * SQ5:
        return 0
    if not abs(r5) > 1.0 * sd_eur * SQ5:
        return 0
    return -_sgn(r5)


# ------------------------------------------------------------------ N equity rebalancing

def sig_eq_n1(w, ts):
    p, i = _today(w, ts)
    return 0 if i is None else _sgn(p.s["rel20"][i])


def sig_eq_n2(w, ts):
    p, i = _today(w, ts)
    if i is None or not _above(p, "rel20", i):
        return 0
    return _sgn(p.s["rel20"][i])


def sig_eq_n3(w, ts):
    j3 = sig_rs_j3(w, ts)
    return j3 if j3 != 0 and j3 == sig_eq_n1(w, ts) else 0


# ------------------------------------------------------------------ O dollar-factor residual

def sig_df_o(w, ts):
    p, i = _today(w, ts)
    if i is None or not _above(p, "res5", i):
        return 0
    return -_sgn(p.s["res5"][i])


# ------------------------------------------------------------------ cells

def _cell(cid, hold_days, signal, **kw):
    s = _SPEC[cid]
    return Cell(cid, s["family"], tz="London", at=AT, hold_days=hold_days, signal=signal, rule=s["rule"], **kw)


CELLS = [
    _cell("RS-J1", 1, sig_rs_j1),
    _cell("RS-J2", 1, sig_rs_j2),
    _cell("RS-J3", 5, sig_rs_j3),
    _cell("RD-K1", 1, rd_signal(5)),
    _cell("RD-K2", 5, rd_signal(5)),
    _cell("RD-K3", 5, rd_signal(20)),
    _cell("EX-L1", 3, ex_signal(5, "fade_unbacked")),
    _cell("EX-L2", 3, ex_signal(5, "fade_all"), selectable=False, control_of="EX-L1"),
    _cell("EX-L3", 1, ex_signal(1, "fade_unbacked")),
    _cell("EX-L4", 5, ex_signal(5, "follow_backed")),
    _cell("ES-M1", 1, sig_es_m1),
    _cell("EQ-N1", 5, sig_eq_n1),
    _cell("EQ-N2", 10, sig_eq_n2),
    _cell("EQ-N3", 5, sig_eq_n3),
    _cell("DF-O1", 1, sig_df_o),
    _cell("DF-O2", 5, sig_df_o),
]
