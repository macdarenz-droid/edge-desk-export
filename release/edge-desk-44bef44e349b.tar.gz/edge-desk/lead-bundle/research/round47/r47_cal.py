"""Round 47 calendar helpers: England and Wales bank holidays (rule-coded, checked against gov.uk for 2019-2025 in
tests/test_r47_cal.py), London business days and their month positions, engine days (17:00 New York to 17:00 New York)."""
from __future__ import annotations

from datetime import date, timedelta
from functools import lru_cache

SPECIAL = {  # one-off changes (gov.uk): moved or added days
    2020: {"drop": [date(2020, 5, 4)], "add": [date(2020, 5, 8)]},
    2022: {"drop": [date(2022, 5, 30)], "add": [date(2022, 6, 2), date(2022, 6, 3), date(2022, 9, 19)]},
    2023: {"drop": [], "add": [date(2023, 5, 8)]},
}


def easter(y: int) -> date:
    """Anonymous Gregorian algorithm (Meeus/Jones/Butcher)."""
    a, b, c = y % 19, y // 100, y % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return date(y, month, day)


def _first_monday(y, m):
    d = date(y, m, 1)
    return d + timedelta(days=(7 - d.weekday()) % 7)


def _last_monday(y, m):
    d = date(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1)
    return d - timedelta(days=d.weekday())


@lru_cache(None)
def bank_holidays(y: int) -> frozenset:
    hol = set()
    nyd = date(y, 1, 1)
    hol.add(nyd if nyd.weekday() < 5 else nyd + timedelta(days=7 - nyd.weekday()))
    e = easter(y)
    hol |= {e - timedelta(days=2), e + timedelta(days=1)}
    hol |= {_first_monday(y, 5), _last_monday(y, 5), _last_monday(y, 8)}
    xmas, box = date(y, 12, 25), date(y, 12, 26)
    if xmas.weekday() == 5:          # Saturday: Mon 27 and Tue 28
        hol |= {date(y, 12, 27), date(y, 12, 28)}
    elif xmas.weekday() == 6:        # Sunday: Boxing Mon 26, Christmas substitute Tue 27
        hol |= {box, date(y, 12, 27)}
    elif xmas.weekday() == 4:        # Friday: Boxing Day Saturday -> Monday 28
        hol |= {xmas, date(y, 12, 28)}
    else:
        hol |= {xmas, box}
    sp = SPECIAL.get(y, {"drop": [], "add": []})
    hol -= set(sp["drop"])
    hol |= set(sp["add"])
    return frozenset(hol)


def is_london_bd(d: date) -> bool:
    return d.weekday() < 5 and d not in bank_holidays(d.year)


@lru_cache(None)
def london_bds(y: int, m: int) -> tuple:
    d, out = date(y, m, 1), []
    while d.month == m:
        if is_london_bd(d):
            out.append(d)
        d += timedelta(days=1)
    return tuple(out)


def nth_last_london_bd(y: int, m: int, n: int) -> date:
    """n = 1: the last London business day of the month; 3: the third-last."""
    return london_bds(y, m)[-n]


def london_bd_offset(d: date, k: int) -> date:
    """The London business day k business days after (k > 0) or before (k < 0) d."""
    step = 1 if k > 0 else -1
    x, left = d, abs(k)
    while left:
        x += timedelta(days=step)
        if is_london_bd(x):
            left -= 1
    return x
