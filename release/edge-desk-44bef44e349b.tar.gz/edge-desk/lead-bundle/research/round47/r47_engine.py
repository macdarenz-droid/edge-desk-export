"""Round 47 (Stage 1 bias census): data world, cell simulator and statistics.

A cell = a causal signal (side +1, -1 or 0 known at its decision time) x a decision time (London or New York local
time) x a holding time. No stop and no target: the trade is entered at the first 1-minute bar at or after the decision
and closed at the first bar at or after the hold's end. One position at a time per cell (no overlapping trades).
Nothing at or after CUT (1751317200) is ever loaded.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Callable
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "round45"))
import r45  # noqa: E402  (hash-checked loaders, daily bars, CUT, financing rule)

CUT = r45.CUT
PIP = 1e-4
SLIP = 0.2 * PIP
COST = 2.0
FILL_LIMIT = 15 * 60          # amendment A2 (COMMON CONVENTIONS): a missing bar means no trade; no fill over 15 min late
LON, NY = ZoneInfo("Europe/London"), ZoneInfo("America/New_York")
TZ = {"London": LON, "NewYork": NY}
XA_SERIES = ("AUD_USD", "BCO_USD", "DE10YB_EUR", "DE30_EUR", "EUR_GBP", "JP225_USD", "NAS100_USD", "SPX500_USD",
             "UK100_GBP", "UK10YB_GBP", "USB02Y_USD", "USB10Y_USD", "USD_CAD", "USD_CHF", "USD_JPY", "XAU_USD")
ERAS = {
    "B": {"from": date(2016, 3, 1), "to": date(2021, 12, 31), "warm": date(2016, 1, 3), "end": 1640995200},
    "C": {"from": date(2022, 1, 3), "to": date(2023, 11, 30), "warm": date(2020, 11, 1), "end": 1701388800},
    "T": {"from": date(2023, 12, 1), "to": date(2025, 6, 27), "warm": date(2022, 11, 1), "end": CUT},
}


# ------------------------------------------------------------------ data world

def load_xa(end_ts: int) -> dict:
    end_ts = min(int(end_ts), CUT)
    out = {}
    for s in XA_SERIES:
        parts = []
        for d in r45.XA.values():
            f = d / f"{s}_M15_M.csv"
            r45.check(f, d / "HASHES.txt")
            parts.append(pd.read_csv(f, usecols=["ts_utc", "c"]))
        b = pd.concat(parts, ignore_index=True).drop_duplicates("ts_utc").sort_values("ts_utc")
        tc = b.ts_utc.to_numpy() + 900
        keep = tc <= end_ts
        out[s] = (tc[keep], b.c.to_numpy()[keep])
    return out


def load_events(end_ts: int) -> pd.DataFrame:
    """Scheduled release times (known in advance; the schedule is not an outcome), before min(end_ts, CUT)."""
    e = pd.read_csv(r45.REPO / "research/round17/data/events.csv", usecols=["type", "utc", "status"])
    e = e[e.status == "held"].copy()
    e["ts"] = [int(pd.Timestamp(u).timestamp()) for u in e.utc]      # seconds, whatever the pandas time unit
    return e[e.ts < min(int(end_ts), CUT)][["type", "ts"]].sort_values("ts").reset_index(drop=True)


@dataclass
class World:
    m1: dict
    xa: dict
    events: pd.DataFrame
    days: pd.DataFrame
    end_ts: int

    @classmethod
    def load(cls, end_ts: int, start_ts: int = 0) -> "World":
        m1 = r45.load_m1(end_ts, start_ts)
        return cls(m1, load_xa(end_ts), load_events(end_ts), r45.daily_bars(m1), min(int(end_ts), CUT))

    def cut(self, ts: int) -> "World":
        """The same world as known at ts (for leak tests): bars closed by ts only."""
        k = int(np.searchsorted(self.m1["ts_utc"], ts - 60, side="right"))
        m1 = {c: v[:k] for c, v in self.m1.items()}
        xa = {s: (a[a <= ts], b[a <= ts]) for s, (a, b) in self.xa.items()}
        days = self.days[self.days.end <= ts].reset_index(drop=True)
        return World(m1, xa, self.events, days, ts)

    # -- prices known at ts
    def eur(self, ts: int) -> float:
        """EUR/USD mid close of the last 1-minute bar fully closed by ts."""
        ts_arr = self.m1["ts_utc"]
        k = int(np.searchsorted(ts_arr, ts - 60, side="right")) - 1
        if k < 0:
            return np.nan
        return (self.m1["bid_c"][k] + self.m1["ask_c"][k]) / 2

    def px(self, s: str, ts: int, max_age: int = 4 * 86400) -> float:
        a, c = self.xa[s]
        k = int(np.searchsorted(a, ts, side="right")) - 1
        if k < 0 or ts - a[k] > max_age:
            return np.nan
        return float(c[k])

    def ret(self, s: str, ts: int, lb: int) -> float:
        """ln return of series s from ts - lb to ts (seconds); 'EUR_USD' uses the 1-minute mid."""
        if s == "EUR_USD":
            a, b = self.eur(ts), self.eur(ts - lb)
        else:
            a, b = self.px(s, ts), self.px(s, ts - lb)
        return float(np.log(a / b)) if np.isfinite(a) and np.isfinite(b) and a > 0 and b > 0 else np.nan

    def day_k(self, ts: int) -> int:
        """Index of the last New York trading day completed by ts (-1 if none)."""
        return int(np.searchsorted(self.days.end.to_numpy(), ts, side="right")) - 1

    def day_ret(self, ts: int, n: int) -> float:
        """EUR/USD mid close-to-close return over the last n completed New York days."""
        k = self.day_k(ts)
        if k - n < 0:
            return np.nan
        c = self.days.c.to_numpy()
        return float(np.log(c[k] / c[k - n]))

    def atr20(self, ts: int) -> float:
        k = self.day_k(ts)
        return float(self.days.atr20.iloc[k]) if k >= 0 else np.nan

    def events_between(self, a: int, b: int, types=None) -> pd.DataFrame:
        e = self.events[(self.events.ts >= a) & (self.events.ts < b)]
        return e if types is None else e[e.type.isin(types)]


# ------------------------------------------------------------------ decisions and trades

def local_ts(d: date, hhmm: str, tz: str) -> int:
    h, m = map(int, hhmm.split(":"))
    return int(datetime.combine(d, time(h, m), TZ[tz]).timestamp())


def decision_dates(era: str, weekdays=(0, 1, 2, 3, 4)) -> list:
    e = ERAS[era]
    out, x = [], e["from"]
    while x <= e["to"]:
        if x.weekday() in weekdays:
            out.append(x)
        x += timedelta(days=1)
    return out


@dataclass
class Cell:
    id: str
    family: str
    tz: str = "London"           # "London" or "NewYork"
    at: str = "07:00"            # "HH:MM" local
    hold_min: int = 0            # intraday hold in minutes, or
    hold_days: int = 0           # N trading days (Mon-Fri) later at the same local time
    signal: Callable = None      # signal(world, ts) -> -1, 0 or +1 (must use only data known at ts)
    weekdays: tuple = (0, 1, 2, 3, 4)
    rule: str = ""
    decide_ts: Callable = None   # decide_ts(world, d: date) -> decision ts or None; overrides tz/at (event cells)
    exit_ts: Callable = None     # exit_ts(world, d: date, t: int) -> exit ts or None; overrides hold_min/hold_days
    selectable: bool = True      # False for placebos and controls
    control_of: str = ""         # for a placebo or control: the id of the cell it controls


def _bar_at_or_after(ts_arr: np.ndarray, t: int, limit: int = 3 * 3600) -> int:
    i = int(np.searchsorted(ts_arr, t, side="left"))
    if i >= len(ts_arr) or ts_arr[i] >= t + limit:
        return -1
    return i


def run_cell(w: World, cell: Cell, era: str) -> list:
    """Trades of one cell. Entry: the first 1-minute bar at or after the decision, within 15 minutes, else no trade.
    Exit: the first 1-minute bar at or after the exit time, within 15 minutes, else no trade (amendment A2).
    One position at a time: a decision before the open trade's exit is skipped; one at the exit minute may trade."""
    m = w.m1
    ts = m["ts_utc"]
    dates = decision_dates(era, cell.weekdays)
    trading = decision_dates(era) + [ERAS[era]["to"] + timedelta(days=k) for k in range(1, 40)
                                       if (ERAS[era]["to"] + timedelta(days=k)).weekday() < 5]
    trades, busy_until = [], -1
    for d in dates:
        t = cell.decide_ts(w, d) if cell.decide_ts else local_ts(d, cell.at, cell.tz)
        if t is None or t < busy_until or t >= w.end_ts:              # A2: a decision at the exit minute may trade
            continue
        side = int(cell.signal(w, t))
        if side == 0:
            continue
        if cell.exit_ts:
            t_exit = cell.exit_ts(w, d, t)
        elif cell.hold_days:
            k = trading.index(d) + cell.hold_days if d in trading else None
            t_exit = local_ts(trading[k], cell.at, cell.tz) if k is not None and k < len(trading) else None
        else:
            t_exit = t + 60 * cell.hold_min
        if t_exit is None or t_exit <= t or t_exit >= w.end_ts:
            continue
        i = _bar_at_or_after(ts, t, limit=FILL_LIMIT)                  # A2: no fill more than 15 minutes late
        j = _bar_at_or_after(ts, t_exit, limit=FILL_LIMIT)
        if i < 0 or j < 0 or ts[j] >= w.end_ts or j <= i:
            continue
        mid_i = (m["bid_o"][i] + m["ask_o"][i]) / 2
        mid_j = (m["bid_o"][j] + m["ask_o"][j]) / 2
        move = (mid_j - mid_i) / PIP
        long_ba = ((m["bid_o"][j] - SLIP) - (m["ask_o"][i] + SLIP)) / PIP
        short_ba = ((m["bid_o"][i] - SLIP) - (m["ask_o"][j] + SLIP)) / PIP
        fin = r45.financing_pips(int(ts[i]), int(ts[j]), w.days)
        net = {s_: min(s_ * move - COST, ba) - fin for s_, ba in ((1, long_ba), (-1, short_ba))}
        net16 = {s_: min(s_ * move - 1.6, ba) - fin for s_, ba in ((1, long_ba), (-1, short_ba))}
        trades.append({"cell": cell.id, "date": str(d), "side": side, "entry_ts": int(ts[i]), "exit_ts": int(ts[j]),
                       "move_pips": move, "net_ba": (long_ba if side == 1 else short_ba) - fin, "fin": fin,
                       "net": net[side], "net16": net16[side], "net_long": net[1], "net_short": net[-1]})
        busy_until = int(ts[j])
    return trades


def wilder_atr(w: World, ts: int, n: int) -> float:
    """Wilder ATR(n) of EUR/USD mid daily bars completed by ts (New York engine days)."""
    k = w.day_k(ts)
    if k < n:
        return np.nan
    d = w.days.iloc[: k + 1]
    pc = d.c.shift(1)
    tr = np.maximum(d.h - d.l, np.maximum((d.h - pc).abs(), (d.l - pc).abs())).to_numpy()[1:]
    a = tr[:n].mean()
    for x in tr[n:]:
        a = (a * (n - 1) + x) / n
    return float(a)


# ------------------------------------------------------------------ statistics

def era_months(era: str) -> list:
    e = ERAS[era]
    out, y, mo = [], e["from"].year, e["from"].month
    while (y, mo) <= (e["to"].year, e["to"].month):
        out.append(f"{y:04d}-{mo:02d}")
        mo = mo + 1 if mo < 12 else 1
        y = y + 1 if mo == 1 else y
    return out


def summarize(trades: list, era: str, n: int = 2000, seed: int = 4747) -> dict:
    months = era_months(era)
    if not trades:
        return {"trades": 0, "per_month": 0.0, "months": len(months), "null_p": 1.0}
    df = pd.DataFrame(trades)
    df["month"] = df.date.str[:7]
    x = df.net.to_numpy()
    out = {"trades": len(df), "months": len(months), "per_month": len(df) / len(months),
           "mean_net": float(x.mean()), "mean_net_ba": float(df.net_ba.mean()), "mean_move_side": float((df.side * df.move_pips).mean()),
           "hit": float((x > 0).mean()), "net_month": float(x.sum() / len(months)),
           "t": float(x.mean() / (x.std(ddof=1) / np.sqrt(len(x)))) if len(x) > 2 and x.std(ddof=1) > 0 else 0.0,
           "longs": int((df.side == 1).sum()), "shorts": int((df.side == -1).sum())}
    yrs = df.groupby(df.date.str[:4]).net.sum()
    out["by_year"] = {k: round(float(v), 1) for k, v in yrs.items()}
    out["years_pos"] = int((yrs > 0).sum())
    out["years"] = int(len(yrs))
    by_m = {mo: df.net[df.month == mo].to_numpy() for mo in months}
    rng = np.random.default_rng(seed)
    means = []
    for _ in range(n):
        vals = np.concatenate([by_m[months[p]] for p in rng.integers(0, len(months), len(months))])
        means.append(vals.mean() if len(vals) else 0.0)
    out["boot90"] = [float(np.percentile(means, 5)), float(np.percentile(means, 95))]
    pick = np.random.default_rng(seed + 1).integers(0, 2, (n, len(df)))
    null = np.where(pick == 0, df.net_long.to_numpy(), df.net_short.to_numpy()).mean(axis=1)
    out["null_p"] = float((null >= x.mean() - 1e-12).mean())
    return out


bh = r45.bh
