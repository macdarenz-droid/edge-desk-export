# Round 49: Round 47's picks, tested once on 2010-2015

Declared by the second agent on 12 Oct 2026, before any 2010-2015 price is read. The sha256 is in DECLARATION.sha256, and the time comes from the commit. A later change is a numbered amendment, made before the look.

## 1. Why

Round 47 picked three cells on 2016-2021. All three were positive on both 2022-2023 and Dec 2023 - Jun 2025, but the pooled p (0.06-0.26) did not pass. 2010-2015 has never been used to choose or judge these cells. The owner approved this one-time test at about 10:56 Melbourne: "Test them on 2010-2015 (Recommended)" (CLAUDE.md).

## 2. The rules (unchanged code)

From research/round47/cells/fam_events.py (sha256 8c2d2211dac94c4105c62a2a0a87ef5431271c2455586c93bc9cc1ededac4614), run by research/round47/r47_engine.py (sha256 4d1c0a97300b2ab91e9683fd3941b90493ada16fa5098654194a24650788b4e0), both at commit 00f15b2:
- **PA-F4:** long EUR/USD at 12:00 London on the London business day before an ECB monetary-policy decision; out 5 minutes before the decision.
- **PA-F1:** long EUR/USD at 14:00 New York on the weekday before a scheduled FOMC statement; out 5 minutes before the statement.
- **SQ-G2:** Fridays at 08:00 New York. If the week's move (from Sunday's open) is at least 2.0 x ATR14, fade it; out 15:55 New York.
- **Placebo PA-F1P** (Tuesdays of weeks with no FOMC statement), reported beside PA-F1.

Costs and measures are Round 47's:
- net pips = min(side x mid move - 2.0, the bid/ask result with 0.2 pip slippage), minus financing (1 pip a night, 3 for a Wednesday);
- the random-side p, 2,000 runs, seed 4949.

**The one declared mapping.** In 2010-2012 the scheduled FOMC statement came at 14:15 New York, or 12:30 on some press-conference days, not 14:00. fam_events.py keeps 14:00 statements only; that filter was there to drop the unscheduled 2019-2020 statements. Here the FOMC set is every scheduled, held statement at its own time, from the official calendar (research/round49/data/events_2010_2015.csv, built from the Fed's and ECB's own pages). This is done by giving the unchanged cell code a World whose events hold those rows, with each statement's own time. The strict reading (14:00 statements only, which leaves mainly 2013-2015) is reported beside it.

**Calendar check.** The new calendar's 2015 rows must match research/round17/data/events.csv for both types. If any 2015 row differs, 2015 uses events.csv and the difference is reported.

## 3. Data

- **Prices:** EUR/USD 1-minute bid/ask from 2010-01-01 to 2016-01-01, downloaded once from OANDA practice (research/data/oanda_download.py, rate-limited). The sha256 is compared with research/round14/CONFIRM2_DATA_HASHES.txt. If it differs, that is reported and the new hash is recorded.
- **Decisions:** 2010-04-01 to 2015-12-31. Before that is warm-up for ATR14.
- Nothing after 2016-01-01 is read. Validation and the holdout are never read.

## 4. Verdict (fixed now)

**Confirmed on 2010-2015**, per rule:
- mean net > 0;
- random-side p ≤ 0.05;
- BH q ≤ 0.10 over the three rules.

**Consistent**, but not confirmed: mean net > 0 and p > 0.05.

Also reported: each rule's figures over all four periods (2010-2015, 2016-2021, 2022-2023, Dec 2023 - Jun 2025), and its by-year sums.

**What each verdict means.**
- **A confirmed rule** has held on data it never saw, twice. It goes to Stage 2 (entry), then 3 (stop) and 4 (target), chosen on 2010-2021 only, then to the locked final test under HANDOFF "Final tests (locked data)".
- **Not confirmed:** the Round 47 result is more likely luck, and the line is recorded as closed.

## 5. Never

Validation, the holdout, the main agent's running rounds, the newbies' work. No order code, no secrets, no risk-size rules.
