"""Round 49: Round 47's picks (PA-F4, PA-F1, SQ-G2) and the placebo PA-F1P, once on 2010-2015 (DECLARATION.md).

  python3 r49_run.py look      (commits and pushes its own 'started' mark before reading any 2010-2015 price)
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from datetime import date, datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(REPO / "research/round47"))
import r47_engine as E  # noqa: E402
from cells import fam_events as F  # noqa: E402

BRANCH = "agent/round-45"
DECL_SHA = "85208d4b0b35899e10c5cb4a64010ba7fd80b4893119d9dbc180c7df066f4675"
PINNED = {"research/round47/cells/fam_events.py": "8c2d2211dac94c4105c62a2a0a87ef5431271c2455586c93bc9cc1ededac4614",
          "research/round47/r47_engine.py": "4d1c0a97300b2ab91e9683fd3941b90493ada16fa5098654194a24650788b4e0"}
RAW = Path("/tmp/claude-0/-home-user-Forex-signal/f70f8404-eff2-5a54-b7d9-7c14fcd9210f/scratchpad/fxdata_confirm2_raw/EURUSD_M1_BA.csv")
END = int(datetime(2016, 1, 1, tzinfo=timezone.utc).timestamp())
RULES = ("PA-F4", "PA-F1", "SQ-G2")
PLACEBO = "PA-F1P"
CAL = HERE / "data/events_2010_2015.csv"


def git(*a):
    r = subprocess.run(["git", "-C", str(REPO), *a], capture_output=True, text=True)
    if r.returncode:
        raise SystemExit(f"git {' '.join(a)}: {r.stderr.strip()}")
    return r.stdout


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 22), b""):
            h.update(b)
    return h.hexdigest()


def guards():
    if sha(HERE / "DECLARATION.md") != DECL_SHA:
        raise SystemExit("DECLARATION.md changed")
    for rel, want in PINNED.items():
        if sha(REPO / rel) != want:
            raise SystemExit(f"{rel} is not the declared code")
    files = ["research/round49/r49_run.py", "research/round49/data/events_2010_2015.csv"]
    if git("status", "--porcelain", "--", *files).strip():
        raise SystemExit("runner or calendar not committed")
    git("fetch", "-q", "origin", BRANCH)
    if subprocess.run(["git", "-C", str(REPO), "merge-base", "--is-ancestor", "HEAD", f"origin/{BRANCH}"]).returncode:
        raise SystemExit("HEAD is not pushed")
    if (HERE / "LOOKS.jsonl").exists() or (HERE / "results.json").exists() or \
            git("log", "--all", "--format=%H", "--", "research/round49/LOOKS.jsonl").strip():
        raise SystemExit("2010-2015 was already looked at once")


def mark_started():
    head = git("rev-parse", "HEAD").strip()
    (HERE / "LOOKS.jsonl").write_text(json.dumps({"status": "started", "head": head,
                                                   "utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}) + "\n")
    git("add", "research/round49/LOOKS.jsonl")
    git("commit", "-q", "-m", "Round 49: 2010-2015 look started (mark committed before any price is read)")
    for _ in range(4):
        if subprocess.run(["git", "-C", str(REPO), "push", "-q", "origin", BRANCH]).returncode == 0:
            return head
    raise SystemExit("the started mark could not be pushed; no price was read")


def calendar() -> tuple:
    """(events for the World, 2015 check). Scheduled, held FOMC statements and ECB decisions with a time."""
    c = pd.read_csv(CAL)
    c = c[(c.scheduled == 1) & (c.status == "held") & c.type.isin(["FOMC_STATEMENT", "ECB_DECISION"]) & c.utc.notna()].copy()
    c["ts"] = [int(pd.Timestamp(u).timestamp()) for u in c.utc]
    ref = pd.read_csv(REPO / "research/round17/data/events.csv")
    ref = ref[(ref.scheduled == 1) & (ref.status == "held") & ref.type.isin(["FOMC_STATEMENT", "ECB_DECISION"]) & ref.utc.notna()]
    ref15 = {(t, u) for t, u, y in zip(ref.type, ref.utc, ref.year) if int(y) == 2015}
    new15 = {(t, u) for t, u, y in zip(c.type, c.utc, c.year) if int(y) == 2015}
    check = {"match": ref15 == new15, "only_in_new": sorted(new15 - ref15), "only_in_events_csv": sorted(ref15 - new15)}
    if not check["match"]:                                    # DECLARATION section 2: then 2015 comes from events.csv
        r15 = ref[ref.year.astype(int) == 2015].copy()
        r15["ts"] = [int(pd.Timestamp(u).timestamp()) for u in r15.utc]
        c = pd.concat([c[c.year.astype(int) < 2015], r15])
    ev = c[c.ts < END][["type", "ts"]].sort_values("ts").reset_index(drop=True)
    return ev, check


def load_world(ev) -> E.World:
    m = pd.read_csv(RAW)
    m = m[(m.ts_utc < END)].drop_duplicates("ts_utc").sort_values("ts_utc")
    m1 = {k: m[k].to_numpy() for k in m.columns}
    return E.World(m1, {}, ev, E.r45.daily_bars(m1), END)


def run(w, mapping: bool) -> dict:
    fomc_ts = set(int(t) for ty, t in zip(w.events.type, w.events.ts) if ty == "FOMC_STATEMENT")
    orig = F.ny_hhmm
    if mapping:                                               # the declared mapping: every scheduled statement counts
        F.ny_hhmm = lambda t: "14:00" if int(t) in fomc_ts else orig(t)
    F._EV_CACHE.clear()
    try:
        by = {c.id: c for c in F.CELLS}
        out, trades = {}, []
        for cid in RULES + (PLACEBO,):
            tr = E.run_cell(w, by[cid], "X")
            out[cid] = E.summarize(tr, "X", seed=4949)
            trades += tr
        return out, trades
    finally:
        F.ny_hhmm = orig
        F._EV_CACHE.clear()


def main():
    guards()
    E.ERAS["X"] = {"from": date(2010, 4, 1), "to": date(2015, 12, 31), "warm": date(2010, 1, 3), "end": END}
    ev, check = calendar()
    head = mark_started()
    raw_sha = sha(RAW)
    listed = dict(l.split()[::-1] for l in (REPO / "research/round14/CONFIRM2_DATA_HASHES.txt").read_text().splitlines() if l.strip())
    w = load_world(ev)
    assert int(w.m1["ts_utc"].max()) < END
    main_res, main_tr = run(w, mapping=True)
    strict_res, _ = run(w, mapping=False)
    ps = [main_res[r]["null_p"] for r in RULES]
    verdict = {}
    for r, q in zip(RULES, E.bh(ps)):
        s = main_res[r]
        pos = s.get("mean_net", -1) > 0
        verdict[r] = {"mean_net": s.get("mean_net"), "trades": s.get("trades"), "null_p": s.get("null_p"), "bh_q": q,
                      "verdict": "confirmed" if pos and s["null_p"] <= 0.05 and q <= 0.10 else ("consistent" if pos else "not confirmed")}
    r47 = {e: json.loads((REPO / f"research/round47/results/{e}.json").read_text())["cells"] for e in ("B", "C", "T")}
    periods = {r: {"2010-2015": main_res[r].get("mean_net"), **{e: r47[e].get(r, {}).get("mean_net") for e in ("B", "C", "T")}}
               for r in RULES}
    out = {"head": head, "raw_sha256": raw_sha, "confirm2_listed_sha256": listed.get("EURUSD_M1_BA.csv"),
           "raw_matches_confirm2": raw_sha == listed.get("EURUSD_M1_BA.csv"), "calendar_2015_check": check,
           "events": {"FOMC_STATEMENT": int((ev.type == "FOMC_STATEMENT").sum()), "ECB_DECISION": int((ev.type == "ECB_DECISION").sum())},
           "main": main_res, "strict_14_00_only": strict_res, "verdict": verdict, "mean_net_by_period": periods}
    (HERE / "results.json").write_text(json.dumps(out, indent=1, default=float))
    pd.DataFrame(main_tr).to_csv(HERE / "trades_2010_2015.csv.gz", index=False)
    with open(HERE / "LOOKS.jsonl", "a") as f:
        f.write(json.dumps({"status": "done", "head": head, "results_sha256": sha(HERE / "results.json")}) + "\n")
    print(json.dumps({k: out[k] for k in ("raw_matches_confirm2", "calendar_2015_check", "events", "verdict", "mean_net_by_period")},
                     indent=1, default=float))


if __name__ == "__main__":
    if sys.argv[1:] == ["look"]:
        main()
