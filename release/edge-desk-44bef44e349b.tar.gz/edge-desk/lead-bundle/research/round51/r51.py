"""Round 51 (Stage 2): entry variants for the pre-FOMC lead (DECLARATION.md).

  python3 r51.py build    (2010-2015 and 2016-2021; marks itself, writes results_build.json)
  python3 r51.py freeze   (FROZEN.json from results_build.json; commit and push before judge)
  python3 r51.py judge    (C and T once)
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(REPO / "research/round47"))
sys.path.insert(0, str(REPO / "research/round49"))
import r47_engine as E  # noqa: E402
import r49_run as R49  # noqa: E402

BRANCH = "agent/round-45"
DECL_SHA = "f482f5101d9f4bd8b05d6b704d8f9091339fee2a0acacccb3cf6a831bf78a1eb"
NY = E.NY
PIP, SLIP, COST, LIMIT = E.PIP, E.SLIP, E.COST, 15 * 60
VARIANTS = ("E0", "T1", "T2", "T3", "T4", "L1", "L2", "D1", "D2", "V1", "V2")
PERIODS = {   # name: (first decision date, last date, world loader key)
    "y2010_15": (date(2010, 4, 1), date(2015, 12, 31)),
    "y2016_21": (date(2016, 1, 4), date(2021, 12, 31)),
    "C": (date(2022, 1, 3), date(2023, 11, 30)),
    "T": (date(2023, 12, 1), date(2025, 6, 27)),
}


def ny_ts(d: date, hhmm: str) -> int:
    h, m = map(int, hhmm.split(":"))
    return int(datetime.combine(d, time(h, m), NY).timestamp())


def prev_weekday(d: date, n: int = 1) -> date:
    x = d
    while n:
        x -= timedelta(days=1)
        if x.weekday() < 5:
            n -= 1
    return x


def statements(w: E.World, all_times: bool) -> list:
    """Scheduled, held FOMC statement times in the world's events (2016+: the 14:00 New York rows, as Round 47)."""
    out = []
    for ty, t in zip(w.events.type, w.events.ts):
        if ty != "FOMC_STATEMENT":
            continue
        lt = datetime.fromtimestamp(int(t), NY)
        if all_times or lt.strftime("%H:%M") == "14:00":
            out.append(int(t))
    return sorted(out)


def atr_simple(w: E.World, ts: int, n: int) -> float:
    k = w.day_k(ts)
    if k < n:
        return np.nan
    d = w.days.iloc[: k + 1]
    pc = d.c.shift(1)
    tr = np.maximum(d.h - d.l, np.maximum((d.h - pc).abs(), (d.l - pc).abs())).to_numpy()
    return float(tr[-n:].mean())


def bar_at(ts_arr, t):
    i = int(np.searchsorted(ts_arr, t, side="left"))
    return i if i < len(ts_arr) and ts_arr[i] < t + LIMIT else -1


def trade(w: E.World, v: str, S: int) -> dict | None:
    """One variant's trade for the statement at S (None: no trade)."""
    m, ts = w.m1, w.m1["ts_utc"]
    dS = datetime.fromtimestamp(S, NY).date()
    d1, d2 = prev_weekday(dS, 1), prev_weekday(dS, 2)
    t_e0 = ny_ts(d1, "14:00")
    t = {"E0": t_e0, "T1": ny_ts(d1, "08:00"), "T2": ny_ts(d1, "17:00"), "T3": ny_ts(dS, "03:00"), "T4": ny_ts(d2, "14:00"),
         "L1": t_e0, "L2": t_e0, "D1": t_e0, "D2": t_e0, "V1": t_e0, "V2": t_e0}[v]
    t_exit = S - 300
    if t >= t_exit or t_exit >= w.end_ts:
        return None
    if v in ("D1", "D2"):
        a, b = w.eur(t), w.eur(t - 86400)
        if not (np.isfinite(a) and np.isfinite(b)) or a == b or (v == "D1") != (a < b):
            return None
    if v in ("V1", "V2"):
        r = atr_simple(w, t, 20) / atr_simple(w, t, 100)
        if not np.isfinite(r) or (v == "V1") != (r >= 1.0):
            return None
    j = bar_at(ts, t_exit)
    if j < 0:
        return None
    if v in ("L1", "L2"):
        i0 = bar_at(ts, t)
        if i0 < 0:
            return None
        k = 0.15 if v == "L1" else 0.30
        a20 = atr_simple(w, t, 20)
        mid0 = w.eur(t)
        if not (np.isfinite(a20) and np.isfinite(mid0)):
            return None
        lim = mid0 - k * a20
        t_cancel = min(ny_ts(dS, "10:00"), t_exit)
        i1 = int(np.searchsorted(ts, t_cancel, side="left"))
        hits = np.nonzero(m["ask_l"][i0:i1] <= lim)[0]
        if not len(hits):
            return None
        i = i0 + int(hits[0])
        if i >= j:
            return None
        entry_ask = min(lim, m["ask_o"][i])                       # a gap below the limit fills at the open
        half = (m["ask_o"][i] - m["bid_o"][i]) / 2
        entry_mid, entry_bid = entry_ask - half, entry_ask - 2 * half
        long_entry, short_entry = entry_ask, entry_bid
    else:
        i = bar_at(ts, t)
        if i < 0 or i >= j:
            return None
        entry_mid = (m["bid_o"][i] + m["ask_o"][i]) / 2
        long_entry, short_entry = m["ask_o"][i] + SLIP, m["bid_o"][i] - SLIP
    exit_mid = (m["bid_o"][j] + m["ask_o"][j]) / 2
    move = (exit_mid - entry_mid) / PIP
    long_ba = ((m["bid_o"][j] - SLIP) - long_entry) / PIP
    short_ba = (short_entry - (m["ask_o"][j] + SLIP)) / PIP
    fin = E.r45.financing_pips(int(ts[i]), int(ts[j]), w.days)
    net_l = min(move - COST, long_ba) - fin
    net_s = min(-move - COST, short_ba) - fin
    return {"variant": v, "statement_ts": S, "date": str(d1), "entry_ts": int(ts[i]), "exit_ts": int(ts[j]),
            "move": move, "net": net_l, "net_short": net_s, "fin": fin, "net_ba": long_ba - fin}


def run_period(w: E.World, name: str, all_times: bool) -> pd.DataFrame:
    a, b = PERIODS[name]
    lo, hi = int(datetime.combine(a, time(0), timezone.utc).timestamp()), int(datetime.combine(b + timedelta(days=1), time(0), timezone.utc).timestamp())
    rows = []
    for S in statements(w, all_times):
        dS = datetime.fromtimestamp(S, NY).date()
        d1 = prev_weekday(dS, 1)
        if not (lo <= ny_ts(d1, "14:00") < hi):
            continue
        for v in VARIANTS:
            t = trade(w, v, S)
            if t:
                t["period"] = name
                rows.append(t)
    return pd.DataFrame(rows)


def stats(df: pd.DataFrame, seed: int) -> dict:
    out = {}
    for v in VARIANTS:
        d = df[df.variant == v] if len(df) else df
        if not len(d):
            out[v] = {"trades": 0, "total": 0.0}
            continue
        x = d.net.to_numpy()
        pick = np.random.default_rng(seed).integers(0, 2, (2000, len(d)))
        null = np.where(pick == 0, x, d.net_short.to_numpy()).mean(axis=1)
        out[v] = {"trades": int(len(d)), "total": float(x.sum()), "mean": float(x.mean()), "hit": float((x > 0).mean()),
                  "p": float((null >= x.mean() - 1e-12).mean()), "by_year": d.groupby(d.date.str[:4]).net.sum().round(1).to_dict()}
    return out


# ------------------------------------------------------------------ worlds

def world_2010_15() -> E.World:
    ev, _ = R49.calendar()
    return R49.load_world(ev)


def world_era(era: str) -> E.World:
    e = E.ERAS[era]
    start = int(datetime.combine(e["warm"], time(0), timezone.utc).timestamp())
    end = int(datetime(2022, 1, 1, tzinfo=timezone.utc).timestamp()) if era == "B" else e["end"]
    return E.World.load(end, start)


# ------------------------------------------------------------------ guards and looks

def git(*a):
    r = subprocess.run(["git", "-C", str(REPO), *a], capture_output=True, text=True)
    if r.returncode:
        raise SystemExit(f"git {' '.join(a)}: {r.stderr.strip()}")
    return r.stdout


def guards(step: str):
    if hashlib.sha256((HERE / "DECLARATION.md").read_bytes()).hexdigest() != DECL_SHA:
        raise SystemExit("DECLARATION.md changed")
    if git("status", "--porcelain", "--", "research/round51/r51.py", "research/round51/DECLARATION.md").strip():
        raise SystemExit("code not committed")
    git("fetch", "-q", "origin", BRANCH)
    if subprocess.run(["git", "-C", str(REPO), "merge-base", "--is-ancestor", "HEAD", f"origin/{BRANCH}"]).returncode:
        raise SystemExit("HEAD is not pushed")
    looks = (HERE / "LOOKS.jsonl").read_text().splitlines() if (HERE / "LOOKS.jsonl").exists() else []
    if any(json.loads(l)["step"] == step for l in looks if l.strip()):
        raise SystemExit(f"{step} was already run once")
    if step == "judge":
        if subprocess.run(["git", "-C", str(REPO), "cat-file", "-e", f"origin/{BRANCH}:research/round51/FROZEN.json"]).returncode:
            raise SystemExit("FROZEN.json must be pushed before the judge look")


def mark(step: str, status: str, extra=None):
    line = {"step": step, "status": status, "head": git("rev-parse", "HEAD").strip(),
            "utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), **(extra or {})}
    with open(HERE / "LOOKS.jsonl", "a") as f:
        f.write(json.dumps(line) + "\n")
    if status == "started":
        git("add", "research/round51/LOOKS.jsonl")
        git("commit", "-q", "-m", f"Round 51: {step} started (mark committed before data is read)")
        for _ in range(4):
            if subprocess.run(["git", "-C", str(REPO), "push", "-q", "origin", BRANCH]).returncode == 0:
                return
        raise SystemExit("mark not pushed; no data read")


def build():
    guards("build")
    mark("build", "started")
    a = run_period(world_2010_15(), "y2010_15", all_times=True)
    b = run_period(world_era("B"), "y2016_21", all_times=False)
    df = pd.concat([a, b])
    df.to_csv(HERE / "trades_build.csv.gz", index=False)
    res = {"all": stats(df, 5151), "y2010_15": stats(a, 5152), "y2016_21": stats(b, 5153)}
    (HERE / "results_build.json").write_text(json.dumps(res, indent=1))
    mark("build", "done")
    return res


def freeze():
    r = json.loads((HERE / "results_build.json").read_text())
    tot = {v: r["all"][v]["total"] for v in VARIANTS}
    best = max(tot, key=tot.get)
    keep = best
    if best != "E0" and not all(r[h][best]["total"] > r[h]["E0"]["total"] for h in ("y2010_15", "y2016_21")):
        keep = "E0"
    fz = {"best_by_total": best, "chosen": keep, "totals": tot, "rule": "DECLARATION section 4"}
    (HERE / "FROZEN.json").write_text(json.dumps(fz, indent=1))
    return fz


def judge():
    guards("judge")
    mark("judge", "started")
    fz = json.loads((HERE / "FROZEN.json").read_text())
    c = run_period(world_era("C"), "C", all_times=False)
    t = run_period(world_era("T"), "T", all_times=False)
    df = pd.concat([c, t])
    df.to_csv(HERE / "trades_judge.csv.gz", index=False)
    sc, st, sct = stats(c, 5154), stats(t, 5155), stats(df, 5156)
    ch = fz["chosen"]
    kept = sc[ch].get("mean", -1) > 0 and st[ch].get("mean", -1) > 0 and sct[ch]["total"] >= sct["E0"]["total"]
    res = {"C": sc, "T": st, "CT": sct, "chosen": ch, "kept": kept}
    (HERE / "results_judge.json").write_text(json.dumps(res, indent=1))
    mark("judge", "done")
    return res


if __name__ == "__main__":
    step = sys.argv[1]
    out = {"build": build, "freeze": freeze, "judge": judge}[step]()
    print(json.dumps(out, indent=1, default=float)[:6000])
