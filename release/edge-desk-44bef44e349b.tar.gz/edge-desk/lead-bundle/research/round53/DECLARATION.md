# Round 53: Stages 3 and 4, the stop and the target for the pre-FOMC lead

Declared by the second agent on 12 Oct 2026, before any result of these variants exists. The sha256 is in DECLARATION.sha256, and the time comes from the commit. A later change is a numbered amendment, made before the look.

## 1. Why

- Round 51 kept the plain entry, E0: buy EUR/USD at 14:00 New York on the weekday before a scheduled FOMC statement, out 5 minutes before the statement.
- Stage 3 chooses its stop, with the entry and the time exit fixed.
- Stage 4 then chooses its target, with that stop fixed.
- Both are chosen on the build years. The final combination is judged once on C+T.
- Decided as the owner (CLAUDE.md, 12 Oct about 11:16).

## 2. Stage 3: stop variants (6)

Each sits below the entry fill. There is no target; the time exit is 5 minutes before the statement.

| id | Stop distance |
|---|---|
| S1 | 0.25 x ATR20 |
| S2 | 0.50 x ATR20 |
| S3 | 1.00 x ATR20 |
| S4 | below the last completed New York day's low, minus 2 pips (at least 10 pips from the entry) |
| S5 | 20 pips |
| S6 | 30 pips |

ATR20 is the simple mean of the last 20 completed New York days' true ranges (Round 51's atr_simple).

**Fills:**
- the stop is hit when the bid low reaches it, and fills at the lower of the stop and that bar's bid open, minus 0.2 pip;
- a target is hit when the bid high reaches it, and fills at the target;
- if both happen in one bar, the stop counts;
- time exit: sell at the bid minus 0.2 pip at the first bar at or after statement - 5 minutes (within 15 minutes).

**R** = the stop distance in pips from the entry fill. Per trade:
- R_20 = min(R_mid - 2.0 / R pips, R_ba) - financing / R pips;
- financing is 1 pip a night, and 3 for a Wednesday.

**Choice:** the stop with the highest total R_20 over the build era. It also needs mean R_20 > 0 on both build halves (2010-2015 and 2016-2021). If none qualifies, Stage 3 keeps S6 (30 pips, the owner's stated comfort), and this is reported.

## 3. Stage 4: target variants (6, with the chosen stop)

| id | Target |
|---|---|
| X0 | none (time exit only) |
| X1 | 1R |
| X2 | 1.5R |
| X3 | 2R |
| X4 | 3R (the owner's default) |
| X5 | none, but the stop moves to the entry once price reaches +1R (on the bid) |

**Choice:** the highest total R_20 over the build era, with mean R_20 > 0 on both build halves. Otherwise X0.

## 4. Eras and look order

Build = 2010-04-01 to 2021-12-31. Judge = C (2022-01-03 to 2023-11-30) and T (2023-12-01 to 2025-06-27). Data and statements are as in Round 51.

Order:
1. Build: all stops, then all targets on every stop. The target is chosen only on the chosen stop.
2. FROZEN.json committed and pushed.
3. Judge: the frozen stop and target, once, on C+T.

## 5. Verdict (fixed now)

**Kept** as the full trade: mean R_20 > 0 on C and on T. Also reported:
- R a trade and R a year;
- the hit rate;
- the random-side p on C+T;
- a $15,000 account example at 1% risk (an example scale only, not a risk rule).

A kept trade goes to the owner as a component for paper trading, and to the locked final test when enough FOMC events exist. It is NOT an edge at his targets (about 8 trades a year).

## 6. Never

Validation, the holdout, the main agent's running rounds. No order code, no secrets, no risk-size rules.
