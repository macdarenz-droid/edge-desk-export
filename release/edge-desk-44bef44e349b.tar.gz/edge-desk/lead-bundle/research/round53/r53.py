"""Round 53 (Stages 3-4): stop then target for the pre-FOMC lead E0 (DECLARATION.md).

  python3 r53.py build | freeze | judge
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(REPO / "research/round51"))
import r51  # noqa: E402

E = r51.E
BRANCH = "agent/round-45"
DECL_SHA = "034208dc4299fbd8caa336bbf365fe33c4b388341c2bb4f980b7f210b19ae9ce"
PIP, SLIP, COST = E.PIP, E.SLIP, E.COST
STOPS = ("S1", "S2", "S3", "S4", "S5", "S6")
TARGETS = ("X0", "X1", "X2", "X3", "X4", "X5")


def stop_px(w, v: str, t: int, entry: float) -> float | None:
    a20 = r51.atr_simple(w, t, 20)
    if v in ("S1", "S2", "S3"):
        if not np.isfinite(a20):
            return None
        return entry - {"S1": 0.25, "S2": 0.5, "S3": 1.0}[v] * a20
    if v == "S4":
        k = w.day_k(t)
        if k < 0:
            return None
        s = float(w.days.l.iloc[k]) - 2 * PIP
        return min(s, entry - 10 * PIP)
    return entry - {"S5": 20, "S6": 30}[v] * PIP


def trade(w, S: int, stop_v: str, tgt_v: str) -> dict | None:
    """E0 entry and time exit (Round 51), with a stop and a target; long only."""
    m, ts = w.m1, w.m1["ts_utc"]
    dS = datetime.fromtimestamp(S, r51.NY).date()
    d1 = r51.prev_weekday(dS, 1)
    t = r51.ny_ts(d1, "14:00")
    t_exit = S - 300
    if t >= t_exit or t_exit >= w.end_ts:
        return None
    i, j = r51.bar_at(ts, t), r51.bar_at(ts, t_exit)
    if i < 0 or j < 0 or i >= j:
        return None
    entry = m["ask_o"][i] + SLIP
    entry_mid = (m["bid_o"][i] + m["ask_o"][i]) / 2
    sp = stop_px(w, stop_v, t, entry)
    if sp is None or sp >= entry:
        return None
    r_px = entry - sp
    tgt = None if tgt_v in ("X0", "X5") else entry + {"X1": 1.0, "X2": 1.5, "X3": 2.0, "X4": 3.0}[tgt_v] * r_px
    lo, hi, op = m["bid_l"][i:j], m["bid_h"][i:j], m["bid_o"][i:j]
    mid_o = (m["bid_o"][i:j] + m["ask_o"][i:j]) / 2
    stop = np.full(j - i, sp)
    if tgt_v == "X5":                                              # stop to entry once the bid reaches +1R
        reached = np.maximum.accumulate(hi) >= entry + r_px
        prev = np.r_[False, reached[:-1]]                         # from the bar after the one that reached it
        stop = np.where(prev, np.maximum(sp, entry), sp)
    hit_s = lo <= stop
    hit_t = hi >= tgt if tgt is not None else np.zeros(j - i, bool)
    any_hit = hit_s | hit_t
    if any_hit.any():
        k = int(np.argmax(any_hit))
        if hit_s[k]:
            fill, midf, why = min(stop[k], op[k]) - SLIP, min(stop[k], mid_o[k]), "stop" if stop[k] == sp else "breakeven"
        else:
            fill, midf, why = tgt, tgt, "target"
        jj = i + k
    else:
        jj = j
        fill, midf, why = m["bid_o"][j] - SLIP, (m["bid_o"][j] + m["ask_o"][j]) / 2, "time"
    r_pips = r_px / PIP
    R_ba = (fill - entry) / r_px
    R_mid = (midf - entry_mid) / r_px
    fin = E.r45.financing_pips(int(ts[i]), int(ts[jj]), w.days)
    R20 = min(R_mid - COST / r_pips, R_ba) - fin / r_pips
    # mirrored side for a random-side check: a short with the same distances, judged on the same bars
    s_entry = m["bid_o"][i] - SLIP
    s_stop = s_entry + r_px
    s_tgt = None if tgt is None else s_entry - (tgt - entry)
    lo_s, hi_s, op_s = m["ask_h"][i:j], m["ask_l"][i:j], m["ask_o"][i:j]
    s_stop_arr = np.full(j - i, s_stop)
    if tgt_v == "X5":
        reached_s = np.minimum.accumulate(hi_s) <= s_entry - r_px
        s_stop_arr = np.where(np.r_[False, reached_s[:-1]], np.minimum(s_stop, s_entry), s_stop)
    hs = lo_s >= s_stop_arr
    ht = hi_s <= s_tgt if s_tgt is not None else np.zeros(j - i, bool)
    ah = hs | ht
    if ah.any():
        k2 = int(np.argmax(ah))
        if hs[k2]:
            sf, smid = max(s_stop_arr[k2], op_s[k2]) + SLIP, max(s_stop_arr[k2], mid_o[k2])
        else:
            sf, smid = s_tgt, s_tgt
        jj2 = i + k2
    else:
        jj2 = j
        sf, smid = m["ask_o"][j] + SLIP, (m["bid_o"][j] + m["ask_o"][j]) / 2
    fin2 = E.r45.financing_pips(int(ts[i]), int(ts[jj2]), w.days)
    R20s = min((entry_mid - smid) / r_px - COST / r_pips, (s_entry - sf) / r_px) - fin2 / r_pips
    return {"date": str(d1), "stop_v": stop_v, "tgt_v": tgt_v, "r_pips": r_pips, "why": why, "R_ba": R_ba,
            "R_20": R20, "R_20_short": R20s, "entry_ts": int(ts[i]), "exit_ts": int(ts[jj])}


def run(w, name, combos) -> pd.DataFrame:
    a, b = r51.PERIODS[name]
    lo = int(datetime.combine(a, time(0), timezone.utc).timestamp())
    hi = int(datetime.combine(b + timedelta(days=1), time(0), timezone.utc).timestamp())
    rows = []
    for S in r51.statements(w, all_times=(name == "y2010_15")):
        d1 = r51.prev_weekday(datetime.fromtimestamp(S, r51.NY).date(), 1)
        if not (lo <= r51.ny_ts(d1, "14:00") < hi):
            continue
        for sv, tv in combos:
            x = trade(w, S, sv, tv)
            if x:
                x["period"] = name
                rows.append(x)
    return pd.DataFrame(rows)


def summ(d: pd.DataFrame, seed: int) -> dict:
    if not len(d):
        return {"trades": 0, "total": 0.0}
    x = d.R_20.to_numpy()
    pick = np.random.default_rng(seed).integers(0, 2, (2000, len(d)))
    null = np.where(pick == 0, x, d.R_20_short.to_numpy()).mean(axis=1)
    return {"trades": int(len(d)), "total": float(x.sum()), "mean": float(x.mean()), "hit": float((x > 0).mean()),
            "mean_r_pips": float(d.r_pips.mean()), "p": float((null >= x.mean() - 1e-12).mean()),
            "exits": d.why.value_counts().to_dict()}


def git(*a):
    r = subprocess.run(["git", "-C", str(REPO), *a], capture_output=True, text=True)
    if r.returncode:
        raise SystemExit(f"git {' '.join(a)}: {r.stderr.strip()}")
    return r.stdout


def guards(step):
    if hashlib.sha256((HERE / "DECLARATION.md").read_bytes()).hexdigest() != DECL_SHA:
        raise SystemExit("DECLARATION.md changed")
    if git("status", "--porcelain", "--", "research/round53/r53.py", "research/round51/r51.py").strip():
        raise SystemExit("code not committed")
    git("fetch", "-q", "origin", BRANCH)
    if subprocess.run(["git", "-C", str(REPO), "merge-base", "--is-ancestor", "HEAD", f"origin/{BRANCH}"]).returncode:
        raise SystemExit("HEAD is not pushed")
    looks = (HERE / "LOOKS.jsonl").read_text().splitlines() if (HERE / "LOOKS.jsonl").exists() else []
    if any(json.loads(l)["step"] == step for l in looks if l.strip()):
        raise SystemExit(f"{step} was already run once")
    if step == "judge" and subprocess.run(["git", "-C", str(REPO), "cat-file", "-e", f"origin/{BRANCH}:research/round53/FROZEN.json"]).returncode:
        raise SystemExit("FROZEN.json must be pushed before the judge look")


def mark(step, status):
    with open(HERE / "LOOKS.jsonl", "a") as f:
        f.write(json.dumps({"step": step, "status": status, "head": git("rev-parse", "HEAD").strip(),
                            "utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}) + "\n")
    if status == "started":
        git("add", "research/round53/LOOKS.jsonl")
        git("commit", "-q", "-m", f"Round 53: {step} started (mark committed before data is read)")
        for _ in range(4):
            if subprocess.run(["git", "-C", str(REPO), "push", "-q", "origin", BRANCH]).returncode == 0:
                return
        raise SystemExit("mark not pushed; no data read")


def build():
    guards("build")
    mark("build", "started")
    combos = [(s, t) for s in STOPS for t in TARGETS]
    a = run(r51.world_2010_15(), "y2010_15", combos)
    b = run(r51.world_era("B"), "y2016_21", combos)
    df = pd.concat([a, b])
    df.to_csv(HERE / "trades_build.csv.gz", index=False)
    res = {}
    for sv, tv in combos:
        key = f"{sv}_{tv}"
        res[key] = {h: summ(d[(d.stop_v == sv) & (d.tgt_v == tv)], 5353) for h, d in (("all", df), ("y2010_15", a), ("y2016_21", b))}
    (HERE / "results_build.json").write_text(json.dumps(res, indent=1))
    mark("build", "done")
    return res


def freeze():
    r = json.loads((HERE / "results_build.json").read_text())

    def ok(k):
        return all(r[k][h].get("mean", -1) > 0 for h in ("y2010_15", "y2016_21"))
    stop_cands = [s for s in STOPS if ok(f"{s}_X0")]
    stop = max(stop_cands, key=lambda s: r[f"{s}_X0"]["all"]["total"]) if stop_cands else "S6"
    tgt_cands = [t for t in TARGETS if ok(f"{stop}_{t}")]
    tgt = max(tgt_cands, key=lambda t: r[f"{stop}_{t}"]["all"]["total"]) if tgt_cands else "X0"
    fz = {"stop": stop, "target": tgt, "stop_qualified": bool(stop_cands), "target_qualified": bool(tgt_cands),
          "stop_totals": {s: r[f"{s}_X0"]["all"]["total"] for s in STOPS},
          "target_totals": {t: r[f"{stop}_{t}"]["all"]["total"] for t in TARGETS}, "rule": "DECLARATION sections 2-3"}
    (HERE / "FROZEN.json").write_text(json.dumps(fz, indent=1))
    return fz


def judge():
    guards("judge")
    mark("judge", "started")
    fz = json.loads((HERE / "FROZEN.json").read_text())
    combo = [(fz["stop"], fz["target"])]
    c = run(r51.world_era("C"), "C", combo)
    t = run(r51.world_era("T"), "T", combo)
    df = pd.concat([c, t])
    df.to_csv(HERE / "trades_judge.csv.gz", index=False)
    sc, st, sct = summ(c, 5354), summ(t, 5355), summ(df, 5356)
    kept = sc.get("mean", -1) > 0 and st.get("mean", -1) > 0
    res = {"combo": combo[0], "C": sc, "T": st, "CT": sct, "kept": kept,
           "R_year_CT": sct["total"] / (42 / 12), "usd_year_15k_1pct": sct["total"] / (42 / 12) * 150}
    (HERE / "results_judge.json").write_text(json.dumps(res, indent=1))
    mark("judge", "done")
    return res


if __name__ == "__main__":
    out = {"build": build, "freeze": freeze, "judge": judge}[sys.argv[1]]()
    if sys.argv[1] != "build":
        print(json.dumps(out, indent=1, default=float))
