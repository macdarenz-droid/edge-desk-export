# Round 55: wider event census

Declared by the second agent on 12 Oct 2026, before any EUR/USD result of these cells exists. The sha256 is in DECLARATION.sha256, and the time comes from the commit. A later change is a numbered amendment in AMENDMENTS.md, made before the look it affects.

## 1. Why

**The owner's ask** (12 Oct, about 11:25 Melbourne, after Round 53): "Does that mean even we find the edge, we cant  trade daily? Or later on we can find an edge too to increase our trades? I dont want to stop here yet. If i will mot be having a trade atleast 3-5x a week".

Read as (CLAUDE.md "More trades, keep going"):
- the search goes on;
- the target is at least 3-5 trades a week on EUR/USD;
- small edges that each pass the checks may be stacked into one book.

**What is known.**
- Round 47: PA-F1 (long before the FOMC statement) and PA-F4 (long before the ECB decision) were "promising". Both were positive on C and T; pooled C+T random-side p 0.0985 and 0.062.
- Round 49 (2010-2015): PA-F1 +7.2 pips a trade (46 trades, p 0.10); PA-F4 flat (+0.1 pips, 65 trades).
- Round 53 kept PA-F1 with a 1 x ATR20 stop and a 2R target: about +1R a year.
- Each lead gives about 8 trades a year.

**This round** asks whether the same pre-event premium shows before other scheduled events, which would add trades. It adds one non-event family (the FOMC cycle) and one diagnostic of the leads.

**Design.** Three designs, one critic and one synthesis, kept in DESIGN_INPUTS.json. The critic's kills and fixes are applied here. The cells, their exact rules and their flags are in CELLS.json (sha256 in CELLS.sha256). Where this file and CELLS.json differ, this file wins.

## 2. Batches and gate

Fixed by the lead agent before this declaration.

**Batch A**, 15 cells, no new calendar:
- REF-F1, REF-F4 (anchors);
- PB-USALL, its members PB-NFP, PB-CPI, PB-MIN, PB-GDP, and its control PB-USALL-P;
- PB-SAME and PB-SAME-P;
- XC-DOLX;
- FC-1 and FC-1C;
- ST-A and ST-A-P.

**Batch B**, 18 cells that need a calendar:
- PB-USALL-1014;
- PB-USX, its members PB-RS, PB-PPI, PB-PCE, PB-ISM, and PB-USX-P;
- PB-EZ, its members PB-EZHICP, PB-ECBACC, and PB-EZ-P;
- PB-OCB and PB-OCB-P;
- TA-1, TA-1-P, TA-2, TA-2-P;
- ST-B.

**Gate**, fixed now:
- PB-USALL-1014, the PB-USX, PB-EZ and PB-OCB pools, their members and their controls are built and run only if PB-USALL is eligible on B (section 7).
- TA-1, TA-1-P, TA-2 and TA-2-P are built and run after batch A, whatever it finds.
- ST-B is reported only if a batch-B cell runs.
- A gated-out cell is listed as "not run".

**Calendars.** Each batch-B calendar comes from official publisher sources only (the agency, bank or Treasury that issues the release), built without reading any price. Its sources, file, sha256, dropped rows and leak-guard evidence are fixed in a numbered amendment, committed before that cell's first look and before the A-C look (section 10, step 4). Any fetch keeps to at most 50% of the documented rate limit and stops after 3 failures.

## 3. Conventions

Binding for every cell.

**Code and data.**
- Engine: research/round47/r47_engine.py (sha256 4d1c0a97300b2ab91e9683fd3941b90493ada16fa5098654194a24650788b4e0), `run_cell` and `summarize`, unchanged.
- Event file: research/round17/data/events.csv (sha256 ee2c318882e97c60d3d43ac95248571a9d59ba4cb99b0ddfa5e47283d4f86c22). Times come from its utc column, never from a constant.
- London business days: research/round47/r47_cal.py (sha256 0333645a530503432a6f31ba6ca4549f36661016a7f369bb2a49e5ae8a402b2b).

**Fills.**
- Entry at the first 1-min bar opening at or after the decision time; exit at the first 1-min bar opening at or after the exit time.
- Each bar must open within 15 minutes of its time, else there is no trade (Round 47 amendment A2). No fallback to another day.
- A buy fills at the ask plus 0.2 pip, a sell at the bid minus 0.2 pip.

**Net pips**, per trade, with the cell's side:
- net = min(side x mid move - 2.0, the bid/ask result with 0.2 pip slippage on each fill), minus financing;
- financing: 1 pip for each 17:00 New York close held, 3 for a Wednesday close (Round 45's rule);
- the same at 1.6 pips is also reported.

**Positions.** One position at a time per cell. A decision before the open trade's exit is skipped; one at the exit minute may trade (t < busy_until, Round 47 A2).

**Days.**
- "Weekday" counting is Monday-Friday. Holidays are not skipped (as Round 47's PA-F1 and the FOMC-cycle paper).
- The New York date of an event is the date of its utc in New York. A row with an empty utc uses its local_date as its New York date. The only such row is ECB_OTHER-2020-03-18 (2020-03-18; checked in the file).
- A trade belongs to the era of its decision date.

**Era ends** (Round 47's code, stated so no later price is read):
- Each look loads `World.load(ERAS[era]["end"], start)`, with start = 00:00 UTC of the era's warm-up date, exactly as Round 47's runner did.
- `run_cell` drops a trade whose exit time is at or after its era's end, so no trade reads a later era's price.
- Calendar check (events.csv only): two FC-1 trades are lost this way, entry 27 Dec 2021 (exit 3 Jan 2022) and entry 27 Nov 2023 (exit 4 Dec 2023). No PB-USALL, PB-SAME or FC-1C trade crosses an era end.
- A test asserts, for every look, that the world's largest bar timestamp is below its era's end (as Round 47's runner asserts).

**Readings of the design** (where this file departs from the design's words):
- **D-1.** The design says "the previous engine trading day with data". It is read as the previous weekday, with no fallback to an earlier day when data are missing. This is Round 47's code for PA-F1 (`ev_index`: `fomc_prev = add_weekdays(dn, -1)`) and the conservative reading; a missing bar means no trade (A2).
- **E.** The design says "the engine day (17:00-17:00 New York) containing the event utc". For every kept row (all at 08:30 or 14:00 New York) that is the New York date.
- **TA-1 and TA-2 sit in ST-B, not ST-A.** They need a calendar. ST-A is built after batch A from file-only pieces.
- **GBP/USD in XC-DOLX.** The design asked to check GBP/USD 1-minute coverage for Dec 2023 - Jun 2025 and use the cross only if it is missing. It is fixed now as the cross EUR/USD / EUR_GBP in every era, as Round 47's DF-O1 code (research/round47/cells/fam_rates_cross.py). One definition holds in all eras, and no new price file is read.

**Windows.**
- A window is [decision time, exit time) in scheduled clock time, taken from the calendar, not from fills.
- Two windows overlap when each starts before the other ends. Touching ends do not overlap.
- "Skip, never truncate": an overlapping trade is dropped whole.

**No-event days.** A control's no-event test counts every events.csv row, of any type and any status, including rows dropped by the leak guard.

**Eras** (Round 47's, so the anchors' parity holds):

| Era | Decisions | Warm-up (prices only) |
|---|---|---|
| B | 2016-03-01 to 2021-12-31 | from 2016-01-03 |
| C | 2022-01-03 to 2023-11-30 | from 2020-11-01 |
| T | 2023-12-01 to 2025-06-27; nothing at or after 1751317200 | from 2022-11-01 |

**Placebo weighting** (weekday-matched), for every cell-against-control comparison:
- Each control rule names its strata g. The default is the weekday of the decision date. Some add the exit clock.
- In era e, n(g) = the tested cell's trades in stratum g; m(g) = the control's mean net (2.0 pips) over all its trades in stratum g in era e.
- Weighted control mean = sum of n(g) x m(g) / sum of n(g).
- A stratum of the cell with no control trade is left out on both sides. The cell's compared mean is then taken without those trades, and how many were left out is reported.
- "Beats its control" = the cell's compared mean net is higher than the weighted control mean.
- No random draw is used here, so no seed is needed. ST-A-P's draw has its own seed (section 9).

**Event-premium test** (report-only, never deciding; section 7 explains why it is added):
- For each cell with a control: on B, and on pooled C+T for every cell judged on C and T.
- Strata h = (era, the control's stratum g). w_h = n_cell(h) / N, over the strata kept under the rules above.
- Statistic S = sum over h of w_h x (the cell's mean net in h - the control's mean net in h). On one era this is exactly the cell's compared mean minus the weighted control mean.
- Null: within each stratum h, the cell's and the control's trades are pooled, and n_cell(h) of them are drawn without replacement as the "cell" trades. The two sets never share a window, because each control excludes its cell's windows.
- p = (k + 1) / (n + 1), where k counts permuted S ≥ the observed S - 1e-12; n = 100,000, in 10 chunks of 10,000 from one generator, numpy default_rng(55057) on B and default_rng(55058) on C+T.
- Reported beside every verdict. Not in BH.

**R unit** (report-only, for the owner):
- R = ATR20 at the decision: the simple mean of the true ranges of the last 20 New York days completed by the decision, in pips (Round 51's `atr_simple`, research/round51/r51.py, sha256 91b45497b9c1d5be936cf9cacebdaf60d89663fa18ccd5c32f5d02ae5a1a770c). 1 x ATR20 is the stop Round 53 kept.
- R a trade = net pips / R pips. R a month = the sum of R / months in the era.
- No stop is simulated. With a real stop the result would differ.
- A dollar example is shown next to R: a $15,000 account at 1% risk per R. This is an example scale only, never a risk rule.

**Leak tests.** XC-DOLX is the only cell whose side reads prices. Its side computed on `World.cut(decision)` must equal its side on the full world. Every event cell must also pass the calendar leak guard (section 4).

**Data stop.** Nothing at or after 1751317200 is ever read.

## 4. Leak guard

US_NFP, US_CPI and US_GDP rows in events.csv are ALFRED vintage dates (the actual release dates), not agency calendars. A D-1 rule is causal only if the date was public before the decision. The checkable rule is applied in order.

**L0.** Keep rows with scheduled == 1 and status == "held".
- Dropped: US_NFP-2025-10-03 (status "not released (no vintage that month)").

**L1. Candidates.** A row is a moved-date candidate if its local date falls in a lapse window for its agency (BLS: NFP and CPI; BEA: GDP). A lapse window runs from the first day of a US federal funding lapse that closed the agency to 60 calendar days after the lapse ended:
- W1: 2018-01-20 to 2018-03-23 (lapse of 20-22 Jan 2018; BLS and BEA). The lapse dates are recalled, not verified here. The window is generous either way, and its 6 dropped rows are a conservative choice.
- W2: 2018-12-22 to 2019-03-26 (lapse of 22 Dec 2018 to 25 Jan 2019; BEA only). BLS was funded: "The Bureau of Labor Statistics (BLS) was funded during the shutdown period and was operating as usual." (https://www.bls.gov/news.release/archives/empsit_02012019.htm, read 12 Oct 2026).
- W3: 2025-10-01 to the end of events.csv (2025-12-30), for the autumn 2025 lapse (BLS and BEA). The rule's own end, 60 days after the lapse ended, falls after the file's end if the lapse ended after 31 Oct 2025 (its end is recalled as 12 Nov 2025, not verified). Every row in W3 is after the price cut, so W3 changes no result.

FOMC_MINUTES rows come from the Fed's own "Released <date>" pages. The Fed was not closed by these lapses. They are not candidates.

**L2. Evidence.** A candidate is kept only if an official agency notice shows either:
- that it came out on its originally scheduled date; or
- that its new date was published on a calendar date before D-1.

Otherwise it is dropped.

**Result** (checked by code against the file; 12 candidates):
- Kept: US_GDP-2019-02-28. BEA's blog of 6 Feb 2019 says "A report called Initial Gross Domestic Product for the 4th Quarter and Annual 2018 will be released on Feb. 28 at 8:30 a.m." (https://www.bea.gov/news/blog/2019-02-06/new-dates-set-gdp-personal-income-and-international-trade). Its D-1 is 27 Feb 2019.
- Dropped, W1, no notice verified: US_GDP-2018-01-26, US_NFP-2018-02-02, US_CPI-2018-02-14, US_GDP-2018-02-28, US_NFP-2018-03-09, US_CPI-2018-03-13.
- Dropped, W3, after the price cut anyway: US_CPI-2025-10-24, US_NFP-2025-11-20, US_NFP-2025-12-16, US_CPI-2025-12-18, US_GDP-2025-12-23.
- So 12 rows are dropped in all (L0 plus 11).

**Noted, not candidates:**
- US_GDP-2019-03-28 is outside W2. BEA's blog of 22 Mar 2019 also says "It is being released on its originally scheduled date" (https://www.bea.gov/news/blog/2019-03-22/gdp-back-schedule-third-estimate).
- 22 held NFP rows differ from the file's "first-Friday rule" (source_note "DIFFERS"). That rule is a heuristic, not BLS's schedule. Three of them sit in lapse windows and are dropped above (US_NFP-2018-03-09, US_NFP-2025-11-20, US_NFP-2025-12-16). The other 19 are outside every lapse window; their dates are taken to follow BLS's annual schedule, which is published ahead of each year (not re-verified here year by year).

**After the guard:** 467 rows of the four types remain in 2015-2025 (127 NFP, 127 CPI, 126 GDP, 87 minutes).

**Residual risk.** The guard catches moves caused by funding lapses only. A short-notice move for another reason would not be caught. None is known to the designers for 2016 - Jun 2025, but the rows were not checked one by one against agency calendars.

Batch-B calendars use the same rule, with their own lapse windows: the 1-16 Oct 2013 lapse for PB-USALL-1014. Their amendment states the evidence.

## 5. The cells

Exact rule text is in CELLS.json. In short:

### Anchors

- **REF-F1**: Round 47's PA-F1, unchanged code (research/round47/cells/fam_events.py, sha256 8c2d2211dac94c4105c62a2a0a87ef5431271c2455586c93bc9cc1ededac4614), on Round 47's World and eras. Long EUR/USD at 14:00 New York on the weekday before a scheduled FOMC statement. Out 5 minutes before the statement.
- **REF-F4**: Round 47's PA-F4, unchanged. Long at 12:00 London on the London business day before an ECB decision. Out 5 minutes before the decision.
- Not new tests. Their verdicts stay Round 47's ("promising"). They are the first two members of every stack.
- **Parity check:** their B, C and T trades must equal the PA-F1 and PA-F4 rows of research/round47/results/trades_B.csv.gz, trades_C.csv.gz and trades_T.csv.gz (same date, side, entry and exit time; net and net16 within 1e-9 pips). If parity fails, no Round 55 result is read until an amendment explains and fixes it.

### PB: US file events

- **PB-USALL** (selectable, the primary cell). Events: kept US_NFP, US_CPI, US_GDP and FOMC_MINUTES rows (section 4).
  - E = the event's New York date. D-1 = the weekday before E.
  - All kept rows with the same E form one trade.
  - Long EUR/USD at 14:00 New York on D-1. Out at the earliest event time of E minus 5 minutes (08:25 New York; 13:55 New York on a minutes-only day).
  - Skip any window that overlaps a REF-F1 or REF-F4 window.
  - Must beat PB-USALL-P.
- **Members** PB-NFP, PB-CPI, PB-MIN, PB-GDP (report-only):
  - PB-USALL's rule applied to one event type only, with its own exits and skips.
  - They run on C and T only if PB-USALL is eligible on B.
  - The design's expectation "PB-GDP should have the smallest mean" is dropped: it runs against Hu et al.'s equity table (section 11).
  - Equity analogue, stated before any look and report-only: Hu et al.'s Table 1 has pre-release means of NFP +10.10 bps (t 3.63), GDP +7.46 (t 2.08) and CPI -2.14 (t -0.69); FOMC minutes are not in their table. If that pattern carried to EUR/USD, PB-NFP and PB-GDP would sit above PB-CPI. It is reported beside the members and never used to choose.
  - The design's condition ("selectable only if PB-USALL passes and it beats PB-USALL-P on its own entry weekday") is reported as a flag only. No member is selected in this round.
- **PB-SAME** (selectable, a minority alternative). Kept NFP, CPI and GDP rows.
  - Long at 07:00 London local on the release day (02:00 New York, or 03:00 in DST-mismatch weeks). Out 5 minutes before the release. No night held.
  - Same REF overlap skip.
  - Must beat PB-SAME-P.
  - Never added to PB-USALL. In a stack it replaces PB-USALL only if PB-SAME is "promising" or "confirmed" and PB-USALL is not.

### XC: diagnostic

- **XC-DOLX** (report-only). REF-F1's and REF-F4's windows exactly, but the side comes from the dollar's 5-weekday move to the decision time.
  - DOL5 = the mean of +USD/JPY, +USD/CHF, +USD/CAD, -AUD/USD and -GBP/USD log returns.
  - GBP/USD = EUR/USD / EUR_GBP, as Round 47's DF-O1 code did (fixed now).
  - DOL5 > 0: long; < 0: short; 0 or a missing leg: no trade.
  - Reading fixed now: XC-DOLX differs from the anchors only on windows where DOL5 < 0, about half of roughly 56 C+T windows, so a point comparison on so few trades is mostly noise. If, on the windows where both XC-DOLX and an anchor traded, pooled over C and T, XC-DOLX's mean net a trade is above the anchors', that can only motivate a later declared test of two-sided event cells. It cannot show that squaring is the better story, and the opposite result does not show the long premium is real.
  - Never added to a stack.

### FC: FOMC cycle

- **FC-1** (selectable; power flag). Day 0 = the New York date of a scheduled, held FOMC statement. Days count weekdays.
  - Week k = days 5k-1 to 5k+3, the paper's definition (section 11).
  - **Cycle boundary, the paper's.** A day at -6 or closer (in weekdays) to the next scheduled, held statement belongs to the next cycle (its week -1 or week 0), never to a forward week of this one. Day -7 = 7 weekdays before the next statement's New York date.
  - For weeks 2, 4 and 6: long at 16:00 London on day 5k-2 (days 8, 18, 28), only if that entry day is before day -7 of the next statement.
  - Out at 16:00 London on the earlier of day 5k+3 (days 13, 23, 33) and day -7 of the next statement.
  - So the trade holds only days of its own week, and of no later cycle. A 35-weekday cycle (29 of the 86 cycles in events.csv) has no week-6 trade, because its days 29-33 are the next cycle's week -1.
  - Week 0 (days -1 to 3), the paper's strongest even week, is left out on purpose: REF-F1 and the statement sit in it.
  - About 5 nights held: about 7 pips of financing plus the 2.0 spread (approximate).
  - Must beat FC-1C. Lowest priority in any stack.
- **FC-1C** (control): the same with weeks 1, 3 and 5 (in on days 3, 13, 23; out on days 8, 18, 28), with the same cycle boundary. Week -1 belongs to no FC cell.
- **Counts** (events.csv only, before data gaps and the fill rule): FC-1 97 on B (3 shortened by day -7), 33 on C, 25 on T. Two of those cross an era end and are not taken (section 3), so 96, 32 and 25. FC-1C 112, 37 and 32. FC-1 keeps 30+ trades on B.

### ST: stacks

ST-A and ST-A-P are described in section 9.

### Batch B

- **PB-USALL-1014** (report-only check): PB-USALL unchanged on Round 49's era X (decisions 2010-04-01 to 2015-12-31).
  - It uses the 2010-2015 price file Round 49 already holds. No new price download.
  - Events 2010-2014 come from BLS, BEA and federalreserve.gov archives. 2015 comes from events.csv.
  - Run once, after PB-USALL's verdict. Never used to choose.
  - If an agency archive cannot be read, it is not run.
  - Why 2010-2015 may be used: CLAUDE.md "Newbie journey" (owner, 11 Oct about 19:44 Melbourne) says CONFIRM-2 (2010-2015) "stops being a locked confirmation set (it was optional under S10)"; the HANDOFF data table says "optional under S10 (older years no longer veto); if used, one declared batch (S5-c)". No price download is needed, and a calendar fetch is not a price fetch.
  - Round 49 and the newbies have already read 2010-2015 in full, so this is a report-only consistency check on years already read, not fresh evidence. Its amendment cites these two lines.
- **PB-USX** (selectable pool): advance retail sales, PPI final demand, personal income and outlays, ISM Manufacturing.
  - Long 14:00 New York on D-1. Out 5 minutes before the release (09:55 New York for ISM).
  - A release at the same time as a kept PB-USALL row is dropped.
  - Skip on overlap with REF and PB-USALL windows.
  - ISM's fallback rule is only used if it matches archived notices over 2 or more years.
  - Members PB-RS, PB-PPI, PB-PCE, PB-ISM are report-only. Control PB-USX-P.
- **PB-EZ** (selectable pool): Eurostat flash HICP and ECB accounts.
  - Long 12:00 London on the London business day before. Out 5 minutes before the release.
  - Members PB-EZHICP, PB-ECBACC are report-only. Control PB-EZ-P. Lower prior, because REF-F4 was flat on 2010-2015.
- **PB-OCB** (selectable): scheduled Bank of England decisions and SNB quarterly assessments. Unscheduled moves are excluded.
  - Long 12:00 London on the London business day before. Out 5 minutes before the decision.
  - Low prior; a mechanism test. Control PB-OCB-P.
- **TA-1** (selectable, **short**): 10-year and 30-year Treasury auctions. Its calendar (shared with TA-2) is built and committed before the A-C look (section 10).
  - Short 14:00 New York on the weekday before. Out 12:55 New York on auction day.
  - A 30-year auction on the weekday after a 10-year auction is skipped. Control TA-1-P.
- **TA-2** (selectable): long 13:05 New York on auction day. Out 13:00 New York the next weekday. Control TA-2-P.
- **ST-B** (report-only stack): section 9.

**Leak guard for batch B.** An event is used only if its date was public before its decision time. The amendment gives the evidence (the publisher's advance calendar, the Treasury tentative schedule or auction announcement, the bank's published dates). Otherwise the row is dropped and listed.

**Calendar choices are mechanical.** No calendar choice is made after any C or T result is known (section 10 fixes when each calendar is built). Before any fetch, the calendar amendment names each series' official source URLs. Each URL gets at most 3 fetch attempts, logged in research/round55/FETCH_LOG.jsonl (url, UTC time, HTTP status, bytes, sha256). Then:
- A series is in its pool only if its named sources return its release dates for every year the cell's eras need. Otherwise it is left out, and the log shows why.
- ISM's fallback rule is used only if it matches every archived ISM notice the logged fetches return, over 2 or more years.
- A row is dropped only under the leak guard's written rule, with the logged evidence.
- No series, fallback or row is kept or dropped by judgement.

## 6. Controls

| Control | Controls | Strata |
|---|---|---|
| PB-USALL-P | PB-USALL and its 4 members | entry weekday, exit clock (08:25 or 13:55 New York) |
| PB-SAME-P | PB-SAME | weekday |
| FC-1C | FC-1 | entry weekday |
| ST-A-P | ST-A | per member placebo (section 9) |
| PB-USX-P | PB-USX and its 4 members | entry weekday, exit clock (08:25 or 09:55 New York) |
| PB-EZ-P | PB-EZ and its 2 members | entry weekday, exit clock |
| PB-OCB-P | PB-OCB | entry weekday, exit clock (11:55 or 08:25 London) |
| TA-1-P | TA-1 | entry weekday |
| TA-2-P | TA-2 | entry weekday |

**Components** (not separate cells):
- Round 47's **PA-F1P**: the placebo of REF-F1 inside ST-A-P. Unchanged code. Its B trades must equal Round 47's PA-F1P rows.
- **REF-F4P**: the placebo of REF-F4 inside ST-A-P, defined in ST-A-P's rule.

Both run on B, C and T.

**Disclosures** (no rule change):
- PA-F1P is Tuesday-only and excludes only FOMC weeks. REF-F4P excludes every events.csv day within a weekday of its window, a stricter filter. The two placebos are not built alike.
- REF-F1 has 3 Wednesday decisions (B 2: 7 Nov 2018 and 4 Nov 2020; T 1: 6 Nov 2024; checked in events.csv). No PA-F1P stratum matches them, so they drop out of the ST-A-P comparison.
- The no-event filter uses rows the leak guard dropped, at their actual (moved) dates. That is a tiny look-ahead in which placebo days are kept (the 6 W1 rows on B). It only removes a few placebo days near those dates and reads no price; its effect is tiny.
- Placebo days can hold retail sales, PPI or ISM releases (not in events.csv). If a general pre-release premium exists, the controls earn part of it, which biases each comparison against the cell.

**Selectable cells (8):** PB-USALL, PB-SAME, FC-1 (batch A); PB-USX, PB-EZ, PB-OCB, TA-1, TA-2 (batch B).

**Report-only:** REF-F1, REF-F4, the 10 members, XC-DOLX, PB-USALL-1014, ST-A, ST-B. The 9 controls are not selectable either.

## 7. Verdicts

Fixed now. Every figure is at the 2.0-pip cost with financing.

**Eligible** (selectable cells only, on B):
- at least 30 trades;
- mean net > 0;
- beats its control (section 3 weighting).

**Freeze.** The eligible list goes into FROZEN_A.json (batch A) or FROZEN_B.json (batch B). It is committed and pushed before C is read. Every eligible cell goes on to C and T; there is no top-3 cap.

**Pass**, per eligible cell:
- mean net > 0 on C and on T;
- beats its control on C and on T.

**Confirmed** = pass, plus:
- pooled C+T random-side p ≤ 0.05 (the side flipped per trade between net_long and net_short, as Round 47's verdict; computed as in section 8, "p precision", with numpy default_rng(5501));
- BH q ≤ 0.10 (section 8).

**Promising** = pass without the p or the q. **No edge** = anything else.

**What the p does and does not show.** The random-side p asks whether trading the cell's side beat a coin flip for the side on the same windows. For a long-only cell that mostly asks whether EUR/USD rose on those windows by more than chance; a general rise of EUR/USD across C and T can give a small p. It does not show that the events matter. That second question is asked by "beats its control" (a point comparison, no test) and by the event-premium test of section 3, which is reported beside every verdict but decides nothing. The verdict rules above stay as the lead agent fixed them.

A confirmed cell is a stage-1 component, not an edge. An edge still needs the locked final test (HANDOFF "Final tests (locked data)").

**If PB-USALL is eligible,** the gate in section 2 opens.

## 8. Multiple testing

**The BH family** (Benjamini-Hochberg, q ≤ 0.10):
- Every Round 55 cell that runs adds one p, including controls, members, the diagnostic, ST-A, ST-B and PB-USALL-1014. ST-A-P is the one exception (below).
  - a selectable cell judged on C and T adds its pooled C+T p (seed 5501);
  - every other cell adds its B random-side p (seed 4748, the seed Round 47's `summarize(seed=4747)` uses for its side draw); PB-USALL-1014 adds its era-X p the same way.
  - Both are computed as in "p precision" below. `summarize`'s own 2,000-run null_p is still reported, but it never enters BH.
- Both registers: every row of research/fastscreen/REGISTER.jsonl and REGISTER_main.jsonl with era "B" and a p. That is 1,188 + 142 = 1,330 at declaration (only 11 at or below 0.10; the smallest is 0.0096). The runner records the count and both files' sha256 when it computes BH.

**p precision.** With 2,000 runs a p is either 0 or at least 0.0005. A p of 0 gives q = 0, and a cell whose true p is 0.0005 shows p = 0 in about 37% of seeds ((1 - 0.0005)^2000). With about 1,365 p values, a lone small p needs about 0.10 / 1,365 ≈ 0.00007 for q ≤ 0.10, so the 2,000-run grid could give a false "confirmed". So every p that enters BH is:
- p = (k + 1) / (n + 1), with n = 1,000,000 random-side runs and k = the runs whose mean net is at least the real mean net minus 1e-12;
- drawn in 100 chunks of 10,000 runs from one numpy generator, default_rng(seed), each chunk `integers(0, 2, (10000, trades))`, in order;
- so the smallest reachable p is about 0.000001, well below 0.10 / m.
This changes only how precise the p is, not any rule. ST-A-P's 2,000-draw share (section 9) is report-only and stays as declared.

**ST-A-P adds no p.** It is a weighted mean plus a draw, not a trade list. Its parts are counted already: PB-USALL-P, PB-SAME-P and FC-1C as cells, and PA-F1P and REF-F4P are components only. ST-B's placebo stack adds no p either.

**ST-A's and ST-B's p count trades twice, on purpose.** Their B p re-uses trades already counted under REF-F1, REF-F4, PB-USALL and the others. That adds p values to the family, which only makes BH stricter.

**The anchors, counted once.**
- REF-F1 and REF-F4 add their Round 47 pooled C+T p (0.0985 and 0.062, research/round47/results/VERDICT.json), as Round 47 published them. They are on Round 47's 2,000-run grid, which does not matter here because neither is near 0.
- The parity re-run gives the same trades, so it adds no new p.
- Neither register holds Round 47's cells (checked: the register rows are fast-screen looks only). So each anchor sits in the family exactly once.
- PA-F1P and REF-F4P are components of ST-A-P and add no p of their own.

**Not run, not counted.** A gated-out cell has no p and is listed as not run.

**Two BH figures.**
- Interim: after batch A, over the batch-A cells plus the registers.
- Final: after the last batch-B look, over every cell that ran plus the registers. The final figure decides "confirmed". An interim "confirmed" that fails the final q is reported as "promising".

**Wider figure** (information only, never deciding): the same BH with Round 47's other 59 B p values added (research/round47/results/B.json).

## 9. Stacks

**ST-A** (report-only), computed after the batch-A verdict from trades already made. No new price is read.
- Members: REF-F1, REF-F4, and each batch-A selectable cell that is "promising" or "confirmed": PB-USALL (or PB-SAME, as in section 5) and FC-1.
- Priority: REF-F1 > REF-F4 > PB-USALL or PB-SAME > FC-1.
- Build per era: take members in priority order. Keep a trade only if its scheduled window overlaps no trade already kept. One position at a time, so opposite sides are never held together.
- If no new cell passes, ST-A is the two anchors only, and it is still reported.
- **In-sample, said plainly.** The stack is built from pieces chosen because they did well on these same years (the new members pass B, C and T; the anchors were kept in Round 47 for being positive on C and T). Its numbers describe them; they do not predict them. That covers its trades a week, R a month and the placebo-stack comparison.

**ST-A-P** (control):
- Each member's placebo: PA-F1P for REF-F1, REF-F4P for REF-F4, PB-USALL-P, PB-SAME-P, FC-1C.
- Its mean = the stratum-weighted placebo means, weighted by ST-A's kept trades per member and stratum (section 3).
- ST-A "beats its placebo stack" when its mean net a trade is higher, on B and on each judging era (a reported flag).
- Draw, fixed now: 2,000 placebo stacks, numpy default_rng(55055). Each draws n_M(g) trades with replacement from each member's placebo stratum, members in priority order, strata sorted. Reported: the share of drawn stacks at least as good as ST-A.

**ST-B** (report-only), only if a batch-B cell runs:
- ST-A's members plus each batch-B pool that is "promising" or "confirmed".
- Priority: REF-F1 > REF-F4 > PB-USALL or PB-SAME > PB-EZ > PB-USX > PB-OCB > TA-1 > TA-2 > FC-1. PB-USALL's members sit inside its slot.
- Its placebo stack is built the same way, with numpy default_rng(55056).

**Reported per stack, per era and pooled C+T:**
- trades a week;
- net pips a month at 2.0 and 1.6;
- net R a month;
- worst month;
- maximum drawdown in R;
- the correlation of members' monthly results;
- the placebo-stack comparison.

## 10. Look order

**Batch A:**
1. DECLARATION.md and CELLS.json are committed with their sha256 files. Code, tests and review follow, with amendments before the look they affect.
2. **A-B look:** all 15 batch-A cells, PA-F1P and REF-F4P, on B. The runner commits and pushes its "started" mark (LOOKS.jsonl) before reading any B price (Round 45/47 runner rules). Parity is checked here first.
3. FROZEN_A.json is committed and pushed.
4. **Calendars before C.** The gate is read from the A-B results. Before the A-C look, every batch-B calendar that will be used is built (no price read) and fixed by its committed amendment:
   - always the TA-1 and TA-2 auction calendar;
   - if the gate opens, the PB-USX, PB-EZ and PB-OCB calendars and PB-USALL-1014's 2010-2014 calendar;
   - if the gate stays shut, nothing more is fetched.
   So no calendar choice is made after a C or T result is known (section 5, "Calendar choices are mechanical").
5. **A-C look**, once, then **A-T look**, once. The set:
   - REF-F1, REF-F4, XC-DOLX, PA-F1P and REF-F4P (always);
   - every eligible cell and its control;
   - PB-USALL's members, if PB-USALL is eligible.
6. Batch-A verdict with the interim BH, then ST-A and ST-A-P.

**Batch B:**
7. The calendars are already fixed (step 4). No calendar is changed after that.
8. **B-B look** (every batch-B cell that runs), FROZEN_B.json, **B-C look** once, **B-T look** once.
9. Final verdict with the final BH, then ST-B.
10. PB-USALL-1014, if gated in: one look on era X, after PB-USALL's verdict.

Each era of each batch is read once. Nothing is tuned on C or T.

## 11. Reports

**Per cell and era:**
- trades and trades a month;
- mean net at 2.0 and 1.6, and mean bid/ask net;
- hit rate and t;
- by year and years positive;
- the 90% month-block bootstrap;
- the random-side p;
- the weighted control comparison and how many trades were left out;
- R a trade and R a month.

**Power flag** (B only): the minimum detectable effect ≈ 2.5 x sd(net) / √n, from the trade count and the sd only, never the mean. Reported, never used to choose.

**For the owner:**
- trades a week of the passing pieces together (ST-A, then ST-B);
- R a month against his +5R a month target, with the $15,000 example;
- trades a week against his 3-5 a week;
- with this sentence next to the stack's numbers: "The stack is built from pieces chosen because they did well on these same years; its numbers describe them, they do not predict them."

**How far "confirmed" is** (approximate, from the calendar count and the design's sd only, never from a mean): with about 1,365 p values in BH, "confirmed" needs a pooled p below about 0.0001 (z about 3.8). For PB-USALL on C+T (141 trades by the calendar count; sd about 40-50 pips, the design's estimate) that is roughly +11 pips a trade net (about +10 to +13 across that sd range). Promising is the likely best outcome, and the owner is told so before any result.

**The honest trade count** (approximate, from the calendar only, before data gaps and the 15-minute fill rule):

| Cell | B | C | T | A year |
|---|---|---|---|---|
| REF-F1 | 46 | 15 | 13 | about 8 |
| REF-F4 | 47 | 15 | 13 | about 8 |
| PB-USALL | 224 (19 skipped for REF overlap) | 79 (5) | 62 (6) | about 38 |
| PB-SAME | 184 | 64 | 51 | about 31 |
| FC-1 | 96 (3 shortened) | 32 | 25 | about 16, mostly overlapping |

- The anchors' counts match Round 47's trades (B 46 and 47; C+T 28 each).
- FC-1's counts are after the paper's cycle boundary and the era-end rule (section 5).
- If PB-USALL passes, ST-A gives about 8 + 8 + 38 = about 54 trades a year, **about 1 a week**.
- FC-1 adds few after the overlap skip.
- 3-5 a week needs most calendar pools to pass too: PB-USX about 35, PB-EZ about 18, PB-OCB about 10, TA-1 and TA-2 about 40 a year (design estimates, approximate). Each is a low-prior analogy, so that is unlikely. The owner is told this plainly.

**Priors, stated before any look** (both papers are equity evidence; neither is an FX source):
- **PB-USALL, against:** Lucca and Moench, "The Pre-FOMC Announcement Drift" (NY Fed Staff Report 512, Sep 2011, revised Aug 2013): "other major U.S. macroeconomic news announcements do not give rise to pre-announcement equity returns". Their test is a dummy for the day before the release.
- **PB-USALL, for:** Hu, Pan, Wang and Zhu, "Premium for heightened uncertainty: Explaining pre-announcement market returns" (Journal of Financial Economics): "We find large overnight returns with no abnormal variance before nonfarm payrolls, ISM, and GDP announcements, similar to the pre-FOMC returns." Their window is "from 4 pm on the pre-announcement day to five minutes before the release time" (S&P 500 index futures, September 1994 to May 2018), almost exactly PB-USALL's window. They say the return is "realized mostly overnight – a key reason why this empirical fact has been missed by early studies including Lucca and Moench (2015)". This also supports ISM in PB-USX.
- **Per release (Hu et al., Table 1, pre-announcement mean in bps, t in brackets):** NFP 10.10 (3.63), ISM 9.14 (2.10), GDP 7.46 (2.08), PI 3.50 (0.94), PPI -0.58 (-0.17), CPI -2.14 (-0.69). So the equity evidence is against PB-CPI and PB-PPI, weak for PB-PCE (personal income), and silent on FOMC minutes and retail sales.
- **FC-1:** the paper's own FX evidence is against a dollar link. Its 2 Oct 2015 draft says "we fail to detect a similar bi-weekly pattern in the so-called dollar portfolio returns" and "we find no tendency for the dollar to appreciate in even weeks in FOMC cycle time".
- **PB-SAME:** Round 47's same-day FOMC version (PA-F2) failed on B.
- **PB-EZ:** REF-F4 was flat on 2010-2015.

**Sources.**
- **Verified on 12 Oct 2026** (each PDF downloaded and its text searched):
  - Cieslak, Morse and Vissing-Jorgensen, "Stock Returns over the FOMC Cycle", working-paper draft of 2 Oct 2015 (https://www.stern.nyu.edu/sites/default/files/assets/documents/cycle_paper_cieslak_morse_vissingjorgensen.pdf) and draft of 25 Jun 2014 (https://conference.nber.org/conf_papers/f74573/f74573.pdf).
    - Table note (2015 draft): "Week -1: Days -6 to -2. Week 0: Days -1 to 3. Week 1: Days 4 to 8. Week 2: Days 9 to 13. Week 3: Days 14 to 18. Week 4: Days 19 to 23. Week 5: Days 24-28. Week 6: Days 29-33."
    - Footnote 5 (both drafts): "There are 3 days over the last 20 years which fall into what would be week 7 in FOMC cycle time. For simplicity of interpretation we drop these 3 days from our analysis throughout." With 7-8 week gaps between meetings, so few week-7 days is only possible if days -6 to -2 before the next meeting count as the next cycle's week -1.
    - Figure note (both drafts): "If a given day is day -6 or closer to the next meeting, the 5-day (forward) return for this day is not used in the right part of the graph, so points to the right do not use any data for days -2 and later."
    - Text (2015 draft): "Date 0 on the horizontal axis is the day of a scheduled FOMC meeting. For two-day meetings, date 0 refers to the second day. The graph omits weekends and sets return to zero on holidays."
    - These settle the cycle boundary that FC-1 and FC-1C use (section 5).
  - Lucca and Moench, NY Fed Staff Report 512 (https://www.newyorkfed.org/medialibrary/media/research/staff_reports/sr512.pdf). Read as the staff report, not the 2015 Journal of Finance text.
  - Hu, Pan, Wang and Zhu, Journal of Financial Economics, doi 10.1016/j.jfineco.2021.09.015 (https://www.mit.edu/~zhuh/HuPanWangZhu_preannouncement.pdf, the journal's "article in press" version).
  - The BEA and BLS notices quoted in section 4.
- **Not verified:**
  - The published Journal of Finance version of the FOMC-cycle paper (2019) was not read: Wiley and a 2018 draft at acfr.aut.ac.nz returned 403 to the critic.
  - Savor and Wilson (2013), Lou, Yan and Zhang (2013) and Verdelhan (2018) are cited from memory.

**Costs.** Financing is a flat convention. Real swap differs by broker and year, so it must be checked before any live use.

## 12. Never

- Validation (anything at or after 1751317200) and the holdout.
- The main agent's running rounds, and the newbies' work.
- A price download in batch A. Batch B fetches only official calendars, rate-limited. PB-USALL-1014 uses only Round 49's existing 2010-2015 file.
- A rule changed after a look, except by a numbered amendment before the look it affects. Nothing tuned on C or T.
- Order code, secrets, risk-size rules.

## 13. Critic

One red-team pass before this file's first commit. Its findings were applied in the text above, so they need no numbered amendment. One line per finding:

1. **Blocker, FC week rule:** applied. FC-1 and FC-1C use the paper's cycle boundary (day -6 or closer belongs to the next cycle; entry only before day -7; exit on the earlier of day 5k+3 and day -7). The three sentences were checked in both drafts, and the counts recomputed from events.csv (section 5). Week 0 is left out on purpose. The 2019 journal text was not read.
2. **Blocker, p grid:** applied. Every p that enters BH is (k+1)/(n+1) with n = 1,000,000 runs, in fixed chunks, with the same declared seeds (section 8).
3. **Era ends:** applied (section 3), with the two lost FC-1 trades named and a world-maximum test. The critic's FC-1 counts of 97 and 33 include those two trades; the declaration gives both.
4. **ST-A-P's p:** applied. ST-A-P and ST-B's placebo stack add no p, and ST-A's and ST-B's double count is stated as deliberate (section 8).
5. **Event part untested:** applied as a report-only stratified permutation test (section 3), plus a plain statement of what the random-side p shows (section 7). Decision 4 is unchanged.
6. **Power:** applied (section 11, "How far confirmed is"), from the calendar count and the design's sd only.
7. **Sources:** applied. Both papers were downloaded and quoted verbatim; Lucca-Moench is marked as the staff report. Hu et al. is named as evidence for PB-USALL and ISM, and its Table 1 is added. The "PB-GDP smallest" expectation is dropped and replaced by Hu et al.'s ranking, labelled report-only (sections 5 and 11).
8. **Calendars after C and T:** applied. Every calendar that will be used is built and committed before the A-C look: TA always, the gated pools and PB-USALL-1014 only if the gate opens. Availability, the ISM fallback and dropped rows are decided mechanically from FETCH_LOG.jsonl (sections 5 and 10).
9. **ST-A in-sample:** applied in sections 9 and 11 and in the owner report.
10. **Readings of the design** (D-1, TA in ST-B, the XC cross): applied as a list in section 3, with E added.
11. **PB-SAME clock:** applied ("02:00 New York, or 03:00 in DST-mismatch weeks").
12. **Empty utc:** applied (section 3; ECB_OTHER-2020-03-18 uses its local_date).
13. **Control disclosures:** applied as four lines in section 6. The critic's word "conservative" for the dropped-row look-ahead is not used: removing a few placebo days has no known direction, so the text says only that its effect is tiny.
14. **XC-DOLX reading:** applied (section 5): the comparison can only motivate a later declared test.
15. **Leak-guard windows:** applied. W1 is marked as recalled. W3 runs to the file's end (2025-12-30), so its 5 dropped rows stay an exact, checkable list; the rule's own end is stated beside it.
16. **PB-USALL-1014:** applied. The CLAUDE.md and HANDOFF lines are cited, and the result is labelled a report-only check on years already read (section 5).
17. **Checks that found no error:** none needed. The registers (1,188 + 142, 11 at or below 0.10, smallest 0.0096), the anchors' p values (0.0985 and 0.062) and the 37% figure were re-checked here.
