"""Round 55 batch A (DECLARATION.md sections 3-6 and 9; rule text verbatim from CELLS.json).

Cells run in a look: REF-F1, REF-F4 (Round 47's PA-F1 and PA-F4, imported unchanged), PB-USALL, PB-NFP, PB-CPI,
PB-MIN, PB-GDP, PB-USALL-P (two sub-series), PB-SAME, PB-SAME-P, XC-DOLX, FC-1, FC-1C, and the components PA-F1P
(Round 47's, imported unchanged) and REF-F4P (one sub-series per exit clock). ST-A and ST-A-P are built by the
runner from these trades (section 9); they are not Cell objects.

Calendar. Every event cell reads research/round17/data/events.csv (sha256-checked) through decide_ts / exit_ts keyed
by the decision date; no price is read for the calendar, so World.cut cannot change an event cell's side or window.
XC-DOLX is the only cell whose side reads prices (section 3, leak tests).

Readings of the declaration (each one is reported to the lead; none changes a declared rule):
- R1. A sub-series (PB-USALL-P's two exit clocks, REF-F4P's clocks) is its own Cell with id "<cell>@<HH:MM>", so the
  engine keeps one position at a time per sub-series. base() maps it back to the cell id.
- R2. REF windows for the skip rules come from Round 47's own event index (fam_events.ev_index) on the held rows of
  events.csv before CUT (r47_engine.load_events), so they are exactly PA-F1's and PA-F4's calendar windows:
  [14:00 New York on the weekday before, statement - 5 min) and [12:00 London on the London business day before,
  decision - 5 min).
- R3. "No event" date ranges are inclusive calendar ranges: PB-USALL-P [weekday before d, weekday after d+1];
  REF-F4P [weekday before L, weekday after L']. PB-SAME-P is read literally as the two dates {d, next weekday}.
- R4. PB-USALL-P's windows to avoid are PB-USALL's windows, kept or skipped (the members' windows are not added;
  every member window ends on an event date that the no-event range already excludes).
- R5. FC day 0 = scheduled == 1, held FOMC_STATEMENT rows (all at 14:00 New York, checked). A cycle with no next
  statement in the file has no trade. "Before day -7" is strict; the exit is the earlier of day 5k+3 and day -7.
- R6. XC-DOLX: T5 = the same local clock (New York 14:00 for REF-F1 windows, London 12:00 for REF-F4 windows) on the
  5th weekday before the decision date. Prices are read with Round 47 DF-O1's own readers (fam_rates_cross.Panel._mid
  and Panel._xa). If an REF-F1 and an REF-F4 decision fell on one date, the earlier is used (none does; tested).
- R7. A REF-F4P clock set is per era: the London clocks of REF-F4's scheduled exits whose decision date is in that
  era (cells_for() returns only those sub-series).
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from bisect import bisect_left, bisect_right
from dataclasses import replace
from datetime import date, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
R55 = HERE.parent
REPO = R55.parents[1]
R47 = REPO / "research/round47"
sys.path.insert(0, str(R47))
import r47_cal as K  # noqa: E402
import r47_engine as E  # noqa: E402
from r47_engine import LON, NY, Cell, local_ts  # noqa: E402


def _load(name: str, path: Path):
    """A module by file path under its own name (Round 47's `cells` name stays free, see cells/__init__.py)."""
    if name in sys.modules and getattr(sys.modules[name], "__file__", None) == str(path):
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


F47 = _load("r47_fam_events", R47 / "cells/fam_events.py")          # PA-F1, PA-F4, PA-F1P, unchanged
X47 = _load("r47_fam_rates_cross", R47 / "cells/fam_rates_cross.py")  # DF-O1's price readers, unchanged

EVENTS = REPO / "research/round17/data/events.csv"
EVENTS_SHA = "ee2c318882e97c60d3d43ac95248571a9d59ba4cb99b0ddfa5e47283d4f86c22"
_SPEC = {c["id"]: c for c in json.loads((R55 / "CELLS.json").read_text())["cells"]}

BATCH_A = ("REF-F1", "REF-F4", "PB-USALL", "PB-NFP", "PB-CPI", "PB-MIN", "PB-GDP", "PB-USALL-P", "PB-SAME",
           "PB-SAME-P", "XC-DOLX", "FC-1", "FC-1C", "ST-A", "ST-A-P")
COMPONENTS = ("PA-F1P", "REF-F4P")
STACKS = ("ST-A", "ST-A-P")
SELECTABLE = ("PB-USALL", "PB-SAME", "FC-1")
MEMBERS = ("PB-NFP", "PB-CPI", "PB-MIN", "PB-GDP")
ANCHORS = ("REF-F1", "REF-F4")
CONTROL = {"PB-USALL": "PB-USALL-P", "PB-NFP": "PB-USALL-P", "PB-CPI": "PB-USALL-P", "PB-MIN": "PB-USALL-P",
           "PB-GDP": "PB-USALL-P", "PB-SAME": "PB-SAME-P", "FC-1": "FC-1C"}
PLACEBO = {"REF-F1": "PA-F1P", "REF-F4": "REF-F4P", "PB-USALL": "PB-USALL-P", "PB-SAME": "PB-SAME-P", "FC-1": "FC-1C"}
CLOCK_TZ = {"PB-USALL-P": "NewYork", "REF-F4P": "London"}   # controls whose strata add the exit clock (section 6)
PRIORITY = ("REF-F1", "REF-F4", "PB-USALL", "PB-SAME", "FC-1")  # ST-A (section 9); PB-USALL and PB-SAME never both

GUARD_TYPES = ("US_NFP", "US_CPI", "US_GDP", "FOMC_MINUTES")
AGENCY = {"US_NFP": "BLS", "US_CPI": "BLS", "US_GDP": "BEA"}         # FOMC_MINUTES: the Fed, not a candidate
LAPSES = (("W1", date(2018, 1, 20), date(2018, 3, 23), ("BLS", "BEA")),
          ("W2", date(2018, 12, 22), date(2019, 3, 26), ("BEA",)),
          ("W3", date(2025, 10, 1), date(2025, 12, 30), ("BLS", "BEA")))
EVIDENCE = {"US_GDP-2019-02-28": "BEA blog of 6 Feb 2019 (https://www.bea.gov/news/blog/2019-02-06/"
                                 "new-dates-set-gdp-personal-income-and-international-trade): released on Feb. 28"}
DECLARED_DROPPED = ("US_NFP-2025-10-03",
                    "US_GDP-2018-01-26", "US_NFP-2018-02-02", "US_CPI-2018-02-14", "US_GDP-2018-02-28",
                    "US_NFP-2018-03-09", "US_CPI-2018-03-13",
                    "US_CPI-2025-10-24", "US_NFP-2025-11-20", "US_NFP-2025-12-16", "US_CPI-2025-12-18",
                    "US_GDP-2025-12-23")
PLAN_FROM, PLAN_TO = date(2015, 12, 1), date(2025, 7, 31)    # placebo calendars cover every era; CUT stops the rest


# ------------------------------------------------------------------ time helpers

def sha256(p: Path) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def ny_date(ts: int) -> date:
    return datetime.fromtimestamp(int(ts), NY).date()


def lon_date(ts: int) -> date:
    return datetime.fromtimestamp(int(ts), LON).date()


def clock(ts: int, tz: str) -> str:
    return datetime.fromtimestamp(int(ts), E.TZ[tz]).strftime("%H:%M")


add_weekdays = F47.add_weekdays          # Round 47's weekday counter (Monday-Friday; holidays are not skipped)


def weekdays(a: date, b: date) -> list:
    out, x = [], a
    while x <= b:
        if x.weekday() < 5:
            out.append(x)
        x += timedelta(days=1)
    return out


def overlaps(a0: int, a1: int, b0: int, b1: int) -> bool:
    """Windows [a0, a1) and [b0, b1) overlap when each starts before the other ends (touching ends do not)."""
    return a0 < b1 and b0 < a1


class Windows:
    """A set of [start, end) windows with an overlap query."""

    def __init__(self, wins):
        w = sorted((int(a), int(b)) for a, b in wins)
        self.starts = [a for a, _ in w]
        self.w = w
        self.maxlen = max((b - a for a, b in w), default=0)

    def hit(self, a: int, b: int) -> bool:
        i = bisect_left(self.starts, b)                       # windows starting before b
        j = bisect_left(self.starts, a - self.maxlen)         # earlier ones end before a
        return any(overlaps(a, b, s, e) for s, e in self.w[j:i])


# ------------------------------------------------------------------ calendar (events.csv only)

def read_events(path: Path = EVENTS, check: bool = True) -> pd.DataFrame:
    """Every row of events.csv with its utc as ts (None if empty) and its New York date (section 3: the date of its utc
    in New York; a row with an empty utc uses its local_date)."""
    if check and sha256(path) != EVENTS_SHA:
        raise RuntimeError(f"{path} is not the declared events.csv")
    e = pd.read_csv(path, dtype={"utc": str, "local_date": str, "event_id": str, "status": str})
    ts = [int(pd.Timestamp(u).timestamp()) if isinstance(u, str) and u.strip() else None for u in e.utc]
    e["ts"] = pd.Series(ts, dtype=object)
    e["ny_date"] = [ny_date(t) if t is not None else date.fromisoformat(ld) for t, ld in zip(ts, e.local_date)]
    e["ldate"] = [date.fromisoformat(x) for x in e.local_date]
    return e


def leak_guard(ev: pd.DataFrame):
    """Section 4. Returns (kept rows of the four types, {event_id: reason} dropped, [candidate ids])."""
    rows = ev[ev.type.isin(GUARD_TYPES)]
    dropped, cands, keep = {}, [], []
    for _, r in rows.iterrows():
        if not (int(r.scheduled) == 1 and r.status == "held"):
            dropped[r.event_id] = f"L0: scheduled {r.scheduled}, status {r.status!r}"
            continue
        win = [n for n, a, b, ag in LAPSES if AGENCY.get(r.type) in ag and a <= r.ldate <= b]
        if win:
            cands.append(r.event_id)
            if r.event_id not in EVIDENCE:
                dropped[r.event_id] = f"L1 candidate in {win[0]}, L2 no verified notice"
                continue
        keep.append(r.event_id)
    kept = rows[rows.event_id.isin(keep)].reset_index(drop=True)
    return kept, dropped, cands


def ref_windows(held: pd.DataFrame) -> dict:
    """REF-F1 and REF-F4 calendar windows, from Round 47's own event index (reading R2). held: columns type, ts."""
    info = F47.ev_index(SimpleNamespace(events=held))
    f1 = {d: (local_ts(d, "14:00", "NewYork"), int(s) - 300) for d, s in info["fomc_prev"].items()}
    f4 = {d: (local_ts(d, "12:00", "London"), int(s) - 300) for d, s in info["ecb_prev"].items()}
    return {"REF-F1": f1, "REF-F4": f4}


def pb_plan(kept: pd.DataFrame, types, block: Windows, same_day: bool = False):
    """PB-USALL's rule on the kept rows of `types` (or PB-SAME's with same_day). Returns (plan, skipped, clocks):
    plan / skipped = {decision date: (decision ts, exit ts)}; clocks = {decision date: exit clock, New York}."""
    rows = kept[kept.type.isin(types)]
    first = {}
    for d, t in zip(rows.ny_date, rows.ts):                     # all kept rows with the same E form one trade
        first[d] = min(int(t), first.get(d, int(t)))
    plan, skipped, clocks = {}, {}, {}
    for e_day in sorted(first):
        x = first[e_day] - 300
        if same_day:
            d, t = e_day, local_ts(e_day, "07:00", "London")
        else:
            d = add_weekdays(e_day, -1)
            t = local_ts(d, "14:00", "NewYork")
        if d in plan or d in skipped:
            raise RuntimeError(f"two event days share the decision date {d}")
        (skipped if block.hit(t, x) else plan)[d] = (t, x)
        clocks[d] = clock(x, "NewYork")
    return plan, skipped, clocks


def _no_event(dates_sorted: list, lo: date, hi: date) -> bool:
    return bisect_right(dates_sorted, hi) == bisect_left(dates_sorted, lo)


def usall_p_plan(clk: str, ev_dates: list, block: Windows, a: date = PLAN_FROM, b: date = PLAN_TO) -> dict:
    """PB-USALL-P, one exit clock: 14:00 New York on d to clk New York on the next weekday."""
    plan = {}
    for d in weekdays(a, b):
        d1 = add_weekdays(d, 1)
        if not _no_event(ev_dates, add_weekdays(d, -1), add_weekdays(d1, 1)):
            continue
        t, x = local_ts(d, "14:00", "NewYork"), local_ts(d1, clk, "NewYork")
        if not block.hit(t, x):
            plan[d] = (t, x)
    return plan


def same_p_plan(ev_dates: list, block: Windows, a: date = PLAN_FROM, b: date = PLAN_TO) -> dict:
    """PB-SAME-P: 07:00 London to 08:25 New York on d; no event dated d or the next weekday (reading R3)."""
    evs = set(ev_dates)
    plan = {}
    for d in weekdays(a, b):
        if d in evs or add_weekdays(d, 1) in evs:
            continue
        t, x = local_ts(d, "07:00", "London"), local_ts(d, "08:25", "NewYork")
        if not block.hit(t, x):
            plan[d] = (t, x)
    return plan


def f4p_plan(clk: str, ev_dates: list, block: Windows, a: date = PLAN_FROM, b: date = PLAN_TO) -> dict:
    """REF-F4P, one exit clock: 12:00 London on London business day L to clk London on the next one, L'."""
    plan = {}
    for d in weekdays(a, b):
        if not K.is_london_bd(d):
            continue
        d1 = K.london_bd_offset(d, 1)
        if not _no_event(ev_dates, add_weekdays(d, -1), add_weekdays(d1, 1)):
            continue
        t, x = local_ts(d, "12:00", "London"), local_ts(d1, clk, "London")
        if not block.hit(t, x):
            plan[d] = (t, x)
    return plan


def fc_plan(stmt_days: list, weeks) -> tuple:
    """FC-1 (weeks 2, 4, 6) or FC-1C (1, 3, 5) with the paper's cycle boundary (section 5, reading R5).
    Returns ({entry date: (entry ts, exit ts)}, [entry dates shortened by day -7])."""
    plan, short = {}, []
    days = sorted(stmt_days)
    for s0, s1 in zip(days, days[1:]):
        d7 = add_weekdays(s1, -7)
        for k in weeks:
            a, b = add_weekdays(s0, 5 * k - 2), add_weekdays(s0, 5 * k + 3)
            if not a < d7:
                continue
            if d7 < b:
                b = d7
                short.append(a)
            plan[a] = (local_ts(a, "16:00", "London"), local_ts(b, "16:00", "London"))
    return plan, short


def fomc_days(ev: pd.DataFrame) -> list:
    s = ev[(ev.type == "FOMC_STATEMENT") & (ev.scheduled == 1) & (ev.status == "held")]
    if any(clock(t, "NewYork") != "14:00" for t in s.ts):
        raise RuntimeError("a scheduled, held FOMC statement is not at 14:00 New York")
    return sorted(set(s.ny_date))


def era_plan(plan: dict, era: str) -> dict:
    """The calendar trades of an era (section 11): decision date in the era, exit before the era's end."""
    e = E.ERAS[era]
    return {d: w for d, w in plan.items() if e["from"] <= d <= e["to"] and w[1] < e["end"]}


def busy_thin(plan: dict) -> dict:
    """The section-3 busy rule on scheduled windows (calendar only, before data gaps and the fill rule): in decision
    order, a window starting before the last kept window's exit is skipped; one starting at that exit is kept."""
    kept, busy = {}, -1
    for d, (t, x) in sorted(plan.items(), key=lambda kv: kv[1][0]):
        if t >= busy:
            kept[d], busy = (t, x), x
    return kept


# ------------------------------------------------------------------ the calendar of this round

class Calendar:
    def __init__(self, ev: pd.DataFrame):
        self.ev = ev
        self.kept, self.dropped, self.candidates = leak_guard(ev)
        held = E.load_events(E.CUT)          # Round 47's own reader: held rows (type, ts) before CUT
        self.held = held
        self.ref = ref_windows(held)
        ref = Windows(list(self.ref["REF-F1"].values()) + list(self.ref["REF-F4"].values()))
        self.ev_dates = sorted(ev.ny_date)
        self.pb = {}
        for cid, types, same in (("PB-USALL", GUARD_TYPES, False), ("PB-NFP", ("US_NFP",), False),
                                 ("PB-CPI", ("US_CPI",), False), ("PB-MIN", ("FOMC_MINUTES",), False),
                                 ("PB-GDP", ("US_GDP",), False), ("PB-SAME", ("US_NFP", "US_CPI", "US_GDP"), True)):
            self.pb[cid] = pb_plan(self.kept, types, ref, same)
        plan, skipped, _ = self.pb["PB-USALL"]
        usall = Windows(list(plan.values()) + list(skipped.values()))
        both = Windows(ref.w + usall.w)
        self.usall_p = {c: usall_p_plan(c, self.ev_dates, both) for c in ("08:25", "13:55")}
        self.same_p = same_p_plan(self.ev_dates, ref)
        self.f4_clocks = {era: sorted({clock(x, "London") for _, x in era_plan(self.ref["REF-F4"], era).values()})
                          for era in E.ERAS}
        clocks = sorted({c for v in self.f4_clocks.values() for c in v})
        self.f4p = {c: f4p_plan(c, self.ev_dates, ref) for c in clocks}
        self.fomc = fomc_days(ev)
        self.fc1, self.fc1_short = fc_plan(self.fomc, (2, 4, 6))
        self.fc1c, self.fc1c_short = fc_plan(self.fomc, (1, 3, 5))

    def plan(self, cid: str) -> dict:
        """{decision date: (decision ts, exit ts)} of a calendar cell or sub-series (scheduled times)."""
        b, _, sub = cid.partition("@")
        if b in self.pb:
            return self.pb[b][0]
        if b == "PB-USALL-P":
            return self.usall_p[sub]
        if b == "PB-SAME-P":
            return self.same_p
        if b == "REF-F4P":
            return self.f4p[sub]
        if b == "FC-1":
            return self.fc1
        if b == "FC-1C":
            return self.fc1c
        if b in self.ref:
            return self.ref[b]
        raise KeyError(cid)


CAL = Calendar(read_events())


# ------------------------------------------------------------------ cells

def base(cid: str) -> str:
    return cid.split("@")[0]


def long_only(w, t):
    return 1


def plan_decide(cid: str, cal: Calendar = None):
    def decide(w, d):
        v = (cal or CAL).plan(cid).get(d)
        return v[0] if v else None
    return decide


def plan_exit(cid: str, cal: Calendar = None):
    def ex(w, d, t):
        v = (cal or CAL).plan(cid).get(d)
        return v[1] if v and v[0] == t else None
    return ex


# XC-DOLX (section 5): REF-F1's and REF-F4's windows through Round 47's own functions; side from DOL5.

def xc_window(w, d: date):
    """(decision ts, tz, clock, kind) of the earlier REF decision on d (reading R6), or None."""
    c = []
    t1 = F47.f1_decide(w, d)
    if t1 is not None:
        c.append((t1, "NewYork", "14:00", "F1"))
    t4 = F47.f4_decide(w, d)
    if t4 is not None:
        c.append((t4, "London", "12:00", "F4"))
    return min(c) if c else None


def xc_decide(w, d):
    v = xc_window(w, d)
    return v[0] if v else None


def xc_exit(w, d, t):
    v = xc_window(w, d)
    if v is None or v[0] != t:
        return None
    return F47.f1_exit(w, d, t) if v[3] == "F1" else F47.f4_exit(w, d, t)


DOL_LEGS = (("USD_JPY", 1), ("USD_CHF", 1), ("USD_CAD", 1), ("AUD_USD", -1))


def dol5(w, t: int) -> float:
    """DOL5 to the decision t (nan if a leg is missing), with DF-O1's readers: 15-min closes at T and T5 exactly, the
    EUR/USD 1-min close mid at most 15 minutes stale, GBP/USD = EUR/USD / EUR_GBP."""
    d, info = None, None
    for dd in (ny_date(t), lon_date(t)):
        v = xc_window(w, dd)
        if v is not None and v[0] == int(t):
            d, info = dd, v
            break
    if info is None:
        return np.nan
    t5 = local_ts(add_weekdays(d, -5), info[2], info[1])
    T = np.array([t5, int(t)], dtype=np.int64)
    legs = []
    for s, sgn in DOL_LEGS:
        a = X47.Panel._xa(w, s, T)
        legs.append(sgn * np.log(a[1] / a[0]))
    eur, egb = X47.Panel._mid(w, T), X47.Panel._xa(w, "EUR_GBP", T)
    with np.errstate(invalid="ignore", divide="ignore"):
        gbp = eur / egb
        legs.append(-np.log(gbp[1] / gbp[0]))
    x = float(np.mean(legs))
    return x if np.isfinite(x) else np.nan


def xc_signal(w, t):
    x = dol5(w, t)
    if not np.isfinite(x) or x == 0:
        return 0
    return 1 if x > 0 else -1


def _spec(cid):
    s = _SPEC[cid]
    return {"family": s["family"], "rule": s["rule"]}


def _ref(cid47: str, cid: str) -> Cell:
    c = next(c for c in F47.CELLS if c.id == cid47)
    return replace(c, id=cid, selectable=False, **_spec(cid))


def _cal_cell(cid: str, tz: str, at: str, control_of: str = "", selectable: bool = False, spec_id: str = None):
    s = _spec(spec_id or base(cid))
    return Cell(cid, s["family"], tz=tz, at=at, signal=long_only, rule=s["rule"], decide_ts=plan_decide(cid),
                exit_ts=plan_exit(cid), selectable=selectable, control_of=control_of)


def _f4p(clk: str) -> Cell:
    s = _spec("ST-A-P")
    return Cell(f"REF-F4P@{clk}", "REF-F4P component of ST-A-P", tz="London", at="12:00", signal=long_only,
                rule=s["rule"], decide_ts=plan_decide(f"REF-F4P@{clk}"), exit_ts=plan_exit(f"REF-F4P@{clk}"),
                selectable=False, control_of="REF-F4")


CELLS = [
    _ref("PA-F1", "REF-F1"),
    _ref("PA-F4", "REF-F4"),
    _cal_cell("PB-USALL", "NewYork", "14:00", selectable=True),
    _cal_cell("PB-NFP", "NewYork", "14:00"),
    _cal_cell("PB-CPI", "NewYork", "14:00"),
    _cal_cell("PB-MIN", "NewYork", "14:00"),
    _cal_cell("PB-GDP", "NewYork", "14:00"),
    _cal_cell("PB-USALL-P@08:25", "NewYork", "14:00", control_of="PB-USALL"),
    _cal_cell("PB-USALL-P@13:55", "NewYork", "14:00", control_of="PB-USALL"),
    _cal_cell("PB-SAME", "London", "07:00", selectable=True),
    _cal_cell("PB-SAME-P", "London", "07:00", control_of="PB-SAME"),
    Cell("XC-DOLX", _SPEC["XC-DOLX"]["family"], tz="NewYork", at="14:00", signal=xc_signal, rule=_SPEC["XC-DOLX"]["rule"],
         decide_ts=xc_decide, exit_ts=xc_exit, selectable=False),
    _cal_cell("FC-1", "London", "16:00", selectable=True),
    _cal_cell("FC-1C", "London", "16:00", control_of="FC-1"),
    next(c for c in F47.CELLS if c.id == "PA-F1P"),
] + [_f4p(c) for c in sorted(CAL.f4p)]

BY_ID = {c.id: c for c in CELLS}
RUN_IDS = tuple(i for i in BATCH_A if i not in STACKS)          # the 13 cells a look runs (plus the components)


def cells_for(era: str, ids) -> list:
    """The Cell objects (sub-series included) of the given cell or component ids, for one era (reading R7)."""
    out = []
    for c in CELLS:
        b = base(c.id)
        if b not in ids:
            continue
        if b == "REF-F4P" and c.id.split("@")[1] not in CAL.f4_clocks[era]:
            continue
        out.append(c)
    return out


def scheduled(w, cell: Cell, trade: dict) -> tuple:
    """The trade's scheduled window (decision ts, exit ts) from the calendar, not from fills (section 3, Windows)."""
    d = date.fromisoformat(trade["date"])
    t = cell.decide_ts(w, d)
    return int(t), int(cell.exit_ts(w, d, t))


def stratum(control_id: str, trade: dict) -> tuple:
    """Placebo stratum g (sections 3 and 6): the decision date's weekday, plus the scheduled exit clock for the
    controls that name it. `trade` needs 'date' and, for those controls, 'sched_exit_ts'."""
    wd = date.fromisoformat(trade["date"]).weekday()
    tz = CLOCK_TZ.get(base(control_id))
    return (wd, clock(trade["sched_exit_ts"], tz)) if tz else (wd,)
