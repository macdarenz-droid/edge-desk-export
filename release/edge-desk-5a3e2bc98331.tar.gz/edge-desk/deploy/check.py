#!/usr/bin/env python3
"""Server check for the Edge Desk (A9). Run on the server by whoever the owner gives access; its output is the
evidence. Standard library only. It prints PASS or FAIL lines and never prints a secret.

  python3 deploy/check.py memwatch --out var/memwatch.jsonl [--interval 30]
      samples the resident memory of MT5, Wine, Xvfb and the app every interval seconds (run it as the
      edge-memwatch service over one full London and New York day)
  python3 deploy/check.py report --https-url https://<name>.<tailnet>.ts.net [--forbid-host <signer hostname>] \
      [--forbid-machine-id <signer machine id>] [--db var/edge.db] [--mem var/memwatch.jsonl]
      the checks below

Checks (blueprint "Server setup", card A9):
  host        this host is not the meme bot's host: none of its own markers is here (a zeroed-* systemd unit,
              /var/lib/zeroed, the zeroed-signer or zeroed-worker user; the installer's guard uses the same), and its
              hostname and /etc/machine-id differ from any values given
  loopback    the app listens on 127.0.0.1:8787 only (from /proc/net/tcp and tcp6), never on all addresses
  app         http://127.0.0.1:8787/api/health answers 200 on the server
  https       the --https-url answers 200 over HTTPS (Tailscale). The check from the owner's phone is his: open the
              same address in the installed app.
  export      the daily export's last try: FAIL while the export repo is public (nothing is sent to it)
  bridge      the journal's latest snapshot from the EA arrived within the last 60 s (read-only open)
  news        the EA's last EUR and USD calendar post (edge-calendar/2) is within [news] stale_after_min, and the
              server's clock change did not move the stored release times (app/news; PASS when [news] is off);
              FAIL when the move record file was changed. Suffixes: how many seconds after its release the last
              high-impact number arrived (rows held before their release only), how many high-impact rows have no
              family and their names, the move record's state (a pause in Melbourne 12-hour time; "not built yet"
              while the feed has not started it)
  headlines   each Fed and ECB headline feed fetched within [headlines] stale_after_min and none stopped (PASS when
              [headlines] is off); a late feed says until when it waits (its back-off, its host's not-before time
              or a host block); it names the decision windows the stored MT5 rows set for the next 30 days (all
              times Melbourne 12-hour)
  units       every unit active: edge-desk (serve), the virtual display, MT5, memwatch, the Part B units
              (edge-desk-feed, edge-desk-method, edge-desk-leads) when config [feed] is on, and
              edge-desk-headlines when [headlines] is on
  memory      peak resident memory of MT5, Wine, Xvfb and the app (serve, the feed, both workers and the lead
              worker's child) over a sample covering 07:00 London to 17:00 New York, at or under the 1.6 GB working
              ceiling
"""
from __future__ import annotations

import argparse
import json
import socket
import sqlite3
import sys
import time
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

UTC = timezone.utc
LONDON, NEW_YORK = ZoneInfo("Europe/London"), ZoneInfo("America/New_York")
CEILING = 1.6 * 2**30          # bytes: the working ceiling declared in the blueprint (of 2 GB)
PORT = 8787
BASE_UNITS = ("edge-desk.service", "edge-desk-xvfb.service", "edge-desk-mt5.service", "memwatch.service")
PART_B_UNITS = ("edge-desk-feed.service", "edge-desk-method.service", "edge-desk-leads.service")
HEADLINE_UNITS = ("edge-desk-headlines.service",)
UNITS = BASE_UNITS + PART_B_UNITS + HEADLINE_UNITS
HERE = Path(__file__).resolve().parent
EVENTS_FILE = HERE.parent / "app" / "news" / "move_events.json"       # app/news/moverecord.py EVENTS_FILE
RECORD_DIR, RECORD_NAME = "news_record", "move_record.json"           # app/news/moverecord.py
MEME_UNIT_DIRS = ("etc/systemd/system", "lib/systemd/system", "usr/lib/systemd/system", "run/systemd/system",
                  "run/systemd/transient")
MEME_USERS = ("zeroed-signer", "zeroed-worker")
WINE_COMMS = {"wineserver", "wine", "wine64", "wine-preloader", "wine64-preloader", "winedevice.exe",
              "services.exe", "plugplay.exe", "explorer.exe", "rpcss.exe", "svchost.exe", "start.exe",
              "conhost.exe", "tabtip.exe"}


def _read(p: Path) -> str:
    try:
        return p.read_text(errors="replace")
    except OSError:
        return ""


def _group(comm: str, cmdline: str) -> str | None:
    low = cmdline.lower()
    if "terminal64.exe" in low or comm.lower() == "terminal64.exe" or "metaeditor64.exe" in low:
        return "mt5"
    if "-m app" in cmdline or "app/suggest/lead_child.py" in cmdline:
        return "app"                     # serve, feed, both workers and the lead worker's child
    if comm == "Xvfb":
        return "xvfb"
    if comm in WINE_COMMS or comm.endswith(".exe") or "c:\\windows" in low:
        return "wine"
    return None


def sample(proc_root: Path = Path("/proc")) -> dict:
    """Resident memory (bytes) of the Edge Desk's processes by group, matched on comm and cmdline (PIDs change)."""
    groups: dict[str, int] = {}
    for d in proc_root.iterdir():
        if not d.name.isdigit():
            continue
        comm = _read(d / "comm").strip()
        cmdline = _read(d / "cmdline").replace("\0", " ").strip()
        g = _group(comm, cmdline)
        if g is None:
            continue
        rss = 0
        for line in _read(d / "status").splitlines():
            if line.startswith("VmRSS:"):
                rss = int(line.split()[1]) * 1024
        groups[g] = groups.get(g, 0) + rss
    return {"groups": groups, "total": sum(groups.values())}


def memwatch(out: Path, interval: int) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    while True:
        s = sample()
        s["at"] = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        with out.open("a") as fh:
            fh.write(json.dumps(s) + "\n")
        time.sleep(interval)


def _covers_a_day(times: list[datetime]) -> bool:
    """True when the samples run from 07:00 London to 17:00 New York on one weekday, with no gap over 10 minutes."""
    if not times:
        return False
    times = sorted(times)
    for day in sorted({t.astimezone(LONDON).date() for t in times}):
        if day.weekday() > 4:
            continue
        start = datetime(day.year, day.month, day.day, 7, tzinfo=LONDON)
        end = datetime(day.year, day.month, day.day, 17, tzinfo=NEW_YORK)
        inside = [t for t in times if start - timedelta(minutes=10) <= t <= end + timedelta(minutes=10)]
        if not inside or inside[0] > start + timedelta(minutes=10) or inside[-1] < end - timedelta(minutes=10):
            continue
        if all((b - a) <= timedelta(minutes=10) for a, b in zip(inside, inside[1:])):
            return True
    return False


def memory_verdict(log: Path, ceiling: float = CEILING) -> dict:
    rows = [json.loads(x) for x in _read(log).splitlines() if x.strip()]
    if not rows:
        return {"ok": False, "detail": f"no samples in {log}", "peak_mb": None}
    times = [datetime.strptime(r["at"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC) for r in rows]
    peak = max(r["total"] for r in rows)
    day = _covers_a_day(times)
    ok = day and peak <= ceiling
    return {"ok": ok, "peak_mb": peak / 2**20, "samples": len(rows),
            "detail": f"peak {peak / 2**20:.0f} MB of {ceiling / 2**20:.0f} MB ceiling; "
                      f"{len(rows)} samples {times[0]:%d %b %H:%M}-{times[-1]:%d %b %H:%M} UTC; "
                      + ("covers a London and New York day" if day else "does NOT cover 07:00 London to 17:00 New York")}


def listeners(tcp_file: Path, port: int) -> list[str]:
    """Local addresses listening on `port` in a /proc/net/tcp file (IPv4) or tcp6 (shown as ::1 or ::)."""
    out = []
    for line in _read(tcp_file).splitlines()[1:]:
        parts = line.split()
        if len(parts) < 4 or parts[3] != "0A":
            continue
        addr, hexport = parts[1].split(":")
        if int(hexport, 16) != port:
            continue
        if len(addr) == 8:
            out.append(socket.inet_ntoa(bytes.fromhex(addr)[::-1]))
        else:
            raw = bytes.fromhex(addr)
            words = b"".join(raw[i:i + 4][::-1] for i in range(0, 16, 4))
            out.append(socket.inet_ntop(socket.AF_INET6, words))
    return out


def meme_markers(root: Path = Path("/")) -> list[str]:
    """The meme bot host's own markers found under root (the same list as deploy/install/guard.sh)."""
    found = []
    for d in MEME_UNIT_DIRS:
        base = root / d
        if base.is_dir():
            found += [f"/{d}/{p.name}" for p in sorted(base.glob("zeroed-*"))]
    if (root / "var/lib/zeroed").exists():
        found.append("/var/lib/zeroed")
    users = {ln.split(":", 1)[0] for ln in _read(root / "etc/passwd").splitlines()}
    found += [f"user {u}" for u in MEME_USERS if u in users]
    return found


def host_ok(hostname: str, machine_id: str, forbid_hosts: list[str], forbid_ids: list[str],
            markers: list[str] | None = None) -> dict:
    """With markers given (the report), the markers decide, and any hostname or machine id given counts on top.
    Without them, only the values given can show it, and none given proves nothing."""
    if markers is None and not forbid_hosts and not forbid_ids:
        return {"ok": False, "detail": "give --forbid-host (and --forbid-machine-id) of the meme bot's signer host"}
    if markers:
        return {"ok": False, "detail": "this IS the meme bot's host (" + ", ".join(markers) + "): stop"}
    bad = hostname in forbid_hosts or (machine_id and machine_id in forbid_ids)
    return {"ok": not bad, "detail": ("this IS the signer host: stop" if bad else
                                      f"no meme bot marker here; hostname {hostname}")}


def bridge_ok(db_path: Path, now: datetime, max_age_s: int = 60) -> dict:
    try:
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        row = con.execute("SELECT last_seen_utc, last_seq, last_reason, trade_allowed FROM bridge_status"
                          " ORDER BY last_seen_utc DESC LIMIT 1").fetchone()
        con.close()
    except sqlite3.Error as exc:
        return {"ok": False, "detail": f"journal not readable: {type(exc).__name__}", "seq": None}
    if row is None:
        return {"ok": False, "detail": "no snapshot from the EA yet", "seq": None}
    seen = datetime.strptime(row[0], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    age = (now - seen).total_seconds()
    ok = age <= max_age_s and not row[3]
    return {"ok": ok, "seq": row[1], "detail": f"last snapshot {age:.0f} s ago, seq {row[1]}, reason {row[2]}"
            + ("; TERMINAL CAN TRADE: log in with the investor password" if row[3] else "")}


PUBLIC_REASON = "the export repo is public"       # app/export/daily.py PUBLIC_REASON


def export_enabled(config: Path) -> bool:
    import tomllib
    try:
        return bool(tomllib.loads(_read(config)).get("export", {}).get("enabled"))
    except tomllib.TOMLDecodeError:
        return False


def export_ok(db_path: Path, enabled: bool) -> dict:
    """The daily export's last try (read-only): FAIL while the export repo is public or the last try failed."""
    if not enabled:
        return {"ok": True, "detail": "off (Part B is off)"}
    try:
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        row = con.execute("SELECT status, detail, made_utc FROM worker_run WHERE worker = 'export'"
                          " ORDER BY id DESC LIMIT 1").fetchone()
        con.close()
    except sqlite3.Error as exc:
        return {"ok": False, "detail": f"journal not readable: {type(exc).__name__}"}
    if row is None:
        return {"ok": True, "detail": "nothing sent yet (the first export is after 17:05 New York)"}
    if row[0] == "sent":
        return {"ok": True, "detail": f"last sent {row[2]}"}
    if PUBLIC_REASON in (row[1] or ""):
        return {"ok": False, "detail": f"{PUBLIC_REASON}: nothing is sent until it is private"}
    return {"ok": False, "detail": f"last try {row[2]} failed: {(row[1] or '')[:120]}"}


def _news_config(config: Path) -> dict:
    import tomllib
    try:
        news = tomllib.loads(_read(config)).get("news", {})
    except tomllib.TOMLDecodeError:
        news = {}
    return news if isinstance(news, dict) else {}


def _sha256(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()


def record_status(db_path: Path, meta: dict, events_file: Path = EVENTS_FILE) -> tuple[str | None, bool]:
    """(suffix or None, broken): the move record built on this server (app/news/moverecord.py; ruling R7)."""
    path = db_path.parent / RECORD_DIR / RECORD_NAME
    if path.exists():
        try:
            doc = json.loads(path.read_bytes())
            ok = _sha256(json.dumps(doc["rows"], sort_keys=True, separators=(",", ":")).encode()) == doc["rows_sha256"]
        except (OSError, ValueError, KeyError, TypeError):
            ok = False
        if not ok:
            return None, True
        try:
            current = _sha256(events_file.read_bytes())
        except OSError:
            current = None
        if current is None or doc.get("events_sha256") == current:
            return f"move record: {len(doc['rows'])} event types", False
    try:
        st = json.loads(meta.get("news.record.state") or "null")
    except ValueError:
        st = None
    if st is None:                                     # no file and no job state: the feed has not started it
        return "move record not built yet (it starts with the OANDA feed)", False
    if not isinstance(st, dict):
        return None, False
    s = st.get("state")
    if s == "building":
        return f"move record building: {int(st.get('done') or 0)} of {int(st.get('total') or 0)} price windows", False
    if s == "paused":
        return f"move record paused{_until_melb(st.get('next_try_utc'))} ({str(st.get('error') or '')[:60]})", False
    if s == "halted":
        return "move record stopped: python -m app feed --reset-record", False
    return None, False


MELBOURNE = ZoneInfo("Australia/Melbourne")


def _melb(iso) -> str:
    """"Sat 7 Nov 2:00 am Melbourne" from a stored UTC time (the owner reads Melbourne 12-hour times); "" if bad."""
    try:
        t = datetime.strptime(str(iso), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC).astimezone(MELBOURNE)
    except ValueError:
        return ""
    return f"{t:%a} {t.day} {t:%b} {t.hour % 12 or 12}:{t:%M} {'am' if t.hour < 12 else 'pm'} Melbourne"


def _until_melb(iso) -> str:
    """ " until Sat 7 Nov 2:00 am Melbourne" from a stored UTC time."""
    m = _melb(iso)
    return f" until {m}" if m else ""


UNMAPPED_SHOWN = 5


def _unmapped(con: sqlite3.Connection) -> list[str] | None:
    """'<country> <name>' of the high-impact EUR or USD rows with no family (app/news/families.py), or None when
    that cannot be read: the names a wrong pattern in the family table needs."""
    try:
        sys.path.insert(0, str(HERE.parent))
        from app.news.families import family_of
        rows = con.execute("SELECT DISTINCT country, name FROM news_event WHERE impact = 'high' AND kind != 'holiday'"
                           " AND currency IN ('EUR', 'USD')").fetchall()
    except (ImportError, sqlite3.Error):
        return None
    return sorted(f"{c} {n}".strip() for c, n in rows if family_of(c, n) is None)


def news_ok(db_path: Path, config: Path, now: datetime) -> dict:
    """The EA's calendar posts (read-only): PASS when [news] is off; FAIL with none yet, when the last one is older
    than [news] stale_after_min, or when the server's clock change moved the stored times (news spec 7.3: the
    coordinator then switches the conversion)."""
    news = _news_config(config)
    if news.get("enabled", True) is False:
        return {"ok": True, "detail": "off in config"}
    stale = news.get("stale_after_min", 30)
    try:
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        got = dict(con.execute("SELECT key, value FROM meta WHERE key IN ('news.last_ok_utc', 'news.clock_check',"
                               " 'news.record.state')"))
        rows = con.execute("SELECT COUNT(*) FROM news_event").fetchone()[0] if got else 0
        try:
            # only a row the app held before its release says how late the number came (not one first stored
            # after it: a new install or an EA outage)
            lag = con.execute("SELECT event_utc, actual_first_utc FROM news_event WHERE impact = 'high'"
                              " AND actual_first_utc IS NOT NULL AND time_mode = 'exact' AND first_seen_utc < event_utc"
                              " ORDER BY event_utc DESC LIMIT 1").fetchone()
            have_lag = True
        except sqlite3.Error:                    # a journal from before these columns: no lag suffix
            lag, have_lag = None, False
        unmapped = _unmapped(con)
        con.close()
    except sqlite3.Error as exc:
        return {"ok": False, "detail": f"journal not readable: {type(exc).__name__}"}
    rec, broken = record_status(db_path, got) if news.get("show_record", True) is not False else (None, False)
    if broken:
        return {"ok": False, "detail": "move record file changed: delete var/news_record/move_record.json and the "
                                       "feed builds it again"}
    if "news.last_ok_utc" not in got:
        return {"ok": False, "detail": "no calendar from the EA yet"}
    seen = datetime.strptime(got["news.last_ok_utc"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    age = int((now - seen).total_seconds() // 60)
    if age > stale:
        return {"ok": False, "detail": f"last calendar {age} min ago (stale after {stale} min)"}
    try:
        cc = json.loads(got.get("news.clock_check") or "null")
    except ValueError:
        cc = None
    if isinstance(cc, dict):
        held, moved, on = int(cc.get("held", 0)), int(cc.get("moved", 0)), str(cc.get("at", ""))[:10]
        if moved > 0 and moved >= held:
            return {"ok": False, "detail": f"times moved at the server's clock change on {on} ({moved} rows): the "
                                           "coordinator switches the conversion"}
        seen_change = f"clock change on {on}: {held} held"
    else:
        seen_change = "no clock change seen yet"
    extra = ""
    if have_lag:
        if lag is None:
            extra += "; no high-impact number seen yet"
        else:
            t = lambda s: datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)     # noqa: E731
            extra += f"; numbers: last high-impact number {int((t(lag[1]) - t(lag[0])).total_seconds())} s after its" \
                     " release (MT5)"
    if unmapped:
        names = ", ".join(unmapped[:UNMAPPED_SHOWN]) + (f" +{len(unmapped) - UNMAPPED_SHOWN} more"
                                                         if len(unmapped) > UNMAPPED_SHOWN else "")
        extra += f"; {len(unmapped)} high-impact rows with no family ({names})"
    if rec:
        extra += f"; {rec}"
    return {"ok": True, "detail": f"last calendar {age} min ago, {rows} rows; {seen_change}{extra}"}


def _headlines_config(config: Path) -> dict:
    import tomllib
    try:
        h = tomllib.loads(_read(config)).get("headlines", {})
    except tomllib.TOMLDecodeError:
        h = {}
    return h if isinstance(h, dict) else {}


def headlines_enabled(config: Path) -> bool:
    return _headlines_config(config).get("enabled", True) is True


HEADLINE_LABELS = {"fed_policy": "Fed policy", "fed_speeches": "Fed speeches", "ecb_press": "ECB press"}
HEADLINE_HOSTS = {"fed_policy": "www.federalreserve.gov", "fed_speeches": "www.federalreserve.gov",
                  "ecb_press": "www.ecb.europa.eu"}           # as app/news/headlines.py SOURCES


def headlines_ok(db_path: Path, config: Path, now: datetime) -> dict:
    """The Fed and ECB headline feeds (read-only): PASS when [headlines] is off; FAIL when a feed is stopped, has no
    good fetch yet, or none within [headlines] stale_after_min. Names the decision windows of the next 30 days."""
    h = _headlines_config(config)
    if h.get("enabled", True) is False:
        return {"ok": True, "detail": "off in config"}
    sources = [s for s in h.get("sources", list(HEADLINE_LABELS)) if s in HEADLINE_LABELS]
    stale = h.get("stale_after_min", 30)
    try:
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        meta = dict(con.execute("SELECT key, value FROM meta WHERE key LIKE 'headlines.%'"))
        try:
            blocks = dict(con.execute("SELECT host, MAX(until_utc) FROM feed_block GROUP BY host"))
        except sqlite3.Error:
            blocks = {}
        try:
            dec = con.execute("SELECT country, name, event_utc FROM news_event WHERE impact = 'high' AND"
                              " time_mode = 'exact' AND event_utc >= ? AND event_utc <= ? ORDER BY event_utc",
                              (now.strftime("%Y-%m-%dT%H:%M:%SZ"),
                               (now + timedelta(days=30)).strftime("%Y-%m-%dT%H:%M:%SZ"))).fetchall()
        except sqlite3.Error:
            dec = []
        con.close()
    except sqlite3.Error as exc:
        return {"ok": False, "detail": f"journal not readable: {type(exc).__name__}"}
    def waits(s: str) -> str:
        """", waits until <Melbourne time>" while the feed's back-off, its host's not-before time or a host block
        is still ahead (fix round 2)."""
        ahead = []
        for v in (meta.get(f"headlines.{s}.stopped_until"), meta.get(f"headlines.{HEADLINE_HOSTS[s]}.not_before")):
            try:
                if v is not None and float(v) > now.timestamp():
                    ahead.append(datetime.fromtimestamp(float(v), UTC))
            except ValueError:
                continue
        b = blocks.get(HEADLINE_HOSTS[s])
        try:
            if b is not None and datetime.strptime(b, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC) > now:
                ahead.append(datetime.strptime(b, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC))
        except ValueError:
            pass
        return f", waits until {_melb(max(ahead).strftime('%Y-%m-%dT%H:%M:%SZ'))}" if ahead else ""

    bad, parts = [], []
    for s in sources:
        if meta.get(f"headlines.{s}.halted"):
            bad.append(f"{HEADLINE_LABELS[s]} stopped ({meta[f'headlines.{s}.halted'][:60]}): python -m app headlines "
                       "--reset-halt")
            continue
        last = meta.get(f"headlines.{s}.last_ok_utc")
        if last is None:
            bad.append(f"{HEADLINE_LABELS[s]}: no good fetch yet{waits(s)}")
            continue
        age = int((now - datetime.strptime(last, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)).total_seconds() // 60)
        if age > stale:
            bad.append(f"{HEADLINE_LABELS[s]} last fetched {age} min ago (stale after {stale} min){waits(s)}")
        else:
            parts.append(f"{HEADLINE_LABELS[s]} {age} min ago")
    windows = []
    try:
        sys.path.insert(0, str(HERE.parent))
        from app.news.families import family_of
        for c, n, t in dec:
            f = family_of(c, n)
            if f is not None and f.key in ("US_FED_RATE", "EU_ECB_MRO"):
                windows.append(("Fed " if f.key == "US_FED_RATE" else "ECB ") + (_melb(t) or t))
    except ImportError:
        pass
    tail = "; decision windows: " + (", ".join(windows) if windows else "none in the next 30 days")
    if bad:
        return {"ok": False, "detail": "; ".join(bad) + tail}
    return {"ok": True, "detail": ", ".join(parts) + tail}


def _unit_state(unit: str) -> str:
    import subprocess
    try:
        r = subprocess.run(["systemctl", "is-active", unit], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError) as exc:
        return f"unknown ({type(exc).__name__})"
    return (r.stdout or r.stderr).strip() or "unknown"


def required_units(feed_on: bool, headlines_on: bool = False) -> tuple[str, ...]:
    return BASE_UNITS + (PART_B_UNITS if feed_on else ()) + (HEADLINE_UNITS if headlines_on else ())


def feed_enabled(config: Path) -> bool | None:
    """[feed] enabled from the app's config; None when it cannot be read (the units line then fails)."""
    import tomllib
    text = _read(config)
    if not text:
        return None
    try:
        return bool(tomllib.loads(text).get("feed", {}).get("enabled"))
    except tomllib.TOMLDecodeError:
        return None


def units_ok(state=None, feed_on: bool | None = True, headlines_on: bool = False) -> dict:
    """Every Edge Desk unit that should run is active (systemctl is-active); Part B's only when [feed] is on, the
    headline worker only when [headlines] is on."""
    if feed_on is None:
        return {"ok": False, "detail": "config/app.toml could not be read, so which units should run is not known"}
    state = state or _unit_state
    units = required_units(feed_on, headlines_on)
    got = {u: state(u) for u in units}
    bad = {u: s for u, s in got.items() if s != "active"}
    return {"ok": not bad, "detail": "all active: " + ", ".join(units) if not bad else
            "not active: " + ", ".join(f"{u} ({s})" for u, s in bad.items())}


def _http_ok(url: str) -> dict:
    try:
        with urllib.request.urlopen(url, timeout=10) as r:      # noqa: S310 - a fixed health URL
            return {"ok": r.status == 200, "detail": f"{url} answered {r.status}"}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "detail": f"{url}: {type(exc).__name__}"}


TODO = {
    "host": "this is the meme bot's server: install the Edge Desk on the other server",
    "loopback": "the app must listen on 127.0.0.1:8787 only: check config [app] host",
    "app": "the app does not answer: journalctl -u edge-desk",
    "https": "HTTPS through Tailscale does not answer yet",
    "units": "a service is not running (the units line names it)",
    "bridge": "no snapshot from MT5 yet: the terminal must reach the broker, logged in with the investor password",
    "news": "no news from MT5 yet: the EA sends the calendar once the terminal is connected (the bridge line must "
            "pass first)",
    "headlines": "Fed or ECB headlines are not arriving (the headlines line says which feed and why)",
    "export": "the daily export (the export line says why; a public export repo gets nothing until it is made "
              "private in GitHub, Settings, Danger Zone)",
    "memory": "the memory sample over one full London and New York day (memwatch runs; run this report again "
              "after 5:00 pm New York on a weekday)",
}


def todo(results: list, oanda: bool, tailscale: bool) -> list[str]:
    """One "missing:" line per item still open after the install, in the owner's words."""
    out = [f"missing: {TODO[name]}" for name, r in results if not r.get("ok") and name in TODO]
    if not tailscale:
        out.append("missing: Tailscale: paste the install line again with an auth key (tskey-...)")
    if not oanda:
        out.append("missing: the OANDA practice token, so suggestions and paper leads stay off (optional; paste the "
                   "install line again to add it)")
    if any(name == "bridge" and not r.get("ok") for name, r in results):
        out.append("missing: MT5 check: the bridge line passes once the EA's snapshots arrive")
    out.append("missing: the phone check (yours): open the app over HTTPS, add it to the Home Screen, "
               "send a test alert")
    return out


def report(args) -> int:
    lines = []
    hostname = socket.gethostname()
    mid = _read(Path("/etc/machine-id")).strip()
    lines.append(("host", host_ok(hostname, mid, args.forbid_host, args.forbid_machine_id, markers=meme_markers())))
    addrs = listeners(Path("/proc/net/tcp"), PORT) + listeners(Path("/proc/net/tcp6"), PORT)
    lines.append(("loopback", {"ok": bool(addrs) and set(addrs) <= {"127.0.0.1", "::1"},
                               "detail": f"port {PORT} listens on {addrs or 'nothing'}"}))
    lines.append(("app", _http_ok(f"http://127.0.0.1:{PORT}/api/health")))
    lines.append(("https", _http_ok(args.https_url.rstrip("/") + "/api/health") if args.https_url else
                  {"ok": False, "detail": "give --https-url (the Tailscale https address)"}))
    lines.append(("units", units_ok(feed_on=feed_enabled(Path(args.config)),
                                    headlines_on=headlines_enabled(Path(args.config)))))
    lines.append(("bridge", bridge_ok(Path(args.db), datetime.now(UTC))))
    lines.append(("news", news_ok(Path(args.db), Path(args.config), datetime.now(UTC))))
    lines.append(("headlines", headlines_ok(Path(args.db), Path(args.config), datetime.now(UTC))))
    lines.append(("export", export_ok(Path(args.db), export_enabled(Path(args.config)))))
    lines.append(("memory", memory_verdict(Path(args.mem))))
    for name, r in lines:
        print(f"{'PASS' if r['ok'] else 'FAIL'} {name}: {r['detail']}")
    print(f"checked {datetime.now(UTC):%Y-%m-%d %H:%M} UTC on {hostname}")
    if args.todo:
        for line in todo(lines, oanda=args.oanda == "yes", tailscale=args.tailscale == "yes"):
            print(line)
    return 0 if all(r["ok"] for _, r in lines) else 1


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="deploy/check.py", description="Edge Desk server check (report, memwatch)")
    sub = p.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("memwatch", help="sample resident memory of MT5, Wine, Xvfb and the app")
    m.add_argument("--out", default="var/memwatch.jsonl")
    m.add_argument("--interval", type=int, default=30)
    r = sub.add_parser("report", help="print the PASS / FAIL checks")
    r.add_argument("--https-url", default="")
    r.add_argument("--forbid-host", action="append", default=[])
    r.add_argument("--forbid-machine-id", action="append", default=[])
    r.add_argument("--db", default="var/edge.db")
    r.add_argument("--mem", default="var/memwatch.jsonl")
    r.add_argument("--config", default="config/app.toml")
    r.add_argument("--todo", action="store_true", help="also list what is still missing (the installer's finish)")
    r.add_argument("--oanda", choices=("yes", "no"), default="no")
    r.add_argument("--tailscale", choices=("yes", "no"), default="no")
    args = p.parse_args(argv)
    if args.cmd == "memwatch":
        memwatch(Path(args.out), max(5, args.interval))
        return 0
    return report(args)


if __name__ == "__main__":
    sys.exit(main())
