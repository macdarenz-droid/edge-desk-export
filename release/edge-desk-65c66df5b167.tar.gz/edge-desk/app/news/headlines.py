"""Headlines from the Federal Reserve's and the ECB's own RSS feeds (HEADLINES.md; coordinator ruling R3).

Three feeds only, a hard allow-list (any other host, path or query raises PathRefused before anything is sent):
  fed_policy    https://www.federalreserve.gov/feeds/press_monetary.xml          statements, minutes, policy
  fed_speeches  https://www.federalreserve.gov/feeds/speeches_and_testimony.xml  speeches, testimony
  ecb_press     https://www.ecb.europa.eu/rss/press.html                         decisions, releases, speeches
Terms (read 19 Oct 2026; re-read before each release): the Fed's site is public domain ("Please cite to the Board as
the source of the information"); the ECB's disclaimer (https://www.ecb.europa.eu/home/disclaimer/html/index.en.html)
says "users of this website may make free use of the information obtained directly from it" and "When such
information is distributed or reproduced, it must appear accurately and the ECB must be cited as the source." So a
title is kept verbatim (whitespace collapsed only) and always shown with its source, "Fed" or "ECB". Only title,
link, guid, publication time and category are read: never a description or an article body.

Limits: neither host documents a rate limit (the Fed has no robots.txt; the ECB's asks Crawl-delay 5, so 10 s between
requests to one host is half that rate, kept across restarts in meta headlines.<host>.last_request_ts). Normal polls
every headlines.poll_s (Fed speeches headlines.speeches_poll_s); around a Fed decision every window_poll_s from 1 min
before to 10 min after it, around an ECB decision every max(60, window_poll_s) from 1 min before to 15 min after
(the decision times are the stored MT5 rows' own). The ECB feed is never read twice inside its max-age of 60 s. The
Fed gets If-None-Match and If-Modified-Since (a 304 saves nothing); the ECB re-tags the same body, so a body whose
sha256 equals the last one is not parsed again. A 403 or 429 blocks the host for max(24 h, Retry-After) (feed_block,
shared with the OANDA feed's table, keyed by host). One gate per host (fix round 2, red team B1; the two Fed feeds
share www.federalreserve.gov): any failure the host answered, from either of its feeds, adds one to the host's run
(meta headlines.<host>.failures) and moves its not-before time (headlines.<host>.not_before) to at least now +
Retry-After, a 5xx or network error to at least now + 2^n s, and the third in a row to at least now + max(30 min,
Retry-After); a success clears the run. due() and Client.get send nothing to that host before it (HostWait), after a
restart too. Each feed also keeps its own back-off: a 5xx or a network error waits max(Retry-After, 2^n s), and 3 in
a row cool the feed down max(30 min, Retry-After); a 404, a 3xx, a wrong content type, a body over 1 MiB, a DOCTYPE or
ENTITY, a body that is not plain UTF-8 RSS (it must start with <?xml or <rss after an optional UTF-8 byte order mark
and hold no NUL byte, so a UTF-16 body cannot hide a DOCTYPE from the byte check), or a body that does not parse
halts that feed until `python -m app headlines --reset-halt` (which clears halts only, never a wait a server asked
for) and queues one headlines_halted alert a day. Nothing is saved while storage.raw_allowed() is False. Rows
(news_headline) are kept headlines.keep_days, at most HEADLINE_MAX_ROWS, never exported. The items a body drops are
counted (headlines.<source>.dropped); the first ECB decision item is logged once (HEADLINES 14 H3).

The push (headline_policy, priority 3): a Fed FOMC statement or an ECB decision, once (key headline_policy:<id>), only
when it was first seen within 20 minutes of its publication time, at most 4 a UTC day; fixed app text (never the
third-party title); the push expires after 15 minutes and a queued one older than that is skipped.
"""
from __future__ import annotations

import email.utils
import hashlib
import http.client
import logging
import re
import sqlite3
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Callable
from urllib.parse import urlsplit, urlunsplit

from app import db, storage
from app.feed.oanda import OPENER, _retry_after, blocked_until
from app.notify.alerts import Alert
from app.timeutil import fmt_melbourne_12, from_iso, to_iso

log = logging.getLogger("app.news.headlines")

UTC = timezone.utc
SOURCES = {
    "fed_policy": ("www.federalreserve.gov", "/feeds/press_monetary.xml", "text/xml"),
    "fed_speeches": ("www.federalreserve.gov", "/feeds/speeches_and_testimony.xml", "text/xml"),
    "ecb_press": ("www.ecb.europa.eu", "/rss/press.html", "application/rss+xml"),
}
ALLOWED = frozenset((host, path) for host, path, _ in SOURCES.values())
LABEL = {"fed_policy": "Fed", "fed_speeches": "Fed", "ecb_press": "ECB"}
FEED_NAME = {"fed_policy": "Fed policy", "fed_speeches": "Fed speeches", "ecb_press": "ECB press"}   # as check.py
PUSH_KIND = {"fed_policy": "Fed statements", "ecb_press": "ECB decisions"}     # the feeds the policy push reads
HOST_GAP_S = 10.0
ECB_MIN_GAP_S = 60.0                  # the ECB feed's own max-age
MAX_BODY = 1024 * 1024
MAX_TITLE = 500
MAX_LINK = 500
FUTURE_S = 600                        # a pubDate more than 10 min ahead of now is dropped
FRESH_S = 20 * 60                     # a policy push only for an item first seen within 20 min of its publication
PUSH_DAILY_CAP = 4
PUSH_SKIP_S = 15 * 60
COOLDOWN_S = 1800
MAX_FAILURES = 3
BLOCK_HOURS = 24
HEADLINE_MAX_ROWS = 1000
FED_WINDOW = (-60, 600)               # around a Fed decision: 1 min before to 10 min after
ECB_WINDOW = (-60, 900)               # around an ECB decision: 1 min before to 15 min after
KINDS = ("statement", "minutes", "policy", "speech", "testimony", "decision", "release", "interview", "accounts",
         "other")
KIND_LABEL = {"statement": "Statement", "minutes": "Minutes", "policy": "Policy", "speech": "Speech",
              "testimony": "Testimony", "decision": "Decision", "release": "Release", "interview": "Interview",
              "accounts": "Accounts", "other": "Other"}
_CTRL = re.compile(r"[\x00-\x1f\x7f-\x9f]")
_RAW_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")     # tab, LF and CR are whitespace; the rest drop
_RSS_START = re.compile(rb"(?:\xef\xbb\xbf)?<(?:\?xml|rss)\b")
_ECB_DECISION = re.compile(r"^/press/pr/date/\d{4}/html/ecb\.mp\d{6}~[0-9a-f]+\.en\.html$")
_BANNED_XML = re.compile(rb"<!\s*(DOCTYPE|ENTITY)", re.I)
VERSION = "0.2"


class HeadlineError(RuntimeError):
    """A failed fetch. retryable: a 5xx or a network error; fatal: anything else (the feed halts)."""

    def __init__(self, msg: str, code: int | None = None, retry_after: float | None = None, retryable=False):
        super().__init__(msg)
        self.code, self.retry_after, self.retryable = code, retry_after, retryable


class PathRefused(HeadlineError):
    """A host, path or query outside the allow-list: raised before anything is sent."""


class Blocked(HeadlineError):
    """A 403 or 429: the host is blocked (feed_block)."""


class HostWait(HeadlineError):
    """The host's not-before time is still ahead (a Retry-After, a back-off or a cool-down): nothing was sent."""

    def __init__(self, msg: str, until: float):
        super().__init__(msg)
        self.until = until


# ---------------------------------------------------------------- state (meta, prefixed keys)

def _meta(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return None if row is None else row[0]


def _put(conn: sqlite3.Connection, key: str, value) -> None:
    with db.transaction(conn):
        if value is None:
            conn.execute("DELETE FROM meta WHERE key = ?", (key,))
        else:
            conn.execute("INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET "
                         "value = excluded.value", (key, str(value)))


def _k(source: str, name: str) -> str:
    return f"headlines.{source}.{name}"


def reset_halt(conn: sqlite3.Connection, source: str | None = None) -> None:
    """python -m app headlines --reset-halt: clears halts only. A feed's back-off or cool-down and its host's
    not-before time (a server's Retry-After among them) and a host block run out by themselves (fix round 2)."""
    with db.transaction(conn):
        for s in ([source] if source else list(SOURCES)):
            conn.execute("DELETE FROM meta WHERE key = ?", (_k(s, "halted"),))


def source_state(conn: sqlite3.Connection, source: str) -> dict:
    return {k: _meta(conn, _k(source, k)) for k in ("last_ok_utc", "halted", "stopped_until", "failures", "dropped")}


# ---------------------------------------------------------------- one gate per host (fix round 2, red team B1)

def _hk(host: str, name: str) -> str:
    return f"headlines.{host}.{name}"


def host_state(conn: sqlite3.Connection, host: str) -> dict:
    return {k: _meta(conn, _hk(host, k)) for k in ("failures", "not_before")}


def host_wait(conn: sqlite3.Connection, host: str, now_ts: float) -> float | None:
    """The host's not-before time while it is still ahead, else None. An unreadable value holds the host for the
    cool-down from now (never a reason to send)."""
    v = _meta(conn, _hk(host, "not_before"))
    if v is None:
        return None
    try:
        t = float(v)
    except ValueError:
        return now_ts + COOLDOWN_S
    return t if t > now_ts else None


def _host_failed(conn: sqlite3.Connection, host: str, exc: HeadlineError, now_ts: float) -> None:
    """One more failure in a row at this host, whichever of its feeds got it: Retry-After, the 2^n s back-off for a
    5xx or a network error, and on the third in a row max(30 min, Retry-After) move the not-before time (never
    earlier than it was); the run then starts again."""
    try:
        n = int(_meta(conn, _hk(host, "failures")) or 0) + 1
    except ValueError:
        n = MAX_FAILURES
    wait = float(exc.retry_after or 0.0)
    if exc.retryable:
        wait = max(wait, 2.0 ** n)
    if n >= MAX_FAILURES:
        wait, n = max(wait, COOLDOWN_S), 0
        log.warning("headlines: %s failures in a row at %s: no request for %s s", MAX_FAILURES, host, int(wait))
    _put(conn, _hk(host, "failures"), n)
    if wait > 0:
        cur = host_wait(conn, host, now_ts)
        _put(conn, _hk(host, "not_before"), repr(max(cur or 0.0, now_ts + wait)))


def _host_ok(conn: sqlite3.Connection, host: str) -> None:
    if _meta(conn, _hk(host, "failures")) not in (None, "0"):
        _put(conn, _hk(host, "failures"), 0)


# ---------------------------------------------------------------- the client

class Client:
    """GET of the three feeds only. base_url: None for the real hosts, or http://127.0.0.1:<port> in tests (the
    request then goes there, while gaps and blocks still count against the source's own host)."""

    def __init__(self, conn: sqlite3.Connection | None = None, base_url: str | None = None, clock=time.time,
                 sleep=time.sleep, timeout_s: float = 20.0):
        if base_url is not None:
            u = urlsplit(base_url)
            if not (u.scheme == "http" and u.hostname == "127.0.0.1") or u.path not in ("", "/") or u.query:
                raise PathRefused("headlines read only the Fed and ECB feeds (or http://127.0.0.1 in tests)")
            base_url = base_url.rstrip("/")
        self.conn, self.base_url, self.clock, self.sleep, self.timeout_s = conn, base_url, clock, sleep, timeout_s

    def url(self, host: str, path: str) -> str:
        if (host, path) not in ALLOWED:
            raise PathRefused("feed not allowed")
        return f"{self.base_url}{path}" if self.base_url else f"https://{host}{path}"

    def check(self, url: str) -> None:
        """Refuse any URL whose host and path are not one of the three feeds, or that has a query or fragment."""
        u = urlsplit(url)
        if u.query or u.fragment or u.username or u.password:
            raise PathRefused("query, fragment or user info refused")
        if self.base_url and url.startswith(self.base_url + "/"):
            if not any(u.path == p for _, p in ALLOWED):
                raise PathRefused("path not allowed")
            return
        if u.scheme != "https" or (u.hostname, u.path) not in ALLOWED or u.port is not None:
            raise PathRefused("host or path not allowed")

    def _gap(self, host: str) -> None:
        if self.conn is None:
            return
        last = _meta(self.conn, f"headlines.{host}.last_request_ts")
        if last is not None:
            wait = float(last) + HOST_GAP_S - self.clock()
            if wait > 0:
                self.sleep(wait)
        _put(self.conn, f"headlines.{host}.last_request_ts", repr(self.clock()))

    def _block(self, host: str, code: int, retry_after: float | None) -> float:
        now = self.clock()
        until = now + max(BLOCK_HOURS * 3600.0, retry_after or 0.0)
        if self.conn is not None:
            with db.transaction(self.conn):
                self.conn.execute("INSERT INTO feed_block (host, code, blocked_utc, until_utc, retry_after)"
                                  " VALUES (?, ?, ?, ?, ?)", (host, int(code), _iso(now), _iso(until),
                                                              None if retry_after is None else str(int(retry_after))))
        return until

    def get(self, source: str, etag: str | None = None, modified: str | None = None) -> tuple[int, bytes, dict]:
        """(status, body, headers) for 200 or 304; raises HeadlineError for anything else."""
        host, path, ctype = SOURCES[source]
        url = self.url(host, path)
        self.check(url)
        if self.conn is not None:
            b = blocked_until(self.conn, host, self.clock())
            if b is not None:
                raise Blocked(f"host blocked until {_iso(b)}")
            nb = host_wait(self.conn, host, self.clock())
            if nb is not None:
                raise HostWait(f"host waits until {_iso(nb)}", nb)
        headers = {"User-Agent": f"EdgeDesk/{VERSION} (personal, single user)",
                   "Accept": "application/rss+xml, application/xml;q=0.9", "Connection": "close"}
        if etag:
            headers["If-None-Match"] = etag
        if modified:
            headers["If-Modified-Since"] = modified
        self._gap(host)
        req = urllib.request.Request(url, method="GET", headers=headers)
        try:
            with OPENER.open(req, timeout=self.timeout_s) as r:
                body = r.read(MAX_BODY + 1)
                got = {k.lower(): v for k, v in r.headers.items()}
                status = r.status
        except urllib.error.HTTPError as e:
            code, ra = e.code, _retry_after(e.headers.get("Retry-After") if e.headers else None)
            e.close()
            if code == 304:
                return 304, b"", {}
            if code in (403, 429):
                until = self._block(host, code, ra)
                raise Blocked(f"HTTP {code}: host blocked until {_iso(until)}", code, ra) from None
            raise HeadlineError(f"HTTP {code}", code, ra, retryable=500 <= code <= 599) from None
        except (urllib.error.URLError, OSError, TimeoutError, http.client.HTTPException) as e:
            # http.client's own family (a non-HTTP status line, a chunked body cut short, a line too long, too many
            # headers) is neither an OSError nor a URLError: a network error too, so it counts (fix round 3)
            raise HeadlineError(f"network error {type(e).__name__}", retryable=True) from None
        finally:
            if self.conn is not None:
                _put(self.conn, f"headlines.{host}.last_request_ts", repr(self.clock()))
        if status != 200:
            raise HeadlineError(f"HTTP {status}", status)
        if len(body) > MAX_BODY:
            raise HeadlineError("body over 1 MiB")
        if not got.get("content-type", "").lower().startswith(ctype):
            raise HeadlineError("wrong content type")
        return 200, body, got


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(int(ts), UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------- parsing (title, link, guid, time, category only)

def _text(item, tag: str) -> str | None:
    el = item.find(tag)
    return None if el is None or el.text is None else el.text


def clean_title(raw: str | None) -> str | None:
    if raw is None or _RAW_CTRL.search(raw):     # before split(), which turns \x1c-\x1f and \x85 into spaces
        return None
    t = " ".join(raw.split())
    if not t or len(t) > MAX_TITLE or _CTRL.search(t):
        return None
    return t


def clean_link(raw: str | None, host: str) -> str | None:
    if not raw:
        return None
    u = urlsplit(raw.strip())
    if u.scheme != "https" or u.hostname != host or u.port is not None or u.username or u.password \
            or u.query or u.fragment:
        return None
    path = re.sub(r"/{2,}", "/", u.path)
    if not re.search(r"\.(html|htm|pdf)$", path) or _CTRL.search(path):
        return None
    out = urlunsplit(("https", host, path, "", ""))
    return out if len(out) <= MAX_LINK else None


def classify(source: str, title: str, link: str | None, category: str | None) -> str:
    if source == "fed_policy":
        if title == "Federal Reserve issues FOMC statement":
            return "statement"
        if title.startswith("Minutes of the Federal Open Market Committee"):
            return "minutes"
        return "policy"
    if source == "fed_speeches":
        return "testimony" if (category or "").strip() == "Testimony" else "speech"
    path = urlsplit(link).path if link else ""
    if _ECB_DECISION.match(path):
        return "decision"
    for prefix, kind in (("/press/pr/", "release"), ("/press/key/", "speech"), ("/press/inter/", "interview"),
                         ("/press/accounts/", "accounts")):
        if path.startswith(prefix):
            return kind
    return "other"


def parse(source: str, body: bytes, now: datetime) -> tuple[list[dict], int]:
    """(items, dropped). Raises HeadlineError for a body that is not an RSS 2.0 feed."""
    if _BANNED_XML.search(body):
        raise HeadlineError("DOCTYPE or ENTITY refused")
    if b"\x00" in body or not _RSS_START.match(body):        # UTF-16 or UTF-32, or not RSS at all (fix round 1)
        raise HeadlineError("not RSS 2.0")
    if body.startswith(b"\xef\xbb\xbf"):
        body = body[3:]
    try:
        root = ET.fromstring(body)
    except (ET.ParseError, LookupError, ValueError, OverflowError):
        # LookupError: an unknown encoding in the XML declaration; ValueError: a multi-byte one (expat) (fix round 3)
        raise HeadlineError("not XML") from None
    if root.tag != "rss" or root.get("version") != "2.0" or root.find("channel") is None:
        raise HeadlineError("not RSS 2.0")
    host = SOURCES[source][0]
    items, dropped = [], 0
    for it in root.find("channel").findall("item"):
        title = clean_title(_text(it, "title"))
        when = None
        try:
            raw = _text(it, "pubDate")
            when = email.utils.parsedate_to_datetime(raw.strip()) if raw else None
            when = None if when is None or when.tzinfo is None else when.astimezone(UTC)
        except (TypeError, ValueError, IndexError, OverflowError):     # OverflowError: past year 9999 in UTC
            when = None
        if title is None or when is None or when > now + timedelta(seconds=FUTURE_S):
            dropped += 1
            continue
        raw_link = _text(it, "link")
        link = clean_link(raw_link, host)
        guid = (_text(it, "guid") or raw_link or title).strip()
        items.append({"id": hashlib.sha256(f"{source}|{guid}".encode()).hexdigest()[:20], "source": source,
                      "kind": classify(source, title, link, _text(it, "category")), "title": title, "link": link,
                      "published_utc": to_iso(when)})
    return items, dropped


def store(conn: sqlite3.Connection, items: list[dict], now: datetime) -> int:
    if not items or not storage.raw_allowed(conn):
        return 0
    n = 0
    with db.transaction(conn):
        for it in items:
            n += conn.execute("INSERT OR IGNORE INTO news_headline (id, source, kind, title, link, published_utc,"
                              " first_seen_utc) VALUES (?, ?, ?, ?, ?, ?, ?)",
                              (it["id"], it["source"], it["kind"], it["title"], it["link"], it["published_utc"],
                               to_iso(now))).rowcount
    return n


def prune(conn: sqlite3.Connection, now: datetime, keep_days: int) -> int:
    """Rows published more than keep_days ago, then the oldest beyond HEADLINE_MAX_ROWS."""
    n = conn.execute("DELETE FROM news_headline WHERE published_utc < ?",
                     (to_iso(now - timedelta(days=keep_days)),)).rowcount
    over = conn.execute("SELECT COUNT(*) FROM news_headline").fetchone()[0] - HEADLINE_MAX_ROWS
    if over > 0:
        n += conn.execute("DELETE FROM news_headline WHERE id IN (SELECT id FROM news_headline ORDER BY"
                          " published_utc, id LIMIT ?)", (over,)).rowcount
    return n


# ---------------------------------------------------------------- the schedule

def decision_times(conn: sqlite3.Connection, source: str) -> list[datetime]:
    """The stored MT5 decision rows (Fed or ECB rate decisions, high impact, exact time) that define the windows."""
    from app.news.families import family_of
    want = "US_FED_RATE" if source == "fed_policy" else "EU_ECB_MRO" if source == "ecb_press" else None
    if want is None:
        return []
    out = []
    for r in conn.execute("SELECT country, name, event_utc FROM news_event WHERE time_mode = 'exact'"
                          " AND impact = 'high' AND kind != 'holiday'"):
        f = family_of(r["country"], r["name"])
        if f is not None and f.key == want:
            out.append(from_iso(r["event_utc"]))
    return out


def interval_s(conn: sqlite3.Connection, cfg, source: str, now: datetime) -> float:
    h = cfg.headlines
    normal = float(h.speeches_poll_s if source == "fed_speeches" else h.poll_s)
    win = FED_WINDOW if source == "fed_policy" else ECB_WINDOW if source == "ecb_press" else None
    if win is not None:
        for t in decision_times(conn, source):
            if t + timedelta(seconds=win[0]) <= now <= t + timedelta(seconds=win[1]):
                fast = float(h.window_poll_s) if source == "fed_policy" else max(ECB_MIN_GAP_S, float(h.window_poll_s))
                return min(normal, fast)
    return max(normal, ECB_MIN_GAP_S) if source == "ecb_press" else normal


def due(conn: sqlite3.Connection, cfg, source: str, now: datetime) -> bool:
    if _meta(conn, _k(source, "halted")):
        return False
    st = _meta(conn, _k(source, "stopped_until"))
    if st is not None and float(st) > now.timestamp():
        return False
    host = SOURCES[source][0]
    if blocked_until(conn, host, now.timestamp()) is not None or host_wait(conn, host, now.timestamp()) is not None:
        return False
    last = _meta(conn, _k(source, "last_try_ts"))
    if last is not None and now.timestamp() - float(last) < interval_s(conn, cfg, source, now):
        return False
    hl = _meta(conn, f"headlines.{host}.last_request_ts")
    return hl is None or now.timestamp() - float(hl) >= HOST_GAP_S


def _log_first_decision(conn: sqlite3.Connection, items: list[dict]) -> None:
    """HEADLINES 14 H3: the first ECB decision item after install, logged once (its title and path), so the form the
    decision push relies on can be checked on the server."""
    if _meta(conn, "headlines.ecb_press.first_decision_logged"):
        return
    for it in items:
        if it["source"] == "ecb_press" and it["kind"] == "decision":
            log.info("headlines: first ECB decision item: %r %s", it["title"], urlsplit(it["link"] or "").path)
            _put(conn, "headlines.ecb_press.first_decision_logged", it["published_utc"])
            return


def _halt(conn, source: str, why: str, now: datetime, q: Callable | None) -> None:
    _put(conn, _k(source, "halted"), why)
    log.warning("headlines: %s halted: %s", source, why)
    if q is not None:
        q(Alert(f"headlines_halted:{source}:{now.date().isoformat()}", "headlines_halted", 2, "Headlines stopped",
                f"{FEED_NAME[source]} feed: {why}. On the server: python -m app headlines --reset-halt"))


def poll(conn: sqlite3.Connection, cfg, client: Client, source: str, now: datetime, q: Callable | None = None) -> str:
    """One fetch of one feed if it is due. Returns what happened: skipped, not_modified, same, stored:<n>, failed,
    blocked, halted."""
    if source not in cfg.headlines.sources or not due(conn, cfg, source, now):
        return "skipped"
    if not storage.raw_allowed(conn):          # below the disk floor or over the budget: no fetch, nothing saved
        return "skipped"
    _put(conn, _k(source, "last_try_ts"), repr(now.timestamp()))
    fed = source.startswith("fed_")
    host = SOURCES[source][0]
    try:
        status, body, headers = client.get(source, _meta(conn, _k(source, "etag")) if fed else None,
                                           _meta(conn, _k(source, "last_modified")) if fed else None)
        if status == 304:
            out = "not_modified"
        else:
            digest = hashlib.sha256(body).hexdigest()
            if digest == _meta(conn, _k(source, "body_sha256")):
                out = "same"
            else:
                items, dropped = parse(source, body, now)
                out = f"stored:{store(conn, items, now)}"
                _put(conn, _k(source, "body_sha256"), digest)
                _put(conn, _k(source, "dropped"), dropped)       # HEADLINES 5: dropped and counted (last body)
                if dropped:
                    log.info("headlines: %s dropped %s items (no title, a bad title or no time)", source, dropped)
                _log_first_decision(conn, items)
            if fed:
                _put(conn, _k(source, "etag"), headers.get("etag"))
                _put(conn, _k(source, "last_modified"), headers.get("last-modified"))
    except Blocked:
        return "blocked"
    except HostWait:                           # nothing was sent, so not a failure
        return "skipped"
    except PathRefused as exc:                 # refused before anything was sent
        _halt(conn, source, str(exc), now, q)
        return "halted"
    except HeadlineError as exc:
        _host_failed(conn, host, exc, now.timestamp())
        if not exc.retryable:
            _halt(conn, source, str(exc), now, q)
            return "halted"
        fails = int(_meta(conn, _k(source, "failures")) or 0) + 1
        if fails >= MAX_FAILURES:
            _put(conn, _k(source, "failures"), 0)
            _put(conn, _k(source, "stopped_until"), repr(now.timestamp() + max(COOLDOWN_S, exc.retry_after or 0.0)))
        else:
            _put(conn, _k(source, "failures"), fails)
            _put(conn, _k(source, "stopped_until"), repr(now.timestamp() + max(exc.retry_after or 0.0, 2.0 ** fails)))
        return "failed"
    _host_ok(conn, host)
    _put(conn, _k(source, "failures"), 0)
    _put(conn, _k(source, "last_ok_utc"), to_iso(now))
    return out


def run_forever(conn: sqlite3.Connection, cfg, tick_s: float = 5.0) -> None:
    """python -m app headlines: check each feed every few seconds and fetch the ones that are due."""
    from app.notify.alerts import queue_alert
    client = Client(conn, timeout_s=cfg.headlines.timeout_s)
    while True:
        now = datetime.now(UTC)
        for source in cfg.headlines.sources:
            try:
                r = poll(conn, cfg, client, source, now, lambda a: queue_alert(conn, a, now))
                if r not in ("skipped",):
                    log.info("headlines: %s %s", source, r)
            except Exception as exc:  # noqa: BLE001 - one broken feed must not stop the others
                log.error("headlines: %s failed: %s", source, type(exc).__name__)
        time.sleep(tick_s)


# ---------------------------------------------------------------- screens and the push

PAUSE_SHOWN_S = 60                     # Today names a paused feed only for a wait of a minute or more


def wait_until(conn: sqlite3.Connection, source: str, now_ts: float) -> float | None:
    """When a feed that is not halted may next be fetched, if that is still ahead: its own back-off or cool-down,
    its host's not-before time or a host block, whichever ends last."""
    host = SOURCES[source][0]
    vals = [blocked_until(conn, host, now_ts), host_wait(conn, host, now_ts)]
    st = _meta(conn, _k(source, "stopped_until"))
    try:
        vals.append(float(st) if st is not None else None)
    except ValueError:
        pass
    ahead = [v for v in vals if v is not None and v > now_ts]
    return max(ahead) if ahead else None


def last_ok(conn: sqlite3.Connection, cfg) -> str | None:
    vals = [v for s in cfg.headlines.sources if (v := _meta(conn, _k(s, "last_ok_utc")))]
    return max(vals) if vals else None


def none_label(reading: list[str]) -> str | None:
    """Whose headlines Today's empty note may say there are none of: only the feeds being read (not stopped, not
    paused), so a stopped or waiting feed is never claimed quiet (fix round 3, red team minor). "Fed" only when both
    Fed feeds are read; None when no feed is."""
    fed = [s for s in reading if s.startswith("fed_")]
    parts = (["Fed"] if len(fed) == 2 else [FEED_NAME[s] for s in fed]) + (["ECB"] if "ecb_press" in reading else [])
    return " or ".join(parts) or None


def today_block(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    h = cfg.headlines
    if not h.enabled:
        return {"enabled": False, "items": []}
    rows = conn.execute(f"SELECT * FROM news_headline WHERE source IN ({','.join('?' * len(h.sources))})"
                        " AND published_utc >= ? ORDER BY published_utc DESC, id LIMIT 10",
                        (*h.sources, to_iso(now - timedelta(hours=h.show_hours)))).fetchall()
    last = last_ok(conn, cfg)
    stopped = [FEED_NAME[s] for s in h.sources if _meta(conn, _k(s, "halted"))]
    halted = bool(stopped)
    stale = last is None or (now - from_iso(last)).total_seconds() > h.stale_after_min * 60
    paused = []
    for s in h.sources:
        if _meta(conn, _k(s, "halted")):
            continue
        until = wait_until(conn, s, now.timestamp())
        if until is not None and until - now.timestamp() >= PAUSE_SHOWN_S:
            paused.append({"name": FEED_NAME[s], "until_utc": _iso(until)})
    waiting = {p["name"] for p in paused}
    reading = [s for s in h.sources if not _meta(conn, _k(s, "halted")) and FEED_NAME[s] not in waiting]
    return {"enabled": True, "last_ok_utc": last, "stale": stale, "halted": halted, "stopped": stopped,
            "paused": paused, "hours": h.show_hours, "none_label": none_label(reading),
            "items": [{"id": r["id"], "source": LABEL[r["source"]], "kind": r["kind"], "kind_label": KIND_LABEL[r["kind"]],
                       "title": r["title"], "link": r["link"], "published_utc": r["published_utc"],
                       "policy": r["kind"] in ("statement", "decision")} for r in rows]}


def settings_block(conn: sqlite3.Connection, cfg) -> dict:
    h = cfg.headlines
    return {"enabled": h.enabled, "sources": [LABEL[s] + " " + {"fed_policy": "monetary policy",
                                                                 "fed_speeches": "speeches and testimony",
                                                                 "ecb_press": "press"}[s] for s in h.sources],
            "poll_s": h.poll_s, "speeches_poll_s": h.speeches_poll_s,
            # each decision-day poll only for a feed that is read (fix round 3, red team minor)
            "window_poll_s": h.window_poll_s if "fed_policy" in h.sources else None,
            "ecb_window_poll_s": int(max(ECB_MIN_GAP_S, float(h.window_poll_s))) if "ecb_press" in h.sources else None,
            "keep_days": h.keep_days,
            "push": h.push, "last_ok_utc": last_ok(conn, cfg),
            # a halted feed sends no policy alert until it is reset (fix round 2), so its kind is left out
            "push_kinds": [PUSH_KIND[s] for s in h.sources if s in PUSH_KIND and not _meta(conn, _k(s, "halted"))],
            "halted": [FEED_NAME[s] for s in h.sources if _meta(conn, _k(s, "halted"))]}


def alert_step(conn: sqlite3.Connection, cfg, now: datetime, q: Callable) -> None:
    """The monitor's headlines step (reads news_headline only; serve never fetches)."""
    h = cfg.headlines
    queued = conn.execute("SELECT id, created_utc FROM alert WHERE kind = 'headline_policy' AND status = 'queued'")
    stale = [r["id"] for r in queued if (now - from_iso(r["created_utc"])).total_seconds() > PUSH_SKIP_S]
    if stale:
        with db.transaction(conn):
            conn.executemany("UPDATE alert SET status = 'skipped', last_error = 'headline is old'"
                             " WHERE id = ? AND status = 'queued'", [(i,) for i in stale])
    if not (h.enabled and h.push):
        return
    day0 = now.replace(hour=0, minute=0, second=0, microsecond=0)
    sent_today = conn.execute("SELECT COUNT(*) FROM alert WHERE kind = 'headline_policy' AND created_utc >= ?",
                              (to_iso(day0),)).fetchone()[0]
    rows = conn.execute("SELECT * FROM news_headline WHERE alerted = 0 AND kind IN ('statement', 'decision')"
                        " ORDER BY first_seen_utc, id").fetchall()
    for r in rows:
        fresh = 0 <= (from_iso(r["first_seen_utc"]) - from_iso(r["published_utc"])).total_seconds() <= FRESH_S
        recent = (now - from_iso(r["first_seen_utc"])).total_seconds() <= PUSH_SKIP_S
        if fresh and recent and r["source"] in h.sources and sent_today < PUSH_DAILY_CAP:
            pub = from_iso(r["published_utc"])
            hm = fmt_melbourne_12(pub).split(" ", 3)[3]
            if r["source"] == "ecb_press":
                title, body = "ECB decision out", f"ECB · {hm} Melbourne"
            else:
                title, body = "Fed statement out", f"Federal Reserve · {hm} Melbourne"
            q(Alert(f"headline_policy:{r['id']}", "headline_policy", 3, title, body))
            sent_today += 1
        with db.transaction(conn):
            conn.execute("UPDATE news_headline SET alerted = 1 WHERE id = ?", (r["id"],))

