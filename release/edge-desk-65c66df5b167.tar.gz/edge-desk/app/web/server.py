"""The Edge Desk web server: standard library only (http.server.ThreadingHTTPServer).

  /api/health                   GET, no auth, says only {"ok": true}
  /api/bridge/v1/snapshot       POST, Bearer EDGE_INGEST_TOKEN (bridge/CONTRACT.md); body up to
                                bridge.max_payload_bytes
  /api/bridge/v1/calendar       POST, the same Bearer: EUR and USD calendar rows from the EA (edge-calendar/2,
                                app/news); body up to 262,144 bytes; 404 while [news] enabled is false
  /api/login, /api/logout       POST with header X-Edge: 1
  /api/...                      the screens' API (api.py); GET needs the session cookie; POST needs the
                                cookie AND X-Edge: 1 (a custom header a cross-site form cannot send); 64 KiB
  /, /static/<file>             app/web/static (index.html at /); no listing, no dot files, no way out;
                                web file types only (CONTENT_TYPES), so icons/make_icons.py is never served
  /sw.js, /manifest.webmanifest  the service worker (scope /) and the app manifest from app/web/static, no
                                login (a browser fetches them before it has a session)
Every response carries the security headers below; /api adds Cache-Control: no-store. Optional TLS with
EDGE_TLS_CERT and EDGE_TLS_KEY (file paths); normally a reverse proxy in front does HTTPS. Set
EDGE_TRUSTED_PROXY to that proxy's address so the login limit follows each visitor (auth.py).
Slow clients: one request (line, headers and body) must arrive within REQUEST_DEADLINE_S, and at most
MAX_CONNECTIONS connections are served at once (more are answered 503 and closed).
A background thread runs notify.monitor.tick every 5 s until the server closes; alerts go to the saved phones
by Web Push (notify/push.py) once EDGE_VAPID_PRIVATE_KEY and EDGE_VAPID_SUBJECT are set.
The app never sends, changes or closes an order: nothing here talks to the broker.
"""
from __future__ import annotations

import io
import json
import logging
import math
import os
import re
import ssl
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qs, unquote, urlsplit

from app import db, storage
from app.news import schema as news_schema
from app.notify import monitor
from app.notify.push import PushClient, WebPushTransport, public_key_b64url
from app.photos import images as photo_images
from app.photos import store as photo_store
from app.timeutil import day_bounds, now_utc, trading_day
from app.web import api, auth

log = logging.getLogger("edge.web")

STATIC_DIR = Path(__file__).resolve().parent / "static"
CSP = ("default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; font-src 'self'; "
       "connect-src 'self'; worker-src 'self'; manifest-src 'self'; frame-ancestors 'none'")
SECURITY_HEADERS = (("Content-Security-Policy", CSP), ("X-Content-Type-Options", "nosniff"),
                    ("Referrer-Policy", "no-referrer"), ("X-Frame-Options", "DENY"))
API_BODY_LIMIT = 64 * 1024
DISCARD_FACTOR = 2                    # read and drop a refused body up to 2x the largest allowed body, so the
DISCARD_RECV_TIMEOUT_S = 2            # client sees the reply; anything bigger just closes the connection
REQUEST_DEADLINE_S = 30.0             # the whole request (line, headers, body) must arrive within this time
MAX_CONNECTIONS = 64                  # connections served at once; the bridge and one browser need about 10
MONITOR_INTERVAL_S = 5.0
CONTENT_TYPES = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
                 ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
                 ".json": "application/json", ".woff2": "font/woff2", ".woff": "font/woff",
                 ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon",
                 ".webmanifest": "application/manifest+json", ".txt": "text/plain; charset=utf-8"}
_SEGMENT = re.compile(r"[A-Za-z0-9_-][A-Za-z0-9._-]*")
_LENGTH = re.compile(r"[0-9]{1,15}")      # ASCII digits only: str.isdigit() also accepts '²', which int() refuses
_DEFAULT = object()
ROOT_FILES = {"/sw.js": "sw.js", "/manifest.webmanifest": "manifest.webmanifest"}   # served at the site root
_PHOTO_IMAGE = re.compile(r"/api/photos/([0-9]{1,12})/image")
_MTIME = re.compile(r"[0-9]{1,15}")


def _ms_to_iso(value: str | None) -> str | None:
    """The phone's File.lastModified (ms since 1970) as UTC ISO, or None when missing or outside 2000-2100."""
    if value is None or not _MTIME.fullmatch(value.strip()):
        return None
    secs = int(value.strip()) // 1000
    if not 946684800 <= secs < 4102444800:
        return None
    return datetime.fromtimestamp(secs, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def trading_day_start(now: datetime, cfg) -> datetime:
    """The start of the trading day holding `now` (the day ends at [day] boundary_hour in boundary_tz)."""
    d = trading_day(now, cfg.day.boundary_tz, cfg.day.boundary_hour)
    return day_bounds(d, cfg.day.boundary_tz, cfg.day.boundary_hour)[0]


class Stopped(Exception):
    """Raised by the alert client's wait when the server is closing: the alert stays queued, never rushed."""


@dataclass
class EdgeContext:
    cfg: Any
    conn: Any
    clock: Callable[[], datetime]
    static_dir: Path
    client: Any
    secure_cookie: bool
    limiter: auth.LoginLimiter = field(default_factory=auth.LoginLimiter)
    proxies: frozenset = frozenset()      # EDGE_TRUSTED_PROXY addresses
    valid_after: int = 0                  # sessions issued at or before this time (the last logout) are over
    push_public_key: str | None = None    # VAPID public key (the browser's applicationServerKey) when configured
    photos_dir: Path | None = None        # the photo journal's files (var/photos beside the journal)
    photo_times: list = field(default_factory=list)   # recent upload times, for [photos] max_per_minute


SESSIONS_KEY = "sessions_valid_after"


def _finite(value):
    """Non-finite floats (from a broker value that overflowed) become null, so a page still loads."""
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, dict):
        return {k: _finite(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_finite(v) for v in value]
    return value


class _DeadlineReader(io.RawIOBase):
    """Socket reads that share one deadline per request. The socket timeout alone is per recv, so a client
    sending a byte every 29 s could hold a connection for ever; here every recv waits at most what is left."""

    def __init__(self, sock, idle_timeout: float):
        self._sock = sock
        self.idle_timeout = idle_timeout
        self.recv_timeout = idle_timeout
        self.deadline: float | None = None

    def readable(self) -> bool:
        return True

    def readinto(self, buf) -> int:
        timeout = self.recv_timeout
        if self.deadline is not None:
            left = self.deadline - time.monotonic()
            if left <= 0:
                raise TimeoutError("request deadline passed")
            timeout = min(timeout, left)
        self._sock.settimeout(timeout)
        try:
            return self._sock.recv_into(buf)
        finally:
            self._sock.settimeout(self.idle_timeout)     # writes keep the normal timeout


def _no_constants(name: str):
    raise ValueError(f"{name} is not valid JSON")


def _parse_json(raw: bytes) -> dict:
    try:
        value = json.loads(raw.decode("utf-8"), parse_constant=_no_constants)
    except (UnicodeDecodeError, ValueError, RecursionError):
        raise api.ApiError(400, "body is not valid JSON") from None
    if not isinstance(value, dict):
        raise api.ApiError(400, "body must be a JSON object")
    return value


class Handler(BaseHTTPRequestHandler):
    server_version = "EdgeDesk"
    sys_version = ""
    protocol_version = "HTTP/1.1"
    timeout = 30
    request_deadline_s = REQUEST_DEADLINE_S
    _api_path = False
    _raw: _DeadlineReader | None = None

    # ------------------------------------------------------------ plumbing

    def version_string(self) -> str:
        return self.server_version          # no Python or OS version in the Server header

    def setup(self):
        super().setup()
        self._raw = _DeadlineReader(self.connection, self.timeout)
        original, self.rfile = self.rfile, io.BufferedReader(self._raw)
        original.close()

    def handle_one_request(self):
        if self._raw is not None:
            self._raw.recv_timeout = self.timeout
            self._raw.deadline = time.monotonic() + self.request_deadline_s
        super().handle_one_request()

    @property
    def ctx(self) -> EdgeContext:
        return self.server.ctx

    def log_request(self, code="-", size="-"):
        path = urlsplit(getattr(self, "path", "") or "").path
        log.info("%s %s %s", getattr(self, "command", "-"), path[:200], code)

    def log_message(self, format, *args):   # noqa: A002 - base class name
        log.info("http: %s", (format % args)[:200])

    _private_cache = False                 # a picture: Cache-Control private, set by _photo_image

    def end_headers(self):
        for k, v in SECURITY_HEADERS:
            self.send_header(k, v)
        if self._api_path and not self._private_cache:
            self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def send_error(self, code, message=None, explain=None):
        """Errors from the base class (bad request line, unknown method) as short JSON, no echo."""
        self.close_connection = True
        try:
            phrase = HTTPStatus(code).phrase
        except ValueError:
            phrase = "error"
        body = json.dumps({"ok": False, "error": phrase.lower()}).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        if getattr(self, "command", "") != "HEAD" and code >= 200 and code not in (204, 304):
            self.wfile.write(body)

    def _send(self, status: int, body: bytes, ctype: str, headers: dict | None = None, head: bool = False):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        if self.close_connection:
            self.send_header("Connection", "close")
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def _json(self, status: int, payload: dict, headers: dict | None = None):
        try:
            text = json.dumps(payload, allow_nan=False, separators=(",", ":"), default=str)
        except ValueError:
            text = json.dumps(_finite(payload), allow_nan=False, separators=(",", ":"), default=str)
        self._send(status, text.encode(), "application/json; charset=utf-8", headers)

    def _discard_cap(self) -> int:
        return DISCARD_FACTOR * max(self.ctx.cfg.bridge.max_payload_bytes, API_BODY_LIMIT)

    def _discard(self, n: int) -> None:
        """Drop a body we will not use, so the client can read the reply; then close."""
        if n <= 0:
            return
        self.close_connection = True
        if n > self._discard_cap():
            return
        try:
            if self._raw is not None:
                self._raw.recv_timeout = DISCARD_RECV_TIMEOUT_S
            else:
                self.connection.settimeout(DISCARD_RECV_TIMEOUT_S)
            left = n
            while left > 0:
                chunk = self.rfile.read(min(65536, left))
                if not chunk:
                    break
                left -= len(chunk)
        except OSError:
            pass

    def _length(self) -> int | None:
        if self.headers.get("Transfer-Encoding"):
            return None
        cl = (self.headers.get("Content-Length") or "").strip()
        return int(cl) if _LENGTH.fullmatch(cl) else None

    def _read_json(self, limit: int, strip_nul: bool = False) -> dict:
        """Body as a JSON object, or raise ApiError (411 / 413 / 415 / 400). strip_nul drops one trailing
        NUL byte (an MQL5 char array can keep the string's terminating zero)."""
        n = self._length()
        if n is None:
            self.close_connection = True
            raise api.ApiError(411, "length required")
        if n > limit:
            self._discard(n)
            raise api.ApiError(413, "payload too large")
        if n == 0:
            return {}
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if ctype != "application/json":
            self._discard(n)
            raise api.ApiError(415, "Content-Type must be application/json")
        try:
            raw = self.rfile.read(n)
        except TimeoutError:
            self.close_connection = True
            raise api.ApiError(408, "request timeout") from None
        if len(raw) != n:
            self.close_connection = True
            raise api.ApiError(400, "body shorter than Content-Length")
        if strip_nul and raw.endswith(b"\x00"):
            raw = raw[:-1]
        return _parse_json(raw)

    def _refuse_body(self) -> None:
        """A request we answer without using its body (if it has one)."""
        if self.headers.get("Transfer-Encoding"):
            self.close_connection = True
            return
        cl = (self.headers.get("Content-Length") or "").strip()
        if not cl:
            return
        if not _LENGTH.fullmatch(cl):
            self.close_connection = True
            return
        self._discard(int(cl))

    # ------------------------------------------------------------ methods

    def do_GET(self):
        self._handle("GET")

    def do_HEAD(self):
        self._handle("HEAD")

    def do_POST(self):
        self._handle("POST")

    def _not_allowed(self):
        self._handle("OTHER")

    do_PUT = do_DELETE = do_PATCH = do_OPTIONS = _not_allowed

    def _handle(self, method: str) -> None:
        try:
            if method != "POST" and (self.headers.get("Transfer-Encoding") or (
                    self.headers.get("Content-Length") is not None and self._length() != 0)):
                self.close_connection = True  # a body we never read must not be taken as the next request
            parts = urlsplit(self.path)
            path = parts.path
            self._api_path = path == "/api" or path.startswith("/api/")
            if self._api_path:
                self._api(method, path, parts.query)
            else:
                self._static(method, path)
        except api.ApiError as exc:
            self._json(exc.status, {"ok": False, "error": exc.message})
        except Exception:  # noqa: BLE001
            log.exception("request failed")
            self.close_connection = True
            self._json(500, {"ok": False, "error": "server error"})

    # ------------------------------------------------------------ API

    def _session_ok(self) -> bool:
        value = auth.read_cookie(self.headers.get("Cookie"))
        return auth.verify_session(self.ctx.cfg.secrets.dashboard_token, value, self.ctx.clock().timestamp(),
                                   self.ctx.valid_after)

    def _same_origin(self) -> bool:
        """B9: a browser's cross-site write is refused. Sec-Fetch-Site, when sent, must be same-origin (or none:
        typed by the user); Origin, when sent, must name this host (the Host header, as the proxy passes it)."""
        site = self.headers.get("Sec-Fetch-Site")
        if site is not None and site not in ("same-origin", "none"):
            return False
        origin = self.headers.get("Origin")
        if origin is None:
            return True
        u = urlsplit(origin)
        host = (self.headers.get("Host") or "").strip().lower()
        return u.scheme in ("http", "https") and bool(u.netloc) and u.netloc.lower() == host

    def _api(self, method: str, path: str, query_text: str) -> None:
        ctx = self.ctx
        if path == "/api/health":
            if method not in ("GET", "HEAD"):
                self._refuse_body()
                raise api.ApiError(405, "method not allowed")
            return self._json(200, {"ok": True})
        if path == api.BRIDGE_PATH:
            if method != "POST":
                self._refuse_body()
                raise api.ApiError(405, "method not allowed")
            return self._bridge()
        if path == api.CALENDAR_PATH:
            if method != "POST":
                self._refuse_body()
                raise api.ApiError(405, "method not allowed")
            return self._bridge_calendar()
        if path in ("/api/login", "/api/logout"):
            if method != "POST":
                self._refuse_body()
                raise api.ApiError(405, "method not allowed")
            return self._login() if path == "/api/login" else self._logout()
        if path == "/api/photos" and method == "POST":
            return self._photo_upload()
        m = _PHOTO_IMAGE.fullmatch(path)
        if m and method in ("GET", "HEAD"):
            return self._photo_image(int(m.group(1)), head=method == "HEAD")

        fn, groups, allowed = api.match(method, path)
        if fn is None:
            self._refuse_body()
            raise api.ApiError(405 if allowed else 404, "method not allowed" if allowed else "not found")
        if not ctx.cfg.secrets.dashboard_token or not self._session_ok():
            if method == "POST":
                self._refuse_body()
            if not ctx.cfg.secrets.dashboard_token:
                raise api.ApiError(503, "not configured")
            raise api.ApiError(401, "login needed")
        body = None
        if method == "POST":
            if self.headers.get("X-Edge") != "1":
                self._refuse_body()
                raise api.ApiError(403, "missing X-Edge header")
            if not self._same_origin():
                self._refuse_body()
                raise api.ApiError(403, "cross-origin request")
            body = self._read_json(API_BODY_LIMIT)
        query = {k: v[-1] for k, v in parse_qs(query_text, keep_blank_values=False).items()}
        agent = self.headers.get("User-Agent") or ""
        if fn in api.UNLOCKED:   # sends alerts: takes the journal lock itself, never while sending
            status, payload = api.call(fn, ctx, groups, query, body, agent)
        else:
            with db._LOCK:   # one shared connection: each request reads and writes under the journal lock
                status, payload = api.call(fn, ctx, groups, query, body, agent)
        self._json(status, payload)

    # ------------------------------------------------------------ the photo journal (app/photos)

    def _write_allowed(self) -> None:
        """The checks every write passes: a session, X-Edge: 1 and the same origin (raises ApiError; the caller has not
        read the body)."""
        ctx = self.ctx
        if not ctx.cfg.secrets.dashboard_token:
            self._refuse_body()
            raise api.ApiError(503, "not configured")
        if not self._session_ok():
            self._refuse_body()
            raise api.ApiError(401, "login needed")
        if self.headers.get("X-Edge") != "1":
            self._refuse_body()
            raise api.ApiError(403, "missing X-Edge header")
        if not self._same_origin():
            self._refuse_body()
            raise api.ApiError(403, "cross-origin request")

    def _photo_upload(self) -> None:
        """POST /api/photos: one JPEG or PNG as the raw body (docs/JOURNAL_DESIGN.md §4, §10). The body is read OUTSIDE
        the journal lock, within the request's 30 s deadline, so a slow upload never holds up the bridge or a page;
        app/photos/store.py takes the lock only for its short row writes. Headers: X-File-Mtime (the phone's
        File.lastModified, ms), X-Trade-Ref (mt5:<id> or paper:<id>: link it to that trade)."""
        ctx = self.ctx
        cfg = ctx.cfg
        self._write_allowed()
        if not cfg.photos.enabled or ctx.photos_dir is None:
            self._refuse_body()
            raise api.ApiError(404, "pictures are off")
        n = self._length()
        if n is None:
            self.close_connection = True
            raise api.ApiError(411, "length required")
        if n > cfg.photos.max_bytes:
            self._discard(n)
            raise api.ApiError(413, "picture too large")
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if ctype not in photo_images.TYPES:
            self._discard(n)
            raise api.ApiError(415, photo_images.TYPE_TEXT)
        trade_ref = self.headers.get("X-Trade-Ref")
        if trade_ref is not None and not photo_store.TRADE_REF.fullmatch(trade_ref):
            self._discard(n)
            raise api.ApiError(400, "X-Trade-Ref must be mt5:<id> or paper:<id>")
        now = ctx.clock()
        with db._LOCK:
            room = storage.raw_allowed(ctx.conn)
        if not room or photo_store.full(cfg, ctx.photos_dir):
            self._discard(n)          # design §8.2: storage full or the disk floor reached, so nothing more is kept
            raise api.ApiError(507, "picture storage full")
        with self.server.photo_gate:  # decided under the gate; a refused body is dropped after it is released
            ctx.photo_times[:] = [t for t in ctx.photo_times if (now - t).total_seconds() < 60]
            day_start = trading_day_start(now, cfg)
            with db._LOCK:
                today = photo_store.uploads_since(ctx.conn, day_start)
            busy = len(ctx.photo_times) >= cfg.photos.max_per_minute or today >= cfg.photos.max_per_day
            if not busy:
                ctx.photo_times.append(now)
        if busy:
            self._discard(n)
            raise api.ApiError(429, "too many pictures: wait a minute")
        try:
            raw = self.rfile.read(n)
        except TimeoutError:
            self.close_connection = True
            raise api.ApiError(408, "request timeout") from None
        if len(raw) != n:
            self.close_connection = True
            raise api.ApiError(400, "body shorter than Content-Length")
        mtime = _ms_to_iso(self.headers.get("X-File-Mtime"))
        try:
            res = photo_store.save(ctx.conn, cfg, ctx.photos_dir, raw, ctype, mtime, trade_ref, now)
        except photo_images.Refused as exc:
            raise api.ApiError(exc.status, exc.message) from None
        except photo_store.NotFound as exc:
            raise api.ApiError(404, str(exc)) from None
        self._json(202, {"ok": True, **res})

    def _photo_image(self, photo_id: int, head: bool) -> None:
        """GET /api/photos/<id>/image: the stored file, the path derived from its row, never from the request."""
        ctx = self.ctx
        if not ctx.cfg.secrets.dashboard_token or not self._session_ok():
            raise api.ApiError(503 if not ctx.cfg.secrets.dashboard_token else 401, "login needed")
        if ctx.photos_dir is None or not ctx.cfg.photos.enabled:
            raise api.ApiError(404, "not found")
        try:
            with db._LOCK:
                data, mime = photo_store.image(ctx.conn, ctx.photos_dir, photo_id)
        except photo_store.NotFound:
            raise api.ApiError(404, "not found") from None
        self._private_cache = True
        try:
            self._send(200, data, mime, {"Content-Disposition": "inline",
                                         "Cache-Control": "private, max-age=86400"}, head=head)
        finally:
            self._private_cache = False

    def _login(self) -> None:
        ctx = self.ctx
        token = ctx.cfg.secrets.dashboard_token
        if not token:
            self._refuse_body()
            raise api.ApiError(503, "not configured")
        if self.headers.get("X-Edge") != "1":
            self._refuse_body()
            raise api.ApiError(403, "missing X-Edge header")
        ip = auth.client_key(self.client_address[0], self.headers.get_all("X-Forwarded-For"), ctx.proxies)
        now_s = ctx.clock().timestamp()
        # The try is counted before the body is read (SEC-01): tries sent together cannot all pass.
        if not ctx.limiter.reserve(ip, now_s):
            self._refuse_body()
            return self._json(429, {"ok": False, "error": "too many tries"},
                              {"Retry-After": str(ctx.limiter.retry_after(ip, now_s))})
        body = self._read_json(API_BODY_LIMIT)            # a bad body keeps the try counted
        given = body.get("token")
        if set(body) != {"token"} or not isinstance(given, str):
            raise api.ApiError(400, "send {\"token\": \"...\"}")
        if not auth.token_equal(given, token):
            raise api.ApiError(401, "wrong token")
        ctx.limiter.release(ip, now_s)                    # the right token gives its slot back
        issued = max(int(now_s), ctx.valid_after + 1)     # never at or before the last logout
        value = auth.sign_session(token, issued)
        self._json(200, {"ok": True}, {"Set-Cookie": auth.session_cookie(value, ctx.secure_cookie)})

    def _logout(self) -> None:
        if self.headers.get("X-Edge") != "1":
            self._refuse_body()
            raise api.ApiError(403, "missing X-Edge header")
        self._refuse_body()
        ctx = self.ctx
        if ctx.cfg.secrets.dashboard_token and self._session_ok():
            # Only a logged-in caller ends the sessions (a stranger cannot log the owner out). The cookie is
            # stateless, so logout ends every session issued until now, on every device (SEC-14).
            cutoff = max(ctx.valid_after, int(ctx.clock().timestamp()))
            with db.transaction(ctx.conn):
                ctx.conn.execute("INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE"
                                 " SET value = excluded.value", (SESSIONS_KEY, str(cutoff)))
            ctx.valid_after = cutoff
        self._json(200, {"ok": True}, {"Set-Cookie": auth.clear_cookie(ctx.secure_cookie)})

    def _bridge(self) -> None:
        ctx = self.ctx
        token = ctx.cfg.secrets.ingest_token
        if not token:
            self._refuse_body()
            raise api.ApiError(503, "not configured")
        if not auth.bearer_ok(self.headers.get("Authorization"), token):
            self._refuse_body()
            raise api.ApiError(401, "unauthorized")
        payload = self._read_json(ctx.cfg.bridge.max_payload_bytes, strip_nul=True)
        with db._LOCK:
            status, body = api.bridge_snapshot(ctx, payload)
        self._json(status, body)

    def _bridge_calendar(self) -> None:
        ctx = self.ctx
        token = ctx.cfg.secrets.ingest_token
        if not token:
            self._refuse_body()
            raise api.ApiError(503, "not configured")
        if not auth.bearer_ok(self.headers.get("Authorization"), token):
            self._refuse_body()
            raise api.ApiError(401, "unauthorized")
        payload = self._read_json(news_schema.MAX_PAYLOAD_BYTES, strip_nul=True)
        with db._LOCK:
            status, body = api.bridge_calendar(ctx, payload)
        self._json(status, body)

    # ------------------------------------------------------------ static files

    def _static(self, method: str, path: str) -> None:
        if method not in ("GET", "HEAD"):
            self._refuse_body()
            return self._send(405, b"method not allowed", "text/plain; charset=utf-8", head=method == "HEAD")
        target = self._static_file(path)
        if target is None:
            return self._send(404, b"not found", "text/plain; charset=utf-8", head=method == "HEAD")
        data = target.read_bytes()
        ctype = CONTENT_TYPES[target.suffix.lower()]          # _static_file serves listed types only
        self._send(200, data, ctype, {"Cache-Control": "no-cache"}, head=method == "HEAD")

    def _static_file(self, raw_path: str) -> Path | None:
        try:
            path = unquote(raw_path, errors="strict") if "%" in raw_path else raw_path
        except UnicodeDecodeError:
            return None
        if path == "/":
            rel = "index.html"
        elif path in ROOT_FILES:
            rel = ROOT_FILES[path]
        elif path.startswith("/static/"):
            rel = path[len("/static/"):]
        else:
            return None
        if not rel or "\\" in rel or "\x00" in rel:
            return None
        segments = rel.split("/")
        if not all(_SEGMENT.fullmatch(s) for s in segments):
            return None
        root = self.ctx.static_dir.resolve()
        try:
            target = (root / Path(*segments)).resolve(strict=True)
        except (OSError, RuntimeError):
            return None
        if not target.is_relative_to(root) or not target.is_file():
            return None
        if target.suffix.lower() not in CONTENT_TYPES:   # web files only: never a script's source or notes
            return None
        return target


class EdgeServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 64
    max_connections = MAX_CONNECTIONS

    def __init__(self, address, ctx: EdgeContext, tls: ssl.SSLContext | None = None):
        super().__init__(address, Handler)
        self.ctx = ctx
        self._slots = threading.BoundedSemaphore(self.max_connections)
        self.tls = tls is not None
        if tls is not None:
            # The handshake runs in the request thread on first read, so a slow client never blocks accept().
            self.socket = tls.wrap_socket(self.socket, server_side=True, do_handshake_on_connect=False)
        self._serve_thread: threading.Thread | None = None
        self._monitor_thread: threading.Thread | None = None
        self.stop_event = threading.Event()
        self.photo_gate = threading.Lock()      # the upload counters (never held while a body is read)

    def process_request(self, request, client_address):
        """One thread per connection, at most max_connections at once; more are answered 503 and closed."""
        if not self._slots.acquire(blocking=False):
            if not self.tls:
                try:
                    request.settimeout(0.5)
                    request.sendall(b"HTTP/1.1 503 Service Unavailable\r\nContent-Length: 0\r\n"
                                    b"Connection: close\r\n\r\n")
                except OSError:
                    pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()

    @property
    def port(self) -> int:
        return self.server_address[1]

    @property
    def url(self) -> str:
        return f"{'https' if self.tls else 'http'}://{self.server_address[0]}:{self.port}"

    def start(self) -> "EdgeServer":
        """Serve in a background thread (tests); `serve_forever()` serves in the calling thread."""
        self._serve_thread = threading.Thread(target=self.serve_forever, kwargs={"poll_interval": 0.05},
                                              name="edge-http", daemon=True)
        self._serve_thread.start()
        return self

    def start_monitor(self, interval_s: float = MONITOR_INTERVAL_S) -> None:
        if self.monitor_alive():
            return
        self.stop_event.clear()
        ctx = self.ctx
        started = ctx.clock()

        def loop():
            while not self.stop_event.wait(interval_s):
                try:
                    monitor.tick(ctx.conn, ctx.cfg, ctx.clock(), ctx.client, started_utc=started)
                except Exception:  # noqa: BLE001 - keep the schedule alive
                    log.exception("monitor tick failed")

        self._monitor_thread = threading.Thread(target=loop, name="edge-monitor", daemon=True)
        self._monitor_thread.start()

    def wait_or_stop(self, seconds: float) -> None:
        """Sleep for the alert client; raise Stopped when the server closes, so no message is sent early."""
        if self.stop_event.wait(seconds):
            raise Stopped()

    def monitor_alive(self) -> bool:
        return self._monitor_thread is not None and self._monitor_thread.is_alive()

    def stop_monitor(self, timeout: float = 10.0) -> None:
        self.stop_event.set()
        if self._monitor_thread is not None:
            self._monitor_thread.join(timeout)

    def close(self) -> None:
        self.stop_monitor()
        if self._serve_thread is not None:
            self.shutdown()
            self._serve_thread.join(10)
            self._serve_thread = None
        self.server_close()


def _tls_context(env) -> ssl.SSLContext | None:
    cert, key = (env.get("EDGE_TLS_CERT") or "").strip(), (env.get("EDGE_TLS_KEY") or "").strip()
    if not cert and not key:
        return None
    if not cert or not key:
        raise ValueError("set both EDGE_TLS_CERT and EDGE_TLS_KEY, or neither")
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(cert, key)
    return context


def make_server(cfg, conn, host: str | None = None, port: int | None = None, *, static_dir: Path | None = None,
                clock: Callable[[], datetime] | None = None, client=_DEFAULT, env=None,
                photos_dir: Path | None = None) -> EdgeServer:
    """Build the server. client: an alert client (PushClient), None for no alerts, or (default) a PushClient
    made from config, with a Web Push transport only when EDGE_VAPID_PRIVATE_KEY and EDGE_VAPID_SUBJECT are
    both set. env: where EDGE_COOKIE_SECURE / EDGE_TLS_CERT / EDGE_TLS_KEY are read (os.environ).
    With push configured, a missing pywebpush raises ImportError before anything listens."""
    env = os.environ if env is None else env
    tls = _tls_context(env)
    proxies = auth.trusted_proxies(env)
    transport, public_key = None, None
    if cfg.secrets.push_configured:
        public_key = public_key_b64url(cfg.secrets.vapid_private_key)
        if client is _DEFAULT:
            transport = WebPushTransport(cfg.secrets.vapid_private_key, cfg.secrets.vapid_subject)
    if photos_dir is None and str(cfg.app.db_path) != ":memory:":
        photos_dir = Path(cfg.app.db_path).parent / "photos"      # var/photos beside the journal
    ctx = EdgeContext(cfg, conn, clock or now_utc, Path(static_dir) if static_dir else STATIC_DIR, None,
                      auth.cookie_secure(tls is not None, env, behind_proxy=bool(proxies)), proxies=proxies,
                      push_public_key=public_key, photos_dir=Path(photos_dir) if photos_dir else None)
    with db._LOCK:
        row = conn.execute("SELECT value FROM meta WHERE key = ?", (SESSIONS_KEY,)).fetchone()
    if row is not None and _LENGTH.fullmatch(str(row[0])):
        ctx.valid_after = int(row[0])
    server = EdgeServer((host if host is not None else cfg.app.host, cfg.app.port if port is None else port), ctx, tls)
    if client is _DEFAULT:
        n = cfg.notify
        client = PushClient(conn, transport, n.min_interval_s, n.max_attempts, n.push_ttl_s, n.push_ttl_urgent_s,
                            clock=ctx.clock, sleep=server.wait_or_stop)
    ctx.client = client
    return server
