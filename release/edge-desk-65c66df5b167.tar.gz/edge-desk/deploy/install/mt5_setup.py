#!/usr/bin/env python3
"""MT5's first-time setup on the server (run by deploy/install/stage2.sh as the mt5 user, with the system Python;
standard library only). It reuses what the bridge demo worked out (bridge/demo/run_demo.py, EVIDENCE.md, 16 Oct):
MetaQuotes' installer under WineHQ devel 11.20, the EA compiled with MetaEditor (0 errors required), and the
WebRequest allow-list set by keyboard and mouse at the measured screen points. Not stable 11.0: it has no syscall user
dispatch, so the protected installer shows a false "A debugger has been found" message and never installs (WineHQ bug
58043; evidence/part-b/installer/WINE.md, 18 Oct).

Two starts (real path, 18 Oct; evidence/part-b/installer/MT5_SETUP.md):
1. the login start, with the start file C:\\edge\\start.ini (the investor login, KeepPrivate=1 so the terminal keeps
   it; deleted 45 s after the start and not before the main window shows), closed cleanly with `wine taskkill` (no
   /f) about 70 s after the start so the terminal writes its settings;
2. a start with no start file: MT5 build 6272 saves Tools > Options to Config/common.ini only in such a session. Once
   its main window shows, Login and LiveUpdate windows get Escape until none has shown for a few seconds; then ctrl+o
   goes to the main window by its id, and the clicks wait for the Options window at the place where they were
   measured. Both checkbox points must read as checkboxes and each clicked box must read its new state. They turn
   algorithmic trading off and WebRequest on, and add http://127.0.0.1:8787; then a clean close. No click is needed
   when common.ini already holds the settings. The build is printed; one whose points were not measured (only 6266
   and 6272 were) is clicked behind the same checks, and the step log says so.
Config/common.ini is then read back. setup.done ("ok build N") is written only when its [Experts] section holds
WebRequest=1, a listed URL and Enabled=0 and the build did not change; otherwise the setup exits, says whether pasting
the install line again can help (Enter keeps the saved login), and writes nothing done. The password goes into the
start file in double quotes (PASSWORD_MAX below says why: '#' and ';' are safe as written, an outer space or quote is
not). Note: after the setup,
common.ini's [Common] holds Login=0 and an empty Server (a start file's account is not saved), so a start with no start
file always shows a Login window and never connects; that window is expected in the settings start (real run 3).

The secrets come only on stdin, as KEY=value lines (MT5_LOGIN, MT5_SERVER, MT5_PASSWORD: the INVESTOR password, and
EDGE_INGEST_TOKEN). The password is written to one file only, the start file (mode 0600), deleted once the terminal
has started; the token goes to the EA's token file (0600). The service's run.ini (0600, owner mt5, on the server only)
names the account and server but holds no password: the terminal keeps the password itself, and with the account
named it connects at once instead of waiting on its Login window (real path test F). Nothing here prints a secret.

  stage2.sh:  ... | runuser -u mt5 -- python3 -I mt5_setup.py --base /home/mt5/edge

After the settings start, Config/assistant.ini gets Enable=0 in its [MCP.*] sections: build 6272 runs an MCP server on
127.0.0.1:22346 by default, which the bridge does not need (real run 2: with Enable=0 no "MCP started" line and no
listener). The read-back requires it off too.

Real runs in a container (evidence/part-b/installer/MT5_SETUP.md): run 1 (18 Oct, 4 CPUs), run 2 (18 Oct, one CPU
by taskset, a 1.5 GiB memory cgroup) and run 3 (18 Oct, the committed code at ce95deff) passed with a dummy account
that never logged in. Run 4 (18 Oct, the code at 894e0be2, with the checkbox reads) failed its first setup: a box
read with the pointer still on it is drawn in hover colours, outside the measured readings; with the pointer moved
off before each read (run_demo.REST_AT), a fresh setup, three service-style starts and a re-run passed. Run 5 (18 Oct,
the code at ea2e076f, one CPU, Python 3.12) ran the changes made after run 4 and passed the same: a fresh setup, three
service-style starts, the taskkill restart and a re-run that kept the prefix. The click on an unmeasured build has
still not run on a real terminal (only build 6272 was given). Not verified on a real server: a real investor login
(that it authorizes and is kept between starts; with the dummy, the saved password survived a run.ini start closed by
taskkill), the screen points on the server's build, that the terminal reaches the broker from the server (the
container could not), and whether Escape alone closes the LiveUpdate window (in run 2 it showed at the end of a login
start; Escape and the taskkill after it left the terminal on its build).
"""
from __future__ import annotations

import argparse
import re
import signal
import string
import subprocess
import sys
import time
from pathlib import Path

DESK = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(DESK / "bridge" / "demo"))
import run_demo as D  # noqa: E402

NEEDED = ("MT5_LOGIN", "MT5_SERVER", "MT5_PASSWORD", "EDGE_INGEST_TOKEN")
# Enabled=0: "Allow algorithmic trading" off. A start file's value applies at every start that uses it, whatever was
# saved (real path: Enabled=1 turned it on); the EA still loads and runs with it off (tests C and E2), and WebRequest
# to http://127.0.0.1:8787 works with it off (real run 3: a probe EA posted every 3 s, terminal_trade_allowed=0, with
# this [Experts] section and the saved allow-list). EdgeBridge itself posts only once the terminal is connected to
# the broker, which no run here could reach: the server's 3-minute snapshot check shows that part.
EXPERTS = ["[Experts]", "AllowLiveTrading=0", "AllowDllImport=0", "Enabled=0", "Account=0", "Profile=0"]
STARTUP = ["[StartUp]", r"Expert=EdgeBridge\EdgeBridge", "ExpertParameters=edge.set", "Symbol=EURUSD", "Period=H1"]
# Builds whose Tools > Options click points were measured on screenshots: 6266 (bridge demo, 16 Oct) and 6272 (real
# path, 18 Oct). mt5setup.exe is pinned, but it is a web installer that downloads the current build (real run 3), and
# builds change often (6251, 6266, 6272 within about a week), so another build is not refused: it is clicked behind
# the same checks (run_demo.allow_webrequest: Options where measured, checkbox readings, each click read back), the
# step log names the build and says it was not measured, and the common.ini read-back decides.
MEASURED_BUILDS = frozenset({6266, 6272})
POPUPS = ("^Login$", "LiveUpdate")      # xdotool search --name patterns of the windows that get Escape
# Waits, with margin over what real runs measured (evidence/part-b/installer/MT5_SETUP.md): the main window showed 4-5 s
# after a start in run 1 (4 CPUs) and 6-10 s in run 2 (one CPU, 1.5 GiB); the Login window 5-9 s after it in run 1
# and about 1 s in run 2; Options about 1 s after ctrl+o in both (run_demo.OPTIONS_WAIT_S allows 30 s).
MAIN_WAIT_S = 120
POPUP_SETTLE_S = 20     # Login and LiveUpdate windows are looked for at least this long after the main window shows
POPUP_QUIET_S = 5       # ... and until none has shown for this long
POPUP_LIMIT_S = 90
TOKEN_CHARS = frozenset(string.ascii_letters + string.digits + "-_.~+/=")   # EdgeBridge.mq5 TokenOk
# The start file's Password= value (measured on MT5 build 6295 under Wine 11.20, 30 Oct 2026; desk/evidence/
# account_switch/MT5_PASSWORD_START_FILE.md): MT5 reads [Common] with GetPrivateProfileStringW, which keeps '#', ';'
# and '=' as written but trims outer spaces and removes one pair of matching quotes around the value; no escapes; a
# file with no byte-order mark is read as Windows-1252; the buffer is 512 characters. So the value is written in
# double quotes (the one pair MT5 removes), which round-tripped every case tried, and a password must be printable
# ASCII (install.sh's own check) of at most PASSWORD_MAX characters.
PASSWORD_MAX = 500


def parse_secrets(stream) -> dict:
    out = {}
    for line in stream.read().splitlines():
        k, sep, v = line.partition("=")
        if sep and k in NEEDED:
            out[k] = v
    missing = [k for k in NEEDED if not out.get(k)]
    if missing:
        raise SystemExit(f"mt5 setup: missing on stdin: {', '.join(missing)}")
    pw = out["MT5_PASSWORD"]
    if len(pw) > PASSWORD_MAX or not all(" " <= c <= "~" for c in pw):
        raise SystemExit(f"mt5 setup: MT5_PASSWORD must be 1 to {PASSWORD_MAX} printable ASCII characters (MT5 reads "
                         "its start file as Windows-1252 and cuts a value at 511 characters)")
    tok = out["EDGE_INGEST_TOKEN"]
    if not 32 <= len(tok) <= 256 or not set(tok) <= TOKEN_CHARS:
        raise SystemExit("mt5 setup: EDGE_INGEST_TOKEN must be 32 to 256 letters, digits or - _ . ~ + / = "
                         "(the EA refuses any other)")
    return out


def login_ini(s: dict) -> str:
    lines = ["[Common]", f"Login={s['MT5_LOGIN']}", f'Password="{s["MT5_PASSWORD"]}"', f"Server={s['MT5_SERVER']}",
             "KeepPrivate=1", "NewsEnable=0", *EXPERTS, *STARTUP]
    return "\r\n".join(lines) + "\r\n"


def run_ini(s: dict) -> str:
    """The service's start file: the account and server (no password: the terminal keeps it) and the EA on its chart.
    No WebRequest keys: a plaintext WebRequestUrl in a start file is ignored, and the saved list is what counts."""
    lines = ["[Common]", f"Login={s['MT5_LOGIN']}", f"Server={s['MT5_SERVER']}", *EXPERTS, *STARTUP]
    return "\r\n".join(lines) + "\r\n"


def _text(raw: bytes) -> str:
    """MT5 writes Config/common.ini and its journal as UTF-16 with a byte-order mark; anything else is read as UTF-8."""
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16", errors="replace")
    return raw.decode("utf-8", errors="replace")


def read_ini(path: Path) -> dict[str, dict[str, str]]:
    try:
        text = _text(path.read_bytes())
    except FileNotFoundError:
        return {}
    out: dict[str, dict[str, str]] = {}
    sect = None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("[") and line.endswith("]"):
            sect = out.setdefault(line[1:-1], {})
        elif sect is not None and "=" in line:
            k, _, v = line.partition("=")
            sect[k.strip()] = v.strip()
    return out


def options_problems(common_ini: Path) -> list[str]:
    """What Config/common.ini lacks for the bridge, empty when nothing: the [Experts] section with WebRequest on, a
    listed URL (MT5 keeps the list encrypted, so only that it is there is checked; nothing else adds a URL),
    algorithmic trading off and DLL imports not on."""
    ex = read_ini(common_ini).get("Experts")
    if ex is None:
        return ["no [Experts] section in Config/common.ini (MT5 did not save the Options)"]
    probs = []
    if ex.get("WebRequest") != "1":
        probs.append("WebRequest is not on")
    if not ex.get("WebRequestUrl"):
        probs.append("no URL in the WebRequest list")
    if ex.get("Enabled") != "0":
        probs.append("algorithmic trading is not off")
    if ex.get("AllowDllImport") == "1":         # 0 after every real setup; 1 only if a shifted layout ticked it
        probs.append("DLL imports are not off")
    return probs


def disable_mcp(assistant_ini: Path) -> None:
    """Enable=0 in every [MCP.*] section of Config/assistant.ini: MT5 6272 runs an MCP server on 127.0.0.1:22346 (and
    MetaEditor's on 22345) by default, and the read-only bridge needs neither. Run only while the terminal is closed.
    The file's encoding, line ends and other lines (its API keys) are kept as they are and never printed."""
    try:
        raw = assistant_ini.read_bytes()
    except FileNotFoundError:
        return
    sect, out = None, []
    for line in _text(raw).splitlines(keepends=True):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            sect = s[1:-1]
        elif (sect or "").startswith("MCP.") and s.partition("=")[0].strip() == "Enable":
            line = "Enable=0" + line[len(line.rstrip("\r\n")):]
        out.append(line)
    new = "".join(out)
    if raw[:2] == b"\xff\xfe":
        data = b"\xff\xfe" + new.encode("utf-16-le")
    elif raw[:2] == b"\xfe\xff":
        data = b"\xfe\xff" + new.encode("utf-16-be")
    else:
        data = new.encode("utf-8")
    if data != raw:
        assistant_ini.write_bytes(data)


def mcp_problems(assistant_ini: Path) -> list[str]:
    on = [s for s, kv in read_ini(assistant_ini).items() if s.startswith("MCP.") and kv.get("Enable") != "0"]
    return [f"the MCP server is still on in Config/assistant.ini ({', '.join(on)})"] if on else []


def running_build(mt5: Path) -> int | None:
    """The build in the newest 'MetaTrader 5 x64 build N started' line of the terminal's journal (logs/YYYYMMDD.log;
    MetaEditor's log is not read)."""
    for log in sorted((mt5 / "logs").glob("[0-9]*.log"), reverse=True):
        found = re.findall(r"MetaTrader 5 x64 build (\d+) started", _text(log.read_bytes()))
        if found:
            return int(found[-1])
    return None


class Setup(D.Demo):
    def __init__(self, base: Path, secrets: dict, alias: str):
        super().__init__(base, login=True)
        self.secrets = secrets
        self.alias = alias
        self.common_ini = self.mt5 / "Config" / "common.ini"

    # ---------- the terminal and its windows ----------
    def popen_terminal(self, *args: str) -> subprocess.Popen:
        p = subprocess.Popen(["wine", "terminal64.exe", "/portable", *args], cwd=self.mt5, env=self.env,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.procs.append(p)
        return p

    def main_window(self) -> str | None:
        """The terminal's main window: visible, of the terminal64.exe class, at least 1000 px wide and not named like
        a Login or LiveUpdate window (its dialogs share the class, the search order is not fixed, and real run 2 once
        logged the Login window at the main window's 1280x998 while it was being made)."""
        for wid in self.xdo_out("search", "--onlyvisible", "--classname", "terminal64.exe"):
            geo = dict(x.split("=", 1) for x in self.xdo_out("getwindowgeometry", "--shell", wid) if "=" in x)
            if not (geo.get("WIDTH", "").isdigit() and int(geo["WIDTH"]) >= 1000):
                continue
            name = " ".join(self.xdo_out("getwindowname", wid))
            if not any(re.search(pattern, name) for pattern in POPUPS):
                return wid
        return None

    def dismiss_popups(self) -> int:
        """Escape, sent to each visible Login or LiveUpdate window by its id (key --window: with no window manager,
        windowactivate is refused). Never Return: on the LiveUpdate window it would press Restart. Returns how many
        windows got it."""
        n = 0
        for pattern in POPUPS:
            for wid in self.xdo_out("search", "--onlyvisible", "--name", pattern):
                self.xdo("key", "--window", wid, "Escape")
                n += 1
                time.sleep(1)
        return n

    def settle_popups(self, at_least: int) -> None:
        """dismiss_popups about once a second until at least `at_least` seconds have passed and none has shown for
        POPUP_QUIET_S seconds (at most POPUP_LIMIT_S): a Login window can show some seconds after the main window,
        later on a slower server, and a modal one would take the keys and clicks meant for Options."""
        quiet = 0
        for t in range(1, POPUP_LIMIT_S + 1):
            quiet = 0 if self.dismiss_popups() else quiet + 1
            if t >= at_least and quiet >= POPUP_QUIET_S:
                return
            time.sleep(1)

    def wait_main_window(self, p: subprocess.Popen, which: str) -> tuple[str, int]:
        """The main window's id and about how many seconds it took to show; after MAIN_WAIT_S the terminal is closed
        and the setup stops."""
        for waited in range(0, MAIN_WAIT_S, 2):
            wid = self.main_window()
            if wid:
                return wid, waited
            time.sleep(2)
        self.close_terminal(p, which)
        raise SystemExit(f"mt5 setup: the terminal's main window did not show within {MAIN_WAIT_S} s of the {which}; "
                         "nothing was marked done: paste the install line again (Enter keeps the MT5 login)")

    @staticmethod
    def _ends(p: subprocess.Popen, seconds: int) -> bool:
        try:
            p.wait(timeout=seconds)
            return True
        except subprocess.TimeoutExpired:
            return False

    def close_terminal(self, p: subprocess.Popen, which: str) -> None:
        """A clean close, so the terminal writes its settings and the saved login: `wine taskkill` without /f (exit 0 in
        about 2 s on the real path, even with a modal window open), then alt+F4 sent to the main window. A terminal
        still running after that fails the setup (main then stops Wine)."""
        try:
            D.run(["wine", "taskkill", "/im", "terminal64.exe"], cwd=self.mt5, env=self.env, check=False, timeout=60,
                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except subprocess.TimeoutExpired:
            pass
        if self._ends(p, 60):
            return
        wid = self.main_window()
        if wid:
            self.xdo("key", "--window", wid, "alt+F4")
            if self._ends(p, 60):
                return
        raise SystemExit(f"mt5 setup: the terminal did not close after the {which}; nothing was marked done")

    # ---------- the two starts ----------
    def login_start(self) -> None:
        presets = self.mt5 / "MQL5" / "Presets"
        presets.mkdir(parents=True, exist_ok=True)
        (presets / "edge.set").write_text(f"InpAlias={self.alias}\r\nInpUrl={D.INGEST_URL}\r\n"
                                          "InpTokenFile=edge_bridge_token.txt\r\n", encoding="utf-16")
        self.ini.parent.mkdir(parents=True, exist_ok=True)
        D.write_private(self.ini, login_ini(self.secrets))
        p = self.popen_terminal(r"/config:C:\edge\start.ini")
        _, waited = self.wait_main_window(p, "login start")   # the start file has been read once the window shows
        time.sleep(max(0, 45 - waited))
        self.ini.unlink(missing_ok=True)       # the login file lives only while the terminal starts
        time.sleep(25)                         # time to log in and keep the login
        self.dismiss_popups()
        self.close_terminal(p, "login start")

    def options_start(self) -> int:
        """Tools > Options in a start with no start file (build 6272 saves Options to Config/common.ini only then).
        Returns the running build. A build whose click points were not measured is clicked too (MetaQuotes' web
        installer gives whatever build is current), behind the same checks as a measured one: Options must show at
        run_demo.OPTIONS_AT, both checkbox points must read as checkboxes and each clicked box its new state, and the
        common.ini read-back decides; otherwise the Options window gets Escape (no save) and nothing is done."""
        p = self.popen_terminal()
        main, _ = self.wait_main_window(p, "settings start")
        build = running_build(self.mt5)
        measured = "measured" if build in MEASURED_BUILDS else (
            "not measured: clicked only where Options and its checkboxes read as on builds "
            + " and ".join(map(str, sorted(MEASURED_BUILDS))))
        print(f"mt5 setup: terminal build {build} (click points {measured})", flush=True)
        if not options_problems(self.common_ini):
            self.close_terminal(p, "settings start")
            return build
        listed = bool(read_ini(self.common_ini).get("Experts", {}).get("WebRequestUrl"))
        self.settle_popups(POPUP_SETTLE_S)
        try:
            self.allow_webrequest(add_url=not listed, window=main)
        except D.OptionsError as e:
            self.close_terminal(p, "settings start")
            advice = ("paste the install line again (Enter keeps the MT5 login)" if e.retry else
                      "this needs a code update with new click points, and pasting the install line again will not "
                      "help")
            raise SystemExit(f"mt5 setup: Tools > Options could not be set on MT5 build {build}: {e}. Nothing was "
                             f"marked done: {advice}") from None
        self.close_terminal(p, "settings start")
        return build


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--base", default="/home/mt5/edge")
    ap.add_argument("--alias", default="main")
    a = ap.parse_args(argv)
    secrets = parse_secrets(sys.stdin)
    base = Path(a.base)
    (base / "setup.done").unlink(missing_ok=True)     # only this run's own checks may mark the setup done
    s = Setup(base, secrets, a.alias)
    # stopping the install unit sends SIGTERM: as an exit, so `finally` removes start.ini (the investor password)
    old_term = signal.signal(signal.SIGTERM, D._terminated)
    try:
        if (s.mt5 / "terminal64.exe").exists() and (s.mt5 / "MQL5" / "Experts").exists():   # install_mt5's own test
            print("mt5 setup: MT5 already installed: kept", flush=True)
        else:
            print("mt5 setup: installing MT5 (MetaQuotes' installer, pinned by stage2)", flush=True)
        s.install_mt5()
        print("mt5 setup: compiling the EA", flush=True)
        s.compile_ea()
        D.write_private(s.common_files() / "edge_bridge_token.txt", secrets["EDGE_INGEST_TOKEN"])
        # a login change: the old account's run.ini goes first, so no start until setup.done can log the old account
        # in under the new alias (the EA's preset gets the new alias in login_start)
        (s.prefix / "drive_c" / "edge" / "run.ini").unlink(missing_ok=True)
        print("mt5 setup: first start with the investor login", flush=True)
        s.login_start()
        print("mt5 setup: Tools > Options in a start without a start file", flush=True)
        build = s.options_start()
        after = running_build(s.mt5)
        if after != build:
            raise SystemExit(f"mt5 setup: the terminal changed from build {build} to {after} during the setup "
                             "(LiveUpdate); nothing was marked done: paste the install line again (Enter keeps the "
                             "MT5 login)")
        assistant = s.mt5 / "Config" / "assistant.ini"
        disable_mcp(assistant)                         # the terminal is closed now
        problems = options_problems(s.common_ini) + mcp_problems(assistant)
        if problems:
            raise SystemExit("mt5 setup: MT5 did not save the settings the bridge needs: " + "; ".join(problems)
                             + ". Nothing was marked done: paste the install line again (Enter keeps the MT5 login)")
        D.write_private(s.prefix / "drive_c" / "edge" / "run.ini", run_ini(secrets))
        (base / "setup.done").write_text(f"ok build {build}\n")      # stage2.sh shows the build in its progress lines
        print("mt5 setup: done", flush=True)
        return 0
    finally:
        try:
            s.ini.unlink(missing_ok=True)
            s.stop()
        finally:
            signal.signal(signal.SIGTERM, old_term)


if __name__ == "__main__":
    sys.exit(main())
