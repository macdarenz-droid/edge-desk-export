"""T1-M v1, the rule itself (research/volume/T1M_RULE.md on the research branch). Pure code: no database, no clock.
The live step (app/t1m/step.py) and the parity replay (evidence/t1m/replay_parity.py) both call evaluate_day, so the
app trades on paper exactly what the replay checks.

The rule (EUR/USD, London weekdays, mid = (bid + ask) / 2):
  signal  a 1-minute candle that opens 10:00-12:44 London and closes above the highest high of the 30 one-minute
          candles before it (minute closes forward-filled through missing minutes, as the research does);
          after a signal, the next one needs its minute more than 30 minutes later
  entry   paper SELL at the open of the first bar from the next minute, at most 6 minutes later, at mid - 0.1 pip
  stop    fill + 60 pips, checked on the ask (mid high + 0.1) from the fill minute; a stop fills at
          max(stop, ask open of that minute) (the fill minute itself: at the stop)
  exit    every open trade at 13:00:00 London: the close of the 12:59 candle (or the last close before it) + 0.1
  pips    (fill - exit) - 0.5 commission - 0.5 more when stopped

Prices are held as whole numbers: s = bid points + ask points (1 point = 0.00001), so mid = s / 200000 and one unit
of s is 0.05 pip. Every comparison is exact (no float ties).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from app.timeutil import LONDON

@dataclass(frozen=True)
class Stream:
    """One proven paper stream: everything the rule code needs, in one place, so a second stream that passed its own
    proof is added as one more Stream (plus its parity run), not new code. Times are London minutes of the day.

    Only the T1-M shape is coded: a sell after a candle closes above the highest high of the previous `lookback`
    candles, exits at `exit_min`'s close. Another shape (a buy, a fade of a fall) needs its own code and parity run;
    evaluate_day refuses a stream it cannot run."""
    id: str                        # the rule id in the suggestion log, alert keys and tables, e.g. "T1M-V1"
    name: str                      # what the phone and Today show, e.g. "T1-M"
    pair: str = "EUR_USD"          # the feed's instrument (m1_bar holds EUR/USD only today)
    pair_label: str = "EUR/USD"
    side: int = -1                 # -1 sell
    shape: str = "rally_above_high"
    signal_from: int = 10 * 60     # first signal minute (its candle opens then)
    signal_to: int = 12 * 60 + 44  # last signal minute
    lookback: int = 30             # candles before the signal candle
    spacing: int = 30              # a new signal needs its minute > last signal minute + spacing
    fill_within: int = 6           # the fill: the first bar within this many minutes after the signal minute
    exit_min: int = 12 * 60 + 59   # the exit is this candle's close
    stop_pips: float = 60.0
    pip: float = 0.0001
    half_spread_pips: float = 0.1
    commission_pips: float = 0.5
    stop_slip_pips: float = 0.5
    tested: str = ""               # the fixed record line (unseen-data results), shown on every alert and on Today

    @property
    def unit_pip(self) -> int:     # units of s per pip (s = bid + ask in points of 0.00001)
        return int(round(2 * self.pip / 0.00001))

    @property
    def half_spread(self) -> int:
        return int(round(self.half_spread_pips * self.unit_pip))

    @property
    def stop_units(self) -> int:
        return int(round(self.stop_pips * self.unit_pip))


T1M_V1 = Stream(
    id="T1M-V1", name="T1-M",
    tested=("Tested on unseen data: 2021-Jun 2025 +1.26 pips a trade, Jul 2025-Nov 2026 +1.02. "
            "Paper. Not proven live."))
STREAMS = {s.id: s for s in (T1M_V1,)}

# T1-M's values under their old names (tests and the parity replay read them).
RULE_ID = T1M_V1.id
SIGNAL_FROM, SIGNAL_TO, LOOKBACK, SPACING = T1M_V1.signal_from, T1M_V1.signal_to, T1M_V1.lookback, T1M_V1.spacing
FILL_WITHIN, EXIT_MIN = T1M_V1.fill_within, T1M_V1.exit_min
UNIT_PIP, HALF_SPREAD, STOP_UNITS = T1M_V1.unit_pip, T1M_V1.half_spread, T1M_V1.stop_units
COMMISSION_PIPS, STOP_SLIP_PIPS = T1M_V1.commission_pips, T1M_V1.stop_slip_pips


def pts(price: float) -> int:
    """A quote price as whole points (1.08913 -> 108913)."""
    return int(round(float(price) * 100000))


def price_of(units: int) -> float:
    """Units of s (twice the mid in points) to a price, rounded to 0.000005."""
    return round(units / 200000.0, 6)


def london_midnight_ts(day: date) -> int:
    return int(datetime(day.year, day.month, day.day, tzinfo=LONDON).timestamp())


def minute_ts(day: date, minute: int) -> int:
    """Unix seconds of London minute-of-day `minute` on `day`. London's clock changes on Sundays only, so on a
    weekday the minute of the day is (ts - midnight) // 60."""
    return int(datetime(day.year, day.month, day.day, minute // 60, minute % 60, tzinfo=LONDON).timestamp())


def is_filler(row) -> bool:
    """A zero-volume flat bar (no trade in the minute): the research drops these."""
    return int(row["volume"]) == 0 and len({row["bid_o"], row["bid_h"], row["bid_l"], row["bid_c"]}) == 1 \
        and len({row["ask_o"], row["ask_h"], row["ask_l"], row["ask_c"]}) == 1


@dataclass
class DayBars:
    """One London day's mid bars by minute of day (units of s)."""
    day: date
    o: dict = field(default_factory=dict)
    h: dict = field(default_factory=dict)
    c: dict = field(default_factory=dict)
    known_to: int = 0          # minutes < known_to are final (the feed's complete_through, as a minute of the day)


def day_bars(day: date, rows, complete_through: int | None) -> DayBars:
    """Build a DayBars from m1_bar-like rows (dicts or sqlite rows with ts and bid_/ask_ OHLC, volume). Only rows of
    that London day with ts < complete_through are used; complete_through None means the whole day is final."""
    lo = london_midnight_ts(day)
    nxt = day + timedelta(days=1)
    hi = london_midnight_ts(nxt)
    end = hi if complete_through is None else min(hi, int(complete_through))
    out = DayBars(day)
    for r in rows:
        ts = int(r["ts"])
        if ts < lo or ts >= end or is_filler(r):
            continue
        m = (ts - lo) // 60
        out.o[m] = pts(r["bid_o"]) + pts(r["ask_o"])
        out.h[m] = pts(r["bid_h"]) + pts(r["ask_h"])
        out.c[m] = pts(r["bid_c"]) + pts(r["ask_c"])
    out.known_to = 24 * 60 if end >= hi else max(0, (end - lo) // 60)
    return out


@dataclass
class Trade:
    signal_m: int                    # the signal candle's minute (London minute of day)
    signal_close: int                # its close (units), the reference price for the phone
    state: str = "pending"           # pending (fill not known yet), nofill, open, stopped, closed
    fill_m: int | None = None
    entry: int | None = None         # sell fill, units (mid open - 0.1 pip)
    stop: int | None = None          # entry + 60 pips
    exit_m: int | None = None
    exit: int | None = None
    pips: float | None = None

    @property
    def stopped(self) -> bool:
        return self.state == "stopped"

    def as_dict(self, day: date) -> dict:
        d = {"signal_m": self.signal_m, "signal_ts": minute_ts(day, self.signal_m), "state": self.state,
             "ref": price_of(self.signal_close), "fill_m": self.fill_m, "entry": None, "stop": None,
             "exit_m": self.exit_m, "exit": None, "pips": self.pips}
        if self.fill_m is not None:
            d["fill_ts"] = minute_ts(day, self.fill_m)
            d["entry"], d["stop"] = price_of(self.entry), price_of(self.stop)
        if self.exit is not None:
            d["exit"] = price_of(self.exit)
            d["exit_ts"] = minute_ts(day, self.exit_m) + (60 if self.state == "closed" else 0)   # a time exit: its close
        return d


def signals(b: DayBars, st: Stream = T1M_V1) -> list[tuple[int, int]]:
    """(minute, close) of each signal known so far, after the spacing."""
    out, last = [], None
    cf = None
    for m in range(0, min(b.known_to, st.signal_to + 1)):
        if m in b.c:
            cf = b.c[m]
        if m < st.signal_from or cf is None:
            continue
        hs = [b.h[k] for k in range(m - st.lookback, m) if k in b.h]
        if hs and cf <= max(hs):
            continue
        if last is not None and m - last <= st.spacing:
            continue
        out.append((m, cf))
        last = m
    return out


def _close_at(b: DayBars, m: int) -> int | None:
    """The forward-filled close at minute m (the last close at or before m)."""
    for k in range(m, -1, -1):
        if k in b.c:
            return b.c[k]
    return None


def evaluate_day(b: DayBars, st: Stream = T1M_V1) -> list[Trade]:
    """Every paper trade of the stream that day, as far as the known minutes show."""
    if st.shape != "rally_above_high" or st.side != -1:
        raise ValueError(f"stream {st.id}: shape {st.shape} side {st.side} is not coded")
    hs_, stop_units, ex = st.half_spread, st.stop_units, st.exit_min
    trades = []
    for m, close in signals(b, st):
        t = Trade(m, close)
        trades.append(t)
        j = next((k for k in range(m + 1, m + st.fill_within + 1) if k in b.o), None)
        if j is None:
            t.state = "nofill" if b.known_to > m + st.fill_within else "pending"
            continue
        if j >= ex:
            t.state = "nofill"
            continue
        t.fill_m, t.entry = j, b.o[j] - hs_
        t.stop = t.entry + stop_units
        t.state = "open"
        for k in range(j, min(ex + 1, b.known_to)):
            if k in b.h and b.h[k] + hs_ >= t.stop:
                t.exit = max(t.stop, b.o[k] + hs_) if k > j else t.stop
                t.exit_m, t.state = k, "stopped"
                break
        if t.state == "open" and b.known_to > ex:
            c = _close_at(b, ex)
            t.exit, t.exit_m, t.state = c + hs_, ex, "closed"
        if t.exit is not None:
            gross = (t.entry - t.exit) / st.unit_pip
            t.pips = round(gross - st.commission_pips - (st.stop_slip_pips if t.stopped else 0.0), 2)
    return trades


def day_final(b: DayBars, st: Stream = T1M_V1) -> bool:
    """The exit time has passed in the data: every trade of the day is settled."""
    return b.known_to > st.exit_min


# Sizing rule W (research/volume/round2/sizing_FROZEN_W.md, frozen 9 Nov 2026 before its proof): raw size 0.5 on a
# London Monday or Tuesday, 1.0 Wednesday to Friday, scaled so the average is risk_usd. The frozen file's
# normalisation (mean raw 0.7998 on 2005-2020 trades) gives $100.03 / $200.05 at 160; the research session's spec is
# $100 / $200, i.e. raw / 0.8 (the weekday mix 2 x 0.5 + 3 x 1.0 over 5). Lots are the same either way (0.16 / 0.33).
W_FACTOR = {0: 0.625, 1: 0.625, 2: 1.25, 3: 1.25, 4: 1.25}


def risk_for(day: date, risk_usd: float, sizing: str) -> float:
    """Dollars at the stop for a trade on that London day: W (Mon/Tue half size) or flat."""
    if sizing == "flat":
        return float(risk_usd)
    if sizing != "W":
        raise ValueError(f"sizing {sizing!r}")
    return round(float(risk_usd) * W_FACTOR.get(day.weekday(), 1.25), 2)


def size_line(day: date, risk_usd: float, sizing: str, stop_pips: float) -> str:
    """'Suggested size: 0.16 lots ($100 risk, Mon/Tue half size)' (research session's wording, 10 Nov)."""
    r = risk_for(day, risk_usd, sizing)
    note = ", Mon/Tue half size" if sizing == "W" and day.weekday() in (0, 1) else ""
    return f"Suggested size: {lots(r, stop_pips):.2f} lots (${r:g} risk{note})"


def lots(risk_usd: float, stop_pips: float, usd_per_pip_per_lot: float = 10.0) -> float:
    """Lots for a dollar risk at the stop, rounded DOWN to 0.01 (0.26 for $160 and 60 pips at $10 a pip a lot)."""
    if stop_pips <= 0 or risk_usd <= 0:
        return 0.0
    hundredths = int((round(risk_usd * 100) * 100) // round(stop_pips * usd_per_pip_per_lot * 100))
    return hundredths / 100.0
