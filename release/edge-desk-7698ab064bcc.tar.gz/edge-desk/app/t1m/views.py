"""Paper streams on Today: one block per enabled stream ("T1-M (paper)" first). Every word and number is made here;
the screen only shows them."""
from __future__ import annotations

import sqlite3
from datetime import datetime

from app.t1m import alerts as TA
from app.t1m import rule
from app.t1m.step import get_state, london_now, streams
from app.timeutil import LONDON

TESTED = TA.TESTED


def _rows(conn: sqlite3.Connection, st: rule.Stream, day_iso: str) -> dict:
    """signal_ts -> {stage: row} for a stream's counted trades of a day."""
    out: dict = {}
    for r in conn.execute("SELECT * FROM t1m_trade WHERE stream = ? AND day = ? AND counted = 1"
                          " ORDER BY signal_ts, id", (st.id, day_iso)):
        out.setdefault(r["signal_ts"], {})[r["stage"]] = dict(r)
    return out


def _line(st: rule.Stream, sig_ts: int, s: dict) -> str:
    side = TA.SIDE_WORD[st.side]
    at = TA.london_hm(sig_ts + 60)
    if "closed" in s:
        c = s["closed"]
        how = "stop" if c["exit_type"] == "stop" else TA.exit_hm(st)
        return f"{at} London: {side} {TA.px(c['entry'])}, out {TA.px(c['exit'])} ({how}), {c['pips']:+.2f} pips"
    if "nofill" in s:
        return f"{at} London: signal, no price within {st.fill_within} minutes (no paper trade)"
    if "filled" in s:
        f = s["filled"]
        return f"{at} London: {side} {TA.px(f['entry'])}, stop {TA.px(f['stop'])}, open"
    return f"{at} London: signal at {TA.px(s['signal']['ref'])}, paper fill next minute"


def record(conn: sqlite3.Connection, st: rule.Stream = rule.T1M_V1) -> dict:
    r = conn.execute("SELECT COUNT(*), COALESCE(SUM(pips), 0), MIN(day), SUM(exit_type = 'stop'), COALESCE(SUM(usd), 0)"
                     " FROM t1m_trade WHERE stream = ? AND stage = 'closed' AND counted = 1", (st.id,)).fetchone()
    days = conn.execute("SELECT COUNT(*) FROM t1m_day WHERE stream = ?", (st.id,)).fetchone()[0]
    return {"trades": int(r[0]), "pips": round(float(r[1]), 2), "since": r[2], "stops": int(r[3] or 0), "days": days,
            "usd": round(float(r[4]), 2)}


def stream_block(conn: sqlite3.Connection, cfg, st: rule.Stream, sc, now: datetime) -> dict:
    day, minute = london_now(now)
    trades = _rows(conn, st, day.isoformat())
    n_open = sum(1 for s in trades.values() if "closed" not in s and "nofill" not in s)
    x = TA.exit_ts(day, st)
    xm = st.exit_min + 1
    first, last = rule.minute_ts(day, st.signal_from), st.signal_to
    if day.weekday() >= 5:
        status = f"Weekend: no {st.name}"
    elif not cfg.feed.enabled:
        status = "Off: no price feed"
    elif n_open:
        status = f"{n_open} open: close at {TA.exit_hm(st)} London ({TA.melb_hm(x)} Melbourne)"
    elif minute < st.signal_from:
        status = f"Waiting: watching from {TA.london_hm(first)} London ({TA.melb_hm(first)} Melbourne)"
    elif minute <= last:
        status = f"Watching {TA.london_hm(first)}-{last // 60:02d}:{last % 60:02d} London"
    elif minute < xm:
        status = f"No new signals after {last // 60:02d}:{last % 60:02d} London"
    else:
        status = "Done for today"
    rec = record(conn, st)
    since = get_state(conn, "started_ts")
    if rec["trades"]:
        usd = rec["usd"]
        fwd = (f"Paper record since {rec['since']}: {rec['trades']} trades, {rec['pips']:+.1f} pips "
               f"({rec['pips'] / rec['trades']:+.2f} a trade), {rec['stops']} stopped; "
               f"{'+' if usd >= 0 else '-'}${abs(usd):,.0f} at the suggested sizes.")
    elif since is not None:
        fwd = f"Paper record since {datetime.fromtimestamp(int(since), LONDON):%d %b %Y}: no trades yet."
    else:
        fwd = "Paper record: starts with the first run."
    return {"id": st.id, "title": f"{st.name} (paper)", "label": "Paper", "status": status,
            "lines": [_line(st, ts, s) for ts, s in sorted(trades.items())],
            "size": (f"{rule.size_line(day, sc.risk_usd, sc.sizing, st.stop_pips)} today, at a {st.stop_pips:g}-pip"
                     " stop and $10 a pip for 1 lot."),
            "forward": fwd, "tested": st.tested}


def today_block(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    """{"enabled": False} when no stream is on; else the first stream's block (T1-M) at the top level, as the screen
    reads it, and every stream's block in "streams"."""
    on = streams(cfg)
    if not on:
        return {"enabled": False}
    blocks = [stream_block(conn, cfg, st, sc, now) for st, sc in on]
    return {"enabled": True, **blocks[0], "streams": blocks}
