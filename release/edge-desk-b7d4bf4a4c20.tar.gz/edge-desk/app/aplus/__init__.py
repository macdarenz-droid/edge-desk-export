"""The A+, paper only (docs/APLUS_DESIGN.md): since 30 Oct 2026 the A22 pick `D4h 3m+5m`, buys and sells on EUR/USD,
in place of the v3 short (owner: "And also yes to replace a+ of a22"). Its rule is not written here: pinned byte copies
of its verified live rule (app/aplus/pinned, checked by pins.py) run in their own `python -I -B` process (child.py),
with the app's book (book.py: the guard kept from the v3 bot, the paper size, broker prices by side). The app adds
bars in at every 1-minute close (step.py), alert texts (alerts.py), the Today block (views.py) and the tested record
(record.py). Never an order card, never the planner slot, never an order. desk/evidence/a22/NOTES.md: the decisions,
the guard rules kept and dropped, and the parity through the app."""
