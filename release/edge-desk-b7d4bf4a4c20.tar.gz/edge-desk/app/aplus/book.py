"""The A+ book: what the app adds to the pinned A22 rule's events in the child process (app/aplus/child.py). The rule
(`D4h 3m+5m`, research/a22_live live.Runner, pinned in app/aplus/pinned) gives the order, the fill and the end of each
London day; this file adds the guard, the paper size, the broker prices and the alert facts. Standard library only:
the child imports it before nothing else is needed, and the parent never runs it. Never an order, never a real size.

Decisions of 30 Oct 2026 (owner: "And also yes to replace a+ of a22"; job brief decisions 2 and 3):

Both sides. The rule trades buys and sells on EUR/USD. Every price, word and R here follows the order's own side.

Broker prices (the rule's prices are exact K1 units, price x 400,000, and can fall between broker points of 0.00001):
the stop rounds away from the entry, so it is never tighter than the rule's (a sell's up, a buy's down); the target
rounds toward the entry, so it is never further (a sell's up, a buy's down); the entry rounds away from the stop (a
sell's down, a buy's up; trader review, 30 Oct: the nearest point shrank the stop distance by up to 0.05 pip on 13 of
the 42 real orders), so the broker's entry-to-stop distance is never under the rule's. A buy is the exact mirror of a
sell (round_x(u, "buy") == -round_x(-u, "sell")). Lots come from the broker stop distance.

Held trades: a v3 short's trade or order still open when the A22 rule took over (app/aplus/step.py _switch) is held by
the guard as an open EUR/USD trade of one full size until 17:00 New York of its London day (the stricter reading);
it then counts as closed at 0 R, neither a win nor a loss.

The guard. From the v3 bot's BK3 guard (bot/guard.py at research commit f52dfb2839b1, sandbox/work/short_book/PLAN.md
N3), each rule that is side-neutral and holds on one pair is kept with the same threshold; only what was about the
second pair, or about sells only, is dropped. Nothing is raised; the owner's own day rules and [risk]/[paper] config are
not touched (KEPT and DROPPED below give each rule and why; desk/evidence/a22/NOTES.md lists them too).
"""
from __future__ import annotations

import datetime as dt
import math
from decimal import Decimal
from fractions import Fraction
from zoneinfo import ZoneInfo

LON = ZoneInfo("Europe/London")
NYZ = ZoneInfo("America/New_York")
PAIRS = ("EUR_USD",)
SIDES = ("sell", "buy")
RULE_TAG = "A22"                         # every alert id starts with it: never the v3 short's ids (ORDER:EUR_USD:...)
ALERT_KINDS = frozenset({"ORDER", "SKIPPED", "FILLED", "CANCELLED", "CLOSE_SOON", "CLOSED", "NO_TRADE_GAP",
                         "GAP_WARNING"})
UNITS_PER_POINT = 4                      # K1: 1 point = 0.00001 = 4 units; 1 pip = 10 points = 40 units

# ---------------------------------------------------------------- the thresholds (bot/guard.py, bot/sizing.py: never raised)
CAP = Fraction(3, 2)                     # rule 1: open risk + live orders + the new order, in full trades
DAY_STOP = Fraction(-3, 2)               # rule 4: the London day's closed net, in full trades
DAY_LOSSES = 2                           # rule 4: losing trades closed that London day
WEEK_BRAKE = Fraction(-2)                # rule 5: the week's closed net, in full trades
FULL = Fraction(1)
USD_PER_PIP_PER_LOT = {"EUR_USD": 10}    # quote currency USD: 100,000 x 0.0001 = $10
MIN_LOTS = Fraction(1, 100)
COMMISSION_PER_LOT = 5                   # the owner's MT5 raw account, round trip, shown beside the size
MAX_RISK_PCT_BEFORE_25 = Fraction(1)     # N2: at most 1% a trade until 25 forward A+ trades

KEPT = {
    "rule 1": "risk cap: open risk (open trades, whose stops never move) plus every live order counted as filled plus "
              "the new order at most 1.5 full, else the order is not placed. Side-neutral; holds on one pair.",
    "rule 3": "one open trade per pair: v3 said one open short per pair because it only sold; the side-neutral reading "
              "counts a long too (the stricter one). A22 closes by 17:00 New York, so it trips only on data trouble.",
    "rule 4": "day stop: the London day's closed net at or under -1.5 full, or 2 losing trades closed that day, blocks "
              "a new order that day. Side-neutral; with one order a pair-day it cannot trip on its own day.",
    "rule 5": "weekly brake: the week's closed net (Monday 00:00 London to Friday 17:00 New York) at or under -2.0 full "
              "blocks every new order until Monday. Side-neutral; holds on one pair.",
    "rule 6": "size: 1 full is risk % of the London-day opening balance ([paper] balance x [risk] risk_pct_per_trade), "
              "never larger after a loss (capped at the last losing trade's full $). Side-neutral.",
    "rule 7": "the firm limit: 1.5 full at most half the funded firm's daily loss limit. Kept in code and off in the "
              "app, as for v3 (docs/APLUS_DESIGN.md D8: paper, no firm money at stake). Side-neutral.",
    "rule 8": "the thresholds are fixed here and only ever tightened. Side-neutral.",
    "N2": "risk over 1% a trade is refused until 25 forward A22 trades (the step passes the count of placed A22 "
          "trades closed since its first check); after that only the owner's [risk] config sets the risk, which "
          "nothing raises; lots rounded down to 0.01 and refused under 0.01. Side-neutral.",
}
DROPPED = {
    "rule 2": "both pairs: the second pair's order skipped or halved and the first resized. It is about the second "
              "pair (GBP/USD), and this step trades EUR/USD only.",
    "RESIZE": "the resize alert: only rule 2 made one, so it goes with it.",
    "BUY_SIGNAL": "v3 made a buy setup a no trade because the A+ short was sells only; the A22 pick trades buys and "
                  "sells, so a buy is an order.",
    "GBP_USD": "GBP/USD's pip value in the sizing: the second pair, not traded here.",
}


class SizeError(ValueError):
    pass


# ---------------------------------------------------------------- clocks


def lon(d: dt.date, hh: int, mm: int = 0) -> int:
    return int(dt.datetime(d.year, d.month, d.day, hh, mm, tzinfo=LON).timestamp())


def nyt(d: dt.date, hh: int, mm: int = 0) -> int:
    return int(dt.datetime(d.year, d.month, d.day, hh, mm, tzinfo=NYZ).timestamp())


def week_window(D: dt.date) -> tuple[int, int]:
    """[Monday 00:00 London, Friday 17:00 New York] of the week holding London date D (unix seconds)."""
    mon = D - dt.timedelta(days=D.weekday())
    return lon(mon, 0), nyt(mon + dt.timedelta(days=4), 17)


def alert_id(kind: str, pair: str, date_iso: str) -> str:
    return f"{RULE_TAG}:{kind}:{pair}:{date_iso}"


# ---------------------------------------------------------------- sizing (bot/sizing.py, EUR/USD only)


def exact(x) -> Fraction:
    """int, Fraction, Decimal or decimal text/float -> Fraction (floats go through their shortest text)."""
    if isinstance(x, Fraction):
        return x
    if isinstance(x, int):
        return Fraction(x)
    return Fraction(Decimal(str(x)))


def _exact_input(x, what: str) -> Fraction:
    try:
        return exact(x)
    except (ArithmeticError, ValueError, TypeError):
        raise SizeError(f"{what} {x!r} is not a number") from None


def check_risk(risk_pct, aplus_trades_done: int = 0) -> Fraction:
    """N2: risk % above 0, and at most 1% until 25 forward A+ trades."""
    if not isinstance(aplus_trades_done, int) or aplus_trades_done < 0:
        raise SizeError(f"forward A+ trades done must be a whole number of 0 or more (got {aplus_trades_done!r})")
    pct = _exact_input(risk_pct, "risk %")
    if pct <= 0:
        raise SizeError(f"risk % must be above 0 (got {risk_pct})")
    if pct > MAX_RISK_PCT_BEFORE_25 and aplus_trades_done < 25:
        raise SizeError(f"risk {risk_pct}% is over the 1% ceiling that holds until 25 forward A+ trades (PLAN N2)")
    return pct


def check_usd(x, what: str = "balance") -> Fraction:
    v = _exact_input(x, what)
    if v <= 0:
        raise SizeError(f"{what} must be above 0 (got {x})")
    return v


def full_risk_usd(opening_balance, risk_pct, last_loss_full_usd=None, aplus_trades_done: int = 0) -> Fraction:
    """$ of 1 full: risk_pct % of the London-day opening balance, never larger after a loss (rule 6)."""
    pct = check_risk(risk_pct, aplus_trades_done)
    usd = check_usd(opening_balance) * pct / 100
    if last_loss_full_usd is not None:
        usd = min(usd, exact(last_loss_full_usd))
    return usd


def fmt_lots(x) -> str:
    return "%.2f" % float(x)


def fmt_usd(x) -> str:
    return "{:,.2f}".format(float(x))


def fmt_pips(x) -> str:
    return ("%.2f" % float(x)).rstrip("0").rstrip(".")


def lots(pair: str, risk_usd, stop_pips) -> Fraction:
    """Lots for risk_usd over a stop of stop_pips, rounded down to 0.01; SizeError under 0.01 or for another pair."""
    if pair not in USD_PER_PIP_PER_LOT:
        raise SizeError(f"no pip value for {pair}")
    r, sp = exact(risk_usd), exact(stop_pips)
    if sp <= 0:
        raise SizeError("stop distance must be above 0 pips")
    raw = r / (sp * USD_PER_PIP_PER_LOT[pair])
    out = Fraction(math.floor(raw * 100), 100)
    if out < MIN_LOTS:
        raise SizeError(f"size {float(raw):.4f} lots is under the 0.01 minimum: risk ${fmt_usd(r)} over "
                        f"{fmt_pips(sp)} pips is too small")
    return out


def check_firm_limit(daily_loss_limit_usd, full_usd) -> bool:
    """Rule 7: 1.5 full must be at most half the firm's daily loss limit."""
    return CAP * exact(full_usd) <= exact(daily_loss_limit_usd) / 2


# ---------------------------------------------------------------- broker prices by side


def _side(side: str) -> str:
    if side not in SIDES:
        raise ValueError(f"side {side!r}: only sell or buy")
    return side


def _points(units) -> Fraction:
    return Fraction(units) / UNITS_PER_POINT


def round_entry(units, side: str) -> int:
    """Away from the stop: a sell's down (its stop is above), a buy's up, so the broker's entry-to-stop distance is
    never under the rule's."""
    p = _points(units)
    return math.floor(p) if _side(side) == "sell" else math.ceil(p)


def round_stop(units, side: str) -> int:
    """Away from the entry, never tighter than the rule's stop: a sell's up, a buy's down."""
    p = _points(units)
    return math.ceil(p) if _side(side) == "sell" else math.floor(p)


def round_target(units, side: str) -> int:
    """Toward the entry, never further than the rule's target: a sell's up (it is below), a buy's down."""
    p = _points(units)
    return math.ceil(p) if _side(side) == "sell" else math.floor(p)


def broker_plan(pair: str, side: str, E, S, T, risk_usd, no_size: str | None = None) -> dict:
    """Broker prices (points), stop and target distances (pips) and lots for risk_usd. lots is None with a reason when
    the size would be under 0.01 lots, or when risk_usd is None (no_size gives the reason)."""
    e, s, t = round_entry(E, side), round_stop(S, side), round_target(T, side)
    stop_pips, tgt_pips = Fraction(abs(s - e), 10), Fraction(abs(e - t), 10)
    if risk_usd is None:
        n, why = None, no_size or "no size"
    else:
        try:
            n, why = lots(pair, risk_usd, stop_pips), None
        except SizeError as err:
            n, why = None, str(err)
    return dict(entry=e, stop=s, target=t, stop_pips=stop_pips, target_pips=tgt_pips, lots=n, why=why)


# ---------------------------------------------------------------- the guard (kept rules only)


def weekly_brake(closed: list, D: dt.date) -> str | None:
    """Rule 5. closed: the trades closed by now, each {date, size, R, exit}."""
    w0, w1 = week_window(D)
    net = sum((o["size"] * o["R"] for o in closed if w0 <= o["exit"] <= w1), Fraction(0))
    return f"weekly brake (rule 5): week closed net {float(net):.2f} full" if net <= WEEK_BRAKE else None


def day_stop(closed: list, D: dt.date) -> str | None:
    """Rule 4: the London day's closed net at or under -1.5 full, or 2 losing trades closed that day."""
    today = [o for o in closed if o["date"] == D]
    net = sum((o["size"] * o["R"] for o in today), Fraction(0))
    n = sum(1 for o in today if o["R"] < 0)
    if net <= DAY_STOP or n >= DAY_LOSSES:
        return f"day stop (rule 4): day closed net {float(net):.2f} full, {n} losses"
    return None


class Guard:
    """BK3's kept rules as a causal event processor (the v3 bot's order of checks: rule 5, 4, 3, then 1). Sizes are
    in full trades; the caller feeds events in time order (fills, cancels and closes before a new order at the same
    time)."""

    def __init__(self):
        self.orders: dict = {}        # (pair, date iso) -> placed order: pair, date, arm, size, fill, end, exit, R

    def _closed(self, T: int) -> list:
        return [o for o in self.orders.values() if o["exit"] is not None and o["exit"] <= T]

    def _open_trades(self, T: int) -> list:
        return [o for o in self.orders.values()
                if o["fill"] is not None and o["fill"] <= T and (o["exit"] is None or T < o["exit"])]

    def hold(self, pair: str, day: str, since: int, until: int) -> None:
        """A trade or order of the earlier rule (the v3 short) still open at the switch: an open trade of one full size
        from `since` to `until` (17:00 New York of its London day), then closed at 0 R."""
        if pair not in PAIRS:
            raise ValueError(f"pair {pair}: the A+ book is EUR/USD only")
        self.orders[(pair, f"held:{day}")] = dict(pair=pair, date=dt.date.fromisoformat(day), arm=int(since), size=FULL,
                                                   fill=int(since), end=None, exit=int(until), R=Fraction(0))

    def _live_orders(self, T: int) -> list:
        return [o for o in self.orders.values()
                if o["arm"] <= T and (o["fill"] is None or o["fill"] > T) and (o["end"] is None or o["end"] > T)]

    def on_order(self, pair: str, D: dt.date, T: int) -> dict:
        """A new A+ order armed at T on London date D: {action PLACE | SKIP | BLOCK, rule, size}."""
        if pair not in PAIRS:
            raise ValueError(f"pair {pair}: the A+ book is EUR/USD only")
        key = (pair, D.isoformat())
        if key in self.orders:
            raise ValueError(f"a second order for {key}")
        closed = self._closed(T)
        for why in (weekly_brake(closed, D), day_stop(closed, D)):
            if why:
                return dict(action="BLOCK", rule=why, size=Fraction(0))
        if any(o["pair"] == pair for o in self._open_trades(T)):
            return dict(action="SKIP", rule="one open trade per pair (rule 3)", size=Fraction(0))
        live = sum((o["size"] for o in self._open_trades(T)), Fraction(0))
        live += sum((o["size"] for o in self._live_orders(T)), Fraction(0))
        if live + FULL > CAP:
            return dict(action="BLOCK", rule=f"risk cap (rule 1): open risk {float(live):.2f} + {float(FULL):.2f} > "
                                             "1.5 full", size=Fraction(0))
        self.orders[key] = dict(pair=pair, date=D, arm=T, size=FULL, fill=None, end=None, exit=None, R=None)
        return dict(action="PLACE", rule=None, size=FULL)

    def on_fill(self, key, t: int) -> None:
        if key in self.orders:
            self.orders[key]["fill"] = t

    def on_cancel(self, key, t: int) -> None:
        if key in self.orders:
            self.orders[key]["end"] = t

    def on_close(self, key, t: int, R) -> None:
        if key in self.orders:
            self.orders[key]["exit"], self.orders[key]["R"] = t, Fraction(R)


# ---------------------------------------------------------------- events to alerts


def _price(points: int) -> str:
    return "%d.%05d" % (points // 100000, points % 100000)


def _hm(ts: int) -> str:
    return dt.datetime.fromtimestamp(int(ts), LON).strftime("%H:%M")


def _pos(side: str) -> str:
    return "short" if side == "sell" else "long"


def record_text(kind: str, pair: str, D: dt.date, facts: dict, side: str | None) -> str:
    """The alert in one line, for the record (aplus_alert.text); the phone texts are app/aplus/alerts.py's."""
    p = pair.replace("_", "/")
    s = side or ""
    if kind == "ORDER":
        size = "no size" if facts.get("lots") is None else f"{fmt_lots(facts['lots'])} lots"
        return (f"ORDER {p} {s.upper()} LIMIT {_price(facts['entry'])} stop {_price(facts['stop'])} target "
                f"{_price(facts['target'])} (3R), {size}, armed {_hm(facts['arm'])} London on the {facts['chart']} chart, "
                f"London day {D.isoformat()}")
    if kind == "SKIPPED":
        did = "blocked" if facts["action"] == "BLOCK" else "skipped"
        return f"NO ORDER {p} {D.isoformat()}: the guard {did} it ({facts['rule']})"
    if kind == "FILLED":
        how = "at market" if facts["market"] else "limit filled"
        return (f"FILLED {p} {_pos(s).upper()} {how} at {_price(facts['entry'])}, {_hm(facts['t'])} London; stop "
                f"{_price(facts['stop'])} target {_price(facts['target'])}")
    if kind == "CANCELLED":
        return f"CANCEL {p} {s} limit of {D.isoformat()}: {facts['kind']}, {_hm(facts['t'])} London"
    if kind == "CLOSE_SOON":
        return f"CLOSE AT 17:00 NEW YORK {p} {_pos(s).upper()} of {D.isoformat()}"
    if kind == "CLOSED":
        return (f"CLOSED {p} {_pos(s).upper()} of {D.isoformat()}: {facts['kind']}, {_hm(facts['t'])} London, "
                f"{facts['R']}R after owner costs")
    if kind == "NO_TRADE_GAP":
        return f"NO TRADE {p} {D.isoformat()}: a price gap over 16 minutes after 00:00 London"
    return f"DATA GAP {p} {D.isoformat()}: a price gap over 16 minutes after the order armed; the order stays"


class Book:
    """The guard, the paper size and the alerts over the pinned Runner's events (live.Runner.events, in time order),
    with each pair-day's latest state (live.Runner.states; its order, fill and end never change once set).

    balance_for(D): the opening balance of London day D, or None (then orders come without a size).
    firm_daily_loss_usd: rule 7; None (the app's paper setting) leaves it off."""

    def __init__(self, risk_pct, balance_for=None, last_loss_full_usd=None, aplus_trades_done: int = 0,
                 firm_daily_loss_usd=None, held=()):
        check_risk(risk_pct, aplus_trades_done)              # bad settings stop here, before any event
        self.firm = None if firm_daily_loss_usd is None else check_usd(firm_daily_loss_usd, "firm daily loss limit")
        self.risk_pct = risk_pct
        self.balance_for = balance_for or (lambda D: None)
        self.aplus_done = aplus_trades_done
        self.last_loss_full_usd = None if last_loss_full_usd is None else exact(last_loss_full_usd)
        self.guard = Guard()
        for h in held or ():
            self.guard.hold("EUR_USD", h["day"], h["since"], h["until"])
        self.alerts: list = []
        self.book: dict = {}
        self.full_usd: dict = {}

    def day_full(self, D: dt.date):
        """($ of 1 full on London day D, None) or (None, why): no balance for D, or rule 7 refuses it."""
        ds = D.isoformat()
        if ds not in self.full_usd:
            bal = self.balance_for(D)
            if bal is None:
                self.full_usd[ds] = (None, f"no opening balance recorded for {D:%a} {D.day} {D:%b}")
            else:
                full = full_risk_usd(bal, self.risk_pct, self.last_loss_full_usd, self.aplus_done)
                if self.firm is not None and not check_firm_limit(self.firm, full):
                    self.full_usd[ds] = (None, f"guard rule 7 refuses it: 1.5 full = ${fmt_usd(CAP * full)} is more "
                                               f"than half the firm's daily loss limit of ${fmt_usd(self.firm)}")
                else:
                    self.full_usd[ds] = (full, None)
        return self.full_usd[ds]

    def _alert(self, e: dict, kind: str, facts: dict, side: str | None) -> None:
        D = dt.date.fromisoformat(e["date"])
        self.alerts.append(dict(id=alert_id(kind, e["pair"], e["date"]), at=int(e["at"]), pair=e["pair"],
                                date=e["date"], kind=kind, facts=facts,
                                text=record_text(kind, e["pair"], D, facts, side)))

    def run(self, events: list, states: dict) -> None:
        for e in events:
            self.apply(e, states[(e["pair"], e["date"])])

    def apply(self, e: dict, st: dict) -> None:
        """One event of the Runner (kind, t, at, pair, date) with its pair-day's state."""
        key = (e["pair"], e["date"])
        D = dt.date.fromisoformat(e["date"])
        kind = e["kind"]
        o = st.get("order") or {}
        side = o.get("side")
        if kind == "ORDER":
            dec = self.guard.on_order(e["pair"], D, int(e["t"]))
            full, why = self.day_full(D)
            b = dict(action=dec["action"], rule=dec["rule"], size=dec["size"], full_usd=full, why=why, plan=None,
                     side=side)
            self.book[key] = b
            if dec["action"] != "PLACE":
                self._alert(e, "SKIPPED", dict(action=dec["action"], rule=dec["rule"]), side)
                return
            risk = None if full is None else dec["size"] * full
            plan = broker_plan(e["pair"], side, Fraction(o["E"]), Fraction(o["S"]), Fraction(o["T"]), risk, why)
            b["plan"] = plan
            self._alert(e, "ORDER", dict(side=side, chart=o["chart"], pool=o.get("pool"), arm=int(o["arm"]),
                                         entry=plan["entry"],
                                         stop=plan["stop"], target=plan["target"], size=dec["size"],
                                         lots=plan["lots"]), side)
            return
        if kind == "NO_TRADE_GAP":
            self._alert(e, "NO_TRADE_GAP", {}, side)
            return
        if kind == "GAP_WARNING":
            self._alert(e, "GAP_WARNING", {}, side)
            return
        b = self.book.get(key)
        placed = b is not None and b["action"] == "PLACE"
        if kind == "FILLED":
            self.guard.on_fill(key, int(e["t"]))
            if placed:
                f = st["fill"]
                n = b["plan"]["lots"] if b["plan"] else None
                if f["market"]:                      # a market fill moves the stop and target: size from them
                    risk = None if b["full_usd"] is None else b["size"] * b["full_usd"]
                    n = broker_plan(e["pair"], side, Fraction(f["px"]), Fraction(f["S"]), Fraction(f["T"]), risk,
                                    b.get("why"))["lots"]
                b["fill_lots"] = n
                self._alert(e, "FILLED", dict(side=side, t=int(f["utc"]), entry=round_entry(Fraction(f["px"]), side),
                                              stop=round_stop(Fraction(f["S"]), side),
                                              target=round_target(Fraction(f["T"]), side), market=bool(f["market"]),
                                              lots=n), side)
        elif kind == "CANCELLED":
            self.guard.on_cancel(key, int(e["t"]))
            if placed:
                self._alert(e, "CANCELLED", dict(kind=st["end"]["kind"], t=int(e["t"])), side)
        elif kind == "CLOSE_SOON":
            if placed:
                self._alert(e, "CLOSE_SOON", dict(t=int(e["t"])), side)
        elif kind == "CLOSED":
            R = Fraction(st["end"]["R"])
            self.guard.on_close(key, int(e["t"]), R)
            if placed:
                self._alert(e, "CLOSED", dict(kind=st["end"]["kind"], t=int(e["t"]), R="%+.2f" % float(R)), side)
                if R >= 0:
                    self.last_loss_full_usd = None
                elif b["full_usd"] is not None:      # a loss caps 1 full at that trade's 1 full (rule 6)
                    self.last_loss_full_usd = b["full_usd"]
        else:
            raise ValueError(f"unknown event {kind}")
