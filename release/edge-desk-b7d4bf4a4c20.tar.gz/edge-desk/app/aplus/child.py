"""The A+ child process: the A22 pick's live rule `D4h 3m+5m` (live.Runner of research/a22_live, unchanged, from the
pinned copy) and the app's book (app/aplus/book.py: the guard, the paper size, broker prices and alert facts).

Run only as `python -I -B child.py` (no user site, no PYTHONPATH, not the script's folder on sys.path, no bytecode
written). stdin: an .npz with ts_utc (int64), bid_o..ask_c (float64, the feed's prices), volume (int64) and `request`
(JSON: now, days, pairs, balance, risk_pct, last_loss_full_usd, quotes, and since the 30 Oct review held, the earlier
rule's trades still open at the switch, and aplus_trades_done, the forward A22 trade count for N2). stdout: one JSON
object.

`now` is a 1-minute close (decision 1 of 30 Oct 2026): the rule's 3m chart arms on 3m closes that are not 5m closes
(26 of its 42 EUR/USD orders of 2010-2012), so an M5 step would tell such an order up to 4 minutes late. The Runner
steps every 1-minute close from 07:00 London, and each chart sees only the bars before its own last close.

Order of work:
  1. pins.verify (standard library) before anything is imported from the copy; any difference: status "refused".
  2. The copy's folder goes on sys.path and `live` is imported (its own vendored.check() runs too: every research
     file's sha256, the named code at its pinned lines); every bare-name module must come from the copy.
  3. Prices to K1 units: points = rint(price x 100000), refused unless every price is within 1e-6 of a whole point;
     then the engine's own K2 cleaning (data.clean) and K1 conversion (data.to_units) on points / 100000.0, and
     units == 4 x points on every kept row.
  4. The book's settings are checked (book.Book: risk over 1% before 25 forward trades is refused), then live.Runner
     runs every London day of the request to `now`, and the book takes the Runner's events in time order.
  5. The alerts (id, at, pair, date, kind, facts and a record text), the state of every pair-day in the rule's own keys
     (order: chart, side, E, S0, S, T, d0, d, arm, expiry, ny_end, zone, pool; fill: utc, px, market, d, S, T; end:
     kind, utc, at, px, net_units, R, R_float), with R after 2.0 pips (R_20, R_20_float) beside the owner-cost R of a
     closed trade, the book (guard action and rule, size, full $, broker plan, fill lots), versions and counts. Every
     Fraction goes out as text.

The top level imports only the standard library: compute() loads the copy when it is first called, so the parity
harness can call it in its own process. The app's processes never import this module's pinned code.
"""
import io
import json
import sys
from datetime import date
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
DESK = HERE.parents[1]
PINNED = HERE / "pinned"
QFIELDS = ("bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")
PAIRS = ("EUR_USD",)                 # EUR/USD only
QUOTES = ("owner",)                  # the research's owner-cost quotes only (A22's owner case)
POINT_TOL = 1e-6                     # a stored price must be this close to a whole point (0.00001)
STEP_S = 60                          # `now` is a 1-minute close
# R after 2.0 pips: the same path and exit, 2.0 pips (80 K1 units) as the only charge, on the trade's own side.
COSTS_20 = dict(comm=80, stop_slip=0, mkt_entry=0, time_exit=0, stress=False)
BARE = ("live", "vendored", "engine", "data", "outcomes", "run")


class ChildRefused(RuntimeError):
    pass


def _app_module(name: str):
    """app.aplus.<name> (standard library only), imported without leaving the app's folder on sys.path."""
    full = f"app.aplus.{name}"
    if full in sys.modules:
        return sys.modules[full]
    sys.path.insert(0, str(DESK))
    try:
        __import__(full)
    finally:
        sys.path.remove(str(DESK))
    return sys.modules[full]


def _pins():
    return _app_module("pins")


def _book():
    return _app_module("book")


def load(pinned_dir: Path = PINNED) -> dict:
    """Verify the copy, then import it by bare name. Returns {name: module}. Raises ChildRefused."""
    pins = _pins()
    pinned_dir = Path(pinned_dir).resolve()
    try:
        pins.verify(pinned_dir)
    except pins.Refused as e:
        raise ChildRefused(f"pinned code refused: {e}") from None
    loaded = {n: sys.modules.get(n) for n in BARE}
    if any(m is not None for m in loaded.values()):
        _check_origin(pinned_dir, loaded, pins)
        return loaded
    before = sys.dont_write_bytecode
    sys.dont_write_bytecode = True           # never a __pycache__ in the copy (pins.verify refuses one)
    sys.path.insert(0, str(pinned_dir))
    try:
        import live  # noqa: F401  (vendored.check() runs at its import)
    finally:
        sys.dont_write_bytecode = before
    mods = {n: sys.modules.get(n) for n in BARE}
    _check_origin(pinned_dir, mods, pins)
    return mods


def _check_origin(pinned_dir: Path, mods: dict, pins) -> None:
    for name, sub in pins.MODULE_DIRS.items():
        m = mods.get(name)
        want = (pinned_dir / sub).resolve() if sub else pinned_dir
        if m is None or Path(m.__file__).resolve().parent != want:
            raise ChildRefused(f"module {name} was not loaded from the pinned copy")


def unload() -> None:
    """Remove the copy's bare-name modules and folders (tests and the parity harness, after an in-process run)."""
    for n in BARE:
        sys.modules.pop(n, None)
    for p in (str(PINNED.resolve()), str((PINNED / "vendor").resolve())):
        while p in sys.path:
            sys.path.remove(p)


def _text(x):
    """JSON-safe copy: Fraction -> 'a/b' text (str(Fraction)), tuples -> lists, dict keys -> text."""
    if isinstance(x, Fraction):
        return str(x)
    if isinstance(x, dict):
        return {str(k): _text(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_text(v) for v in x]
    if hasattr(x, "item") and not isinstance(x, (str, bytes)):   # numpy scalars
        return x.item()
    return x


def to_pairdata(arrays: dict, mods: dict):
    """The feed's float prices -> PairData through the engine's own cleaning (K2) and units (K1). Raises
    ChildRefused for a price off a whole point, a non-finite price or no bars."""
    import numpy as np
    DA = mods["data"]
    ts = np.asarray(arrays["ts_utc"], dtype=np.int64)
    if len(ts) == 0:
        raise ChildRefused("no bars")
    raw = {"ts_utc": ts.copy(), "volume": np.asarray(arrays["volume"], dtype=np.int64).copy()}
    points = {}
    for f in QFIELDS:
        x = np.asarray(arrays[f], dtype=np.float64) * 100000.0
        if not np.all(np.isfinite(x)):
            raise ChildRefused(f"{f}: a price is not a number")
        r = np.rint(x)
        worst = float(np.abs(x - r).max())
        if worst > POINT_TOL:
            raise ChildRefused(f"{f}: a price is {worst:.2e} points away from a whole point")
        points[f] = r.astype(np.int64)
        raw[f] = points[f] / 100000.0
    cleaned, rep = DA.clean(raw)
    u = DA.to_units(cleaned)
    rep["k1_worst_points"] = float(u.pop("_k1_worst"))
    keep = np.isin(raw["ts_utc"], cleaned["ts_utc"])
    for f in QFIELDS:
        if not np.array_equal(u[f], 4 * points[f][keep]):
            raise ChildRefused(f"{f}: units differ from 4 x points")
    return DA.PairData(u), rep


def _r20(OC, st: dict) -> Fraction | None:
    """R after 2.0 pips of a closed trade: outcomes.net_units on the same side, fill and exit, 80 units only, / d."""
    f, e, o = st.get("fill"), st.get("end"), st.get("order") or {}
    if st.get("phase") != "CLOSED" or not f or not e:
        return None
    short = o["side"] == "sell"
    return Fraction(OC.net_units(short, Fraction(f["px"]), Fraction(e["px"]), e["kind"], bool(f["market"]),
                                 COSTS_20)) / Fraction(f["d"])


def compute(arrays: dict, req: dict, pinned_dir: Path = PINNED) -> dict:
    """One run: the request's London days through live.Runner to req['now'], then the book. Returns the output."""
    import numpy as np
    pairs = list(req.get("pairs") or [])
    if pairs != list(PAIRS):
        raise ChildRefused(f"pairs {pairs}: only {list(PAIRS)}")
    quotes = req.get("quotes")
    if quotes not in QUOTES:
        raise ChildRefused(f"quotes {quotes!r}: only {list(QUOTES)}")
    now = int(req["now"])
    if now % STEP_S:
        raise ChildRefused("now must be a 1-minute close")
    if len(arrays["ts_utc"]) and int(np.max(arrays["ts_utc"])) >= now:
        raise ChildRefused("a bar at or after now was passed")
    mods = load(pinned_dir)
    LV, EN, OC = mods["live"], mods["engine"], mods["outcomes"]
    BK, pins = _book(), _pins()
    pdat, rep = to_pairdata(arrays, mods)
    bal = req.get("balance")
    last = req.get("last_loss_full_usd")
    held = req.get("held") or []
    done = req.get("aplus_trades_done") or 0
    if not isinstance(done, int) or done < 0 or not isinstance(held, list) or not all(
            isinstance(h, dict) and isinstance(h.get("day"), str) and isinstance(h.get("since"), int)
            and isinstance(h.get("until"), int) for h in held):
        raise ChildRefused("held or aplus_trades_done is not well formed")
    try:
        book = BK.Book(str(req["risk_pct"]),
                       balance_for=(lambda D: None) if bal is None else (lambda D: Fraction(str(bal))),
                       last_loss_full_usd=None if last is None else Fraction(str(last)), aplus_trades_done=done,
                       firm_daily_loss_usd=None, held=held)
    except BK.SizeError as e:          # e.g. [risk] risk_pct_per_trade over the 1% ceiling before 25 forward trades
        raise ChildRefused(f"size settings refused by the book: {e}") from None
    runs0 = LV.STATS["engine_runs"]
    runner = LV.Runner({PAIRS[0]: pdat})
    days = [date.fromisoformat(d) for d in req["days"]]
    for D in days:
        runner.run_day(D, until=now)
    book.run(runner.events, runner.states)
    states = []
    for (pair, ds), st in sorted(runner.states.items()):
        st = dict(st)
        r20 = _r20(OC, st)
        if r20 is not None:
            st["end"] = dict(st["end"], R_20=f"{r20.numerator}/{r20.denominator}", R_20_float=float(r20))
        states.append(st)
    entries = [dict(pair=pair, date=ds, **b) for (pair, ds), b in sorted(book.book.items())]
    alerts = [dict(id=a["id"], at=int(a["at"]), pair=a["pair"], date=a["date"], kind=a["kind"], facts=a["facts"],
                   text=a["text"]) for a in book.alerts]
    return _text({
        "status": "done", "now": now, "days": [d.isoformat() for d in days], "alerts": alerts, "states": states,
        "book": entries, "last_loss_full_usd": book.last_loss_full_usd, "engine_runs": LV.STATS["engine_runs"] - runs0,
        "steps": runner.steps, "clean": rep, "rows": int(len(pdat.t1)), "floor_units": EN.FLOOR,
        "versions": {"python": sys.version.split()[0], "numpy": np.__version__, "code_sha256": pins.code_sha256(HERE),
                     "app_files": pins.app_hashes(HERE)},
    })


def compute_npz(raw: bytes, pinned_dir: Path = PINNED) -> dict:
    import numpy as np
    z = np.load(io.BytesIO(raw), allow_pickle=False)
    req = json.loads(str(z["request"]))
    arrays = {k: z[k] for k in ("ts_utc", "volume") + QFIELDS}
    return compute(arrays, req, pinned_dir)


def main() -> int:
    raw = sys.stdin.buffer.read()
    try:
        out = compute_npz(raw)
    except ChildRefused as e:
        out = {"status": "refused", "message": str(e)[:500]}
    sys.stdout.write(json.dumps(out, sort_keys=True))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
