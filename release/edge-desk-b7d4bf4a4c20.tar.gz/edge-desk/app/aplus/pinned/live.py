"""The live rule of A22's pick `D4h 3m+5m` on EUR/USD, buys and sells (research/marc_rules/RESULTS_A22.md, A22.3).

`D4h 3m+5m` is the A+ (the daily candle with the trade, the last three UTC 4h candles not against it; sweep of AH,
PDH or EQH after 07:00 London, wick only; CHoCH by 10:00; entry at the middle of the newest FVG, else the OB; stop
1 pip past the sweep; target 3R; d0 more than 8 pips; cancel at 11:00 London or when the target trades first; exit at
17:00 New York) read on two charts at once: the whole trigger on the 3m chart and, separately, on the 5m chart (the
A+ itself). Each chart's first signal of the London day decides that chart's day. The set places the A+ order with
the earlier arm time (close of the order bar); a tie goes to the 5m chart. The other chart's order that day is not
placed, whatever it does (A22.3.5, A14 D3). One order per pair-day.

Nothing of the rule is written here. vendored.py loads the research's own code from pinned byte copies: A22's
run_rows18 (the K14 window run: data.DayTable, make_ctx, the views and eval_day18 with find_signal18 and order18),
is_aplus18, design_row and set_choice (the set), decision_time, make_order18, and the owner-cost path trade
(v2x_path, case_quotes, nofill_reason). This file only decides which bars each chart may see at `now`, when a
decision is final, and turns states into events.

    evaluate(pdat, pair, D, now)  -> the pair-day state at the 1-minute close `now` (pure)
    Runner                        -> steps every 1-minute close from 07:00 London until the pair-day is final, and
                                     turns state changes into events: ORDER, FILLED, CANCELLED, CLOSE_SOON, CLOSED,
                                     NO_TRADE_GAP (and GAP_WARNING, as the v3 bot)

What each chart may see at `now`: the M1 bars that opened before its own last close at or before `now` (3m: the
last multiple of 180 s, 5m: of 300 s; never later than 11:00 London), from 00:00 London 60 days before the day (the
window A22's K14 check proved equal to the production rows). So no chart ever sees a bar of its own that has not
closed. A chart's row is final once its decision time has passed (ARMED, VOID, NO_ZONE, S5, BOTH_SIDES at the close
of their order or signal bar; NO_SIGNAL at 10:00; NO_ORDER_BAR at 11:00), as K14's truncation test showed.
Why the set's choice is final as soon as one chart has an A+ order: a chart whose row is not final at `now` decides
at one of its own closes after `now`, so any order it may still give arms strictly later than the order already
there (its arm time is at least its last close plus its bar length, which is after `now`).
"""
import datetime as dt
import os
import sys
from fractions import Fraction

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import numpy as np  # noqa: E402

from vendored import EN, DA, OC, A22  # noqa: E402

PAIRS = ('EUR_USD',)
DESIGN = 'D4h 3m+5m'
BASE = A22.DESIGN[DESIGN]['base']                    # 'D4h'
MEMBERS = A22.XMEMBERS[A22.DESIGN[DESIGN]['ex']]     # (3, 5)
WHICH = A22.stage_which([DESIGN])                    # each chart's rows carry the daily and the 4h bias
assert BASE == 'D4h' and MEMBERS == (3, 5) and WHICH == {'X1': ('daily', 'h4'), 'X2': ('daily', 'h4')}
WINDOW_DAYS = 60                     # A22's K14 window: 00:00 London 60 days before D
STEP_S = 60                          # the Runner steps every 1-minute close
FINAL_AT_DECISION = ('ARMED', 'VOID', 'NO_ZONE', 'S5', 'BOTH_SIDES')
FINAL_PHASES = ('NOT_ELIGIBLE', 'NO_TRADE', 'CANCELLED', 'CLOSED')
STATS = {'engine_runs': 0}


class InconsistentState(RuntimeError):
    """A later evaluation contradicted an earlier one (a final decision changed). Must never happen."""


# ---------------------------------------------------------------- clocks
def clocks(D):
    return dict(L07=DA.lon(D, 7), Ldl=DA.lon(D, *A22.W1RULE.deadline), Lexp=DA.lon(D, *A22.W1RULE.expiry),
                ny_end=DA.nyt(D, 17))


def london_clock(D, t):
    """(hh, mm) of unix time t on London date D; asserts the round trip (no DST ambiguity after 00:00 on a weekday)"""
    lt = dt.datetime.fromtimestamp(int(t), DA.LON)
    assert lt.date() == D and DA.lon(D, lt.hour, lt.minute) == t, (D, t)
    return lt.hour, lt.minute


def gap_ok_until(pdat, D, t_end):
    """The engine's K4 gap test (data.gap_ok) over [00:00 London, t_end): gap_ok reads only .t1."""
    return DA.gap_ok(pdat, D, upto=london_clock(D, t_end))


def chart_cut(now, m, Lexp):
    """the last close of the m-minute chart at or before now, never after 11:00 London"""
    return min(int(now) - int(now) % (60 * m), Lexp)


# ---------------------------------------------------------------- one chart's row at its cut
def _chart_entry(pdat, D, m, cut):
    """A22's row of the uniform m-minute design (D4h base) for London day D on the M1 bars opening in
    [00:00 London D-60, cut): run_rows18, the research's own K14 window run."""
    c = clocks(D)
    a, b = pdat.rows(DA.lon(D - dt.timedelta(days=WINDOW_DAYS), 0), cut)
    if b <= a:            # no bar at all: the gap test fails too, so the day can never be traded
        return dict(m=m, cut=cut, status='NO_DATA', final=True, decision=None, row=None, ctx=None, warm=None)
    STATS['engine_runs'] += 1
    x = A22.UNIFORM_OF[m]
    rows, S, ctx = A22.run_rows18(pdat, D, a, b, [x], which=WHICH)
    row = rows[x]
    st = row['status']
    if st in FINAL_AT_DECISION:
        final, decision = True, int(row['_decision'])
        if decision > cut:
            raise InconsistentState('%s row at %d decided after its cut %d' % (st, decision, cut))
    elif st == 'NO_SIGNAL':
        final, decision = cut >= c['Ldl'], c['Ldl']
    elif st == 'NO_ORDER_BAR':
        final, decision = cut >= c['Lexp'], c['Lexp']
    else:
        raise InconsistentState('unexpected row status %s' % st)
    return dict(m=m, cut=cut, status=st, final=final, decision=decision if final else None, row=row, ctx=ctx,
                warm=ctx.n_complete >= 20)


def chart_entry(pdat, pair, D, m, cut, cache=None):
    """_chart_entry, memoised in `cache` (a dict bound to one data set): a final row is reused for every cut at or
    after its decision time (it never changes there, K14), any other entry only for its own cut."""
    if cache is None:
        return _chart_entry(pdat, D, m, cut)
    fk, ck = (pair, D.isoformat(), m, 'final'), (pair, D.isoformat(), m, cut)
    ent = cache.get(fk)
    if ent is not None and ent['decision'] <= cut:
        return ent
    ent = cache.get(ck)
    if ent is None:
        ent = _chart_entry(pdat, D, m, cut)
        cache[fk if (ent['final'] and ent['status'] != 'NO_DATA') else ck] = ent
    return ent


def chart_reason(ent):
    """one chart's state in words: its W1 status; on an ARMED row, H_FILTER (the bias base failed), D0_8_PIPS_OR_LESS
    (not an A+ order) or APLUS"""
    if ent['status'] != 'ARMED':
        return ent['status']
    bs = A22.base_status(ent['row'], BASE)
    if bs != 'ARMED':
        return bs
    return 'APLUS' if A22.is_aplus18(ent['row'], BASE) else 'D0_8_PIPS_OR_LESS'


# ---------------------------------------------------------------- the order path (owner costs)
def _fx(v):
    return None if v is None else EN.fmt(v)


def _fr(v):
    v = Fraction(v)
    return '%d/%d' % (v.numerator, v.denominator)


def path_state(pdat, pair, order, now):
    """The order on the M1 bars opening in [arm, now) through A22's owner path (trade: v2x_path on owner-cost quotes,
    case_quotes). Returns (phase, fill, end): phase ARMED | FILLED | CANCELLED | CLOSED. Read on part of the day:
    'EXPIRED' before 11:00 London means the order is still live; a TIME exit before 17:00 New York means the trade is
    still open."""
    j0 = int(np.searchsorted(pdat.t1, order['live_from']))
    j1 = int(np.searchsorted(pdat.t1, now))
    t1 = pdat.t1[j0:j1]
    Q = A22.case_quotes({k: pdat.u[k][j0:j1] for k in DA.QFIELDS}, 'owner', pair)
    t = A22.trade(t1, Q, order, 'owner')
    if not t['filled']:
        kind = t['exit']
        if kind == 'EXPIRED':
            if now >= order['expiry']:
                return 'CANCELLED', None, dict(kind='EXPIRED', utc=int(order['expiry']), at=int(order['expiry']))
            return 'ARMED', None, None
        # the minute of a target-first or fill-bar cancel: the engine's outcomes.order_path gives its index; its
        # label must be the research's (nofill_reason)
        r = OC.order_path(t1, Q, order, A22.COSTS18[pair]['owner'])
        if r['filled'] or r['exit'] != kind:
            raise InconsistentState('order_path %s differs from nofill_reason %s' % (r['exit'], kind))
        u = int(t1[r['exit_i']])
        return 'CANCELLED', None, dict(kind=kind, utc=u, at=u)
    sg = 1 if order['side'] == 'sell' else -1
    F, d = Fraction(t['F']), Fraction(t['d'])
    fill = dict(utc=int(t1[t['fill_i']]), px=F, market=bool(t['market']), d=d, S=F + sg * d, T=F - sg * 3 * d)
    if t['kind'] == 'TIME' and now < order['ny_end']:
        return 'FILLED', fill, None
    u = int(t1[t['exit_i']])
    end = dict(kind=t['kind'], utc=u, at=int(order['ny_end']) if t['kind'] == 'TIME' else u, px=Fraction(t['raw']),
               net_units=Fraction(t['net_units']), R=Fraction(t['net_units']) / d)
    return 'CLOSED', fill, end


# ---------------------------------------------------------------- the pair-day state
def evaluate(pdat, pair, D, now, excluded=frozenset(), cache=None):
    """State of `D4h 3m+5m` for (pair, London weekday D) at the 1-minute close `now`, from M1 bars opening before now
    only (each chart: before its own last close). Pure: the same data and arguments always give the same state (the
    cache holds only entries that cannot change)."""
    if now % STEP_S:
        raise ValueError('now must be a 1-minute close (a multiple of 60 s)')
    if pair not in PAIRS:
        raise ValueError('pair %s: the live rule is EUR/USD only' % pair)
    if D.weekday() >= 5:
        raise ValueError('%s is not a London weekday' % D)
    c = clocks(D)
    st = dict(pair=pair, date=D.isoformat(), now=int(now), phase='WAIT', reason='', final=False, late_gap=False,
              charts=None, order=None, fill=None, end=None)
    if now < c['L07']:
        return st
    if not A22.clock_ok(D):           # the research's CLOCK days (none on 2010-2015 weekdays)
        st.update(phase='NOT_ELIGIBLE', reason='CLOCK', final=True)
        return st
    cut_all = min(int(now), c['Lexp'])
    ents = {m: chart_entry(pdat, pair, D, m, chart_cut(now, m, c['Lexp']), cache) for m in MEMBERS}
    if any(e['status'] == 'NO_DATA' for e in ents.values()):
        st.update(phase='NOT_ELIGIBLE', reason='NO_DATA', final=True)
        return st
    if len({e['warm'] for e in ents.values()}) != 1:
        raise InconsistentState('the charts disagree on WARMUP')
    # permanent reasons first, in the engine's order (WARMUP, BLIND, HOLIDAY), so a final reason never changes; the
    # research reports a GAP before BLIND and HOLIDAY when a day has both (both: no trade)
    static = [r for r, bad in (('WARMUP', not ents[MEMBERS[0]]['warm']), ('BLIND', D in excluded),
                                ('HOLIDAY', (D.month, D.day) in DA.HOLIDAY_MD)) if bad]
    if static:
        st.update(phase='NOT_ELIGIBLE', reason=static[0], final=True)
        return st
    charts = {'%dm' % m: dict(state=chart_reason(e), final=e['final'], decision=e['decision'])
              for m, e in ents.items()}
    rows = {A22.UNIFORM_OF[m]: e['row'] for m, e in ents.items()}
    row, chart = A22.design_row(rows, DESIGN)            # the set's choice (A22.3.5), the research's own code
    if row is not None:
        if not ents[chart]['final']:
            raise InconsistentState('an A+ order from a row that is not final')
        decision = int(row['live_from_utc'])
    elif all(e['final'] for e in ents.values()):
        decision = int(A22.decision_time(rows, DESIGN))
    else:
        decision = None
    gap_end = cut_all if decision is None else min(decision, cut_all)
    if not gap_ok_until(pdat, D, gap_end):
        st.update(phase='NOT_ELIGIBLE', reason='GAP', final=True)
        return st
    if row is None:
        # each chart's state is shown only while scanning and on a final no-trade (then every chart is final); a
        # final state never shows a part that could still change
        why = ', '.join('%s %s' % (k, v['state']) for k, v in charts.items())
        if decision is None:
            st.update(phase='SCANNING', reason=why, charts=charts)
        else:
            st.update(phase='NO_TRADE', reason=why, final=True, charts=charts)
        return st
    late_gap = gap_end < cut_all and not gap_ok_until(pdat, D, cut_all)
    o = A22.make_order18(pair, D, ents[chart]['ctx'], row, A22.UNIFORM_OF[chart], chart)
    phase, fill, end = path_state(pdat, pair, o, now)
    st.update(phase=phase, final=phase in FINAL_PHASES, late_gap=late_gap and phase in ('ARMED', 'FILLED'),
              order=dict(chart='%dm' % chart, side=o['side'], E=_fx(o['E']), S0=_fx(o['S0']), S=_fx(o['S']),
                         T=_fx(o['T']), d0=_fx(o['d0']), d=_fx(o['d']), arm=int(o['live_from']),
                         expiry=int(o['expiry']), ny_end=int(o['ny_end']), zone=row['zone'], pool=row['pool']))
    if fill is not None:
        st['fill'] = dict(utc=fill['utc'], px=_fx(fill['px']), market=fill['market'], d=_fx(fill['d']),
                          S=_fx(fill['S']), T=_fx(fill['T']))
    if end is not None:
        e = dict(kind=end['kind'], utc=end['utc'], at=end['at'])
        if 'R' in end:
            e.update(px=_fx(end['px']), net_units=_fx(end['net_units']), R=_fr(end['R']), R_float=float(end['R']))
        st['end'] = e
    return st


# ---------------------------------------------------------------- events
def without_now(st):
    return {k: v for k, v in st.items() if k != 'now'}


def diff(prev, cur):
    """Events from one state to the next, in order ORDER, FILLED, CANCELLED / CLOSED, GAP_WARNING, NO_TRADE_GAP.
    Raises InconsistentState if an earlier final fact changed."""
    if prev is not None:
        if prev['final'] and without_now(prev) != without_now(cur):
            raise InconsistentState('final state changed: %s %s' % (cur['pair'], cur['date']))
        for k in ('order', 'fill', 'end'):
            if prev[k] is not None and prev[k] != cur[k]:
                raise InconsistentState('%s changed: %s %s' % (k, cur['pair'], cur['date']))
    pv = prev or {'order': None, 'fill': None, 'end': None, 'late_gap': False}
    base = dict(pair=cur['pair'], date=cur['date'])
    out = []
    if cur['order'] is not None and pv['order'] is None:
        out.append(dict(base, kind='ORDER', t=cur['order']['arm']))
    if cur['fill'] is not None and pv['fill'] is None:
        out.append(dict(base, kind='FILLED', t=cur['fill']['utc']))
    if cur['end'] is not None and pv['end'] is None:
        out.append(dict(base, kind='CLOSED' if cur['phase'] == 'CLOSED' else 'CANCELLED', t=cur['end']['at']))
    if cur['late_gap'] and not pv['late_gap']:
        out.append(dict(base, kind='GAP_WARNING', t=cur['now']))
    if cur['phase'] == 'NOT_ELIGIBLE' and cur['reason'] == 'GAP' and (prev is None or prev['phase'] != 'NOT_ELIGIBLE'):
        out.append(dict(base, kind='NO_TRADE_GAP', t=cur['now']))
    return out


_RANK = {'FILLED': 0, 'CANCELLED': 0, 'CLOSED': 0, 'GAP_WARNING': 0, 'NO_TRADE_GAP': 0, 'CLOSE_SOON': 0, 'ORDER': 1}


class Runner:
    """Steps London day D at every 1-minute close from 07:00 London while the pair-day can still change, up to 17:00
    New York, and turns state changes into events (fills, cancels and closes before a new order at the same time).
    At 16:55 New York it adds CLOSE_SOON for a trade still open (the 17:00 New York exit is done by hand).
    The guard, sizing and alert texts of the app are not here (step 2 of the swap wires them)."""

    def __init__(self, data, excluded=frozenset(), use_cache=True):
        self.data = data
        self.excluded = frozenset(excluded)
        self.cache = {} if use_cache else None
        self.states = {}           # (pair, date iso) -> latest state
        self.events = []
        self.steps = 0

    def step(self, D, T):
        self.steps += 1
        evs = []
        for pair in PAIRS:
            if pair not in self.data:
                continue
            key = (pair, D.isoformat())
            prev = self.states.get(key)
            if prev is not None and prev['final']:
                continue                       # a final state never changes (checked by the replay)
            cur = evaluate(self.data[pair], pair, D, T, self.excluded, self.cache)
            evs.extend(diff(prev, cur))
            self.states[key] = cur
            if cur['final'] and self.cache is not None:
                for k in [k for k in self.cache if k[:2] == key]:
                    del self.cache[k]          # nothing of a final pair-day is needed again
        if T == clocks(D)['ny_end'] - 300:     # 16:55 New York: remind to close what is still open at 17:00
            for pair in PAIRS:
                st = self.states.get((pair, D.isoformat()))
                if st is not None and st['phase'] == 'FILLED' and st['now'] == T:
                    evs.append(dict(pair=pair, date=D.isoformat(), kind='CLOSE_SOON', t=T))
        evs.sort(key=lambda e: (e['t'], _RANK[e['kind']], PAIRS.index(e['pair'])))
        for e in evs:
            e['at'] = T
        self.events.extend(evs)
        return evs

    def busy(self, D):
        ds = D.isoformat()
        return any(self.states.get((p, ds)) is None or not self.states[(p, ds)]['final']
                   for p in PAIRS if p in self.data)

    def run_day(self, D, until=None, on_step=None):
        """Step every 1-minute close of London day D from 07:00 London to 17:00 New York (or `until`), stopping once
        the pair-day is final (later steps cannot change anything)."""
        if D.weekday() >= 5:
            return
        c = clocks(D)
        end = c['ny_end'] if until is None else min(c['ny_end'], until)
        T = c['L07']
        while T <= end:
            self.step(D, T)
            if on_step is not None:
                on_step(D, T, self)
            if not self.busy(D):
                break
            T += STEP_S
