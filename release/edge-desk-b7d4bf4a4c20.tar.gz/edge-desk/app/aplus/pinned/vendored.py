"""Load the unchanged research code of A22's pick `D4h 3m+5m` from byte copies in vendor/, after checking their sha256.

vendor/ holds six byte copies, never edited:
  engine.py, data.py, outcomes.py   marc_test/v2x (the engine that passed K14; the same bytes as bot/vendor/)
  run.py                            marc_test/v2x/run.py (the runner glue A22.2 pins; only `order_spec` is used)
  views.py                          A18's views.py (A22.2: `build_tf`, `tf_view`, the 1m/3m/15m charts)
  run_a22.py                        A22's own run_a22.py, the file of the DISCOVER outcomes run (A22 RULING R2)

engine, data, outcomes and run are imported as modules. views.py and run_a22.py cannot be imported as they stand
(their first lines pin absolute paths of the research sandbox and assert files there), so they are never imported:
their named top-level code is compiled from the pinned bytes, unchanged, and run in fresh module namespaces whose
only inputs are the vendored modules above and the standard library:
  VW   build_tf, tf_view                                    (views.py, A4's code with A18's two named blocks)
  A22  the constants block "instruments and costs ... the designs" (run_a22.py lines RUN_A22_BLOCK) and the
       functions RUN_A22_FUNCS: the trigger, the rows, the set choice, the order and the owner path, each exactly as
       the DISCOVER run executed it.
No signal, order or path logic is written here. Every module of research/a22_live gets the research code through
this file:

    from vendored import EN, DA, OC, RUN, VW, A22

The check runs once, at import: vendor/SHA256SUMS must list exactly the pins below, every file must hash to its
pin, the named objects must exist exactly once at their pinned lines, and every global name the loaded functions
read must resolve. Any difference stops the import (VendorError).
"""
import ast
import builtins
import collections
import datetime
import dis
import hashlib
import os
import sys
import types
from fractions import Fraction

HERE = os.path.dirname(os.path.abspath(__file__))
VENDOR = os.path.join(HERE, 'vendor')

# sha256 of the research files, as stated by the A22 lines of research/marc_rules/FROZEN.txt
# (ccr-b1232258-55ajvr): engine/data/outcomes/run (A22.2 and pre_era22.PIN), views.py (A22 CUT line), run_a22.py
# (A22 RULING R2, the code of the one live DISCOVER outcomes run)
PINNED = {
    'engine.py': 'eb6740763ab683c6be95af9a6a09106806b4211592249c46593ca772ea388909',
    'data.py': '25e3f5bb5399bc7439e88237eb64a06a1070cbd68d2b867ab12ce459c41a9e2a',
    'outcomes.py': '829ed19e48c0153b3cde7e9ce24f5ae6e8ba6234f164a35398774a8679aadf74',
    'run.py': '4749e1ae28fea25fa73485ff5323201f7630615c234c36268d7ac7df11f178ca',
    'views.py': 'fe200fb5617a8f6986a4a5b797fba374f4215267650e6c00890ed9365b4dd3b2',
    'run_a22.py': '11172ed892ba0bf2034a3f70c5b3d3f60aa6876ef75d071f2a444817ce7c8c31',
}

VIEWS_FUNCS = {'build_tf': 38, 'tf_view': 52}
# run_a22.py: the top-level statements on these lines (the instruments, costs, A+, charts, executions and designs
# block, from `ORDER = ...` to `assert len(DESIGNS) == 45 ...`) and these functions, at these first lines
RUN_A22_BLOCK = (194, 258)
RUN_A22_FUNCS = {
    'clock_ok': 399, 'case_quotes': 411, 'v2x_path': 426, 'placement': 465, 'nofill_reason': 495, 'trade': 515,
    'design_of': 261, 'designs_on': 265, 'stage_which': 270, 'bases_on': 285,
    'add_h2': 1426, 'make_series': 1432, 'charts_for': 1437, 'row_executions': 1448,
    'tc_range': 1483, 'ob_index': 1489, 'find_signal18': 1494, 'biases_at': 1573, 'order18': 1588,
    'base_status': 1643, 'is_aplus18': 1653, 'eval_day18': 1668, 'set_choice': 1682, 'design_row': 1696,
    'decision_time': 1716, 'make_order18': 1764, 'order_key': 1771, 'run_rows18': 2351,
}


class VendorError(RuntimeError):
    pass


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def check(vendor_dir=VENDOR, pinned=PINNED):
    """Raise VendorError unless SHA256SUMS equals the pins and every file hashes to its pin."""
    sums = {}
    with open(os.path.join(vendor_dir, 'SHA256SUMS')) as f:
        for line in f:
            if line.strip():
                h, name = line.split()
                sums[name.lstrip('*')] = h
    if sums != pinned:
        raise VendorError('vendor/SHA256SUMS differs from the pinned hashes')
    for name, want in pinned.items():
        got = file_sha256(os.path.join(vendor_dir, name))
        if got != want:
            raise VendorError('vendor/%s sha256 %s differs from the pin %s' % (name, got, want))
    return True


def select_nodes(tree, funcs, block=None):
    """The pinned top-level nodes of a parsed file: the functions `funcs` ({name: first line}, each exactly once,
    at its line) and every top-level statement whose lines lie inside `block` (first, last), in file order."""
    found, out = {}, []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in funcs:
            if node.name in found:
                raise VendorError('%s is defined twice' % node.name)
            if node.lineno != funcs[node.name]:
                raise VendorError('%s starts at line %d, not %d' % (node.name, node.lineno, funcs[node.name]))
            found[node.name] = node
            out.append(node)
        elif block is not None and block[0] <= node.lineno and node.end_lineno <= block[1]:
            if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.Import, ast.ImportFrom)):
                raise VendorError('unexpected %s in the constants block' % type(node).__name__)
            out.append(node)
    missing = set(funcs) - set(found)
    if missing:
        raise VendorError('not found: %s' % sorted(missing))
    return out


def load_named(path, name, funcs, block, env):
    """Compile the pinned nodes of `path` (unchanged bytes) and run them in a new module whose globals are `env`."""
    with open(path, 'rb') as f:
        src = f.read()
    tree = ast.parse(src, filename=path)
    nodes = select_nodes(tree, funcs, block)
    mod = types.ModuleType(name)
    mod.__file__ = path
    mod.__dict__.update(env)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), path, 'exec'), mod.__dict__)
    return mod


def unresolved_globals(mod, names):
    """Global names read by the named functions (and their nested code) that resolve neither in the module nor in
    builtins: must be empty."""
    bad = set()

    def walk(code):
        for ins in dis.get_instructions(code):
            if ins.opname in ('LOAD_GLOBAL', 'LOAD_NAME'):
                yield ins.argval
        for c in code.co_consts:
            if isinstance(c, types.CodeType):
                yield from walk(c)

    for fn in names:
        for n in walk(getattr(mod, fn).__code__):
            if n not in mod.__dict__ and not hasattr(builtins, n):
                bad.add((fn, n))
    return sorted(bad)


check()
if VENDOR not in sys.path:
    sys.path.insert(0, VENDOR)

import numpy as np       # noqa: E402
import engine as EN      # noqa: E402
import data as DA        # noqa: E402
import outcomes as OC    # noqa: E402
import run as RUN        # noqa: E402

for _m in (EN, DA, OC, RUN):
    if os.path.dirname(os.path.abspath(_m.__file__)) != VENDOR:
        raise VendorError('module %s was not loaded from vendor/ (%s)' % (_m.__name__, _m.__file__))

VW = load_named(os.path.join(VENDOR, 'views.py'), 'a22_views', VIEWS_FUNCS, None,
                dict(np=np, Series=EN.Series, find_swings=EN.find_swings))
A22 = load_named(os.path.join(VENDOR, 'run_a22.py'), 'a22_rules', RUN_A22_FUNCS, RUN_A22_BLOCK,
                 dict(C=collections, dt=datetime, np=np, Fraction=Fraction, EN=EN, DA=DA, OC=OC, RUN=RUN, VW=VW,
                      TICK=EN.TICK))
for _mod, _names in ((VW, VIEWS_FUNCS), (A22, RUN_A22_FUNCS)):
    _bad = unresolved_globals(_mod, _names)
    if _bad:
        raise VendorError('unresolved global names in the loaded research code: %s' % _bad)
