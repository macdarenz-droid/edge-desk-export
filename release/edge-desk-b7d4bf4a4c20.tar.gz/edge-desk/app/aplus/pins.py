"""The pinned A+ code (app/aplus/pinned): byte copies of the A22 pick's live rule `D4h 3m+5m`, research/a22_live at the
local research commit SOURCE_COMMIT (branch p3-a22-live; research/a22_live/NOTES.md: parity with A22's DISCOVER rows on
2010-2012 EUR/USD, 42/42 orders and 37/37 fills with 0 differences, a look-ahead review of 4,751 cuts with 0
differences, 29 unit tests). Its vendor/ folder holds the research's own files, byte copies again, each pinned there by
its own vendored.py and SHA256SUMS. These replace the v3 short's copies (30 Oct 2026): no v3 module is left.

The code version of a logged suggestion (CODE_SHA256) is one sha256 over the pin table and over every app file that
decides a logged value (APP_FILES: the guard, sizes and prices of book.py; the child; the step's rows and push rules;
the alert texts and cancel times; the record line), so a changed byte in any of them changes it (code review, 30 Oct).

Standard library only: verify() runs in the child before anything is imported from the copy. It refuses (Refused)
unless pinned/ holds exactly the pinned files and its vendor/ folder (no other file or folder that a bare-name import
could pick up, and no __pycache__: cached bytecode would be run in place of the checked source) and each file's sha256
is its pin. The copy is never changed to suit the app: the app reads the rule's own state keys (child.py, step.py).
"""
from __future__ import annotations

import hashlib
from pathlib import Path

SOURCE_COMMIT = "4f790deabd92494cae4e428ff2d284f5a63e4e1a"
SOURCE_PATH = "research/a22_live"
PINNED_DIR = Path(__file__).resolve().with_name("pinned")
PINS = {
    "live.py": "5673ed6e38aa368e6f25fc2eb008532ecd75d432fdbbe5c694d222c0e44972db",
    "vendored.py": "7ecb8bb8bd0689df3579b1251d2a599565f560bd5a8c1096514acc6fdbfb73a6",
    "vendor/engine.py": "eb6740763ab683c6be95af9a6a09106806b4211592249c46593ca772ea388909",
    "vendor/data.py": "25e3f5bb5399bc7439e88237eb64a06a1070cbd68d2b867ab12ce459c41a9e2a",
    "vendor/outcomes.py": "829ed19e48c0153b3cde7e9ce24f5ae6e8ba6234f164a35398774a8679aadf74",
    "vendor/run.py": "4749e1ae28fea25fa73485ff5323201f7630615c234c36268d7ac7df11f178ca",
    "vendor/views.py": "fe200fb5617a8f6986a4a5b797fba374f4215267650e6c00890ed9365b4dd3b2",
    "vendor/run_a22.py": "11172ed892ba0bf2034a3f70c5b3d3f60aa6876ef75d071f2a444817ce7c8c31",
    "vendor/SHA256SUMS": "36361970d05e98a0d8f59fb849eb039734f23dc98ca7c7d23a8db9543ad90bac",
}
APP_DIR = Path(__file__).resolve().parent
# The app's own files that decide a value the suggestion log or the run rows keep.
APP_FILES = ("alerts.py", "book.py", "child.py", "record.json", "record.py", "step.py")
# The modules the child loads by bare name, and the folder each must come from (vendor/views.py and vendor/run_a22.py
# are never imported: the copy's vendored.py compiles their named code from the pinned bytes).
MODULE_DIRS = {"live": "", "vendored": "", "engine": "vendor", "data": "vendor", "outcomes": "vendor", "run": "vendor"}


class Refused(RuntimeError):
    pass


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


FOLDERS = {"vendor"}


def files_on_disk(root: Path) -> set[str]:
    """Every entry under root (relative, "/"-separated) except the vendor folder itself: a file, a link or any other
    folder (a __pycache__ too) is listed, so it fails the comparison with PINS."""
    out = set()
    for p in root.rglob("*"):
        rel = p.relative_to(root)
        if p.is_dir() and not p.is_symlink() and rel.as_posix() in FOLDERS:
            continue
        out.add(rel.as_posix())
    return out


def app_hashes(app_dir: Path | str = APP_DIR) -> dict:
    """{file: sha256} of APP_FILES in app_dir (app/aplus)."""
    return {f: sha256_file(Path(app_dir) / f) for f in APP_FILES}


def code_sha256(app_dir: Path | str = APP_DIR) -> str:
    """The code version: one sha256 over "<sha256>  <path>" lines, as sha256sum prints them: the pin table in path
    order, then APP_FILES (as app/aplus/<file>) in name order."""
    lines = [f"{h}  {f}\n" for f, h in sorted(PINS.items())]
    lines += [f"{h}  app/aplus/{f}\n" for f, h in sorted(app_hashes(app_dir).items())]
    return hashlib.sha256("".join(lines).encode()).hexdigest()


# The code version of an A+ suggestion in the suggestion log (its code_sha256) and of every run row.
CODE_SHA256 = code_sha256()


def verify(root: Path | str = PINNED_DIR) -> None:
    """Refused unless root holds exactly PINS, every file a regular file (no link) with its pinned sha256."""
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise Refused(f"{root} is not a folder")
    got = files_on_disk(root)
    if got != set(PINS):
        raise Refused(f"files differ from the pins: extra {sorted(got - set(PINS))}, missing {sorted(set(PINS) - got)}")
    for rel, want in sorted(PINS.items()):
        p = root / rel
        if p.is_symlink() or not p.is_file():
            raise Refused(f"{rel} is not a plain file")
        have = sha256_file(p)
        if have != want:
            raise Refused(f"{rel} sha256 {have} differs from the pin {want}")
