"""The A+ tested record line (rule APLUS-A22, the A22 pick `D4h 3m+5m`), from record.json: every card and order alert
carries it. The figures are A22's own on the years it was picked on (2010-2012 DISCOVER, EUR/USD), stated as picked on
them: its 2013-2015 test (VALIDATE) has not run, so the line says so and ends "Paper. Not proven.". Since the trader
review of 30 Oct it also gives how often: trades a week (over A22's 152 DISCOVER weeks) and R a month after 2.0 pips
(over the 36 months of 2010-2012), beside the owner's goal of 3-5 trades a week (CLAUDE.md "Search freedoms": shown
beside every result, never a gate).

recompute() rebuilds the figures from the live rule's parity orders (research/a22_live/out/replay_orders.csv at
p3-a22-live 4f790dea; each row equal field by field to A22's published trades_a22_d_EUR_USD.csv), so the test can check
record.json against a byte copy of it. Standard library only."""
from __future__ import annotations

import csv
import io
import json
from fractions import Fraction
from functools import lru_cache
from pathlib import Path

PATH = Path(__file__).with_name("record.json")
RULE_ID = "APLUS-A22"
LEGACY_RULE_IDS = ("APLUS-V3",)       # the v3 short's suggestions logged before the swap (still A+ cards)
END = "Paper. Not proven."
COMM_20 = 80                  # 2.0 pips in K1 units (1 pip = 40)
OWNER_COMM, OWNER_SLIP = 20, 20       # A22's owner case on EUR/USD: 0.5 pip commission, 0.5 pip on a stop exit


@lru_cache(maxsize=1)
def data() -> dict:
    return json.loads(PATH.read_text())


def _r(x: float) -> str:
    return f"{x:+.2f}R"


def record_line() -> str:
    d = data()
    e = d["figures"]["eur_usd"]
    return d["template"].format(years=d["years"], test_years=d["test_years"], orders=e["orders"], trades=e["trades"],
                                total_20=_r(e["total_20"]), r_20=_r(e["r_20"]), total_owner=_r(e["total_owner"]),
                                r_owner=_r(e["r_owner"]), per_week=f"{e['per_week']:.2f}",
                                r_month_20=_r(e["r_month_20"]))


def r_after_20(row: dict) -> Fraction:
    """R after 2.0 pips of one filled order from its owner-cost net units (already signed by side): the same fill and
    exit, 2.0 pips the only charge."""
    slip = OWNER_SLIP if row["exit"] == "STOP" else 0
    return (Fraction(row["net_units"]) + OWNER_COMM + slip - COMM_20) / Fraction(row["d"])


def recompute(csv_text: str) -> dict:
    """{'eur_usd': {orders, trades (filled), total_owner, r_owner, total_20, r_20, per_week (trades over record.json's
    weeks), r_month_20 (total_20 over its months)}}, exact (Fractions)."""
    rows = list(csv.DictReader(io.StringIO(csv_text)))
    fills = [r for r in rows if r["filled"] == "1"]
    n = len(fills)
    own = sum((Fraction(r["net_units"]) / Fraction(r["d"]) for r in fills), Fraction(0))
    r20 = sum((r_after_20(r) for r in fills), Fraction(0))
    d = data()
    return {"eur_usd": {"orders": len(rows), "trades": n, "total_owner": own, "r_owner": own / n if n else None,
                        "total_20": r20, "r_20": r20 / n if n else None, "per_week": Fraction(n, d["weeks"]),
                        "r_month_20": r20 / d["months"]}}
