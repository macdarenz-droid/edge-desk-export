"""The A+ step (docs/APLUS_DESIGN.md section 4): run inside the method worker's loop (every 30 s), after the method
step, in its own try. Paper only: it reads bars, runs the pinned code in its own process and writes alerts, states and
the suggestion log. It never touches an order, the planner, the paper book or the day guard.

Since 30 Oct 2026 the A+ is the A22 pick `D4h 3m+5m` (owner: "And also yes to replace a+ of a22"): the pinned code is
its live rule (app/aplus/pins.py), with the app's book (app/aplus/book.py) in the same child. Decisions recorded here:
  - 1-minute closes (decision 1): T is the last 1-minute close (CLOSE_S), not the M5 close, because the rule's 3m
    chart arms on closes that are not 5m closes; a pair-day is open from 07:00 London (the rule's first step). The
    worker's 30 s loop and the feed's 20 s poll (a minute final 30 s after it) already see every minute; the child
    timeout and the one-child-at-a-time lock are unchanged. The failure count stays one an M5 close of the wall clock
    (FAIL_ALERT_AFTER closes: about 15 minutes), as before.
  - The rule's own state keys (decision 4): a fill's time and price are fill.utc and fill.px; an end's event time is
    end.at (the 17:00 New York exit's at is 17:00 New York); the order carries its side and chart.
  - Alert ids start with "A22:" (app/aplus/book.py RULE_TAG), so they never meet the v3 short's ids.
  - Rows are the rule's by the run that wrote them: every run row's versions_json carries "rule": record.RULE_ID
    (_record_run), alerts carry the "A22:" prefix, and day rows point at their run. The step, Today and the forward
    record read only the rule's rows, so the v3 short's rows (kept in the append-only tables) are never corrected,
    withdrawn, pushed again, carried or counted, and the rule's own rows stay continuous whatever ran in between.
  - The switch (decision 6, and the code review of 30 Oct): the first step of the rule records in aplus_state the last
    row ids of the earlier rule (rule_marks), and marks them again whenever a row after them is not the rule's (an
    older release reinstalled, then this one). At each mark, the earlier rule's open days are cut over: each unsettled
    v3 suggestion is settled "no trade" with the reason RULE_REPLACED (no R: in no record), a v3 trade or order whose
    day is not final is held by the guard as an open EUR/USD trade to 17:00 New York of its day (aplus_state "held",
    sent with every request), and one alert says that its paper trade is no longer followed.
  - CPU (code review, 30 Oct): the child runs at nice 10, its timeout is [aplus] child_timeout_s (60 s by default),
    and after a failed or timed-out child run, or a step that fails after its child (a database error writing the
    run's rows), the next try waits for the next M5 close (one child a 5 minutes while it fails) instead of every
    1-minute close or every 30 s loop.
  - N2 (code review): the request carries aplus_trades_done, the placed A22 trades closed since the rule's first check
    (forward_trades), so the book's 1% ceiling holds until 25 of them; the risk is always [risk] risk_pct_per_trade.
  - The suggestion log (code review): a rebuilt order whose side changed withdraws the old suggestion (its reason
    WITHDRAWN_SIDE; settled "no trade", SIDE_CHANGED, when the day ends) and logs a new one on the new side; a side is
    never changed in place. Its card names the swept level (a SWEEP_<pool> tick).

run(now_wall):
  1. [aplus] enabled false: nothing. Else the heartbeat (aplus_state heartbeat_utc), which serve's monitor watches.
  2. The window: a London weekday (not 24, 25, 26, 31 Dec or 1 Jan) from 07:00 London to 17:00 New York + 10 min.
     The first step of the current rule records the switch marks (rule_marks).
  3. Inside the window, prices more than [aplus] stale_after_min behind the wall clock: one aplus_data_stale a
     stall; aplus_data_back when they catch up (at any time).
  4. T = the 1-minute close floor(min(feed marker, wall)). Nothing to do without a marker, when T is not past the
     last run's T, or when no pair-day is still open at T (open: from 07:00 London until its latest aplus_day row of
     this rule is final: not eligible, no trade, cancelled or closed).
  5. An earlier week (at most CARRY_WEEKS back) with a pair-day still open (a trade filled on Friday while the check
     was down until Monday) is rebuilt first, to its Friday 17:10 New York, once that time is in the prices.
  6. The days: London weekdays from Monday to today (the wall's London date), rebuilt from Monday each run as the
     verified run_live does. Bars from 00:00 London 60 days before Monday (the K14 window); fewer: refused, logged
     once a day.
  7. Bars with ts < T only (an assertion refuses any later row), with volume, to the child (python -I -B, its
     own environment of PATH and LANG only, a timeout). One aplus_run row per run, written in one transaction with
     its alerts (8), suggestion rows (9), day rows (10), the last loss and the mark that its close is done (last_T,
     or an earlier week's carried mark): a run that fails anywhere in them leaves none of it, so no "ran" row.
  8. Alerts, as run_live: an id not stored before is a new alert; a stored id whose facts now differ gets a
     correction row and an aplus_update; a stored id of a rebuilt day missing now (stamped at or before T) gets a
     withdrawn row and an aplus_update "no longer holds"; one that is back gets "holds again". The cancel or close of
     a trade the phone was told about is queued for the phone within 7 days, whatever its day (T's own day over 6 h
     late, the run again of a failed close, an earlier day). Else only alerts of T's London day stamped within 6 h
     are queued, an order only before its 11:00 London cancel. The rest are stored with pushed = 0 (a first run
     mid-week, a catch-up after a stop). Each alert row and its phone alert are written in one transaction, so a
     failure between them loses nothing (bot/NOTES.md finding 12).
  9. The suggestion log (app/suggest/log.py; owner, 16 Oct: every suggestion logged with his decision, the MT5 trade
     it led to and its own result): a pushed order is an offered suggestion (source "lead", rule APLUS-A22 on the
     order's own side, take, skip or changed on its card), a pushed guard skip one not offered; its own result is
     settled when its day is final.
     Its current row follows the stored alerts: a changed order corrects it, a fill takes the fill's broker prices
     (a market fill moves the stop and target), an order that no longer holds is a correction whose reason says so
     and one that holds again clears it (never the log's final cancel event: only the day's own end writes one).
 10. aplus_day: one row per pair-day whose phase, reason, order, fill, end or guard changed.
 11. last_T = T (also after a child error or timeout: the next 1-minute close rebuilds the week anyway). A close
     whose own run failed is run again while no new close is due, at most once every RETRY_S and while it is under
     RETRY_FOR_S old, so a cause fixed when no prices come (the evening, the weekend) clears the stall (12).
 12. Failed runs (error or refused, an error inside the step, the lock file not opened) count at most once an M5
     close (of the wall clock), so FAIL_ALERT_AFTER of them in a row inside the window take FAIL_ALERT_AFTER M5
     closes: one aplus_failing alert a stall; Today shows the failure. A close that failed inside the step is tried
     again at the next 30 s loop. A run that the child completes clears the count, with one aplus_check_back if the
     stall was alerted. So does the first loop that holds the lock and returns without an error, idle included, but
     only while the stall holds no failed run of the check (fail_run: a child error or timeout, a refusal, an error
     inside a run): an idle loop shows that the lock and the step's own reads work again, not the child.
"""
from __future__ import annotations

import fcntl
import io
import json
import logging
import os
import shutil
import subprocess
import sys
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from app import db
from app.aplus import alerts as AA
from app.aplus import pins, record
from app.timeutil import LONDON, NEW_YORK, to_iso

log = logging.getLogger("app.aplus")
CHILD = Path(__file__).with_name("child.py")
WINDOW_DAYS = 60                       # bot/live.py WINDOW_DAYS: 00:00 London 60 days before Monday (K14)
PUSH_WITHIN_S = 6 * 3600
HOLIDAY_MD = {(12, 24), (12, 25), (12, 26), (12, 31), (1, 1)}   # never traded (the research rule)
FINAL = ("NOT_ELIGIBLE", "NO_TRADE", "CANCELLED", "CLOSED")
QFIELDS = ("bid_o", "bid_h", "bid_l", "bid_c", "ask_o", "ask_h", "ask_l", "ask_c")
CHUNK = 20000
CHILD_ENV = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"}
FOLLOW_UP_S = 7 * 86400                # the cancel or close of a told trade is still pushed this long, whatever its day
CARRY_WEEKS = 2                        # earlier weeks whose open pair-day is still rebuilt
FAIL_ALERT_AFTER = 3                   # failed M5 closes in a row (in the window) before one aplus_failing alert
CLOSE_S = 60                           # T is a 1-minute close (the 3m chart's closes are not all 5m closes)
FAIL_KEYS = ("fail_since", "fail_n", "fail_status", "fail_detail", "fail_alerted", "fail_T", "fail_last_T",
             "fail_tried", "fail_run")
RETRY_S = 15 * 60                      # a close whose own run failed is run again at most this often while no new
RETRY_FOR_S = 4 * 86400                # close is due, and only while it is under this old (the longest market closure,
                                       # Christmas or New Year beside a weekend, is shorter)
WITHDRAWN = "No longer holds on the rebuilt prices"     # the reason of a withdrawn A+ suggestion (its correction row)
SUGGEST_PAIR = "EUR_USD"               # the suggestion log links EUR/USD MT5 trades only (app/suggest/log.py)
SIDE = {"sell": -1, "buy": 1}          # the suggestion log's side
WITHDRAWN_SIDE = "Withdrawn: the rebuilt prices changed its side"     # a suggestion whose order changed side
RULE_REPLACED = "RULE_REPLACED"        # the exit reason of a v3 suggestion settled at the switch (no R, no record)
NICE = shutil.which("nice", path="/usr/bin:/bin")       # the child runs at nice 10 (None: no nice on this system)
HELD_FOR_S = 7 * 86400                 # a v3 day ended more than this long before the switch is neither held nor told


class ChildError(RuntimeError):
    pass


# ---------------------------------------------------------------- clocks


def lon(d: date, hh: int, mm: int = 0) -> int:
    return int(datetime(d.year, d.month, d.day, hh, mm, tzinfo=LONDON).timestamp())


def nyt(d: date, hh: int, mm: int = 0) -> int:
    return int(datetime(d.year, d.month, d.day, hh, mm, tzinfo=NEW_YORK).timestamp())


def london_date(ts: int) -> date:
    return datetime.fromtimestamp(int(ts), LONDON).date()


def trading_weekday(d: date) -> bool:
    return d.weekday() < 5 and (d.month, d.day) not in HOLIDAY_MD


def close_of(ts: int) -> int:
    """The last 1-minute close at or before ts."""
    return int(ts) // CLOSE_S * CLOSE_S


def in_window(wall: int) -> bool:
    """07:00 London to 17:00 New York + 10 min on a London weekday that is traded."""
    d = london_date(wall)
    return trading_weekday(d) and lon(d, 7) <= wall <= nyt(d, 17) + 600


def week_days(wall: int) -> list[date]:
    """The London weekdays from Monday to the wall's London date (bot/live.py london_weekdays_of_week)."""
    d = london_date(wall)
    mon = d - timedelta(days=d.weekday())
    return [mon + timedelta(days=i) for i in range(5) if mon + timedelta(days=i) <= d]


def week_end_T(monday: date) -> int:
    """The close at Friday 17:10 New York of the week of monday: every pair-day of the week is final there."""
    return close_of(nyt(monday + timedelta(days=4), 17) + 600)


# ---------------------------------------------------------------- state


def get_state(conn, key: str) -> str | None:
    row = conn.execute("SELECT value FROM aplus_state WHERE key = ?", (key,)).fetchone()
    return None if row is None or row[0] == "" else row[0]


def set_state(conn, key: str, value) -> None:
    with db.transaction(conn):
        conn.execute("INSERT INTO aplus_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET"
                     " value = excluded.value", (key, "" if value is None else str(value)))


def _maxima(conn) -> dict:
    return {k: int(conn.execute(f"SELECT COALESCE(MAX(id), 0) FROM {t}").fetchone()[0])
            for k, t in (("alert", "aplus_alert"), ("day", "aplus_day"), ("run", "aplus_run"))}


def rule_marks(conn) -> dict:
    """{alert, day, run}: the last row ids when the current rule last cut over from the earlier one (the v3 short).
    Before the current rule's first step, every row so far is the earlier rule's."""
    from app.aplus import record
    if get_state(conn, "rule") == record.RULE_ID:
        return {k: int(get_state(conn, f"rule_{k}_id") or 0) for k in ("alert", "day", "run")}
    return _maxima(conn)


def rule_pattern() -> str:
    """LIKE pattern of a run row of the current rule (its versions_json, written by _record_run)."""
    from app.aplus import record
    return f'%"rule": "{record.RULE_ID}"%'


ALERT_PATTERN = "A22:%"                # the rule's alert ids (app/aplus/book.py RULE_TAG)


def latest_day(conn, pair: str, day: str) -> dict | None:
    """The latest aplus_day row of the current rule (written by one of its runs) for a pair-day, or None."""
    row = conn.execute("SELECT d.* FROM aplus_day d JOIN aplus_run r ON r.id = d.run_id WHERE d.pair = ? AND d.day = ?"
                       " AND r.versions_json LIKE ? ORDER BY d.id DESC LIMIT 1", (pair, day, rule_pattern())).fetchone()
    return None if row is None else dict(row)


def latest_days(conn, pairs, days: list[date]) -> dict:
    """{(pair, day iso): the latest aplus_day row of the current rule as a dict}"""
    out = {}
    for p in pairs:
        for d in days:
            row = latest_day(conn, p, d.isoformat())
            if row is not None:
                out[(p, d.isoformat())] = row
    return out


def forward_rows(conn, cache: bool = False) -> tuple[int | None, list[dict]]:
    """(the close of the current rule's first completed check, or None; its placed trades closed since then: the
    latest day rows of the rule, phase CLOSED, guard PLACE, armed at or after that close). The forward record (Today)
    and N2's forward trade count read the same rows. cache: the step keeps the first close in aplus_state (Today's
    reads never write)."""
    first = get_state(conn, "rule_first_T")
    if first is None:                        # found once: later runs only add later closes
        first = conn.execute("SELECT MIN(now_ts) FROM aplus_run WHERE status IN ('ran', 'late') AND versions_json"
                             " LIKE ?", (rule_pattern(),)).fetchone()[0]
        if first is None:
            return None, []
        if cache:
            set_state(conn, "rule_first_T", int(first))
    out = []
    for r in conn.execute("SELECT d.* FROM aplus_day d JOIN (SELECT dd.pair, dd.day, MAX(dd.id) AS mid FROM aplus_day dd"
                          " JOIN aplus_run rr ON rr.id = dd.run_id WHERE rr.versions_json LIKE ? GROUP BY dd.pair,"
                          " dd.day) m ON d.id = m.mid WHERE d.phase = 'CLOSED' ORDER BY d.day, d.pair",
                          (rule_pattern(),)):
        book = json.loads(r["guard_json"] or "null") or {}
        arm = (json.loads(r["order_json"] or "null") or {}).get("arm")
        if book.get("action") != "PLACE" or arm is None or int(arm) < int(first):
            continue
        out.append(dict(r))
    return int(first), out


def forward_trades(conn) -> int:
    """N2's count: the current rule's placed trades closed since its first check (the step's call: it caches)."""
    return len(forward_rows(conn, cache=True)[1])


def open_earlier_weeks(conn, monday: date) -> list[date]:
    """Mondays of the CARRY_WEEKS weeks before monday that hold a pair-day whose latest aplus_day row (of the current
    rule) is not final."""
    lo = (monday - timedelta(days=7 * CARRY_WEEKS)).isoformat()
    out = set()
    for r in conn.execute("SELECT d.day, d.phase FROM aplus_day d JOIN (SELECT dd.pair, dd.day, MAX(dd.id) AS mid"
                          " FROM aplus_day dd JOIN aplus_run rr ON rr.id = dd.run_id WHERE rr.versions_json LIKE ?"
                          " GROUP BY dd.pair, dd.day) m ON d.id = m.mid WHERE d.day >= ? AND d.day < ?",
                          (rule_pattern(), lo, monday.isoformat())):
        if r["phase"] not in FINAL:
            d = date.fromisoformat(r["day"])
            out.add(d - timedelta(days=d.weekday()))
    return sorted(out)


def sent_alerts(conn) -> dict:
    """{alert_id: the latest aplus_alert row of the current rule (dict) plus 'rows' (how many rows that id has)}"""
    out = {}
    for r in conn.execute("SELECT a.*, m.n AS rows FROM aplus_alert a JOIN (SELECT alert_id, MAX(id) AS mid,"
                          " COUNT(*) AS n FROM aplus_alert WHERE alert_id LIKE ? GROUP BY alert_id) m ON a.id = m.mid"
                          " ORDER BY a.id", (ALERT_PATTERN,)):
        out[r["alert_id"]] = dict(r)
    return out


# ---------------------------------------------------------------- bars and the child


def read_bars(conn, lo: int, hi: int) -> dict:
    """m1_bar rows with lo <= ts < hi as arrays (ts and volume int64, prices float64), read in one query so prices
    and volume come from the same rows (app/suggest/bars.py reads the prices only). Refuses a row at or after hi."""
    import numpy as np
    n = conn.execute("SELECT COUNT(*) FROM m1_bar WHERE ts >= ? AND ts < ?", (int(lo), int(hi))).fetchone()[0]
    out = {"ts_utc": np.empty(n, dtype=np.int64), "volume": np.empty(n, dtype=np.int64)}
    for f in QFIELDS:
        out[f] = np.empty(n, dtype=np.float64)
    cur = conn.execute("SELECT ts, bid_o, bid_h, bid_l, bid_c, ask_o, ask_h, ask_l, ask_c, volume FROM m1_bar"
                       " WHERE ts >= ? AND ts < ? ORDER BY ts", (int(lo), int(hi)))
    i = 0
    while i < n:
        rows = cur.fetchmany(CHUNK)
        if not rows:
            break
        j = i + len(rows)
        out["ts_utc"][i:j] = [r[0] for r in rows]
        out["volume"][i:j] = [r[9] for r in rows]
        block = np.array([r[1:9] for r in rows], dtype=np.float64)
        for c, f in enumerate(QFIELDS):
            out[f][i:j] = block[:, c]
        i = j
    if i < n:
        out = {k: v[:i] for k, v in out.items()}
    if len(out["ts_utc"]) and int(out["ts_utc"].max()) >= int(hi):
        raise AssertionError("a bar at or after T reached the A+ child")
    return out


def subprocess_child(arrays: dict, req: dict, timeout_s: int, python: str = sys.executable) -> dict:
    """The pinned code in its own `python -I -B` process at nice 10; its environment holds PATH and LANG only."""
    import numpy as np
    buf = io.BytesIO()
    np.savez(buf, request=np.array(json.dumps(req)), **arrays)
    cmd = ([NICE, "-n", "10"] if NICE else []) + [python, "-I", "-B", str(CHILD)]
    r = subprocess.run(cmd, input=buf.getvalue(), capture_output=True,
                       timeout=timeout_s, cwd=str(CHILD.parent), env=dict(CHILD_ENV))
    if r.returncode != 0:
        raise ChildError(crash_words(r.stderr.decode(errors="replace"), r.returncode))
    return json.loads(r.stdout)


def crash_words(stderr: str, code: int) -> str:
    """A crashed child in words: its last stderr line first (the error type and message: what the alert and Today
    show), then the exit code and the end of stderr (for the run row and the log)."""
    lines = [x.strip() for x in stderr.splitlines() if x.strip()]
    tail = " ".join(stderr[-400:].split())
    if not lines:
        return f"exit {code}"
    return f"{lines[-1]} (exit {code})" + (f"; stderr: {tail}" if tail != lines[-1] else "")


def _db_file(conn) -> Path | None:
    main = next((r[2] for r in conn.execute("PRAGMA database_list") if r[1] == "main"), "")
    return Path(main) if main else None


# ---------------------------------------------------------------- the step


class AplusStep:
    def __init__(self, conn, cfg, run_child=None, python: str = sys.executable):
        self.conn, self.cfg = conn, cfg
        self.python = python
        self.run_child = run_child or (lambda arrays, req, timeout_s: subprocess_child(arrays, req, timeout_s,
                                                                                      self.python))
        self._in_run = False                         # inside a run of the check (_week): an error is a failed run
        self._run_T: int | None = None               # the close that run is for (the back-off after an error)

    # -------------------------------------------------------------- the one-at-a-time lock
    def _lock(self):
        """An exclusive lock beside the journal, so `python -m app aplus --once` never runs beside the worker's step.
        The file is opened read-only (flock needs no write access), so one made by another user never stops the
        worker. True for an in-memory journal (tests), the open file, None when busy, or the OSError."""
        path = _db_file(self.conn)
        if path is None:
            return True
        try:
            f = os.fdopen(os.open(path.parent / "aplus.lock", os.O_RDONLY | os.O_CREAT, 0o644), "rb")
        except OSError as e:
            return e
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            f.close()
            return None
        return f

    def run(self, now_wall: datetime) -> dict:
        if not self.cfg.aplus.enabled:
            return {"status": "off"}
        lock = self._lock()
        if lock is None:
            return {"status": "busy"}
        if isinstance(lock, OSError):
            msg = f"the lock file beside the journal cannot be opened: {lock.strerror or lock}"
            queued: list[str] = []
            set_state(self.conn, "heartbeat_utc", to_iso(now_wall))
            self._failed(now_wall, "error", msg, queued)
            log.warning("A+ step: %s", msg)
            return {"status": "error", "message": msg, "queued": queued}
        self._in_run = False
        self._run_T = None
        try:
            r = self._run(now_wall)
            # it held the lock and nothing failed: a stall of the step alone ends here, idle too; one that holds a
            # failed run of the check ends only at a run the child completes (_run calls _succeeded then)
            if r.pop("healthy", False) and get_state(self.conn, "fail_run") is None:
                self._succeeded(now_wall, r.setdefault("queued", []))
            return r
        except Exception as e:                       # noqa: BLE001  (counted as a failed run, then raised)
            try:
                self._failed(now_wall, "error", f"{type(e).__name__}: {str(e)[:300]}", [], run=self._in_run)
                if self._in_run and self._run_T is not None:   # failed inside a run (after its child too): the next
                    self._close_failed(self._run_T, int(now_wall.timestamp()))   # try waits for the next M5 close
            except Exception:                        # noqa: BLE001
                log.exception("A+ step: the failure could not be recorded")
            raise
        finally:
            if lock is not True:
                lock.close()

    def _run(self, now_wall: datetime) -> dict:
        from app.feed.oanda import complete_through
        conn, cfg = self.conn, self.cfg
        if now_wall.tzinfo is None:
            raise ValueError("now must be a time with a zone (UTC)")
        wall = int(now_wall.timestamp())
        set_state(conn, "heartbeat_utc", to_iso(now_wall))
        self._switch(wall)
        marker = complete_through(conn)
        queued: list[str] = []
        self._stale(wall, now_wall, marker, queued)
        if marker is None:
            return {"status": "no prices yet", "queued": queued, "healthy": True}
        T = close_of(min(int(marker), wall))
        days = week_days(wall)
        monday = days[0]
        last_T = get_state(conn, "last_T")
        latest = latest_days(conn, cfg.aplus.pairs, days)
        open_days = [d for d in days if lon(d, 7) <= T
                     and any((p, d.isoformat()) not in latest or latest[(p, d.isoformat())]["phase"] not in FINAL
                             for p in cfg.aplus.pairs)]
        carry = [m for m in open_earlier_weeks(conn, monday) if get_state(conn, f"carried:{m.isoformat()}") is None]
        if last_T is not None and T <= int(last_T):          # this close was tried: healthy unless its run failed
            failed = get_state(conn, "fail_last_T") == str(int(last_T))
            if not (failed and run_again(conn, T, int(last_T), wall)):
                return {"status": "idle", "T": T, "queued": queued, "healthy": not failed}
        elif last_T is not None and get_state(conn, "fail_last_T") == str(int(last_T)) and T < next_m5(int(last_T)):
            # the last close's child run failed or timed out: the next try waits for the next M5 close (CPU)
            return {"status": "idle", "T": T, "queued": queued, "healthy": False}
        if not (open_days or carry):                         # nothing open to check: the step itself is fine
            return {"status": "idle", "T": T, "queued": queued, "healthy": True}
        res: dict = {"new": [], "updates": 0, "status": "ran"}
        self._run_T = T
        for n, mon in enumerate(carry):                      # an earlier week first ("never larger after a loss")
            Tc = min(T, week_end_T(mon))
            done = {}
            if Tc == week_end_T(mon):                        # rebuilt to its end: never again, final or not
                done[f"carried:{mon.isoformat()}"] = T
            if not open_days and n == len(carry) - 1:        # the loop's last run: its close is done with it
                done["last_T"] = T
            self._in_run = True
            r = self._week(now_wall, wall, marker, Tc, [mon + timedelta(days=i) for i in range(5)], mon, queued,
                           london_date(T).isoformat(), done)
            self._in_run = False
            if r["status"] in ("error", "refused"):
                self._close_failed(T, wall)                  # idle until the next close is not "running again"
                return dict(r, T=T, queued=queued)
            res = {"new": res["new"] + r.get("new", []), "updates": res["updates"] + r.get("updates", 0),
                   "status": r["status"]}
        if not open_days:
            self._succeeded(now_wall, queued)
            return dict(res, T=T, queued=queued)
        week = monday.isoformat()
        if get_state(conn, "week") != week:          # "never larger after a loss" carries over the weekend
            set_state(conn, "week_start_last_loss", get_state(conn, "last_loss_full_usd"))
            set_state(conn, "week", week)
        self._in_run = True
        r = self._week(now_wall, wall, marker, T, days, monday, queued, london_date(T).isoformat(), {"last_T": T})
        self._in_run = False
        if r["status"] in ("ran", "late"):
            self._succeeded(now_wall, queued)
        else:
            self._close_failed(T, wall)
        return dict(r, new=res["new"] + r.get("new", []), updates=res["updates"] + r.get("updates", 0), T=T,
                    queued=queued)

    def _stray(self) -> bool:
        """A row after the marks that is not the current rule's: an older release ran after them. Each step reads only
        the rows written since the last clean check (rule_checked), so the cost stays flat as the tables grow."""
        conn, marks = self.conn, rule_marks(self.conn)
        seen = json.loads(get_state(conn, "rule_checked") or "{}")
        lo = {k: max(marks[k], int(seen.get(k, 0))) for k in marks}
        stray = any(conn.execute(sql, args).fetchone() is not None for sql, args in (
            ("SELECT 1 FROM aplus_alert WHERE id > ? AND alert_id NOT LIKE ? LIMIT 1", (lo["alert"], ALERT_PATTERN)),
            ("SELECT 1 FROM aplus_run WHERE id > ? AND status IN ('ran', 'late') AND versions_json NOT LIKE ? LIMIT 1",
             (lo["run"], rule_pattern())),
            ("SELECT 1 FROM aplus_day d LEFT JOIN aplus_run r ON r.id = d.run_id WHERE d.id > ? AND (r.id IS NULL OR"
             " r.versions_json NOT LIKE ?) LIMIT 1", (lo["day"], rule_pattern()))))
        if not stray:
            now = _maxima(conn)
            if now != {k: int(seen.get(k, -1)) for k in now}:
                set_state(conn, "rule_checked", json.dumps(now, sort_keys=True))
        return stray

    def _switch(self, wall: int) -> None:
        """The first step of the current rule (record.RULE_ID), and any step that finds a row of an older release after
        the marks, marks where the earlier rule's rows end (rule_marks) and cuts its open days over (_cut_over)."""
        from app.aplus import record
        if get_state(self.conn, "rule") == record.RULE_ID and not self._stray():
            return
        from app.notify.alerts import queue_alert
        conn = self.conn
        marks = _maxima(conn)
        now_wall = datetime.fromtimestamp(wall, timezone.utc)
        with db.transaction(conn):
            for k, v in marks.items():
                set_state(conn, f"rule_{k}_id", v)
            set_state(conn, "rule_since", wall)
            set_state(conn, "rule", record.RULE_ID)
            held, told = self._cut_over(wall, now_wall)
            set_state(conn, "held", json.dumps(held, sort_keys=True))
            for day in told:
                queue_alert(conn, AA.v3_replaced(date.fromisoformat(day)), now_wall)

    def _cut_over(self, wall: int, now_wall: datetime) -> tuple[list, list]:
        """The earlier rule's open days at the mark: (held, told). held: each v3 day whose latest row is not final and
        holds an order, ended under HELD_FOR_S ago: {day, since (its arm), until (17:00 New York of the day)}; told:
        those of them the phone was told of (a pushed v3 alert). Each unsettled v3 suggestion is settled "no trade",
        RULE_REPLACED, with no R."""
        from app.aplus import record
        from app.suggest import log as L
        conn = self.conn
        held, told = [], []
        for r in conn.execute("SELECT d.* FROM aplus_day d JOIN (SELECT dd.pair, dd.day, MAX(dd.id) AS mid FROM aplus_day"
                              " dd LEFT JOIN aplus_run rr ON rr.id = dd.run_id WHERE rr.id IS NULL OR rr.versions_json"
                              " NOT LIKE ? GROUP BY dd.pair, dd.day) m ON d.id = m.mid ORDER BY d.day",
                              (rule_pattern(),)):
            day = date.fromisoformat(r["day"])
            until = nyt(day, 17)
            order = json.loads(r["order_json"] or "null")
            if r["phase"] in FINAL or not order or r["pair"] != SUGGEST_PAIR or wall - until > HELD_FOR_S:
                continue
            held.append({"day": r["day"], "since": int(order.get("arm") or lon(day, 7)), "until": until})
            if conn.execute("SELECT 1 FROM aplus_alert WHERE pair = ? AND day = ? AND pushed = 1 AND alert_id NOT LIKE ?"
                            " LIMIT 1", (r["pair"], r["day"], ALERT_PATTERN)).fetchone() is not None:
                told.append(r["day"])
        rules = record.LEGACY_RULE_IDS
        for s in conn.execute(f"SELECT id FROM suggestion WHERE supersedes_id IS NULL AND rule_id IN"
                              f" ({','.join('?' * len(rules))}) ORDER BY id", rules).fetchall():
            if L.result(conn, s[0]) is None:
                L.settle(conn, s[0], {"outcome": "no_trade", "exit_reason": RULE_REPLACED, "unit": "R"}, now=now_wall)
        return held, told

    def _close_failed(self, T: int, wall: int) -> None:
        """The close T was tried and its own run failed (child error or timeout, refusal): idle until the next close,
        or until it is run again (run_again: fail_tried is when it was last tried)."""
        with db.transaction(self.conn):
            for k, v in (("last_T", T), ("fail_last_T", T), ("fail_tried", wall)):
                set_state(self.conn, k, v)

    def _week(self, now_wall: datetime, wall: int, marker: int, T: int, days: list[date], monday: date,
              queued: list, push_day: str, done: dict | None = None) -> dict:
        """One child run for the London days `days` of the week of `monday`, to the close T. done: the state that
        marks the run's close done (last_T, a carried week), written with the run when it succeeds."""
        conn, cfg = self.conn, self.cfg
        t_from = lon(monday - timedelta(days=WINDOW_DAYS), 0)
        first = conn.execute("SELECT MIN(ts) FROM m1_bar").fetchone()[0]
        if first is None or int(first) > t_from:
            today = london_date(wall).isoformat()
            have = "none" if first is None else datetime.fromtimestamp(int(first), timezone.utc).date().isoformat()
            msg = f"under {WINDOW_DAYS} days of prices before Monday {monday.isoformat()}: first bar {have}"
            if get_state(conn, "refused_day") != today:
                self._record_run(now_wall, T, marker, "refused", 0.0, {}, 0, msg)
                set_state(conn, "refused_day", today)
            self._failed(now_wall, "refused", msg, queued, run=True)
            return {"status": "refused", "message": msg}
        arrays = read_bars(conn, t_from, T)
        wsll = get_state(conn, "week_start_last_loss") if get_state(conn, "week") == monday.isoformat() else None
        req = {"now": T, "days": [d.isoformat() for d in days], "pairs": list(cfg.aplus.pairs),
               "balance": None if cfg.account.currency != "USD" else repr(float(cfg.paper.balance)),
               "risk_pct": repr(float(cfg.risk.risk_pct_per_trade)),
               "last_loss_full_usd": wsll, "quotes": cfg.aplus.quotes,
               "held": json.loads(get_state(conn, "held") or "[]"), "aplus_trades_done": forward_trades(conn)}
        t0 = time.monotonic()
        try:
            out = self.run_child(arrays, req, cfg.aplus.child_timeout_s)
        except subprocess.TimeoutExpired:
            out = {"status": "error", "message": f"timeout after {cfg.aplus.child_timeout_s} s"}
        except Exception as e:                       # noqa: BLE001  (a crash is recorded; the loop goes on)
            out = {"status": "error", "message": f"{type(e).__name__}: {e}"}   # a ChildError's last line first
        secs = round(time.monotonic() - t0, 3)
        if out.get("status") != "done":
            status = "refused" if out.get("status") == "refused" else "error"
            msg = str(out.get("message") or "")[:500]
            self._record_run(now_wall, T, marker, status, secs, {}, 0, msg)
            self._failed(now_wall, status, msg, queued, run=True)
            log.warning("A+ step: %s at %s: %s", status, T, out.get("message"))
            return {"status": status, "message": out.get("message")}
        status = "late" if wall - T > cfg.aplus.late_after_min * 60 else "ran"
        # the run row, its alerts, its day rows, the last loss and the done mark: a run that fails in any of them
        # leaves none of it (no "ran" row), and the close is tried again at the next loop
        with db.transaction(conn):
            run_id = self._record_run(now_wall, T, marker, status, secs, out.get("versions") or {},
                                      int(out.get("engine_runs") or 0), "")
            res = self._alerts(out, run_id, T, days, now_wall, queued, push_day)
            self._days(out, run_id, now_wall)
            set_state(conn, "last_loss_full_usd", out.get("last_loss_full_usd"))
            set_state(conn, "fail_run", None)        # the child completed: a stall now ends at a loop without an error
            for k, v in (done or {}).items():
                set_state(conn, k, v)
        return dict(res, status=status, run_id=run_id, seconds=secs)

    # -------------------------------------------------------------- failed runs
    def _failed(self, now_wall: datetime, status: str, detail: str, queued: list, run: bool = False) -> None:
        """One more failed run in a row, counted at most once an M5 close of the wall clock (fail_T): the worker loops
        every 30 s and retries a close that failed inside the step, so a count per loop would alert after 60 s. After
        FAIL_ALERT_AFTER closes, inside the window, one aplus_failing alert a stall: silence would read as "no A+ setup
        today". The latest reason is kept either way. run: a failed run of the check (the child failed or timed out,
        a refusal, an error inside the run), which only a run the child completes clears (fail_run)."""
        from app.notify.alerts import queue_alert
        conn = self.conn
        wall = int(now_wall.timestamp())
        close = wall // 300 * 300
        made: list[str] = []
        with db.transaction(conn):
            set_state(conn, "fail_status", status)
            set_state(conn, "fail_detail", " ".join((detail or "").split())[:300])
            if run:
                set_state(conn, "fail_run", 1)
            counted = get_state(conn, "fail_T")
            if counted is None or close > int(counted):
                since = int(get_state(conn, "fail_since") or wall)
                n = int(get_state(conn, "fail_n") or 0) + 1
                for k, v in (("fail_since", since), ("fail_n", n), ("fail_T", close)):
                    set_state(conn, k, v)
                if n >= FAIL_ALERT_AFTER and in_window(wall) and get_state(conn, "fail_alerted") is None:
                    a = AA.failing(since, n, status, detail, unit=AA.unit_of(self.cfg), at=wall)
                    if queue_alert(conn, a, now_wall):
                        made.append(a.key)
                    set_state(conn, "fail_alerted", a.key)
        queued.extend(made)

    def _succeeded(self, now_wall: datetime, queued: list) -> None:
        """A check ran, or a loop held the lock and found nothing failing while the stall held no failed run of the
        check (run): the failure count starts again, with one aplus_check_back if the stall was alerted."""
        from app.notify.alerts import queue_alert
        conn = self.conn
        if get_state(conn, "fail_since") is None:
            return
        made: list[str] = []
        with db.transaction(conn):
            if get_state(conn, "fail_alerted") is not None:
                a = AA.check_back(int(get_state(conn, "fail_since")), int(get_state(conn, "fail_n") or 0),
                                  int(now_wall.timestamp()))
                if queue_alert(conn, a, now_wall):
                    made.append(a.key)
            for k in FAIL_KEYS:
                set_state(conn, k, None)
        queued.extend(made)

    # -------------------------------------------------------------- pieces
    def _stale(self, wall: int, now_wall: datetime, marker: int | None, queued: list) -> None:
        """The state change and its alert in one transaction (a failure between them loses neither)."""
        from app.notify.alerts import queue_alert
        if marker is None:
            return
        conn, thr = self.conn, self.cfg.aplus.stale_after_min * 60
        since = get_state(conn, "stale_since")
        lag = wall - int(marker)
        day = london_date(wall)
        made: list[str] = []
        if lag > thr:
            if since is None and in_window(wall):
                a = AA.data_stale(day, int(marker), now_wall)
                with db.transaction(conn):
                    set_state(conn, "stale_since", int(marker))
                    if queue_alert(conn, a, now_wall):
                        made.append(a.key)
        elif since is not None:
            a = AA.data_back(day, int(since), int(marker))
            with db.transaction(conn):
                set_state(conn, "stale_since", None)
                if queue_alert(conn, a, now_wall):
                    made.append(a.key)
        queued.extend(made)

    def _record_run(self, now_wall, T, marker, status, secs, versions, engine_runs, detail) -> int:
        """One aplus_run row, its versions stamped with the current rule (rows are the rule's by their run)."""
        from app.aplus import record
        versions = dict(versions or {}, rule=record.RULE_ID)
        with db.transaction(self.conn):
            return self.conn.execute(
                "INSERT INTO aplus_run (run_utc, now_ts, marker_ts, status, seconds, engine_runs, versions_json,"
                " detail) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (to_iso(now_wall), int(T), None if marker is None else int(marker), status, float(secs),
                 int(engine_runs), json.dumps(versions, sort_keys=True), detail)).lastrowid

    def _day_rule(self, now_wall: datetime) -> str | None:
        """The owner's own MT5 day guard in words when it is not open (shown, never applied: design D8)."""
        try:
            from app.risk.day_guard import STATUS_WORDS
            from app.risk.flags import guard_now
            g = guard_now(self.conn, self.cfg, now_wall, "mt5")
        except Exception:                            # noqa: BLE001  (a missing guard never stops an alert)
            return None
        if g.status == "open":
            return None
        return f"{STATUS_WORDS.get(g.status, g.status)} ({g.reason})"

    def _alerts(self, out: dict, run_id: int, T: int, days: list[date], now_wall: datetime, queued: list,
                push_day: str) -> dict:
        from app.notify.alerts import queue_alert
        conn, cfg = self.conn, self.cfg
        wall = int(now_wall.timestamp())
        late_s = cfg.aplus.late_after_min * 60
        states = {(s["pair"], s["date"]): s for s in out.get("states") or []}
        books = {(b["pair"], b["date"]): b for b in out.get("book") or []}
        day_rule = self._day_rule(now_wall) if any(a["kind"] == "ORDER" for a in out.get("alerts") or []) else None
        told = {(r[0], r[1]) for r in conn.execute("SELECT DISTINCT pair, day FROM aplus_alert WHERE pushed = 1"
                                                   " AND alert_id LIKE ?", (ALERT_PATTERN,))}

        def ctx(a):
            k = (a["pair"], a["date"])
            return {"state": states.get(k) or {}, "book": books.get(k) or {}, "day_rule": day_rule}

        def push_ok(a: dict, at: int, kind: str) -> bool:
            if kind in ("CANCELLED", "CLOSED") and (a["pair"], a["date"]) in told:
                return wall - int(at) <= FOLLOW_UP_S     # the end of a trade the phone was told of, whatever its day
            if a["date"] != push_day:                # an earlier day: nothing else
                return False
            if wall - int(at) > PUSH_WITHIN_S:
                return False
            return kind != "ORDER" or wall < AA.cancel_ts(date.fromisoformat(a["date"]))

        sent = sent_alerts(conn)
        rebuilt = {a["id"]: a for a in out.get("alerts") or []}
        rows = []                                    # each: the alert, its row fields and how it reaches the phone
        for a in out.get("alerts") or []:
            old = sent.get(a["id"])
            if old is None:
                rows.append(dict(a=a, how="new", supersedes=None, withdrawn=0, push=push_ok(a, a["at"], a["kind"]),
                                 n=None, why=None))
                continue
            old_facts = json.loads(old["facts_json"])
            if old["withdrawn"] or old_facts != a["facts"]:
                why = ("it holds again on the rebuilt prices" if old["withdrawn"]
                       else "the rebuilt prices changed it: " + "; ".join(AA.changes(old_facts, a["facts"])))
                rows.append(dict(a=a, how="update", supersedes=old["id"], withdrawn=0, push=push_ok(a, T, "UPDATE"),
                                 n=int(old["rows"]), why=why, old_facts=old_facts))
        rebuilt_days = {d.isoformat() for d in days}
        for aid, old in sorted(sent.items()):
            if old["withdrawn"] or old["day"] not in rebuilt_days or int(old["at_ts"]) > T or aid in rebuilt:
                continue
            a = dict(id=aid, at=int(old["at_ts"]), pair=old["pair"], date=old["day"], kind=old["kind"],
                     facts=json.loads(old["facts_json"]), text=old["text"])
            rows.append(dict(a=a, how="withdrawn", supersedes=old["id"], withdrawn=1, push=push_ok(a, T, "UPDATE"),
                             n=int(old["rows"]), why=None))
        also: dict = {}
        for r in rows:
            also.setdefault((r["a"]["pair"], r["a"]["date"]), set()).add(
                r["a"]["kind"] if r["how"] == "new" else "UPDATE")
        phone = []                                   # every phone alert is built before anything is written
        for r in rows:
            if not r["push"]:
                continue
            a = r["a"]
            others = also.get((a["pair"], a["date"]), set()) - {a["kind"]}
            if r["how"] == "new":
                phone.append(AA.build(cfg, a, ctx(a), now_wall, late_s, others))
            else:
                now_alert = None if r["how"] == "withdrawn" else AA.build(cfg, a, ctx(a), now_wall, 10 ** 9)
                phone.append(AA.update(cfg, a, r["n"], r["why"] or "", now_alert, T, now_wall, late_s))
        made = to_iso(now_wall)
        new_keys: list[str] = []
        with db.transaction(conn):                   # the rows, their phone alerts and the log: all or nothing
            for r in rows:
                a = r["a"]
                conn.execute("INSERT INTO aplus_alert (alert_id, kind, pair, day, at_ts, facts_json, text, pushed,"
                             " withdrawn, made_utc, run_id, supersedes_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                             (a["id"], a["kind"], a["pair"], a["date"], int(a["at"]),
                              json.dumps(a["facts"], sort_keys=True), a.get("text") or "", int(bool(r["push"])),
                              r["withdrawn"], made, run_id, r["supersedes"]))
            for alert in phone:
                if queue_alert(conn, alert, now_wall):
                    new_keys.append(alert.key)
            self._suggestions(rows, states, now_wall, T)
        queued.extend(new_keys)
        return {"new": [r["a"]["id"] for r in rows if r["how"] == "new"],
                "updates": sum(1 for r in rows if r["how"] != "new")}

    # -------------------------------------------------------------- the suggestion log (owner, 16 Oct)
    def _suggestions(self, rows: list, states: dict, now_wall: datetime, T: int) -> None:
        """A pushed order: an offered suggestion; a pushed guard skip: one not offered (its reason the guard's rule).
        Then each day whose order or fill alert changed brings its suggestion's current row up to the stored alerts
        (_sync_suggestion). Called inside the alert transaction, after the alert rows are written."""
        from app.suggest import log as L
        wall = int(now_wall.timestamp())
        late_s = self.cfg.aplus.late_after_min * 60
        touched: set[str] = set()
        for r in rows:
            a = r["a"]
            if a["pair"] != SUGGEST_PAIR:
                continue
            if a["kind"] in ("ORDER", "FILLED"):
                touched.add(a["date"])
            if a["kind"] not in ("ORDER", "SKIPPED"):
                continue
            sid = suggestion_of(self.conn, a["date"])
            if r["how"] == "new" and r["push"] and sid is None:      # later changes, a side too: _sync_suggestion
                if a["kind"] == "ORDER":
                    L.add_suggestion(self.conn, suggestion_row(a, None, wall - int(a["facts"]["arm"]) > late_s),
                                     now=now_wall)
                else:
                    order = (states.get((a["pair"], a["date"])) or {}).get("order") or {}
                    if order.get("arm") is not None:
                        L.add_suggestion(self.conn, suggestion_row(a, order, wall - int(order["arm"]) > late_s),
                                         now=now_wall)
        for day in sorted(touched):
            self._sync_suggestion(day, now_wall)

    def _sync_suggestion(self, day: str, now_wall: datetime) -> None:
        """The offered A+ suggestion of a day follows its latest stored ORDER and FILLED alerts, by correction rows
        only (the log is append-only; its card reads the latest): a changed order corrects the arm time, prices, size
        and swept level; a fill gives the fill's broker prices (a market fill moves the stop and target); an order that
        no longer holds gets the reason WITHDRAWN, and one that holds again clears it. A side is never changed in
        place: when the order's side changes, every offered suggestion of the day on the other side is withdrawn
        (WITHDRAWN_SIDE) and the suggestion of the new side is logged (or brought back). No event is written here: the
        log's cancel or expiry event is final, and only the day's own end (_settle) writes one."""
        from app.aplus import book as BK
        from app.suggest import log as L
        conn = self.conn
        roots = [L.current(conn, sid) for sid in suggestion_roots(conn, day)]
        offered = [c for c in roots if c["offered"]]
        if not offered:
            return

        def latest(kind):
            return conn.execute("SELECT facts_json, withdrawn FROM aplus_alert WHERE alert_id = ? ORDER BY id DESC"
                                " LIMIT 1", (BK.alert_id(kind, SUGGEST_PAIR, day),)).fetchone()
        order, fill = latest("ORDER"), latest("FILLED")
        if order is None:
            return
        if order["withdrawn"]:
            for cur in offered:
                if cur["reason"] not in (WITHDRAWN, WITHDRAWN_SIDE):
                    L.correct_suggestion(conn, cur["id"], {"reason": WITHDRAWN}, now=now_wall)
            return
        facts = json.loads(order["facts_json"])
        new = suggestion_row({"date": day, "facts": facts}, None, False)
        for cur in offered:
            if cur["side"] != new["side"] and cur["reason"] != WITHDRAWN_SIDE:
                L.correct_suggestion(conn, cur["id"], {"reason": WITHDRAWN_SIDE}, now=now_wall)
        mine = [c for c in offered if c["side"] == new["side"]]
        if mine:
            cur = mine[0]
        else:
            late = int(now_wall.timestamp()) - int(facts["arm"]) > self.cfg.aplus.late_after_min * 60
            sid, _ = L.add_suggestion(conn, suggestion_row({"date": day, "facts": facts}, None, late), now=now_wall)
            cur = L.current(conn, sid)
        want = {k: new[k] for k in ("placed_ts", "w")}
        src = json.loads(fill["facts_json"]) if fill is not None and not fill["withdrawn"] else facts
        want.update({k: int(src[k]) / 100000.0 for k in ("entry", "stop", "target")})
        want["reason"] = None
        change = {k: v for k, v in want.items() if cur[k] != v}
        if json.loads(cur["ticks_json"] or "{}") != new["ticks"]:
            change["ticks"] = new["ticks"]
        if change:
            L.correct_suggestion(conn, cur["id"], change, now=now_wall)

    def _settle(self, s: dict, now_wall: datetime) -> None:
        """A final pair-day settles its suggestions' own results once (inside the day transaction): the one on the
        order's side by the day's end; one withdrawn when the side changed: "no trade", SIDE_CHANGED."""
        from app.suggest import log as L
        if s["pair"] != SUGGEST_PAIR or s["phase"] not in FINAL:
            return
        side = SIDE.get((s.get("order") or {}).get("side"))
        for sid in suggestion_roots(self.conn, s["date"]):
            if L.result(self.conn, sid) is not None:
                continue
            if side is not None and L.get(self.conn, sid)["side"] != side:
                L.settle(self.conn, sid, {"outcome": "no_trade", "exit_reason": "SIDE_CHANGED", "unit": "R"},
                         now=now_wall)
                continue
            self._settle_one(sid, s, now_wall)

    def _settle_one(self, sid: int, s: dict, now_wall: datetime) -> None:
        from app.suggest import log as L
        end = s.get("end") or {}
        if s["phase"] == "CLOSED":
            res = {"outcome": "filled", "exit_reason": end.get("kind"), "R_20": end.get("R_20_float")}
        elif s["phase"] == "CANCELLED":
            kind = end.get("kind")
            event = "expiry" if kind == "EXPIRED" else "cancel"
            if end.get("at") is not None and event not in L.events(self.conn, sid):
                L.add_event(self.conn, sid, event, int(end["at"]), now=now_wall, detail=str(kind or ""))
            res = {"outcome": "expired" if kind == "EXPIRED" else "cancelled", "exit_reason": kind}
        else:                                        # the order no longer holds: no trade that day
            res = {"outcome": "no_trade", "exit_reason": s.get("reason") or None}
        L.settle(self.conn, sid, dict(res, unit="R"), now=now_wall)

    def _days(self, out: dict, run_id: int, now_wall: datetime) -> None:
        """aplus_day rows and the suggestions' results (called inside the run's transaction, after its alerts)."""
        conn = self.conn
        books = {(b["pair"], b["date"]): b for b in out.get("book") or []}
        days = sorted({s["date"] for s in out.get("states") or []})
        latest = latest_days(conn, sorted({s["pair"] for s in out.get("states") or []}),
                             [date.fromisoformat(d) for d in days])   # the rule's own rows only

        def dump(x):
            return None if x is None else json.dumps(x, sort_keys=True)

        with db.transaction(conn):
            for s in out.get("states") or []:
                k = (s["pair"], s["date"])
                end = s.get("end") or {}
                rec = dict(phase=s["phase"], reason=s.get("reason") or "", order_json=dump(s.get("order")),
                           fill_json=dump(s.get("fill")), end_json=dump(s.get("end")), guard_json=dump(books.get(k)))
                old = latest.get(k)
                if old is None or any(old[f] != v for f, v in rec.items()):
                    conn.execute("INSERT INTO aplus_day (pair, day, phase, reason, order_json, fill_json, end_json,"
                                 " guard_json, r_owner, r_20, made_utc, run_id)"
                                 " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                                 (s["pair"], s["date"], rec["phase"], rec["reason"], rec["order_json"],
                                  rec["fill_json"], rec["end_json"], rec["guard_json"], end.get("R_float"),
                                  end.get("R_20_float"), to_iso(now_wall), run_id))
                self._settle(s, now_wall)


def run_again(conn, T: int, last_T: int, wall: int) -> bool:
    """Whether the close last_T, whose own run failed, is run again now: no new close is due (T is that close), it is
    under RETRY_FOR_S old and was last tried RETRY_S ago or more. Each run again that fails counts as one more failed
    run (at most one an M5 close, _failed); one that succeeds clears the stall."""
    tried = get_state(conn, "fail_tried")
    return T == last_T and wall - T <= RETRY_FOR_S and (tried is None or wall - int(tried) >= RETRY_S)


def next_m5(t: int) -> int:
    """The first M5 close after t."""
    return (int(t) // 300 + 1) * 300


def suggestion_roots(conn, day_iso: str) -> list[int]:
    """The A+ suggestions (their first rows) of a London day, oldest first: one a side at most (EUR/USD only)."""
    d = date.fromisoformat(day_iso)
    return [int(r[0]) for r in conn.execute(
        "SELECT id FROM suggestion WHERE rule_id = ? AND supersedes_id IS NULL AND placed_ts >= ? AND placed_ts < ?"
        " ORDER BY id", (record.RULE_ID, lon(d, 0), lon(d + timedelta(days=1), 0)))]


def suggestion_of(conn, day_iso: str) -> int | None:
    """The first A+ suggestion of a London day, or None."""
    roots = suggestion_roots(conn, day_iso)
    return roots[0] if roots else None


def suggestion_row(a: dict, order: dict | None, late: bool) -> dict:
    """The suggestion-log row of an A+ order alert (order None) or of a guard skip (order: the pinned rule's order),
    on the order's own side (a sell -1, a buy 1). Prices as the feed stores them (points / 100000); expiry: the order's
    11:00 am London cancel. Its tick names the swept level (SWEEP_<pool>, from the rule's own order)."""
    d = date.fromisoformat(a["date"])
    f = a["facts"] or {}
    pool = f.get("pool") if order is None else order.get("pool")
    if order is None:
        from fractions import Fraction
        offered, reason, arm, side = 1, None, int(f["arm"]), SIDE[f["side"]]
        prices = {k: int(f[k]) / 100000.0 for k in ("entry", "stop", "target")}
        w = float(Fraction(str(f.get("size") or "1")))
    else:
        offered, arm, side = 0, int(order["arm"]), SIDE[order["side"]]
        reason = f"Not placed by the guard: {f.get('rule') or f.get('action') or 'guard'}"
        prices, w = {"entry": None, "stop": None, "target": None}, 0.0
    return {"key": f"lead:{record.RULE_ID}:{arm}:{side}", "source": "lead", "rule_id": record.RULE_ID,
            "code_sha256": pins.CODE_SHA256, "offered": offered, "reason": reason, "placed_ts": arm, "side": side,
            **prices, "expiry_ts": AA.cancel_ts(d), "score": None, "tier": None, "w": w,
            "ticks": {f"SWEEP_{pool}": True} if pool else {},
            "record_line": record.record_line(), "late": 1 if late else 0}


def status_line(r: dict) -> str:
    """One line for `python -m app aplus --once`."""
    parts = [f"A+ step: {r.get('status')}"]
    if r.get("T") is not None:
        parts.append(f"prices to {datetime.fromtimestamp(int(r['T']), timezone.utc):%Y-%m-%d %H:%M} UTC")
    if r.get("new") is not None:
        parts.append(f"{len(r['new'])} new alerts, {r.get('updates', 0)} updates")
    parts.append(f"{len(r.get('queued') or [])} queued for the phone")
    if r.get("message"):
        parts.append(str(r["message"])[:200])
    return ", ".join(parts)
