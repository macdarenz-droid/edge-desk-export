"""Configuration: limits and sizes from config/app.toml, secrets from the environment.

Nothing secret is ever read from a file in the repo. `load()` validates every value and fails
loudly on anything unknown or out of range, so a typo cannot silently loosen a limit.
"""
from __future__ import annotations

import base64
import binascii
import os
import re
import tomllib
from dataclasses import dataclass, field
from datetime import time
from pathlib import Path
from zoneinfo import ZoneInfo

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = REPO_ROOT / "config" / "app.toml"

# Environment secrets. Values are never logged, returned by the API or written to disk.
SECRET_ENV = {
    "ingest_token": "EDGE_INGEST_TOKEN",                # bearer token the MT5 bridge EA sends
    "dashboard_token": "EDGE_DASHBOARD_TOKEN",          # login for the dashboard
    "vapid_private_key": "EDGE_VAPID_PRIVATE_KEY",      # Web Push signing key (raw P-256, base64url)
    "oanda_token": "EDGE_OANDA_TOKEN",                  # the owner's OANDA practice token, for price candles only (B1)
    "export_token": "EDGE_EXPORT_TOKEN",                # GitHub fine-grained token for the private export repo (B5)
    # The picture reader's key (docs/JOURNAL_DESIGN.md §9): only in /etc/edge-desk/reader.env (root, 0600), loaded by
    # edge-desk-reader.service alone; `serve` and the other units never have it (app/photos/reader.py)
    "anthropic_key": "EDGE_ANTHROPIC_KEY",
}
# Not a secret but personal (an email address or a site), so it stays out of the repo and is never shown:
# the VAPID "sub" contact the push services can write to (RFC 8292 section 2.1).
SUBJECT_ENV = "EDGE_VAPID_SUBJECT"
MIN_TOKEN_LEN = 32
# Order of the P-256 group (SEC 2 v2, section 2.4.2): a private key is an integer in [1, n - 1].
P256_ORDER = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
# A Console API key: "sk-ant-", then letters, digits, "-" and "_" (no spaces); the installer checks the same shape
_ANTHROPIC_KEY = re.compile(r"sk-ant-[A-Za-z0-9_-]{20,250}")
_B64URL = re.compile(r"[A-Za-z0-9_-]+={0,2}")
# A subject the push services and py_vapid accept: mailto:<address> or https://<host> (no path).
_SUBJECT = re.compile(r"mailto:[^@\s]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+|https://[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+")
MAX_PUSH_TTL_S = 28 * 24 * 3600   # 4 weeks: the longest TTL the push services keep a message
MIN_PUSH_TTL_S = 60
PAPER_COST_FLOOR_PIPS = 2.0   # paper cost may not go below the research pass case
# A10 storage ceilings (only the owner raises them): budget at most 5 GB, free floor at least 3 GB, 7 daily and 4 weekly
STORAGE_BUDGET_CEILING_GB = 5.0
STORAGE_FREE_FLOOR_MIN_GB = 3.0
BACKUP_DAILY_MAX = 7
BACKUP_WEEKLY_MAX = 4
# B1 feed limits (coordinator ruling 5, 16 Oct 2026: at most 1 request every 2 s, Retry-After honoured, stop after
# 3 failures; card B1: the first 403 or 429 blocks the host for 24 h; first start backfills 120 days).
FEED_MIN_GAP_S = 2.0
FEED_MAX_FAILURES = 3
FEED_MIN_BLOCK_HOURS = 24
FEED_MIN_BACKFILL_DAYS = 120
FEED_MIN_MARKER_DELAY_S = 30      # red team 17 Oct, item 8: a server clock a little ahead cannot claim a minute
# B5: the export goes to a separate private repo only, never this research repo (blueprint "Daily export").
RESEARCH_REPO_NAMES = ("forex-signal",)
# News (app/news): EUR and USD from the MT5 terminal's own calendar (edge-calendar/2). ForexFactory is not a source:
# its terms forbid copying its calendar without the written consent of its owner (Fair Economy, Inc.).
NEWS_SOURCES = ("mt5",)
NEWS_CURRENCIES = ("EUR", "USD")
NEWS_IMPACTS = ("high", "medium")
NEWS_MIN_BEFORE_MIN = 10        # the push TTL of a news alert is 10 min (notify/push.py KIND_TTL_S)
NEWS_MAX_BEFORE_MIN = 120
NEWS_MIN_KEEP_DAYS = 7
NEWS_MAX_KEEP_DAYS = 30
# Headlines (app/news/headlines.py; HEADLINES.md): the Federal Reserve's and the ECB's own feeds only. Neither documents
# a rate limit (the ECB's robots.txt asks Crawl-delay 5); the floors are far under it, and 10 s between requests to one
# host is a code constant (headlines.HOST_GAP_S).
HEADLINE_SOURCES = ("fed_policy", "fed_speeches", "ecb_press")
HEADLINES_MIN_POLL_S = 300
HEADLINES_MAX_POLL_S = 3600
HEADLINES_MIN_WINDOW_POLL_S = 30
HEADLINES_MAX_WINDOW_POLL_S = 300
HEADLINES_MIN_KEEP_DAYS = 7
HEADLINES_MAX_KEEP_DAYS = 30
# The A+ (app/aplus, docs/APLUS_DESIGN.md section 10; the A22 pick since 30 Oct 2026): EUR/USD only (another pair
# would also change the feed's allow-list), on the research's owner-cost quotes only. Paper only: nothing here sizes a
# real order.
APLUS_PAIRS = ("EUR_USD",)
APLUS_QUOTES = ("owner",)
# Where the A+ step runs (design D5): inside the method worker ("method"), or alone in its own unit ("own":
# `python -m app aplus`, the fallback if the method unit's memory peak ever passes 450 MB).
APLUS_RUN_IN = ("method", "own")
FUNDED_PRODUCTS = ("", "stellar2", "stellar1")
FUNDED_STAGES = ("", "phase1", "phase2", "funded")


class ConfigError(ValueError):
    pass


def _hhmm(value: str, key: str) -> time:
    try:
        hh, mm = value.split(":")
        return time(int(hh), int(mm))
    except (ValueError, AttributeError) as exc:
        raise ConfigError(f"{key}: expected HH:MM, got {value!r}") from exc


@dataclass(frozen=True)
class AppSection:
    name: str
    host: str
    port: int
    db_path: Path
    display_tz: ZoneInfo


@dataclass(frozen=True)
class AccountSection:
    alias: str
    currency: str


@dataclass(frozen=True)
class InstrumentSection:
    symbol: str
    broker_symbols: tuple[str, ...]
    pip_size: float


@dataclass(frozen=True)
class DaySection:
    boundary_tz: ZoneInfo
    boundary_hour: int
    london_open: time
    ny_open: time


@dataclass(frozen=True)
class RiskSection:
    risk_pct_per_trade: float
    max_losses_per_day: int
    trades_after_first_win: int
    loss_after_win_ends_day: bool
    breakeven_band_r: float


@dataclass(frozen=True)
class StreakSection:
    enabled: bool
    green_days_to_start: int
    target_min_r: float
    target_max_r: float
    floor_fraction: float


@dataclass(frozen=True)
class ManagementSection:
    breakeven_from_r: float
    breakeven_to_r: float
    take_or_trail_r: float
    trail_stop_r: float


@dataclass(frozen=True)
class PlannerSection:
    mode: str
    strategy: str
    order_expiry_london: time
    plan_time_london: time


@dataclass(frozen=True)
class AnalyticsSection:
    min_trades: int


@dataclass(frozen=True)
class PaperSection:
    balance: float
    cost_pips: float
    cost_pips_info: float = 1.6
    financing_pips_night: float = 1.0
    financing_wednesday_nights: int = 3


@dataclass(frozen=True)
class FundedSection:
    """Funded-account limits typed by the owner (A5). None = not set."""
    enabled: bool = False
    initial_balance: float | None = None
    daily_loss_pct: float | None = None
    max_loss_pct: float | None = None
    risk_cap_pct: float | None = None
    reset: str = "server_midnight"
    alert_at: tuple[float, ...] = (0.5, 0.8)
    product: str = ""                    # "stellar2", "stellar1" or "" (deploy/install/render_config.py)
    stage: str = ""                      # "phase1", "phase2", "funded" or ""
    target_pct: float | None = None      # profit target of the phase, % of the initial balance (none funded)
    min_days: float | None = None        # FundedNext's minimum trading days of the phase (none funded)

    @property
    def is_set(self) -> bool:
        """The balance and both loss limits. The risk cap is FundedNext's rule for the FundedNext Account stage only
        (none in the challenge phases), so it may stay "" (deploy/install/render_config.py)."""
        return None not in (self.initial_balance, self.daily_loss_pct, self.max_loss_pct)


@dataclass(frozen=True)
class StorageSection:
    """A10: disk budget and backups. Ceilings pinned by tests/test_storage.py."""
    disk_budget_gb: float = 5.0
    free_floor_gb: float = 3.0
    backup_daily_keep: int = 7
    backup_weekly_keep: int = 4


@dataclass(frozen=True)
class FeedSection:
    """B1: OANDA practice EUR/USD M1 bid/ask candles. Limits pinned by tests/test_feed.py."""
    enabled: bool = False
    min_gap_s: float = 2.0
    max_failures: int = 3
    block_hours: int = 24
    cooldown_s: int = 300
    backfill_days: int = 120
    marker_delay_s: int = 30
    poll_s: int = 20
    timeout_s: int = 20


@dataclass(frozen=True)
class ExportSection:
    """B5: the daily export to the owner's separate private export repo (never this research repo)."""
    enabled: bool = False
    repo: str = ""
    branch: str = "main"
    after_ny: time = time(17, 5)


@dataclass(frozen=True)
class NewsSection:
    """EUR and USD news (app/news). Ceilings pinned by tests/test_news.py."""
    enabled: bool = True
    source: str = "mt5"
    currencies: tuple[str, ...] = ("EUR", "USD")
    show_impacts: tuple[str, ...] = ("high", "medium")
    alert_impacts: tuple[str, ...] = ("high",)
    alert_before_min: int = 15
    upcoming_hours: int = 48
    stale_after_min: int = 30
    keep_days: int = 14
    show_record: bool = True          # the 2016-21 move record, built on this server (app/news/moverecord.py)
    result_alerts: bool = True        # one alert per currency and release minute when a number is out


@dataclass(frozen=True)
class HeadlinesSection:
    """Fed and ECB headlines (app/news/headlines.py). Ceilings pinned by tests/test_headlines.py."""
    enabled: bool = True
    sources: tuple[str, ...] = ("fed_policy", "fed_speeches", "ecb_press")
    poll_s: int = 300
    speeches_poll_s: int = 900
    window_poll_s: int = 30
    push: bool = True
    show_hours: int = 72
    keep_days: int = 14
    stale_after_min: int = 30
    timeout_s: int = 20


@dataclass(frozen=True)
class AplusSection:
    """The A+, paper only (app/aplus). Its size comes from [paper] balance and [risk] risk_pct_per_trade."""
    enabled: bool = True
    pairs: tuple[str, ...] = ("EUR_USD",)
    quotes: str = "owner"
    late_after_min: int = 5
    stale_after_min: int = 10
    child_timeout_s: int = 60
    run_in: str = "method"


@dataclass(frozen=True)
class PhotosSection:
    """The photo journal (app/photos, docs/JOURNAL_DESIGN.md §9). Ceilings pinned by tests/test_photos.py and
    tests/test_photo_reader_store.py; only the owner raises them. Off until he switches it on; the reader stays "off"
    until it is evaluated (§11.3): "local" reads the lines only (he taps each one), "claude" adds the paid read.
    `paid_reader` names who answers the paid read (D6); every attempt is priced from prices_per_mtok, and one not listed
    there at the highest listed rate (D12)."""
    enabled: bool = False
    max_bytes: int = 6 * 1024 * 1024
    min_side_px: int = 600
    max_side_px: int = 4096
    max_per_day: int = 40
    max_per_minute: int = 6
    keep_days: int = 180
    unconfirmed_keep_days: int = 7
    folder_cap_mb: float = 1024
    reader: str = "off"
    history_paid_read: bool = True
    paid_reader: str = "claude-opus-5-5"
    effort: str = "low"
    monthly_usd_cap: float = 10.0
    prices_per_mtok: tuple = (("claude-opus-5-5", 4.0, 20.0), ("claude-opus-5", 5.0, 25.0),
                              ("claude-opus-4-8", 5.0, 25.0))

    def price(self, name: str | None) -> tuple[float, float]:
        """USD per million tokens (input, output) for what answered; one not listed at the highest listed rates."""
        for n, rate_in, rate_out in self.prices_per_mtok:
            if n == name:
                return rate_in, rate_out
        return (max(r[1] for r in self.prices_per_mtok), max(r[2] for r in self.prices_per_mtok))


PHOTOS_MAX_BYTES = 8 * 1024 * 1024
PHOTOS_MAX_SIDE_PX = 4096
PHOTOS_MAX_PER_DAY = 100
PHOTOS_MAX_KEEP_DAYS = 730
PHOTOS_MAX_UNCONFIRMED_DAYS = 30
PHOTOS_MAX_FOLDER_MB = 2048
PHOTOS_READERS = ("off", "local", "claude")
PHOTOS_EFFORTS = ("low", "medium", "high")
PHOTOS_MAX_USD_CAP = 50.0                  # a month's paid reads (the owner also sets a Console spend limit)
PHOTOS_MAX_PRICE_IN, PHOTOS_MAX_PRICE_OUT = 100.0, 500.0     # USD per million tokens: a typo cannot price at 1000x
_PRICE_NAME = re.compile(r"[a-z0-9][a-z0-9.-]{0,63}")


@dataclass(frozen=True)
class BridgeSection:
    contract: str
    stale_after_s: int
    offline_after_s: int
    silent_alert_after_s: int
    max_payload_bytes: int
    max_clock_skew_s: int
    broker_clock: str


@dataclass(frozen=True)
class NotifySection:
    min_interval_s: int
    max_attempts: int
    daily_summary_ny: time
    alert_no_trade_day: bool
    management_alerts: bool
    push_ttl_s: int              # how long a push service keeps an alert for a phone that is offline
    push_ttl_urgent_s: int       # the same for priority 4 and 5


@dataclass(frozen=True)
class Secrets:
    """Secret values from the environment, plus the personal VAPID subject. repr() never shows them."""

    ingest_token: str | None = field(default=None, repr=False)
    dashboard_token: str | None = field(default=None, repr=False)
    vapid_private_key: str | None = field(default=None, repr=False)
    oanda_token: str | None = field(default=None, repr=False)
    export_token: str | None = field(default=None, repr=False)
    vapid_subject: str | None = field(default=None, repr=False)
    anthropic_key: str | None = field(default=None, repr=False)

    def present(self) -> dict[str, bool]:
        return {name: bool(getattr(self, name)) for name in SECRET_ENV}

    @property
    def push_configured(self) -> bool:
        """Web Push can sign alerts only with both the private key and the subject."""
        return bool(self.vapid_private_key and self.vapid_subject)


@dataclass(frozen=True)
class Config:
    app: AppSection
    account: AccountSection
    instrument: InstrumentSection
    day: DaySection
    risk: RiskSection
    streak: StreakSection
    management: ManagementSection
    planner: PlannerSection
    analytics: AnalyticsSection
    paper: PaperSection
    bridge: BridgeSection
    notify: NotifySection
    funded: FundedSection = field(default_factory=FundedSection)
    storage: StorageSection = field(default_factory=StorageSection)
    feed: FeedSection = field(default_factory=FeedSection)
    export: ExportSection = field(default_factory=ExportSection)
    news: NewsSection = field(default_factory=NewsSection)
    headlines: HeadlinesSection = field(default_factory=HeadlinesSection)
    aplus: AplusSection = field(default_factory=AplusSection)
    secrets: Secrets = field(default_factory=Secrets, repr=False)
    photos: PhotosSection = field(default_factory=PhotosSection)

    def is_eurusd(self, symbol: str) -> bool:
        return symbol in self.instrument.broker_symbols


_SECTIONS = {
    "app": {"name", "host", "port", "db_path", "display_tz"},
    "account": {"alias", "currency"},
    "instrument": {"symbol", "broker_symbols", "pip_size"},
    "day": {"boundary_tz", "boundary_hour", "london_open", "ny_open"},
    "risk": {"risk_pct_per_trade", "max_losses_per_day", "trades_after_first_win",
             "loss_after_win_ends_day", "breakeven_band_r"},
    "streak": {"enabled", "green_days_to_start", "target_min_r", "target_max_r", "floor_fraction"},
    "management": {"breakeven_from_r", "breakeven_to_r", "take_or_trail_r", "trail_stop_r"},
    "planner": {"mode", "strategy", "order_expiry_london", "plan_time_london"},
    "analytics": {"min_trades"},
    "paper": {"balance", "cost_pips", "cost_pips_info", "financing_pips_night", "financing_wednesday_nights"},
    "bridge": {"contract", "stale_after_s", "offline_after_s", "silent_alert_after_s",
               "max_payload_bytes", "max_clock_skew_s", "broker_clock"},
    "notify": {"min_interval_s", "max_attempts", "daily_summary_ny", "alert_no_trade_day", "management_alerts",
               "push_ttl_s", "push_ttl_urgent_s"},
    "funded": {"enabled", "initial_balance", "daily_loss_pct", "max_loss_pct", "risk_cap_pct", "reset", "alert_at",
               "product", "stage", "target_pct", "min_days"},
    "storage": {"disk_budget_gb", "free_floor_gb", "backup_daily_keep", "backup_weekly_keep"},
    "feed": {"enabled", "min_gap_s", "max_failures", "block_hours", "cooldown_s", "backfill_days", "marker_delay_s",
             "poll_s", "timeout_s"},
    "export": {"enabled", "repo", "branch", "after_ny"},
    "news": {"enabled", "source", "currencies", "show_impacts", "alert_impacts", "alert_before_min", "upcoming_hours",
             "stale_after_min", "keep_days", "show_record", "result_alerts"},
    "headlines": {"enabled", "sources", "poll_s", "speeches_poll_s", "window_poll_s", "push", "show_hours",
                  "keep_days", "stale_after_min", "timeout_s"},
    "aplus": {"enabled", "pairs", "quotes", "late_after_min", "stale_after_min", "child_timeout_s", "run_in"},
    # "photos": added below from _TYPES["photos"] (its keys are the PhotosSection fields)
}


# Value types per key. "int" and "num" refuse booleans (in Python True is an int, so `risk_pct_per_trade = true`
# would load as 1.0%); booleans must be real booleans (`enabled = "false"` would load as True).
_NUM, _INT, _OPT = "num", "int", "optional number"
_TYPES = {
    "app": {"name": str, "host": str, "port": _INT, "db_path": str, "display_tz": str},
    "account": {"alias": str, "currency": str},
    "instrument": {"symbol": str, "broker_symbols": list, "pip_size": _NUM},
    "day": {"boundary_tz": str, "boundary_hour": _INT, "london_open": str, "ny_open": str},
    "risk": {"risk_pct_per_trade": _NUM, "max_losses_per_day": _INT, "trades_after_first_win": _INT,
             "loss_after_win_ends_day": bool, "breakeven_band_r": _NUM},
    "streak": {"enabled": bool, "green_days_to_start": _INT, "target_min_r": _NUM, "target_max_r": _NUM,
               "floor_fraction": _NUM},
    "management": {"breakeven_from_r": _NUM, "breakeven_to_r": _NUM, "take_or_trail_r": _NUM, "trail_stop_r": _NUM},
    "planner": {"mode": str, "strategy": str, "order_expiry_london": str, "plan_time_london": str},
    "analytics": {"min_trades": _INT},
    "paper": {"balance": _NUM, "cost_pips": _NUM, "cost_pips_info": _NUM, "financing_pips_night": _NUM,
              "financing_wednesday_nights": _INT},
    "bridge": {"contract": str, "stale_after_s": _INT, "offline_after_s": _INT, "silent_alert_after_s": _INT,
               "max_payload_bytes": _INT, "max_clock_skew_s": _INT, "broker_clock": str},
    "notify": {"min_interval_s": _INT, "max_attempts": _INT, "daily_summary_ny": str,
               "alert_no_trade_day": bool, "management_alerts": bool, "push_ttl_s": _INT, "push_ttl_urgent_s": _INT},
    "funded": {"enabled": bool, "initial_balance": _OPT, "daily_loss_pct": _OPT, "max_loss_pct": _OPT,
               "risk_cap_pct": _OPT, "reset": str, "alert_at": list, "product": str, "stage": str,
               "target_pct": _OPT, "min_days": _OPT},
    "storage": {"disk_budget_gb": _NUM, "free_floor_gb": _NUM, "backup_daily_keep": _INT, "backup_weekly_keep": _INT},
    "feed": {"enabled": bool, "min_gap_s": _NUM, "max_failures": _INT, "block_hours": _INT, "cooldown_s": _INT,
             "backfill_days": _INT, "marker_delay_s": _INT, "poll_s": _INT, "timeout_s": _INT},
    "export": {"enabled": bool, "repo": str, "branch": str, "after_ny": str},
    "news": {"enabled": bool, "source": str, "currencies": list, "show_impacts": list, "alert_impacts": list,
             "alert_before_min": _INT, "upcoming_hours": _INT, "stale_after_min": _INT, "keep_days": _INT,
             "show_record": bool, "result_alerts": bool},
    "headlines": {"enabled": bool, "sources": list, "poll_s": _INT, "speeches_poll_s": _INT, "window_poll_s": _INT,
                  "push": bool, "show_hours": _INT, "keep_days": _INT, "stale_after_min": _INT, "timeout_s": _INT},
    "aplus": {"enabled": bool, "pairs": list, "quotes": str, "late_after_min": _INT, "stale_after_min": _INT,
              "child_timeout_s": _INT, "run_in": str},
    "photos": {"enabled": bool, "max_bytes": _INT, "min_side_px": _INT, "max_side_px": _INT, "max_per_day": _INT,
               "max_per_minute": _INT, "keep_days": _INT, "unconfirmed_keep_days": _INT, "folder_cap_mb": _INT,
               "reader": str, "history_paid_read": bool, "paid_reader": str, "effort": str,
               "monthly_usd_cap": _NUM, "prices_per_mtok": dict},
}
_SECTIONS["photos"] = set(_TYPES["photos"])        # one key per PhotosSection field (docs/JOURNAL_DESIGN.md §9)


def _type_ok(value, kind) -> bool:
    if kind == _INT:
        return isinstance(value, int) and not isinstance(value, bool)
    if kind == _NUM:
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if kind == _OPT:      # a number, or "" for not set
        return value == "" or (isinstance(value, (int, float)) and not isinstance(value, bool))
    return isinstance(value, kind)


def _check_types(raw: dict) -> None:
    for name, keys in _TYPES.items():
        for key, kind in keys.items():
            if not _type_ok(raw[name][key], kind):
                want = {_INT: "a whole number", _NUM: "a number", bool: "true or false", str: "text",
                        list: "a list", dict: "a table", _OPT: 'a number or "" (not set)'}[kind]
                raise ConfigError(f"{name}.{key} must be {want}, got {raw[name][key]!r}")


def _check_keys(raw: dict) -> None:
    unknown = set(raw) - set(_SECTIONS)
    missing = set(_SECTIONS) - set(raw)
    if unknown or missing:
        raise ConfigError(f"sections: unknown {sorted(unknown)}, missing {sorted(missing)}")
    for name, keys in _SECTIONS.items():
        got = set(raw[name])
        if got != keys:
            raise ConfigError(f"[{name}]: unknown {sorted(got - keys)}, missing {sorted(keys - got)}")


def _require(cond: bool, msg: str) -> None:
    if not cond:
        raise ConfigError(msg)


def _alias_ok(alias: str) -> bool:
    # An alias is a short label. All-digit strings are refused so an account number cannot be used.
    return (isinstance(alias, str) and 1 <= len(alias) <= 32 and not alias.isdigit()
            and all(c.isalnum() or c in "-_" for c in alias))


def vapid_key_bytes(value: str) -> bytes:
    """The raw 32-byte P-256 private key from base64url (padding optional), or ValueError. The message
    never contains the value."""
    if not isinstance(value, str) or not _B64URL.fullmatch(value) or len(value.rstrip("=")) != 43:
        raise ValueError("must be a raw P-256 private key in base64url (43 characters)")
    try:
        raw = base64.urlsafe_b64decode(value.rstrip("=") + "=")
    except (binascii.Error, ValueError):
        raise ValueError("must be a raw P-256 private key in base64url (43 characters)") from None
    if len(raw) != 32 or not 0 < int.from_bytes(raw, "big") < P256_ORDER:
        raise ValueError("is not a valid P-256 private key")
    return raw


def _vapid_key(value: str) -> str:
    try:
        raw = vapid_key_bytes(value)
    except ValueError as exc:
        raise ConfigError(f"{SECRET_ENV['vapid_private_key']} {exc} (make one with: python3 -m app vapid-keygen"
                          " --out FILE)") from None
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()      # one spelling: no padding


def load_secrets(env: dict[str, str] | None = None) -> Secrets:
    env = os.environ if env is None else env
    values = {}
    for name, var in SECRET_ENV.items():
        val = (env.get(var) or "").strip() or None
        if val is not None and name in ("ingest_token", "dashboard_token") and len(val) < MIN_TOKEN_LEN:
            raise ConfigError(f"{var} must be at least {MIN_TOKEN_LEN} characters")
        if val is not None and name == "vapid_private_key":
            val = _vapid_key(val)
        if val is not None and name in ("oanda_token", "export_token") and (len(val) < 20 or any(c.isspace() for c in val)):
            raise ConfigError(f"{var} does not look like a token (20 or more characters, no spaces)")
        if val is not None and name == "anthropic_key" and not _ANTHROPIC_KEY.fullmatch(val):
            raise ConfigError(f"{var} does not look like a Console key (sk-ant-..., letters, digits, - and _ only)")
        values[name] = val
    if values["ingest_token"] and values["ingest_token"] == values["dashboard_token"]:
        # The ingest token sits in a plain file on the VPS; the same value would open the dashboard too.
        raise ConfigError("EDGE_INGEST_TOKEN and EDGE_DASHBOARD_TOKEN must be different")
    subject = (env.get(SUBJECT_ENV) or "").strip() or None
    if subject is not None and not _SUBJECT.fullmatch(subject):
        raise ConfigError(f"{SUBJECT_ENV} must be a mailto: link with an email address, or the https address of a"
                          " site (no path)")
    return Secrets(**values, vapid_subject=subject)


def _photo_prices(table: dict) -> tuple:
    """[photos] prices_per_mtok: {name = [input, output]} in USD per million tokens, each above 0 and under its
    ceiling, so no attempt can be priced at nothing (the monthly cap counts every attempt, D12)."""
    _require(1 <= len(table) <= 10, "photos.prices_per_mtok: 1 to 10 entries")
    out = []
    for name, rates in table.items():
        _require(isinstance(name, str) and bool(_PRICE_NAME.fullmatch(name)), f"photos.prices_per_mtok: bad name {name!r}")
        _require(isinstance(rates, list) and len(rates) == 2 and all(_type_ok(r, _NUM) for r in rates),
                 f"photos.prices_per_mtok.{name}: [input, output] numbers")
        _require(0 < rates[0] <= PHOTOS_MAX_PRICE_IN and 0 < rates[1] <= PHOTOS_MAX_PRICE_OUT,
                 f"photos.prices_per_mtok.{name}: above 0, at most {PHOTOS_MAX_PRICE_IN:g} and"
                 f" {PHOTOS_MAX_PRICE_OUT:g}")
        out.append((name, float(rates[0]), float(rates[1])))
    return tuple(out)


def load(path: Path | str | None = None, env: dict[str, str] | None = None) -> Config:
    path = Path(path) if path else DEFAULT_CONFIG_PATH
    with open(path, "rb") as fh:
        raw = tomllib.load(fh)
    _check_keys(raw)
    _check_types(raw)
    env_map = os.environ if env is None else env

    a = raw["app"]
    db_path = Path(env_map.get("EDGE_DB_PATH") or a["db_path"])
    if not db_path.is_absolute():
        db_path = REPO_ROOT / db_path
    _require(isinstance(a["port"], int) and 1 <= a["port"] <= 65535, "app.port out of range")
    app = AppSection(a["name"], a["host"], a["port"], db_path, ZoneInfo(a["display_tz"]))

    acc = raw["account"]
    _require(_alias_ok(acc["alias"]), "account.alias must be a short label (letters, digits, - or _), not a number")
    account = AccountSection(acc["alias"], acc["currency"])

    ins = raw["instrument"]
    _require(ins["symbol"] == "EURUSD", "instrument.symbol: the app is EUR/USD only")
    _require(all(isinstance(s, str) and s.upper().startswith("EURUSD") for s in ins["broker_symbols"])
             and ins["broker_symbols"], "instrument.broker_symbols must all be EUR/USD names")
    _require(ins["pip_size"] == 0.0001, "instrument.pip_size for EUR/USD is 0.0001")
    instrument = InstrumentSection(ins["symbol"], tuple(ins["broker_symbols"]), ins["pip_size"])

    d = raw["day"]
    _require(isinstance(d["boundary_hour"], int) and 0 <= d["boundary_hour"] <= 23, "day.boundary_hour")
    day = DaySection(ZoneInfo(d["boundary_tz"]), d["boundary_hour"],
                     _hhmm(d["london_open"], "day.london_open"), _hhmm(d["ny_open"], "day.ny_open"))

    r = raw["risk"]
    _require(isinstance(r["risk_pct_per_trade"], (int, float)) and 0 < r["risk_pct_per_trade"] <= 5,
             "risk.risk_pct_per_trade must be above 0 and at most 5")
    _require(isinstance(r["max_losses_per_day"], int) and r["max_losses_per_day"] >= 1, "risk.max_losses_per_day >= 1")
    _require(isinstance(r["trades_after_first_win"], int) and r["trades_after_first_win"] >= 0,
             "risk.trades_after_first_win >= 0")
    _require(isinstance(r["loss_after_win_ends_day"], bool), "risk.loss_after_win_ends_day must be true or false")
    _require(isinstance(r["breakeven_band_r"], (int, float)) and 0 <= r["breakeven_band_r"] < 1,
             "risk.breakeven_band_r must be in [0, 1)")
    risk = RiskSection(float(r["risk_pct_per_trade"]), r["max_losses_per_day"], r["trades_after_first_win"],
                       r["loss_after_win_ends_day"], float(r["breakeven_band_r"]))

    s = raw["streak"]
    _require(isinstance(s["green_days_to_start"], int) and s["green_days_to_start"] >= 1, "streak.green_days_to_start")
    _require(0 < s["target_min_r"] <= s["target_max_r"], "streak targets: 0 < min <= max")
    _require(0 < s["floor_fraction"] < 1, "streak.floor_fraction must be in (0, 1)")
    streak = StreakSection(bool(s["enabled"]), s["green_days_to_start"], float(s["target_min_r"]),
                           float(s["target_max_r"]), float(s["floor_fraction"]))

    m = raw["management"]
    _require(0 < m["breakeven_from_r"] <= m["breakeven_to_r"] < m["take_or_trail_r"], "management R levels out of order")
    _require(0 < m["trail_stop_r"] < m["take_or_trail_r"], "management.trail_stop_r")
    management = ManagementSection(float(m["breakeven_from_r"]), float(m["breakeven_to_r"]),
                                   float(m["take_or_trail_r"]), float(m["trail_stop_r"]))

    p = raw["planner"]
    _require(p["mode"] == "paper", "planner.mode: only \"paper\" exists")
    planner = PlannerSection(p["mode"], p["strategy"], _hhmm(p["order_expiry_london"], "planner.order_expiry_london"),
                             _hhmm(p["plan_time_london"], "planner.plan_time_london"))

    an = raw["analytics"]
    _require(isinstance(an["min_trades"], int) and an["min_trades"] >= 30, "analytics.min_trades must be at least 30")
    analytics = AnalyticsSection(an["min_trades"])

    pa = raw["paper"]
    _require(pa["balance"] > 0, "paper.balance must be positive")
    # 2.0 pips is the pass case until the owner has an account with a measured lower cost (CLAUDE.md).
    _require(PAPER_COST_FLOOR_PIPS <= pa["cost_pips"] <= 10,
             f"paper.cost_pips must be from {PAPER_COST_FLOOR_PIPS} to 10")
    _require(0 < pa["cost_pips_info"] <= pa["cost_pips"], "paper.cost_pips_info must be above 0 and at most cost_pips")
    _require(0 <= pa["financing_pips_night"] <= 10, "paper.financing_pips_night must be in [0, 10]")
    _require(1 <= pa["financing_wednesday_nights"] <= 3, "paper.financing_wednesday_nights: 1 to 3")
    paper = PaperSection(float(pa["balance"]), float(pa["cost_pips"]), float(pa["cost_pips_info"]),
                         float(pa["financing_pips_night"]), pa["financing_wednesday_nights"])

    b = raw["bridge"]
    _require(b["contract"] == "edge-bridge/1", "bridge.contract: this app speaks edge-bridge/1")
    _require(0 < b["stale_after_s"] < b["offline_after_s"] <= b["silent_alert_after_s"], "bridge timings out of order")
    _require(1024 <= b["max_payload_bytes"] <= 4 * 1024 * 1024, "bridge.max_payload_bytes")
    _require(b["broker_clock"] in ("ny_close", "measured"), "bridge.broker_clock must be ny_close or measured")
    bridge = BridgeSection(b["contract"], b["stale_after_s"], b["offline_after_s"], b["silent_alert_after_s"],
                           b["max_payload_bytes"], b["max_clock_skew_s"], b["broker_clock"])

    n = raw["notify"]
    _require(n["min_interval_s"] >= 5, "notify.min_interval_s must be at least 5")
    _require(1 <= n["max_attempts"] <= 3, "notify.max_attempts: 1 to 3")
    for key in ("push_ttl_s", "push_ttl_urgent_s"):
        _require(MIN_PUSH_TTL_S <= n[key] <= MAX_PUSH_TTL_S,
                 f"notify.{key} must be from {MIN_PUSH_TTL_S} to {MAX_PUSH_TTL_S} seconds")
    notify = NotifySection(n["min_interval_s"], n["max_attempts"],
                           _hhmm(n["daily_summary_ny"], "notify.daily_summary_ny"),
                           bool(n["alert_no_trade_day"]), bool(n["management_alerts"]),
                           n["push_ttl_s"], n["push_ttl_urgent_s"])

    fu = raw["funded"]

    def opt(key: str, lo: float, hi: float) -> float | None:
        v = fu[key]
        if v == "":
            return None
        _require(lo < v <= hi, f"funded.{key} must be above {lo} and at most {hi}, or \"\" for not set")
        return float(v)

    _require(fu["reset"] == "server_midnight", "funded.reset: only \"server_midnight\" exists")
    al = fu["alert_at"]
    _require(len(al) == 2 and all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in al)
             and 0 < al[0] < al[1] < 1, "funded.alert_at must be two fractions, rising, between 0 and 1")
    _require(fu["product"] in FUNDED_PRODUCTS, 'funded.product: "stellar2", "stellar1" or ""')
    _require(fu["stage"] in FUNDED_STAGES, 'funded.stage: "phase1", "phase2", "funded" or ""')
    _require(not (fu["product"] == "stellar1" and fu["stage"] == "phase2"), "funded.stage: Stellar 1-Step has no phase 2")
    min_days = opt("min_days", 0, 30)
    _require(min_days is None or min_days == int(min_days), "funded.min_days: a whole number of days")
    funded = FundedSection(bool(fu["enabled"]), opt("initial_balance", 0, 1e9), opt("daily_loss_pct", 0, 50),
                           opt("max_loss_pct", 0, 50), opt("risk_cap_pct", 0, 50), fu["reset"],
                           tuple(float(x) for x in al), fu["product"], fu["stage"], opt("target_pct", 0, 50), min_days)

    st = raw["storage"]
    _require(0 < st["disk_budget_gb"] <= STORAGE_BUDGET_CEILING_GB,
             f"storage.disk_budget_gb must be above 0 and at most {STORAGE_BUDGET_CEILING_GB}")
    _require(STORAGE_FREE_FLOOR_MIN_GB <= st["free_floor_gb"] <= 1000,
             f"storage.free_floor_gb must be at least {STORAGE_FREE_FLOOR_MIN_GB}")
    _require(1 <= st["backup_daily_keep"] <= BACKUP_DAILY_MAX, f"storage.backup_daily_keep: 1 to {BACKUP_DAILY_MAX}")
    _require(0 <= st["backup_weekly_keep"] <= BACKUP_WEEKLY_MAX, f"storage.backup_weekly_keep: 0 to {BACKUP_WEEKLY_MAX}")
    storage = StorageSection(float(st["disk_budget_gb"]), float(st["free_floor_gb"]), st["backup_daily_keep"],
                             st["backup_weekly_keep"])

    fe = raw["feed"]
    _require(FEED_MIN_GAP_S <= fe["min_gap_s"] <= 60, f"feed.min_gap_s must be from {FEED_MIN_GAP_S} to 60")
    _require(1 <= fe["max_failures"] <= FEED_MAX_FAILURES, f"feed.max_failures: 1 to {FEED_MAX_FAILURES}")
    _require(FEED_MIN_BLOCK_HOURS <= fe["block_hours"] <= 24 * 7, f"feed.block_hours: {FEED_MIN_BLOCK_HOURS} to 168")
    _require(60 <= fe["cooldown_s"] <= 86400, "feed.cooldown_s: 60 to 86400")
    _require(FEED_MIN_BACKFILL_DAYS <= fe["backfill_days"] <= 400, f"feed.backfill_days: {FEED_MIN_BACKFILL_DAYS} to 400")
    _require(FEED_MIN_MARKER_DELAY_S <= fe["marker_delay_s"] <= 600,
             f"feed.marker_delay_s: {FEED_MIN_MARKER_DELAY_S} to 600")
    _require(fe["min_gap_s"] <= fe["poll_s"] <= 600, "feed.poll_s: from feed.min_gap_s to 600")
    _require(5 <= fe["timeout_s"] <= 120, "feed.timeout_s: 5 to 120")
    feed = FeedSection(bool(fe["enabled"]), float(fe["min_gap_s"]), fe["max_failures"], fe["block_hours"],
                       fe["cooldown_s"], fe["backfill_days"], fe["marker_delay_s"], fe["poll_s"], fe["timeout_s"])

    ex = raw["export"]
    repo = ex["repo"].strip()
    _require(repo == "" or re.fullmatch(r"[A-Za-z0-9-]{1,39}/[A-Za-z0-9._-]{1,100}", repo) is not None,
             "export.repo must be owner/name, or \"\" (not set)")
    _require(repo.lower().split("/")[-1] not in RESEARCH_REPO_NAMES,
             "export.repo must be the separate private export repo, never the research repo")
    _require(re.fullmatch(r"[A-Za-z0-9._/-]{1,100}", ex["branch"]) is not None, "export.branch")
    _require(not (ex["enabled"] and not repo), "export.enabled needs export.repo")
    export = ExportSection(bool(ex["enabled"]), repo, ex["branch"], _hhmm(ex["after_ny"], "export.after_ny"))

    nw = raw["news"]

    def _names(value, allowed) -> bool:
        return all(isinstance(x, str) for x in value) and len(set(value)) == len(value) and set(value) <= set(allowed)

    _require(nw["source"] in NEWS_SOURCES, 'news.source: only "mt5" (ForexFactory needs FEI\'s written consent first)')
    _require(bool(nw["currencies"]) and _names(nw["currencies"], NEWS_CURRENCIES),
             "news.currencies: one or both of EUR and USD")
    _require(bool(nw["show_impacts"]) and _names(nw["show_impacts"], NEWS_IMPACTS),
             "news.show_impacts: one or both of high and medium")
    _require(_names(nw["alert_impacts"], nw["show_impacts"]), "news.alert_impacts: only impacts that are shown")
    _require(NEWS_MIN_BEFORE_MIN <= nw["alert_before_min"] <= NEWS_MAX_BEFORE_MIN,
             f"news.alert_before_min: {NEWS_MIN_BEFORE_MIN} to {NEWS_MAX_BEFORE_MIN}")
    _require(12 <= nw["upcoming_hours"] <= 96, "news.upcoming_hours: 12 to 96")
    _require(10 <= nw["stale_after_min"] <= 180, "news.stale_after_min: 10 to 180")
    _require(NEWS_MIN_KEEP_DAYS <= nw["keep_days"] <= NEWS_MAX_KEEP_DAYS,
             f"news.keep_days: {NEWS_MIN_KEEP_DAYS} to {NEWS_MAX_KEEP_DAYS}")
    news = NewsSection(nw["enabled"], nw["source"], tuple(nw["currencies"]), tuple(nw["show_impacts"]),
                       tuple(nw["alert_impacts"]), nw["alert_before_min"], nw["upcoming_hours"], nw["stale_after_min"],
                       nw["keep_days"], nw["show_record"], nw["result_alerts"])

    hl = raw["headlines"]
    _require(_names(hl["sources"], HEADLINE_SOURCES), "headlines.sources: any of fed_policy, fed_speeches, ecb_press")
    _require(HEADLINES_MIN_POLL_S <= hl["poll_s"] <= HEADLINES_MAX_POLL_S,
             f"headlines.poll_s: {HEADLINES_MIN_POLL_S} to {HEADLINES_MAX_POLL_S}")
    _require(HEADLINES_MIN_POLL_S <= hl["speeches_poll_s"] <= HEADLINES_MAX_POLL_S,
             f"headlines.speeches_poll_s: {HEADLINES_MIN_POLL_S} to {HEADLINES_MAX_POLL_S}")
    _require(HEADLINES_MIN_WINDOW_POLL_S <= hl["window_poll_s"] <= HEADLINES_MAX_WINDOW_POLL_S,
             f"headlines.window_poll_s: {HEADLINES_MIN_WINDOW_POLL_S} to {HEADLINES_MAX_WINDOW_POLL_S}")
    _require(24 <= hl["show_hours"] <= 168, "headlines.show_hours: 24 to 168")
    _require(HEADLINES_MIN_KEEP_DAYS <= hl["keep_days"] <= HEADLINES_MAX_KEEP_DAYS,
             f"headlines.keep_days: {HEADLINES_MIN_KEEP_DAYS} to {HEADLINES_MAX_KEEP_DAYS}")
    _require(10 <= hl["stale_after_min"] <= 180, "headlines.stale_after_min: 10 to 180")
    _require(5 <= hl["timeout_s"] <= 60, "headlines.timeout_s: 5 to 60")
    headlines = HeadlinesSection(hl["enabled"], tuple(hl["sources"]), hl["poll_s"], hl["speeches_poll_s"],
                                 hl["window_poll_s"], hl["push"], hl["show_hours"], hl["keep_days"],
                                 hl["stale_after_min"], hl["timeout_s"])

    ap = raw["aplus"]
    _require(len(ap["pairs"]) >= 1 and len(set(ap["pairs"])) == len(ap["pairs"])
             and all(isinstance(x, str) and x in APLUS_PAIRS for x in ap["pairs"]),
             'aplus.pairs: only ["EUR_USD"] (GBP/USD is step 2)')
    _require(ap["quotes"] in APLUS_QUOTES, 'aplus.quotes: only "owner" (the research\'s owner-cost quotes)')
    _require(5 <= ap["late_after_min"] <= 15, "aplus.late_after_min: 5 to 15")
    _require(10 <= ap["stale_after_min"] <= 30, "aplus.stale_after_min: 10 to 30")
    _require(30 <= ap["child_timeout_s"] <= 300, "aplus.child_timeout_s: 30 to 300")
    _require(ap["run_in"] in APLUS_RUN_IN, 'aplus.run_in: "method" (inside the method worker) or "own" (its own unit)')
    aplus = AplusSection(ap["enabled"], tuple(ap["pairs"]), ap["quotes"], ap["late_after_min"], ap["stale_after_min"],
                         ap["child_timeout_s"], ap["run_in"])

    ph = raw["photos"]
    _require(1024 * 1024 <= ph["max_bytes"] <= PHOTOS_MAX_BYTES, f"photos.max_bytes: 1 MiB to {PHOTOS_MAX_BYTES}")
    _require(300 <= ph["min_side_px"] <= 1080, "photos.min_side_px: 300 to 1080")
    _require(ph["min_side_px"] < ph["max_side_px"] <= PHOTOS_MAX_SIDE_PX,
             f"photos.max_side_px: above min_side_px, at most {PHOTOS_MAX_SIDE_PX}")
    _require(1 <= ph["max_per_day"] <= PHOTOS_MAX_PER_DAY, f"photos.max_per_day: 1 to {PHOTOS_MAX_PER_DAY}")
    _require(1 <= ph["max_per_minute"] <= 10, "photos.max_per_minute: 1 to 10")
    _require(30 <= ph["keep_days"] <= PHOTOS_MAX_KEEP_DAYS, f"photos.keep_days: 30 to {PHOTOS_MAX_KEEP_DAYS}")
    _require(1 <= ph["unconfirmed_keep_days"] <= PHOTOS_MAX_UNCONFIRMED_DAYS,
             f"photos.unconfirmed_keep_days: 1 to {PHOTOS_MAX_UNCONFIRMED_DAYS}")
    _require(64 <= ph["folder_cap_mb"] <= PHOTOS_MAX_FOLDER_MB, f"photos.folder_cap_mb: 64 to {PHOTOS_MAX_FOLDER_MB}")
    _require(ph["reader"] in PHOTOS_READERS, 'photos.reader: "off", "local" or "claude"')
    _require(ph["effort"] in PHOTOS_EFFORTS, 'photos.effort: "low", "medium" or "high"')
    _require(0 < ph["monthly_usd_cap"] <= PHOTOS_MAX_USD_CAP,
             f"photos.monthly_usd_cap: above 0, at most {PHOTOS_MAX_USD_CAP:g}")
    photos = PhotosSection(**{**ph, "prices_per_mtok": _photo_prices(ph["prices_per_mtok"])})
    _require(any(n == photos.paid_reader for n, _, _ in photos.prices_per_mtok),
             "photos.paid_reader must be listed in prices_per_mtok")

    return Config(app, account, instrument, day, risk, streak, management, planner, analytics, paper,
                  bridge, notify, funded, storage, feed, export, news, headlines, aplus, load_secrets(env), photos)
