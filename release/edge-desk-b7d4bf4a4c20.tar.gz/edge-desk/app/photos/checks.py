"""The fixed checks after reading and the field states (docs/JOURNAL_DESIGN.md §5.1 step 3, §5.5 V1-V15, D4).

Two sources: the paid reading (schema mt5shot/2: what the picture means: which line is the entry, stop or target, the
side, lots and P&L) and the local pass (app/photos/local.py: the axis fit and every long line's price measured from
its height, the live tag, the chip). Each printed price is matched to a measured line within 0.5 pip (reconcile).

Field states:
- green: two independent sources agree (the reading and a measured line within 0.5 pip; the reading and the P&L
  arithmetic, V6), or the value is exact from the bridge;
- amber: one source, or a value worked out (a hidden number filled from its line or from the P&L);
- red: missing, or two sources in conflict, or a failed check (V3, V4, V5, V8 lots).
A value the reading marks hidden is discarded (V14): only a line or arithmetic fills it. Nothing here becomes a journal
fact until he confirms it (app/photos/trades.py). V9 (the picture's time) comes from app/photos/clocks.py, V12 (the
bridge) and V13 (duplicates) from app/photos/match.py and reader.py.
"""
from __future__ import annotations

import re
from datetime import datetime

from app.photos import clocks

MATCH_PIPS = 0.5          # a printed price and its measured line
V4_PIPS = 30.0            # the live tag and an open entry against the price feed's mid (plus the entry's own P&L)
V11_PIPS = 2.0            # the live tag against the feed's bid at that minute
RISK_NOTE_PCT = 1.5       # V8: risk above this share of the balance is noted (his setting is 0.6-0.7%)
TRADING_TF = ("M5", "M15")
CRITICAL = ("side", "lots", "entry", "sl", "tp")
_SYMBOL = re.compile(r"[A-Z]{6}")
_SIDE_COLOUR = {"buy": "blue", "sell": "red"}


def field(value, state: str, source: str, note: str = "") -> dict:
    return {"value": value, "state": state, "source": source, "note": note}


def base_symbol(text) -> str | None:
    m = _SYMBOL.match(str(text or "").replace(" ", "").upper())
    return m.group(0) if m else None


def _agree_text(v, l, norm=lambda x: x) -> dict:
    if v is not None and l is not None:
        if norm(v) == norm(l):
            return field(v, "green", "both")
        return field(v, "red", "both", f"the reading says {v}, the picture's label {l}")
    if v is not None:
        return field(v, "amber", "vision")
    if l is not None:
        return field(l, "amber", "local")
    return field(None, "red", "none", "missing")


def _num(node, discarded: list) -> float | None:
    """A printed number from the reading; one marked hidden is discarded (V14), even when a number came with it."""
    if not isinstance(node, dict):
        return None
    if node.get("shown") == "hidden":
        if node.get("value") is not None:
            discarded.append(node.get("value"))
        return None
    v = node.get("value")
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else None


class _Lines:
    """The measured lines and the role each one gets."""

    def __init__(self, lines, pip: float):
        self.rows = [dict(ln, role=None, trade=None) for ln in lines or ()]
        self.pip = pip

    def near(self, price: float, colours=None, free_only=True) -> dict | None:
        best = None
        for ln in self.rows:
            if free_only and ln["role"] is not None:
                continue
            if colours and ln.get("colour") not in colours:
                continue
            d = abs(ln["price"] - price)
            if d <= MATCH_PIPS * self.pip + 1e-9 and (best is None or d < abs(best["price"] - price)):
                best = ln
        return best

    def take(self, ln: dict, role: str, trade: int) -> None:
        ln["role"], ln["trade"] = role, trade

    def free(self, colours=None) -> list[dict]:
        return [ln for ln in self.rows if ln["role"] is None and (not colours or ln.get("colour") in colours)]


def _owner(level: dict, n_pos: int, n_pend: int) -> int | None:
    """The index into the trade list (positions first, then pending orders) a level belongs to, or None (unknown)."""
    ref = level.get("owner_ref") or {}
    i = ref.get("index")
    if ref.get("type") == "position" and isinstance(i, int) and 0 <= i < n_pos:
        return i
    if ref.get("type") == "pending_order" and isinstance(i, int) and 0 <= i < n_pend:
        return n_pos + i
    return None


def _side_of(kind: str) -> str:
    return "buy" if kind.startswith("buy") else "sell"


def _v5_levels(side: str, entry, sl, tp) -> tuple[bool, bool, bool]:
    """(stop on the loss side, stop moved to or past the entry, target on the profit side)."""
    sign = 1 if side == "buy" else -1
    stop_ok = sl is None or entry is None or sign * (entry - sl) > 1e-9
    moved = sl is not None and entry is not None and not stop_ok
    target_ok = tp is None or entry is None or sign * (tp - entry) > 1e-9
    return stop_ok, moved, target_ok


def reconcile(cfg, local: dict, vision: dict | None, *, picture_utc: datetime, oanda=None, balance=None,
              time: dict | None = None) -> dict:
    """The merged reading: {"trades": [{"role", "index", "fields", "first_stop_ok", "moved"}], "fields" (symbol,
    timeframe, live_bid, seen), "checks": [{"id", "ok", "note"}], "lines": [... with "role" and "trade"],
    "which_trade", "moved_stop", "status" (ok, not_switched_on, refused), "needs_taps", "red"}."""
    pip = cfg.instrument.pip_size
    checks: list[dict] = []

    def add(vid: str, ok: bool, note: str = "") -> None:
        checks.append({"id": vid, "ok": bool(ok), "note": note})

    lines = _Lines(local.get("lines"), pip)
    axis = local.get("axis") or {}
    err = axis.get("max_err_pips")
    axis_ok = bool(axis.get("ok")) and err is not None and err < 0.2
    out = {"trades": [], "fields": {}, "checks": checks, "lines": lines.rows, "which_trade": False,
           "moved_stop": False, "status": "ok", "needs_taps": vision is None, "red": [], "message": "",
           "free_levels": []}
    if time is not None:
        out["fields"]["seen"] = field(clocks.iso(time["utc"]).strftime("%Y-%m-%dT%H:%M:%SZ") if time.get("utc") else
                                      None, time.get("state", "amber"), time.get("how", ""),
                                      "; ".join(time.get("notes") or ()) + (" (about)" if time.get("about") else ""))
        add("V9", time.get("state") == "green", "; ".join(time.get("notes") or ()))
    if vision is None:
        return out
    discarded: list = []

    # V1 symbol, V2 timeframe
    v_sym = (vision.get("symbol") or {}).get("value")
    out["fields"]["symbol"] = _agree_text(v_sym, local.get("symbol"), base_symbol)
    base = base_symbol(v_sym or local.get("symbol"))
    if base == "EURUSD":
        full = str(v_sym or local.get("symbol"))
        add("V1", True, "" if full in cfg.instrument.broker_symbols or full == base else f"{full}: a suffix not in"
                                                                                         " broker_symbols")
    elif base == "GBPUSD":
        out["status"], out["message"] = "not_switched_on", "GBP/USD is not switched on yet."
        add("V1", False, "GBPUSD: not switched on yet")
    elif base is not None:
        out["status"], out["message"] = "refused", f"{base} is not read: EUR/USD only."
        add("V1", False, f"{base}: refused")
    else:
        add("V1", False, "no symbol read")
    v_tf = (vision.get("timeframe") or {}).get("value")
    out["fields"]["timeframe"] = _agree_text(v_tf, local.get("timeframe"))
    tf = v_tf or local.get("timeframe")
    add("V2", tf in TRADING_TF, "" if tf in TRADING_TF else f"{tf or 'no timeframe'}: not your trading timeframe")
    add("V3", axis_ok, "" if axis_ok else "the price axis does not fit one constant step within 0.2 pip")

    # the live price (V4 below, V11)
    v_bid = _num(vision.get("live_price_tag"), discarded)
    l_bid = (local.get("live_tag") or {}).get("price")
    if v_bid is not None and l_bid is not None:
        bid_f = (field(v_bid, "green", "both") if abs(v_bid - l_bid) <= MATCH_PIPS * pip + 1e-9
                 else field(v_bid, "red", "both", f"the measured tag is at {l_bid:.5f}"))
    elif v_bid is not None or l_bid is not None:
        bid_f = field(v_bid if v_bid is not None else l_bid, "amber", "vision" if v_bid is not None else "lines")
    else:
        bid_f = field(None, "amber", "none", "no live price read")
    out["fields"]["live_bid"] = bid_f
    bid = bid_f["value"]
    ask = _num(vision.get("ask_tag"), discarded)
    v4_ok, v4_notes = True, []
    mid = None if not oanda else (oanda[0] + oanda[1]) / 2
    if bid is not None and mid is not None:
        if abs(bid - mid) > V4_PIPS * pip:
            bid_f.update(state="red", note=f"{abs(bid - mid) / pip:.1f} pips from the price feed")
            v4_ok = False
            v4_notes.append("live price")
        v11 = abs(bid - oanda[0]) <= V11_PIPS * pip
        add("V11", v11, "" if v11 else f"live price {abs(bid - oanda[0]) / pip:.1f} pips from the feed: wrong date,"
                                       " symbol or scroll?")
        if not v11 and bid_f["state"] == "green":
            bid_f.update(state="amber", note="off the price feed by more than 2 pips")
    else:
        add("V11", False, "no price feed at that minute" if mid is None else "no live price read")
        if bid_f["state"] == "green":
            bid_f.update(state="amber", note="not checked against the price feed")

    # the trades on the picture: positions first, then pending orders
    positions = [p for p in vision.get("positions") or () if isinstance(p, dict)]
    pending = [o for o in vision.get("pending_orders") or () if isinstance(o, dict)]
    trades = []
    for i, p in enumerate(positions):
        trades.append({"role": "position", "index": i, "side": p.get("side"), "lots": p.get("lots"),
                       "pnl": p.get("pnl"), "price": _num(p.get("entry_tag"), discarded), "kind": None})
    for i, o in enumerate(pending):
        kind = str(o.get("type") or "")
        trades.append({"role": "pending", "index": i, "side": _side_of(kind) if kind else None, "lots": o.get("lots"),
                       "pnl": None, "price": _num(o.get("price_tag"), discarded), "kind": kind or None})
    if not trades:
        out["needs_taps"] = bool(lines.rows)
        _finish(out, add, discarded, v4_ok, v4_notes, axis_ok)
        return out

    # entries: the printed price and its line; a hidden one from the side's line or the P&L (worked out)
    fields = [dict() for _ in trades]
    for k, t in enumerate(trades):
        colours = (_SIDE_COLOUR.get(t["side"]),) if t["role"] == "position" else None
        if t["price"] is not None:
            ln = lines.near(t["price"])
            if ln is not None:
                lines.take(ln, "entry", k)
                fields[k]["entry"] = field(t["price"], "green", "both")
            else:
                fields[k]["entry"] = field(t["price"], "red", "vision", "no measured line under it")
        else:
            cands = lines.free(colours) if colours and colours[0] else []
            if len(cands) == 1:
                lines.take(cands[0], "entry", k)
                fields[k]["entry"] = field(cands[0]["price"], "amber", "lines", "worked out from its line")
            else:
                fields[k]["entry"] = field(None, "red", "none", "hidden")

    # stops and targets: owners (V15), the printed price and its line, a hidden one from its line by elimination
    levels = [lv for lv in vision.get("levels") or () if isinstance(lv, dict) and lv.get("kind") in ("sl", "tp")]
    owners = [_owner(lv, len(positions), len(pending)) for lv in levels]
    if len(trades) == 1:
        owners = [0 for _ in owners]
    elif any(o is None for o in owners):
        out["which_trade"] = True
    per = {}
    v15_ok = not out["which_trade"]
    for lv, o in zip(levels, owners):
        if o is None:
            continue
        if (o, lv["kind"]) in per:
            v15_ok = False
            out["which_trade"] = True
            continue
        per[(o, lv["kind"])] = lv
    if out["which_trade"]:          # owners unknown: each printed stop and target is kept for his pick (item 12)
        for lv, o in zip(levels, owners):
            price = _num(lv.get("price_tag"), [])
            if o is None and price is not None:
                out["free_levels"].append({"kind": lv["kind"], "price": price,
                                           "state": "green" if lines.near(price) is not None else "red"})
    for visible_pass in (True, False):
        for (o, kind), lv in per.items():
            price = _num(lv.get("price_tag"), [])
            if visible_pass != (price is not None):
                continue
            if price is not None:
                ln = lines.near(price)
                if ln is not None:
                    lines.take(ln, kind, o)
                    fields[o][kind] = field(price, "green", "both")
                else:
                    fields[o][kind] = field(price, "red", "vision", "no measured line under it")
            else:
                entry = fields[o]["entry"]["value"]
                side = trades[o]["side"]
                sign = 1 if side == "buy" else -1
                want = -1 if kind == "sl" else 1
                cands = [ln for ln in lines.free(("grey",)) if entry is not None
                         and sign * want * (ln["price"] - entry) > 0]
                if len(cands) == 1:
                    lines.take(cands[0], kind, o)
                    fields[o][kind] = field(cands[0]["price"], "amber", "lines", "worked out from its line")
                else:
                    fields[o][kind] = field(None, "red", "none", "hidden")
    for lv in levels:                                      # discarded hidden numbers (V14), counted once
        _num(lv.get("price_tag"), discarded)

    # side, lots, order kind, P&L; V5-V8
    v5_ok, v6_ok, v8_ok, v6_notes, v8_notes = True, True, True, [], []
    pnl_sum, lots_sum = 0.0, 0.0
    for k, t in enumerate(trades):
        fs = fields[k]
        fs.setdefault("sl", field(None, "amber", "none", "no stop on the picture"))
        fs.setdefault("tp", field(None, "amber", "none", "no target on the picture"))
        entry_line = next((ln for ln in lines.rows if ln["role"] == "entry" and ln["trade"] == k), None)
        line_side = {"blue": "buy", "red": "sell"}.get((entry_line or {}).get("colour"))
        if t["role"] == "pending":
            label = local.get("pending_label") or {}
            fs["side"] = _agree_text(t["side"], _side_of(label["type"]) if label.get("type") else None)
            fs["order_kind"] = _agree_text(t["kind"], label.get("type"))
        else:
            fs["side"] = _agree_text(t["side"], line_side)
            fs["order_kind"] = field(None, "amber", "none", "a position: the order picture says how it was placed")
        lots = t["lots"] if isinstance(t["lots"], (int, float)) and not isinstance(t["lots"], bool) else None
        step_ok = lots is not None and lots > 0 and abs(round(lots / 0.01) * 0.01 - lots) < 1e-9
        if lots is None:
            fs["lots"] = field(None, "red", "none", "missing")
            v8_ok = False
        elif not step_ok:
            fs["lots"] = field(lots, "red", "vision", "not in steps of 0.01")
            v8_ok = False
            v8_notes.append(f"lots {lots} not in steps of 0.01")
        else:
            fs["lots"] = field(lots, "amber", "vision")
            lots_sum += lots
        if t["role"] == "position":
            pnl = t["pnl"] if isinstance(t["pnl"], (int, float)) and not isinstance(t["pnl"], bool) else None
            fs["pnl"] = field(pnl, "amber", "vision") if pnl is not None else field(None, "amber", "none")
            if pnl is not None:
                pnl_sum += pnl
        entry = fs["entry"]["value"]
        # V6: the P&L arithmetic (USD-quoted pair, USD account)
        if t["role"] == "position" and entry is not None and lots and step_ok and fs["pnl"]["value"] is not None \
                and bid is not None:
            pnl = fs["pnl"]["value"]
            implied = (bid - pnl / (lots * 100_000)) if t["side"] == "buy" else \
                ((ask if ask is not None else bid) + pnl / (lots * 100_000))
            if abs(implied - entry) <= MATCH_PIPS * pip + 1e-9:
                fs["lots"].update(state="green", source="arith")
                if fs["entry"]["source"] == "vision" and fs["entry"]["state"] != "red":
                    fs["entry"].update(state="green", source="arith")
            else:
                v6_ok = False
                v6_notes.append(f"the P&L implies an entry of {implied:.5f}")
                if fs["entry"]["state"] == "green":
                    fs["entry"].update(state="amber", note=f"the P&L implies {implied:.5f}")
        elif t["role"] == "position" and entry is None and lots and step_ok and fs["pnl"]["value"] is not None \
                and bid is not None and t["side"] in ("buy", "sell"):
            pnl = fs["pnl"]["value"]
            implied = (bid - pnl / (lots * 100_000)) if t["side"] == "buy" else bid + pnl / (lots * 100_000)
            fs["entry"] = field(round(implied, 5), "amber", "arith", "worked out from the P&L")
        # V4 for an open entry: within 30 pips of the mid plus the distance its own P&L shows
        if t["role"] == "position" and entry is not None and mid is not None:
            allow = V4_PIPS
            if fs["pnl"]["value"] is not None and lots:
                allow += abs(fs["pnl"]["value"]) / (lots * 10)
            if abs(entry - mid) > allow * pip + 1e-9:
                fs["entry"].update(state="red", note=f"{abs(entry - mid) / pip:.1f} pips from the price feed")
                v4_ok = False
                v4_notes.append("open entry")
        # V4 for stops, targets and pending prices: inside the axis range (their line match is above)
        top, bottom, step = axis.get("top"), axis.get("bottom"), axis.get("step") or 0
        if top is not None and bottom is not None:
            lo, hi = min(top, bottom) - 1.5 * step, max(top, bottom) + 1.5 * step      # local.AXIS_MARGIN_STEPS
            for name in ("sl", "tp") + (("entry",) if t["role"] == "pending" else ()):
                v = fs[name]["value"]
                if v is not None and not lo <= v <= hi:
                    fs[name].update(state="red", note="outside the price axis")
                    v4_ok = False
                    v4_notes.append(f"{name} outside the axis")
        # V5: the order of the prices; a stop at or past the entry is a moved stop
        side = t["side"]
        stop_ok, moved, target_ok = _v5_levels(side, entry, fs["sl"]["value"], fs["tp"]["value"])
        if not target_ok:
            fs["tp"].update(state="red", note="on the wrong side of the entry")
            v5_ok = False
        if moved:
            if t["role"] == "pending":
                fs["sl"].update(state="red", note="on the wrong side of the order price")
                v5_ok = False
            else:
                fs["sl"]["note"] = "moved: the stop is at or past the entry, so it is not the first stop"
                out["moved_stop"] = True
        if t["role"] == "pending" and entry is not None and bid is not None and t["kind"]:
            below = entry < bid
            want_below = t["kind"] in ("buy_limit", "sell_stop", "buy_stop_limit")
            if t["kind"] in ("buy_limit", "sell_limit", "buy_stop", "sell_stop") and below != want_below:
                fs["entry"].update(state="red", note=f"a {t['kind'].replace('_', ' ')} on the wrong side of the price")
                v5_ok = False
        # V8: the risk to the read stop (only when it is not a moved stop)
        sl = fs["sl"]["value"]
        if balance and entry is not None and sl is not None and not moved and lots and step_ok:
            pct = abs(entry - sl) * lots * 100_000 / balance * 100
            if pct > RISK_NOTE_PCT:
                v8_notes.append(f"high risk: {pct:.1f}% of the balance")
        trades_out = {"role": t["role"], "index": t["index"], "fields": fs, "moved": moved,
                      "first_stop_ok": bool(sl is not None and not moved and stop_ok),
                      "first_stop_from_order": t["role"] == "pending"}
        out["trades"].append(trades_out)
    if not axis_ok:
        for t in out["trades"]:
            for name in ("entry", "sl", "tp"):
                if t["fields"][name]["value"] is not None:
                    t["fields"][name].update(state="red", note="the price axis did not fit")
    add("V4", v4_ok, "; ".join(v4_notes))
    add("V5", v5_ok)
    add("V6", v6_ok, "; ".join(v6_notes))
    # V7: the chip against the P&L labels, within one tick
    chip = local.get("chip")
    if chip is None:
        chip = (vision.get("chip") or {}).get("value")
    if positions and chip is not None:
        v7 = abs(chip - pnl_sum) <= lots_sum * 1.0 + 0.005
        add("V7", v7, "" if v7 else f"the chip shows {chip:.2f}, the labels add up to {pnl_sum:.2f}")
        for t in out["trades"]:
            if "pnl" in t["fields"] and t["fields"]["pnl"]["value"] is not None:
                t["fields"]["pnl"].update(state="green" if v7 else "amber", source="both" if v7 else "vision")
    else:
        add("V7", True, "no open position" if not positions else "no chip read")
    add("V8", v8_ok, "; ".join(v8_notes))
    # V10: the time labels run left to right and are not after the picture's date (never used for exact times)
    labels = clocks.label_times(vision.get("time_labels"), picture_utc.year)
    server_day = clocks.utc_to_server(picture_utc).date()
    v10 = all(a < b for a, b in zip(labels, labels[1:])) and all(t.date() <= server_day for t in labels)
    add("V10", v10, "" if v10 else "time labels out of order or after the picture's date")
    # V15: two or more trades: each stop and target has exactly one owner and every pairing passes V5
    if len(trades) > 1:
        add("V15", v15_ok and not out["which_trade"] and v5_ok,
            "" if v15_ok and not out["which_trade"] else "which trade is each stop and target?")
    else:
        add("V15", True, "one trade")
    _finish(out, add, discarded, v4_ok, v4_notes, axis_ok, ran_v4=True)
    return out


def _finish(out: dict, add, discarded: list, v4_ok: bool, v4_notes: list, axis_ok: bool, ran_v4: bool = False):
    if not ran_v4:
        add("V4", v4_ok, "; ".join(v4_notes))
    add("V14", True, f"{len(discarded)} number(s) marked hidden came with a value: discarded" if discarded else "")
    for k, t in enumerate(out["trades"]):
        for name in CRITICAL:
            if t["fields"].get(name, {}).get("state") == "red":
                out["red"].append(f"{k}.{name}")
    for name in ("symbol",):
        if out["fields"].get(name, {}).get("state") == "red":
            out["red"].append(name)
