"""The paid read (docs/JOURNAL_DESIGN.md §5.3, §5.4, §5.6, D6, D12): one call on the cropped chart, run only by the
send pass (app/photos/sender.py; edge-desk-reader.service, its own user and group edge-reader), the one process that
holds EDGE_ANTHROPIC_KEY; it reads the exact bytes the local pass left in the outbox, never decodes a picture and never
opens the journal. `serve` never imports this module's
client: the anthropic package is imported only inside make_client(), in the reader's own virtualenv. The client is
made with the API host named (base_url) and max_retries=0: every call goes through read(), so every call is counted.

The request is exactly §5.3 (checked against the installed SDK, anthropic 1.17.0: client.beta.messages.create takes
betas, fallbacks ("default" or a list), output_config with effort and a json_schema format; with the
server-side-fallback-2026-07-01 header a fallback attempt keeps the request's format): no temperature and no thinking
parameter (thinking cannot be turned off on this reader; effort is the control). The picture goes as PNG: the crop
is re-encoded from decoded pixels, which also drops anything but the pixels.

Before each create() the `reserve` hook records the call's ceiling (the sender appends and fsyncs it to its ledger);
after a create() that returned usage, the `spend` hook records the actual cost. A call that returns no usage (any
error, an answer that cannot be parsed or priced, a kill) keeps its ceiling. Once a call has started, read() never
raises: the outcome says what happened, and the sender marks the job done. The answer is handled in order: stop_reason "refusal" (stop_details.category
logged), "max_tokens" (one retry at 16000, only when `may_retry` says the cap leaves room for it), else the text block
is parsed and checked against mt5shot/2. Every attempt in usage.iterations is recorded
and priced at its own rate ([photos] prices_per_mtok; one not listed at the highest listed rate): the top-level usage
covers only the attempt that answered. A "message" attempt that names no one is the requested reader's. Errors, most
specific first: AuthenticationError / PermissionDeniedError stop paid reads; BadRequestError (and any other 4xx)
fails this picture; RateLimitError, InternalServerError, OverloadedError and every other 5xx, APIConnectionError and
APITimeoutError re-queue it (reader.py: +2, +10, +30 minutes).
"""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from functools import lru_cache
from pathlib import Path

from app.photos import schema

log = logging.getLogger("edge.reader")
BETA = "server-side-fallback-2026-07-01"
MAX_TOKENS, RETRY_MAX_TOKENS = 8000, 16000
TIMEOUT_S, SDK_RETRIES = 90, 0
API_HOST = "https://api.anthropic.com"
PROMPT_FILE = Path(__file__).with_name("prompt_mt5shot2.txt")
CEILING_INPUT_TOKENS = 10_000          # an upper bound for one attempt's input (picture, prompt, schema)
CEILING_ATTEMPTS = 2                   # the requested reader plus one fallback


@lru_cache(maxsize=1)
def prompt() -> tuple[str, str]:
    """The fixed system text and its sha256 (stored on every reading as prompt_sha)."""
    text = PROMPT_FILE.read_text(encoding="utf-8")
    return text, hashlib.sha256(text.encode("utf-8")).hexdigest()


PROMPT_SHA = prompt()[1]


def note_for(phone_clock: str | None, file_time: str | None) -> str:
    """Only facts the app knows; nothing he typed goes into the call (§5.3 PER_PICTURE_NOTE)."""
    first = f"Phone clock read as {phone_clock}." if phone_clock else "Phone clock not read."
    if file_time:
        t = datetime.fromisoformat(str(file_time).replace("Z", "+00:00"))
        return f"{first} File saved {t:%H:%M} UTC."
    return f"{first} File time unknown."


def request(cfg, image_png: bytes, note: str, max_tokens: int = MAX_TOKENS) -> dict:
    """The keyword arguments of client.beta.messages.create, exactly §5.3."""
    p = cfg.photos
    image = {"type": "image", "source": {"type": "base64", "media_type": "image/png",
                                         "data": base64.b64encode(image_png).decode("ascii")}}
    return dict(model=p.paid_reader, max_tokens=max_tokens, betas=[BETA], fallbacks="default",
                output_config={"effort": p.effort, "format": {"type": "json_schema", "schema": schema.load()}},
                system=prompt()[0], messages=[{"role": "user", "content": [image, {"type": "text", "text": note}]}])


def usd(cfg, name: str | None, tokens_in: int, tokens_out: int) -> float:
    rate_in, rate_out = cfg.photos.price(name)
    return tokens_in * rate_in / 1e6 + tokens_out * rate_out / 1e6


def call_ceiling_usd(cfg, max_tokens: int = MAX_TOKENS) -> float:
    """The most one create() call can cost at the highest listed rates: the requested attempt and one fallback."""
    rate_in, rate_out = cfg.photos.price(None)
    return CEILING_ATTEMPTS * (CEILING_INPUT_TOKENS * rate_in + max_tokens * rate_out) / 1e6


def month_spend(conn, now: datetime) -> float:
    """This UTC month's paid calls as the journal has them (the photo_spend rows the local pass imports from the
    sender's ledger): what Settings shows. The cap itself is the ledger (sender.month_spend)."""
    start = now.strftime("%Y-%m-01T00:00:00Z")
    row = conn.execute("SELECT COALESCE(SUM(usd_est), 0) FROM photo_spend WHERE made_utc >= ?", (start,)).fetchone()
    return float(row[0])


@dataclass
class Reading:
    outcome: str                      # ok, refused, max_tokens, bad_output, stop_key, bad_request, retry, failed
    vision: dict | None = None
    served: str | None = None
    attempts: list = field(default_factory=list)
    usd: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    category: str | None = None
    request_id: str | None = None
    error: str = ""
    ms: int = 0
    calls: int = 0


def _served_by(item) -> str | None:
    try:
        return item.model
    except AttributeError:
        return None


def _attempts(cfg, resp) -> list[dict]:
    """Every attempt of one response, each priced at its own rate."""
    usage = resp.usage
    items = getattr(usage, "iterations", None) or []
    out = []
    for it in items:
        name = _served_by(it) or cfg.photos.paid_reader
        tin = int(getattr(it, "input_tokens", 0) or 0) + int(getattr(it, "cache_creation_input_tokens", 0) or 0) \
            + int(getattr(it, "cache_read_input_tokens", 0) or 0)
        tout = int(getattr(it, "output_tokens", 0) or 0)
        out.append({"type": str(getattr(it, "type", "message")), "name": str(name), "in": tin, "out": tout,
                    "usd": round(usd(cfg, name, tin, tout), 6)})
    if not out:
        name = _served_by(resp) or cfg.photos.paid_reader
        tin = int(getattr(usage, "input_tokens", 0) or 0) + int(getattr(usage, "cache_creation_input_tokens", 0) or 0) \
            + int(getattr(usage, "cache_read_input_tokens", 0) or 0)
        tout = int(getattr(usage, "output_tokens", 0) or 0)
        out.append({"type": "message", "name": str(name), "in": tin, "out": tout,
                    "usd": round(usd(cfg, name, tin, tout), 6)})
    return out


def classify_error(exc: BaseException, sdk) -> str:
    """stop_key, bad_request or retry, most specific class first; None for an exception that is not the SDK's."""
    if isinstance(exc, (sdk.AuthenticationError, sdk.PermissionDeniedError)):
        return "stop_key"
    if isinstance(exc, sdk.BadRequestError):
        return "bad_request"
    retry_classes = tuple(c for c in (getattr(sdk, n, None) for n in (
        "RateLimitError", "InternalServerError", "OverloadedError", "ServiceUnavailableError",
        "DeadlineExceededError")) if c is not None)
    if isinstance(exc, retry_classes):
        return "retry"
    if isinstance(exc, sdk.APIStatusError):
        return "retry" if int(getattr(exc, "status_code", 0) or 0) >= 500 else "bad_request"
    if isinstance(exc, sdk.APIConnectionError):               # APITimeoutError is one
        return "retry"
    return "failed"


def _text_of(resp) -> str | None:
    for block in getattr(resp, "content", None) or ():
        if getattr(block, "type", None) == "text":
            return block.text
    return None


def _charged_without_usage(exc: BaseException, sdk) -> bool:
    """A timeout, a dropped connection or a 5xx may have run (and been billed) with no usage returned; a 4xx is the
    API refusing the request before running it."""
    if isinstance(exc, sdk.APIStatusError):
        return int(getattr(exc, "status_code", 0) or 0) >= 500
    return isinstance(exc, sdk.APIConnectionError)


def read(client, cfg, image_png: bytes, note: str, sdk, *, clock=time.monotonic, reserve=None, spend=None,
         may_retry=None) -> Reading:
    """One paid read of one cropped picture. `reserve(max_tokens, ceiling)` runs before each create() (the sender
    appends and fsyncs "reserved <ceiling>"; if it raises, nothing was sent and the error goes up); `spend(call)` gets
    {"max_tokens", "attempts", "usd", "error"} right after a create() that returned usage ("actual <cost>"); a call
    that returns no usage keeps its reservation. Once a call has started nothing is raised (only a kill stops it):
    the outcome says what happened. `may_retry(max_tokens)` is asked before the retry at 16000."""
    r = Reading(outcome="failed")
    t0 = clock()
    for max_tokens in (MAX_TOKENS, RETRY_MAX_TOKENS):
        if max_tokens != MAX_TOKENS and may_retry is not None and not may_retry(max_tokens):
            r.error = "no room for the retry at 16000 (the monthly cap or the pass's time)"
            break
        kwargs = request(cfg, image_png, note, max_tokens)
        ceiling = call_ceiling_usd(cfg, max_tokens)
        if reserve is not None:
            reserve(max_tokens, ceiling)
        r.calls += 1
        try:
            resp = client.beta.messages.create(**kwargs)
            got = _attempts(cfg, resp)               # inside the guard: an answer it cannot price ends the read here
        except Exception as exc:  # noqa: BLE001 - after a call starts, nothing goes up; the reservation stands
            r.outcome = classify_error(exc, sdk)
            r.attempts.append({"type": "no_usage", "name": cfg.photos.paid_reader, "in": 0, "out": 0,
                               "usd": round(ceiling, 6)})
            r.request_id = getattr(exc, "request_id", None)
            r.error = type(exc).__name__
            if r.outcome == "failed":
                log.warning("reader: a paid call ended with %s; its ceiling stays counted", r.error)
            break
        if spend is not None:
            try:
                spend({"max_tokens": max_tokens, "attempts": got, "usd": sum(a["usd"] for a in got), "error": ""})
            except Exception:  # noqa: BLE001 - the reservation (its ceiling) stays counted
                log.exception("reader: the actual cost could not be recorded; the ceiling stays counted")
        r.attempts += got
        try:
            r.served = _served_by(resp)
            stop = getattr(resp, "stop_reason", None)
            if stop == "refusal":
                details = getattr(resp, "stop_details", None)
                r.outcome, r.category = "refused", getattr(details, "category", None)
                break
            if stop == "max_tokens":
                r.outcome = "max_tokens"
                continue
            text = _text_of(resp)
            try:
                doc = json.loads(text) if isinstance(text, str) else None
            except ValueError:
                doc = None
            errors = schema.validate(doc) if doc is not None else ["no JSON text"]
            if errors:
                r.outcome, r.error = "bad_output", "; ".join(errors[:5])
            else:
                r.outcome, r.vision = "ok", doc
        except Exception as exc:  # noqa: BLE001 - an answer of an unexpected shape
            r.outcome, r.vision, r.error = "failed", None, type(exc).__name__
        break
    r.usd = round(sum(a["usd"] for a in r.attempts), 6)
    r.tokens_in = sum(a["in"] for a in r.attempts)
    r.tokens_out = sum(a["out"] for a in r.attempts)
    r.ms = int((clock() - t0) * 1000)
    return r


def make_client(key: str):
    """(client, the anthropic module) for the send pass only. The API host is named and the SDK never retries on its
    own (each retry is the reader's, counted and cap-checked). The SDK's own logging stays at warnings, so nothing it
    logs can carry the key or a picture."""
    import anthropic                       # the reader's virtualenv only (requirements-reader.txt)
    for name in ("anthropic", "anthropic._base_client", "httpx", "httpx2", "httpcore", "httpcore2"):
        logging.getLogger(name).setLevel(logging.WARNING)
    return anthropic.Anthropic(api_key=key, base_url=API_HOST, timeout=TIMEOUT_S, max_retries=SDK_RETRIES), anthropic
