"""The local pass: free, on this server, in the reader unit only (docs/JOURNAL_DESIGN.md §5.1 step 1, §5.7, §5.8, D7,
D13). It uses the measured methods of the research probes (shots/probe/line_probe.py and ocr_probe.py on the research
branch): MT5's dark-theme colour masks, the price-axis column at the right (x from 84.5% of the width), white label text
enlarged 3x for tesseract, a straight fit of price against pixel row, and long horizontal rows in the plot area (light
grey stop, target and order lines; blue buy and red sell position lines) turned into prices.

What it gives (one dict, see analyse()): the orientation and theme; the phone clock and whether a status bar is there;
the "SYMBOL ▾ TF" label; the axis fit (one constant step, fit error under 0.2 pip, an odd label dropped); every long
line's price; the live tag and the countdown under it; the bottom chip (kept on this server); the position and pending
labels when tesseract can read them; the free pre-filter's three MT5 signs (the axis step, MT5's dark colours, the
label) and the picture's kind (chart, look_mt5, look_tradingview, history, other); History rows read on the server
with the format checks of §5.8 (the summary under the rows is never read), each with its band clipped halfway to the
next text line above and below (or none, when a summary line or a panel falls inside it); the privacy crop, from the
top of the "SYMBOL ▾ TF" label (no label, no crop) down to the bottom bar, and a flag for a panel inside it (a
notification banner, light or dark: any wide even panel whose brightness differs from the plot's by 24 or more).

TradingView is recognised first, before any other stop (a sideways picture included): its title words, its bottom
bar (Watchlist, Chart, Explore, Community, Menu: three of them) or a symbol with a TradingView interval ("EURUSD 5m").

Decoding is Pillow's, under Image.MAX_IMAGE_PIXELS = 12 MP (a picture over it is never decoded), and the metadata is
checked again: a picture that still carries any is refused (the upload strips it, §10).
"""
from __future__ import annotations

import io
import re
import warnings

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

from app.photos import ocr

MAX_PIXELS = 12_000_000
Image.MAX_IMAGE_PIXELS = MAX_PIXELS
MIN_SIDE = 600
AXIS_X = 0.845                 # the price-axis column starts here (probe)
AXIS_Y = (0.08, 0.86)
LINES_Y = (0.11, 0.835)        # the plot area searched for long lines (the probe stopped at 0.82; the plot runs
                               # to the bottom bar at 0.84, less its time labels)
LINES_X = 0.84
LINE_COVER = 0.25              # a row is part of a line when this share of the plot's width is line-coloured
CROP_TOP_MIN = 0.045           # at least this much is cut off the top (the status bar and its notifications)
PANEL_DIFF = 24                # a panel row: this much brighter or darker than the background ...
PANEL_COVER = 0.6              # ... across this share of the width ...
PANEL_EVEN = 12                # ... most of it within this of one level (text on it is a minority) ...
PANEL_ROWS, BAND_PANEL_ROWS = 30, 16   # ... for this many rows in a row (a chart crop, a History band)
BAND_PAD = 24                  # a History row with no text line above or below it: this far past it
CROP_BOTTOM = 0.84             # the bottom bar and the chip start here
FIT_MAX_PIPS = 0.2
AXIS_MARGIN_STEPS = 1.5        # "inside the axis range": the labelled span and up to 1.5 label gaps past either end
TIMEFRAMES = ("M1", "M2", "M3", "M4", "M5", "M6", "M10", "M12", "M15", "M20", "M30", "H1", "H2", "H3", "H4", "H6",
              "H8", "H12", "D1", "W1", "MN1")
MESSAGES = {
    "landscape": "Turn your phone upright and take the screenshot again. Sideways pictures aren't read yet.",
    "light": "Switch MT5 to the dark theme for screenshots. Light ones aren't read yet.",
    "no_axis": "Send the full screenshot, not a cropped one: the prices on the right are needed.",
    "small": "This copy is too small to read. Send the original screenshot from your gallery.",
    "too_large": "This picture is too large. Send the screenshot as it was taken.",
    "metadata": "This picture could not be checked. Send the screenshot again.",
    "broken": "This picture is cut short or broken: send the original screenshot.",
    "other": "This isn't an MT5 chart: not read.",
}
_PRICE = re.compile(r"\d\.\d{5}")
_CLOCK = re.compile(r"\d{1,2}:\d{2}")
_COUNTDOWN = re.compile(r"\d{1,2}:\d{2}(:\d{2})?")
_SYMBOL = re.compile(r"[A-Z]{6}([._-]?[A-Za-z0-9]{1,4})?")
_TV = re.compile(r"\bOANDA\b|TradingView|\bFX:|\bFXCM\b|\bFX_IDC\b|Euro\s*/\s*U\.?\s*S\.?\s*Dollar", re.I)
_TV_BAR = {"watchlist", "chart", "explore", "community", "menu"}
_TV_INTERVAL = re.compile(r"\d{1,3}[mhDWM]")
_TV_SYMBOL = re.compile(r"[A-Z]{6}")
_MONEY = re.compile(r"[-+]?\d{1,3}(?: \d{3})*\.\d{2}")
_ROW_HEAD = re.compile(r"^([A-Z]{6}[.\w-]*),\s*(buy|sell)\s+(\d+(?:\.\d+)?)\b", re.I)
_CLOSE_TIME = re.compile(r"(\d{4}\.\d{2}\.\d{2})\s+(\d{2}:\d{2}:\d{2})")
_ROW_PRICES = re.compile(r"(\d\.\d+)\D{1,8}?(\d\.\d+)")
_ROW_PROFIT = re.compile(r"([-+]?\d{1,3}(?:[ ,]\d{3})*\.\d+)\s*$")
_SUMMARY = re.compile(r"^(Profit|Balance|Deposit|Withdrawal|Credit)\b", re.I)
# a tapped row's labels, matched anywhere on a line: his rows have two columns ("#id … Open:", "S / L … Swap:",
# "T / P … Commission:"), and tesseract may read a pair as one line or as two
_EXTRAS = (("open_time", re.compile(r"\bOpen\b\s*:?\s*(\d{4}\.\d{2}\.\d{2}\s+\d{2}:\d{2}:\d{2})")),
           ("sl", re.compile(r"\bS\s*/\s*L\b\s*:?\s*(\d\.\d+)")),
           ("tp", re.compile(r"\bT\s*/\s*P\b\s*:?\s*(\d\.\d+)")),
           ("swap", re.compile(r"\bSwap\b\s*:?\s*([-+]?\d{1,3}(?: \d{3})*\.\d+)")),
           ("commission", re.compile(r"\bCommission\b\s*:?\s*([-+]?\d{1,3}(?: \d{3})*\.\d+)")))
_TICKET = re.compile(r"^#\d+")


class Unreadable(Exception):
    def __init__(self, problem: str):
        super().__init__(problem)
        self.problem = problem


def decode(data: bytes) -> Image.Image:
    """The picture as RGB, or Unreadable: over 12 megapixels (never decoded), not a plain JPEG or PNG, animated,
    cut short, or still carrying metadata."""
    with warnings.catch_warnings():
        warnings.simplefilter("error", Image.DecompressionBombWarning)
        try:
            im = Image.open(io.BytesIO(data), formats=("JPEG", "PNG"))  # no other decoder ever sees his bytes
        except (Image.DecompressionBombError, Image.DecompressionBombWarning):
            raise Unreadable("too_large") from None
        except (UnidentifiedImageError, OSError, SyntaxError, ValueError):
            raise Unreadable("broken") from None
        if im.format not in ("JPEG", "PNG") or getattr(im, "n_frames", 1) != 1:
            raise Unreadable("broken")
        if im.width * im.height > MAX_PIXELS:
            raise Unreadable("too_large")
        try:
            meta = len(im.getexif()) > 0 or any(k in im.info for k in ("exif", "xmp", "XML:com.adobe.xmp",
                                                                        "icc_profile", "comment"))
            meta = meta or bool(getattr(im, "text", None))
            im.load()
        except (OSError, SyntaxError, ValueError):
            raise Unreadable("broken") from None
        if meta:
            raise Unreadable("metadata")
        return im.convert("RGB")


def _luma(a: np.ndarray) -> np.ndarray:
    return a[..., 0] * 0.299 + a[..., 1] * 0.587 + a[..., 2] * 0.114


def _text_img(a: np.ndarray, mask=None) -> Image.Image:
    """Dark text on white for tesseract: a mask's pixels, or the grey picture inverted when it is dark."""
    if mask is not None:
        return Image.fromarray(np.where(mask, 0, 255).astype("uint8"))
    g = Image.fromarray(_luma(a).astype("uint8"))
    return ImageOps.invert(g) if np.median(_luma(a)) < 128 else g


def _ocr(a: np.ndarray, x0: int, y0: int, mask=None, psm: int = 11, scale: int = 2) -> list[dict]:
    img = _text_img(a, mask)
    if scale != 1:
        img = img.resize((img.width * scale, img.height * scale), Image.LANCZOS)
    return ocr.words(img, psm=psm, scale=scale, offset=(x0, y0))


def _white(a: np.ndarray) -> np.ndarray:
    return a.min(axis=2) > 200


def _masks(a: np.ndarray) -> dict:
    a = a.astype(int)
    mn, mx = a.min(axis=2), a.max(axis=2)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    return {"grey": (mn > 95) & (mx - mn < 40), "blue": (b > 170) & (b - r > 50), "red": (r > 170) & (r - g > 70)}


def fit_axis(points: list[tuple[float, float]], pip: float) -> dict:
    """price = a + b * row through the axis labels, under the constant-step rule: the step is the commonest gap
    between neighbouring labels; labels off that grid (a tag's price, a misread) are dropped; the fit must leave every
    kept label within 0.2 pip. ok needs three labels or more."""
    out = {"ok": False, "a": None, "b": None, "step": None, "top": None, "bottom": None, "labels": 0,
           "max_err_pips": None, "dropped": len(points)}
    pts = sorted(points)
    if len(pts) < 3:
        return out
    gaps = [round((p0 - p1) / 1e-5) for (_, p0), (_, p1) in zip(pts, pts[1:]) if round((p0 - p1) / 1e-5) > 0]
    if not gaps:
        return out
    counts: dict = {}
    for g in gaps:
        counts[g] = counts.get(g, 0) + 1
    step_pts = max(counts, key=lambda g: (counts[g], -g))
    best: list = []
    for _, anchor in pts:
        on = [(y, p) for y, p in pts if abs((anchor - p) / (step_pts * 1e-5) - round((anchor - p) / (step_pts * 1e-5)))
              < 0.05]
        if len(on) > len(best):
            best = on
    for _ in range(3):
        if len(best) < 3:
            return out
        ys, ps = np.array([y for y, _ in best]), np.array([p for _, p in best])
        b, a = np.polyfit(ys, ps, 1)
        resid = np.abs(ps - (a + b * ys))
        keep = resid < 0.5 * step_pts * 1e-5
        if keep.all():
            break
        best = [pt for pt, k in zip(best, keep) if k]
    if len(best) < 3 or b >= 0:
        return out
    ys, ps = np.array([y for y, _ in best]), np.array([p for _, p in best])
    b, a = np.polyfit(ys, ps, 1)
    err = float(np.max(np.abs(ps - (a + b * ys))) / pip)
    prices = sorted(p for _, p in best)
    steps_ok = all(abs(round((q - p) / (step_pts * 1e-5)) - (q - p) / (step_pts * 1e-5)) < 0.05
                   for p, q in zip(prices, prices[1:]))
    out.update(ok=bool(steps_ok and err < FIT_MAX_PIPS), a=float(a), b=float(b), step=round(step_pts * 1e-5, 6),
               top=max(prices), bottom=min(prices), labels=len(best), max_err_pips=round(err, 4),
               dropped=len(points) - len(best))
    return out


def _groups(rows: np.ndarray, gap: int = 2) -> list[list[int]]:
    groups, cur = [], []
    for r in rows:
        if cur and r - cur[-1] > gap:
            groups.append(cur)
            cur = []
        cur.append(int(r))
    if cur:
        groups.append(cur)
    return groups


def _lines(a: np.ndarray, fit: dict) -> list[dict]:
    """Long horizontal rows in the plot area, priced from the axis fit; kept when inside the axis range."""
    H, W, _ = a.shape
    y0, y1, x1 = int(H * LINES_Y[0]), int(H * LINES_Y[1]), int(W * LINES_X)
    m = _masks(a[y0:y1, :x1])
    cover = {k: v.mean(axis=1) for k, v in m.items()}
    total = np.maximum.reduce([cover["grey"], cover["blue"], cover["red"]])
    out = []
    if not fit.get("ok") and fit.get("a") is None:
        return out
    lo, hi = fit["bottom"] - AXIS_MARGIN_STEPS * fit["step"], fit["top"] + AXIS_MARGIN_STEPS * fit["step"]
    for g in _groups(np.where(total > LINE_COVER)[0]):
        w = total[g]
        y = float(np.average(np.array(g, float), weights=w)) + y0
        colour = max(("grey", "blue", "red"), key=lambda k: float(cover[k][g].sum()))
        price = fit["a"] + fit["b"] * y
        if lo <= price <= hi:
            out.append({"y": round(y, 2), "price": round(price, 5), "colour": colour})
    out.sort(key=lambda ln: ln["y"])
    for i, ln in enumerate(out, start=1):
        ln["n"] = i
    return out


def _live_tag(a: np.ndarray, fit: dict, countdown_y: float | None) -> dict | None:
    H, W, _ = a.shape
    y0, y1, x0 = int(H * AXIS_Y[0]), int(H * AXIS_Y[1]), int(W * AXIS_X)
    col = a[y0:y1, x0:].astype(int)
    r, g, b = col[..., 0], col[..., 1], col[..., 2]
    masks = {"green": (g > 130) & (g - r > 60) & (g - b > 20), "red": (r > 170) & (r - g > 70)}
    found = []
    for colour, m in masks.items():
        for grp in _groups(np.where(m.mean(axis=1) > 0.5)[0]):
            if len(grp) >= 12:
                found.append((float(np.mean(grp)) + y0, colour))
    if not found or fit.get("a") is None:
        return None
    if countdown_y is not None:
        above = [f for f in found if 0 < countdown_y - f[0] < 90]
        if above:
            found = above
    green = [f for f in found if f[1] == "green"]
    y, colour = max(green or found, key=lambda f: f[0])
    return {"y": round(y, 2), "price": round(fit["a"] + fit["b"] * y, 5), "colour": colour}


def _money(text: str) -> float | None:
    m = _MONEY.fullmatch(text.strip())
    return float(m.group(0).replace(" ", "")) if m else None


def _panel(a: np.ndarray, y0: int, y1: int, bg: float, min_rows: int = PANEL_ROWS) -> bool:
    """A wide, even panel (a notification banner, light or dark) between rows y0 and y1."""
    y0, y1 = max(0, int(y0)), min(a.shape[0], int(y1))
    if y1 - y0 < min_rows:
        return False
    lum = _luma(a[y0:y1].astype(float))
    off = np.abs(lum - bg) >= PANEL_DIFF
    rows = []
    for i in np.where(off.mean(axis=1) >= PANEL_COVER)[0]:
        level = float(np.median(lum[i][off[i]]))
        if (np.abs(lum[i] - level) <= PANEL_EVEN).mean() >= 0.5:
            rows.append(i)
    return any(len(g) >= min_rows for g in _groups(np.array(rows, dtype=int)))


def history_band(a: np.ndarray, *, top: float, bottom: float, above: float | None, below: float | None,
                 avoid: list) -> list[int] | None:
    """One History row's band: from halfway to the text line above to halfway to the one below (BAND_PAD past the row
    when there is none), or None when a summary line (avoid: its (top, bottom) rows) or a panel falls inside it."""
    H, W, _ = a.shape
    y0 = int((above + top) / 2) if above is not None else int(top - BAND_PAD)
    y1 = int((bottom + below) / 2) if below is not None else int(np.ceil(bottom + BAND_PAD))
    y0, y1 = max(0, y0), min(H, y1)
    if any(s < y1 and e > y0 for s, e in avoid):
        return None
    bg = float(np.median(_luma(a[::8, ::8].astype(float))))
    if _panel(a, y0, y1, bg, BAND_PANEL_ROWS):
        return None
    return [0, y0, W, y1]


def _history(a: np.ndarray) -> dict | None:
    """MT5 History rows (positions): "SYMBOL, side lots", the close time, "open → close" and the profit; a row
    tapped open adds its ticket, open time, stop, target, swap and commission (two columns). The summary block is never
    read into a row; its lines only keep every band clear of them."""
    found = ocr.lines(_ocr(a, 0, 0, psm=4, scale=1))
    rows, cur, summary, ended = [], None, [], False
    for ln in found:
        text = ln["text"].strip()
        if _SUMMARY.match(text):
            summary.append((ln["y"], ln["bottom"]))
            cur = None
            ended = ended or bool(rows)
            continue
        if ended:
            continue
        head = _ROW_HEAD.match(text)
        when = _CLOSE_TIME.search(text)
        if head and when:
            cur = {"symbol": head.group(1).upper(), "side": head.group(2).lower(), "lots": float(head.group(3)),
                   "close_time": f"{when.group(1)} {when.group(2)}", "open_price": None, "close_price": None,
                   "profit": None, "profit_text": None, "tapped": False, "open_time": None, "sl": None, "tp": None,
                   "swap": None, "commission": None, "top": ln["y"], "bottom": ln["bottom"], "_lines": 0}
            rows.append(cur)
            continue
        if cur is None:
            continue
        cur["_lines"] += 1
        if cur["_lines"] > 7:
            cur = None
            continue
        prices = _ROW_PRICES.search(text)
        if cur["open_price"] is None and prices:
            cur["open_price_text"], cur["close_price_text"] = prices.group(1), prices.group(2)
            cur["open_price"], cur["close_price"] = float(prices.group(1)), float(prices.group(2))
            prof = _ROW_PROFIT.search(text[prices.end():])
            if prof:
                cur["profit_text"] = prof.group(1)
                cur["profit"] = float(prof.group(1).replace(" ", "").replace(",", ""))
            cur["bottom"] = ln["bottom"]
            continue
        hit = bool(_TICKET.match(text))
        for key, rx in _EXTRAS:
            m = rx.search(text)
            if m:
                value = m.group(1)
                cur[key] = value if key == "open_time" else float(value.replace(" ", ""))
                cur[key + "_text"] = value
                hit = True
        if hit:
            cur["tapped"] = True
            cur["bottom"] = ln["bottom"]
    spans = sorted((ln["y"], ln["bottom"]) for ln in found)
    out = []
    for r in rows:
        problems = []
        for k in ("open_price_text", "close_price_text"):
            if not _PRICE.fullmatch(r.get(k) or ""):
                problems.append(f"{k[:-5]}: not a price with 5 decimals")
        if not r["profit_text"] or not _MONEY.fullmatch(r["profit_text"]):
            problems.append("profit: not money with 2 decimals")
        for k in ("swap", "commission"):
            if r.get(k + "_text") is not None and not _MONEY.fullmatch(r[k + "_text"].strip()):
                problems.append(f"{k}: not money with 2 decimals")
        for k in ("sl", "tp"):
            if r.get(k + "_text") is not None and not _PRICE.fullmatch(r[k + "_text"]):
                problems.append(f"{k}: not a price with 5 decimals")
        if not (r["lots"] > 0 and abs(round(r["lots"] / 0.01) * 0.01 - r["lots"]) < 1e-9):
            problems.append("lots: not in steps of 0.01")
        above = max((b for y, b in spans if b <= r["top"]), default=None)
        below = min((y for y, b in spans if y >= r["bottom"]), default=None)
        band = history_band(a, top=r["top"], bottom=r["bottom"], above=above, below=below, avoid=summary)
        out.append({k: r[k] for k in ("symbol", "side", "lots", "open_price", "close_price", "close_time", "profit",
                                      "tapped", "open_time", "sl", "tp", "swap", "commission")}
                   | {"ok": not problems, "problems": problems, "band": band})
    return {"rows": out} if out else None


def crop_box(a: np.ndarray, label_top: float | None) -> list[int] | None:
    """The part that may be sent: from the top of the "SYMBOL ▾ TF" label (never above it, and at least 4.5% of the
    height down) to the bottom bar; None when the label was not found (nothing is sent then)."""
    if label_top is None:
        return None
    H, W, _ = a.shape
    return [0, max(int(np.ceil(label_top)), int(H * CROP_TOP_MIN)), W, int(H * CROP_BOTTOM)]


def crop_png(data: bytes, box) -> bytes:
    """The box re-encoded as PNG from decoded pixels: the pixels only."""
    rgb = decode(data).crop(tuple(int(v) for v in box))
    b = io.BytesIO()
    rgb.save(b, "PNG", optimize=False)
    return b.getvalue()


def _tradingview(a: np.ndarray, top_words: list[dict]) -> bool:
    """TradingView, from its title words, a symbol beside a TradingView interval ("EURUSD 5m"), or its bottom bar."""
    if _TV.search(" ".join(w["text"] for w in top_words)):
        return True
    syms = [w for w in top_words if _TV_SYMBOL.fullmatch(w["text"])]
    ivs = [w for w in top_words if _TV_INTERVAL.fullmatch(w["text"])]
    if any(abs(s["y"] - i["y"]) < 40 and i["x"] > s["x"] for s in syms for i in ivs):
        return True
    H = a.shape[0]
    y0 = H - max(int(H * 0.1), 140)
    bar = {re.sub(r"[^a-z]", "", w["text"].lower()) for w in _ocr(a[y0:], 0, y0)}
    return len(bar & _TV_BAR) >= 3


def analyse(data: bytes) -> dict:
    out = {"width": None, "height": None, "orientation": None, "theme": None, "problem": None, "message": "",
           "status_bar": False, "phone_clock": None, "symbol": None, "timeframe": None, "tradingview": False,
           "axis": None, "lines": [], "live_tag": None, "countdown": None, "chip": None,
           "signs": {"axis": False, "colours": False, "label": False}, "kind": "other", "history": None,
           "crop": None, "banner": False, "position_label": None, "pending_label": None, "label_top": None}

    def stop(problem: str) -> dict:
        out["problem"], out["message"] = problem, MESSAGES[problem]
        return out

    try:
        rgb = decode(data)
    except Unreadable as exc:
        return stop(exc.problem)
    a = np.asarray(rgb)
    H, W, _ = a.shape
    out.update(width=W, height=H, orientation="landscape" if W > H else "portrait")
    if min(W, H) < MIN_SIDE:
        return stop("small")
    top_band = a[: int(H * 0.16)]
    top_words = _ocr(top_band, 0, 0)
    if _tradingview(a, top_words):                     # before any other stop: a sideways TradingView is a look too
        out.update(tradingview=True, kind="look_tradingview")
        return out
    if W > H:
        return stop("landscape")
    plot_luma = float(np.median(_luma(a[int(H * 0.15):int(H * 0.8), : int(W * 0.8)])))
    out["theme"] = "light" if plot_luma > 128 else "dark"
    for w in top_words:
        if w["y"] < H * 0.06 and w["x"] < W * 0.45 and _CLOCK.fullmatch(w["text"]):
            out.update(phone_clock=w["text"], status_bar=True)
            break
    label = [w for w in top_words if H * 0.06 <= w["y"] <= H * 0.16 and w["x"] < W * 0.7]
    tops = []
    for w in label:
        t = w["text"].replace("▾", "").replace("▼", "").strip(",")
        if out["symbol"] is None and _SYMBOL.fullmatch(t):
            out["symbol"] = t
            tops.append(w["y"])
        if out["timeframe"] is None and t in TIMEFRAMES:
            out["timeframe"] = t
            tops.append(w["y"])
    out["signs"]["label"] = bool(out["symbol"] and out["timeframe"])
    out["label_top"] = round(min(tops), 1) if out["signs"]["label"] else None
    if out["theme"] == "light":
        return stop("light") if out["signs"]["label"] else stop("other")
    # the axis column: white labels at one constant step (and the countdown, white, under the live tag)
    y0, y1, x0 = int(H * AXIS_Y[0]), int(H * AXIS_Y[1]), int(W * AXIS_X)
    col = a[y0:y1, x0:]
    white = _white(col)
    axis_words = _ocr(col, x0, y0, mask=white, psm=6, scale=3)
    pip = 0.0001
    points = [(w["y"] + w["h"] / 2, float(w["text"])) for w in axis_words if _PRICE.fullmatch(w["text"])]
    fit = fit_axis(points, pip)
    out["axis"] = fit
    out["signs"]["axis"] = bool(fit["ok"])
    out["signs"]["colours"] = plot_luma < 40 and int(white.sum()) > 200
    cd = [w for w in axis_words if _COUNTDOWN.fullmatch(w["text"])]
    if cd:
        out["countdown"] = cd[0]["text"]
    if len(points) < 3 and not fit["ok"]:
        if out["signs"]["label"]:
            return stop("no_axis")
        hist = _history(a)
        if hist:
            out.update(kind="history", history=hist, crop=None)
            return out
        return stop("other")
    out["lines"] = _lines(a, fit) if fit["a"] is not None else []
    out["live_tag"] = _live_tag(a, fit, (cd[0]["y"] + cd[0]["h"] / 2) if cd else None)
    # the chip (read here only; never sent)
    cy0, cy1 = int(H * CROP_BOTTOM), int(H * 0.92)
    chip_lines = ocr.lines(_ocr(a[cy0:cy1, int(W * 0.2): int(W * 0.8)], int(W * 0.2), cy0, psm=11))
    for ln in chip_lines:
        v = _money(ln["text"])
        if v is not None:
            out["chip"] = v
            break
    # the position and pending labels at the lines' left ends (often unreadable locally: the probe read 0 of 4)
    py0, py1 = int(H * LINES_Y[0]), int(H * LINES_Y[1])
    m = _masks(a[py0:py1, : int(W * 0.7)])
    text = " ".join(w["text"] for w in _ocr(a[py0:py1, : int(W * 0.7)], 0, py0, mask=m["grey"] | m["blue"] | m["red"]
                                            | _white(a[py0:py1, : int(W * 0.7)])))
    pos = re.search(r"\b(BUY|SELL)\s+(\d+(?:\.\d+)?),?\s+([+-]?\d[\d ]*\.\d{2})\s*USD", text)
    if pos:
        out["position_label"] = {"side": pos.group(1).lower(), "lots": float(pos.group(2)),
                                 "pnl": float(pos.group(3).replace(" ", ""))}
    pend = re.search(r"\b(BUY|SELL)\s+(LIMIT|STOP)\s+(\d+(?:\.\d+)?)", text)
    if pend:
        out["pending_label"] = {"type": f"{pend.group(1).lower()}_{pend.group(2).lower()}", "lots": float(pend.group(3))}
    out["crop"] = crop_box(a, out["label_top"])
    out["banner"] = _panel(a, out["crop"][1] if out["crop"] else int(H * CROP_TOP_MIN), int(H * CROP_BOTTOM),
                           plot_luma)
    out["kind"] = "chart" if out["lines"] else "look_mt5"
    return out
