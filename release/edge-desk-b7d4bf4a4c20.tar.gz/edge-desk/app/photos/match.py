"""Matching a picture to its trade, and what the price feed can say about a picture trade (docs/JOURNAL_DESIGN.md §6;
D14 replaced 30 Oct 2026: his account has the read-only bridge, so a bridge trade is the record).

Order of truth: the bridge's exact values, then his confirmed edits, then two agreeing reads, then one read, then
values estimated from prices.
1. Bridge trades (the `trade` table, book mt5): the same symbol and side, lots equal, the entry within 1 pip
   (checklist MATCH_PRICE_PIPS), opened within the 12 hours before the picture; the stop is compared (within 1 pip,
   MATCH_STOP_PIPS) only while no moved stop has been seen. From the lines alone too: a bridge trade whose entry and its
   stop or target each sit on a measured line (no paid read needed for its numbers). Pending orders the bridge sees
   are matched once they are stored (order_seen, another builder's table): until then only positions and deals.
2. Picture trades: an open one (no exit) on any trading day, a closed one only on its own trading day (17:00 to
   17:00 New York); symbol, side, lots and the entry within 0.5 pip; never the stop (he moves it).
3. History rows: an open picture trade (or one closed only from prices) by symbol, side, lots, the open price within
   0.5 pip and a close time after its open; a row he types (its own read failed a check) by symbol, side, lots and
   the close time only.
5. Never counted twice (fix round D-c): a picture trade is held out of R until he answers "Which trade is this?" while
   any bridge trade is plausibly the same one: the same symbol and side, its entry within 3 pips, and open at one of
   the picture trade's times (a picture of it, its fill or its placing) or opened on one of those trading days, or
   (a pending order resting for hours or days) opened after its first picture and before its exit, within 7 days.
4. Prices (the app's m1_bar, OANDA bid and ask; OANDA is not his broker, so 1-pip tolerances): the fill estimate is the
   first minute after the order picture where the ask low reached the limit + 0.2 pip (buy limit) or the bid high the
   limit - 0.2 pip (sell limit); the exit estimate is a range from the first minute the bid (long) or ask (short) touched
   the stop or target to the first minute it traded through it by at least 1 pip. Estimates stay out of R stats.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from app.checklist.store import MATCH_PRICE_PIPS, MATCH_STOP_PIPS
from app.photos import clocks
from app.photos.checks import base_symbol
from app.timeutil import from_iso, to_iso, trading_day

UTC = timezone.utc
WINDOW = timedelta(hours=12)
PICTURE_PIPS = 0.5
FILL_PIPS = 0.2
THROUGH_PIPS = 1.0
LOTS_EPS = 0.005
SEARCH_DAYS = 7
PLAUSIBLE_PIPS = 3.0
PENDING = ("buy_limit", "sell_limit", "buy_stop", "sell_stop")
_EPS = 1e-9


def _pip(cfg) -> float:
    return cfg.instrument.pip_size


def _syms(cfg) -> list[str]:
    return list(cfg.instrument.broker_symbols)


def bridge_candidates(conn, cfg, *, side: str, lots: float, price: float, at: datetime, stop: float | None = None,
                      moved: bool = False) -> list[dict]:
    pip = _pip(cfg)
    syms = _syms(cfg)
    rows = conn.execute(f"SELECT * FROM trade WHERE book = 'mt5' AND side = ? AND symbol IN ({','.join('?' * len(syms))})"
                        " AND open_utc BETWEEN ? AND ? ORDER BY open_utc, id",
                        (side, *syms, to_iso(at - WINDOW), to_iso(at))).fetchall()
    out = []
    for t in rows:
        if abs(t["volume"] - lots) > LOTS_EPS or abs(t["open_price"] - price) > MATCH_PRICE_PIPS * pip + _EPS:
            continue
        if not moved and stop is not None and t["initial_sl"] is not None \
                and abs(t["initial_sl"] - stop) > MATCH_STOP_PIPS * pip + _EPS:
            continue
        out.append(dict(t))
    return out


def bridge_by_lines(conn, cfg, lines, at: datetime) -> list[dict]:
    """Bridge trades whose entry and stop or target each lie within 1 pip of a measured line."""
    pip = _pip(cfg)
    prices = [ln["price"] for ln in lines or ()]

    def on_line(p):
        return p is not None and any(abs(p - q) <= MATCH_PRICE_PIPS * pip + _EPS for q in prices)
    syms = _syms(cfg)
    rows = conn.execute(f"SELECT * FROM trade WHERE book = 'mt5' AND symbol IN ({','.join('?' * len(syms))})"
                        " AND open_utc BETWEEN ? AND ? ORDER BY open_utc, id",
                        (*syms, to_iso(at - WINDOW), to_iso(at))).fetchall()
    return [dict(t) for t in rows if on_line(t["open_price"]) and (on_line(t["initial_sl"]) or on_line(t["initial_tp"]))]


def picture_candidates(conn, cfg, *, side: str, lots: float, entry: float, at: datetime) -> list[dict]:
    pip = _pip(cfg)
    day = trading_day(at).isoformat()
    rows = conn.execute("SELECT * FROM photo_trade WHERE state IN ('confirmed','closed') AND linked_trade_id IS NULL"
                        " AND side = ? ORDER BY id", (side,)).fetchall()
    out = []
    for t in rows:
        if t["symbol"] not in _syms(cfg) or t["lots"] is None or t["entry"] is None:
            continue
        if abs(t["lots"] - lots) > LOTS_EPS or abs(t["entry"] - entry) > PICTURE_PIPS * pip + _EPS:
            continue
        open_now = t["exit_price"] is None
        if open_now or day in (t["trading_day"], t["close_trading_day"]):
            out.append(dict(t))
    return out


def _opened(t) -> datetime | None:
    for k in ("fill_utc", "placed_utc"):
        if t[k]:
            return from_iso(t[k])
    return None


def history_candidates(conn, cfg, row: dict, loose: bool = False) -> list[dict]:
    """Open picture trades a History row may close; `loose` (a row he types because its read failed a check) leaves
    out the open price, which may be the number that failed."""
    pip = _pip(cfg)
    if not row.get("close_time") or (row.get("open_price") is None and not loose):
        return []
    closed = clocks.server_to_utc(datetime.strptime(row["close_time"], "%Y.%m.%d %H:%M:%S"))
    rows = conn.execute("SELECT * FROM photo_trade WHERE state IN ('confirmed','closed') AND linked_trade_id IS NULL"
                        " AND side = ? AND (exit_price IS NULL OR exit_how = 'prices') ORDER BY id",
                        (row.get("side"),)).fetchall()
    out = []
    for t in rows:
        if base_symbol(t["symbol"]) != base_symbol(row.get("symbol")):
            continue
        if t["lots"] is None or abs(t["lots"] - float(row.get("lots") or 0)) > LOTS_EPS:
            continue
        if not loose and (t["entry"] is None or abs(t["entry"] - row["open_price"]) > PICTURE_PIPS * pip + _EPS):
            continue
        if closed <= _seen_from(conn, t):
            continue
        out.append(dict(t))
    return out


def seen_times(conn, t) -> list[datetime]:
    """Every time the picture trade was seen: each of its pictures, its fill and its placing."""
    out = [from_iso(r[0]) for r in conn.execute(
        "SELECT COALESCE(p.picture_utc, p.received_utc) FROM photo p JOIN photo_link l ON l.photo_id = p.id"
        " WHERE l.trade_ref = ? AND p.state != 'deleted'", (f"photo:{t['id']}",)) if r[0]]
    out += [from_iso(t[k]) for k in ("fill_utc", "placed_utc") if t[k]]
    return sorted(out) or [from_iso(t["created_utc"])]


def bridge_plausible(conn, cfg, t) -> list[dict]:
    """Bridge trades that may be this picture trade (item 5 above), oldest first."""
    if t["entry"] is None or t["side"] not in ("buy", "sell"):
        return []
    pip, syms = _pip(cfg), _syms(cfg)
    seen = seen_times(conn, t)
    days = {trading_day(s).isoformat() for s in seen}
    until = from_iso(t["exit_utc_to"]) if t["exit_utc_to"] else seen[0] + timedelta(days=SEARCH_DAYS)
    out = []
    for b in conn.execute(f"SELECT * FROM trade WHERE book = 'mt5' AND side = ? AND symbol IN ({','.join('?' * len(syms))})"
                          " ORDER BY open_utc, id", (t["side"], *syms)):
        if b["open_price"] is None or abs(b["open_price"] - t["entry"]) > PLAUSIBLE_PIPS * pip + _EPS:
            continue
        opened = from_iso(b["open_utc"])
        closed = from_iso(b["close_utc"]) if b["close_utc"] else None
        hit = any(opened <= s and (closed is None or s <= closed) for s in seen) or b["trading_day"] in days
        if not hit and t["order_kind"] in PENDING:
            hit = seen[0] <= opened <= min(until, seen[0] + timedelta(days=SEARCH_DAYS))
        if hit:
            out.append(dict(b))
    return out


def _bars(conn, start: datetime, end: datetime):
    return conn.execute("SELECT * FROM m1_bar WHERE ts >= ? AND ts < ? ORDER BY ts",
                        (int(start.timestamp()) // 60 * 60, int(end.timestamp()))).fetchall()


def quote_at(conn, at: datetime) -> tuple[float, float] | None:
    """(bid, ask) at the close of the minute holding `at`, or of the latest minute in the 5 before it."""
    ts = int(at.timestamp()) // 60 * 60
    r = conn.execute("SELECT bid_c, ask_c FROM m1_bar WHERE ts <= ? AND ts >= ? ORDER BY ts DESC LIMIT 1",
                     (ts, ts - 300)).fetchone()
    return (r["bid_c"], r["ask_c"]) if r else None


def _seen_from(conn, t) -> datetime:
    """When the order or position was first seen: its placing or fill time, else its first picture."""
    opened = _opened(t)
    if opened:
        return opened
    r = conn.execute("SELECT MIN(p.picture_utc) FROM photo p JOIN photo_link l ON l.photo_id = p.id"
                     " WHERE l.trade_ref = ?", (f"photo:{t['id']}",)).fetchone()
    return from_iso(r[0]) if r and r[0] else from_iso(t["created_utc"])


def fill_estimate(conn, cfg, t) -> dict | None:
    """A pending order's fill from prices: {"utc", "price", "how": "prices"} or None."""
    kind, price = t["order_kind"], t["entry"]
    if kind not in ("buy_limit", "sell_limit", "buy_stop", "sell_stop") or price is None or t["fill_utc"]:
        return None
    pip = _pip(cfg)
    start = _seen_from(conn, t)
    for b in _bars(conn, start + timedelta(seconds=1), start + timedelta(days=SEARCH_DAYS)):
        hit = {"buy_limit": b["ask_l"] <= price + FILL_PIPS * pip + _EPS,
               "sell_limit": b["bid_h"] >= price - FILL_PIPS * pip - _EPS,
               "buy_stop": b["ask_h"] >= price - _EPS, "sell_stop": b["bid_l"] <= price + _EPS}[kind]
        if hit:
            return {"utc": datetime.fromtimestamp(b["ts"], UTC), "price": price, "how": "prices"}
    return None


def exit_estimate(conn, cfg, t) -> dict | None:
    """The first of the stop or the target the prices reached and then went through by 1 pip:
    {"kind", "price", "from", "to", "text"}, or None while neither has been traded through."""
    if t["exit_price"] is not None or t["side"] not in ("buy", "sell"):
        return None
    pip = _pip(cfg)
    start = _seen_from(conn, t)
    if t["fill_utc"]:
        start = from_iso(t["fill_utc"])
    end = start + timedelta(days=SEARCH_DAYS)                 # m1_bar holds finished minutes only
    buy = t["side"] == "buy"
    levels = [(k, t[k]) for k in ("sl", "tp") if t[k] is not None]
    touched: dict = {}
    for b in _bars(conn, start + timedelta(seconds=1), end):
        at = datetime.fromtimestamp(b["ts"], UTC)
        for kind, level in levels:
            if kind == "sl":
                reach = (b["bid_l"] <= level + _EPS) if buy else (b["ask_h"] >= level - _EPS)
                through = (b["bid_l"] <= level - THROUGH_PIPS * pip + _EPS) if buy else \
                    (b["ask_h"] >= level + THROUGH_PIPS * pip - _EPS)
            else:
                reach = (b["bid_h"] >= level - _EPS) if buy else (b["ask_l"] <= level + _EPS)
                through = (b["bid_h"] >= level + THROUGH_PIPS * pip - _EPS) if buy else \
                    (b["ask_l"] <= level - THROUGH_PIPS * pip + _EPS)
            if reach and kind not in touched:
                touched[kind] = at
            if through:
                first = touched.get(kind, at)
                word = "stopped" if kind == "sl" else "target"
                return {"kind": kind, "price": level, "from": first, "to": at,
                        "text": f"{word} {clocks.fmt_range(first, at)}?"}
    return None


def r_values(side: str, entry, initial_sl, exit_price, lots, profit, commission, swap, exact: bool):
    """(R before costs, R net, risk in USD) from initial_sl only (D15); R only for an exact exit; R net only when the
    commission is known. EUR/USD on a USD account: 100,000 units a lot."""
    if entry is None or initial_sl is None or abs(entry - initial_sl) < 1e-9:
        return None, None, None
    risk = abs(entry - initial_sl) * (lots or 0) * 100_000 or None
    if not exact or exit_price is None:
        return None, None, risk
    sign = 1 if side == "buy" else -1
    before = sign * (exit_price - entry) / abs(entry - initial_sl)
    net = None
    if commission is not None and profit is not None and risk:
        net = (profit + commission + (swap or 0.0)) / risk
    return before, net, risk
