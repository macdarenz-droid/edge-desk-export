"""tesseract, the reader's local text reader (docs/JOURNAL_DESIGN.md §5.1, §5.8): Ubuntu 24.04's tesseract-ocr, pinned
by deploy/install/stage2.sh. Run on a PNG through stdin with TSV output (no temporary file), one thread, a deadline;
used only by the reader unit, never by `serve`. Word boxes come back in the picture's own pixels.
"""
from __future__ import annotations

import io
import os
import shutil
import subprocess

TESSERACT = "tesseract"
TIMEOUT_S = 60
_ENV = {"OMP_THREAD_LIMIT": "1", "PATH": os.environ.get("PATH", "/usr/bin:/bin"), "LC_ALL": "C"}


def available() -> bool:
    return shutil.which(TESSERACT) is not None


def version() -> str:
    out = subprocess.run([TESSERACT, "--version"], capture_output=True, text=True, timeout=TIMEOUT_S, env=_ENV)
    first = (out.stdout or out.stderr).splitlines()
    return first[0].strip() if first else ""


def words(img, psm: int = 11, scale: float = 1.0, offset: tuple[int, int] = (0, 0)) -> list[dict]:
    """Every word tesseract finds in a PIL image: text (brackets and bars that tag boxes add are stripped), its box in
    the original picture's pixels (`scale` the image was enlarged by, `offset` its top-left corner there), the
    confidence and its line key (block, paragraph, line)."""
    b = io.BytesIO()
    img.save(b, "PNG")
    out = subprocess.run([TESSERACT, "stdin", "stdout", "--psm", str(psm), "tsv"], input=b.getvalue(),
                         capture_output=True, timeout=TIMEOUT_S, env=_ENV, check=True).stdout.decode("utf-8", "replace")
    found = []
    ox, oy = offset
    for line in out.splitlines()[1:]:
        f = line.split("\t")
        if len(f) < 12 or f[0] != "5":
            continue
        text = f[11].strip().strip("[]|{}()")
        if not text:
            continue
        x, y, w, h = (int(v) for v in f[6:10])
        found.append({"text": text, "x": x / scale + ox, "y": y / scale + oy, "w": w / scale, "h": h / scale,
                      "conf": float(f[10]), "line": (int(f[2]), int(f[3]), int(f[4]))})
    return found


def lines(found: list[dict]) -> list[dict]:
    """Words grouped into tesseract's lines, top to bottom: {"text", "words", "y", "bottom"}."""
    groups: dict = {}
    for w in found:
        groups.setdefault(w["line"], []).append(w)
    out = []
    for ws in groups.values():
        ws.sort(key=lambda w: w["x"])
        out.append({"text": " ".join(w["text"] for w in ws), "words": ws, "y": min(w["y"] for w in ws),
                    "bottom": max(w["y"] + w["h"] for w in ws)})
    out.sort(key=lambda ln: ln["y"])
    return out
