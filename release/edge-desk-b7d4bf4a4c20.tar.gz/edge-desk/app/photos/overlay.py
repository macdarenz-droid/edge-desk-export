"""The found lines drawn over his own picture (docs/JOURNAL_DESIGN.md §3 step 3, D11): a server-made SVG the size of the
picture, shown in an <img> stacked over it, so the screens hold no drawing code. Each measured line is drawn across the
plot with its number and price: the entry amber, the stop red, the target green, the others grey; if a drawn line sits
on his MT5 line it was read right. Attribute-only SVG, every text escaped: no script, style, link or embedded image.
Text at least 40 px at his picture's 1080 px width.
"""
from __future__ import annotations

from xml.sax.saxutils import escape

COLOURS = {"entry": "#f5a524", "sl": "#e5484d", "tp": "#30a46c", None: "#8b8d98"}
NAMES = {"entry": "Entry", "sl": "Stop", "tp": "Target"}
FONT = 44


def lines_svg(reading: dict, width: int, height: int) -> bytes:
    rows = reading.get("lines") or []
    scale = max(1.0, width / 1080)
    font = round(FONT * scale, 1)
    stroke = round(4 * scale, 1)
    plot_w = round(width * 0.84, 1)
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {int(width)} {int(height)}" '
             f'width="{int(width)}" height="{int(height)}">']
    for ln in rows:
        try:
            y = float(ln["y"])
            price = float(ln["price"])
            n = int(ln["n"])
        except (KeyError, TypeError, ValueError):
            continue
        role = ln.get("role") if ln.get("role") in COLOURS else None
        colour = COLOURS[role]
        label = f"{n} · {price:.5f}" + (f" · {NAMES[role]}" if role in NAMES else "")
        parts.append(f'<line x1="0" y1="{y:.1f}" x2="{plot_w}" y2="{y:.1f}" stroke="{colour}" '
                     f'stroke-width="{stroke}" stroke-opacity="0.9"/>')
        ty = max(font, y - stroke * 2)
        parts.append(f'<rect x="{round(16 * scale, 1)}" y="{ty - font:.1f}" width="{round(len(label) * font * 0.56, 1)}" '
                     f'height="{font * 1.15:.1f}" rx="{round(8 * scale, 1)}" fill="#000000" fill-opacity="0.72"/>')
        parts.append(f'<text x="{round(26 * scale, 1)}" y="{ty - font * 0.12:.1f}" font-size="{font}" '
                     f'font-family="sans-serif" fill="{colour}">{escape(label)}</text>')
    parts.append("</svg>")
    return "".join(parts).encode("utf-8")
