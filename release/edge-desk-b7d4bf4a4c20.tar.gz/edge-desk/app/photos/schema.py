"""Schema mt5shot/2 (docs/JOURNAL_DESIGN.md §5.2): what one MetaTrader 5 phone picture shows, as the paid read returns
it. The file mt5shot2.json is the research branch's shots/extraction_schema.json byte for byte, frozen by its sha256;
it is sent as the structured-output format and checked again here after the answer comes back ("then the app's own
schema validation", §5.3). Standard library only: the keywords the schema uses (type, enum, properties, required,
additionalProperties false, items, anyOf, $ref to #/$defs) and nothing else.
"""
from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path

SCHEMA_ID = "mt5shot/2"
SCHEMA_FILE = Path(__file__).with_name("mt5shot2.json")
SCHEMA_SHA256 = "e850556b94c99f4a7ee4322d93ce6e1ae2cd5442b277e6fd023153c46f2d6c9e"
_TYPES = {"object": dict, "array": list, "string": str, "boolean": bool, "null": type(None)}
MAX_ERRORS = 20


@lru_cache(maxsize=1)
def _loaded() -> str:
    raw = SCHEMA_FILE.read_bytes()
    if hashlib.sha256(raw).hexdigest() != SCHEMA_SHA256:
        raise RuntimeError(f"{SCHEMA_FILE.name} is not the frozen mt5shot/2 (sha256 differs)")
    return raw.decode("utf-8")


def load() -> dict:
    """A fresh copy of the frozen schema (refused if the file changed)."""
    return json.loads(_loaded())


def _is(value, kind: str) -> bool:
    if kind == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if kind == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    return isinstance(value, _TYPES[kind])


def _check(node: dict, value, path: str, defs: dict, out: list[str]) -> None:
    if len(out) >= MAX_ERRORS:
        return
    if "$ref" in node:
        name = node["$ref"].rsplit("/", 1)[-1]
        return _check(defs[name], value, path, defs, out)
    if "anyOf" in node:
        for option in node["anyOf"]:
            trial: list[str] = []
            _check(option, value, path, defs, trial)
            if not trial:
                return
        out.append(f"{path}: matches none of its options")
        return
    kinds = node.get("type")
    if kinds is not None:
        kinds = [kinds] if isinstance(kinds, str) else kinds
        if not any(_is(value, k) for k in kinds):
            out.append(f"{path}: not {'/'.join(kinds)}")
            return
    if "enum" in node and value not in node["enum"]:
        out.append(f"{path}: not one of {node['enum']}")
        return
    if isinstance(value, dict) and "properties" in node:
        props = node["properties"]
        for key in node.get("required", ()):
            if key not in value:
                out.append(f"{path}.{key}: missing")
        if node.get("additionalProperties") is False:
            for key in value:
                if key not in props:
                    out.append(f"{path}.{key}: not in the schema")
        for key, sub in props.items():
            if key in value:
                _check(sub, value[key], f"{path}.{key}", defs, out)
    if isinstance(value, list) and "items" in node:
        for i, item in enumerate(value):
            _check(node["items"], item, f"{path}[{i}]", defs, out)


def validate(doc) -> list[str]:
    """The reasons `doc` is not a valid mt5shot/2 reading ([] when it is)."""
    s = load()
    out: list[str] = []
    _check(s, doc, "$", s.get("$defs", {}), out)
    return out
