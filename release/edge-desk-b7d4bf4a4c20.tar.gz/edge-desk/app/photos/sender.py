"""The send pass (docs/JOURNAL_DESIGN.md §4 "Reader trigger", D5, D12; fix round E, the coordinator's second D-b
design): `python -m app reader --send`, run by edge-desk-reader.service as its own user and group edge-reader, the
one process with EDGE_ANTHROPIC_KEY. It never decodes a picture (no Pillow), never opens the journal (no database at
all) and writes only the results folder.

The two folders, under EDGE_READER_DIR (/opt/edge-desk/reader on the server; next to the photos folder in tests):
- outbox/ (edge:edge-reader, 2750; files 0640): the local pass leaves each job there, "<photo id>-<claim>.png" (the
  exact bytes to send) and ".json" (what the local pass needs back, with the bytes' sha256). The sender reads it and
  never deletes from it; the local pass removes a job once its answer is in the journal.
- results/ (edge-reader:edge, 2750; files 0640): the sender writes each job's answer "<job>.json", its key's state
  "key.json", and its spend ledger "spend-YYYY-MM.jsonl"; the local pass imports them into the journal. The sender
  removes an answer once its job has left the outbox.

The ledger is the cap. Before each create() the sender appends and fsyncs {"kind": "reserved", "usd": <the call's
ceiling>}; after a call that returned usage, {"kind": "actual", "usd": <its cost>}. A call costs its actual line, or
its ceiling when there is none (an error, an answer that could not be parsed, a kill mid-call). A job with any
reservation is never sent again: once a call has started, the job is done whatever happens. Only an outage before
the call (the reservation cannot be written, the client is missing, the pass's time is up) leaves a job for later.
The local pass's outbox lock (outbox/.lock) is held while a reservation is made, so a job is never sent after the
local pass removed it. The sender stops starting calls DEADLINE_S into its pass, at least two call timeouts before
its unit's TimeoutStartSec.

Every file in these folders is read as untrusted input (fix round F): opened with O_NOFOLLOW and O_NONBLOCK, accepted
only as a plain file under its size limit (an answer ANSWER_MAX_BYTES, a ledger LEDGER_MAX_BYTES, a job's JSON
JOB_MAX_BYTES and bytes PNG_MAX_BYTES, key.json KEY_MAX_BYTES), every field checked. An answer that cannot be read is
a failed read; an "ok" whose reading fails mt5shot/2 is a bad output. A ledger line that cannot be read or has a
number that is not finite and at least 0, or a time that is not a time, charges its call's ceiling (the retry's when
even that is unknown) and still marks its job as started; a ledger file that cannot be read stops paid reads (the
month counts as spent). Each line is written with one write of the whole line, its length checked, after a newline
when the file lacks a final one, and a call's "actual" line goes next to its "reserved" line, in the month it was
reserved.
"""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import logging
import math
import os
import re
import stat
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app.photos import claude, schema

log = logging.getLogger("edge.reader")
UTC = timezone.utc
OUTBOX, RESULTS, LOCK, KEY_FILE = "outbox", "results", ".lock", "key.json"
UNIT_TIMEOUT_S = 15 * 60                                  # edge-desk-reader.service TimeoutStartSec
DEADLINE_S = UNIT_TIMEOUT_S - 2 * claude.TIMEOUT_S - 60   # no call starts after this, in a pass
STALE = timedelta(seconds=UNIT_TIMEOUT_S) + timedelta(minutes=5)   # a reservation with no answer this old: stopped
ANSWER_MAX_BYTES = 256 * 1024             # an answer: a reading is a few KB (its output is capped at 16,000 tokens)
LEDGER_MAX_BYTES = 4 * 1024 * 1024        # a month's ledger: about 200 bytes a line, a few hundred calls at the cap
LEDGER_MAX_LINES = 20_000                 # more lines than any month at the cap writes: the file counts as unreadable
MAX_ATTEMPTS_LISTED = 10                  # attempts in an answer or a ledger line (a call makes two at most)
JOB_MAX_BYTES = 1024 * 1024               # a job's JSON: the local pass's result, a few KB
PNG_MAX_BYTES = 16 * 1024 * 1024          # the bytes to send: a crop of a picture of at most 12 megapixels
KEY_MAX_BYTES = 4 * 1024
OUTCOMES = ("ok", "refused", "max_tokens", "bad_output", "stop_key", "bad_request", "retry", "failed", "cap")
_CALL = re.compile(r"[A-Za-z0-9_-]{1,64}\.[0-9]{1,4}")
_JOB = re.compile(r"[0-9]{1,12}-[0-9]{1,12}")       # a job's name: "<photo id>-<n>"; nothing else is an answer
MAX_CALL_USD = 50.0                       # no call costs more (the cap's own ceiling): a larger figure is not clean
AHEAD = timedelta(minutes=10)             # a reservation's time is at most this far after now
_MONTH_FILE = re.compile(r"spend-([0-9]{4}-[0-9]{2})\.jsonl")
_write = os.write                         # one write of the whole line (a test makes it short)


class Unreadable(Exception):
    """A file in the reader folders that is not a plain file under its limit, or not what it should be."""


def _open_plain(path: Path, limit: int) -> int:
    """An open file descriptor of a plain file under its limit, never following a link and never blocking on a
    FIFO."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError as exc:
        raise Unreadable(f"cannot be opened ({exc.strerror or exc})") from None
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            raise Unreadable("not a plain file")
        if st.st_size > limit:
            raise Unreadable("larger than its limit")
    except BaseException:
        os.close(fd)
        raise
    return fd


def _stream_lines(path: Path, limit: int, max_lines: int):
    """A plain file's lines, read a chunk at a time (never the whole file in memory at once beyond one line); more than
    `limit` bytes or `max_lines` lines makes it unreadable."""
    fd = _open_plain(path, limit)
    try:
        buf, total, n = b"", 0, 0
        while True:
            try:
                chunk = os.read(fd, 65536)
            except OSError as exc:
                raise Unreadable(f"cannot be read ({exc.strerror or exc})") from None
            if not chunk:
                break
            total += len(chunk)
            if total > limit:
                raise Unreadable("larger than its limit")
            buf += chunk
            *lines, buf = buf.split(b"\n")
            for line in lines:
                n += 1
                if n > max_lines:
                    raise Unreadable("more lines than its limit")
                yield line
        if buf:
            if n + 1 > max_lines:
                raise Unreadable("more lines than its limit")
            yield buf
    finally:
        os.close(fd)


def read_file(path: Path, limit: int) -> bytes:
    """A plain file's bytes, never following a link and never blocking on a FIFO; at most `limit` bytes."""
    fd = _open_plain(path, limit)
    try:
        chunks, total = [], 0
        while True:
            b = os.read(fd, 65536)
            if not b:
                break
            total += len(b)
            if total > limit:
                raise Unreadable("larger than its limit")
            chunks.append(b)
        return b"".join(chunks)
    except OSError as exc:
        raise Unreadable(f"cannot be read ({exc.strerror or exc})") from None
    finally:
        os.close(fd)


def _no_constants(name):
    raise ValueError(f"{name} is not a number")


def _json(data: bytes):
    return json.loads(data.decode("utf-8"), parse_constant=_no_constants)


def _money(v) -> float | None:
    """A finite amount of at least 0 (never a bool, NaN or infinity), or None."""
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return None
    v = float(v)
    return v if math.isfinite(v) and v >= 0 else None


def _when(v, month: str | None = None, now: datetime | None = None) -> str | None:
    """A reservation's time, or None when it is not a clean one: not a time with its zone, out of the range a date can
    hold, outside its ledger file's month, or more than AHEAD after now."""
    if not isinstance(v, str) or len(v) > 40:
        return None
    try:
        t = datetime.fromisoformat(v.replace("Z", "+00:00"))
        if t.tzinfo is None:
            return None
        t = t.astimezone(UTC)
    except (ValueError, OverflowError):
        return None
    if not 2000 <= t.year <= 2999 or (month is not None and t.strftime("%Y-%m") != month):
        return None
    if now is not None and t > now + AHEAD:
        return None
    return _iso(t)


class Gone(Exception):
    """The job left the outbox before its first call was reserved: nothing is sent."""


def base_for(folder) -> Path:
    """The reader folders' parent when EDGE_READER_DIR is not given: next to the photos folder."""
    return Path(folder).parent / "reader"


def _iso(t: datetime) -> str:
    return t.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _put(path: Path, data: bytes) -> None:
    """Write a file whole (a temporary name, then a rename), 0640: readable by the other reader user's group."""
    tmp = path.with_name("." + path.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, data)
        os.fchmod(fd, 0o640)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, path)


def _folder(path: Path) -> Path:
    if not path.is_dir():
        path.mkdir(parents=True, exist_ok=True)
        os.chmod(path, 0o2750)
    return path


@contextlib.contextmanager
def outbox_lock(base, create: bool = False):
    """The local pass (create=True) and the sender take it in turn; the sender only opens it."""
    box = Path(base) / OUTBOX
    path = box / LOCK
    if create:
        _folder(box)
        fd = os.open(path, os.O_RDONLY | os.O_CREAT, 0o640)
        os.fchmod(fd, 0o640)
    else:
        try:
            fd = os.open(path, os.O_RDONLY)
        except FileNotFoundError:
            yield
            return
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        os.close(fd)


# ---------------------------------------------------------------- the outbox (written by the local pass)

def job_name(row) -> str:
    return f"{row['id']}-{row['attempts']}"


def write_job(base, row, kind: str, png: bytes, note: str, loc: dict, band_row: int | None = None,
              job: str | None = None) -> str:
    """The exact bytes to send and what the local pass needs back; the JSON is written last (a job is complete once
    its JSON is there). Called by the local pass, under the outbox lock, with a name never used before (fix round F:
    "<photo id>-<n>"; job_name(row) only where no journal gives one)."""
    box = _folder(Path(base) / OUTBOX)
    job = job or job_name(row)
    _put(box / f"{job}.png", png)
    meta = {"job": job, "photo_id": row["id"], "attempts": row["attempts"], "kind": kind, "band_row": band_row,
            "png_sha256": hashlib.sha256(png).hexdigest(), "note": note, "loc": loc}
    _put(box / f"{job}.json", json.dumps(meta, default=str).encode())
    return job


def remove_job(base, job: str) -> None:
    box = Path(base) / OUTBOX
    for ext in (".json", ".png"):
        (box / f"{job}{ext}").unlink(missing_ok=True)


def _job_key(path: Path):
    try:
        return tuple(int(x) for x in path.stem.split("-"))
    except ValueError:
        return (1 << 62,)


def jobs(base, with_png: bool = False) -> list[dict]:
    """The complete jobs in the outbox, oldest picture first; with_png adds each one's bytes (checked against their
    sha256). The sender reads one job's bytes at a time (job_bytes), so a long outbox never fills its memory."""
    box = Path(base) / OUTBOX
    out = []
    if not box.is_dir():
        return out
    for j in sorted(box.glob("*.json"), key=_job_key):
        if j.name.startswith("."):
            continue
        if not _JOB.fullmatch(j.stem):
            continue
        try:
            meta = _json(read_file(j, JOB_MAX_BYTES))
            if not isinstance(meta, dict) or meta.get("job") != j.stem or not (box / f"{j.stem}.png").exists():
                continue
            if with_png:
                png = job_bytes(base, meta)
                if png is None:
                    continue
                meta = {**meta, "png": png}
        except Exception:  # noqa: BLE001 - any file it cannot use (RecursionError included) is skipped
            continue
        out.append(meta)
    return out


def job_bytes(base, job: dict) -> bytes | None:
    """A job's bytes, checked against the sha256 it was written with; None when they cannot be read or differ."""
    try:
        png = read_file(Path(base) / OUTBOX / f"{job['job']}.png", PNG_MAX_BYTES)
    except (Unreadable, KeyError, TypeError):
        return None
    return png if hashlib.sha256(png).hexdigest() == job.get("png_sha256") else None


# ---------------------------------------------------------------- the results folder (written by the sender)

def _text(v, n=300) -> str | None:
    return v[:n] if isinstance(v, str) else None


def _int(v) -> int:
    return int(v) if isinstance(v, int) and not isinstance(v, bool) and 0 <= v < 10 ** 9 else 0


def clean_answer(job: str, d) -> dict:
    """An answer as the local pass may use it: known fields of the right types only; an "ok" whose reading fails
    mt5shot/2 is a bad output, never a draft."""
    if not isinstance(d, dict) or d.get("job") != job:
        return {"job": job, "outcome": "failed", "error": "the answer file is not an answer for this job"}
    outcome = d.get("outcome") if d.get("outcome") in OUTCOMES else "failed"
    vision, error = None, _text(d.get("error")) or ""
    if outcome == "ok":
        v = d.get("vision")
        errors = schema.validate(v) if isinstance(v, dict) else ["no reading"]
        if errors:
            outcome, error = "bad_output", "the answer failed its schema check: " + "; ".join(errors[:3])
        else:
            vision = v
    listed = d.get("attempts_usage") if isinstance(d.get("attempts_usage"), list) else []
    if len(listed) > MAX_ATTEMPTS_LISTED:
        return {"job": job, "outcome": "failed",
                "error": f"the answer lists more than {MAX_ATTEMPTS_LISTED} attempts: not an answer"}
    attempts = []
    for a in listed:
        if isinstance(a, dict) and _money(a.get("usd")) is not None:
            attempts.append({"type": _text(a.get("type"), 40) or "message", "name": _text(a.get("name"), 80) or "",
                             "in": _int(a.get("in")), "out": _int(a.get("out")), "usd": _money(a.get("usd"))})
    return {"job": job, "photo_id": _int(d.get("photo_id")), "attempts": _int(d.get("attempts")), "outcome": outcome,
            "vision": vision, "served": _text(d.get("served"), 80), "attempts_usage": attempts,
            "usd": _money(d.get("usd")) or 0.0, "tokens_in": _int(d.get("tokens_in")),
            "tokens_out": _int(d.get("tokens_out")), "category": _text(d.get("category"), 80),
            "request_id": _text(d.get("request_id"), 120), "error": error, "ms": _int(d.get("ms")),
            "calls": _int(d.get("calls"))}


def answered(base) -> set:
    """The jobs with an answer file, by name only (nothing is opened)."""
    box = Path(base) / RESULTS
    if not box.is_dir():
        return set()
    return {f.stem for f in box.glob("*.json") if _JOB.fullmatch(f.stem)}


def results(base, only=None) -> dict:
    """job -> its answer, cleaned; an answer file that cannot be read is a failed read for its job. `only`: read the
    answers of these jobs alone (the local pass reads only the jobs still in its outbox)."""
    box = Path(base) / RESULTS
    out = {}
    if not box.is_dir():
        return out
    names = answered(base) if only is None else {n for n in only if isinstance(n, str) and _JOB.fullmatch(n)}
    for name in sorted(names):
        f = box / f"{name}.json"
        if not os.path.lexists(f):
            continue
        try:
            out[f.stem] = clean_answer(f.stem, _json(read_file(f, ANSWER_MAX_BYTES)))
        except Unreadable as exc:
            out[f.stem] = {"job": f.stem, "outcome": "failed", "error": f"the answer file could not be read: {exc}"}
        except Exception as exc:  # noqa: BLE001 - not JSON, too deep (RecursionError), anything: a failed read
            out[f.stem] = {"job": f.stem, "outcome": "failed",
                           "error": f"the answer file could not be read: {type(exc).__name__}"}
    return out


def _bad_line(line: str) -> dict:
    """What can still be told about a line that is not clean: its call, job, picture and size, if they show."""
    def grab(key, pat):
        m = re.search(rf'"{key}"\s*:\s*{pat}', line)
        return m.group(1) if m else None
    call = grab("call", r'"([A-Za-z0-9_.-]{1,80})"')
    job = grab("job", r'"([A-Za-z0-9_-]{1,64})"') or (call.rsplit(".", 1)[0] if call and "." in call else None)
    pid = grab("photo_id", r"([0-9]{1,12})")
    mt = grab("max_tokens", r"([0-9]{1,6})")
    return {"call": call if call and _CALL.fullmatch(call) else None, "job": job,
            "photo_id": int(pid) if pid else None, "max_tokens": int(mt) if mt else None,
            "actual": grab("kind", r'"(actual)"') is not None}


def ledger(base, month: str | None = None, now: datetime | None = None) -> tuple[dict, list]:
    """(call -> its entry, the months whose file could not be read). An entry: job, photo_id, at, max_tokens,
    reserved and actual (None when absent or not clean), attempts, error, bad (a line of it was not clean)."""
    box = Path(base) / RESULTS
    calls: dict = {}
    broken: list = []
    if not box.is_dir():
        return calls, broken
    for f in sorted(box.glob("spend-*.jsonl")):
        m = _MONTH_FILE.fullmatch(f.name)
        try:
            y, mo = (int(x) for x in m.group(1).split("-")) if m else (0, 0)
        except ValueError:
            y, mo = 0, 0
        if not (2000 <= y <= 2999 and 1 <= mo <= 12):
            broken.append(f"invalid file {f.name}")       # named for no month: unreadable for the cap
            continue
        if month is not None and m.group(1) != month:
            continue
        try:
            for raw in _stream_lines(f, LEDGER_MAX_BYTES, LEDGER_MAX_LINES):
                line = raw.decode("utf-8", "replace")
                if not line.strip():
                    continue
                _ledger_line(calls, line, m.group(1), now)
        except Unreadable:
            broken.append(m.group(1))
    return calls, broken


def _ledger_line(calls: dict, line: str, month: str, now) -> None:
    """One ledger line into `calls`. A line that is not clean marks its call (its ceiling, its job started); one with no
    call id that can be read joins its file's single anonymous entry (one ceiling a file, never one a line)."""
    d, huge = None, False
    try:
        d = json.loads(line, parse_constant=_no_constants)
        ok = isinstance(d, dict) and isinstance(d.get("call"), str) and _CALL.fullmatch(d["call"]) is not None \
            and d.get("kind") in ("reserved", "actual")
        usd = _money(d.get("usd")) if ok else None
        huge = usd is not None and usd > MAX_CALL_USD
        if ok and d["kind"] == "reserved":
            ok = (isinstance(d.get("job"), str) and d["call"].rsplit(".", 1)[0] == d["job"]
                  and usd is not None and not huge and _when(d.get("at"), month, now) is not None
                  and _int(d.get("photo_id")) == d.get("photo_id") and _int(d.get("max_tokens")) > 0)
        elif ok:
            ok = usd is not None and not huge
    except Exception:  # noqa: BLE001 - not JSON, too deep (RecursionError), an odd time: not clean
        ok = False
    key = d["call"] if ok else None
    if not ok:
        b = _bad_line(line)
        key = b["call"] or f"?{month}"
    c = calls.setdefault(key, {"call": key, "month": month, "job": None, "photo_id": None, "at": None,
                               "max_tokens": None, "reserved": None, "actual": None, "attempts": [],
                               "error": "", "bad": False})
    if not ok:
        c["bad"] = True
        c["huge"] = c.get("huge") or huge
        c["job"] = c["job"] or b["job"]
        c["photo_id"] = c["photo_id"] if c["photo_id"] is not None else b["photo_id"]
        c["max_tokens"] = c["max_tokens"] or b["max_tokens"]
        if b["actual"]:
            c["actual_bad"] = True
        return
    if d["kind"] == "reserved":
        c.update(job=d["job"], photo_id=d["photo_id"], at=_when(d["at"], month, now),
                 max_tokens=d["max_tokens"], reserved=_money(d["usd"]))
    else:
        c.update(actual=_money(d["usd"]), error=_text(d.get("error")) or "",
                 attempts=[a for a in d.get("attempts") or [] if isinstance(a, dict)][:MAX_ATTEMPTS_LISTED]
                 if isinstance(d.get("attempts"), list) else [])


def ledger_calls(base, month: str | None = None, cfg=None, now: datetime | None = None) -> dict:
    return ledger(base, month, now)[0]


def call_cost(c: dict, cfg) -> float:
    """A call's cost: its clean actual line; without one, the larger of its reservation and its ceiling (the retry's
    when its size is unknown); a line claiming more than any call costs, MAX_CALL_USD. Never 0 for a call that may
    have run, never NaN, never infinite."""
    if c.get("actual") is not None and not c.get("actual_bad"):
        return c["actual"]
    if c.get("huge"):
        return MAX_CALL_USD
    ceiling = claude.call_ceiling_usd(cfg, c.get("max_tokens") if c.get("max_tokens") in (
        claude.MAX_TOKENS, claude.RETRY_MAX_TOKENS) else claude.RETRY_MAX_TOKENS)
    return max(ceiling, c.get("reserved") or 0.0)


def month_spend(base, now: datetime, cfg) -> float:
    """The cap: this UTC month's calls, each at its cost (call_cost); a month whose file cannot be read counts as
    spent (infinity: no paid read starts)."""
    calls, broken = ledger(base, now.astimezone(UTC).strftime("%Y-%m"), now)
    if broken:
        return math.inf
    return sum(call_cost(c, cfg) for c in calls.values())


def may_spend(base, cfg, now: datetime, max_tokens: int = claude.MAX_TOKENS) -> bool:
    return month_spend(base, now, cfg) + claude.call_ceiling_usd(cfg, max_tokens) <= cfg.photos.monthly_usd_cap + 1e-12


def _append(base, month: str, entry: dict) -> None:
    """One whole line, written with one write and its length checked, after a newline when the file lacks a final one
    (a line torn by a kill stays alone on its line); fsynced."""
    box = _folder(Path(base) / RESULTS)
    path = box / f"spend-{month}.jsonl"
    fd = os.open(path, os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_NOFOLLOW, 0o640)      # read: its last byte
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            raise OSError("the ledger is not a plain file")
        os.fchmod(fd, 0o640)
        data = (json.dumps(entry, default=str) + "\n").encode()
        if st.st_size and os.pread(fd, 1, st.st_size - 1) != b"\n":
            data = b"\n" + data
        if _write(fd, data) != len(data):
            raise OSError("a short write to the ledger")
        os.fsync(fd)
    finally:
        os.close(fd)


def key_state(base) -> dict | None:
    """{"state": "set" | "not_set" | "not_working", "fp"} as the sender last saw its key, or None (never run)."""
    try:
        d = _json(read_file(Path(base) / RESULTS / KEY_FILE, KEY_MAX_BYTES))
    except Exception:  # noqa: BLE001 - unreadable, not JSON, too deep: as if never written
        return None
    if not isinstance(d, dict) or d.get("state") not in ("set", "not_set", "not_working"):
        return None
    return {"state": d["state"], "fp": _text(d.get("fp"), 16) or ""}


def _record_key(base, key: str | None, failed: bool = False) -> str:
    """The key's state, written only when it changes. A key that failed (401/403) stays "not working" until it
    changes: only a short hash of it is kept to notice that."""
    fp = hashlib.sha256(key.encode()).hexdigest()[:16] if key else ""
    before = key_state(base) or {}
    if not key:
        state = "not_set"
    elif failed or (before.get("state") == "not_working" and before.get("fp") == fp):
        state = "not_working"
    else:
        state = "set"
    if (before.get("state"), before.get("fp")) != (state, fp):
        _put(_folder(Path(base) / RESULTS) / KEY_FILE, json.dumps({"state": state, "fp": fp}).encode())
    return state


def _clean(base) -> None:
    """Drop the answers whose job has left the outbox (the local pass imported them), by name: never opened."""
    box, res = Path(base) / OUTBOX, Path(base) / RESULTS
    for job in answered(base):
        if not (box / f"{job}.json").exists():
            (res / f"{job}.json").unlink(missing_ok=True)


def _answer(base, job: dict, payload: dict) -> None:
    _put(_folder(Path(base) / RESULTS) / f"{job['job']}.json",
         json.dumps({"job": job["job"], "photo_id": job["photo_id"], "attempts": job["attempts"], **payload},
                    default=str).encode())


def run_send(cfg, base, now: datetime, *, key=None, client=None, sdk=None, clock=time.monotonic) -> list[str]:
    """One send pass. Never touches the journal: what it learns goes into the results folder."""
    base = Path(base)
    state = _record_key(base, key)
    out = [f"reader: key {state.replace('_', ' ')}"]
    if not cfg.photos.enabled:
        return out + ["reader: pictures are off"]
    _clean(base)
    calls, broken = ledger(base, now=now)
    recent = {now.astimezone(UTC).strftime("%Y-%m"), (now.astimezone(UTC).replace(day=1) - timedelta(days=1))
              .strftime("%Y-%m")}
    blocked = sorted(x for x in broken if x in recent or x.startswith("invalid"))
    if blocked:                            # its calls cannot be told apart from new jobs: no paid call meanwhile
        return out + [f"reader: the ledger ({', '.join(blocked)}) cannot be read: no paid read starts until it can"]
    done = answered(base)
    started = {c["job"] for c in calls.values()}                     # a job with any line, clean or not, has started
    pending = [j for j in jobs(base) if j["job"] not in done and j["job"] not in started]
    if not pending:
        return out + ["reader: nothing to send"]
    if cfg.photos.reader != "claude" or state != "set":
        return out + [f"reader: {len(pending)} picture(s) left for the local pass (no paid read now)"]
    t0 = clock()
    api = [client, sdk]
    for job in pending:
        if clock() - t0 > DEADLINE_S:
            out.append("reader: time is up for this pass: the other pictures wait for the next one")
            break
        when = now + timedelta(seconds=max(0.0, clock() - t0))
        if not may_spend(base, cfg, when):
            _answer(base, job, {"outcome": "cap"})
            out.append(f"reader: picture {job['photo_id']}: monthly cap")
            continue
        if api[0] is None:
            try:
                api[0], api[1] = claude.make_client(key)
            except ImportError:
                out.append("reader: the API client is not installed in this environment")
                break
        n = [0]

        months: dict = {}

        def reserve(max_tokens, ceiling, job=job, n=n, months=months):
            n[0] += 1
            at = now + timedelta(seconds=max(0.0, clock() - t0))
            month = at.astimezone(UTC).strftime("%Y-%m")
            months[n[0]] = month
            with outbox_lock(base):                 # the local pass never removes a job while this is held
                if n[0] == 1 and not (base / OUTBOX / f"{job['job']}.json").exists():
                    raise Gone(job["job"])
                _append(base, month, {"call": f"{job['job']}.{n[0]}", "kind": "reserved", "job": job["job"],
                                      "photo_id": job["photo_id"], "at": _iso(at), "usd": round(ceiling, 6),
                                      "max_tokens": max_tokens})

        def spend(call, job=job, n=n, months=months):            # next to its reservation, in that month's file
            _append(base, months[n[0]], {"call": f"{job['job']}.{n[0]}", "kind": "actual",
                                         "usd": round(float(call["usd"]), 6), "attempts": call["attempts"],
                                         "error": call["error"]})

        def may_retry(max_tokens):
            at = now + timedelta(seconds=max(0.0, clock() - t0))
            return clock() - t0 <= DEADLINE_S and may_spend(base, cfg, at, max_tokens)
        png = job_bytes(base, job)
        if png is None:
            continue                               # its bytes cannot be read or changed: never sent
        try:
            r = claude.read(api[0], cfg, png, job["note"], api[1], reserve=reserve, spend=spend,
                            may_retry=may_retry, clock=clock)
        except Gone:
            continue
        except OSError:
            log.exception("reader: the ledger could not be written: nothing was sent")
            out.append("reader: the ledger could not be written: nothing sent")
            break
        _answer(base, job, {"outcome": r.outcome, "vision": r.vision, "served": r.served, "attempts_usage": r.attempts,
                            "usd": r.usd, "tokens_in": r.tokens_in, "tokens_out": r.tokens_out,
                            "category": r.category, "request_id": r.request_id, "error": r.error, "ms": r.ms,
                            "calls": r.calls})
        out.append(f"reader: picture {job['photo_id']}: {r.outcome}")
        if r.outcome == "stop_key":
            _record_key(base, key, failed=True)
            out.append("reader: the key was refused: paid reads stop until it changes")
            break
        if r.outcome == "retry":
            out.append("reader: the API is out: the other pictures wait for the next pass")
            break
    return out


def reading_of(answer: dict) -> claude.Reading:
    """An answer from the results folder as the reading the local pass works on."""
    return claude.Reading(outcome=answer.get("outcome") or "failed", vision=answer.get("vision"),
                          served=answer.get("served"), attempts=list(answer.get("attempts_usage") or []),
                          usd=float(answer.get("usd") or 0.0), tokens_in=int(answer.get("tokens_in") or 0),
                          tokens_out=int(answer.get("tokens_out") or 0), category=answer.get("category"),
                          request_id=answer.get("request_id"), error=answer.get("error") or "",
                          ms=int(answer.get("ms") or 0), calls=int(answer.get("calls") or 0))
