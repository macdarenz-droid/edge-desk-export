"""Picture trades: his confirmation turns a reading into a journal entry (docs/JOURNAL_DESIGN.md §3 steps 3-5, §6, D9,
D15, §8.1 photo_trade and photo_trade_edit). Runs in `serve` under the journal lock (standard library only).

- Nothing counts until he confirms (D9). Red fields must be fixed or marked "don't know"; amber ones he skips are saved
  with a "check later" record. Every value's origin is an append-only photo_trade_edit row: by the reader (as read),
  by him (a fix, which becomes a labelled mistake for the test set), by the bridge or by prices.
- The first stop (D15): initial_sl is set once (a trigger refuses any change): from an order picture directly, or from a
  stop first seen on a position picture or a History row only after his "yes" to "Was this your first stop?"; a stop at
  the entry or past it on the profit side is never offered. Later stops are edits with the reason "moved".
- Where a picture belongs: a new trade, an earlier picture's trade ("photo:<id>"), or a bridge trade ("mt5:<id>": the
  picture is linked to it, the bridge's values win and no picture trade is made, D14 replaced).
- Closes: a History row (exact: exit, close time, profit; a tapped row adds the open time, stop, target, commission and
  swap), or a range from prices that he confirms (an estimate: no R until a History picture or the bridge confirms).
- R before costs and R net come from initial_sl only (match.r_values); R net only with the commission known.
- Sides (fix round item 10): a target on the wrong side of the entry is refused; a stop past the entry on the profit
  side is asked about (Question) before it is taken, however it was given (read, tapped or typed).
- His answers (fix round D-c, 11, 13): "Which trade is this?" for a picture trade a bridge trade may be (held out of R
  until he answers: linked, or "none of these"); "Was this your first stop?" on a History close, never skipped and never
  dropped; the first stop set later on the trade itself. Each is an append-only edit, by "owner", reason "answer".
"""
from __future__ import annotations

import json
import re
from datetime import datetime

from app import db
from app.photos import clocks, match
from app.photos import store as photo_store
from app.photos.checks import CRITICAL, base_symbol
from app.timeutil import from_iso, session_of, to_iso, trading_day

KINDS = ("market", "buy_limit", "sell_limit", "buy_stop", "sell_stop")
PENDING = ("buy_limit", "sell_limit", "buy_stop", "sell_stop")
ROLES = ("entry", "sl", "tp", "none")
FIELDS = ("side", "order_kind", "lots", "entry", "sl", "tp")
REF = re.compile(r"(photo|mt5):([0-9]{1,12})")
MOVE_EPS = 0.05          # pips: a stop or target that differs by less is the same level
R_UNKNOWN = "R unknown: set the first stop"
HELD = "Which trade is this?"


class Question(ValueError):
    """A value that may be a slip: asked before it is taken (the route answers 409 with the question)."""

    def __init__(self, text: str, key: str):
        super().__init__(text)
        self.key = key


def _sides(values: dict, body: dict, pip: float) -> None:
    """Item 10: a target on the wrong side of the entry is refused; a stop past the entry on the profit side is asked."""
    side, entry = values.get("side"), values.get("entry")
    if side not in ("buy", "sell") or entry is None:
        return
    sign = 1 if side == "buy" else -1
    word = "Buy" if side == "buy" else "Sell"
    tp, sl = values.get("tp"), values.get("sl")
    if tp is not None and sign * (tp - entry) <= MOVE_EPS * pip:
        raise ValueError(f"target: a {word}'s target is {'above' if side == 'buy' else 'below'} its entry")
    if sl is not None and sign * (entry - sl) < -MOVE_EPS * pip and body.get("stop_side_ok") is not True:
        raise Question(f"The stop {sl:.5f} is on the profit side of this {word}'s entry {entry:.5f}: keep it?",
                       "stop_side")


def _num_text(v) -> str | None:
    return None if v is None else (repr(v) if isinstance(v, float) else str(v))


def _price(v, name: str):
    if v is None:
        return None
    if not isinstance(v, (int, float)) or isinstance(v, bool) or not 0.5 < float(v) < 3.0:
        raise ValueError(f"{name}: a EUR/USD price such as 1.30482")
    return round(float(v), 5)


def _lots(v):
    if v is None:
        return None
    if not isinstance(v, (int, float)) or isinstance(v, bool) or not 0 < float(v) <= 100 \
            or abs(round(float(v) / 0.01) * 0.01 - float(v)) > 1e-9:
        raise ValueError("lots: above 0, in steps of 0.01")
    return round(float(v), 2)


def _clean(fields: dict) -> dict:
    out = {}
    side = fields.get("side")
    if side is not None and side not in ("buy", "sell"):
        raise ValueError("side: buy or sell")
    out["side"] = side
    kind = fields.get("order_kind")
    if kind is not None and kind not in KINDS:
        raise ValueError(f"order_kind: one of {', '.join(KINDS)}")
    out["order_kind"] = kind
    out["lots"] = _lots(fields.get("lots"))
    for name in ("entry", "sl", "tp"):
        out[name] = _price(fields.get(name), name)
    return out


def _reading(conn, photo_id: int) -> tuple[dict, dict]:
    p = conn.execute("SELECT * FROM photo WHERE id = ?", (photo_id,)).fetchone()
    if p is None or p["state"] in ("deleted", "receiving", "queued", "failed"):
        raise photo_store.NotFound("no such picture")
    r = conn.execute("SELECT * FROM photo_read WHERE photo_id = ? ORDER BY id DESC LIMIT 1", (photo_id,)).fetchone()
    if r is None:
        raise ValueError("this picture has not been read yet")
    return dict(p), json.loads(r["merged_json"] or "{}") | {"_read_id": r["id"]}


def _edit(conn, tid: int, field: str, old, new, by: str, reason: str, read_id, now: datetime) -> None:
    conn.execute("INSERT INTO photo_trade_edit (photo_trade_id, at_utc, field, old, new, by, reason, photo_read_id)"
                 " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                 (tid, to_iso(now), field, _num_text(old), _num_text(new), by, reason, read_id))


def _same(a, b, pip: float) -> bool:
    if a is None or b is None:
        return a is b
    if isinstance(a, float) or isinstance(b, float):
        return abs(float(a) - float(b)) <= MOVE_EPS * pip
    return a == b


def _link(conn, photo_id: int, ref: str, role: str, now: datetime) -> None:
    conn.execute("INSERT OR IGNORE INTO photo_link (photo_id, trade_ref, role, at_utc) VALUES (?, ?, ?, ?)",
                 (photo_id, ref, role, to_iso(now)))
    conn.execute("UPDATE photo SET state = 'confirmed', confirmed_utc = COALESCE(confirmed_utc, ?) WHERE id = ?",
                 (to_iso(now), photo_id))


def _from_labels(merged: dict, labels: dict, typed: dict) -> tuple[dict, str]:
    """Tap to label (D7): each numbered line is entry, stop, target or not his; he taps buy or sell and the lots."""
    by_n = {str(ln["n"]): ln for ln in merged.get("lines") or ()}
    got: dict = {}
    for n, role in labels.items():
        if role not in ROLES or str(n) not in by_n:
            raise ValueError("labels: each line is entry, sl, tp or none")
        if role == "none":
            continue
        if role in got:
            raise ValueError(f"labels: one line only can be the {role}")
        got[role] = by_n[str(n)]
    if "entry" not in got:
        raise ValueError("labels: tap the entry line")
    entry_line = got["entry"]
    position = entry_line.get("colour") in ("blue", "red")
    side = typed.get("side")
    kind = typed.get("order_kind")
    if not position and kind is None and side in ("buy", "sell"):
        bid = merged.get("live_bid")
        if bid is not None:
            below = entry_line["price"] < bid
            kind = f"{side}_{'limit' if below == (side == 'buy') else 'stop'}"
    values = {"side": side, "lots": typed.get("lots"), "order_kind": None if position else kind,
              "entry": entry_line["price"], "sl": got.get("sl", {}).get("price"), "tp": got.get("tp", {}).get("price")}
    return values, ("open" if position else "order")


def confirm(conn, cfg, photo_id: int, body: dict, now: datetime) -> dict:
    """His "Looks right" (or his fixed values). Called under the journal lock. Returns {"trade_ref", "trade_id",
    "r_unknown"}."""
    p, merged = _reading(conn, photo_id)
    if merged.get("kind") == "history" or body.get("close"):
        return _close_history(conn, cfg, p, merged, body, now)
    if merged.get("status", "ok") != "ok":
        raise ValueError("this picture is not a EUR/USD trade")
    pip = cfg.instrument.pip_size
    fixed, dont_know = set(body.get("fixed") or ()), set(body.get("dont_know") or ())
    labels = body.get("labels")
    if labels:
        values, role = _from_labels(merged, labels, body.get("fields") or {})
        values = _clean(values)
        read_vals, states, t_read = {}, {}, None
        by_default = "owner"
    else:
        pick = body.get("pick", 0)
        trades_read = merged.get("trades") or []
        if not isinstance(pick, int) or not 0 <= pick < len(trades_read):
            raise ValueError("pick: which trade on the picture")
        t_read = trades_read[pick]
        read_vals = {n: f.get("value") for n, f in t_read["fields"].items()}
        states = {n: f.get("state") for n, f in t_read["fields"].items()}
        values = _clean({**{n: read_vals.get(n) for n in FIELDS}, **(body.get("fields") or {})})
        for name in CRITICAL:
            if states.get(name) == "red" and name not in fixed and name not in dont_know:
                raise ValueError(f"{name}: fix it or mark it don't know")
        role = "order" if t_read["role"] == "pending" else "open"
        by_default = "reader"
    for name in dont_know:
        if name in values:
            values[name] = None
    if values["side"] is None or values["entry"] is None or values["lots"] is None:
        raise ValueError("side, entry and lots are needed")
    _sides(values, body, pip)
    moved = bool(t_read and t_read.get("moved"))
    if values["sl"] is not None:
        sign = 1 if values["side"] == "buy" else -1
        moved = moved or sign * (values["entry"] - values["sl"]) <= 1e-9
    ref = body.get("trade") or "new"
    at = from_iso(p["picture_utc"]) if p.get("picture_utc") else from_iso(p["received_utc"])
    with db.transaction(conn):
        if ref.startswith("mt5:"):
            if not photo_store.trade_exists(conn, ref):
                raise photo_store.NotFound("no such trade")
            _link(conn, photo_id, ref, role, now)
            return {"trade_ref": ref, "trade_id": None, "r_unknown": False}
        first_ok = values["sl"] is not None and not moved
        from_order = role == "order"
        wants_first = from_order or (body.get("first_stop") is True and first_ok)
        if ref == "new":
            tid = conn.execute(
                "INSERT INTO photo_trade (created_utc, symbol, side, order_kind, lots, entry, sl, tp, placed_how,"
                " trading_day, session, state) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmed')",
                (to_iso(now), base_symbol(merged.get("symbol")) or "EURUSD", values["side"], values["order_kind"],
                 values["lots"], values["entry"], values["sl"], values["tp"], "unknown" if from_order else None,
                 trading_day(at).isoformat(), session_of(at))).lastrowid
            for name in FIELDS:
                v = values[name]
                if v is None:
                    continue
                r = read_vals.get(name)
                if labels or _same(v, r, pip) or name not in fixed:
                    _edit(conn, tid, name, None, v, by_default, "read", merged["_read_id"], now)
                else:
                    _edit(conn, tid, name, r, v, "owner", "fix", merged["_read_id"], now)
            if wants_first and first_ok:
                conn.execute("UPDATE photo_trade SET initial_sl = ?, initial_sl_how = ? WHERE id = ?",
                             (values["sl"], "order" if from_order else "confirmed", tid))
                _edit(conn, tid, "initial_sl", None, values["sl"], "reader" if from_order else "owner", "read",
                      merged["_read_id"], now)
            later = [n for n in CRITICAL if states.get(n) == "amber" and n not in fixed and values.get(n) is not None]
            if later:
                _edit(conn, tid, "check_later", None, ",".join(later), "reader", "read", merged["_read_id"], now)
        else:
            m = REF.fullmatch(ref)
            if not m or m.group(1) != "photo":
                raise ValueError("trade: new, photo:<id> or mt5:<id>")
            tid = int(m.group(2))
            t = conn.execute("SELECT * FROM photo_trade WHERE id = ?", (tid,)).fetchone()
            if t is None or t["state"] == "void":
                raise ValueError("trade: no such picture trade")
            if t["side"] != values["side"] or abs((t["lots"] or 0) - values["lots"]) > 0.005:
                raise ValueError("trade: not the same side and lots")
            by = lambda name: "owner" if name in fixed else "reader"  # noqa: E731
            for name in ("sl", "tp"):
                v = values[name]
                if v is not None and not _same(v, t[name], pip):
                    conn.execute(f"UPDATE photo_trade SET {name} = ? WHERE id = ?", (v, tid))
                    _edit(conn, tid, name, t[name], v, by(name), "moved" if t[name] is not None else "read",
                          merged["_read_id"], now)
            if t["entry"] is None:
                conn.execute("UPDATE photo_trade SET entry = ? WHERE id = ?", (values["entry"], tid))
                _edit(conn, tid, "entry", None, values["entry"], by("entry"), "read", merged["_read_id"], now)
            if role == "open" and t["order_kind"] in PENDING and t["fill_utc"] is None and t["fill_how"] is None:
                est = match.fill_estimate(conn, cfg, t)
                if est:
                    conn.execute("UPDATE photo_trade SET fill_utc = ?, fill_how = 'prices' WHERE id = ?",
                                 (to_iso(est["utc"]), tid))
                    _edit(conn, tid, "fill_utc", None, to_iso(est["utc"]), "prices", "read", merged["_read_id"], now)
                else:
                    conn.execute("UPDATE photo_trade SET fill_how = 'picture' WHERE id = ?", (tid,))
            if t["initial_sl"] is None and wants_first and first_ok:
                conn.execute("UPDATE photo_trade SET initial_sl = ?, initial_sl_how = ? WHERE id = ?",
                             (values["sl"], "order" if from_order else "confirmed", tid))
                _edit(conn, tid, "initial_sl", None, values["sl"], "reader" if from_order else "owner", "read",
                      merged["_read_id"], now)
        _link(conn, photo_id, f"photo:{tid}", role, now)
        initial = conn.execute("SELECT initial_sl FROM photo_trade WHERE id = ?", (tid,)).fetchone()[0]
    return {"trade_ref": f"photo:{tid}", "trade_id": tid, "r_unknown": initial is None}


def ask_first_stop(t, row: dict, pip: float) -> bool:
    """Item 11: "Was this your first stop?" is asked on a History close only while the trade has no first stop and the
    row's stop sits on the loss side of the entry (not at it)."""
    sl = row.get("sl")
    if t["initial_sl"] is not None or sl is None or t["entry"] is None:
        return False
    sign = 1 if t["side"] == "buy" else -1
    return sign * (t["entry"] - sl) > MOVE_EPS * pip


def _close_history(conn, cfg, p: dict, merged: dict, body: dict, now: datetime) -> dict:
    """A History row closes an open picture trade (or replaces a close estimated from prices). A row whose read failed a
    check is closed from the numbers he types: the exit price, the close time and the profit (item 14)."""
    pip = cfg.instrument.pip_size
    rows = merged.get("history_rows") or []
    k = body.get("row", 0)
    if not isinstance(k, int) or not 0 <= k < len(rows):
        raise ValueError("row: which History row")
    row = dict(rows[k])
    typed = body.get("fields") or {}
    if set(typed) - {"close_price", "close_time", "profit", "commission", "swap"}:
        raise ValueError("fields: close_price, close_time, profit, commission and swap only")
    for name in ("profit", "commission", "swap"):
        if name in typed and typed[name] is not None and (not isinstance(typed[name], (int, float))
                                                          or isinstance(typed[name], bool)):
            raise ValueError(f"{name}: money such as -136.00")
    for name in ("close_price", "profit", "commission", "swap"):
        if name in typed:
            row[name] = typed[name] if name != "close_price" else _price(typed[name], "close_price")
    if "close_time" in typed:
        row["close_time"] = typed["close_time"]
    failed = not row.get("ok", False)
    if failed and not all(typed.get(n) is not None for n in ("close_price", "close_time", "profit")):
        raise ValueError("this row failed a check: type the exit price, close time and profit")
    m = REF.fullmatch(str(body.get("close") or ""))
    if not m or m.group(1) != "photo":
        raise ValueError("close: photo:<id>")
    tid = int(m.group(2))
    try:
        found = match.history_candidates(conn, cfg, row, loose=failed)
    except ValueError:
        raise ValueError("close_time: YYYY.MM.DD hh:mm:ss as MT5 shows it") from None
    if tid not in {c["id"] for c in found}:
        raise ValueError("close: this row is not that trade (side, lots, open price or time)")
    t = conn.execute("SELECT * FROM photo_trade WHERE id = ?", (tid,)).fetchone()
    try:
        closed = clocks.server_to_utc(datetime.strptime(row["close_time"], "%Y.%m.%d %H:%M:%S"))
    except (TypeError, ValueError):
        raise ValueError("close_time: YYYY.MM.DD hh:mm:ss as MT5 shows it") from None
    first = body.get("first_stop")
    asked = ask_first_stop(t, row, pip)
    if asked and first not in (True, False):
        raise ValueError("Was this your first stop? Answer it first")
    if first is True and not asked:
        raise ValueError("this row's stop cannot be the first stop: it is missing, at the entry or past it")
    exit_price = row["close_price"]
    rid = merged["_read_id"]
    with db.transaction(conn):
        sl_now = t["sl"]
        stop_at_close = row.get("sl")
        if stop_at_close is not None and not _same(stop_at_close, sl_now, pip):
            conn.execute("UPDATE photo_trade SET sl = ? WHERE id = ?", (stop_at_close, tid))
            _edit(conn, tid, "sl", sl_now, stop_at_close, "reader", "moved" if sl_now is not None else "read", rid, now)
            sl_now = stop_at_close
        initial = t["initial_sl"]
        if asked and first is True:
            conn.execute("UPDATE photo_trade SET initial_sl = ?, initial_sl_how = 'confirmed' WHERE id = ?",
                         (stop_at_close, tid))
            _edit(conn, tid, "initial_sl", None, stop_at_close, "owner", "answer", rid, now)
            initial = stop_at_close
        elif asked and first is False:
            _edit(conn, tid, "first_stop", None, "no", "owner", "answer", rid, now)
        if row.get("open_time") and t["fill_how"] in (None, "prices", "picture"):
            fill = clocks.server_to_utc(datetime.strptime(row["open_time"], "%Y.%m.%d %H:%M:%S"))
            conn.execute("UPDATE photo_trade SET fill_utc = ?, fill_how = 'history' WHERE id = ?", (to_iso(fill), tid))
            _edit(conn, tid, "fill_utc", t["fill_utc"], to_iso(fill), "reader", "close", rid, now)
        kind = "manual"
        if sl_now is not None and abs(exit_price - sl_now) <= 0.5 * pip + 1e-9:
            kind = "sl"
        elif t["tp"] is not None and abs(exit_price - t["tp"]) <= 0.5 * pip + 1e-9:
            kind = "tp"
        before, net, _ = match.r_values(t["side"], t["entry"], initial, exit_price, t["lots"], row.get("profit"),
                                        row.get("commission"), row.get("swap"), exact=True)
        conn.execute("UPDATE photo_trade SET exit_utc_from = ?, exit_utc_to = ?, exit_price = ?, exit_kind = ?,"
                     " exit_how = 'history', profit = ?, commission = ?, swap = ?, r_before_costs = ?, r_net = ?,"
                     " close_trading_day = ?, state = 'closed' WHERE id = ?",
                     (to_iso(closed), to_iso(closed), exit_price, kind, row.get("profit"), row.get("commission"),
                      row.get("swap"), before, net, trading_day(closed).isoformat(), tid))
        by = "owner" if typed else "reader"
        for name, old, new in (("exit_price", t["exit_price"], exit_price), ("exit_utc", t["exit_utc_to"],
                                                                              to_iso(closed)),
                               ("profit", t["profit"], row.get("profit")), ("commission", t["commission"],
                                                                            row.get("commission")),
                               ("swap", t["swap"], row.get("swap"))):
            if new is not None:
                _edit(conn, tid, name, old, new, by, "close", rid, now)
        _link(conn, p["id"], f"photo:{tid}", "close", now)
    return {"trade_ref": f"photo:{tid}", "trade_id": tid, "r_unknown": initial is None}


def set_first_stop(conn, cfg, tid: int, price, now: datetime) -> dict:
    """Item 13: his first stop, set on the trade later (once; on the loss side of the entry); R follows when the exit is
    exact."""
    pip = cfg.instrument.pip_size
    price = _price(price, "first stop")
    t = conn.execute("SELECT * FROM photo_trade WHERE id = ?", (tid,)).fetchone()
    if t is None or t["state"] not in ("confirmed", "closed"):
        raise photo_store.NotFound("no such picture trade")
    if t["initial_sl"] is not None:
        raise ValueError("the first stop is already set")
    if price is None or t["entry"] is None:
        raise ValueError("first stop: a EUR/USD price such as 1.30414")
    sign = 1 if t["side"] == "buy" else -1
    if sign * (t["entry"] - price) <= MOVE_EPS * pip:
        raise ValueError("first stop: on the loss side of the entry")
    exact = t["exit_how"] in ("history", "bridge")
    before, net, _ = match.r_values(t["side"], t["entry"], price, t["exit_price"], t["lots"], t["profit"],
                                    t["commission"], t["swap"], exact=exact)
    with db.transaction(conn):
        conn.execute("UPDATE photo_trade SET initial_sl = ?, initial_sl_how = 'confirmed', r_before_costs = ?,"
                     " r_net = ? WHERE id = ?", (price, before, net, tid))
        _edit(conn, tid, "initial_sl", None, price, "owner", "answer", None, now)
    return get(conn, cfg, tid)


def _bridge_label(b) -> str:
    return (f"Position · {(b['side'] or '').capitalize()} {b['volume']:.2f} · {b['open_price']:.5f} · opened "
            f"{from_iso(b['open_utc']).astimezone(clocks.LONDON):%a} {clocks.fmt_lon_melb(from_iso(b['open_utc']))}")


def bridge_doubts(conn, cfg, t) -> list[dict]:
    """The bridge trades that may be this picture trade and that he has not ruled out (D-c), none taken by another."""
    if t["linked_trade_id"] is not None or t["state"] not in ("confirmed", "closed"):
        return []
    taken = {r[0] for r in conn.execute("SELECT linked_trade_id FROM photo_trade WHERE linked_trade_id IS NOT NULL")}
    ruled_out = set()
    for r in conn.execute("SELECT new FROM photo_trade_edit WHERE photo_trade_id = ? AND field = 'bridge_none'",
                          (t["id"],)):
        ruled_out |= {int(x) for x in (r[0] or "").split(",") if x.isdigit()}
    return [b for b in match.bridge_plausible(conn, cfg, t) if b["id"] not in taken and b["id"] not in ruled_out]


def answer_bridge(conn, cfg, tid: int, ref: str, now: datetime) -> dict:
    """His answer to "Which trade is this?": one of the bridge trades offered (the picture trade is linked to it and the
    bridge row is the record), or "none" (those offered are ruled out; a new one would be asked about again)."""
    t = conn.execute("SELECT * FROM photo_trade WHERE id = ?", (tid,)).fetchone()
    if t is None:
        raise photo_store.NotFound("no such picture trade")
    doubts = bridge_doubts(conn, cfg, t)
    if ref == "none":
        if not doubts:
            raise ValueError("nothing to answer: no bridge trade is offered for this trade")
        with db.transaction(conn):
            _edit(conn, tid, "bridge_none", None, ",".join(str(b["id"]) for b in doubts), "owner", "answer", None, now)
        return get(conn, cfg, tid)
    m = REF.fullmatch(str(ref or ""))
    if not m or m.group(1) != "mt5" or int(m.group(2)) not in {b["id"] for b in doubts}:
        raise ValueError("trade: one of the trades offered, or none")
    _link_bridge(conn, tid, int(m.group(2)), "owner", "answer", now)
    return get(conn, cfg, tid)


def _link_bridge(conn, tid: int, bid: int, by: str, reason: str, now: datetime) -> None:
    with db.transaction(conn):
        conn.execute("UPDATE photo_trade SET linked_trade_id = ? WHERE id = ?", (bid, tid))
        _edit(conn, tid, "linked_trade_id", None, bid, by, reason, None, now)
        for r in conn.execute("SELECT photo_id, role FROM photo_link WHERE trade_ref = ?", (f"photo:{tid}",)):
            conn.execute("INSERT OR IGNORE INTO photo_link (photo_id, trade_ref, role, at_utc) VALUES (?, ?, ?, ?)",
                         (r["photo_id"], f"mt5:{bid}", r["role"], to_iso(now)))


def close_from_prices(conn, cfg, tid: int, now: datetime) -> dict:
    """He confirms the close the prices show ("stopped 15:08-15:20 London · 2:08-2:20 am Melb.?"): an estimate, so
    no R until a History picture or the bridge confirms it."""
    t = conn.execute("SELECT * FROM photo_trade WHERE id = ?", (tid,)).fetchone()
    if t is None or t["state"] != "confirmed":
        raise ValueError("no open picture trade with that id")
    est = match.exit_estimate(conn, cfg, t)
    if est is None:
        raise ValueError("no close seen in the prices yet")
    with db.transaction(conn):
        conn.execute("UPDATE photo_trade SET exit_utc_from = ?, exit_utc_to = ?, exit_price = ?, exit_kind = ?,"
                     " exit_how = 'prices', close_trading_day = ?, state = 'closed' WHERE id = ?",
                     (to_iso(est["from"]), to_iso(est["to"]), est["price"], est["kind"],
                      trading_day(est["to"]).isoformat(), tid))
        _edit(conn, tid, "exit_price", None, est["price"], "prices", "close", None, now)
        _edit(conn, tid, "exit_utc", None, f"{to_iso(est['from'])}/{to_iso(est['to'])}", "prices", "close", None, now)
    return get(conn, cfg, tid)


def link_to_bridge(conn, cfg, now: datetime) -> list[tuple[int, int]]:
    """A picture trade whose only plausible bridge trade is exactly it (the same lots and the same price) is linked to
    it: the bridge row is the record from then on. Several, or a fill that slipped, are asked, never picked (D-c)."""
    pip = cfg.instrument.pip_size
    out = []
    for t in conn.execute("SELECT * FROM photo_trade WHERE state IN ('confirmed','closed') AND linked_trade_id IS NULL"
                          " ORDER BY id").fetchall():
        if t["entry"] is None or t["lots"] is None:
            continue
        doubts = bridge_doubts(conn, cfg, t)
        if len(doubts) != 1:
            continue
        b = doubts[0]
        if abs(b["volume"] - t["lots"]) > match.LOTS_EPS or abs(b["open_price"] - t["entry"]) > MOVE_EPS * pip + 1e-9:
            continue
        _link_bridge(conn, t["id"], b["id"], "bridge", "read", now)
        out.append((t["id"], b["id"]))
    return out


def r_text(t, held: bool = False) -> str:
    if held:
        return HELD
    if t["initial_sl"] is None:
        return R_UNKNOWN
    if t["exit_how"] == "prices":
        return "Estimated from prices: not in R stats"
    if t["exit_price"] is not None and t["r_net"] is None:
        return "R before commission and swap"
    return ""


def get(conn, cfg, tid: int) -> dict:
    t = conn.execute("SELECT * FROM photo_trade WHERE id = ?", (tid,)).fetchone()
    if t is None:
        raise photo_store.NotFound("no such picture trade")
    _, _, risk = match.r_values(t["side"], t["entry"], t["initial_sl"], None, t["lots"], None, None, None, False)
    pictures = [{"id": r["photo_id"], "role": r["role"]} for r in conn.execute(
        "SELECT photo_id, role FROM photo_link WHERE trade_ref = ? ORDER BY at_utc", (f"photo:{tid}",))]
    fill = match.fill_estimate(conn, cfg, t)
    exit_est = match.exit_estimate(conn, cfg, t)
    edits = [dict(r) for r in conn.execute("SELECT field, old, new, by, reason, at_utc FROM photo_trade_edit"
                                           " WHERE photo_trade_id = ? ORDER BY id", (tid,))]
    doubts = bridge_doubts(conn, cfg, t)
    return {"trade": dict(t), "risk_usd": risk, "r_text": r_text(t, bool(doubts)), "pictures": pictures,
            "edits": edits, "held": bool(doubts),
            "bridge_choices": [{"ref": f"mt5:{b['id']}", "label": _bridge_label(b)} for b in doubts],
            "fill_estimate": None if fill is None else {"utc": to_iso(fill["utc"]),
                                                        "text": "filled about " + clocks.fmt_lon_melb(fill["utc"])
                                                        + ", from prices"},
            "exit_estimate": None if exit_est is None else {"kind": exit_est["kind"], "price": exit_est["price"],
                                                            "from": to_iso(exit_est["from"]),
                                                            "to": to_iso(exit_est["to"]), "text": exit_est["text"]}}


def counts_in_r_stats(t: dict) -> bool:
    """A picture trade counts in R stats only with initial_sl, an exact exit and R net, and not while a bridge trade
    may be the same one (held, D-c); the others are listed apart."""
    return t.get("source") != "photo" or (t.get("r_net") is not None and not t.get("held"))


def journal_rows(conn, cfg) -> list[dict]:
    """Confirmed picture trades as the Journal and Calendar read trades (source "photo"); one linked to a bridge
    trade is left out (the bridge row is the record)."""
    out = []
    for t in conn.execute("SELECT * FROM photo_trade WHERE state IN ('confirmed','closed') AND linked_trade_id IS NULL"
                          " ORDER BY id"):
        doubts = bridge_doubts(conn, cfg, t)
        held = bool(doubts)
        if t["fill_utc"] and t["fill_how"] in ("history", "bridge", "confirmed"):
            opened, open_how = from_iso(t["fill_utc"]), "fill"          # read from a History picture, or given
        else:
            opened, open_how = match.seen_times(conn, t)[0], "picture"  # the picture's time, labelled as such
        net = None
        if t["profit"] is not None and t["commission"] is not None:
            net = t["profit"] + t["commission"] + (t["swap"] or 0.0)
        _, _, risk = match.r_values(t["side"], t["entry"], t["initial_sl"], None, t["lots"], None, None, None, False)
        out.append({
            "id": None, "ref": f"photo:{t['id']}", "source": "photo", "book": "mt5", "account_alias": None,
            "symbol": t["symbol"], "side": t["side"], "volume": t["lots"],
            "status": "closed" if t["exit_price"] is not None else "open",
            "open_utc": to_iso(opened), "open_how": open_how, "open_price": t["entry"], "initial_sl": t["initial_sl"],
            "initial_tp": t["tp"],
            "close_utc": t["exit_utc_to"], "close_price": t["exit_price"],
            "close_reason": t["exit_kind"] if t["exit_kind"] in ("sl", "tp", "manual") else None,
            "sl_at_exit": t["sl"], "profit": t["profit"], "commission": t["commission"], "swap": t["swap"],
            "fee": 0.0, "net_profit": net, "risk_money": risk,
            "stop_pips": None if t["initial_sl"] is None or t["entry"] is None
            else round(abs(t["entry"] - t["initial_sl"]) / cfg.instrument.pip_size, 1),
            "r_net": None if held else t["r_net"], "r_gross": None if held else t["r_before_costs"],
            "balance_at_open": None, "pct_of_balance": None,
            "trading_day": t["trading_day"], "close_trading_day": t["close_trading_day"], "session": t["session"],
            "flags": [], "tag": None, "decision": None, "would_take": None, "management": None, "note": t["note"],
            "choice_id": None, "account_linked": None, "estimated": t["exit_how"] == "prices",
            "r_unknown": t["initial_sl"] is None, "r_text": r_text(t, held), "held": held,
            "bridge_choices": [{"ref": f"mt5:{b['id']}", "label": _bridge_label(b)} for b in doubts]})
    return out
