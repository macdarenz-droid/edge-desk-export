#!/usr/bin/env python3
"""Build the Edge Desk release for the one-paste server install (coordinator ruling, 17 Oct 2026: the research repo
stays off the server; the release goes to the owner's private export repo under release/, and the server fetches it
with EDGE_EXPORT_TOKEN).

  python3 desk/deploy/make_release.py --out /tmp/edge-release --oanda-figures-ok "<ruling>" [--commit <sha>] \
      [--export-repo macdarenz-droid/edge-desk-export] [--branch main]

Release hold (fix round 2, red team B3): the release carries figures computed on OANDA practice prices, from before
the news build: the tested lines (app/checklist/tested.json, app/suggest/records.json) and the lead bundle's research
files (for example research/round53/FROZEN.json, research/departments/COST/COST_MODEL.json). OANDA's terms read "not
clearly allowed" for publishing figures derived from its prices (coordinator ruling R7), and edge-desk-export is
public. So no release is built until the coordinator rules on them, with the owner told: --oanda-figures-ok names that
ruling, and without it nothing is left in --out to publish (README section 12).

Run in a checkout of this repo that holds both the commit and STATS's pinned commit (for the lead bundle). It writes:
  edge-desk-<commit12>.tar.gz   desk/{app,config,deploy,bridge,requirements*.txt} at the commit (from git objects, so
                                the working tree does not matter) plus lead-bundle/ (deploy/make_lead_bundle.py),
                                under edge-desk/; reproducible: sorted members, owner 0, fixed time, gzip time 0
  install.sh                    deploy/install/install.sh.in with the host guard copied in and the tarball's sha256
  OANDA_FIGURES_RULING.txt      when the tarball carries OANDA_FIGURES: the ruling given with --oanda-figures-ok, the
                                tarball's name and sha256 and how many such files it carries, so a published release
                                shows which ruling allowed it (fix round 3, red team)
  SHA256SUMS                    every file above
and prints the two lines the owner pastes. Put every file above in the export repo's release/ folder.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import re
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
FIXED_MTIME = 1735689600                      # 2025-01-01 00:00 UTC, for every member
PATHS = ("desk/app", "desk/config", "desk/deploy", "desk/bridge", "desk/requirements.txt",
         "desk/requirements-reader.txt")              # the picture reader's own packages (its own virtualenv)
SKIP = re.compile(r"(^|/)(__pycache__|tests?)(/|$)|\.pyc$")
# Coordinator ruling R7 (OANDA's terms: publishing figures derived from its prices is not clearly allowed): the move
# record is built on the owner's server only. A release that would carry one is refused, wherever it sits.
REFUSED_NAMES = ("move_record.json", "reaction_table.json")
# ... and a renamed copy (fix round 1, red team M3): any JSON member that holds a key of the record or of the research
# table (app/news/moverecord.py writes them; the shipped event list has none of them).
RECORD_KEYS = (b'"median_60m_pips"', b'"quiet_median_60m_pips"', b'"beat_quiet_p80_share"', b'"median_abs_pips_60m"',
               b'"share_above_base_p80_60"')


# Members that hold backtest or cost figures computed on OANDA practice prices (fix round 2; README section 12): the
# release is held until the coordinator rules on them (main() --oanda-figures-ok). A path ending in "/" is a folder.
OANDA_FIGURES = ("app/checklist/tested.json", "app/suggest/records.json", "lead-bundle/",
                 "app/aplus/record.json")      # the A+ tested record (A22's 2010-2012 parity on OANDA prices)


def _holds_record(name: str, data: bytes) -> bool:
    return name.rsplit("/", 1)[-1] in REFUSED_NAMES or (name.lower().endswith(".json")
                                                       and any(k in data for k in RECORD_KEYS))
TOP = "edge-desk"
REPO_RE = re.compile(r"[A-Za-z0-9-]{1,39}/[A-Za-z0-9._-]{1,100}")
API = "https://api.github.com"


def _git(repo: Path, *args: str) -> bytes:
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, check=True).stdout


def _info(name: str, size: int, mode: int, kind=tarfile.REGTYPE) -> tarfile.TarInfo:
    ti = tarfile.TarInfo(name)
    ti.size, ti.mode, ti.type, ti.mtime = size, mode, kind, FIXED_MTIME
    ti.uid = ti.gid = 0
    ti.uname = ti.gname = ""
    return ti


def _members(repo: Path, commit: str, bundle_dir: Path | None) -> dict[str, tuple[bytes, int]]:
    files: dict[str, tuple[bytes, int]] = {}
    raw = _git(repo, "archive", "--format=tar", commit, *PATHS)
    with tarfile.open(fileobj=io.BytesIO(raw)) as tf:
        for m in tf.getmembers():
            if not m.isfile():
                if m.issym() or m.islnk():
                    raise SystemExit(f"make_release: links are not shipped: {m.name}")
                continue
            rel = m.name[len("desk/"):]
            if SKIP.search(rel):
                continue
            data = tf.extractfile(m).read()
            if _holds_record(rel, data):
                raise SystemExit(f"make_release: {rel} holds figures from OANDA prices and never ships (ruling R7)")
            files[f"{TOP}/{rel}"] = (data, 0o755 if m.mode & 0o111 else 0o644)
    if bundle_dir is not None:
        for p in sorted(bundle_dir.rglob("*")):
            if p.is_symlink():
                raise SystemExit(f"make_release: links are not shipped: {p}")
            # shipped exactly as built: its manifest lists every file, STATS's tests/ included
            if p.is_file():
                data = p.read_bytes()
                if _holds_record(p.name, data):
                    raise SystemExit(f"make_release: {p.name} never ships (ruling R7)")
                files[f"{TOP}/lead-bundle/{p.relative_to(bundle_dir).as_posix()}"] = (data, 0o644)
    return files


def build_tarball(repo: Path, commit: str, out_dir: Path, bundle_dir: Path | None) -> Path:
    commit = _git(repo, "rev-parse", "--verify", f"{commit}^{{commit}}").decode().strip()
    files = _members(repo, commit, bundle_dir)
    dirs = {"/".join(n.split("/")[:i]) for n in files for i in range(1, n.count("/") + 1)}
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w", format=tarfile.PAX_FORMAT) as tf:
        for name in sorted(dirs | set(files)):
            if name in files:
                data, mode = files[name]
                tf.addfile(_info(name, len(data), mode), io.BytesIO(data))
            else:
                tf.addfile(_info(name, 0, 0o755, tarfile.DIRTYPE))
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"edge-desk-{commit[:12]}.tar.gz"
    with open(path, "wb") as fh, gzip.GzipFile(filename="", mode="wb", fileobj=fh, mtime=0, compresslevel=9) as gz:
        gz.write(buf.getvalue())
    return path


def oanda_figures(tarball: Path) -> list[str]:
    """The release members (paths under edge-desk/) that OANDA_FIGURES names."""
    out = []
    with tarfile.open(tarball) as tf:
        for m in tf.getmembers():
            rel = m.name[len(TOP) + 1:] if m.name.startswith(TOP + "/") else ""
            if m.isfile() and any(rel == f or (f.endswith("/") and rel.startswith(f)) for f in OANDA_FIGURES):
                out.append(rel)
    return sorted(out)


RULING_NAME = "OANDA_FIGURES_RULING.txt"


def ruling_text(ruling: str, tarball: str, tarball_sha256: str, commit: str, n: int) -> str:
    """The record, next to install.sh, of the ruling that let OANDA-derived figures ship (whitespace collapsed)."""
    return (f"Release {tarball} (sha256 {tarball_sha256}, commit {commit}) carries {n} files with figures computed on "
            "OANDA practice prices (deploy/README.md section 12).\n"
            f"Allowed by: {' '.join(ruling.split())}\n")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def render_install(export_repo: str, branch: str, release_name: str, release_sha256: str, commit: str) -> str:
    if not REPO_RE.fullmatch(export_repo) or export_repo.split("/")[1].lower() == "forex-signal":
        raise ValueError("the export repo must be owner/name, never the research repo")
    if not re.fullmatch(r"[A-Za-z0-9._/-]{1,100}", branch) or not re.fullmatch(r"[A-Za-z0-9._-]{1,100}", release_name):
        raise ValueError("bad branch or release name")
    if not re.fullmatch(r"[0-9a-f]{64}", release_sha256) or not re.fullmatch(r"[0-9a-f]{3,40}", commit):
        raise ValueError("bad sha256 or commit")
    text = (HERE / "install" / "install.sh.in").read_text()
    guard = (HERE / "install" / "guard.sh").read_text()
    for key, value in (("@@EXPORT_REPO@@", export_repo), ("@@EXPORT_BRANCH@@", branch),
                       ("@@RELEASE_NAME@@", release_name), ("@@RELEASE_SHA256@@", release_sha256),
                       ("@@COMMIT@@", commit), ("@@GUARD@@", guard.rstrip("\n"))):
        if key not in text:
            raise ValueError(f"{key} missing from install.sh.in")
        text = text.replace(key, value)
    return text


def paste_lines(export_repo: str, branch: str, install_sha256: str) -> list[str]:
    url = f"{API}/repos/{export_repo}/contents/release/install.sh?ref={branch}"
    line = ("curl -fsS --proto =https -K <(printf 'header = \"Authorization: Bearer %s\"\\n' \"$T\") "
            "-H 'Accept: application/vnd.github.raw+json' -o /root/edge-install.sh "
            f"'{url}' && echo '{install_sha256}  /root/edge-install.sh' | sha256sum -c && "
            'T="$T" bash /root/edge-install.sh; unset T')
    return ["read -rs T", line]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", required=True)
    ap.add_argument("--repo", default=str(HERE.parents[1]))
    ap.add_argument("--commit", default="HEAD")
    ap.add_argument("--export-repo", default="macdarenz-droid/edge-desk-export")
    ap.add_argument("--branch", default="main")
    ap.add_argument("--oanda-figures-ok", default=None, metavar="RULING",
                    help="the coordinator's ruling that the figures from OANDA prices may ship (README section 12)")
    a = ap.parse_args(argv)
    repo, out = Path(a.repo), Path(a.out)
    commit = _git(repo, "rev-parse", "--verify", f"{a.commit}^{{commit}}").decode().strip()
    sys.path.insert(0, str(HERE))
    sys.path.insert(0, str(HERE.parent))
    import make_lead_bundle
    with tempfile.TemporaryDirectory() as tmp:
        bundle = Path(tmp) / "lead-bundle"
        make_lead_bundle.build(bundle, repo)
        tarball = build_tarball(repo, commit, out, bundle)
    held = oanda_figures(tarball)
    ruling = (a.oanda_figures_ok or "").strip()
    if held and not ruling:
        tarball.unlink()
        shown = [f for f in held if not f.startswith("lead-bundle/")] + (
            ["lead-bundle/ (" + str(sum(f.startswith("lead-bundle/") for f in held)) + " files)"]
            if any(f.startswith("lead-bundle/") for f in held) else [])
        raise SystemExit("make_release: held. These members hold figures computed on OANDA practice prices: "
                         + ", ".join(shown) + ". OANDA's terms do not clearly allow publishing them (ruling R7). Build "
                         "only after the coordinator's ruling, with --oanda-figures-ok <ruling> (README section 12).")
    tsha = sha256(tarball)
    (out / "install.sh").write_text(render_install(a.export_repo, a.branch, tarball.name, tsha, commit))
    isha = sha256(out / "install.sh")
    sums = f"{tsha}  {tarball.name}\n{isha}  install.sh\n"
    (out / RULING_NAME).unlink(missing_ok=True)
    if held:
        (out / RULING_NAME).write_text(ruling_text(ruling, tarball.name, tsha, commit, len(held)))
        sums += f"{sha256(out / RULING_NAME)}  {RULING_NAME}\n"
    (out / "SHA256SUMS").write_text(sums)
    print(f"commit   {commit}")
    print(f"tarball  {tarball.name}  sha256 {tsha}  ({tarball.stat().st_size:,} bytes)")
    print(f"install  install.sh  sha256 {isha}")
    if held:
        print(f"carries  {len(held)} files with figures from OANDA practice prices; ruling: {ruling}")
    files = "the tarball, install.sh, " + (f"{RULING_NAME} " if held else "") + "and SHA256SUMS"
    print(f"Put {files} in {a.export_repo}, branch {a.branch}, folder release/. The owner pastes, as root:")
    for ln in paste_lines(a.export_repo, a.branch, isha):
        print(ln)
    return 0


if __name__ == "__main__":
    sys.exit(main())
