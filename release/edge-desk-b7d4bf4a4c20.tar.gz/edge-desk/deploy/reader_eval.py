"""Evaluation harness for the picture reader (docs/JOURNAL_DESIGN.md §11.2, §11.3). Run before [photos] reader is
switched on; never on the server's live journal. Two steps, as the reader's two units (fix round D-b): the step that
decodes pictures never has the key, and the step that has the key never decodes a picture.

  python3 deploy/reader_eval.py --labels LABELS.json [--pictures DIR] --prepare OUT_DIR
  python3 deploy/reader_eval.py --from OUT_DIR --live --paid-run-ok --max-usd 25 [--effort low,medium] [--repeats 3]
  python3 deploy/reader_eval.py --labels LABELS.json [--pictures DIR] --dry-run [--repeats 3] [--out report.json]

--prepare (no key: it refuses to run with EDGE_ANTHROPIC_KEY in its environment; run it through systemd-run as user
edge with no network and the local unit's hardening, deploy/README.md §14) puts every picture through what the reader does in use: the upload's checks and metadata strip,
then the local pass (the free pre-filter). It scores the non-MT5 pictures on the pre-filter alone (P3) and writes, for
each MT5 chart with all three MT5 signs and no banner, the exact crop to send and its local pass into OUT_DIR. A
picture that fails the MT5 match is never sent, here as in use.

--live is the paid step: it needs EDGE_ANTHROPIC_KEY in its environment (run it through systemd-run as user and group
edge-reader with EnvironmentFile=/etc/edge-desk/reader.env and the send unit's hardening, the app's env file and the
journal hidden, deploy/README.md §14), --paid-run-ok (the owner's OK for
about $25, §5.6) and --max-usd, a running stop: a call starts only while what was spent plus that call's ceiling stays
within it (each call counted at its ceiling until its cost is known). It reads OUT_DIR only (no picture decoder is
imported) and sends the production request (fallbacks on). The Batch API path of §11.2 (half the price, without
fallbacks) is not built here.

--dry-run runs both steps in one process with no key and no call: the reading returned is the one the labels say
(hidden numbers null), with a fixed usage, so the pipeline and the scoring are exercised end to end
(tests/test_reader_eval.py).

LABELS.json is the research branch's labels format (shots/labels.json, frozen by its sha256 there): "mt5" entries with
their hand-read values (a number not printed on the picture is {"expected": x, "shown": "hidden"} or
{"printed": false, "expected": x}) and "not_mt5" lists of file names by kind.

The report: per picture and per repeat, the critical fields (symbol, side, lots, order type, entry, stop, target) with
their state, P1 (no wrong critical value shown green), P2 (90% green), P3 (the pre-filter: no non-MT5 picture passes
the MT5 match, 90% sorted to the right kind, 95% of MT5 charts pass), P4 (no invented hidden number), P5 ($0.10 and 30 s
at the 95th percentile, every attempt counted), P6 (95% of fields the same over the repeats), P7 (line prices within
0.2 pip on 95% of true lines; the axis right or flagged on all). P8-P10 are judged elsewhere (the analysis, his check,
the stop tests). No picture, price or money figure is printed: counts and pass or fail only.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import load  # noqa: E402
from app.photos import checks, claude, images  # noqa: E402

CRITICAL = ("symbol", "side", "lots", "order_kind", "entry", "sl", "tp")
PIP = 0.0001
LINE_PIPS = 0.2
DRY_USAGE = (5200, 1100)
_FILE = re.compile(r"^([^\s(]+)")


def _tv(v) -> tuple:
    """(value, hidden) from a label value: a number, or {"expected": x} with shown hidden or printed false."""
    if isinstance(v, dict):
        return v.get("expected"), v.get("shown") == "hidden" or v.get("printed") is False
    return v, False


def truth_of(label: dict) -> dict:
    pos = (label.get("positions") or [None])[0]
    pend = (label.get("pending") or [None])[0]
    trade: dict = {}
    if pos:
        trade.update(side=(pos.get("side"), False), lots=(pos.get("lots"), False), order_kind=(None, False),
                     entry=_tv(pos.get("entry_tag")))
    elif pend:
        trade.update(side=(pend["type"].split("_")[0], False), lots=(pend.get("lots"), False),
                     order_kind=(pend["type"], False), entry=_tv(pend.get("price")))
    trade["sl"], trade["tp"] = _tv(label.get("sl")), _tv(label.get("tp"))
    trade["symbol"] = (label.get("symbol"), False)
    lines = [v for v, _ in (trade.get("entry", (None, False)), trade["sl"], trade["tp"]) if v is not None]
    axis = label.get("axis_labels") or {}
    return {"id": label.get("id"), "file": label.get("file"), "screen": label.get("screen"), "trade": trade,
            "lines": lines, "axis": (axis.get("top"), axis.get("bottom"))}


def _num(v, hidden):
    return {"value": None, "shown": "hidden", "conf": "low"} if hidden or v is None else \
        {"value": v, "shown": "visible", "conf": "high"}


def to_vision(label: dict) -> dict:
    """The mt5shot/2 reading the labels say: what a perfect read returns (a hidden number null)."""
    t = truth_of(label)["trade"]
    pos = (label.get("positions") or [None])[0]
    pend = (label.get("pending") or [None])[0]
    positions, pending, levels = [], [], []
    owner = {"type": "position", "index": 0} if pos else {"type": "pending_order", "index": 0}
    if pos:
        pnl = pos.get("pnl_label")
        positions.append({"side": pos["side"], "lots": pos["lots"], "pnl": pnl, "pnl_currency": "USD",
                          "entry_tag": _num(*t["entry"]), "conf": "high",
                          "label_text": f"{pos['side'].upper()} {pos['lots']:g}, {pnl:+.2f} USD" if pnl is not None
                          else f"{pos['side'].upper()} {pos['lots']:g}"})
    if pend:
        pending.append({"type": pend["type"], "lots": pend["lots"], "price_tag": _num(*t["entry"]),
                        "label_text": f"{pend['type'].replace('_', ' ').upper()} {pend['lots']:g}", "conf": "high"})
    for kind in ("sl", "tp"):
        v, hidden = t[kind]
        if v is not None:
            levels.append({"kind": kind, "owner_ref": owner, "label_text": kind.upper(), "price_tag": _num(v, hidden),
                           "conf": "high"})
    axis = label.get("axis_labels") or {}
    bid = label.get("bid_tag")
    return {"schema_version": "mt5shot/2", "platform": "mt5_mobile", "screen": "chart", "orientation": "portrait",
            "theme": "dark", "symbol": {"value": label.get("symbol"), "conf": "high"},
            "timeframe": {"value": label.get("timeframe"), "conf": "high"},
            "chart_at_live_edge": {"value": True, "conf": "high"}, "live_price_tag": _num(bid, False),
            "ask_tag": _num(None, True), "countdown": {"value": label.get("countdown"), "conf": "high"},
            "one_click_panel": {"present": False, "lots": None, "sell": None, "buy": None},
            "axis": {"top_label": axis.get("top"), "bottom_label": axis.get("bottom"), "label_count": None,
                     "conf": "high"},
            "time_labels": [], "positions": positions, "pending_orders": pending, "levels": levels, "overlaps": [],
            "chip": {"value": label.get("chip"), "conf": "high"}, "history": {"rows": []}, "drawn_objects": [],
            "privacy": {"notification_or_message_visible": False, "other_personal_text_visible": False},
            "unreadable": []}


class DryClient:
    """client.beta.messages.create answering with the labels' reading and a fixed usage; never the network."""

    def __init__(self):
        self.label = None
        self.calls = 0
        self.beta = SimpleNamespace(messages=SimpleNamespace(create=self._create))

    def _create(self, **kw):
        self.calls += 1
        usage = SimpleNamespace(input_tokens=DRY_USAGE[0], output_tokens=DRY_USAGE[1], cache_creation_input_tokens=0,
                                cache_read_input_tokens=0, iterations=None)
        return SimpleNamespace(model=kw["model"], stop_reason="end_turn", stop_details=None, usage=usage,
                               content=[SimpleNamespace(type="text", text=json.dumps(to_vision(self.label)))])


def _same(a, b) -> bool:
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool):
        return abs(float(a) - float(b)) < 1e-9
    if isinstance(a, str) and isinstance(b, str):
        return checks.base_symbol(a) == checks.base_symbol(b) if len(a) >= 6 and len(b) >= 6 else a == b
    return a == b


def score_chart(truth: dict, merged: dict, vision: dict | None) -> dict:
    """One reading of one chart picture against the labels: the critical fields, a wrong value shown green, an invented
    hidden number (the raw reading gave a number the picture does not print)."""
    trades = merged.get("trades") or []
    fields = dict(trades[0]["fields"]) if trades else {}
    fields["symbol"] = (merged.get("fields") or {}).get("symbol") or {"value": None, "state": "red"}
    out = {"critical": 0, "green": 0, "right": 0, "green_wrong": [], "invented": [], "values": {}}
    for name in CRITICAL:
        want, _ = truth["trade"].get(name, (None, False))
        f = fields.get(name) or {"value": None, "state": "red"}
        if want is None and name == "order_kind":
            continue
        out["critical"] += 1
        out["values"][name] = f.get("value")
        right = _same(f.get("value"), want)
        out["right"] += right
        if f.get("state") == "green":
            out["green"] += 1
            if not right:
                out["green_wrong"].append(name)
    if vision:
        pos = (vision.get("positions") or [None])[0]
        pend = (vision.get("pending_orders") or [None])[0]
        raw = {"entry": (pos or {}).get("entry_tag") or (pend or {}).get("price_tag")}
        for lv in vision.get("levels") or ():
            raw[lv.get("kind")] = lv.get("price_tag")
        for name in ("entry", "sl", "tp"):
            _, hidden = truth["trade"].get(name, (None, False))
            node = raw.get(name) or {}
            if hidden and node.get("value") is not None:
                out["invented"].append(name)
    return out


def _p95(xs: list[float]) -> float | None:
    if not xs:
        return None
    xs = sorted(xs)
    return xs[max(0, math.ceil(0.95 * len(xs)) - 1)]


def bars(results: dict) -> dict:
    charts, other = results.get("charts", []), results.get("not_mt5", [])
    sent = [c for c in charts if c.get("sent")]
    crit = sum(c["critical"] for c in sent)
    green = sum(c["green"] for c in sent)
    out = {}
    wrong = sum(len(c["green_wrong"]) for c in sent)
    out["P1"] = {"pass": wrong == 0 if sent else None, "value": {"wrong_green": wrong}}
    out["P2"] = {"pass": (green / crit >= 0.90) if crit else None, "value": {"green_share": green / crit if crit else None}}
    passed_match = sum(1 for o in other if o.get("mt5_match"))
    sorted_right = sum(1 for o in other if o.get("kind") == o.get("expected"))
    mt5_ok = sum(1 for c in charts if c.get("signs_ok"))
    p3 = passed_match == 0 and not any(o.get("sent") for o in other) \
        and (sorted_right >= 0.90 * len(other) if other else True) and (mt5_ok >= 0.95 * len(charts) if charts else True)
    out["P3"] = {"pass": p3, "value": {"non_mt5_passing": passed_match, "non_mt5_sorted_right": sorted_right,
                                       "non_mt5": len(other), "mt5_passing": mt5_ok, "mt5": len(charts)}}
    invented = sum(len(c["invented"]) for c in sent)
    out["P4"] = {"pass": invented == 0 if sent else None, "value": {"invented": invented}}
    usd, ms = [c["usd"] for c in sent], [c["ms"] for c in sent]
    out["P5"] = {"pass": (_p95(usd) <= 0.10 and _p95(ms) <= 30000) if sent else None,
                 "value": {"usd_p95": _p95(usd), "ms_p95": _p95(ms)}}
    fields_n = same_n = 0
    for c in sent:
        reps = c.get("repeats") or []
        if len(reps) < 2:
            continue
        for key in reps[0]:
            fields_n += 1
            same_n += all(r.get(key) == reps[0][key] for r in reps)
    out["P6"] = {"pass": (same_n / fields_n >= 0.95) if fields_n else None,
                 "value": {"same_share": same_n / fields_n if fields_n else None}}
    true_lines = sum(c.get("lines_true", 0) for c in charts)
    hit = sum(c.get("lines_hit", 0) for c in charts)
    axis_ok = all(c.get("axis_right_or_flagged", False) for c in charts)
    out["P7"] = {"pass": ((hit >= 0.95 * true_lines) and axis_ok) if true_lines else None,
                 "value": {"lines_hit": hit, "lines_true": true_lines, "axis_right_or_flagged": axis_ok}}
    for p in ("P8", "P9", "P10"):
        out[p] = {"pass": None, "value": "judged elsewhere (the analysis picture, his check, the stop tests)"}
    return out


def _files(labels: dict, folder: Path) -> tuple[list, list]:
    mt5 = [l for l in labels.get("mt5") or () if l.get("screen") == "chart"]
    other = []
    for kind, names in (labels.get("not_mt5") or {}).items():
        if kind.startswith("_") or kind == "private_do_not_use":
            continue                               # the private picture is never used, anywhere
        for n in names:
            name = _FILE.match(str(n)).group(1)
            other.append({"file": name, "expected": "look_tradingview" if kind.startswith("tradingview") else "other",
                          "path": folder / name})
    return mt5, other


def _upload(raw: bytes, cfg) -> bytes:
    """What the upload does before a picture reaches the reader (phase 1): type, size, the metadata strip."""
    ctype = "image/png" if raw.startswith(b"\x89PNG") else "image/jpeg"
    mime, _ = images.sniff(raw, ctype)
    images.check_size(raw, cfg.photos)
    return images.strip(raw, mime)


def prepare(labels: dict, folder: Path, out_dir: Path, cfg) -> dict:
    """The decoding step: the upload, the local pass, the pre-filter's scores and the exact crops to send."""
    from app.photos import local                   # Pillow, numpy, tesseract: the reader's own environment
    mt5, other = _files(labels, folder)
    out_dir.mkdir(parents=True, exist_ok=True)
    prepared = {"pictures": len(mt5) + len(other), "not_mt5": [], "charts": []}
    for o in other:
        try:
            loc = local.analyse(_upload(o["path"].read_bytes(), cfg))
            kind = loc["kind"]
            match = all(loc["signs"].values()) and kind in ("chart", "look_mt5")
        except (OSError, images.Refused):
            kind, match = "refused_at_upload", False
        prepared["not_mt5"].append({"id": o["file"], "expected": o["expected"],
                                    "kind": "other" if kind == "refused_at_upload" else kind, "mt5_match": match,
                                    "sent": False})
    for label in mt5:
        truth = truth_of(label)
        data = _upload((folder / label["file"]).read_bytes(), cfg)
        loc = local.analyse(data)
        signs_ok = all(loc["signs"].values()) and not loc.get("banner") and loc["kind"] == "chart"
        hit = sum(1 for p in truth["lines"] if any(abs(ln["price"] - p) <= LINE_PIPS * PIP + 1e-9
                                                   for ln in loc["lines"]))
        ax = loc.get("axis") or {}
        top = truth["axis"][0]
        # P7: the fit is right (its top label is the labels' top label) or flagged (not ok: the prices go red)
        axis_right = (not ax.get("ok")) or top is None or abs(ax["top"] - top) < 1e-9
        crop = None
        if signs_ok:
            crop = f"{len(prepared['charts']):03d}.png"
            (out_dir / crop).write_bytes(local.crop_png(data, loc["crop"]))
        prepared["charts"].append({"label": label, "loc": loc, "crop": crop,
                                   "row": {"id": label["id"], "sent": signs_ok, "signs_ok": signs_ok,
                                           "lines_true": len(truth["lines"]), "lines_hit": hit,
                                           "axis_right_or_flagged": bool(axis_right)}})
    (out_dir / "prepared.json").write_text(json.dumps(prepared, default=str))
    return prepared


def paid(prep_dir: Path, client, sdk, cfg, efforts: list[str], repeats: int, max_usd: float | None,
         live: bool) -> dict:
    """The paid step: the prepared crops sent as they are (no decoder here), the checks and the scores; a call starts
    only while what was spent plus its ceiling stays within max_usd."""
    prepared = json.loads((prep_dir / "prepared.json").read_text())
    results = {"charts": [], "not_mt5": prepared["not_mt5"]}
    state = {"calls": 0, "usd": 0.0, "stopped": False}

    def room(max_tokens: int) -> bool:
        ok = max_usd is None or state["usd"] + claude.call_ceiling_usd(cfg, max_tokens) <= max_usd + 1e-12
        state["stopped"] = state["stopped"] or not ok
        return ok

    def reserve(max_tokens, ceiling):           # as the sender's ledger: the ceiling counts until the cost is known
        state["usd"] += ceiling
        state["held"] = ceiling

    def spend(call):
        state["usd"] += float(call["usd"]) - state.pop("held", 0.0)
    for c in prepared["charts"]:
        label, loc = c["label"], c["loc"]
        truth = truth_of(label)
        row = {**c["row"], "critical": 0, "green": 0, "green_wrong": [], "invented": [], "usd": 0.0, "ms": 0,
               "repeats": [], "by_effort": {}}
        if c["crop"] and not state["stopped"]:
            png = (prep_dir / c["crop"]).read_bytes()
            for effort in efforts:
                cc = replace(cfg, photos=replace(cfg.photos, effort=effort))
                for _ in range(repeats):
                    if not room(claude.MAX_TOKENS):
                        break
                    client.label = label
                    r = claude.read(client, cc, png, claude.note_for(loc.get("phone_clock"), None), sdk,
                                    reserve=reserve, spend=spend, may_retry=room)
                    state.pop("held", None)
                    state["calls"] += r.calls
                    if r.outcome != "ok":
                        row["repeats"].append({"outcome": r.outcome})
                        continue
                    res = checks.reconcile(cc, loc, r.vision, picture_utc=datetime.now(timezone.utc), oanda=None,
                                           balance=None)
                    s = score_chart(truth, res, r.vision)
                    row["repeats"].append({k: s["values"].get(k) for k in s["values"]})
                    if not row["by_effort"].get(effort):
                        row["by_effort"][effort] = s
                        row["critical"] += s["critical"]
                        row["green"] += s["green"]
                        row["green_wrong"] += s["green_wrong"]
                        row["invented"] += s["invented"]
                    row["usd"] = max(row["usd"], r.usd)
                    row["ms"] = max(row["ms"], r.ms)
        results["charts"].append(row)
    return {"mode": "live" if live else "dry-run", "pictures": prepared["pictures"], "calls": state["calls"],
            "usd": round(state["usd"], 6), "stopped_at_max_usd": state["stopped"], "efforts": efforts,
            "repeats": repeats, "results": results, "bars": bars(results)}


def _dry_sdk():
    return SimpleNamespace(**{n: type(n, (Exception,), {}) for n in (
        "AuthenticationError", "PermissionDeniedError", "BadRequestError", "RateLimitError",
        "InternalServerError", "APIStatusError", "APIConnectionError")})


def main(argv=None, env=None) -> int:
    env = os.environ if env is None else env
    ap = argparse.ArgumentParser(prog="reader_eval.py", description=__doc__.split("\n")[0])
    ap.add_argument("--labels", default=None)
    ap.add_argument("--pictures", default=None, help="the folder of the pictures (default: the labels' folder)")
    ap.add_argument("--prepare", default=None, metavar="OUT_DIR", help="the decoding step (no key, no network)")
    ap.add_argument("--from", dest="src", default=None, metavar="OUT_DIR", help="the paid step reads this folder")
    ap.add_argument("--dry-run", action="store_true", help="both steps, no call, no key: the labels' reading")
    ap.add_argument("--live", action="store_true", help="the paid step (needs --paid-run-ok, --max-usd and the key)")
    ap.add_argument("--paid-run-ok", action="store_true", help="the owner said yes to the paid run (about $25)")
    ap.add_argument("--max-usd", type=float, default=None, help="the running stop for the paid step, in USD")
    ap.add_argument("--effort", default="low", help="comma-separated: low,medium")
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--out", default=None)
    args = ap.parse_args(argv)
    if sum(bool(x) for x in (args.prepare, args.live, args.dry_run)) != 1:
        print("give exactly one of --prepare OUT_DIR, --live (with --from OUT_DIR) and --dry-run")
        return 2
    cfg = load(env={})
    efforts = [e.strip() for e in args.effort.split(",") if e.strip()]
    if args.prepare or args.dry_run:
        if env.get("EDGE_ANTHROPIC_KEY"):
            print("the decoding step never runs with the picture reading key in its environment: not run")
            return 2
        if not args.labels:
            print("give --labels LABELS.json")
            return 2
        labels = json.loads(Path(args.labels).read_text())
        folder = Path(args.pictures or labels.get("folder") or ".")
    if args.prepare:
        prepared = prepare(labels, folder, Path(args.prepare), cfg)
        sent = sum(1 for c in prepared["charts"] if c["crop"])
        print(f"prepared: {prepared['pictures']} pictures, {sent} crops to send")
        return 0
    if args.live:
        if not args.paid_run_ok:
            print("a paid run needs the owner's OK: add --paid-run-ok once he has said yes (about $25, §5.6)")
            return 2
        if not env.get("EDGE_ANTHROPIC_KEY"):
            print("a paid run needs EDGE_ANTHROPIC_KEY: run it as the reader's user through systemd-run -p User=edge-reader"
                  " -p EnvironmentFile=/etc/edge-desk/reader.env (deploy/README.md §14)")
            return 2
        if args.max_usd is None or args.max_usd <= 0:
            print("a paid run needs a running stop: add --max-usd (for example 25)")
            return 2
        if not args.src or not (Path(args.src) / "prepared.json").is_file():
            print("a paid run reads a prepared folder: run --prepare first, then give --from OUT_DIR")
            return 2
        client, sdk = claude.make_client(env["EDGE_ANTHROPIC_KEY"])
        report = paid(Path(args.src), client, sdk, cfg, efforts, args.repeats, args.max_usd, live=True)
    else:
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            prepare(labels, folder, Path(tmp), cfg)
            report = paid(Path(tmp), DryClient(), _dry_sdk(), cfg, efforts, args.repeats, None, live=False)
    text = json.dumps(report, indent=1, default=str)
    if args.out:
        Path(args.out).write_text(text)
    for p, b in report["bars"].items():
        verdict = "not judged here" if b["pass"] is None else "PASS" if b["pass"] else "FAIL"
        print(f"{p}: {verdict}")
    stop = " (stopped at --max-usd)" if report["stopped_at_max_usd"] else ""
    print(f"{report['mode']}: {report['pictures']} pictures, {report['calls']} calls{stop}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
