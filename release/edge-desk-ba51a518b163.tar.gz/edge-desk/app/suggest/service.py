"""B10 the two worker processes (python -m app method-worker, python -m app lead-worker). Each loop step writes the
log, queues the alerts (the web server's monitor sends them) and never touches an order.

method_step: your method's closes due now (after the feed marker), its lifecycle, links of taken suggestions to MT5,
             and, after 17:05 New York, the day's export (B5).
lead_step:   once a day, a new calendar pin from the export repo; then the lead worker's run (B3) and its alerts.
"""
from __future__ import annotations

import logging
import sqlite3
import time
from datetime import date, datetime, timedelta
from pathlib import Path

from app.export import daily as X
from app.suggest import alerts as SA
from app.suggest import log as L
from app.timeutil import now_utc, trading_day

log = logging.getLogger("app.suggest")
METHOD_EVERY_S = 30
LEAD_EVERY_S = 300


EXPORT_LOOKBACK_DAYS = 5      # trading days caught up after a stop (a weekend, a restart)


def queue_pending(conn: sqlite3.Connection, cfg, now: datetime) -> int:
    """Suggestion alerts from the log itself, not from a run's return value, so a later error cannot lose one
    (red team 17 Oct, item 4). queue_alert keeps one alert per key."""
    since = int(now.timestamp()) - 86400
    n = 0
    for r in conn.execute("SELECT id FROM suggestion WHERE source = 'method' AND offered = 1 AND supersedes_id IS NULL"
                          " AND placed_ts >= ? AND (expiry_ts IS NULL OR expiry_ts > ?)"
                          " AND id NOT IN (SELECT suggestion_id FROM suggestion_result) ORDER BY id",
                          (since, int(now.timestamp()))).fetchall():
        n += SA.queue_method(conn, cfg, [r[0]], now)
    return n


def export_due(conn: sqlite3.Connection, cfg, now: datetime) -> list:
    """Each of the last EXPORT_LOOKBACK_DAYS weekdays whose 17:05 New York has passed: sent once, and again
    whenever its files change (a trade the bridge reported late)."""
    d = cfg.day
    today = trading_day(now, d.boundary_tz, d.boundary_hour)
    out, day = [], today
    while len(out) < EXPORT_LOOKBACK_DAYS:
        if day.weekday() < 5:
            out.append((day, X.export_day(conn, cfg, day, now=now)))
        day -= timedelta(days=1)
    return out


def method_step(conn: sqlite3.Connection, cfg, now: datetime, worker=None) -> dict:
    """One step; each part in its own try, so one failing part never stops the others."""
    from app.suggest.method import MethodWorker
    out = {"queued": 0, "links": 0, "export": None, "errors": []}
    try:
        w = worker or MethodWorker(conn, cfg)
        r = w.run_due(now)
        out["queued"] += SA.queue_lifecycle(conn, cfg, r.get("lifecycle") or {}, now)
        if r.get("lifecycle_error"):
            out["errors"].append(f"lifecycle: {r['lifecycle_error']}")
    except Exception as e:                                  # noqa: BLE001
        out["errors"].append(f"run: {type(e).__name__}: {str(e)[:200]}")
    try:
        out["queued"] += queue_pending(conn, cfg, now)
    except Exception as e:                                  # noqa: BLE001
        out["errors"].append(f"alerts: {type(e).__name__}")
    try:
        out["links"] = len(L.resolve_links(conn, cfg, now=now))
    except Exception as e:                                  # noqa: BLE001
        out["errors"].append(f"links: {type(e).__name__}")
    if cfg.export.enabled:
        try:
            days = export_due(conn, cfg, now)
            out["export"] = days[0][1] if days else None
        except Exception as e:                              # noqa: BLE001
            out["errors"].append(f"export: {type(e).__name__}")
    for e in out["errors"]:
        log.warning("method worker: %s", e)
    return out


class MethodLoop:
    """The method worker's loop keeps one MethodWorker, so its in-memory bar window is reused (item 3)."""

    def __init__(self, conn: sqlite3.Connection, cfg):
        from app.suggest.method import MethodWorker
        self.conn, self.cfg = conn, cfg
        self.worker = MethodWorker(conn, cfg)

    def step(self, now: datetime) -> dict:
        return method_step(self.conn, self.cfg, now, worker=self.worker)


def lead_step(conn: sqlite3.Connection, cfg, now: datetime, bundle: Path, cal_root: Path, worker=None,
              last_pull: dict | None = None) -> dict:
    from app.feed.oanda import complete_through
    from app.suggest.leads import LeadWorker
    pulled = None
    if cfg.export.enabled and last_pull is not None and last_pull.get("day") != now.date():
        try:
            pulled = str(X.pull_calendar(cfg, cal_root))
        except X.ExportRefused as e:
            pulled = f"refused: {e}"
        last_pull["day"] = now.date()
    cal = X.current_calendar(cal_root)
    if cal is None:
        return {"status": "no calendar pin yet", "pulled": pulled}
    w = worker or LeadWorker(conn, cfg, bundle, cal, complete_through=lambda: complete_through(conn))
    out = w.run(now)
    queued = SA.queue_leads(conn, cfg, out, now)
    for sid in out.get("settled", []):
        res = L.result(conn, sid)
        s = L.current(conn, sid)
        if res is not None and now.timestamp() - (s.get("expiry_ts") or 0) <= 86400:
            from app.notify.alerts import queue_alert
            queued += queue_alert(conn, SA.suggestion_result(cfg, s, res), now)
    return {"status": out.get("status"), "queued": queued, "pulled": pulled}


def run_method_forever(conn: sqlite3.Connection, cfg) -> None:
    loop = MethodLoop(conn, cfg)
    while True:
        try:
            r = loop.step(now_utc())
            log.info("method worker: %s alerts queued, %s links, export %s", r["queued"], r["links"],
                     (r["export"] or {}).get("status"))
        except Exception:                                   # noqa: BLE001  (logged; the loop goes on)
            log.exception("method worker step failed")
        time.sleep(METHOD_EVERY_S)


def run_leads_forever(conn: sqlite3.Connection, cfg, bundle: Path, cal_root: Path) -> None:
    pulls: dict = {}
    while True:
        try:
            r = lead_step(conn, cfg, now_utc(), bundle, cal_root, last_pull=pulls)
            log.info("lead worker: %s, %s alerts queued", r["status"], r.get("queued", 0))
        except Exception:                                   # noqa: BLE001
            log.exception("lead worker step failed")
        time.sleep(LEAD_EVERY_S)


__all__ = ["method_step", "lead_step", "run_method_forever", "run_leads_forever", "date"]
