# MT5 bridge demo: evidence

Run on Fri 16 Oct 2026, 16:53-17:56 Melbourne, in a Claude Code cloud container (Linux, Wine 11.0, MT5 build 6266),
with `bridge/demo/run_demo.py` from this branch. No login number, password, account name or server account detail is in
this file. Screenshots stayed outside git.

## Result: not passed (the broker could not be reached from the container)

| Check | Result |
|---|---|
| EA compile (MetaEditor, build 6266) | **0 errors, 0 warnings** (all three runs) |
| EA loads on EURUSD H1, timer runs | yes: "EdgeBridge edge-bridge/1 started ... Read-only" in the Experts log |
| Algorithmic trading | off (Tools > Options checkbox cleared by the script; checked on the options screenshot) |
| WebRequest allow-list | `http://127.0.0.1:8787` added by the script (checked on the options screenshot) |
| App (`python3 -m app serve`) | started, `/api/health` 200 |
| `--no-login` plumbing run | EA reports "not connected ... nothing is sent until it is", as designed; no snapshot (the EA sends only from a logged-in, connected terminal) |
| Demo-login run | terminal journal: "connection to <server> lost" 4-5 s after start, twice (17:50 and 17:53 Melbourne); never connected |
| Snapshots reaching the app | **0** |
| bridge_status.json | not written (no snapshot) |
| Deals / positions ingested | **0 / 0** (nothing arrived) |

Why it failed: the terminal never connected to the demo trade server. MT5 talks to its trade server over its own
protocol, not HTTPS; this container's outbound traffic goes through an HTTPS agent proxy, and a check of raw outbound
connections was refused by the session's safety classifier, so the cause could not be confirmed further from here.
It is not a login error (MT5 reports a wrong password as an authorization failure, not "connection lost"). The run
needs a machine with ordinary outbound internet, such as the owner's server, or a cloud environment whose network
policy allows the MT5 trade server.

## Fixes made to run_demo.py in this run

- MetaQuotes' CDN returns 403 to Python's default user agent; the installer download now sends a curl user agent
  (the same official file, 23,784,536 bytes, served to curl with 200).
- Ubuntu's Wine 9.0 cannot run MT5 build 6266 ("A debugger has been found running in your system"); WineHQ stable
  11.0 (dl.winehq.org, `winehq-stable`) runs it. `packages()` still installs Ubuntu's wine when none is present, so on
  Ubuntu 24.04 install `winehq-stable` first.
- Wine 11 stops `wineboot` on a "install wine-mono?" dialog; `WINEDLLOVERRIDES="mscoree=;mshtml="` skips it.
- Build 6266 places Tools > Options lower-left of where build 6251 did; the click points were re-measured
  (Experts tab 514,410; algorithmic trading 383,455; WebRequest 383,602; URL row 500,631; OK 759,765) and checked on
  screenshots of the no-login run.

## Resources (for choosing the owner's server)

Sampled every 10 s by PID during the demo-login run (19 samples, terminal not connected, so a connected terminal with
history will use more):

| Process | Peak RSS |
|---|---|
| terminal64.exe | not captured (the sampler matched no process name; a sampler bug, not a zero) |
| wineserver | about 16 MB |
| Xvfb | about 25 MB |
| app (python) | about 25 MB |
| Total of the captured ones | about 66 MB |

MemAvailable stayed above about 15.4 GB (the container has about 15 GB). Disk: the Wine prefix is 2.3 GB, of which
MT5 itself is 486 MB. These are one short run in a container; check them again on the server.

## Safety

- The EA has no order functions (`git grep -nE 'OrderSend|CTrade|OrderModify|PositionClose' bridge/` returns nothing).
- Only the investor (read-only) password was used, written only to a 0600 start file that was deleted after start.
- No order was placed, changed or closed. `git grep` for the login number returns nothing.
