#!/usr/bin/env python3
"""MT5's first-time setup on the server (run by deploy/install/stage2.sh as the mt5 user, with the system Python;
standard library only). It reuses what the bridge demo worked out (bridge/demo/run_demo.py, EVIDENCE.md, 16 Oct):
MetaQuotes' installer under WineHQ 11, the EA compiled with MetaEditor (0 errors required), algorithmic trading off,
and the WebRequest allow-list set by keyboard and mouse at the measured screen points.

The secrets come only on stdin, as KEY=value lines (MT5_LOGIN, MT5_SERVER, MT5_PASSWORD: the INVESTOR password, and
EDGE_INGEST_TOKEN). They are written to two files only, each mode 0600: the start file, deleted once the terminal has
started, and the EA's token file. The login is kept by the terminal itself (KeepPrivate=1), so the service's run.ini
holds no login and no password. Nothing here prints a secret.

  stage2.sh:  ... | runuser -u mt5 -- python3 -I mt5_setup.py --base /home/mt5/edge

Not verified on a real server: the terminal keeping the login between starts, the screen points on the server's
build, and that the terminal reaches the broker from the server (the demo's container could not).
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

DESK = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(DESK / "bridge" / "demo"))

NEEDED = ("MT5_LOGIN", "MT5_SERVER", "MT5_PASSWORD", "EDGE_INGEST_TOKEN")
EXPERTS = ["[Experts]", "AllowLiveTrading=0", "AllowDllImport=0", "Enabled=1", "Account=0", "Profile=0"]
STARTUP = ["[StartUp]", r"Expert=EdgeBridge\EdgeBridge", "ExpertParameters=edge.set", "Symbol=EURUSD", "Period=H1"]


def parse_secrets(stream) -> dict:
    out = {}
    for line in stream.read().splitlines():
        k, sep, v = line.partition("=")
        if sep and k in NEEDED:
            out[k] = v
    missing = [k for k in NEEDED if not out.get(k)]
    if missing:
        raise SystemExit(f"mt5 setup: missing on stdin: {', '.join(missing)}")
    return out


def login_ini(s: dict) -> str:
    lines = ["[Common]", f"Login={s['MT5_LOGIN']}", f"Password={s['MT5_PASSWORD']}", f"Server={s['MT5_SERVER']}",
             "KeepPrivate=1", "NewsEnable=0", *EXPERTS, *STARTUP]
    return "\r\n".join(lines) + "\r\n"


def run_ini() -> str:
    """The service's start file: the EA on its chart, no login (the terminal keeps the saved one)."""
    return "\r\n".join([*EXPERTS, *STARTUP]) + "\r\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--base", default="/home/mt5/edge")
    ap.add_argument("--alias", default="main")
    a = ap.parse_args(argv)
    secrets = parse_secrets(sys.stdin)
    import run_demo as D

    class Setup(D.Demo):
        def start_terminal(self, alias: str) -> Path:
            presets = self.mt5 / "MQL5" / "Presets"
            presets.mkdir(parents=True, exist_ok=True)
            (presets / "edge.set").write_text(f"InpAlias={alias}\r\nInpUrl={D.INGEST_URL}\r\n"
                                              "InpTokenFile=edge_bridge_token.txt\r\n", encoding="utf-16")
            self.ini.parent.mkdir(parents=True, exist_ok=True)
            D.write_private(self.ini, login_ini(secrets))
            self.procs.append(subprocess.Popen(["wine", "terminal64.exe", "/portable", r"/config:C:\edge\start.ini"],
                                               cwd=self.mt5, env=self.env, stdout=subprocess.DEVNULL,
                                               stderr=subprocess.DEVNULL))
            return self.ini

    base = Path(a.base)
    s = Setup(base, login=True)
    try:
        print("mt5 setup: installing MT5 (MetaQuotes' installer, pinned by stage2)", flush=True)
        s.install_mt5()
        print("mt5 setup: compiling the EA", flush=True)
        s.compile_ea()
        D.write_private(s.common_files() / "edge_bridge_token.txt", secrets["EDGE_INGEST_TOKEN"])
        print("mt5 setup: first start with the investor login", flush=True)
        ini = s.start_terminal(a.alias)
        time.sleep(45)
        ini.unlink(missing_ok=True)
        s.allow_webrequest()
        time.sleep(10)
        # A clean close, so the terminal writes its settings and the saved login; then Wine is stopped.
        s.xdo("search", "--name", "MetaTrader", "windowactivate", "--sync", "key", "alt+F4")
        for p in s.procs:
            try:
                p.wait(timeout=60)
            except subprocess.TimeoutExpired:
                pass
        (s.prefix / "drive_c" / "edge" / "run.ini").write_text(run_ini())
        (base / "setup.done").write_text("ok\n")
        print("mt5 setup: done", flush=True)
        return 0
    finally:
        s.ini.unlink(missing_ok=True)
        s.stop()


if __name__ == "__main__":
    sys.exit(main())
