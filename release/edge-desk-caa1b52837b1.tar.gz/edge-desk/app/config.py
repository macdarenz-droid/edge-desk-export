"""Configuration: limits and sizes from config/app.toml, secrets from the environment.

Nothing secret is ever read from a file in the repo. `load()` validates every value and fails
loudly on anything unknown or out of range, so a typo cannot silently loosen a limit.
"""
from __future__ import annotations

import base64
import binascii
import os
import re
import tomllib
from dataclasses import dataclass, field
from datetime import time
from pathlib import Path
from zoneinfo import ZoneInfo

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = REPO_ROOT / "config" / "app.toml"

# Environment secrets. Values are never logged, returned by the API or written to disk.
SECRET_ENV = {
    "ingest_token": "EDGE_INGEST_TOKEN",                # bearer token the MT5 bridge EA sends
    "dashboard_token": "EDGE_DASHBOARD_TOKEN",          # login for the dashboard
    "vapid_private_key": "EDGE_VAPID_PRIVATE_KEY",      # Web Push signing key (raw P-256, base64url)
    "oanda_token": "EDGE_OANDA_TOKEN",                  # the owner's OANDA practice token, for price candles only (B1)
    "export_token": "EDGE_EXPORT_TOKEN",                # GitHub fine-grained token for the private export repo (B5)
}
# Not a secret but personal (an email address or a site), so it stays out of the repo and is never shown:
# the VAPID "sub" contact the push services can write to (RFC 8292 section 2.1).
SUBJECT_ENV = "EDGE_VAPID_SUBJECT"
MIN_TOKEN_LEN = 32
# Order of the P-256 group (SEC 2 v2, section 2.4.2): a private key is an integer in [1, n - 1].
P256_ORDER = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
_B64URL = re.compile(r"[A-Za-z0-9_-]+={0,2}")
# A subject the push services and py_vapid accept: mailto:<address> or https://<host> (no path).
_SUBJECT = re.compile(r"mailto:[^@\s]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+|https://[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+")
MAX_PUSH_TTL_S = 28 * 24 * 3600   # 4 weeks: the longest TTL the push services keep a message
MIN_PUSH_TTL_S = 60
PAPER_COST_FLOOR_PIPS = 2.0   # paper cost may not go below the research pass case
# A10 storage ceilings (only the owner raises them): budget at most 5 GB, free floor at least 3 GB, 7 daily and 4 weekly
STORAGE_BUDGET_CEILING_GB = 5.0
STORAGE_FREE_FLOOR_MIN_GB = 3.0
BACKUP_DAILY_MAX = 7
BACKUP_WEEKLY_MAX = 4
# B1 feed limits (coordinator ruling 5, 16 Oct 2026: at most 1 request every 2 s, Retry-After honoured, stop after
# 3 failures; card B1: the first 403 or 429 blocks the host for 24 h; first start backfills 120 days).
FEED_MIN_GAP_S = 2.0
FEED_MAX_FAILURES = 3
FEED_MIN_BLOCK_HOURS = 24
FEED_MIN_BACKFILL_DAYS = 120
FEED_MIN_MARKER_DELAY_S = 30      # red team 17 Oct, item 8: a server clock a little ahead cannot claim a minute
# B5: the export goes to a separate private repo only, never this research repo (blueprint "Daily export").
RESEARCH_REPO_NAMES = ("forex-signal",)


class ConfigError(ValueError):
    pass


def _hhmm(value: str, key: str) -> time:
    try:
        hh, mm = value.split(":")
        return time(int(hh), int(mm))
    except (ValueError, AttributeError) as exc:
        raise ConfigError(f"{key}: expected HH:MM, got {value!r}") from exc


@dataclass(frozen=True)
class AppSection:
    name: str
    host: str
    port: int
    db_path: Path
    display_tz: ZoneInfo


@dataclass(frozen=True)
class AccountSection:
    alias: str
    currency: str


@dataclass(frozen=True)
class InstrumentSection:
    symbol: str
    broker_symbols: tuple[str, ...]
    pip_size: float


@dataclass(frozen=True)
class DaySection:
    boundary_tz: ZoneInfo
    boundary_hour: int
    london_open: time
    ny_open: time


@dataclass(frozen=True)
class RiskSection:
    risk_pct_per_trade: float
    max_losses_per_day: int
    trades_after_first_win: int
    loss_after_win_ends_day: bool
    breakeven_band_r: float


@dataclass(frozen=True)
class StreakSection:
    enabled: bool
    green_days_to_start: int
    target_min_r: float
    target_max_r: float
    floor_fraction: float


@dataclass(frozen=True)
class ManagementSection:
    breakeven_from_r: float
    breakeven_to_r: float
    take_or_trail_r: float
    trail_stop_r: float


@dataclass(frozen=True)
class PlannerSection:
    mode: str
    strategy: str
    order_expiry_london: time
    plan_time_london: time


@dataclass(frozen=True)
class AnalyticsSection:
    min_trades: int


@dataclass(frozen=True)
class PaperSection:
    balance: float
    cost_pips: float
    cost_pips_info: float = 1.6
    financing_pips_night: float = 1.0
    financing_wednesday_nights: int = 3


@dataclass(frozen=True)
class FundedSection:
    """Funded-account limits typed by the owner (A5). None = not set."""
    enabled: bool = False
    initial_balance: float | None = None
    daily_loss_pct: float | None = None
    max_loss_pct: float | None = None
    risk_cap_pct: float | None = None
    reset: str = "server_midnight"
    alert_at: tuple[float, ...] = (0.5, 0.8)

    @property
    def is_set(self) -> bool:
        return None not in (self.initial_balance, self.daily_loss_pct, self.max_loss_pct, self.risk_cap_pct)


@dataclass(frozen=True)
class StorageSection:
    """A10: disk budget and backups. Ceilings pinned by tests/test_storage.py."""
    disk_budget_gb: float = 5.0
    free_floor_gb: float = 3.0
    backup_daily_keep: int = 7
    backup_weekly_keep: int = 4


@dataclass(frozen=True)
class FeedSection:
    """B1: OANDA practice EUR/USD M1 bid/ask candles. Limits pinned by tests/test_feed.py."""
    enabled: bool = False
    min_gap_s: float = 2.0
    max_failures: int = 3
    block_hours: int = 24
    cooldown_s: int = 300
    backfill_days: int = 120
    marker_delay_s: int = 30
    poll_s: int = 20
    timeout_s: int = 20


@dataclass(frozen=True)
class ExportSection:
    """B5: the daily export to the owner's separate private export repo (never this research repo)."""
    enabled: bool = False
    repo: str = ""
    branch: str = "main"
    after_ny: time = time(17, 5)


@dataclass(frozen=True)
class BridgeSection:
    contract: str
    stale_after_s: int
    offline_after_s: int
    silent_alert_after_s: int
    max_payload_bytes: int
    max_clock_skew_s: int
    broker_clock: str


@dataclass(frozen=True)
class NotifySection:
    min_interval_s: int
    max_attempts: int
    daily_summary_ny: time
    alert_no_trade_day: bool
    management_alerts: bool
    push_ttl_s: int              # how long a push service keeps an alert for a phone that is offline
    push_ttl_urgent_s: int       # the same for priority 4 and 5


@dataclass(frozen=True)
class Secrets:
    """Secret values from the environment, plus the personal VAPID subject. repr() never shows them."""

    ingest_token: str | None = field(default=None, repr=False)
    dashboard_token: str | None = field(default=None, repr=False)
    vapid_private_key: str | None = field(default=None, repr=False)
    oanda_token: str | None = field(default=None, repr=False)
    export_token: str | None = field(default=None, repr=False)
    vapid_subject: str | None = field(default=None, repr=False)

    def present(self) -> dict[str, bool]:
        return {name: bool(getattr(self, name)) for name in SECRET_ENV}

    @property
    def push_configured(self) -> bool:
        """Web Push can sign alerts only with both the private key and the subject."""
        return bool(self.vapid_private_key and self.vapid_subject)


@dataclass(frozen=True)
class Config:
    app: AppSection
    account: AccountSection
    instrument: InstrumentSection
    day: DaySection
    risk: RiskSection
    streak: StreakSection
    management: ManagementSection
    planner: PlannerSection
    analytics: AnalyticsSection
    paper: PaperSection
    bridge: BridgeSection
    notify: NotifySection
    funded: FundedSection = field(default_factory=FundedSection)
    storage: StorageSection = field(default_factory=StorageSection)
    feed: FeedSection = field(default_factory=FeedSection)
    export: ExportSection = field(default_factory=ExportSection)
    secrets: Secrets = field(default_factory=Secrets, repr=False)

    def is_eurusd(self, symbol: str) -> bool:
        return symbol in self.instrument.broker_symbols


_SECTIONS = {
    "app": {"name", "host", "port", "db_path", "display_tz"},
    "account": {"alias", "currency"},
    "instrument": {"symbol", "broker_symbols", "pip_size"},
    "day": {"boundary_tz", "boundary_hour", "london_open", "ny_open"},
    "risk": {"risk_pct_per_trade", "max_losses_per_day", "trades_after_first_win",
             "loss_after_win_ends_day", "breakeven_band_r"},
    "streak": {"enabled", "green_days_to_start", "target_min_r", "target_max_r", "floor_fraction"},
    "management": {"breakeven_from_r", "breakeven_to_r", "take_or_trail_r", "trail_stop_r"},
    "planner": {"mode", "strategy", "order_expiry_london", "plan_time_london"},
    "analytics": {"min_trades"},
    "paper": {"balance", "cost_pips", "cost_pips_info", "financing_pips_night", "financing_wednesday_nights"},
    "bridge": {"contract", "stale_after_s", "offline_after_s", "silent_alert_after_s",
               "max_payload_bytes", "max_clock_skew_s", "broker_clock"},
    "notify": {"min_interval_s", "max_attempts", "daily_summary_ny", "alert_no_trade_day", "management_alerts",
               "push_ttl_s", "push_ttl_urgent_s"},
    "funded": {"enabled", "initial_balance", "daily_loss_pct", "max_loss_pct", "risk_cap_pct", "reset", "alert_at"},
    "storage": {"disk_budget_gb", "free_floor_gb", "backup_daily_keep", "backup_weekly_keep"},
    "feed": {"enabled", "min_gap_s", "max_failures", "block_hours", "cooldown_s", "backfill_days", "marker_delay_s",
             "poll_s", "timeout_s"},
    "export": {"enabled", "repo", "branch", "after_ny"},
}


# Value types per key. "int" and "num" refuse booleans (in Python True is an int, so `risk_pct_per_trade = true`
# would load as 1.0%); booleans must be real booleans (`enabled = "false"` would load as True).
_NUM, _INT, _OPT = "num", "int", "optional number"
_TYPES = {
    "app": {"name": str, "host": str, "port": _INT, "db_path": str, "display_tz": str},
    "account": {"alias": str, "currency": str},
    "instrument": {"symbol": str, "broker_symbols": list, "pip_size": _NUM},
    "day": {"boundary_tz": str, "boundary_hour": _INT, "london_open": str, "ny_open": str},
    "risk": {"risk_pct_per_trade": _NUM, "max_losses_per_day": _INT, "trades_after_first_win": _INT,
             "loss_after_win_ends_day": bool, "breakeven_band_r": _NUM},
    "streak": {"enabled": bool, "green_days_to_start": _INT, "target_min_r": _NUM, "target_max_r": _NUM,
               "floor_fraction": _NUM},
    "management": {"breakeven_from_r": _NUM, "breakeven_to_r": _NUM, "take_or_trail_r": _NUM, "trail_stop_r": _NUM},
    "planner": {"mode": str, "strategy": str, "order_expiry_london": str, "plan_time_london": str},
    "analytics": {"min_trades": _INT},
    "paper": {"balance": _NUM, "cost_pips": _NUM, "cost_pips_info": _NUM, "financing_pips_night": _NUM,
              "financing_wednesday_nights": _INT},
    "bridge": {"contract": str, "stale_after_s": _INT, "offline_after_s": _INT, "silent_alert_after_s": _INT,
               "max_payload_bytes": _INT, "max_clock_skew_s": _INT, "broker_clock": str},
    "notify": {"min_interval_s": _INT, "max_attempts": _INT, "daily_summary_ny": str,
               "alert_no_trade_day": bool, "management_alerts": bool, "push_ttl_s": _INT, "push_ttl_urgent_s": _INT},
    "funded": {"enabled": bool, "initial_balance": _OPT, "daily_loss_pct": _OPT, "max_loss_pct": _OPT,
               "risk_cap_pct": _OPT, "reset": str, "alert_at": list},
    "storage": {"disk_budget_gb": _NUM, "free_floor_gb": _NUM, "backup_daily_keep": _INT, "backup_weekly_keep": _INT},
    "feed": {"enabled": bool, "min_gap_s": _NUM, "max_failures": _INT, "block_hours": _INT, "cooldown_s": _INT,
             "backfill_days": _INT, "marker_delay_s": _INT, "poll_s": _INT, "timeout_s": _INT},
    "export": {"enabled": bool, "repo": str, "branch": str, "after_ny": str},
}


def _type_ok(value, kind) -> bool:
    if kind == _INT:
        return isinstance(value, int) and not isinstance(value, bool)
    if kind == _NUM:
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if kind == _OPT:      # a number, or "" for not set
        return value == "" or (isinstance(value, (int, float)) and not isinstance(value, bool))
    return isinstance(value, kind)


def _check_types(raw: dict) -> None:
    for name, keys in _TYPES.items():
        for key, kind in keys.items():
            if not _type_ok(raw[name][key], kind):
                want = {_INT: "a whole number", _NUM: "a number", bool: "true or false", str: "text",
                        list: "a list", _OPT: 'a number or "" (not set)'}[kind]
                raise ConfigError(f"{name}.{key} must be {want}, got {raw[name][key]!r}")


def _check_keys(raw: dict) -> None:
    unknown = set(raw) - set(_SECTIONS)
    missing = set(_SECTIONS) - set(raw)
    if unknown or missing:
        raise ConfigError(f"sections: unknown {sorted(unknown)}, missing {sorted(missing)}")
    for name, keys in _SECTIONS.items():
        got = set(raw[name])
        if got != keys:
            raise ConfigError(f"[{name}]: unknown {sorted(got - keys)}, missing {sorted(keys - got)}")


def _require(cond: bool, msg: str) -> None:
    if not cond:
        raise ConfigError(msg)


def _alias_ok(alias: str) -> bool:
    # An alias is a short label. All-digit strings are refused so an account number cannot be used.
    return (isinstance(alias, str) and 1 <= len(alias) <= 32 and not alias.isdigit()
            and all(c.isalnum() or c in "-_" for c in alias))


def vapid_key_bytes(value: str) -> bytes:
    """The raw 32-byte P-256 private key from base64url (padding optional), or ValueError. The message
    never contains the value."""
    if not isinstance(value, str) or not _B64URL.fullmatch(value) or len(value.rstrip("=")) != 43:
        raise ValueError("must be a raw P-256 private key in base64url (43 characters)")
    try:
        raw = base64.urlsafe_b64decode(value.rstrip("=") + "=")
    except (binascii.Error, ValueError):
        raise ValueError("must be a raw P-256 private key in base64url (43 characters)") from None
    if len(raw) != 32 or not 0 < int.from_bytes(raw, "big") < P256_ORDER:
        raise ValueError("is not a valid P-256 private key")
    return raw


def _vapid_key(value: str) -> str:
    try:
        raw = vapid_key_bytes(value)
    except ValueError as exc:
        raise ConfigError(f"{SECRET_ENV['vapid_private_key']} {exc} (make one with: python3 -m app vapid-keygen"
                          " --out FILE)") from None
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()      # one spelling: no padding


def load_secrets(env: dict[str, str] | None = None) -> Secrets:
    env = os.environ if env is None else env
    values = {}
    for name, var in SECRET_ENV.items():
        val = (env.get(var) or "").strip() or None
        if val is not None and name in ("ingest_token", "dashboard_token") and len(val) < MIN_TOKEN_LEN:
            raise ConfigError(f"{var} must be at least {MIN_TOKEN_LEN} characters")
        if val is not None and name == "vapid_private_key":
            val = _vapid_key(val)
        if val is not None and name in ("oanda_token", "export_token") and (len(val) < 20 or any(c.isspace() for c in val)):
            raise ConfigError(f"{var} does not look like a token (20 or more characters, no spaces)")
        values[name] = val
    if values["ingest_token"] and values["ingest_token"] == values["dashboard_token"]:
        # The ingest token sits in a plain file on the VPS; the same value would open the dashboard too.
        raise ConfigError("EDGE_INGEST_TOKEN and EDGE_DASHBOARD_TOKEN must be different")
    subject = (env.get(SUBJECT_ENV) or "").strip() or None
    if subject is not None and not _SUBJECT.fullmatch(subject):
        raise ConfigError(f"{SUBJECT_ENV} must be a mailto: link with an email address, or the https address of a"
                          " site (no path)")
    return Secrets(**values, vapid_subject=subject)


def load(path: Path | str | None = None, env: dict[str, str] | None = None) -> Config:
    path = Path(path) if path else DEFAULT_CONFIG_PATH
    with open(path, "rb") as fh:
        raw = tomllib.load(fh)
    _check_keys(raw)
    _check_types(raw)
    env_map = os.environ if env is None else env

    a = raw["app"]
    db_path = Path(env_map.get("EDGE_DB_PATH") or a["db_path"])
    if not db_path.is_absolute():
        db_path = REPO_ROOT / db_path
    _require(isinstance(a["port"], int) and 1 <= a["port"] <= 65535, "app.port out of range")
    app = AppSection(a["name"], a["host"], a["port"], db_path, ZoneInfo(a["display_tz"]))

    acc = raw["account"]
    _require(_alias_ok(acc["alias"]), "account.alias must be a short label (letters, digits, - or _), not a number")
    account = AccountSection(acc["alias"], acc["currency"])

    ins = raw["instrument"]
    _require(ins["symbol"] == "EURUSD", "instrument.symbol: the app is EUR/USD only")
    _require(all(isinstance(s, str) and s.upper().startswith("EURUSD") for s in ins["broker_symbols"])
             and ins["broker_symbols"], "instrument.broker_symbols must all be EUR/USD names")
    _require(ins["pip_size"] == 0.0001, "instrument.pip_size for EUR/USD is 0.0001")
    instrument = InstrumentSection(ins["symbol"], tuple(ins["broker_symbols"]), ins["pip_size"])

    d = raw["day"]
    _require(isinstance(d["boundary_hour"], int) and 0 <= d["boundary_hour"] <= 23, "day.boundary_hour")
    day = DaySection(ZoneInfo(d["boundary_tz"]), d["boundary_hour"],
                     _hhmm(d["london_open"], "day.london_open"), _hhmm(d["ny_open"], "day.ny_open"))

    r = raw["risk"]
    _require(isinstance(r["risk_pct_per_trade"], (int, float)) and 0 < r["risk_pct_per_trade"] <= 5,
             "risk.risk_pct_per_trade must be above 0 and at most 5")
    _require(isinstance(r["max_losses_per_day"], int) and r["max_losses_per_day"] >= 1, "risk.max_losses_per_day >= 1")
    _require(isinstance(r["trades_after_first_win"], int) and r["trades_after_first_win"] >= 0,
             "risk.trades_after_first_win >= 0")
    _require(isinstance(r["loss_after_win_ends_day"], bool), "risk.loss_after_win_ends_day must be true or false")
    _require(isinstance(r["breakeven_band_r"], (int, float)) and 0 <= r["breakeven_band_r"] < 1,
             "risk.breakeven_band_r must be in [0, 1)")
    risk = RiskSection(float(r["risk_pct_per_trade"]), r["max_losses_per_day"], r["trades_after_first_win"],
                       r["loss_after_win_ends_day"], float(r["breakeven_band_r"]))

    s = raw["streak"]
    _require(isinstance(s["green_days_to_start"], int) and s["green_days_to_start"] >= 1, "streak.green_days_to_start")
    _require(0 < s["target_min_r"] <= s["target_max_r"], "streak targets: 0 < min <= max")
    _require(0 < s["floor_fraction"] < 1, "streak.floor_fraction must be in (0, 1)")
    streak = StreakSection(bool(s["enabled"]), s["green_days_to_start"], float(s["target_min_r"]),
                           float(s["target_max_r"]), float(s["floor_fraction"]))

    m = raw["management"]
    _require(0 < m["breakeven_from_r"] <= m["breakeven_to_r"] < m["take_or_trail_r"], "management R levels out of order")
    _require(0 < m["trail_stop_r"] < m["take_or_trail_r"], "management.trail_stop_r")
    management = ManagementSection(float(m["breakeven_from_r"]), float(m["breakeven_to_r"]),
                                   float(m["take_or_trail_r"]), float(m["trail_stop_r"]))

    p = raw["planner"]
    _require(p["mode"] == "paper", "planner.mode: only \"paper\" exists")
    planner = PlannerSection(p["mode"], p["strategy"], _hhmm(p["order_expiry_london"], "planner.order_expiry_london"),
                             _hhmm(p["plan_time_london"], "planner.plan_time_london"))

    an = raw["analytics"]
    _require(isinstance(an["min_trades"], int) and an["min_trades"] >= 30, "analytics.min_trades must be at least 30")
    analytics = AnalyticsSection(an["min_trades"])

    pa = raw["paper"]
    _require(pa["balance"] > 0, "paper.balance must be positive")
    # 2.0 pips is the pass case until the owner has an account with a measured lower cost (CLAUDE.md).
    _require(PAPER_COST_FLOOR_PIPS <= pa["cost_pips"] <= 10,
             f"paper.cost_pips must be from {PAPER_COST_FLOOR_PIPS} to 10")
    _require(0 < pa["cost_pips_info"] <= pa["cost_pips"], "paper.cost_pips_info must be above 0 and at most cost_pips")
    _require(0 <= pa["financing_pips_night"] <= 10, "paper.financing_pips_night must be in [0, 10]")
    _require(1 <= pa["financing_wednesday_nights"] <= 3, "paper.financing_wednesday_nights: 1 to 3")
    paper = PaperSection(float(pa["balance"]), float(pa["cost_pips"]), float(pa["cost_pips_info"]),
                         float(pa["financing_pips_night"]), pa["financing_wednesday_nights"])

    b = raw["bridge"]
    _require(b["contract"] == "edge-bridge/1", "bridge.contract: this app speaks edge-bridge/1")
    _require(0 < b["stale_after_s"] < b["offline_after_s"] <= b["silent_alert_after_s"], "bridge timings out of order")
    _require(1024 <= b["max_payload_bytes"] <= 4 * 1024 * 1024, "bridge.max_payload_bytes")
    _require(b["broker_clock"] in ("ny_close", "measured"), "bridge.broker_clock must be ny_close or measured")
    bridge = BridgeSection(b["contract"], b["stale_after_s"], b["offline_after_s"], b["silent_alert_after_s"],
                           b["max_payload_bytes"], b["max_clock_skew_s"], b["broker_clock"])

    n = raw["notify"]
    _require(n["min_interval_s"] >= 5, "notify.min_interval_s must be at least 5")
    _require(1 <= n["max_attempts"] <= 3, "notify.max_attempts: 1 to 3")
    for key in ("push_ttl_s", "push_ttl_urgent_s"):
        _require(MIN_PUSH_TTL_S <= n[key] <= MAX_PUSH_TTL_S,
                 f"notify.{key} must be from {MIN_PUSH_TTL_S} to {MAX_PUSH_TTL_S} seconds")
    notify = NotifySection(n["min_interval_s"], n["max_attempts"],
                           _hhmm(n["daily_summary_ny"], "notify.daily_summary_ny"),
                           bool(n["alert_no_trade_day"]), bool(n["management_alerts"]),
                           n["push_ttl_s"], n["push_ttl_urgent_s"])

    fu = raw["funded"]

    def opt(key: str, lo: float, hi: float) -> float | None:
        v = fu[key]
        if v == "":
            return None
        _require(lo < v <= hi, f"funded.{key} must be above {lo} and at most {hi}, or \"\" for not set")
        return float(v)

    _require(fu["reset"] == "server_midnight", "funded.reset: only \"server_midnight\" exists")
    al = fu["alert_at"]
    _require(len(al) == 2 and all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in al)
             and 0 < al[0] < al[1] < 1, "funded.alert_at must be two fractions, rising, between 0 and 1")
    funded = FundedSection(bool(fu["enabled"]), opt("initial_balance", 0, 1e9), opt("daily_loss_pct", 0, 50),
                           opt("max_loss_pct", 0, 50), opt("risk_cap_pct", 0, 50), fu["reset"],
                           tuple(float(x) for x in al))

    st = raw["storage"]
    _require(0 < st["disk_budget_gb"] <= STORAGE_BUDGET_CEILING_GB,
             f"storage.disk_budget_gb must be above 0 and at most {STORAGE_BUDGET_CEILING_GB}")
    _require(STORAGE_FREE_FLOOR_MIN_GB <= st["free_floor_gb"] <= 1000,
             f"storage.free_floor_gb must be at least {STORAGE_FREE_FLOOR_MIN_GB}")
    _require(1 <= st["backup_daily_keep"] <= BACKUP_DAILY_MAX, f"storage.backup_daily_keep: 1 to {BACKUP_DAILY_MAX}")
    _require(0 <= st["backup_weekly_keep"] <= BACKUP_WEEKLY_MAX, f"storage.backup_weekly_keep: 0 to {BACKUP_WEEKLY_MAX}")
    storage = StorageSection(float(st["disk_budget_gb"]), float(st["free_floor_gb"]), st["backup_daily_keep"],
                             st["backup_weekly_keep"])

    fe = raw["feed"]
    _require(FEED_MIN_GAP_S <= fe["min_gap_s"] <= 60, f"feed.min_gap_s must be from {FEED_MIN_GAP_S} to 60")
    _require(1 <= fe["max_failures"] <= FEED_MAX_FAILURES, f"feed.max_failures: 1 to {FEED_MAX_FAILURES}")
    _require(FEED_MIN_BLOCK_HOURS <= fe["block_hours"] <= 24 * 7, f"feed.block_hours: {FEED_MIN_BLOCK_HOURS} to 168")
    _require(60 <= fe["cooldown_s"] <= 86400, "feed.cooldown_s: 60 to 86400")
    _require(FEED_MIN_BACKFILL_DAYS <= fe["backfill_days"] <= 400, f"feed.backfill_days: {FEED_MIN_BACKFILL_DAYS} to 400")
    _require(FEED_MIN_MARKER_DELAY_S <= fe["marker_delay_s"] <= 600,
             f"feed.marker_delay_s: {FEED_MIN_MARKER_DELAY_S} to 600")
    _require(fe["min_gap_s"] <= fe["poll_s"] <= 600, "feed.poll_s: from feed.min_gap_s to 600")
    _require(5 <= fe["timeout_s"] <= 120, "feed.timeout_s: 5 to 120")
    feed = FeedSection(bool(fe["enabled"]), float(fe["min_gap_s"]), fe["max_failures"], fe["block_hours"],
                       fe["cooldown_s"], fe["backfill_days"], fe["marker_delay_s"], fe["poll_s"], fe["timeout_s"])

    ex = raw["export"]
    repo = ex["repo"].strip()
    _require(repo == "" or re.fullmatch(r"[A-Za-z0-9-]{1,39}/[A-Za-z0-9._-]{1,100}", repo) is not None,
             "export.repo must be owner/name, or \"\" (not set)")
    _require(repo.lower().split("/")[-1] not in RESEARCH_REPO_NAMES,
             "export.repo must be the separate private export repo, never the research repo")
    _require(re.fullmatch(r"[A-Za-z0-9._/-]{1,100}", ex["branch"]) is not None, "export.branch")
    _require(not (ex["enabled"] and not repo), "export.enabled needs export.repo")
    export = ExportSection(bool(ex["enabled"]), repo, ex["branch"], _hhmm(ex["after_ny"], "export.after_ny"))

    return Config(app, account, instrument, day, risk, streak, management, planner, analytics, paper,
                  bridge, notify, funded, storage, feed, export, load_secrets(env))
