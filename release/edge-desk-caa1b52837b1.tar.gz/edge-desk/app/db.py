"""Journal storage: one SQLite file (Python standard library, no server, no new dependency).

The saved data shape below is a PROPOSAL waiting for the owner's approval (AGENTS.md: new kinds of
saved data need the owner's approval first). All times are UTC ISO-8601 strings ("...Z").
Money is in the account currency. R is the trade's result divided by its planned risk.

Ledgers (blueprint "Keep the records separate"):
  1. opportunity  every setup the planner found, offered or not (plus planner_run: one row per plan,
                  including "no trade today: <reason>")
  2. choice       the owner's decision on an opportunity, or an own idea with no opportunity
  3. trade        the actual trade: MT5 (read from the bridge) or paper, never mixed (column `book`)
Supporting tables: bridge_status, deal (raw MT5 deals, append-only), position_seen, sl_change,
trade_flag, paper_order, alert, review_note, push_subscription (the owner's phones for Web Push alerts;
added in schema 2, also a proposal waiting for the owner's approval).
"""
from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

SCHEMA_VERSION = 4

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Latest state of each bridge (one row per account alias). The raw snapshot is kept for the Live screen.
CREATE TABLE IF NOT EXISTS bridge_status (
    account_alias   TEXT PRIMARY KEY,
    bridge_session  TEXT NOT NULL,
    last_seq        INTEGER NOT NULL,
    last_seen_utc   TEXT NOT NULL,
    last_reason     TEXT NOT NULL,
    trade_allowed   INTEGER NOT NULL,          -- 1 = terminal could trade (not an investor login)
    server_offset_s INTEGER NOT NULL,          -- trade server clock minus UTC, measured by the EA
    clock_offset_s  INTEGER NOT NULL,          -- offset the app used to turn server times into UTC
    snapshot_json   TEXT NOT NULL              -- the validated payload as received
);

-- Raw closed deals from MT5, append-only, one row per deal ticket. Balance operations included.
CREATE TABLE IF NOT EXISTS deal (
    account_alias TEXT NOT NULL,
    deal_id       TEXT NOT NULL,
    order_id      TEXT,
    position_id   TEXT,
    symbol        TEXT NOT NULL,
    type          TEXT NOT NULL CHECK (type IN ('buy','sell','balance','credit','charge','correction',
                                                'bonus','commission','interest','other')),
    entry         TEXT NOT NULL CHECK (entry IN ('in','out','inout','out_by','none')),
    volume        REAL NOT NULL,
    price         REAL NOT NULL,
    time_utc      TEXT NOT NULL,
    profit        REAL NOT NULL,
    commission    REAL NOT NULL,
    swap          REAL NOT NULL,
    fee           REAL NOT NULL,
    reason        TEXT NOT NULL,               -- tp, sl, so, client, mobile, web, expert, other
    sl            REAL,                        -- stop on the deal (entry: the order's stop; exit: the stop at exit)
    tp            REAL,
    received_utc  TEXT NOT NULL,
    PRIMARY KEY (account_alias, deal_id)
);
CREATE INDEX IF NOT EXISTS deal_position ON deal (account_alias, position_id);

-- Every MT5 position the bridge has seen, with its first-seen stop (the planned risk).
CREATE TABLE IF NOT EXISTS position_seen (
    account_alias  TEXT NOT NULL,
    position_id    TEXT NOT NULL,
    symbol         TEXT NOT NULL,
    side           TEXT NOT NULL CHECK (side IN ('buy','sell')),
    volume         REAL NOT NULL,
    open_price     REAL NOT NULL,
    open_utc       TEXT NOT NULL,
    initial_sl     REAL,                       -- NULL while the position has no stop (hard incident)
    initial_tp     REAL,
    last_sl        REAL,
    last_tp        REAL,
    first_seen_utc TEXT NOT NULL,
    last_seen_utc  TEXT NOT NULL,
    closed_utc     TEXT,
    no_stop_seen   INTEGER NOT NULL DEFAULT 0 CHECK (no_stop_seen IN (0,1)),  -- 1 once seen with no stop:
                                               -- the no_stop incident is raised once per position
    max_fav_r      REAL,                       -- schema 3 (A6): highest R seen from snapshot prices (approximate)
    PRIMARY KEY (account_alias, position_id)
);

-- Stop and target changes on open positions (breakeven moves are detected from here).
CREATE TABLE IF NOT EXISTS sl_change (
    id            INTEGER PRIMARY KEY,
    account_alias TEXT NOT NULL,
    position_id   TEXT NOT NULL,
    at_utc        TEXT NOT NULL,
    old_sl        REAL,
    new_sl        REAL,
    old_tp        REAL,
    new_tp        REAL
);

-- One row per planner run: the plan for a trading day, or "no trade today: <reason>".
CREATE TABLE IF NOT EXISTS planner_run (
    id               INTEGER PRIMARY KEY,
    run_utc          TEXT NOT NULL,
    trading_day      TEXT NOT NULL,            -- YYYY-MM-DD, day ending 17:00 New York
    strategy         TEXT NOT NULL,
    strategy_version TEXT NOT NULL,
    result           TEXT NOT NULL CHECK (result IN ('orders','no_trade')),
    reason           TEXT,                     -- set when result = 'no_trade'
    n_cards          INTEGER NOT NULL DEFAULT 0,
    guard_json       TEXT NOT NULL             -- day guard and streak state at plan time
);
CREATE INDEX IF NOT EXISTS planner_run_day ON planner_run (trading_day);

-- Ledger 1: every opportunity the planner found, offered or not.
CREATE TABLE IF NOT EXISTS opportunity (
    id                 INTEGER PRIMARY KEY,
    planner_run_id     INTEGER NOT NULL REFERENCES planner_run(id),
    created_utc        TEXT NOT NULL,
    trading_day        TEXT NOT NULL,
    symbol             TEXT NOT NULL,
    setup              TEXT NOT NULL,
    side               TEXT NOT NULL CHECK (side IN ('buy','sell')),
    entry              REAL NOT NULL,
    stop               REAL NOT NULL,
    target             REAL NOT NULL,
    target_r           REAL NOT NULL,
    expiry_utc         TEXT NOT NULL,
    swept_level        TEXT,                   -- the liquidity level the setup names
    risk_pct           REAL NOT NULL,
    lots               REAL,
    offered            INTEGER NOT NULL CHECK (offered IN (0,1)),
    not_offered_reason TEXT,
    checklist_json     TEXT NOT NULL DEFAULT '[]'
);

-- Ledger 2: the owner's choice on an opportunity, or an own idea (opportunity_id NULL).
CREATE TABLE IF NOT EXISTS choice (
    id              INTEGER PRIMARY KEY,
    created_utc     TEXT NOT NULL,
    opportunity_id  INTEGER REFERENCES opportunity(id),
    trade_id        INTEGER REFERENCES trade(id),
    decision        TEXT NOT NULL CHECK (decision IN ('take','skip','modify','own_idea')),
    tag             TEXT NOT NULL CHECK (tag IN ('planned','own_idea','rule_break')),
    would_take      INTEGER CHECK (would_take IN (0,1)),
    management      TEXT CHECK (management IN ('close_at_4r','trail_to_2r')),
    note            TEXT NOT NULL DEFAULT ''
);
CREATE UNIQUE INDEX IF NOT EXISTS choice_trade ON choice (trade_id) WHERE trade_id IS NOT NULL;

-- Ledger 3: the actual trade. book = 'mt5' (read from the bridge) or 'paper'. Never mixed in results.
CREATE TABLE IF NOT EXISTS trade (
    id                 INTEGER PRIMARY KEY,
    book               TEXT NOT NULL CHECK (book IN ('mt5','paper')),
    account_alias      TEXT NOT NULL,
    broker_position_id TEXT,                   -- MT5 position ticket (kept on the owner's server only)
    paper_order_id     INTEGER REFERENCES paper_order(id),
    symbol             TEXT NOT NULL,
    side               TEXT NOT NULL CHECK (side IN ('buy','sell')),
    volume             REAL NOT NULL,
    status             TEXT NOT NULL CHECK (status IN ('open','closed')),
    open_utc           TEXT NOT NULL,
    open_price         REAL NOT NULL,
    initial_sl         REAL,
    initial_tp         REAL,
    close_utc          TEXT,
    close_price        REAL,
    close_reason       TEXT CHECK (close_reason IN ('tp','sl','be','manual','so','expired','other')),
    sl_at_exit         REAL,
    profit             REAL NOT NULL DEFAULT 0,
    commission         REAL NOT NULL DEFAULT 0,
    swap               REAL NOT NULL DEFAULT 0,
    fee                REAL NOT NULL DEFAULT 0,
    net_profit         REAL NOT NULL DEFAULT 0,
    risk_money         REAL,                   -- money lost if the first stop had been hit
    stop_pips          REAL,
    r_net              REAL,                   -- net_profit / risk_money (costs included)
    r_gross            REAL,                   -- price move / stop distance (costs excluded)
    balance_at_open    REAL,
    pct_of_balance     REAL,                   -- net_profit / balance_at_open * 100
    trading_day        TEXT NOT NULL,          -- of the open; day ending 17:00 New York
    close_trading_day  TEXT,
    session            TEXT NOT NULL CHECK (session IN ('asia','london','new_york')),
    near_miss          INTEGER CHECK (near_miss IN (0,1)),
    -- schema 3 (A4), MT5 trades: the cost split. Pips on the fill side; NULL where the quote is unknown.
    mid_in               REAL,                 -- mid price at the entry (volume-weighted over entry deals)
    mid_out              REAL,
    spread_in_pips       REAL,
    spread_out_pips      REAL,
    quote_drift_in_pips  REAL,                 -- the fill minus the snapshot's ask or bid on the fill side
    quote_drift_out_pips REAL,
    spread_source        TEXT,                 -- snapshot, own_median or unknown (the weakest of the deals)
    quote_lag_s          INTEGER,              -- the longest snapshot lag behind the trade's deals
    slip_exit_pips       REAL,                 -- a stop exit's fill past the stop (positive = worse)
    gross_mid_pips       REAL,                 -- chart move: mid to mid, before every cost
    net_pips             REAL,                 -- price result plus commission, swap and fee, in pips
    UNIQUE (book, account_alias, broker_position_id)
);
CREATE INDEX IF NOT EXISTS trade_day ON trade (book, trading_day);

-- Automatic flags on trades: rule breaks and incidents found by the app.
CREATE TABLE IF NOT EXISTS trade_flag (
    trade_id   INTEGER NOT NULL REFERENCES trade(id),
    flag       TEXT NOT NULL CHECK (flag IN ('after_max_losses','after_loss_after_win','over_trades_after_win',
                                             'over_open_risk','no_stop','early_close','size_above_risk',
                                             'stop_moved_away','no_checklist','below_tier','over_tier_risk',
                                             'no_stop_to_entry')),
    detail     TEXT NOT NULL DEFAULT '',
    created_utc TEXT NOT NULL,
    PRIMARY KEY (trade_id, flag)
);

-- Paper-trade log: an order card followed exactly as if real money were at stake.
CREATE TABLE IF NOT EXISTS paper_order (
    id             INTEGER PRIMARY KEY,
    created_utc    TEXT NOT NULL,
    opportunity_id INTEGER REFERENCES opportunity(id),
    symbol         TEXT NOT NULL,
    side           TEXT NOT NULL CHECK (side IN ('buy','sell')),
    order_type     TEXT NOT NULL CHECK (order_type IN ('limit','stop','market')),
    entry          REAL NOT NULL,
    stop           REAL NOT NULL,
    target         REAL NOT NULL,
    expiry_utc     TEXT,
    risk_pct       REAL NOT NULL,
    lots           REAL NOT NULL,
    status         TEXT NOT NULL CHECK (status IN ('pending','filled','closed','expired','cancelled')),
    filled_utc     TEXT,
    fill_price     REAL,
    closed_utc     TEXT,
    exit_price     REAL,
    exit_reason    TEXT CHECK (exit_reason IN ('tp','sl','be','manual','expired','cancelled')),
    note           TEXT NOT NULL DEFAULT ''
);

-- Alerts: every message the app sends, with a unique key so nothing is sent twice.
CREATE TABLE IF NOT EXISTS alert (
    id          INTEGER PRIMARY KEY,
    key         TEXT NOT NULL UNIQUE,
    kind        TEXT NOT NULL,
    priority    INTEGER NOT NULL CHECK (priority BETWEEN 1 AND 5),
    title       TEXT NOT NULL,
    body        TEXT NOT NULL,
    created_utc TEXT NOT NULL,
    status      TEXT NOT NULL CHECK (status IN ('queued','sent','failed','skipped')),
    attempts    INTEGER NOT NULL DEFAULT 0,
    sent_utc    TEXT,
    last_error  TEXT,
    next_try_utc TEXT                          -- a hard incident that failed waits until then (back-off)
);

-- The one action item from the weekly review (Rules screen).
CREATE TABLE IF NOT EXISTS review_note (
    id          INTEGER PRIMARY KEY,
    week        TEXT NOT NULL UNIQUE,          -- ISO week, e.g. 2026-W41
    action_item TEXT NOT NULL,
    created_utc TEXT NOT NULL
);

-- Phones that get the alerts by Web Push (schema 2): one row per browser push subscription, saved when the
-- owner taps "Turn on alerts on this phone". The endpoint and keys stay on the owner's server and are never
-- returned by the API. A row is deleted when the push service says the subscription is gone (404 / 410).
CREATE TABLE IF NOT EXISTS push_subscription (
    id          INTEGER PRIMARY KEY,
    endpoint    TEXT NOT NULL UNIQUE,          -- the push service URL for this phone (https)
    p256dh      TEXT NOT NULL,                 -- the phone's P-256 public key, base64url (encrypts the alert)
    auth        TEXT NOT NULL,                 -- the phone's 16-byte auth secret, base64url
    user_agent  TEXT NOT NULL DEFAULT '',      -- browser label, to tell the phones apart (at most 200 chars)
    created_utc TEXT NOT NULL,
    last_ok_utc TEXT,                          -- last time the push service accepted an alert for it
    failures    INTEGER NOT NULL DEFAULT 0,    -- pushes refused other than "gone"
    last_error  TEXT                           -- short reason, never the endpoint or keys
);

-- Setup checks (schema 3): the owner's top-down checklist filled before a trade, or a coded suggestion's
-- checklist. Versioned: an edit adds a row (check_id = the first version's id). A check locks at its first
-- link; an edit after that is an 'after_entry' version, which results by tick leave out.
CREATE TABLE IF NOT EXISTS checklist (
    id            INTEGER PRIMARY KEY,
    check_id      INTEGER NOT NULL,            -- id of version 1 of this check
    version       INTEGER NOT NULL,
    created_utc   TEXT NOT NULL,
    source        TEXT NOT NULL CHECK (source IN ('owner','code')),
    suggestion_id INTEGER,                     -- the suggestion it came from (Phase 3), else NULL
    account_alias TEXT NOT NULL,
    symbol        TEXT NOT NULL,
    side          TEXT NOT NULL CHECK (side IN ('buy','sell')),
    fields_json   TEXT NOT NULL,               -- every field as typed or ticked
    entry         REAL NOT NULL,
    zone_low      REAL NOT NULL,               -- the entry zone (the entry itself when no zone was typed)
    zone_high     REAL NOT NULL,
    stop          REAL NOT NULL,               -- stop reference -/+ cushion
    stop_pips     REAL NOT NULL,
    target        REAL NOT NULL,
    target_r      REAL NOT NULL,
    cost_r        REAL NOT NULL,               -- 2.0 pips in R (the pass case)
    cost_r_info   REAL NOT NULL,               -- 1.6 pips in R
    m1 INTEGER NOT NULL, m2 INTEGER NOT NULL, m3 INTEGER NOT NULL, m4 INTEGER NOT NULL,
    c1 INTEGER NOT NULL, c2 INTEGER NOT NULL, c3 INTEGER NOT NULL, c4 INTEGER NOT NULL, c5 INTEGER NOT NULL,
    score         INTEGER NOT NULL CHECK (score BETWEEN 0 AND 5),
    tier          TEXT NOT NULL CHECK (tier IN ('full','half','none')),
    risk_share    REAL NOT NULL,               -- share of the owner's configured risk: 1, 0.5 or 0
    after_entry   INTEGER NOT NULL DEFAULT 0 CHECK (after_entry IN (0,1)),
    status        TEXT NOT NULL CHECK (status IN ('open','locked','superseded','after_entry','expired')),
    expiry_utc    TEXT NOT NULL,
    locked_utc    TEXT,
    UNIQUE (check_id, version)
);

-- Links from a setup check to the owner's MT5 order and trade (schema 3).
CREATE TABLE IF NOT EXISTS checklist_link (
    id            INTEGER PRIMARY KEY,
    check_id      INTEGER NOT NULL,
    checklist_row INTEGER NOT NULL REFERENCES checklist(id),   -- the version current when the link was made
    created_utc   TEXT NOT NULL,
    account_alias TEXT NOT NULL,
    order_ticket  TEXT,
    position_id   TEXT,
    trade_id      INTEGER REFERENCES trade(id),
    method        TEXT NOT NULL CHECK (method IN ('owner_tap','auto_exact_ticket','auto_match')),
    confirmed     INTEGER NOT NULL CHECK (confirmed IN (0,1)),   -- an auto_match is offered (0) until confirmed
    rejected_utc  TEXT                         -- the owner said it is not this check's trade: ignored from then on
);
CREATE INDEX IF NOT EXISTS checklist_link_check ON checklist_link (check_id);
CREATE UNIQUE INDEX IF NOT EXISTS checklist_link_trade ON checklist_link (check_id, trade_id) WHERE trade_id IS NOT NULL;

-- Quote samples (schema 3): each snapshot's bid and ask per symbol, at the snapshot's own time, for the spread
-- at a fill and the account's own median spread per New York hour (A4).
CREATE TABLE IF NOT EXISTS quote_sample (
    account_alias TEXT NOT NULL,
    symbol        TEXT NOT NULL,
    at_utc        TEXT NOT NULL,
    bid           REAL NOT NULL,
    ask           REAL NOT NULL,
    spread_pips   REAL NOT NULL,
    ny_hour       INTEGER NOT NULL CHECK (ny_hour BETWEEN 0 AND 23),
    PRIMARY KEY (account_alias, symbol, at_utc)
);
CREATE INDEX IF NOT EXISTS quote_sample_hour ON quote_sample (account_alias, symbol, ny_hour);

-- The quote fixed for each buy or sell deal when it was first stored (schema 3, A4): the first snapshot within
-- 10 s after the fill ('snapshot'), else the account's own median spread for that symbol and New York hour from
-- at least 30 earlier samples ('own_median'), else 'unknown'. Never changed afterwards.
CREATE TABLE IF NOT EXISTS deal_quote (
    account_alias TEXT NOT NULL,
    deal_id       TEXT NOT NULL,
    source        TEXT NOT NULL CHECK (source IN ('snapshot','own_median','unknown')),
    bid           REAL,
    ask           REAL,
    mid           REAL,
    spread_pips   REAL,
    drift_pips    REAL,                        -- the fill minus the snapshot's ask (buy) or bid (sell); NULL unless snapshot
    lag_s         INTEGER,                     -- snapshot time minus fill time
    samples       INTEGER,                     -- samples behind an own median
    stored_utc    TEXT NOT NULL,
    PRIMARY KEY (account_alias, deal_id)
);

-- Schema 4 (Part B). EUR/USD 1-minute bid/ask candles from the B1 feed (OANDA practice), complete candles only,
-- one row per minute that traded (ts = the minute's open, unix seconds UTC). They stay on the server: never exported.
CREATE TABLE IF NOT EXISTS m1_bar (
    ts     INTEGER PRIMARY KEY CHECK (ts % 60 = 0),
    bid_o  REAL NOT NULL,
    bid_h  REAL NOT NULL,
    bid_l  REAL NOT NULL,
    bid_c  REAL NOT NULL,
    ask_o  REAL NOT NULL,
    ask_h  REAL NOT NULL,
    ask_l  REAL NOT NULL,
    ask_c  REAL NOT NULL,
    volume INTEGER NOT NULL
);

-- The feed's own state: last_request_ts (the 2 s gap across restarts), complete_through (the marker), failures,
-- stopped_until. No token, no response body.
CREATE TABLE IF NOT EXISTS feed_state (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Every 403 or 429: the host is blocked until until_utc (24 h, or Retry-After if longer), across restarts.
CREATE TABLE IF NOT EXISTS feed_block (
    id          INTEGER PRIMARY KEY,
    host        TEXT NOT NULL,
    code        INTEGER NOT NULL,
    blocked_utc TEXT NOT NULL,
    until_utc   TEXT NOT NULL,
    retry_after TEXT
);

-- Schema 4 (B4): the suggestion log. Append-only: triggers refuse every UPDATE and DELETE; a correction is a new row
-- whose supersedes_id points to the row it corrects. Suggestions come from the coded method (source 'method',
-- R57-1H-NEAR) and the three STATS leads (source 'lead'); a setup below the tier is a row with offered = 0.
CREATE TABLE IF NOT EXISTS suggestion (
    id            INTEGER PRIMARY KEY,
    key           TEXT NOT NULL,               -- source:rule:placement time:side (one per worker output)
    source        TEXT NOT NULL CHECK (source IN ('method','lead')),
    rule_id       TEXT NOT NULL,
    code_sha256   TEXT NOT NULL,
    offered       INTEGER NOT NULL CHECK (offered IN (0,1)),
    reason        TEXT,                        -- why not offered
    made_utc      TEXT NOT NULL,
    placed_ts     INTEGER NOT NULL,            -- when the rule placed it (unix s UTC)
    side          INTEGER NOT NULL CHECK (side IN (-1,1)),
    entry         REAL,                        -- NULL for a lead's market entry at its decision time
    stop          REAL,
    target        REAL,
    expiry_ts     INTEGER,
    score         INTEGER,
    tier          TEXT,
    w             REAL,
    ticks_json    TEXT NOT NULL DEFAULT '{}',
    record_line   TEXT NOT NULL,
    late          INTEGER NOT NULL DEFAULT 0 CHECK (late IN (0,1)),
    supersedes_id INTEGER REFERENCES suggestion(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS suggestion_key ON suggestion (key) WHERE supersedes_id IS NULL;

CREATE TABLE IF NOT EXISTS suggestion_decision (
    id            INTEGER PRIMARY KEY,
    suggestion_id INTEGER NOT NULL REFERENCES suggestion(id),
    decision      TEXT NOT NULL CHECK (decision IN ('take','skip','changed')),
    reason        TEXT NOT NULL DEFAULT '',
    decided_utc   TEXT NOT NULL,
    supersedes_id INTEGER REFERENCES suggestion_decision(id)
);

CREATE TABLE IF NOT EXISTS suggestion_link (
    id            INTEGER PRIMARY KEY,
    suggestion_id INTEGER NOT NULL REFERENCES suggestion(id),
    created_utc   TEXT NOT NULL,
    account_alias TEXT NOT NULL,
    order_ticket  TEXT,
    position_id   TEXT,
    trade_id      INTEGER REFERENCES trade(id),
    method        TEXT NOT NULL CHECK (method IN ('owner_tap','auto_exact_ticket','auto_match')),
    confirmed     INTEGER NOT NULL CHECK (confirmed IN (0,1)),
    rejected      INTEGER NOT NULL DEFAULT 0 CHECK (rejected IN (0,1)),
    supersedes_id INTEGER REFERENCES suggestion_link(id)
);

CREATE TABLE IF NOT EXISTS suggestion_result (
    id            INTEGER PRIMARY KEY,
    suggestion_id INTEGER NOT NULL UNIQUE REFERENCES suggestion(id),
    outcome       TEXT NOT NULL CHECK (outcome IN ('filled','expired','cancelled','no_trade')),
    exit_reason   TEXT,
    R_20          REAL,                        -- R after 2.0 pips (method) or the lead's own unit
    R_16          REAL,
    R_before      REAL,                        -- before costs
    unit          TEXT NOT NULL DEFAULT 'R' CHECK (unit IN ('R','pips')),
    settled_utc   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS suggestion_event (
    id            INTEGER PRIMARY KEY,
    suggestion_id INTEGER NOT NULL REFERENCES suggestion(id),
    kind          TEXT NOT NULL CHECK (kind IN ('cancel','expiry','lead_exit')),
    at_ts         INTEGER NOT NULL,
    made_utc      TEXT NOT NULL,
    detail        TEXT NOT NULL DEFAULT '',
    UNIQUE (suggestion_id, kind)
);

-- Each worker run (the method worker at each 1h close; the lead worker), including late and skipped runs.
CREATE TABLE IF NOT EXISTS worker_run (
    id         INTEGER PRIMARY KEY,
    worker     TEXT NOT NULL CHECK (worker IN ('method','lead','export')),
    close_ts   INTEGER NOT NULL,
    status     TEXT NOT NULL,
    detail     TEXT NOT NULL DEFAULT '',
    made_utc   TEXT NOT NULL
);

-- The lead worker (B3): one row per run of STATS's pinned compute_run, and its lines (kept on the server only).
CREATE TABLE IF NOT EXISTS lead_run (
    id              INTEGER PRIMARY KEY,
    run_utc         TEXT NOT NULL,
    data_end_ts     INTEGER NOT NULL,
    status          TEXT NOT NULL,
    calendar_sha256 TEXT,
    tree_sha256     TEXT,
    versions_json   TEXT NOT NULL DEFAULT '{}',
    state_json      TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS lead_line (
    id          INTEGER PRIMARY KEY,
    run_id      INTEGER NOT NULL REFERENCES lead_run(id),
    pick_id     TEXT NOT NULL,
    position_id TEXT,
    kind        TEXT NOT NULL,
    line_json   TEXT NOT NULL,
    line_sha256 TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS lead_line_position ON lead_line (position_id) WHERE position_id IS NOT NULL;
"""


APPEND_ONLY_TABLES = ("suggestion", "suggestion_decision", "suggestion_link", "suggestion_result", "suggestion_event",
                      "worker_run", "lead_run", "lead_line")
for _t in APPEND_ONLY_TABLES:
    SCHEMA += (f"CREATE TRIGGER IF NOT EXISTS {_t}_no_update BEFORE UPDATE ON {_t} "
               f"BEGIN SELECT RAISE(ABORT, '{_t} is append-only'); END;\n"
               f"CREATE TRIGGER IF NOT EXISTS {_t}_no_delete BEFORE DELETE ON {_t} "
               f"BEGIN SELECT RAISE(ABORT, '{_t} is append-only'); END;\n")


def connect(path: Path | str) -> sqlite3.Connection:
    """Open (and create or migrate) the journal. Use ':memory:' in tests."""
    if str(path) != ":memory:":
        Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    if str(path) != ":memory:":
        conn.execute("PRAGMA journal_mode = WAL")
    migrate(conn)
    return conn


# Columns appended to a table after it was first created: CREATE TABLE IF NOT EXISTS leaves an existing
# table alone, so an older journal file gets them here (append-only, same definition as in SCHEMA).
_APPENDED_COLUMNS = (
    ("position_seen", "no_stop_seen", "INTEGER NOT NULL DEFAULT 0 CHECK (no_stop_seen IN (0,1))"),
    ("alert", "next_try_utc", "TEXT"),
    ("position_seen", "max_fav_r", "REAL"),
    # schema 3 (A4): the cost split of each MT5 trade
    ("trade", "mid_in", "REAL"),
    ("trade", "mid_out", "REAL"),
    ("trade", "spread_in_pips", "REAL"),
    ("trade", "spread_out_pips", "REAL"),
    ("trade", "quote_drift_in_pips", "REAL"),
    ("trade", "quote_drift_out_pips", "REAL"),
    ("trade", "spread_source", "TEXT"),
    ("trade", "quote_lag_s", "INTEGER"),
    ("trade", "slip_exit_pips", "REAL"),
    ("trade", "gross_mid_pips", "REAL"),
    ("trade", "net_pips", "REAL"),
)


# 2 -> 3: trade_flag's CHECK lists the flags, and SQLite cannot change a CHECK in place, so the table is rebuilt
# with the full list: copy the rows into a new table, drop the old one, rename, in one transaction with foreign
# keys on (A3).
_TRADE_FLAG_COPY = "INSERT INTO trade_flag_new (trade_id, flag, detail, created_utc)" \
                   " SELECT trade_id, flag, detail, created_utc FROM trade_flag"


def _trade_flag_sql() -> str:
    start = SCHEMA.index("CREATE TABLE IF NOT EXISTS trade_flag (")
    return SCHEMA[start:SCHEMA.index(");", start) + 2]


def _rebuild_trade_flag(conn: sqlite3.Connection) -> None:
    sql = conn.execute("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'trade_flag'").fetchone()
    if sql is None or "no_stop_to_entry" in sql[0]:
        return
    conn.execute(_trade_flag_sql().replace("IF NOT EXISTS trade_flag (", "trade_flag_new (", 1))
    conn.execute(_TRADE_FLAG_COPY)
    conn.execute("DROP TABLE trade_flag")
    conn.execute("ALTER TABLE trade_flag_new RENAME TO trade_flag")


def migrate(conn: sqlite3.Connection) -> None:
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("BEGIN IMMEDIATE")
    try:
        _migrate(conn)
        bad = conn.execute("PRAGMA foreign_key_check").fetchall()
        if bad:
            raise sqlite3.IntegrityError(f"foreign key check failed after migration: {len(bad)} rows")
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    conn.execute("COMMIT")


def _migrate(conn: sqlite3.Connection) -> None:
    for statement in _statements(SCHEMA):
        conn.execute(statement)
    _rebuild_trade_flag(conn)
    for table, column, definition in _APPENDED_COLUMNS:
        if column not in [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
    row = conn.execute("SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
    if row is None:
        conn.execute("INSERT INTO meta (key, value) VALUES ('schema_version', ?)", (str(SCHEMA_VERSION),))
    elif int(row["value"]) > SCHEMA_VERSION:
        raise RuntimeError(f"journal schema {row['value']} is newer than this app ({SCHEMA_VERSION})")
    elif int(row["value"]) < SCHEMA_VERSION:
        # The tables added since (push_subscription in 2; checklist and checklist_link in 3) were created above,
        # and trade_flag was rebuilt with the schema 3 flags.
        conn.execute("UPDATE meta SET value = ? WHERE key = 'schema_version'", (str(SCHEMA_VERSION),))


def _statements(script: str) -> list[str]:
    """The script's statements one by one (executescript would COMMIT the open migration transaction)."""
    out, buf = [], ""
    for line in script.splitlines(keepends=True):
        buf += line
        if sqlite3.complete_statement(buf):
            if buf.strip():
                out.append(buf.strip())
            buf = ""
    return out


# One connection is shared by the server threads; every write goes through this lock.
_LOCK = threading.RLock()


@contextmanager
def transaction(conn: sqlite3.Connection):
    """Serialise writers and run the block as one transaction (rolled back on error)."""
    with _LOCK:
        if conn.in_transaction:  # nested use joins the outer transaction
            yield conn
            return
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        conn.execute("COMMIT")
