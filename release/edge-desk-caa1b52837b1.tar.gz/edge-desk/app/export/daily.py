"""B5 daily export: after 17:05 New York, export/<date>/audit.jsonl, hashes.jsonl and SHA256SUMS to the owner's
separate private export repo, through GitHub's REST contents API, on its one branch.

Sources (read 17 Oct 2026; GitHub's docs change):
- https://docs.github.com/en/rest/repos/contents : "Create or update file contents" PUT /repos/{owner}/{repo}/
  contents/{path} with message, content (Base64), sha ("Required if you are updating a file") and branch; "Get
  repository content" GET .../contents/{path}?ref=<branch> (base64 content, sha; a folder lists its files); headers
  Authorization: Bearer <token>, Accept: application/vnd.github+json, X-GitHub-Api-Version: 2026-03-10.
- https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens :
  GET contents needs "Contents" read, PUT needs "Contents" write.
- https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens :
  a fine-grained token can be limited to "Only select repositories"; the page says nothing about branches, so a
  branch limit is not assumed (the app itself refuses any other repo and branch). "Tokens always include read-only
  access to all public repositories on GitHub."

audit.jsonl: one row per suggestion, decision, link, event and own MT5 trade of the trading day, from ALLOWED only:
times, rule id, code sha256, side, score and ticks, order and position tickets, the decision and its reason, the
owner's own trades' R and pips, the account alias. No prices, and no paper result of the coded method or the leads
(suggestion_result and lead lines stay on the server). hashes.jsonl: the sha256 of each suggestion row (its full
row, prices included, hashed only) and each lead line (STATS's canonical form, fwd_core._canon), for STATS's check.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import re
import sqlite3
import urllib.error
import urllib.request
from datetime import date, datetime, time, timezone
from pathlib import Path
from urllib.parse import quote, urlsplit

from app import db
from app.suggest import log as L
from app.timeutil import NEW_YORK, day_bounds, from_iso, to_iso

API = "https://api.github.com"
API_VERSION = "2026-03-10"
FILES = ("audit.jsonl", "hashes.jsonl")
CAL_FILES = ("FORWARD_EVENTS.csv", "FORWARD_EVENTS.json")
ALLOWED = {
    "suggestion": {"kind", "id", "source", "rule_id", "code_sha256", "offered", "reason", "made_utc", "placed_utc",
                   "side", "expiry_utc", "score", "tier", "w", "ticks", "late", "supersedes_id"},
    "decision": {"kind", "id", "suggestion_id", "decision", "reason", "decided_utc", "supersedes_id"},
    "link": {"kind", "id", "suggestion_id", "created_utc", "order_ticket", "position_ticket", "trade_id", "method",
             "confirmed", "rejected", "supersedes_id"},
    "event": {"kind", "id", "suggestion_id", "event", "at_utc", "made_utc"},
    "own_trade": {"kind", "id", "account", "position_ticket", "open_utc", "close_utc", "side", "r", "pips",
                  "suggestion_id", "own_idea"},
}
TICKET_KEYS = {"order_ticket", "position_ticket"}
HASH_KEYS = {"code_sha256"}                    # a sha256 in hex, checked as one
_HEX64 = re.compile(r"[0-9a-f]{64}")
_WORDS = re.compile(r"login|server|passw|token|secret", re.I)
_LONG_NUMBER = re.compile(r"(?<![\d.])\d{6,}(?![\d.])")


class ExportRefused(RuntimeError):
    pass


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Never follow a redirect: the Authorization header would go with it (red team 17 Oct, item 1)."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


OPENER = urllib.request.build_opener(_NoRedirect)


def _secrets(cfg) -> list[str]:
    s = cfg.secrets
    return [v for v in (s.ingest_token, s.dashboard_token, s.vapid_private_key, s.oanda_token, s.export_token) if v]


def check_row(row: dict, cfg) -> None:
    """ExportRefused unless every key is on the kind's allow-list and no key or value holds an account number,
    a login, a server, a password or a token (ticket fields may hold ticket numbers; the account is the alias)."""
    kind = row.get("kind")
    if kind not in ALLOWED:
        raise ExportRefused(f"unknown row kind {kind!r}")
    extra = set(row) - ALLOWED[kind]
    if extra:
        raise ExportRefused(f"{kind}: fields not on the allow-list: {sorted(extra)}")
    secrets = _secrets(cfg)
    for k, v in row.items():
        if _WORDS.search(k):
            raise ExportRefused(f"{kind}: key {k!r}")
        if k in HASH_KEYS:
            if not (isinstance(v, str) and _HEX64.fullmatch(v)):
                raise ExportRefused(f"{kind}.{k}: not a sha256")
            continue
        texts = [json.dumps(v, sort_keys=True)] if isinstance(v, (dict, list)) else [str(v)] if v is not None else []
        for t in texts:
            if any(sec in t for sec in secrets) or _WORDS.search(t):
                raise ExportRefused(f"{kind}.{k}: holds a login, server, password or token")
            if k not in TICKET_KEYS and _LONG_NUMBER.search(t):
                raise ExportRefused(f"{kind}.{k}: holds a long number (an account or login?)")
    if kind == "own_trade" and row.get("account") != cfg.account.alias:
        raise ExportRefused("own_trade.account must be the account alias")


_PRICE = re.compile(r"(?<![\d.])\d{1,3}\.\d{3,5}(?![\d.])")


def _clean(text: str | None, cfg) -> str:
    """Free text (a reason) that would trip check_row is replaced, never sent; a price-like number in it is taken
    out (red team 17 Oct, item 12: the export holds no prices)."""
    t = _PRICE.sub("[price]", text or "")
    if any(s in t for s in _secrets(cfg)) or _WORDS.search(t) or _LONG_NUMBER.search(t):
        return "[removed: it looked like an account detail]"
    return t


def _iso(ts) -> str | None:
    return None if ts is None else to_iso(datetime.fromtimestamp(int(ts), NEW_YORK))


def _in(iso: str | None, lo: datetime, hi: datetime) -> bool:
    return iso is not None and lo <= from_iso(iso) < hi


def _canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)


def hash_key(conn: sqlite3.Connection) -> str:
    """The server's own key for the suggestion hashes (red team 17 Oct, item 6): an unkeyed sha256 of a row whose
    other fields are in audit.jsonl could be reversed to its prices. Kept in the journal (meta), never exported;
    whether STATS receives it is the coordinator's ruling."""
    row = conn.execute("SELECT value FROM meta WHERE key = 'export_hash_key'").fetchone()
    if row is not None:
        return row[0]
    key = secrets.token_hex(32)
    with db.transaction(conn):
        conn.execute("INSERT OR IGNORE INTO meta (key, value) VALUES ('export_hash_key', ?)", (key,))
    return conn.execute("SELECT value FROM meta WHERE key = 'export_hash_key'").fetchone()[0]


def build(conn: sqlite3.Connection, cfg, day: date) -> dict:
    """The day's three files as bytes. The same DB gives the same bytes."""
    lo, hi = day_bounds(day, cfg.day.boundary_tz, cfg.day.boundary_hour)
    audit, hashes = [], []
    for s in conn.execute("SELECT * FROM suggestion ORDER BY id"):
        s = dict(s)
        if not _in(s["made_utc"], lo, hi):
            continue
        audit.append({"kind": "suggestion", "id": s["id"], "source": s["source"], "rule_id": s["rule_id"],
                      "code_sha256": s["code_sha256"], "offered": s["offered"], "reason": _clean(s["reason"], cfg),
                      "made_utc": s["made_utc"], "placed_utc": _iso(s["placed_ts"]), "side": s["side"],
                      "expiry_utc": _iso(s["expiry_ts"]), "score": s["score"], "tier": s["tier"], "w": s["w"],
                      "ticks": json.loads(s["ticks_json"] or "{}"), "late": s["late"],
                      "supersedes_id": s["supersedes_id"]})
        hashes.append({"kind": "suggestion", "key": s["key"], "keyed": "hmac-sha256",
                       "sha256": hmac.new(hash_key(conn).encode(), _canon(s).encode(), hashlib.sha256).hexdigest()})
    for d in conn.execute("SELECT * FROM suggestion_decision ORDER BY id"):
        if _in(d["decided_utc"], lo, hi):
            audit.append({"kind": "decision", "id": d["id"], "suggestion_id": d["suggestion_id"],
                          "decision": d["decision"], "reason": _clean(d["reason"], cfg),
                          "decided_utc": d["decided_utc"], "supersedes_id": d["supersedes_id"]})
    for k in conn.execute("SELECT * FROM suggestion_link ORDER BY id"):
        if _in(k["created_utc"], lo, hi):
            audit.append({"kind": "link", "id": k["id"], "suggestion_id": k["suggestion_id"],
                          "created_utc": k["created_utc"], "order_ticket": k["order_ticket"],
                          "position_ticket": k["position_id"], "trade_id": k["trade_id"], "method": k["method"],
                          "confirmed": k["confirmed"], "rejected": k["rejected"], "supersedes_id": k["supersedes_id"]})
    for e in conn.execute("SELECT * FROM suggestion_event ORDER BY id"):
        if _in(e["made_utc"], lo, hi):
            audit.append({"kind": "event", "id": e["id"], "suggestion_id": e["suggestion_id"], "event": e["kind"],
                          "at_utc": _iso(e["at_ts"]), "made_utc": e["made_utc"]})
    links = {}
    for k in conn.execute("SELECT suggestion_id, trade_id FROM suggestion_link WHERE trade_id IS NOT NULL"
                          " AND confirmed = 1 AND rejected = 0 ORDER BY id"):
        links[k["trade_id"]] = k["suggestion_id"]
    for t in conn.execute("SELECT * FROM trade WHERE book = 'mt5' AND account_alias = ? AND status = 'closed'"
                          " ORDER BY id", (cfg.account.alias,)):
        if _in(t["close_utc"], lo, hi):
            audit.append({"kind": "own_trade", "id": t["id"], "account": cfg.account.alias,
                          "position_ticket": t["broker_position_id"], "open_utc": t["open_utc"],
                          "close_utc": t["close_utc"], "side": t["side"], "r": t["r_net"], "pips": t["net_pips"],
                          "suggestion_id": links.get(t["id"]), "own_idea": 0 if t["id"] in links else 1})
    for ln in conn.execute("SELECT l.* FROM lead_line l JOIN lead_run r ON r.id = l.run_id ORDER BY l.id"):
        run = conn.execute("SELECT run_utc FROM lead_run WHERE id = ?", (ln["run_id"],)).fetchone()
        if _in(run["run_utc"], lo, hi):
            hashes.append({"kind": "lead_line", "pick_id": ln["pick_id"], "position_id": ln["position_id"],
                           "sha256": ln["line_sha256"]})
    for r in audit:
        check_row(r, cfg)
    files = {"audit.jsonl": "".join(_canon(r) + "\n" for r in audit).encode(),
             "hashes.jsonl": "".join(_canon(r) + "\n" for r in hashes).encode()}
    files["SHA256SUMS"] = "".join(f"{hashlib.sha256(files[n]).hexdigest()}  {n}\n" for n in FILES).encode()
    return files


# ---------------------------------------------------------------- GitHub

class GitHub:
    """Contents API for the one configured repo and branch, under export/ (write) and calendar/ (read) only."""

    def __init__(self, token: str, repo: str, branch: str, api: str = API, timeout_s: float = 30.0):
        u = urlsplit(api)
        if not (api == API or (u.scheme == "http" and u.hostname == "127.0.0.1")):
            raise ExportRefused("the export goes to api.github.com only (or a local fake in tests)")
        if not token:
            raise ExportRefused("no export token (EDGE_EXPORT_TOKEN)")
        self._token, self.repo, self.branch, self.api, self.timeout_s = token, repo, branch, api.rstrip("/"), timeout_s
        self._private_ok = False          # put() refuses until require_private() has passed on this object

    def __repr__(self) -> str:
        return f"GitHub(repo={self.repo!r}, branch={self.branch!r})"

    def _url(self, path: str, repo: str | None, branch: str | None, write: bool) -> str:
        if (repo or self.repo) != self.repo or (branch or self.branch) != self.branch:
            raise ExportRefused("only the configured export repo and branch")
        parts = path.split("/")
        top = ("export",) if write else ("export", "calendar")
        if parts[0] not in top or any(p in ("", ".", "..") for p in parts):
            raise ExportRefused(f"path {path[:60]!r} is outside {'/'.join(top)}")
        return f"{self.api}/repos/{self.repo}/contents/{quote(path)}"

    def _req(self, method: str, url: str, body: dict | None = None):
        data = None if body is None else json.dumps(body).encode()
        req = urllib.request.Request(url, data=data, method=method, headers={
            "Authorization": f"Bearer {self._token}", "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": API_VERSION, "Content-Type": "application/json"})
        try:
            with OPENER.open(req, timeout=self.timeout_s) as r:
                return r.status, json.loads(r.read() or b"null")
        except urllib.error.HTTPError as e:
            e.close()
            return e.code, None
        except (urllib.error.URLError, OSError, TimeoutError) as e:
            raise ExportRefused(f"network error {type(e).__name__}") from None

    def require_private(self) -> None:
        """GET /repos/{repo}: the daily log goes only to a repo GitHub reports as private (17 Oct 2026: the owner
        made the export repo public for the release; the log of suggestions and his decisions is never published,
        AGENTS.md "Never: share, sell or publish signals"). Anything but "private": true refuses the send."""
        code, body = self._req("GET", f"{self.api}/repos/{self.repo}")
        if code != 200 or not isinstance(body, dict):
            raise ExportRefused(f"could not read whether the export repo is private (HTTP {code})")
        # "internal" (GitHub Enterprise) also says private: true, yet every enterprise member can read it
        if body.get("private") is not True or body.get("visibility", "private") != "private":
            raise ExportRefused(PUBLIC_REASON)
        self._private_ok = True

    def get(self, path: str):
        code, body = self._req("GET", self._url(path, None, None, False) + f"?ref={quote(self.branch)}")
        if code == 404:
            return None
        if code != 200:
            raise ExportRefused(f"GET {path}: HTTP {code}")
        return body

    def put(self, path: str, data: bytes, message: str, repo: str | None = None, branch: str | None = None) -> None:
        url = self._url(path, repo, branch, True)
        if not self._private_ok:
            raise ExportRefused("the export repo was not checked private before this send")
        old = self.get(path)
        body = {"message": message, "content": base64.b64encode(data).decode(), "branch": self.branch}
        if isinstance(old, dict) and old.get("sha"):
            body["sha"] = old["sha"]
        code, _ = self._req("PUT", url, body)
        if code not in (200, 201):
            raise ExportRefused(f"PUT {path}: HTTP {code}")

    def read(self, path: str) -> bytes | None:
        body = self.get(path)
        if body is None:
            return None
        if not isinstance(body, dict) or body.get("encoding") != "base64":
            raise ExportRefused(f"{path}: not a base64 file")
        return base64.b64decode(body["content"])


PUBLIC_REASON = "the export repo is public"
MAX_TRIES_A_DAY = 3          # failed sends of one day's files, a UTC day (red team 17 Oct, item 5)


def export_day(conn: sqlite3.Connection, cfg, day: date, *, now: datetime, api: str = API) -> dict:
    """Send one trading day's files after [export] after_ny New York that day; again only when they change.
    At most MAX_TRIES_A_DAY failed tries a UTC day, then it stops until the next UTC day."""
    if not cfg.export.enabled:
        return {"status": "off"}
    due = datetime.combine(day, cfg.export.after_ny, NEW_YORK)
    if now < due:
        return {"status": "too early"}
    close = int(day_bounds(day, cfg.day.boundary_tz, cfg.day.boundary_hour)[1].timestamp())
    runs = L.runs(conn, "export", close)
    utc_day = now.astimezone(timezone.utc).date().isoformat()
    if sum(1 for r in runs if r["status"] == "failed" and r["made_utc"].startswith(utc_day)) >= MAX_TRIES_A_DAY:
        return {"status": "stopped"}
    try:
        files = build(conn, cfg, day)
        digest = hashlib.sha256(files["SHA256SUMS"]).hexdigest()
        sent = [r for r in runs if r["status"] == "sent"]
        if sent and sent[-1]["detail"] == f"sha256 {digest}":
            return {"status": "done"}
        gh = GitHub(cfg.secrets.export_token, cfg.export.repo, cfg.export.branch, api=api)
        gh.require_private()
        for name in FILES + ("SHA256SUMS",):
            gh.put(f"export/{day.isoformat()}/{name}", files[name], f"Edge Desk log {day.isoformat()}: {name}")
    except ExportRefused as e:
        L.log_run(conn, "export", close, "failed", now=now, detail=str(e)[:300])
        return {"status": "failed", "reason": str(e)[:300]}
    L.log_run(conn, "export", close, "sent", now=now, detail=f"sha256 {digest}")
    return {"status": "sent", "files": {k: hashlib.sha256(v).hexdigest() for k, v in files.items()}}


# ---------------------------------------------------------------- calendar pins in (B3)

def current_calendar(folder: Path) -> Path | None:
    p = Path(folder) / "CURRENT"
    if not p.exists():
        return None
    d = Path(folder) / p.read_text().strip()
    return d if d.is_dir() else None


def pull_calendar(cfg, folder: Path, *, api: str = API) -> Path:
    """The export repo's calendar/ pin (the coordinator puts it there after fwd_io.check_calendar_pin): kept only
    when its CSV's sha256 equals the pin's; the lead child checks it again with fwd_core.read_calendar."""
    gh = GitHub(cfg.secrets.export_token, cfg.export.repo, cfg.export.branch, api=api)
    data = {n: gh.read(f"calendar/{n}") for n in CAL_FILES}
    if any(v is None for v in data.values()):
        raise ExportRefused("no calendar pin in the export repo")
    try:
        pin = json.loads(data["FORWARD_EVENTS.json"])
    except ValueError:
        raise ExportRefused("the calendar pin is not JSON") from None
    sha = hashlib.sha256(data["FORWARD_EVENTS.csv"]).hexdigest()
    if pin.get("sha256") != sha:
        raise ExportRefused("the calendar CSV differs from its pin")
    d = Path(folder) / sha[:16]
    d.mkdir(parents=True, exist_ok=True)
    for n, v in data.items():
        (d / n).write_bytes(v)
    (Path(folder) / "CURRENT").write_text(d.name + "\n")
    return d


__all__ = ["build", "check_row", "export_day", "pull_calendar", "current_calendar", "GitHub", "ExportRefused", "db",
           "time"]
