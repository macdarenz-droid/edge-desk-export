"""Funded-account limits (A5), for the planned FundedNext Stellar account. Values come only from config [funded],
typed by the owner from FundedNext's official pages; blank values show "Not set" and send no alert.

Readings (research/departments/COST/sources/FUNDEDNEXT.md, read 13 Oct 2026; terms change):
- Daily loss = the balance at the last reset minus equity now (closed results of the day plus open positions,
  with commission and swap). That day's closed profit raises the allowance, as in FundedNext's example
  "($100,000 x 0.05 + $2,000) = $7,000". Breach: daily loss above initial balance x daily_loss_pct.
- An open loss held past the reset counts against the new day (the new day starts from the closed balance).
- Maximum loss: static floor at initial balance x (1 - max_loss_pct); breach when equity is below it.
- The daily reset is 00:00 on the broker's server clock, from the bridge's measured offset
  (bridge/CONTRACT.md "Broker clock", bridge_status.server_offset_s), not a New York rule: FundedNext says GMT+3
  "during daylight saving time" without saying whose.
- Open risk (FundedNext funded stage: "maximum potential loss on a trade at a time, based on stop-loss placement",
  plus floating losses, against initial balance): for each position the larger of its loss at the stop from
  the open price and its floating loss now; for each pending order its loss at the stop from the order price.
  A position or order with no stop has no stop-based risk and counts with its floating loss only (the no-stop
  incident covers it). This combination is a working reading, not confirmed with FundedNext.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta

from app.notify.alerts import Alert
from app.timeutil import UTC, from_iso, to_iso

NOT_SET = "Not set"


def last_reset_utc(now: datetime, server_offset_s: int) -> datetime:
    """The last 00:00 on the server clock (server time = UTC + offset), in UTC."""
    server = now.astimezone(UTC) + timedelta(seconds=server_offset_s)
    midnight = server.replace(hour=0, minute=0, second=0, microsecond=0)
    return midnight - timedelta(seconds=server_offset_s)


def evaluate(f, *, start_balance: float, balance: float, equity: float, open_risk: float | None) -> dict:
    """The limit state from the balance at the last reset, the balance and equity now, and the open risk."""
    out = {"enabled": f.enabled, "set": f.is_set, "status": "Off" if not f.enabled else NOT_SET,
           "start_balance": start_balance, "balance": balance, "equity": equity, "daily_loss": start_balance - equity,
           "daily_limit": None, "daily_used": None, "daily_breach": None, "floor": None, "to_floor": None,
           "max_breach": None, "open_risk": open_risk, "open_risk_pct": None, "risk_cap_pct": f.risk_cap_pct,
           "cap_hit": None, "alert_at": list(f.alert_at)}
    if not f.enabled or not f.is_set:
        return out
    init = f.initial_balance
    limit = init * f.daily_loss_pct / 100.0
    floor = init * (1 - f.max_loss_pct / 100.0)
    loss = start_balance - equity
    out.update(daily_limit=limit, daily_used=max(0.0, loss) / limit, daily_breach=loss > limit + 1e-9,
               floor=floor, to_floor=equity - floor, max_breach=equity < floor - 1e-9)
    if open_risk is not None:
        pct = open_risk / init * 100.0
        out.update(open_risk_pct=pct, cap_hit=pct > f.risk_cap_pct + 1e-9)
    out["status"] = "Breached" if out["daily_breach"] or out["max_breach"] else "Within limits"
    return out


def _value_per_price(info: dict | None, volume: float) -> float | None:
    if info and info.get("tick_size", 0) > 0 and info.get("tick_value", 0) > 0:
        return info["tick_value"] / info["tick_size"] * volume
    if info and info.get("contract_size", 0) > 0:
        return info["contract_size"] * volume
    return None


def open_risk(snap: dict) -> float | None:
    """Stop-based risk plus floating losses of every position and pending order in a snapshot (account money)."""
    symbols = snap.get("symbols") or {}
    total = 0.0
    for p in snap.get("positions") or []:
        vpp = _value_per_price(symbols.get(p["symbol"]), p["volume"])
        if vpp is None:
            return None
        d = 1.0 if p["side"] == "buy" else -1.0
        at_stop = max(0.0, (p["open_price"] - p["sl"]) * d * vpp) if p.get("sl") is not None else 0.0
        floating = max(0.0, -(p["price"] - p["open_price"]) * d * vpp) if p.get("price") else 0.0
        total += max(at_stop, floating)
    for o in snap.get("orders") or []:
        if o.get("sl") is None or not str(o.get("type", "")).startswith(("buy", "sell")):
            continue
        vpp = _value_per_price(symbols.get(o["symbol"]), o["volume"])
        if vpp is None:
            return None
        d = 1.0 if o["type"].startswith("buy") else -1.0
        total += max(0.0, (o["price"] - o["sl"]) * d * vpp)
    return total


def funded_state(conn: sqlite3.Connection, cfg, now: datetime) -> dict:
    """The limit state from the latest snapshot and the stored deals."""
    row = conn.execute("SELECT * FROM bridge_status WHERE account_alias = ?", (cfg.account.alias,)).fetchone()
    if row is None:
        out = evaluate(cfg.funded, start_balance=0.0, balance=0.0, equity=0.0, open_risk=None)
        out.update(reset_utc=None, next_reset_utc=None, data=False)
        return out
    snap = json.loads(row["snapshot_json"])
    acct = snap.get("account") or {}
    balance, equity = float(acct.get("balance", 0.0)), float(acct.get("equity", 0.0))
    reset = last_reset_utc(now, int(row["server_offset_s"]))
    # Deposits, withdrawals and payouts ('balance'), credit and bonus move the balance but are not the day's trading
    # result, so they shift the day's starting balance instead of counting as a loss or a gain (red team 14).
    since = conn.execute("SELECT COALESCE(SUM(profit + commission + swap + fee), 0) FROM deal WHERE account_alias = ?"
                         " AND time_utc >= ? AND type NOT IN ('balance', 'credit', 'bonus')",
                         (cfg.account.alias, to_iso(reset))).fetchone()[0]
    out = evaluate(cfg.funded, start_balance=balance - since, balance=balance, equity=equity, open_risk=open_risk(snap))
    age = (now - from_iso(row["last_seen_utc"])).total_seconds()
    out.update(reset_utc=to_iso(reset), next_reset_utc=to_iso(reset + timedelta(days=1)), data=True,
               server_offset_s=int(row["server_offset_s"]), stale=age > cfg.bridge.silent_alert_after_s,
               snapshot_age_s=age)
    return out


def funded_alerts(cfg, state: dict, reset: datetime | str | None) -> list[Alert]:
    """funded_50 and funded_80 (daily limit used), risk_cap (open risk at the cap): once per server day each."""
    if not state.get("enabled") or not state.get("set") or state.get("stale"):
        return []          # a silent bridge has its own incident; old numbers send no limit alert
    day = reset if isinstance(reset, str) else to_iso(reset) if reset else state.get("reset_utc") or ""
    out: list[Alert] = []
    used = state.get("daily_used")
    cur = cfg.account.currency
    if used is not None:
        for level, kind, prio in ((state["alert_at"][0], "funded_50", 2), (state["alert_at"][1], "funded_80", 4)):
            if used >= level:
                out.append(Alert(f"{kind}:{day}", kind, prio, f"Daily loss limit {round(level * 100)}% used",
                                 f"Today's loss {state['daily_loss']:,.2f} {cur} of {state['daily_limit']:,.2f} {cur}"
                                 f" ({used * 100:.0f}%). Equity {state['equity']:,.2f} {cur}; floor"
                                 f" {state['floor']:,.2f} {cur}."))
    if state.get("cap_hit"):
        out.append(Alert(f"risk_cap:{day}", "risk_cap", 4, "Open risk at the cap",
                         f"Open risk {state['open_risk']:,.2f} {cur} = {state['open_risk_pct']:.2f}% of the initial"
                         f" balance; cap {state['risk_cap_pct']:.2f}%."))
    return out
