"""Apply one bridge snapshot to the journal, in one transaction, and return the events it raises.

Readings:
- The first snapshot ever stored for an account is the baseline: positions, orders and closed trades it
  already shows raise no opened/placed/closed events. Hard incidents (no_stop, terminal_can_trade,
  clock_mismatch) are raised even then.
- A trade that appears already closed (opened and closed between snapshots, or while the bridge was off)
  raises position_closed when it closed after the previous snapshot, less bridge.max_clock_skew_s.
  Older history (for example a longer history window) stays silent.
- no_stop is raised once per position (position_seen.no_stop_seen), even if the stop comes back and goes
  again. terminal_can_trade and clock_mismatch are raised once per bridge session.
- A stale seq (same bridge_session, seq not above the last one) raises StaleSeqError and writes nothing.
  So does a snapshot under another bridge_session whose gmt_time is not later than the stored one (an old
  snapshot replayed, or captured from an earlier EA run).
- A snapshot from a terminal that is not connected to the broker (terminal.connected false) is refused
  (PayloadError): its positions and prices are frozen copies. Nothing is stored, so the bridge reads stale,
  then offline, and the bridge-silent incident fires as for any silence.
- The account behind an alias is pinned by what it sent first: a snapshot whose account.company or
  account.trade_mode differs from the stored one is refused (another account logged in under the same alias
  must not be merged into this journal; use a new alias for another account). The currency is checked
  against config account.currency (schema).
"""
from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from app.costs.quotes import record_samples, store_new_deal_quotes
from app.db import transaction
from app.events import Event
from app.ingest.clock import ServerClock, check_skew, resolve_clock, rule_offset_s
from app.ingest.schema import PayloadError, Position, Snapshot, validate
from app.ingest.state import known_symbols, pip_size, remember_symbols, status_row  # noqa: F401 (re-export)
from app.ingest.trades import ENTRY_IN, ENTRY_OUT, sync_trades
from app.timeutil import UTC, from_iso, to_iso

_EPS = 1e-9
_TRADE_EVENT_FIELDS = ("symbol", "side", "volume", "open_price", "open_utc", "close_price", "close_utc",
                       "close_reason", "initial_sl", "initial_tp", "sl_at_exit", "net_profit", "risk_money",
                       "r_net", "r_gross", "pct_of_balance", "balance_at_open", "trading_day", "close_trading_day",
                       "session")


class StaleSeqError(Exception):
    """seq is not above the last one stored for this bridge session (a replay); nothing was written."""


@dataclass(frozen=True)
class IngestResult:
    seq: int
    stored_deals: int
    events: list[Event] = field(default_factory=list)


def _differs(a: float | None, b: float | None) -> bool:
    if a is None or b is None:
        return (a is None) != (b is None)
    return abs(a - b) > _EPS


def _at_entry(cfg, symbol: str, sl: float | None, open_price: float, info: dict | None) -> bool:
    if sl is None:
        return False
    pip = pip_size(cfg, symbol, info)
    return abs(sl - open_price) <= (0.5 * pip if pip else 0.0) + _EPS


def _store_deals(conn: sqlite3.Connection, snap: Snapshot, clock: ServerClock, alias: str, now_iso: str) -> int:
    stored = 0
    for d in sorted(snap.deals, key=lambda x: (x.time, int(x.deal))):
        cur = conn.execute(
            "INSERT OR IGNORE INTO deal (account_alias, deal_id, order_id, position_id, symbol, type, entry, volume,"
            " price, time_utc, profit, commission, swap, fee, reason, sl, tp, received_utc)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (alias, d.deal, d.order, d.position_id, d.symbol, d.type, d.entry, d.volume, d.price,
             to_iso(clock.to_utc(d.time)), d.profit, d.commission, d.swap, d.fee, d.reason, d.sl, d.tp, now_iso))
        stored += cur.rowcount
    return stored


def _entry_deal(conn: sqlite3.Connection, alias: str, pid: str) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT sl, tp FROM deal WHERE account_alias = ? AND position_id = ? AND entry IN (?, ?)"
        " ORDER BY time_utc, CAST(deal_id AS INTEGER) LIMIT 1", (alias, pid, *ENTRY_IN)).fetchone()


def _r_now(pos: Position, initial_sl: float | None) -> float | None:
    """R of the position at the snapshot's price against its first stop (A6, max_fav_r); None without one."""
    if initial_sl is None or not pos.price or pos.price <= 0:
        return None
    dist = abs(pos.open_price - initial_sl)
    if dist <= _EPS:
        return None
    d = 1.0 if pos.side == "buy" else -1.0
    return round((pos.price - pos.open_price) * d / dist, 6)


def _position_data(cfg, alias: str, pos: Position, open_utc: str) -> dict:
    return {"alias": alias, "position_id": pos.position_id, "ticket": pos.ticket, "symbol": pos.symbol,
            "is_eurusd": cfg.is_eurusd(pos.symbol), "side": pos.side, "volume": pos.volume,
            "open_price": pos.open_price, "open_utc": open_utc, "sl": pos.sl, "tp": pos.tp}


def _positions(conn, cfg, snap: Snapshot, clock: ServerClock, alias: str, now_iso: str,
               baseline: bool) -> tuple[list[Event], list[Event], list[Event]]:
    opened, no_stop, moved = [], [], []
    for pos in snap.positions:
        pid = pos.position_id
        row = conn.execute("SELECT * FROM position_seen WHERE account_alias = ? AND position_id = ?",
                           (alias, pid)).fetchone()
        entry = _entry_deal(conn, alias, pid)
        if row is None:
            fav_sl = entry["sl"] if entry is not None and entry["sl"] is not None else pos.sl
            fav = _r_now(pos, fav_sl)
            open_utc = to_iso(clock.to_utc(pos.open_time))
            init_sl = entry["sl"] if entry is not None and entry["sl"] is not None else pos.sl
            init_tp = entry["tp"] if entry is not None and entry["tp"] is not None else pos.tp
            conn.execute(
                "INSERT INTO position_seen (account_alias, position_id, symbol, side, volume, open_price, open_utc,"
                " initial_sl, initial_tp, last_sl, last_tp, first_seen_utc, last_seen_utc, closed_utc, no_stop_seen,"
                " max_fav_r) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)",
                (alias, pid, pos.symbol, pos.side, pos.volume, pos.open_price, open_utc, init_sl, init_tp,
                 pos.sl, pos.tp, now_iso, now_iso, int(pos.sl is None), fav))
            data = dict(_position_data(cfg, alias, pos, open_utc), initial_sl=init_sl, initial_tp=init_tp)
            if not baseline:
                opened.append(Event("position_opened", f"position_opened:{alias}:{pid}", open_utc, data))
            if pos.sl is None:
                no_stop.append(Event("no_stop", f"no_stop:{alias}:{pid}", now_iso, data))
            continue

        if _differs(row["last_sl"], pos.sl) or _differs(row["last_tp"], pos.tp):
            cur = conn.execute(
                "INSERT INTO sl_change (account_alias, position_id, at_utc, old_sl, new_sl, old_tp, new_tp)"
                " VALUES (?, ?, ?, ?, ?, ?, ?)", (alias, pid, now_iso, row["last_sl"], pos.sl, row["last_tp"], pos.tp))
            info = snap.symbols.get(pos.symbol)
            moved.append(Event("stop_changed", f"stop_changed:{alias}:{pid}:{cur.lastrowid}", now_iso, dict(
                _position_data(cfg, alias, pos, row["open_utc"]), old_sl=row["last_sl"], new_sl=pos.sl,
                old_tp=row["last_tp"], new_tp=pos.tp, initial_sl=row["initial_sl"], removed=pos.sl is None,
                to_entry=_at_entry(cfg, pos.symbol, pos.sl, pos.open_price,
                                   None if info is None else {"point": info.point, "digits": info.digits}))))
        first_no_stop = pos.sl is None and not row["no_stop_seen"]
        init_sl, init_tp = row["initial_sl"], row["initial_tp"]
        if entry is not None and entry["sl"] is not None:   # the entry deal is the better source
            init_sl = entry["sl"]
            init_tp = entry["tp"] if entry["tp"] is not None else init_tp
        fav = _r_now(pos, init_sl)
        if fav is None or (row["max_fav_r"] is not None and row["max_fav_r"] >= fav):
            fav = row["max_fav_r"]
        conn.execute(
            "UPDATE position_seen SET volume = ?, last_sl = ?, last_tp = ?, last_seen_utc = ?, closed_utc = NULL,"
            " initial_sl = ?, initial_tp = ?, no_stop_seen = ?, max_fav_r = ? WHERE account_alias = ? AND position_id = ?",
            (pos.volume, pos.sl, pos.tp, now_iso, init_sl, init_tp, int(row["no_stop_seen"] or pos.sl is None),
             fav, alias, pid))
        if first_no_stop:
            no_stop.append(Event("no_stop", f"no_stop:{alias}:{pid}", now_iso,
                                 dict(_position_data(cfg, alias, pos, row["open_utc"]), initial_sl=init_sl)))
    return opened, no_stop, moved


def _close_gone_positions(conn: sqlite3.Connection, snap: Snapshot, alias: str) -> None:
    """Mark positions closed when they left the snapshot and their closing deals are stored."""
    live = {p.position_id for p in snap.positions}
    for row in conn.execute("SELECT position_id FROM position_seen WHERE account_alias = ? AND closed_utc IS NULL",
                            (alias,)).fetchall():
        pid = row["position_id"]
        if pid in live:
            continue
        vol = conn.execute(
            "SELECT COALESCE(SUM(CASE WHEN entry IN (?, ?) THEN volume END), 0) AS vin,"
            " COALESCE(SUM(CASE WHEN entry IN (?, ?, ?) THEN volume END), 0) AS vout,"
            " MAX(CASE WHEN entry IN (?, ?, ?) THEN time_utc END) AS last_out"
            " FROM deal WHERE account_alias = ? AND position_id = ?",
            (*ENTRY_IN, *ENTRY_OUT, *ENTRY_OUT, alias, pid)).fetchone()
        if vol["last_out"] and (vol["vin"] <= 0 or vol["vout"] >= vol["vin"] - _EPS):
            conn.execute("UPDATE position_seen SET closed_utc = ? WHERE account_alias = ? AND position_id = ?",
                         (vol["last_out"], alias, pid))


def _order_data(cfg, alias: str, o: dict, clock: ServerClock) -> dict:
    exp = o["expiration"]
    return {"alias": alias, "ticket": o["ticket"], "symbol": o["symbol"], "is_eurusd": cfg.is_eurusd(o["symbol"]),
            "type": o["type"], "volume": o["volume"], "price": o["price"], "sl": o["sl"], "tp": o["tp"],
            "setup_utc": to_iso(clock.to_utc(o["setup_time"])),
            "expiry_utc": None if exp is None else to_iso(clock.to_utc(exp))}


def _order_events(cfg, payload: dict, prev_snap: dict | None, clock: ServerClock, alias: str,
                  now_iso: str) -> list[Event]:
    if prev_snap is None:
        return []
    before = {o["ticket"]: o for o in prev_snap.get("orders", [])}
    after = {o["ticket"]: o for o in payload["orders"]}
    events = [Event("order_placed", f"order_placed:{alias}:{t}", now_iso, _order_data(cfg, alias, after[t], clock))
              for t in sorted(set(after) - set(before), key=int)]
    events += [Event("order_removed", f"order_removed:{alias}:{t}", now_iso,
                     _order_data(cfg, alias, before[t], clock))
               for t in sorted(set(before) - set(after), key=int)]
    return events


def _closed_events(conn, cfg, alias: str, changed: list[int], before: dict[str, str],
                   prev_seen: datetime) -> list[Event]:
    cutoff = to_iso(prev_seen - timedelta(seconds=cfg.bridge.max_clock_skew_s))
    seen = {r["position_id"] for r in conn.execute("SELECT position_id FROM position_seen WHERE account_alias = ?",
                                                   (alias,))}
    events = []
    for tid in changed:
        t = conn.execute("SELECT * FROM trade WHERE id = ?", (tid,)).fetchone()
        pid = t["broker_position_id"]
        if t["status"] != "closed" or before.get(pid) == "closed":
            continue
        if (pid not in before or pid not in seen) and t["close_utc"] < cutoff:
            # Old history: seen for the first time, or known only from deals (a history page that split the
            # entry from the exit) and never shown open by the bridge. Not news (red-team EA-2).
            continue
        data = {"alias": alias, "trade_id": tid, "position_id": pid, "is_eurusd": cfg.is_eurusd(t["symbol"]),
                **{k: t[k] for k in _TRADE_EVENT_FIELDS}}
        events.append(Event("position_closed", f"position_closed:{alias}:{pid}", t["close_utc"], data))
    return events


def apply_snapshot(conn: sqlite3.Connection, cfg, payload: dict, received_utc: datetime) -> IngestResult:
    """Validate and store one snapshot. Raises PayloadError (invalid) or StaleSeqError (replay)."""
    snap = validate(payload, cfg)
    check_skew(cfg, snap, received_utc)
    if not snap.terminal.connected:
        raise PayloadError("terminal.connected: the terminal is not connected to the broker (frozen data); "
                           "nothing stored")
    clock = resolve_clock(cfg, snap)
    alias = snap.account.alias
    session = snap.bridge_session
    now_iso = to_iso(received_utc)

    with transaction(conn):
        prev = status_row(conn, alias)
        same_session = prev is not None and prev["bridge_session"] == session
        if same_session and snap.seq <= prev["last_seq"]:
            raise StaleSeqError(f"seq {snap.seq} is not above {prev['last_seq']} for this bridge session")
        baseline = prev is None
        prev_snap = json.loads(prev["snapshot_json"]) if prev else None
        if prev_snap is not None and not same_session and snap.gmt_time <= prev_snap["gmt_time"]:
            raise StaleSeqError("a new bridge session must be later than the stored snapshot")
        if prev_snap is not None:
            for key in ("company", "trade_mode"):
                before = prev_snap["account"].get(key)
                if before and getattr(snap.account, key) != before:
                    raise PayloadError(f"account.{key}: not the account this alias sent before (another account?"
                                       " use a new alias for it)")

        head: list[Event] = []
        if clock.mismatch:
            prev_mismatch = same_session and prev["server_offset_s"] != rule_offset_s(from_iso(prev["last_seen_utc"]))
            if not prev_mismatch:
                head.append(Event("clock_mismatch", f"clock_mismatch:{alias}:{session}", now_iso, {
                    "alias": alias, "measured_offset_s": clock.measured_offset_s,
                    "rule_offset_s": clock.rule_offset_s, "broker_clock": cfg.bridge.broker_clock}))
        if snap.account.trade_allowed and not (same_session and prev["trade_allowed"]):
            head.append(Event("terminal_can_trade", f"terminal_can_trade:{alias}:{session}", now_iso, {
                "alias": alias, "trade_mode": snap.account.trade_mode,
                "terminal_trade_allowed": snap.terminal.trade_allowed}))

        conn.execute(
            "INSERT INTO bridge_status (account_alias, bridge_session, last_seq, last_seen_utc, last_reason,"
            " trade_allowed, server_offset_s, clock_offset_s, snapshot_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
            " ON CONFLICT(account_alias) DO UPDATE SET bridge_session = excluded.bridge_session,"
            " last_seq = excluded.last_seq, last_seen_utc = excluded.last_seen_utc,"
            " last_reason = excluded.last_reason, trade_allowed = excluded.trade_allowed,"
            " server_offset_s = excluded.server_offset_s, clock_offset_s = excluded.clock_offset_s,"
            " snapshot_json = excluded.snapshot_json",
            (alias, session, snap.seq, now_iso, snap.reason, int(snap.account.trade_allowed),
             clock.measured_offset_s, clock.offset_now_s, json.dumps(payload, sort_keys=True, separators=(",", ":"))))
        remember_symbols(conn, alias, snap.symbols)
        record_samples(conn, cfg, alias, payload["symbols"], datetime.fromtimestamp(snap.gmt_time, UTC))
        stored = _store_deals(conn, snap, clock, alias, now_iso)
        store_new_deal_quotes(conn, cfg, alias, now_iso)
        opened, no_stop, moved = _positions(conn, cfg, snap, clock, alias, now_iso, baseline)
        _close_gone_positions(conn, snap, alias)
        orders = _order_events(cfg, payload, prev_snap, clock, alias, now_iso)

        before = {r["broker_position_id"]: r["status"] for r in conn.execute(
            "SELECT broker_position_id, status FROM trade WHERE book = 'mt5' AND account_alias = ?", (alias,))}
        changed = sync_trades(conn, cfg, alias)
        closed = [] if baseline else _closed_events(conn, cfg, alias, changed, before,
                                                    from_iso(prev["last_seen_utc"]))

    return IngestResult(snap.seq, stored, head + opened + no_stop + moved + orders + closed)
