"""Time helpers. The app stores UTC; rules use London and New York time; the owner sees Melbourne time.

Trading day: the FX day that ENDS at 17:00 New York (config [day]). A trade opened at 18:00 New York
on Monday belongs to Tuesday's trading day. Sessions, by the time a trade opens:
  asia      day start (17:00 New York)  -> London open (07:00 London)
  london    London open                 -> New York open (07:00 New York)
  new_york  New York open               -> day end (17:00 New York)
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

UTC = timezone.utc
LONDON = ZoneInfo("Europe/London")
NEW_YORK = ZoneInfo("America/New_York")
MELBOURNE = ZoneInfo("Australia/Melbourne")


def now_utc() -> datetime:
    return datetime.now(UTC)


def to_iso(dt: datetime) -> str:
    """UTC ISO-8601 with a Z, second precision. Naive datetimes are refused."""
    if dt.tzinfo is None:
        raise ValueError("naive datetime")
    return dt.astimezone(UTC).replace(microsecond=0).strftime("%Y-%m-%dT%H:%M:%SZ")


def from_iso(text: str) -> datetime:
    dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        raise ValueError(f"time without zone: {text!r}")
    return dt.astimezone(UTC)


def trading_day(dt: datetime, boundary_tz: ZoneInfo = NEW_YORK, boundary_hour: int = 17) -> date:
    """The trading day a UTC instant belongs to (the day that ends at boundary_hour in boundary_tz)."""
    local = dt.astimezone(boundary_tz)
    return local.date() + timedelta(days=1) if local.hour >= boundary_hour else local.date()


def day_bounds(day: date, boundary_tz: ZoneInfo = NEW_YORK, boundary_hour: int = 17) -> tuple[datetime, datetime]:
    """[start, end) of a trading day in UTC."""
    end = datetime.combine(day, time(boundary_hour), boundary_tz)
    start = datetime.combine(day - timedelta(days=1), time(boundary_hour), boundary_tz)
    return start.astimezone(UTC), end.astimezone(UTC)


def london_open_utc(day: date, london_open: time = time(7, 0)) -> datetime:
    """London open of a trading day (the London calendar date equals the trading day)."""
    return datetime.combine(day, london_open, LONDON).astimezone(UTC)


def ny_open_utc(day: date, ny_open: time = time(7, 0)) -> datetime:
    return datetime.combine(day, ny_open, NEW_YORK).astimezone(UTC)


def session_of(dt: datetime, boundary_tz: ZoneInfo = NEW_YORK, boundary_hour: int = 17,
               london_open: time = time(7, 0), ny_open: time = time(7, 0)) -> str:
    day = trading_day(dt, boundary_tz, boundary_hour)
    t = dt.astimezone(UTC)
    if t < london_open_utc(day, london_open):
        return "asia"
    if t < ny_open_utc(day, ny_open):
        return "london"
    return "new_york"


def market_open(dt: datetime) -> bool:
    """FX is open from Sunday 17:00 New York to Friday 17:00 New York (holidays not modelled)."""
    ny = dt.astimezone(NEW_YORK)
    wd = ny.weekday()  # Monday 0 ... Sunday 6
    if wd == 5:
        return False
    if wd == 4:
        return ny.hour < 17
    if wd == 6:
        return ny.hour >= 17
    return True


def melbourne(dt: datetime) -> datetime:
    return dt.astimezone(MELBOURNE)


def fmt_melbourne(dt: datetime) -> str:
    """'Sat 10 Oct 17:05' in Melbourne time, for messages to the owner."""
    m = melbourne(dt)
    return f"{m:%a} {m.day} {m:%b %H:%M}"
