/* Edge Desk screens. Vanilla JS, no build step, no requests to other hosts.
   Reads the app's own JSON API. The only writes are journal actions (choice, weekly action item,
   paper log), login/logout and this phone's alert subscription (Web Push, through the app's own server
   and service worker /sw.js); nothing here can place, change or close an order.
   Every value from the API is checked before use: a missing or odd field shows a dash, never a crash.
   Markup is built as strings with classes and data attributes only (the CSP blocks inline styles);
   positions and sizes are applied afterwards through the CSSOM (geom). */
(function () {
  "use strict";

  var doc = document, root = doc.documentElement;
  function $(s, r) { return (r || doc).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || doc).querySelectorAll(s)); }
  var MINUS = "−", DASH = "—", MID = " · ", NDASH = "–";
  var MELB = "Australia/Melbourne", LON = "Europe/London", NYC = "America/New_York";
  var MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  var WD = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  var TABS = ["today", "live", "journal", "calendar", "edge", "leads", "rules", "settings"];
  var RM = window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };
  function reduced() { return !!RM.matches; }

  var store = {
    get: function (k) { try { return window.localStorage.getItem("edgedesk:" + k); } catch (e) { return null; } },
    set: function (k, v) { try { window.localStorage.setItem("edgedesk:" + k, v); } catch (e) { /* ignore */ } }
  };

  var state = {
    tab: "today", book: "mt5", authed: true, skew: 0, currency: "USD",
    today: null, live: null, settings: null, journal: [], paper: [], cal: null, edge: null, rules: null,
    leads: null, sform: null,
    jfilter: "all", month: null, edgeDrawn: false, loaded: 0, lastMinute: "", reachable: true, pollN: 0
  };

  /* ---------------- value guards ---------------- */
  function isObj(x) { return x !== null && typeof x === "object" && !Array.isArray(x); }
  function obj(x) { return isObj(x) ? x : {}; }
  function arr(x) { return Array.isArray(x) ? x : []; }
  function objs(x) { return arr(x).filter(isObj); }
  function num(x) {
    if (typeof x === "number") return isFinite(x) ? x : null;
    if (typeof x === "string" && x.trim() !== "" && isFinite(+x)) return +x;
    return null;
  }
  function str(x) { return typeof x === "string" ? x : (typeof x === "number" && isFinite(x)) ? String(x) : ""; }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function pad(n) { return (n < 10 ? "0" : "") + n; }

  /* ---------------- formatting ---------------- */
  var ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" };
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return ESC[c]; }); }
  function sgn(v) { return v > 0 ? "+" : v < 0 ? MINUS : ""; }
  /* Round half up (away from zero) on the shown decimal, like the phone alerts (app/notify/alerts.py _num):
     3.965 -> 3.97 here and there. toFixed works on the binary value and would show 3.96. */
  function fixed(x, d) {
    var a = Math.abs(x), s = String(a), v;
    v = /e/i.test(s) ? +a.toFixed(d) : +(Math.round(+(s + "e" + d)) + "e-" + d);
    if (x < 0) v = -v;
    return v === 0 ? 0 : v;
  }
  function fR(x, d) {
    x = num(x); if (x === null) return DASH;
    d = d == null ? 2 : d; var v = fixed(x, d);
    return sgn(v) + Math.abs(v).toFixed(d) + "R";
  }
  function fPct(x, d) {
    x = num(x); if (x === null) return DASH;
    d = d == null ? 2 : d; var v = fixed(x, d);
    return sgn(v) + Math.abs(v).toFixed(d) + "%";
  }
  function fRate(x) { x = num(x); return x === null ? DASH : Math.round(x * 100) + "%"; }
  var CUR = { USD: "$", AUD: "A$", EUR: "€", GBP: "£", NZD: "NZ$", CAD: "C$", JPY: "¥", CHF: "CHF " };
  function curSym() { var c = state.currency || "USD"; return CUR[c] || (c + " "); }
  function fMoney(x, signed) {
    x = num(x); if (x === null) return DASH;
    var v = fixed(x, 2);
    return (signed ? sgn(v) : (v < 0 ? MINUS : "")) + curSym() +
      Math.abs(v).toLocaleString("en-AU", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function fPx(p) { p = num(p); return p === null ? DASH : p.toFixed(5); }
  function fNum(x, d) { x = num(x); return x === null ? DASH : x.toFixed(d == null ? 2 : d); }
  function fInt(x) { x = num(x); return x === null ? DASH : String(Math.round(x)); }
  function fLots(x) { x = num(x); return x === null ? DASH : x.toFixed(2); }
  function fPips(x) { x = num(x); return x === null ? DASH : fixed(x, 1).toFixed(1); }
  function cls(r) { r = num(r); return r === null ? "" : r > 0.004 ? "pos-c" : r < -0.004 ? "neg-c" : ""; }
  function yesNo(b) { return b === true ? '<span class="yes">Yes</span>' : b === false ? '<span class="no">No</span>' : DASH; }
  function cap(s) { s = str(s); return s ? s.charAt(0).toUpperCase() + s.slice(1) : ""; }
  function isEur(t) {
    t = obj(t);
    if (t.is_eurusd === true) return true;
    if (t.is_eurusd === false) return false;
    return /^EURUSD/i.test(str(t.symbol));
  }
  function pair(sym) { sym = str(sym); return /^EURUSD/i.test(sym) ? "EUR/USD" : (sym || DASH); }
  function sideLabel(s) { s = str(s); return s === "buy" ? "Buy" : s === "sell" ? "Sell" : DASH; }
  function geomNum(v) { return String(Math.round(clamp(v, 0, 100) * 1000) / 1000); }

  /* ---------------- time ---------------- */
  var fmtCache = {};
  function tzFmt(tz) {
    if (!fmtCache[tz]) {
      fmtCache[tz] = new Intl.DateTimeFormat("en-GB", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit",
        day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", weekday: "short" });
    }
    return fmtCache[tz];
  }
  function tzParts(ms, tz) {
    var p = {};
    tzFmt(tz).formatToParts(new Date(ms)).forEach(function (x) { p[x.type] = x.value; });
    return { y: +p.year, mo: +p.month, d: +p.day, h: (+p.hour) % 24, mi: +p.minute, s: +p.second, wd: p.weekday };
  }
  function tzOffset(ms, tz) { var p = tzParts(ms, tz); return Date.UTC(p.y, p.mo - 1, p.d, p.h, p.mi, p.s) - Math.floor(ms / 1000) * 1000; }
  function zonedToUtc(y, mo, d, h, mi, tz) {
    var guess = Date.UTC(y, mo - 1, d, h, mi);
    var off = tzOffset(guess, tz), t = guess - off, off2 = tzOffset(t, tz);
    return off2 !== off ? guess - off2 : t;
  }
  function tzAbbr(ms, tz) {
    try {
      var f = new Intl.DateTimeFormat("en-AU", { timeZone: tz, timeZoneName: "short" }).formatToParts(new Date(ms));
      for (var i = 0; i < f.length; i++) if (f[i].type === "timeZoneName") return f[i].value;
    } catch (e) { /* ignore */ }
    return "";
  }
  function parseIso(s) { if (typeof s !== "string" || !s) return null; var t = Date.parse(s); return isFinite(t) ? t : null; }
  function toIso(ms) { return new Date(ms).toISOString().replace(/\.\d{3}Z$/, "Z"); }
  function hhmm(ms, tz) { var p = tzParts(ms, tz); return pad(p.h) + ":" + pad(p.mi); }
  function nowMs() { return Date.now() + state.skew; }
  function fWhen(iso) {
    var t = parseIso(iso); if (t === null) return DASH;
    var p = tzParts(t, MELB);
    return p.wd + " " + p.d + " " + MON[p.mo - 1] + " " + pad(p.h) + ":" + pad(p.mi);
  }
  function validDay(s) { return typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s) && isFinite(Date.parse(s + "T00:00:00Z")); }
  function fDay(s) {
    if (!validDay(s)) return DASH;
    var a = s.split("-").map(Number), dt = new Date(Date.UTC(a[0], a[1] - 1, a[2]));
    return WD[dt.getUTCDay()] + " " + a[2] + " " + MON[a[1] - 1];
  }
  function melbDate(ms) { var p = tzParts(ms, MELB); return p.y + "-" + pad(p.mo) + "-" + pad(p.d); }
  function isoWeek(dayStr) {
    var a = dayStr.split("-").map(Number), d = new Date(Date.UTC(a[0], a[1] - 1, a[2]));
    var wd = d.getUTCDay() || 7; d.setUTCDate(d.getUTCDate() + 4 - wd);
    var y0 = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    var wk = Math.ceil(((d - y0) / 86400000 + 1) / 7);
    return d.getUTCFullYear() + "-W" + pad(wk);
  }
  function localInputToIso(v, tz) {
    var m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(str(v));
    if (!m) return null;
    return toIso(zonedToUtc(+m[1], +m[2], +m[3], +m[4], +m[5], tz));
  }
  function nowLocalInput(tz) { var p = tzParts(nowMs(), tz); return p.y + "-" + pad(p.mo) + "-" + pad(p.d) + "T" + pad(p.h) + ":" + pad(p.mi); }

  /* ---------------- DOM patching ---------------- */
  /* geom: data-gl / data-gw / data-gh / data-gr hold percentages; they become CSSOM styles (CSP-safe). */
  function geom(el) {
    $$("[data-gl],[data-gw],[data-gh],[data-gr]", el).forEach(function (n) {
      var v;
      if ((v = n.getAttribute("data-gl")) !== null) n.style.left = v + "%";
      if ((v = n.getAttribute("data-gw")) !== null) n.style.width = v + "%";
      if ((v = n.getAttribute("data-gh")) !== null) n.style.height = v + "%";
      if ((v = n.getAttribute("data-gr")) !== null) n.style.right = v + "%";
    });
  }
  function sameNode(a, b) {
    if (a.nodeType !== b.nodeType) return false;
    if (a.nodeType !== 1) return true;
    return a.nodeName === b.nodeName && (a.getAttribute("data-key") || "") === (b.getAttribute("data-key") || "");
  }
  function patchAttrs(a, b) {
    var i, at;
    for (i = 0; i < b.attributes.length; i++) { at = b.attributes[i]; if (a.getAttribute(at.name) !== at.value) a.setAttribute(at.name, at.value); }
    for (i = a.attributes.length - 1; i >= 0; i--) { at = a.attributes[i].name; if (at !== "style" && !b.hasAttribute(at)) a.removeAttribute(at); }
  }
  function patchChildren(a, b) {
    var ac = Array.prototype.slice.call(a.childNodes), bc = Array.prototype.slice.call(b.childNodes), i;
    for (i = 0; i < bc.length; i++) {
      var x = ac[i], y = bc[i];
      if (!x) { a.appendChild(y); continue; }
      if (!sameNode(x, y)) { a.replaceChild(y, x); continue; }
      if (x.nodeType !== 1) { if (x.nodeValue !== y.nodeValue) x.nodeValue = y.nodeValue; continue; }
      patchAttrs(x, y);
      patchChildren(x, y);
    }
    for (i = bc.length; i < ac.length; i++) a.removeChild(ac[i]);
  }
  /* morph: update a container to new markup in place, so numbers change without rebuilding rows. */
  function morph(el, html) {
    if (!el) return;
    var tpl = doc.createElement("template");
    tpl.innerHTML = html;
    patchChildren(el, tpl.content);
    geom(el);
  }
  function setText(sel, text) { var el = $(sel); if (el && el.textContent !== text) el.textContent = text; }
  function safe(fn) { try { fn(); } catch (e) { setTimeout(function () { throw e; }, 0); } }

  /* ---------------- API ---------------- */
  function api(method, path, body, opts) {
    opts = opts || {};
    var init = { method: method, credentials: "same-origin", cache: "no-store", headers: { "Accept": "application/json" } };
    if (method !== "GET") {
      init.headers["Content-Type"] = "application/json";
      init.headers["X-Edge"] = "1";
      init.body = JSON.stringify(body || {});
    }
    return fetch(path, init).then(function (res) {
      state.reachable = true;
      return res.text().then(function (txt) {
        var data = null;
        try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = null; }
        if ((res.status === 401 || (res.status === 503 && !opts.keep503)) && !opts.noAuth) {
          /* 401: no session. 503: the server has no dashboard token, so nothing can be shown yet
             (except on the push writes, where 503 means the server has no push keys: keep503). */
          needLogin(res.status === 503 ? NOT_SET_UP : "");
          var ea = new Error("login"); ea.auth = true; throw ea;
        }
        if (!res.ok) {
          var er = new Error(str(obj(data).error) || ("HTTP " + res.status));
          er.status = res.status; throw er;
        }
        return isObj(data) ? data : {};
      });
    }, function (e) {
      state.reachable = false; renderChip();
      var en = new Error("unreachable"); en.network = true; throw en;
    });
  }
  /* GET for a screen: on any error except a needed login, render with an empty payload (dashes). */
  function get(path) {
    return api("GET", path).catch(function (e) { if (e && e.auth) throw e; return {}; });
  }
  function noteSkew(d) {
    var t = parseIso(obj(d).now_utc);
    if (t !== null) state.skew = t - Date.now();
  }

  /* ---------------- theme ---------------- */
  var ICON = {
    sun: '<circle cx="8" cy="8" r="3"/><path d="M8 1.5v1.6M8 12.9v1.6M1.5 8h1.6M12.9 8h1.6M3.4 3.4l1.1 1.1M11.5 11.5l1.1 1.1M3.4 12.6l1.1-1.1M11.5 4.5l1.1-1.1"/>',
    moon: '<path d="M13.2 9.6A5.6 5.6 0 0 1 6.4 2.8a5.6 5.6 0 1 0 6.8 6.8z"/>'
  };
  function effTheme() {
    var t = root.getAttribute("data-theme");
    if (t) return t;
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  }
  function applyTheme(t) {
    if (t === "system") root.removeAttribute("data-theme"); else root.setAttribute("data-theme", t);
    store.set("theme", t);
    paintThemeUI();
  }
  function paintThemeUI() {
    var e = effTheme();
    $("#themeIco").innerHTML = e === "dark" ? ICON.moon : ICON.sun;
    $("#themeBtn").setAttribute("aria-label", e === "dark" ? "Switch to light theme" : "Switch to dark theme");
    var cur = root.getAttribute("data-theme") || "system";
    $$("#themeSeg button").forEach(function (b) { b.setAttribute("aria-pressed", String(b.getAttribute("data-theme-set") === cur)); });
  }

  /* ---------------- routing ---------------- */
  function setHash(t) { try { history.replaceState(null, "", "#" + t); } catch (e) { /* ignore */ } }
  function showTab(t, opts) {
    opts = opts || {};
    if (TABS.indexOf(t) < 0) t = "today";
    var prev = state.tab;
    state.tab = t;
    $$("section[data-screen]").forEach(function (s) { s.hidden = !state.authed || s.getAttribute("data-screen") !== t; });
    $$("#tabs .tab").forEach(function (b) {
      var on = b.getAttribute("data-tab") === t;
      b.setAttribute("aria-selected", String(on)); b.tabIndex = on ? 0 : -1;
    });
    var tb = $("#t-" + t);
    if (tb && tb.scrollIntoView && !opts.first) { try { tb.scrollIntoView({ block: "nearest", inline: "nearest" }); } catch (e) { /* ignore */ } }
    store.set("tab", t);
    if (!opts.keepHash) setHash(t);
    if (prev !== t && !opts.first) window.scrollTo(0, 0);
    if (state.authed) loadTab(t);
  }
  function route(first) {
    var h = (location.hash || "").replace(/^#/, "");
    if (TABS.indexOf(h) >= 0) { showTab(h, { keepHash: true, first: first }); return; }
    var t = store.get("tab");
    showTab(TABS.indexOf(t) >= 0 ? t : "today", { first: first });
  }

  var LOADERS = {
    today: function () {
      return Promise.all([get("/api/today"), get("/api/live"), get("/api/checks")]).then(function (r) {
        noteSkew(r[0]); state.today = r[0]; state.live = r[1]; state.checks = obj(r[2]); renderChip(); renderToday();
      });
    },
    live: function () {
      return Promise.all([get("/api/live"), get("/api/checks")]).then(function (r) {
        state.live = r[0]; state.checks = obj(r[1]); renderChip(); renderLive();
      });
    },
    journal: function () {
      var b = state.book, ps = [get("/api/journal?book=" + b)];
      if (b === "paper") { ps.push(get("/api/paper")); ps.push(get("/api/today")); } else { ps.push(get("/api/checks")); }
      return Promise.all(ps).then(function (r) {
        state.journal = objs(obj(r[0]).trades);
        if (b !== "paper") state.checks = obj(r[1]);
        if (b === "paper") { state.paper = objs(obj(r[1]).orders); if (isObj(r[2])) state.today = r[2]; }
        renderJournal();
      });
    },
    calendar: function () {
      var m = state.month || currentMonth();
      state.month = m;
      return get("/api/calendar?book=" + state.book + "&month=" + m).then(function (d) { state.cal = d; renderCalendar(); });
    },
    edge: function () { return get("/api/edge?book=" + state.book).then(function (d) { state.edge = d; renderEdge(); }); },
    leads: function () { return get("/api/leads").then(function (d) { state.leads = d; renderLeads(); }); },
    rules: function () { return get("/api/rules").then(function (d) { state.rules = d; renderRules(); }); },
    settings: function () {
      return Promise.all([get("/api/settings"), loadPushKey().catch(function (e) { if (e && e.auth) throw e; })]).then(function (r) {
        state.settings = r[0]; renderSettings();
      });
    }
  };
  function loadTab(t) {
    var sec = $("#scr-" + t);
    if (!sec) return;
    sec.removeAttribute("data-loaded");
    LOADERS[t]().then(function () { done(); }, function (e) {
      if (e && e.auth) return;
      done();
      setTimeout(function () { throw e; }, 0);
    });
    function done() { geom(sec); sec.setAttribute("data-loaded", String(++state.loaded)); }
  }
  function settingsNow() { return obj(state.settings); }
  function ensureSettings() {
    if (state.settings) return Promise.resolve(state.settings);
    return get("/api/settings").then(function (d) {
      state.settings = d;
      if (str(obj(d).currency)) state.currency = str(d.currency);
      return d;
    }).catch(function () { return {}; });
  }
  function currentMonth() {
    var td = str(obj(state.today).trading_day);
    return validDay(td) ? td.slice(0, 7) : melbDate(nowMs()).slice(0, 7);
  }

  /* ---------------- bridge chip ---------------- */
  var BRIDGE_WORD = { live: "Live", stale: "Stale", offline: "Offline", never: "Not seen" };
  var BRIDGE_SHORT = { live: "Live", stale: "Stale", offline: "Off", never: "None" };
  function bridgeOf() { var b = obj(obj(state.live).bridge); return isObj(b) && b.state ? b : obj(obj(state.today).bridge); }
  function renderChip() {
    var b = bridgeOf(), s = str(b.state);
    if (!BRIDGE_WORD[s]) s = "never";
    var label = "MT5 " + BRIDGE_WORD[s].toLowerCase(), short = BRIDGE_SHORT[s];
    if (!state.reachable) { s = "unreachable"; label = "Server unreachable"; short = "No server"; }
    $("#bridgeChip .dot").setAttribute("data-state", s);
    setText("#bridgeChipT", label);
    setText("#bridgeChipS", short);
  }

  /* ================= TODAY ================= */
  var SESSION_NAME = { asia: "Asia", london: "London", new_york: "New York" };
  function renderToday() {
    var d = obj(state.today), live = obj(state.live);
    safe(function () {
      var td = str(d.trading_day), next = str(d.next_trading_day);
      if (d.market_open === false && validDay(next)) setText("#tradingDay", "Next trading day " + fDay(next));
      else setText("#tradingDay", validDay(td) ? "Trading day " + fDay(td) : "");
      setText("#modeChip", str(d.mode) === "paper" || !d.mode ? "Paper" : cap(str(d.mode)));
    });
    safe(renderClocks);
    safe(function () { renderTimeline(d); });
    safe(function () { renderTodayFigs(d, live); });
    safe(function () { renderPlan(d); });
    safe(function () { renderSuggestions(d); });
    safe(function () { renderChecklist(d); });
    safe(function () { renderGuard(d); });
    safe(function () { renderStreak(d); });
    safe(renderChecks);
    safe(function () { renderFunded(d); });
  }
  var CLOCKS = [["Melbourne", MELB], ["London", LON], ["New York", NYC]];
  function renderClocks() {
    var box = $("#clocks"), now = nowMs();
    if (!box.children.length) {
      box.innerHTML = CLOCKS.map(function (c, i) {
        return '<div class="clock"><div class="clock-name">' + c[0] + ' <span class="clock-abbr" data-abbr="' + i + '"></span></div>' +
          '<div class="clock-time" data-time="' + i + '">' + DASH + '</div><div class="clock-status" data-status="' + i + '"></div></div>';
      }).join("");
    }
    CLOCKS.forEach(function (c, i) {
      var p = tzParts(now, c[1]);
      setText('[data-time="' + i + '"]', pad(p.h) + ":" + pad(p.mi));
      setText('[data-abbr="' + i + '"]', tzAbbr(now, c[1]));
      setText('[data-status="' + i + '"]', p.wd + " " + p.d + " " + MON[p.mo - 1]);
    });
    var mp = tzParts(now, MELB);
    setText("#todayDate", mp.wd + " " + mp.d + " " + MON[mp.mo - 1] + MID + "Melbourne");
  }
  function sessionsOf(d) {
    return objs(d.sessions).map(function (s) {
      return { name: str(s.name), start: parseIso(s.start_utc), end: parseIso(s.end_utc) };
    }).filter(function (s) { return s.start !== null && s.end !== null && s.end > s.start; });
  }
  function renderTimeline(d) {
    var ss = sessionsOf(d), tl = $("#timeline"), lg = $("#tlLegend");
    if (d.market_open === false) {
      morph(tl, '<span class="tl-label faint">' + DASH + '</span><div class="tl-lane"></div>');
      morph(lg, '<span class="faint">Market closed</span>');
      return;
    }
    if (!ss.length) { morph(tl, '<span class="tl-label">' + DASH + '</span><div class="tl-lane"></div>'); morph(lg, ""); return; }
    var start = Math.min.apply(null, ss.map(function (s) { return s.start; }));
    var end = Math.max.apply(null, ss.map(function (s) { return s.end; }));
    var span = end - start, now = nowMs(), shut = d.market_open === false;
    function pc(t) { return clamp((t - start) / span * 100, 0, 100); }
    var axis = "";
    for (var i = 0; i <= 8; i++) {
      var t = start + i * span / 8;
      axis += '<span class="' + (i === 0 ? "first" : i === 8 ? "last" : i % 2 ? "odd" : "") + '" data-gl="' + geomNum(i * 12.5) + '">' + hhmm(t, MELB) + "</span>";
    }
    var html = '<span class="tl-label faint">Melb.</span><div class="tl-axis">' + axis + "</div>";
    ss.forEach(function (s) {
      var on = !shut && now >= s.start && now < s.end;
      html += '<span class="tl-label">' + esc(SESSION_NAME[s.name] || cap(s.name) || DASH) + '</span><div class="tl-lane" role="img" aria-label="' +
        esc((SESSION_NAME[s.name] || s.name) + " " + hhmm(s.start, MELB) + " to " + hhmm(s.end, MELB) + " Melbourne") + '">' +
        '<span class="tl-seg' + (on ? " on" : "") + '" data-gl="' + geomNum(pc(s.start)) + '" data-gw="' + geomNum(pc(s.end) - pc(s.start)) + '"></span></div>';
    });
    var inDay = now >= start && now < end;
    html += '<div class="tl-over">' + (inDay ? '<div class="tl-now" data-gl="' + geomNum(pc(now)) + '"><span>' + hhmm(now, MELB) + "</span></div>" : "") + "</div>";
    morph(tl, html);
    morph(lg, ss.map(function (s) {
      return "<span>" + esc(SESSION_NAME[s.name] || cap(s.name)) + " <b>" + hhmm(s.start, MELB) + NDASH + hhmm(s.end, MELB) + "</b></span>";
    }).join("") + '<span class="faint">Melbourne time</span>');
  }
  function closedTodayEur(live) {
    return objs(obj(live).closed_today).filter(isEur);
  }
  function sumOf(list, key) {
    var s = 0, any = false;
    list.forEach(function (t) { var v = num(t[key]); if (v !== null) { s += v; any = true; } });
    return any ? s : null;
  }
  function fig(label, value, sub, extra) {
    return '<div class="fig' + (extra || "") + '"><div class="fig-label">' + esc(label) + '</div><div class="fig-value ' + (value.c || "") + '">' + esc(value.t) +
      '</div><div class="fig-sub">' + esc(sub || "") + "</div></div>";
  }
  function renderTodayFigs(d, live) {
    var g = obj(d.guard), acct = obj(obj(live).account), ct = closedTodayEur(live);
    var rt = sumOf(ct, "r_net"), pt = sumOf(ct, "pct_of_balance"), mt = sumOf(ct, "net_profit");
    if (str(acct.currency)) state.currency = str(acct.currency);
    var losses = num(g.losses), left = num(g.losses_left), tl = num(g.trades_left);
    var html =
      fig("R today", { t: ct.length ? fR(rt) : (live.account ? fR(0) : DASH), c: cls(rt) }, ct.length ? fPct(pt) + MID + fMoney(mt, true) : (ct.length + " closed"), " big") +
      fig("Equity", { t: fMoney(acct.equity) }, "Balance " + fMoney(acct.balance), " big") +
      fig("Losses left", { t: left === null ? DASH : String(left) }, losses === null || left === null ? "" : "of " + (losses + left)) +
      fig("Trades left", { t: tl === null ? DASH : String(tl) }, tl === null ? "No win yet" : num(g.wins) > 0 ? "After a win" : "No new trades");
    morph($("#todayFigs"), html);
  }
  function renderPlan(d) {
    var p = d.plan, box = $("#plan");
    if (!isObj(p)) { setText("#planMeta", ""); morph(box, '<p class="empty-note">' + DASH + "</p>"); return; }
    if (p.pending === true && p.market_closed === true) {
      setText("#planMeta", "");
      morph(box, '<div class="notrade"><p class="notrade-t">Market closed</p></div>');
      return;
    }
    if (p.pending === true) {
      var pt = parseIso(p.plan_time_utc);
      setText("#planMeta", "");
      morph(box, '<div class="notrade"><p class="notrade-t">Plan pending</p><p class="notrade-s">' +
        (pt === null ? DASH : hhmm(pt, LON) + " London" + MID + hhmm(pt, MELB) + " Melbourne") + "</p></div>");
      return;
    }
    var cards = objs(p.cards), run = parseIso(p.run_utc);
    setText("#planMeta", run === null ? "" : hhmm(run, MELB) + " Melbourne");
    if (str(p.result) !== "orders" || !cards.length) {
      var reason = str(p.reason) || "no trade today";
      morph(box, '<div class="notrade"><p class="notrade-t">' + esc(cap(reason)) + "</p></div>");
      return;
    }
    morph(box, '<div class="cards">' + cards.map(cardHTML).join("") + "</div>");
  }
  function cardHTML(c) {
    var exp = parseIso(c.expiry_utc), entry = num(c.entry), stop = num(c.stop);
    var pips = entry !== null && stop !== null ? Math.abs(entry - stop) * 1e4 : null;
    var offered = c.offered === true;
    return '<article class="ocard" data-key="card-' + esc(str(c.id)) + '"><div class="oc-head"><span class="oc-pair">' + esc(pair(c.symbol)) +
      '</span><span class="oc-side">' + esc(sideLabel(c.side)) + '</span><span class="pill oc-status" data-k="' + (offered ? "planned" : "be") + '">' +
      (offered ? "Offered" : "Not offered") + "</span></div>" +
      '<div class="oc-prices">' + pbox("Entry", fPx(c.entry)) + pbox("Stop", fPx(c.stop)) + pbox("Target", fPx(c.target)) + "</div>" +
      '<dl class="facts"><div><dt>Risk</dt><dd>' + fPips(pips) + " pips <small>" + MID + "1R</small></dd></div>" +
      "<div><dt>Target</dt><dd>" + fR(c.target_r, 1) + "</dd></div>" +
      "<div><dt>Size</dt><dd>" + fLots(c.lots) + " lots <small>" + MID + (num(c.risk_pct) === null ? DASH : fNum(c.risk_pct, 2) + "%") + "</small></dd></div>" +
      "<div><dt>Expiry</dt><dd>" + (exp === null ? DASH : hhmm(exp, LON) + " London <small>" + MID + hhmm(exp, MELB) + " Melb.</small>") + "</dd></div>" +
      "<div><dt>Cost</dt><dd>" + (num(c.cost_pct_of_risk) === null ? DASH : fNum(c.cost_pct_of_risk, 0) + "% <small>" + MID + "of risk</small>") + "</dd></div></dl>" +
      (str(c.level_note) ? '<div class="oc-foot">' + esc(str(c.level_note)) + "</div>" : "") +   /* the level, worded by the server */
      (offered ? "" : '<div class="oc-foot">' + esc(str(c.not_offered_reason) || DASH) + "</div>") + "</article>";
  }
  /* ---------------- suggestions (Part B): cards built from the server's fields; no order is ever sent ---------------- */
  var ACT_WORD = { take: "Take", skip: "Skip", changed: "Changed" };
  function fUnit(x, unit) {
    if (unit !== "pips") return fR(x, 2);
    x = num(x); if (x === null) return DASH;
    var v = fixed(x, 1);                       /* the sign follows the shown value: never "−0.0" */
    return sgn(v) + Math.abs(v).toFixed(1) + " pips";
  }
  /* Melbourne times for the owner on the 12-hour clock (CLAUDE.md "12-hour times"), e.g. "9:30 pm". */
  function hm12(ms, tz) { var p = tzParts(ms, tz), h = p.h % 12 || 12; return h + ":" + pad(p.mi) + " " + (p.h < 12 ? "am" : "pm"); }
  function suggCardHTML(c) {
    var exp = parseIso(c.expiry_utc), at = parseIso(c.placed_utc), id = esc(str(c.id));
    var dec = obj(c.decision), res = obj(c.result), side = str(c.side) === "buy" ? "Buy" : str(c.side) === "sell" ? "Sell" : DASH;
    var prices = num(c.entry) === null ? "" : '<div class="oc-prices">' + pbox("Entry", fPx(c.entry)) + pbox("Stop", fPx(c.stop)) + pbox("Target", fPx(c.target)) + "</div>";
    var ticks = objs(c.ticks).map(function (t) {
      return '<li class="check"><span class="ck">' + (t.ticked === true ? "&#10003;" : "&#8211;") + "</span><span>" + esc(str(t.label)) + "</span></li>";
    }).join("");
    var form = "";
    if (state.sform && state.sform.id === str(c.id)) {
      form = '<form class="sform" id="suggForm" data-id="' + id + '" data-act="' + esc(state.sform.act) + '" novalidate>' +
        '<label class="fl">Reason<input name="reason" maxlength="500" required></label>' +
        '<button class="btn btn-sm" type="submit">Save ' + esc(ACT_WORD[state.sform.act] || "") + "</button>" +
        '<p class="form-msg" id="suggMsg" role="status"></p></form>';
    }
    var acts = arr(c.actions).filter(function (a) { return ACT_WORD[a]; }).map(function (a) {
      return '<button class="btn btn-sm' + (a === "take" ? "" : " btn-quiet") + '" type="button" data-sact="' + a + '" data-sid="' + id + '">' + ACT_WORD[a] + "</button>";
    }).join("");
    return '<article class="ocard" data-key="sugg-' + id + '"><div class="oc-head"><span class="oc-pair">' + esc(str(c.title)) +
      '</span><span class="oc-side">' + esc(side) + '</span><span class="pill oc-status" data-k="planned">' + esc(cap(str(c.state)) || DASH) + "</span></div>" +
      prices +
      '<dl class="facts"><div><dt>Placed</dt><dd>' + (at === null ? DASH : hhmm(at, LON) + " London <small>" + MID + hm12(at, MELB) + " Melb.</small>") + "</dd></div>" +
      "<div><dt>Expiry</dt><dd>" + (exp === null ? DASH : hhmm(exp, NYC) + " New York <small>" + MID + hm12(exp, MELB) + " Melb.</small>") + "</dd></div>" +
      (num(c.score) === null ? "" : "<div><dt>Score</dt><dd>" + fInt(c.score) + " <small>" + MID + esc(cap(str(c.tier))) + "</small></dd></div>") +
      (isObj(c.result) ? "<div><dt>Own result</dt><dd>" + fUnit(res.R_20, res.unit) + " <small>" + MID + "after 2.0 pips</small></dd></div>" : "") +
      (isObj(c.decision) ? "<div><dt>You</dt><dd>" + esc(ACT_WORD[str(dec.decision)] || DASH) + (str(dec.reason) ? " <small>" + MID + esc(str(dec.reason)) + "</small>" : "") + "</dd></div>" : "") +
      "</dl>" + (ticks ? '<ul class="checklist">' + ticks + "</ul>" : "") +
      '<div class="oc-foot">' + esc(str(c.record_line)) + "</div>" +
      (acts ? '<div class="oc-acts">' + acts + "</div>" : "") + form + "</article>";
  }
  function renderSuggestions(d) {
    var list = objs(d.suggestions);
    setText("#suggNote", list.length ? String(list.length) : "");
    morph($("#suggestions"), list.length ? '<div class="cards">' + list.map(suggCardHTML).join("") + "</div>" :
      '<p class="empty-note">None today.</p>');
  }
  function suggAct(act, id) {
    if (act === "take") { sendDecision(id, "take", ""); return; }
    state.sform = { id: id, act: act };
    renderSuggestions(obj(state.today));
    var inp = $("#suggForm input"); if (inp) inp.focus();
  }
  function sendDecision(id, act, reason) {
    return api("POST", "/api/suggestions/" + encodeURIComponent(id) + "/decision", { decision: act, reason: reason }).then(function () {
      state.sform = null; loadTab("today");
    }, function (e) { var m = $("#suggMsg"); if (m) m.textContent = str(e && e.message) || "Not saved"; });
  }
  function submitSugg(f) {
    var reason = str(f.reason && f.reason.value).trim();
    if (!reason) { var m = $("#suggMsg"); if (m) m.textContent = "A reason is needed"; return; }
    sendDecision(f.getAttribute("data-id"), f.getAttribute("data-act"), reason);
  }
  function renderLeads() {
    var d = obj(state.leads), list = objs(d.leads), run = parseIso(d.run_utc);
    $("#leadEmpty").hidden = run !== null;
    setText("#leadNote", run === null ? "" : "run " + hm12(run, MELB) + " Melbourne");
    morph($("#leadList"), list.map(function (x) {
      var t = obj(x.totals), u = str(t.unit), nx = parseIso(x.next_entry_utc);
      var rows = objs(x.trades).map(function (r, i) {
        var at = parseIso(r.decision_utc);
        return '<tr data-key="lt-' + i + '"><td>' + (at === null ? DASH : fWhen(r.decision_utc)) + "</td><td>" + esc(str(r.exit_reason) || DASH) +
          '</td><td class="num">' + fUnit(r.after_20, u) + '</td><td class="num">' + fUnit(r.after_16, u) + '</td><td class="num">' + fUnit(r.before, u) + "</td></tr>";
      }).join("");
      return '<article class="lead" data-key="lead-' + esc(str(x.rule_id)) + '"><div class="ph"><h3>' + esc(str(x.title)) + '</h3><span class="pill">' + esc(str(x.label)) + "</span></div>" +
        '<p class="oc-foot">' + esc(str(x.record_line)) + "</p>" +
        '<dl class="facts"><div><dt>State</dt><dd>' + esc(str(x.state_text) || cap(str(x.state)) || DASH) + "</dd></div>" +
        "<div><dt>Next entry</dt><dd>" + (nx === null ? DASH : fWhen(x.next_entry_utc)) + "</dd></div>" +
        "<div><dt>Trades</dt><dd>" + fInt(t.trades) + " <small>" + MID + esc(str(obj(x.needed).text)) + "</small></dd></div>" +
        "<div><dt>After 2.0 pips</dt><dd>" + fUnit(t.after_20, u) + " <small>" + MID + "1.6: " + fUnit(t.after_16, u) + "</small></dd></div>" +
        "<div><dt>Before costs</dt><dd>" + fUnit(t.before, u) + "</dd></div></dl>" +
        (rows ? '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Entry</th><th>Exit</th><th class="num">2.0</th><th class="num">1.6</th><th class="num">Before</th></tr></thead><tbody>' + rows + "</tbody></table></div>" : "") +
        "</article>";
    }).join("") + (str(d.problem) ? '<p class="oc-foot">' + esc(str(d.problem)) + "</p>" : "") +
      (list.length ? '<p class="empty-note">' + esc(str(d.state_note)) + "</p>" : ""));
  }
  function renderHandCheck(h) {
    setText("#handNote", str(h.note) || "Information. Not a test.");
    morph($("#handCheck"), '<p class="empty-note">' + esc(str(h.title)) + MID + esc(str(h.note) || "Information. Not a test.") + "</p>" +
      '<dl class="facts"><div><dt>Offered</dt><dd>' + fInt(h.offered) + "</dd></div><div><dt>Taken</dt><dd>" + fInt(h.taken) +
      "</dd></div><div><dt>Skipped</dt><dd>" + fInt(h.skipped) + "</dd></div><div><dt>Changed</dt><dd>" + fInt(h.changed) +
      "</dd></div><div><dt>Coded rule</dt><dd>" + fR(h.coded_r_after_20, 2) + " <small>" + MID + fInt(h.coded_trades) + " trades" + MID + "after 2.0 pips</small></dd></div>" +
      "<div><dt>Your trades</dt><dd>" + fR(h.your_r, 2) + " <small>" + MID + fInt(h.your_trades) + " trades</small></dd></div></dl>");
  }
  function pbox(k, v) { return '<div class="pbox"><span class="k">' + esc(k) + '</span><span class="v">' + esc(v) + "</span></div>"; }
  function renderChecklist(d) {
    var list = arr(d.checklist).filter(function (s) { return typeof s === "string" && s.trim(); });
    setText("#checkNote", list.length ? String(list.length) : "");
    morph($("#checklist"), list.length ? list.map(function (s, i) {
      return '<li class="check" data-key="ck-' + i + '"><span class="ck">' + (i + 1) + "</span><span>" + esc(s) + "</span></li>";
    }).join("") : '<li class="check"><span class="ck"></span><span class="faint">' + DASH + "</span></li>");
  }
  var GUARD = {
    open: ["Open", "open"], one_more: ["One more trade", "running"], full: ["Full", "warn"], done: ["Day done", "loss"]
  };
  function renderGuard(d) {
    var g = obj(d.guard), st = str(g.status), meta = GUARD[st];
    var pill = $("#guardPill");
    pill.setAttribute("data-k", meta ? meta[1] : "be");
    setText("#guardPill", meta ? meta[0] : DASH);
    var steps = [["open", "Fresh day"], ["one_more", "After a win"], ["done", "Day done"]];
    var idx = { open: 0, full: 0, one_more: 1, done: 2 }[st];
    var html = '<div class="dg-head">' + esc(meta ? meta[0] : DASH) + '</div><div class="dg-sub">' + esc(str(g.reason) || DASH) + "</div>" +
      '<ol class="ladder">' + steps.map(function (s, i) {
        var c = idx === undefined ? "" : i < idx ? "done" : i === idx ? "now" + (st === "full" ? " warn" : "") : "";
        return '<li class="' + c + '"><span>' + s[1] + "</span></li>";
      }).join("") + "</ol>" +
      (g.can_open_new === false ? '<div class="dg-stop">No new trades</div>' : "") +
      '<dl class="kv">' + kv("Losses left", fInt(g.losses_left)) + kv("Trades left", g.trades_left === null ? DASH : fInt(g.trades_left)) +
      kv("Wins", fInt(g.wins)) + kv("Losses", fInt(g.losses)) + kv("Breakevens", fInt(g.breakevens)) +
      kv("Open", fInt(g.open_trades)) + kv("Pending", fInt(g.pending_orders)) + "</dl>" + paperGuardLine(d);
    morph($("#guardBody"), html);
  }
  function paperGuardLine(d) {
    var pg = obj(d.paper_guard), meta = GUARD[str(pg.status)];
    if (!meta) return "";
    return '<p class="reason" data-k="paper-guard">Paper' + MID + "<b>" + esc(meta[0]) + "</b>" + MID + esc(str(pg.reason) || DASH) + "</p>";
  }
  function kv(k, v, c) { return "<div><dt>" + esc(k) + '</dt><dd class="' + (c || "") + '">' + v + "</dd></div>"; }
  function renderStreak(d) {
    var s = obj(d.streak), cfg = obj(settingsNow().streak);
    var active = s.active === true, known = s.active === true || s.active === false;
    var pill = $("#streakPill");
    pill.setAttribute("data-k", active ? "running" : "be");
    setText("#streakPill", known ? (active ? "On" : "Off") : DASH);
    var need = num(cfg.green_days_to_start), green = num(s.green_days);
    var tmin = num(s.target_min_r), tmax = num(s.target_max_r);
    var bars = "";
    if (need !== null && need > 0 && need <= 10) {
      bars = '<div class="gdays">';
      for (var i = 0; i < need; i++) bars += '<span class="' + (green !== null && i < green ? "on" : "") + '"></span>';
      bars += "</div>";
    }
    var html = '<div class="streak-line">Green days <b>' + fInt(green) + (need !== null ? " of " + fInt(need) : "") + "</b></div>" + bars +
      /* Off: streak_r is the R of the current green run (no peak or floor yet). */
      '<dl class="kv">' + kv(active ? "Streak" : "Run", fR(s.streak_r, 1), cls(s.streak_r)) + kv("Peak", active ? fR(s.peak_r, 1) : DASH) +
      kv("Floor", fR(s.floor_r, 1), "warn-c") +
      kv("Targets", tmin === null || tmax === null ? DASH : fNum(tmin, 0) + NDASH + fNum(tmax, 0) + "R") +
      kv("Ended", validDay(s.ended_on) ? fDay(s.ended_on) : DASH) + "</dl>" +
      (str(s.reason) ? '<p class="reason">' + esc(s.reason) + "</p>" : "");
    morph($("#streakBody"), html);
  }

  function renderFunded(d) {
    var f = obj(d.funded), on = f.enabled === true, set = f.set === true;
    setText("#fundedPill", !on ? "Off" : !set ? "Not set" : str(f.status) || DASH);
    $("#fundedPill").setAttribute("data-k", f.daily_breach === true || f.max_breach === true ? "loss" : on && set ? "running" : "be");
    var money = function (x) { return num(x) === null ? DASH : fMoney(x, false); };
    var used = num(f.daily_used);
    var html = !on ? '<p class="reason">Off in config</p>' : !set ? '<p class="reason">Not set</p>' :
      '<dl class="kv">' + kv("Today's loss", money(f.daily_loss) + " <small>of " + money(f.daily_limit) + "</small>", f.daily_breach === true ? "neg-c" : "") +
      kv("Limit used", used === null ? DASH : fNum(used * 100, 0) + "%", used !== null && used >= 0.8 ? "warn-c" : "") +
      kv("Floor", money(f.floor) + " <small>" + (num(f.to_floor) === null ? "" : money(f.to_floor) + " above") + "</small>", f.max_breach === true ? "neg-c" : "") +
      kv("Open risk", num(f.open_risk_pct) === null ? DASH : fNum(f.open_risk_pct, 2) + "% <small>cap " + fNum(f.risk_cap_pct, 2) + "%</small>", f.cap_hit === true ? "warn-c" : "") +
      kv("Reset", f.next_reset_utc ? fWhen(f.next_reset_utc) : DASH) + "</dl>";
    morph($("#fundedBody"), html);
  }

  /* ================= LIVE ================= */
  var ORDER_TYPE = { buy_limit: "Buy limit", sell_limit: "Sell limit", buy_stop: "Buy stop", sell_stop: "Sell stop",
    buy_stop_limit: "Buy stop limit", sell_stop_limit: "Sell stop limit", buy: "Buy", sell: "Sell", other: "Other" };
  var EXIT = { tp: ["Target", "win"], sl: ["Stop", "loss"], be: ["Breakeven", "be"], manual: ["Manual", "own"], so: ["Stop out", "loss"],
    expired: ["Expired", "be"], other: ["Other", "be"] };
  var MGMT_HINT = { move_stop_to_entry: "Stop to entry", close_or_trail: "Close or trail" };
  function renderLive() {
    var d = obj(state.live), acct = obj(d.account), br = obj(d.bridge), st = str(br.state);
    if (str(acct.currency)) state.currency = str(acct.currency);
    var body = $("#liveBody");
    body.classList.toggle("offline-dim", st === "offline" || st === "never");
    safe(function () {
      var word = BRIDGE_WORD[st] || "Not seen", age = num(br.age_s);
      var bits = [];
      if (age !== null) bits.push(fInt(age) + " s ago");
      if (str(br.alias)) bits.push(str(br.alias));
      morph($("#bridgeLine"), '<span class="dot" data-state="' + (BRIDGE_WORD[st] ? st : "never") + '"></span><span><b>' + word + "</b>" +
        (bits.length ? MID + esc(bits.join(MID)) : "") + "</span>");
    });
    var positions = objs(d.positions);
    safe(function () {
      var inc = [];
      positions.forEach(function (p) {
        if (p.no_stop === true) inc.push('<div class="incident" data-key="ns-' + esc(str(p.position_id)) + '">No stop' + MID + esc(pair(p.symbol)) + " " +
          esc(sideLabel(p.side).toLowerCase()) + " " + fLots(p.volume) + "</div>");
      });
      if (acct.trade_allowed === true || br.trade_allowed === true) inc.push('<div class="incident" data-key="tc">Terminal can trade' + MID + "use the investor password</div>");
      morph($("#incidents"), inc.join(""));
    });
    var eur = positions.filter(isEur), others = num(d.other_symbols_open);
    safe(function () {
      var ct = closedTodayEur(d), rt = sumOf(ct, "r_net");
      var html =
        fig("Equity", { t: fMoney(acct.equity) }, "Balance " + fMoney(acct.balance), " big") +
        fig("Floating", { t: fR(acct.floating_r), c: cls(acct.floating_r) }, fPct(acct.floating_pct) + MID + fMoney(acct.floating, true), " big") +
        fig("R closed today", { t: ct.length ? fR(rt) : (d.account ? fR(0) : DASH), c: cls(rt) }, fPct(sumOf(ct, "pct_of_balance"))) +
        fig("Open", { t: d.account || positions.length ? String(eur.length) : DASH }, others ? "+" + fInt(others) + " other symbols" : "EUR/USD");
      morph($("#liveFigs"), html);
    });
    safe(function () {
      setText("#posCount", eur.length ? String(eur.length) : "");
      morph($("#positions"), eur.length ? eur.map(posHTML).join("") : '<p class="empty-note">No positions</p>');
    });
    safe(function () {
      var ords = objs(d.orders).filter(isEur);
      setText("#pendCount", ords.length ? String(ords.length) : "");
      morph($("#pending"), ords.length ? ords.map(function (o) {
        var tk = esc(str(o.ticket)), open = openCheck();
        return '<div class="row" data-key="ord-' + tk + '"><div class="row-t">EUR/USD <span class="pos-side">' +
          esc(ORDER_TYPE[str(o.type)] || DASH) + " " + fLots(o.volume) + '</span></div><div class="row-v">' + fPx(o.price) + "</div>" +
          '<div class="row-s">Stop ' + fPx(o.sl) + MID + "Target " + fPx(o.tp) + MID + "Expires " + expiryLM(o.expiry_utc) + "</div>" +
          '<div class="row-acts"><button class="btn btn-sm btn-quiet" type="button" data-check-order="' + tk + '">New check</button>' +
          (open ? '<button class="btn btn-sm" type="button" data-link-order="' + tk + '" data-check="' + open.check_id + '">This is my order</button>' : "") +
          "</div></div>";
      }).join("") : '<p class="empty-note">No pending orders</p>');
    });
    safe(function () {
      var ct = closedTodayEur(d);
      setText("#closedCount", ct.length ? String(ct.length) : "");
      morph($("#closed"), ct.length ? ct.map(function (t) {
        var ex = EXIT[str(t.close_reason)];
        return '<div class="row" data-key="cl-' + esc(str(t.id)) + '"><div class="row-t">EUR/USD <span class="pos-side">' + esc(sideLabel(t.side)) + " " +
          fLots(t.volume) + "</span>" + (ex ? '<span class="pill" data-k="' + ex[1] + '">' + ex[0] + "</span>" : "") + '</div><div class="row-v ' + cls(t.r_net) + '">' +
          fR(t.r_net) + '</div><div class="row-s">' + fPct(t.pct_of_balance) + MID + fMoney(t.net_profit, true) + MID + "Closed " + fWhen(t.close_utc) + "</div></div>";
      }).join("") : '<p class="empty-note">No closed trades</p>');
    });
  }
  function expiryLM(iso) {
    var t = parseIso(iso);
    return t === null ? DASH : hhmm(t, LON) + " London" + MID + hhmm(t, MELB) + " Melb.";
  }
  function posHTML(p) {
    var open = num(p.open_price), price = num(p.price), tp = num(p.tp), stop0 = num(p.initial_sl);
    if (stop0 === null) stop0 = num(p.sl);
    var bar = "";
    if (open !== null && tp !== null && stop0 !== null && tp !== stop0) {
      var e = clamp((open - stop0) / (tp - stop0) * 100, 0, 100);
      var prog = num(p.progress), cur = prog !== null ? clamp(prog * 100, 0, 100) : price !== null ? clamp((price - stop0) / (tp - stop0) * 100, 0, 100) : e;
      bar = '<div class="pbar" aria-hidden="true"><div class="pbar-track"></div><div class="pbar-risk" data-gw="' + geomNum(e) + '"></div>' +
        '<div class="pbar-fill' + (cur < e ? " neg" : "") + '" data-gl="' + geomNum(Math.min(e, cur)) + '" data-gw="' + geomNum(Math.abs(cur - e)) + '"></div>' +
        '<div class="pbar-mark" data-gl="' + geomNum(e) + '"></div><div class="pbar-thumb" data-gl="' + geomNum(cur) + '"></div>' +
        '<span class="pbar-lbl l">First stop ' + fPx(stop0) + '</span><span class="pbar-lbl mid" data-gl="' + geomNum(e) + '">Entry</span>' +
        '<span class="pbar-lbl r">Target ' + fPx(tp) + "</span></div>";
    }
    var hint = MGMT_HINT[str(p.management)];
    return '<div class="pos" data-key="pos-' + esc(str(p.position_id)) + '">' +
      '<div class="pos-top"><div class="pos-id"><span class="pos-pair">EUR/USD</span><span class="pos-side">' + esc(sideLabel(p.side)) + " " + fLots(p.volume) + "</span>" +
      (p.stop_at_entry === true ? '<span class="badge-be">Stop at entry</span>' : "") +
      (p.no_stop === true ? '<span class="badge-inc">No stop</span>' : "") +
      (hint ? '<span class="pill" data-k="running">' + hint + "</span>" : "") + "</div>" +
      '<div class="pos-pnl"><span class="r ' + cls(p.r_now) + '" data-f="r">' + fR(p.r_now) + '</span><span class="pct" data-f="pct">' + fPct(p.pct_of_balance) +
      '</span><span class="usd" data-f="usd">' + fMoney(num(p.profit) === null ? null : num(p.profit) + (num(p.swap) || 0), true) + "</span></div></div>" + bar +
      '<div class="pos-meta"><span>Open <b>' + fPx(p.open_price) + '</b></span><span>Now <b data-f="px">' + fPx(p.price) + "</b></span><span>Stop <b>" + fPx(p.sl) +
      "</b></span><span>Target <b>" + fPx(p.tp) + '</b></span><span data-f="dist">' + fPips(p.to_stop_pips) + " pips to stop" + MID + fPips(p.to_target_pips) +
      " to target</span><span>Opened " + fWhen(p.open_utc) + "</span></div></div>";
  }

  /* ================= JOURNAL ================= */
  var TAG = { planned: ["Planned", "planned"], own_idea: ["Own idea", "own"], rule_break: ["Rule break", "break"] };
  var FLAG = { after_max_losses: "After the loss limit", after_loss_after_win: "Loss after a win", over_trades_after_win: "Extra trade after a win",
    over_open_risk: "Too much open risk", no_stop: "No stop", early_close: "Closed early", size_above_risk: "Size above risk",
    stop_moved_away: "Stop moved away", no_checklist: "No check", below_tier: "Below tier", over_tier_risk: "Over tier risk",
    no_stop_to_entry: "No stop to entry" };
  var SESSION_SHORT = { asia: "Asia", london: "London", new_york: "New York" };
  function flagsOf(t) { return arr(t.flags).filter(function (f) { return typeof f === "string"; }); }
  var INFO_FLAGS = { size_above_risk: true };   /* shown, not counted as a rule break (app.risk.flags.INFO_FLAGS) */
  function isBreak(t) { return flagsOf(t).some(function (f) { return !INFO_FLAGS[f]; }) || str(t.tag) === "rule_break"; }
  function isClosed(t) { return str(t.status) === "closed"; }
  function journalRows() {
    return state.journal.filter(function (t) { return !t.symbol || isEur(t); });
  }
  function renderJournal() {
    var all = journalRows(), band = num(obj(settingsNow().risk).breakeven_band_r);
    if (band === null) band = 0;
    var closed = all.filter(isClosed);
    function kind(t) {
      var r = num(t.r_net), g = num(t.r_gross);
      if (str(t.close_reason) === "be" && g !== null && Math.abs(g) <= band) return "be";   /* costs alone are no loss */
      return r === null ? "unknown" : r > band ? "win" : r < -band ? "loss" : "be";
    }
    var F = [["all", "All", function () { return true; }], ["win", "Wins", function (t) { return isClosed(t) && kind(t) === "win"; }],
      ["loss", "Losses", function (t) { return isClosed(t) && kind(t) === "loss"; }], ["break", "Rule breaks", isBreak],
      ["untagged", "Untagged", function (t) { return isClosed(t) && !TAG[str(t.tag)]; }], ["open", "Open", function (t) { return str(t.status) === "open"; }]];
    safe(function () {
      morph($("#jsum"),
        kv("Trades", String(all.length)) + kv("Closed", String(closed.length)) +
        kv("Total R", closed.length ? fR(sumOf(closed, "r_net")) : DASH, cls(sumOf(closed, "r_net"))) +
        kv("Total %", closed.length ? fPct(sumOf(closed, "pct_of_balance")) : DASH) +
        kv("Rule breaks", String(all.filter(isBreak).length)) + kv("Untagged", String(closed.filter(function (t) { return !TAG[str(t.tag)]; }).length)));
    });
    var f = null;
    F.forEach(function (x) { if (x[0] === state.jfilter) f = x; });
    if (!f) { f = F[0]; state.jfilter = "all"; }
    safe(function () {
      morph($("#jfilters"), F.map(function (x) {
        return '<button type="button" class="fchip" data-jf="' + x[0] + '" aria-pressed="' + (state.jfilter === x[0]) + '">' + x[1] +
          '<span class="n">' + all.filter(x[2]).length + "</span></button>";
      }).join(""));
    });
    safe(function () {
      var rows = all.filter(f[2]).slice().reverse();
      var head = '<thead><tr><th>Opened</th><th>Side</th><th class="wide">Session</th><th class="num wide">Stop</th><th class="num">R</th>' +
        '<th class="num wide">%</th><th class="num wide">Money</th><th class="wide">Exit</th><th>Tag</th><th class="wide">Flags</th></tr></thead>';
      var body = rows.length ? rows.map(function (t) {
        var fl = flagsOf(t), tg = TAG[str(t.tag)], ex = EXIT[str(t.close_reason)], id = num(t.id);
        var open = str(t.status) === "open";
        return "<tr" + (id === null ? "" : ' tabindex="0" data-trade="' + id + '"') + ' data-key="tr-' + (id === null ? "x" : id) + '">' +
          '<td class="nw">' + fWhen(t.open_utc) + '<span class="two">' + (open ? DASH : fPct(t.pct_of_balance) + MID + fMoney(t.net_profit, true)) + "</span>" +
          (fl.length ? '<span class="two flagdot">' + esc(FLAG[fl[0]] || fl[0]) + (fl.length > 1 ? " +" + (fl.length - 1) : "") + "</span>" : "") + "</td>" +
          "<td>" + esc(sideLabel(t.side)) + "</td>" +
          '<td class="wide">' + esc(SESSION_SHORT[str(t.session)] || DASH) + "</td>" +
          '<td class="num wide">' + fPips(t.stop_pips) + "</td>" +
          '<td class="num ' + cls(t.r_net) + '">' + (open ? "Open" : fR(t.r_net)) + "</td>" +
          '<td class="num wide">' + (open ? DASH : fPct(t.pct_of_balance)) + "</td>" +
          '<td class="num wide">' + (open ? DASH : fMoney(t.net_profit, true)) + "</td>" +
          '<td class="wide">' + (ex ? '<span class="pill" data-k="' + ex[1] + '">' + ex[0] + "</span>" : DASH) + "</td>" +
          "<td>" + (tg ? '<span class="pill" data-k="' + tg[1] + '">' + tg[0] + "</span>" : '<span class="faint">' + DASH + "</span>") + "</td>" +
          '<td class="wide">' + (fl.length ? '<span class="flagdot">' + esc(FLAG[fl[0]] || fl[0]) + "</span>" + (fl.length > 1 ? ' <span class="faint">+' + (fl.length - 1) + "</span>" : "") : '<span class="faint">' + DASH + "</span>") + "</td></tr>";
      }).join("") : '<tr><td class="empty" colspan="10">No trades</td></tr>';
      morph($("#jtable"), head + "<tbody>" + body + "</tbody>");
    });
    safe(renderPaper);
  }
  function mgmtLabel(k) {
    var m = obj(settingsNow().management), take = num(m.take_or_trail_r), trail = num(m.trail_stop_r);
    if (k === "close_at_4r") return take === null ? "Close" : "Close at +" + fNum(take, 0) + "R";
    if (k === "trail_to_2r") return trail === null ? "Trail" : "Trail to +" + fNum(trail, 0) + "R";
    return "None";
  }
  function findTrade(id) {
    for (var i = 0; i < state.journal.length; i++) if (num(state.journal[i].id) === id) return state.journal[i];
    return null;
  }
  var SPREAD_SRC = { snapshot: "From the bridge", own_median: "Your median for that hour", unknown: "Not known" };
  function costSplitHTML(t) {
    if (str(t.status) !== "closed" || !t.spread_source) return "";
    var pv = num(t.risk_money) && num(t.stop_pips) ? num(t.risk_money) / num(t.stop_pips) : null;
    var pips = function (money) { return pv ? fPips(-num(money) / pv) + " pips" : DASH; };
    var spread = num(t.spread_in_pips) !== null && num(t.spread_out_pips) !== null ? (num(t.spread_in_pips) + num(t.spread_out_pips)) / 2 : null;
    var dir = str(t.side) === "buy" ? 1 : -1;
    var drift = num(t.quote_drift_in_pips) !== null || num(t.quote_drift_out_pips) !== null ? dir * ((num(t.quote_drift_in_pips) || 0) - (num(t.quote_drift_out_pips) || 0)) : null;
    return '<div><h3>Costs</h3><dl class="facts">' +
      "<div><dt>Spread</dt><dd>" + (spread === null ? DASH : fPips(spread) + " pips") + " <small>" + esc(SPREAD_SRC[str(t.spread_source)] || DASH) + "</small></dd></div>" +
      "<div><dt>Quote drift</dt><dd>" + (drift === null ? DASH : fPips(drift) + " pips") + "</dd></div>" +
      "<div><dt>Commission</dt><dd>" + pips(t.commission) + "</dd></div>" +
      "<div><dt>Swap</dt><dd>" + pips(t.swap) + "</dd></div>" +
      "<div><dt>Fee</dt><dd>" + pips(t.fee) + "</dd></div>" +
      "<div><dt>Stop slippage</dt><dd>" + (num(t.slip_exit_pips) === null ? DASH : fPips(t.slip_exit_pips) + " pips") + "</dd></div>" +
      "<div><dt>Net</dt><dd>" + (num(t.net_pips) === null ? DASH : fPips(t.net_pips) + " pips") + "</dd></div></dl></div>";
  }
  function openTrade(id) {
    var t = findTrade(id);
    if (!t) return;
    var fl = flagsOf(t), tg = str(t.tag), would = t.would_take === true ? "1" : t.would_take === false ? "0" : "", mg = str(t.management);
    var ex = EXIT[str(t.close_reason)];
    var html =
      '<div class="oc-prices">' + pbox("Entry", fPx(t.open_price)) + pbox("Stop", fPx(t.initial_sl)) + pbox("Target", fPx(t.initial_tp)) + "</div>" +
      '<div><h3>Result</h3><dl class="facts">' +
      "<div><dt>R</dt><dd class=\"" + cls(t.r_net) + "\">" + fR(t.r_net) + "</dd></div>" +
      (num(t.r_net_info) === null ? "" : "<div><dt>R at 1.6 pips</dt><dd>" + fR(t.r_net_info) + "</dd></div>") +
      "<div><dt>% of balance</dt><dd>" + fPct(t.pct_of_balance) + "</dd></div>" +
      "<div><dt>Money</dt><dd>" + fMoney(t.net_profit, true) + "</dd></div>" +
      (num(t.gross_mid_pips) !== null && num(t.stop_pips)
        ? "<div><dt>Chart move</dt><dd>" + fR(num(t.gross_mid_pips) / num(t.stop_pips)) + " <small>" + fPips(t.gross_mid_pips) + " pips</small></dd></div>"
        : "<div><dt>R before commission and swap</dt><dd>" + fR(t.r_gross) + "</dd></div>") +
      "<div><dt>Stop</dt><dd>" + fPips(t.stop_pips) + " pips</dd></div>" +
      "<div><dt>Exit</dt><dd>" + (ex ? ex[0] : DASH) + " <small>" + fPx(t.close_price) + "</small></dd></div>" +
      "<div><dt>Session</dt><dd>" + esc(SESSION_SHORT[str(t.session)] || DASH) + "</dd></div>" +
      "<div><dt>Closed</dt><dd>" + fWhen(t.close_utc) + "</dd></div></dl></div>" +
      costSplitHTML(t) + linkTradeHTML(t) +
      (fl.length ? '<div><h3>Flags</h3><ul class="flag-list">' + fl.map(function (f) { return "<li><span>" + esc(FLAG[f] || f) + "</span><span></span></li>"; }).join("") + "</ul></div>" : "") +
      '<div><h3>Choice</h3><div class="choice-grid">' +
      '<div><p class="lbl">Tag</p><div class="seg" role="group" aria-label="Tag">' +
      ["planned", "own_idea", "rule_break"].map(function (k) { return '<button type="button" data-tag="' + k + '" aria-pressed="' + (tg === k) + '">' + TAG[k][0] + "</button>"; }).join("") + "</div></div>" +
      '<div><p class="lbl">Would take again</p><div class="seg" role="group" aria-label="Would take again">' +
      '<button type="button" data-would="1" aria-pressed="' + (would === "1") + '">Yes</button><button type="button" data-would="0" aria-pressed="' + (would === "0") + '">No</button></div></div>' +
      '<div><p class="lbl">Exit choice</p><div class="seg" role="group" aria-label="Exit choice">' +
      ["close_at_4r", "trail_to_2r"].map(function (k) { return '<button type="button" data-mgmt="' + k + '" aria-pressed="' + (mg === k) + '">' + esc(mgmtLabel(k)) + "</button>"; }).join("") + "</div></div>" +
      '<div class="field"><label for="noteIn">Note</label><textarea class="in" id="noteIn" maxlength="2000">' + esc(str(t.note)) + "</textarea></div>" +
      '<div class="form-foot"><button class="btn btn-primary" type="button" id="saveChoice" data-id="' + id + '">Save</button><p class="form-msg" id="choiceMsg" role="status" aria-live="polite"></p></div>' +
      "</div></div>";
    openSheet("Trade " + id, pair(t.symbol || "EURUSD") + " " + sideLabel(t.side) + " " + fLots(t.volume) + MID + fWhen(t.open_utc), html);
  }
  function pressed(group) { var b = $('#sheet [' + group + '][aria-pressed="true"]'); return b ? b.getAttribute(group) : null; }
  function toggleIn(btn, attr, allowNone) {
    var on = btn.getAttribute("aria-pressed") === "true";
    $$('#sheet [' + attr + ']').forEach(function (b) { b.setAttribute("aria-pressed", "false"); });
    if (!on || !allowNone) btn.setAttribute("aria-pressed", "true");
  }
  function saveChoice(btn) {
    var id = num(btn.getAttribute("data-id")), msg = $("#choiceMsg");
    var tag = pressed("data-tag"), would = pressed("data-would"), mg = pressed("data-mgmt"), note = $("#noteIn").value;
    if (!tag) { showMsg(msg, "Choose a tag", "bad"); return; }
    btn.disabled = true;
    api("POST", "/api/journal/trades/" + id + "/choice", {
      tag: tag, decision: null, would_take: would === null ? null : would === "1", management: mg, note: note
    }).then(function (t) {
      for (var i = 0; i < state.journal.length; i++) {
        if (num(state.journal[i].id) === id) {
          var cur = state.journal[i];
          state.journal[i] = isObj(t) && num(t.id) === id ? t : cur;
          if (!(isObj(t) && num(t.id) === id)) { cur.tag = tag; cur.would_take = would === null ? null : would === "1"; cur.management = mg; cur.note = note; }
        }
      }
      renderJournal();
      showMsg(msg, "Saved", "good");
    }, function (e) { if (!(e && e.auth)) showMsg(msg, failText(e), "bad"); }).then(function () { btn.disabled = false; });
  }
  function showMsg(el, text, kind) { if (!el) return; el.textContent = text; el.className = "form-msg" + (kind ? " " + kind : ""); }
  function failText(e) {
    if (e && e.network) return "Server unreachable";
    if (e && e.status === 429) return "Too many tries" + MID + "wait a minute";
    return (e && e.message) ? "Not saved" + MID + e.message : "Not saved";
  }

  /* paper log */
  var PSTATUS = { pending: ["Pending", "open"], filled: ["Filled", "running"], closed: ["Closed", "be"], expired: ["Expired", "be"], cancelled: ["Cancelled", "be"] };
  function renderPaper() {
    var panel = $("#paperPanel"), on = state.book === "paper";
    panel.hidden = !on;
    if (!on) return;
    var risk = num(obj(settingsNow().risk).risk_pct_per_trade);
    setText("#paperRisk", risk === null ? "" : "Risk " + fNum(risk, 2) + "%");
    var pg = obj(obj(state.today).paper_guard), pm = GUARD[str(pg.status)], gl = $("#paperGuard");
    gl.textContent = pm ? "Paper day" + MID + pm[0] + (str(pg.reason) ? MID + str(pg.reason) : "") : "";
    gl.className = "form-msg" + (pg.can_open_new === false ? " bad" : "");
    var list = state.paper;
    setText("#paperCount", list.length ? String(list.length) : "");
    morph($("#paperList"), list.length ? list.map(function (o) {
      var id = num(o.id), st = PSTATUS[str(o.status)], acts = "";
      if (id !== null && str(o.status) === "pending") {
        acts = '<button class="btn btn-sm" type="button" data-act="fill" data-id="' + id + '">Fill</button>' +
          '<button class="btn btn-sm btn-quiet" type="button" data-act="cancel" data-id="' + id + '">Cancel</button>' +
          '<button class="btn btn-sm btn-quiet" type="button" data-act="expire" data-id="' + id + '">Expire</button>';
      } else if (id !== null && str(o.status) === "filled") {
        acts = '<button class="btn btn-sm" type="button" data-act="close" data-id="' + id + '">Close</button>';
      }
      var ex = EXIT[str(o.exit_reason)];
      return '<div class="row" data-key="po-' + (id === null ? "x" : id) + '"><div class="row-t">#' + (id === null ? DASH : id) + " " +
        '<span class="pos-side">' + esc(sideLabel(o.side)) + " " + esc(str(o.order_type) || DASH) + " " + fLots(o.lots) + "</span>" +
        (st ? '<span class="pill" data-k="' + st[1] + '">' + st[0] + "</span>" : "") + '</div><div class="row-v">' + fPx(o.entry) + "</div>" +
        '<div class="row-s">Stop ' + fPx(o.stop) + MID + "Target " + fPx(o.target) + MID + "Risk " + (num(o.risk_pct) === null ? DASH : fNum(o.risk_pct, 2) + "%") +
        (o.expiry_utc ? MID + "Expires " + fWhen(o.expiry_utc) : "") +
        (o.fill_price !== null && o.fill_price !== undefined ? MID + "Filled " + fPx(o.fill_price) : "") +
        (o.exit_price !== null && o.exit_price !== undefined ? MID + "Exit " + fPx(o.exit_price) + (ex ? " " + ex[0].toLowerCase() : "") : "") +
        (str(o.note) ? MID + esc(o.note) : "") + "</div>" + (acts ? '<div class="row-a">' + acts + "</div>" : "") + "</div>";
    }).join("") : '<p class="empty-note">No paper orders</p>');
  }
  function readPrice(sel) { var v = $(sel).value.trim().replace(",", "."); return v === "" ? null : num(v); }
  function submitPaper(ev) {
    ev.preventDefault();
    var msg = $("#paperMsg"), side = $("#pSide").value, type = $("#pType").value;
    var entry = readPrice("#pEntry"), stop = readPrice("#pStop"), target = readPrice("#pTarget");
    if (entry === null || stop === null || target === null || entry <= 0 || stop <= 0 || target <= 0) { showMsg(msg, "Entry, stop and target needed", "bad"); return; }
    var ok = side === "buy" ? stop < entry && entry < target : target < entry && entry < stop;
    if (!ok) { showMsg(msg, "Stop or target on the wrong side", "bad"); return; }
    var body = { side: side, order_type: type, entry: entry, stop: stop, target: target, note: $("#pNote").value };
    if ($("#pRuleBreak").checked) body.rule_break = true;
    var exp = $("#pExpiry").value;
    if (exp) {
      var lp = tzParts(nowMs(), LON), hm = exp.split(":");
      body.expiry_utc = toIso(zonedToUtc(lp.y, lp.mo, lp.d, +hm[0], +hm[1], LON));
    }
    var btn = $("#paperForm button[type=submit]");
    btn.disabled = true;
    api("POST", "/api/paper", body).then(function () {
      showMsg(msg, "Saved", "good");
      ["#pEntry", "#pStop", "#pTarget", "#pNote", "#pExpiry"].forEach(function (s) { $(s).value = ""; });
      $("#pRuleBreak").checked = false;
      reloadPaper();
    }, function (e) { if (!(e && e.auth)) showMsg(msg, failText(e), "bad"); }).then(function () { btn.disabled = false; });
  }
  function reloadPaper() {
    if (state.tab === "journal" && state.book === "paper") loadTab("journal");
  }
  function paperAction(act, id) {
    if (act === "cancel" || act === "expire") {
      api("POST", "/api/paper/" + id + "/" + act, {}).then(reloadPaper, function (e) {
        if (!(e && e.auth)) showMsg($("#paperMsg"), failText(e), "bad");
      });
      return;
    }
    var close = act === "close";
    var html = '<form id="paperActForm" data-act="' + act + '" data-id="' + id + '" novalidate>' +
      '<div class="field"><label for="aPrice">' + (close ? "Exit price" : "Fill price") + '</label><input class="in mono" id="aPrice" type="text" inputmode="decimal" autocomplete="off"></div>' +
      (close ? '<div class="field"><label for="aReason">Exit</label><select class="in" id="aReason"><option value="tp">Target</option><option value="sl">Stop</option>' +
        '<option value="be">Breakeven</option><option value="manual">Manual</option></select></div>' : "") +
      (close ? "" : '<label class="check-in"><input type="checkbox" id="aRuleBreak"> Log as a rule break</label>') +
      '<div class="field"><label for="aTime">Time, Melbourne</label><input class="in mono" id="aTime" type="datetime-local" value="' + nowLocalInput(MELB) +
      '" data-default="' + nowLocalInput(MELB) + '"></div>' +
      '<div class="form-foot"><button class="btn btn-primary" type="submit">Save</button><p class="form-msg" id="aMsg" role="status" aria-live="polite"></p></div></form>';
    openSheet("Paper order " + id, (close ? "Close" : "Fill") + MID + "EUR/USD", html);
  }
  function submitPaperAct(form) {
    var act = form.getAttribute("data-act"), id = num(form.getAttribute("data-id")), msg = $("#aMsg");
    var tin = $("#aTime"), price = readPrice("#aPrice");
    /* Time left at its default (now, to the minute): send none and let the server stamp it, since a
       minute-rounded time could fall before the order's own creation second. */
    var typed = tin.value !== tin.getAttribute("data-default"), at = typed ? localInputToIso(tin.value, MELB) : null;
    if (price === null || price <= 0) { showMsg(msg, "Price needed", "bad"); return; }
    if (typed && !at) { showMsg(msg, "Time needed", "bad"); return; }
    var body = act === "close" ? { exit_price: price, reason: $("#aReason").value } : { fill_price: price };
    var rb = $("#aRuleBreak");
    if (rb && rb.checked) body.rule_break = true;
    if (at) body[act === "close" ? "closed_utc" : "filled_utc"] = at;
    api("POST", "/api/paper/" + id + "/" + act, body).then(function () {
      showMsg(msg, "Saved", "good"); closeSheet(); reloadPaper();
    }, function (e) { if (!(e && e.auth)) showMsg(msg, failText(e), "bad"); });
  }

  /* ================= SETUP CHECK (A3) ================= */
  var TIER = { full: "Full risk", half: "Half risk", none: "No trade" };
  function openCheck() {
    var list = objs(obj(state.checks).checks);
    for (var i = 0; i < list.length; i++) if (str(list[i].status) === "open") return list[i];
    return null;
  }
  function testedLine(key) {
    var t = obj(obj(obj(state.checks).tested)[key]);
    return str(t.text) ? '<p class="tested"><span class="lbl">Tested</span> ' + esc(t.text) + "</p>" : "";
  }
  function checkFieldHTML(f, pre) {
    var name = str(f.name), label = str(f.label), kind = str(f.kind), v = pre[name] !== undefined ? pre[name] : f["default"], id = "ck_" + name;
    var tested = f.tested ? testedLine(str(f.tested)) : "";
    if (kind === "bool") return '<label class="check-in"><input type="checkbox" id="' + id + '" data-ck="' + name + '" data-kind="bool"' + (v === true ? " checked" : "") + "> " + esc(label) + "</label>" + tested;
    if (kind === "sel") {
      return '<div class="field"><label for="' + id + '">' + esc(label) + '</label><select class="in" id="' + id + '" data-ck="' + name + '" data-kind="' + (name === "target_r" ? "num" : "sel") + '">' +
        arr(f.options).map(function (o) { return '<option value="' + esc(o[0]) + '"' + (String(v) === o[0] ? " selected" : "") + ">" + esc(o[1]) + "</option>"; }).join("") + "</select></div>" + tested;
    }
    return '<div class="field"><label for="' + id + '">' + esc(label) + '</label><input class="in' + (kind === "text" ? "" : " mono") + '" id="' + id + '" data-ck="' + name + '" data-kind="' + kind +
      '" type="text"' + (kind === "text" ? "" : ' inputmode="decimal"') + ' autocomplete="off" value="' + esc(v === undefined || v === null ? "" : v) + '"></div>' + tested;
  }
  function openCheckForm(pre, ticket, editId) {
    pre = pre || {};
    var html = '<form id="checkForm" data-ticket="' + esc(ticket || "") + '" data-edit="' + esc(editId ? String(editId) : "") + '" novalidate>' +
      objs(obj(state.checks).form).map(function (g) { return "<div><h3>" + esc(str(g.heading)) + "</h3>" + objs(g.fields).map(function (f) { return checkFieldHTML(f, pre); }).join("") + "</div>"; }).join("") +
      testedLine("score") +
      '<div class="form-foot"><button class="btn btn-primary" type="submit">Save check</button><p class="form-msg" id="ckMsg" role="status" aria-live="polite"></p></div></form>';
    openSheet(editId ? "Edit check" : "New check", "EUR/USD" + (ticket ? MID + "order " + ticket : "") + (editId ? MID + "check " + editId : ""), html);
  }
  function readCheckForm(form) {
    var fields = {};
    $$("[data-ck]", form).forEach(function (el) {
      var name = el.getAttribute("data-ck"), kind = el.getAttribute("data-kind");
      if (kind === "bool") { fields[name] = el.checked; return; }
      var v = el.value.trim();
      if (v === "") return;
      fields[name] = kind === "px" || kind === "num" ? num(v.replace(",", ".")) : v;
    });
    return fields;
  }
  function submitCheck(form) {
    var msg = $("#ckMsg"), ticket = form.getAttribute("data-ticket"), editId = form.getAttribute("data-edit");
    api("POST", editId ? "/api/checks/" + editId + "/edit" : "/api/checks", { fields: readCheckForm(form) }).then(function (r) {
      var c = obj(obj(r).check);
      var done = function () {
        showMsg(msg, (TIER[str(c.tier)] || DASH) + MID + "score " + fInt(c.score) + MID + "stop " + fPips(c.stop_pips) + " pips" + MID + "cost " + fR(-num(c.cost_r)), "good");
        reloadChecks();
      };
      if (ticket) api("POST", "/api/checks/" + c.check_id + "/link", { order_ticket: ticket }).then(done, function (e) { if (!(e && e.auth)) showMsg(msg, failText(e), "bad"); });
      else done();
    }, function (e) { if (!(e && e.auth)) showMsg(msg, failText(e), "bad"); });
  }
  function linkOrder(ticket, checkId) {
    api("POST", "/api/checks/" + checkId + "/link", { order_ticket: ticket }).then(reloadChecks, function () { /* shown on next load */ });
  }
  function reloadChecks() {
    get("/api/checks").then(function (d) { state.checks = obj(d); if (state.tab === "today") renderChecks(); if (state.tab === "live") renderLive(); });
  }
  function renderChecks() {
    var list = objs(obj(state.checks).checks).slice(0, 5);
    morph($("#checksList"), list.length ? list.map(function (c) {
      var offers = objs(c.links).filter(function (l) { return l.confirmed === 0 && !l.rejected_utc; });
      var acts = offers.map(function (l) {
        return '<span class="faint">Match: ' + (l.order_ticket ? "order " + esc(str(l.order_ticket)) : "trade " + esc(str(l.position_id))) + "</span>" +
          '<button class="btn btn-sm" type="button" data-link-act="confirm" data-link="' + esc(str(l.id)) + '">Confirm</button>' +
          '<button class="btn btn-sm btn-quiet" type="button" data-link-act="reject" data-link="' + esc(str(l.id)) + '">Not this</button>';
      }).join("") + (str(c.status) === "expired" ? "" : '<button class="btn btn-sm btn-quiet" type="button" data-edit-check="' + esc(str(c.check_id)) + '">Edit</button>');
      return '<div class="row" data-key="chk-' + esc(str(c.check_id)) + '"><div class="row-t">EUR/USD <span class="pos-side">' + esc(sideLabel(c.side)) + "</span></div>" +
        '<div class="row-v">' + esc(TIER[str(c.tier)] || DASH) + '</div><div class="row-s">Score ' + fInt(c.score) + MID + "Entry " + fPx(c.entry) + MID + "Stop " + fPx(c.stop) +
        MID + "Target " + fPx(c.target) + MID + esc(cap(str(c.status).replace("_", " "))) + '</div><div class="row-acts">' + acts + "</div></div>";
    }).join("") : '<p class="empty-note">No checks</p>');
  }
  function findCheck(id) {
    var hit = null;
    objs(obj(state.checks).checks).forEach(function (c) { if (String(c.check_id) === String(id)) hit = c; });
    return hit;
  }
  function linkAction(act, id) {
    api("POST", "/api/checks/links/" + id + (act === "confirm" ? "/confirm" : "/reject"), {}).then(reloadChecks, function () { /* shown on next load */ });
  }
  function editCheck(id) {
    var c = findCheck(id);
    if (!c) return;
    openCheckForm(obj(c.fields), "", id);
  }
  function linkTradeHTML(t) {
    if (str(t.book) === "paper" || !t.id) return "";
    var opts = objs(obj(state.checks).checks).filter(function (c) { return str(c.side) === str(t.side) && str(c.status) !== "expired"; }).slice(0, 3);
    if (!opts.length) return "";
    return '<div><h3>Setup check</h3><div class="row-acts">' + opts.map(function (c) {
      return '<button class="btn btn-sm btn-quiet" type="button" data-link-trade="' + esc(str(t.id)) + '" data-check="' + esc(str(c.check_id)) + '">Link to check ' +
        esc(str(c.check_id)) + MID + "score " + fInt(c.score) + "</button>";
    }).join("") + "</div></div>";
  }
  function linkTrade(tradeId, checkId) {
    api("POST", "/api/checks/" + checkId + "/link", { trade_id: num(tradeId) }).then(function () { closeSheet(); reloadChecks(); }, function () { /* shown on next load */ });
  }
  function orderPrefill(ticket) {
    var o = null;
    objs(obj(state.live).orders).forEach(function (x) { if (str(x.ticket) === ticket) o = x; });
    if (!o) return {};
    var side = str(o.type).indexOf("sell") === 0 ? "sell" : "buy", pre = { side: side, entry: o.price };
    if (num(o.sl) !== null) pre.stop_ref = Math.round((num(o.sl) + (side === "buy" ? 0.00015 : -0.00015)) * 1e5) / 1e5;
    return pre;
  }

  /* ================= CALENDAR ================= */
  function heat(r) { if (r >= 4.5) return "p3"; if (r >= 2) return "p2"; if (r > 0) return "p1"; if (r <= -1.5) return "n2"; if (r < 0) return "n1"; return "z"; }
  function validMonth(m) { return typeof m === "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(m); }
  function shiftMonth(m, k) { var a = m.split("-").map(Number), d = new Date(Date.UTC(a[0], a[1] - 1 + k, 1)); return d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1); }
  function renderCalendar() {
    var d = obj(state.cal), m = validMonth(d.month) ? d.month : state.month;
    if (!validMonth(m)) m = currentMonth();
    var ym = m.split("-").map(Number), y = ym[0], mo = ym[1];
    setText("#calMonth", MON[mo - 1] + " " + y);
    $("#calNext").disabled = m >= currentMonth();
    var byDay = {};
    objs(d.days).forEach(function (c) { if (validDay(c.day)) byDay[c.day] = c; });
    var first = new Date(Date.UTC(y, mo - 1, 1)).getUTCDay(), days = new Date(Date.UTC(y, mo, 0)).getUTCDate(), lead = (first + 6) % 7;
    var todayDay = str(obj(state.today).trading_day);
    if (!validDay(todayDay)) todayDay = melbDate(nowMs());
    var html = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(function (w) { return '<div class="cal-dow">' + w + "</div>"; }).join("");
    for (var b = 0; b < lead; b++) html += '<div class="cell blank" aria-hidden="true"></div>';
    var net = 0, pct = 0, green = 0, red = 0, limit = 0, trades = 0, any = false;
    for (var i = 1; i <= days; i++) {
      var iso = y + "-" + pad(mo) + "-" + pad(i), dow = (lead + i - 1) % 7, c = obj(byDay[iso]);
      var n = num(c.trades) || 0, r = num(c.r), hit = c.hit_loss_limit === true;
      var cl = "cell" + (iso === todayDay ? " today" : "");
      if (!n) {
        if (hit) limit++;
        html += '<div class="' + cl + (dow >= 5 || iso > todayDay ? " wknd" : "") + '" data-key="d-' + iso + '"><div class="cell-top"><span class="cell-day">' + i + "</span></div>" +
          (dow >= 5 || iso > todayDay ? "" : '<div class="cell-n faint">' + DASH + (hit ? ' <span class="limit-mark" title="Loss limit hit"></span>' : "") + "</div>") + "</div>";
        continue;
      }
      any = true; trades += n;
      if (r !== null) { net += r; if (r > 0) green++; else if (r < 0) red++; }
      if (num(c.pct) !== null) pct += num(c.pct);
      if (hit) limit++;
      var label = fDay(iso) + ": " + n + (n === 1 ? " trade, " : " trades, ") + fR(r) + (hit ? ", loss limit hit" : "");
      html += '<button type="button" class="' + cl + '" data-day="' + iso + '" data-key="d-' + iso + '" data-h="' + (r === null ? "z" : heat(r)) + '" aria-label="' + esc(label) + '">' +
        '<div class="cell-top"><span class="cell-day">' + i + "</span></div>" +
        '<div><div class="cell-r ' + cls(r) + '">' + fR(r) + '</div><div class="cell-n"><span class="cnt">' + n + (n === 1 ? " trade" : " trades") + "</span>" +
        (hit ? '<span class="limit-mark" title="Loss limit hit"></span>' : "") + "</div></div></button>";
    }
    morph($("#cal"), html);
    morph($("#calSum"), kv("Month", any ? fR(net) : DASH, cls(net)) + kv("Month %", any ? fPct(pct) : DASH) + kv("Green days", String(green)) +
      kv("Red days", String(red)) + kv("Loss limit hit", String(limit)));
    morph($("#calLegend"), '<span class="scale"><span>' + MINUS + '2R</span><i class="h-n2"></i><i class="h-n1"></i><i class="h-z"></i><i class="h-p1"></i><i class="h-p2"></i><i class="h-p3"></i><span>+5R</span></span>' +
      '<span><span class="limit-mark"></span> Loss limit hit</span><span>' + trades + (trades === 1 ? " trade" : " trades") + "</span>");
  }
  function openDay(day) {
    var c = {};
    objs(obj(state.cal).days).forEach(function (x) { if (x.day === day) c = x; });
    openSheet(fDay(day), (state.book === "paper" ? "Paper" : "MT5") + MID + "trading day", '<p class="empty-note">' + DASH + "</p>");
    get("/api/journal?book=" + state.book + "&from=" + day + "&to=" + day).then(function (d) {
      var list = objs(obj(d).trades).filter(function (t) { return (!t.symbol || isEur(t)) && (str(t.close_trading_day) === day || (!t.close_trading_day && str(t.trading_day) === day)); });
      var r = sumOf(list.filter(isClosed), "r_net");
      var html = '<div class="leak-big"><div><div class="v ' + cls(r) + '">' + fR(r) + '</div><div class="l">Day R</div></div><div><div class="v">' + list.length +
        '</div><div class="l">' + (list.length === 1 ? "Trade" : "Trades") + "</div></div></div>" +
        (c.hit_loss_limit === true ? '<p class="neg-c">Loss limit hit</p>' : "") +
        '<div><h3>Trades</h3><div class="trade-list">' + (list.length ? list.map(function (t) {
          var tg = TAG[str(t.tag)], ex = EXIT[str(t.close_reason)];
          return '<div class="trade-row"><div class="a">EUR/USD ' + esc(sideLabel(t.side).toLowerCase()) + " " + fLots(t.volume) + '</div><div class="mono ' + cls(t.r_net) + '">' + fR(t.r_net) +
            '</div><div class="b"><span>' + fPct(t.pct_of_balance) + "</span><span>" + fMoney(t.net_profit, true) + "</span><span>" + (ex ? ex[0] : DASH) + "</span>" +
            (tg ? '<span class="pill" data-k="' + tg[1] + '">' + tg[0] + "</span>" : "") +
            flagsOf(t).map(function (f) { return '<span class="warn-c">' + esc(FLAG[f] || f) + "</span>"; }).join("") + "</div></div>";
        }).join("") : '<p class="empty-note">No trades</p>') + "</div></div>";
      if (!$("#sheet").hidden && $("#sheetTitle").textContent === fDay(day)) { $("#sheetBody").innerHTML = html; }
    }, function () { /* login view already shown */ });
  }

  /* ================= EDGE LAB ================= */
  function minTrades() { return num(obj(state.edge).min_trades); }
  function nTag(s) {
    s = obj(s);
    var n = num(s.n), label = str(s.label), min = minTrades();
    if (!label && n !== null && min !== null && n < min) label = "too early";
    if (n === null) return '<span class="nn">n=' + DASH + "</span>";
    return label ? '<span class="few">n=' + fInt(n) + MID + esc(label) + "</span>" : '<span class="nn">n=' + fInt(n) + "</span>";
  }
  function renderEdge() {
    var d = obj(state.edge), s = obj(d.summary), min = minTrades();
    setText("#eqNote", num(s.n) === null ? "" : "n=" + fInt(s.n) + (str(s.label) ? MID + str(s.label) : "") + (min === null ? "" : MID + "min " + fInt(min)));
    safe(function () {
      var dd = num(s.max_drawdown_r), ddp = num(s.max_drawdown_pct), est = num(s.max_drawdown_r_est);
      var ddSub = (ddp === null ? "" : fPct(ddp ? -ddp : 0) + MID) +
        (num(s.unknown_r) && est !== null && dd !== null && est > dd + 1e-9 ? "no stop incl. " + fR(-est, 1) + MID : "");
      morph($("#kpis"),
        '<div><div class="fig-label">Expectancy</div><div class="fig-value ' + cls(s.expectancy_r) + '">' + fR(s.expectancy_r) + '</div><div class="fig-sub">profit factor ' + fNum(s.profit_factor) + MID + nTag(s) + "</div></div>" +
        '<div><div class="fig-label">Win rate</div><div class="fig-value">' + fRate(s.win_rate) + '</div><div class="fig-sub">break-even ' + fRate(s.breakeven_win_rate) + MID + nTag(s) + "</div></div>" +
        '<div><div class="fig-label">Total</div><div class="fig-value ' + cls(s.total_r) + '">' + fR(s.total_r) + '</div><div class="fig-sub">' + fPct(s.total_pct) + MID + nTag(s) + "</div></div>" +
        '<div><div class="fig-label">Max drawdown</div><div class="fig-value ' + (dd ? "neg-c" : "") + '">' + (dd === null ? DASH : fR(-dd)) + '</div><div class="fig-sub">' + ddSub + nTag(s) + "</div></div>");
    });
    safe(function () { drawEquity(d); });
    safe(function () { drawGauge(s); });
    safe(function () { renderLeak(obj(d.leak)); });
    safe(function () { morph($("#bySession"), drows(d.by_session, ["asia", "london", "new_york"], function (k) { return SESSION_SHORT[k] || cap(k); })); });
    safe(function () { morph($("#byStop"), drows(d.by_stop, ["<5", "5-10", "10-15", "15+"], function (k) { return STOP_LABEL[k] || k; })); });
    safe(function () { morph($("#byWeekday"), drows(d.by_weekday, ["Mon", "Tue", "Wed", "Thu", "Fri"], function (k) { return k; })); });
    safe(function () { morph($("#byMgmt"), drows(d.by_management, ["close_at_4r", "trail_to_2r"], mgmtLabel, true)); });
    safe(function () {
      var rows = objs(d.by_symbol), groups = {}, order = [], labels = {};
      rows.forEach(function (r) { var k = str(r.symbol); groups[k] = obj(r.summary); order.push(k); labels[k] = str(r.label) || k; });
      morph($("#bySymbol"), drows(groups, order, function (k) { return labels[k] || k; }, true));
    });
    safe(function () { renderCostRows(objs(d.month_costs)); });
    safe(function () { renderHandCheck(obj(d.hand_check)); });
  }
  var STOP_LABEL = { "<5": "Under 5 pips", "5-10": "5" + NDASH + "10 pips", "10-15": "10" + NDASH + "15 pips", "15+": "15+ pips", unknown: "No stop" };
  function renderCostRows(rows) {
    setText("#costNote", rows.length ? fInt(rows.reduce(function (a, r) { return a + (num(r.trades) || 0); }, 0)) + " trades" : "");
    if (!rows.length) { morph($("#costRows"), '<p class="empty-note">No closed trades</p>'); return; }
    var head = "<tr><th>Month</th><th class=\"num\">Trades</th><th class=\"num\">Chart move</th><th class=\"num\">Spread</th>" +
      "<th class=\"num\">Commission</th><th class=\"num\">Swap</th><th class=\"num\">Net</th><th class=\"num\">Net pips</th>" +
      "<th class=\"num\">Cost a trade</th><th class=\"num\">Account charges</th></tr>";
    var body = rows.slice().reverse().map(function (r) {
      return "<tr><td>" + esc(str(r.month)) + '</td><td class="num">' + fInt(r.trades) + '</td><td class="num">' + (num(r.chart_known) ? fR(r.chart_r) : DASH) +
        '</td><td class="num">' + (num(r.chart_known) ? fR(r.spread_r) : DASH) + " <small>" + fInt(r.spread_known) + " of " + fInt(r.trades) + "</small>" + '</td><td class="num">' + fR(r.commission_r) + '</td><td class="num">' + fR(r.swap_r) +
        '</td><td class="num ' + cls(r.net_r) + '">' + fR(r.net_r) + '</td><td class="num">' + fPips(r.net_pips) + '</td><td class="num">' + fR(r.cost_per_trade_r) +
        '</td><td class="num">' + fMoney(r.other_charges, true) + "</td></tr>";
    }).join("");
    morph($("#costRows"), '<div class="tbl-wrap"><table class="tbl">' + head + body + "</table></div>");
  }
  function drows(groups, order, label, only) {
    groups = obj(groups);
    var keys = order.slice();
    if (!only) Object.keys(groups).forEach(function (k) { if (keys.indexOf(k) < 0) keys.push(k); });
    var rows = keys.map(function (k) { return [k, obj(groups[k])]; });
    var mx = 0.5;
    rows.forEach(function (r) { var e = num(r[1].expectancy_r); if (e !== null) mx = Math.max(mx, Math.abs(e)); });
    return rows.map(function (r) {
      var e = num(r[1].expectancy_r), w = e === null ? 0 : Math.abs(e) / mx * 50;
      return '<div class="drow" data-key="dr-' + esc(r[0]) + '"><span class="lb">' + esc(label(r[0])) + '</span><div class="dtrack"><span class="dbar ' + (e !== null && e < 0 ? "n" : "p") +
        '" data-gw="' + geomNum(w) + '"></span></div><span class="vl ' + cls(e) + '">' + fR(e) + " <small>" + nTag(r[1]) + "</small></span></div>";
    }).join("");
  }
  function renderLeak(L) {
    var clean = obj(L.clean), broke = obj(L.rule_break), tags = obj(L.by_tag), flags = obj(L.by_flag);
    setText("#leakNote", "");
    var maxAbs = 1;
    ["planned", "own_idea", "rule_break", "untagged"].forEach(function (k) { var v = num(obj(tags[k]).total_r); if (v !== null) maxAbs = Math.max(maxAbs, Math.abs(v)); });
    function row(k, name, pk) {
      var g = obj(tags[k]), tot = num(g.total_r), w = tot === null ? 0 : Math.abs(tot) / maxAbs * 50;
      return '<tr data-key="lk-' + k + '"><td><span class="pill" data-k="' + pk + '">' + name + '</span></td><td class="num">' + fInt(g.n) + '</td><td class="num wide">' + fRate(g.win_rate) +
        '</td><td class="num ' + cls(g.expectancy_r) + '">' + fR(g.expectancy_r) + '</td><td class="num ' + cls(tot) + '">' + fR(tot) + "</td>" +
        '<td class="wide"><div class="dtrack"><span class="dbar ' + (tot !== null && tot < 0 ? "n" : "p") + '" data-gw="' + geomNum(w) + '"></span></div></td><td class="wide">' + nTag(g) + "</td></tr>";
    }
    var flagKeys = Object.keys(flags);
    morph($("#leak"),
      '<div class="leak-big"><div><div class="v ' + cls(L.cost_r) + '">' + fR(L.cost_r) + '</div><div class="l">Rule breaks cost' + MID + nTag(broke) + "</div></div>" +
      '<div><div class="v ' + cls(clean.expectancy_r) + '">' + fR(clean.expectancy_r) + '</div><div class="l">Clean, per trade' + MID + nTag(clean) + "</div></div>" +
      '<div><div class="v ' + cls(L.without_breaks_total_r) + '">' + fR(L.without_breaks_total_r) + '</div><div class="l">Total without breaks' + MID + nTag(clean) + "</div></div></div>" +
      '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Group</th><th class="num">Trades</th><th class="num wide">Win rate</th><th class="num">Avg R</th><th class="num">Total</th><th class="wide"></th><th class="wide"></th></tr></thead><tbody>' +
      row("planned", "Planned", "planned") + row("own_idea", "Own idea", "own") + row("rule_break", "Rule break", "break") + row("untagged", "Untagged", "be") + "</tbody></table></div>" +
      (flagKeys.length ? '<ul class="flag-list">' + flagKeys.map(function (f) {
        var g = obj(flags[f]);
        return '<li data-key="fl-' + esc(f) + '"><span>' + esc(FLAG[f] || f) + " " + nTag(g) + '</span><span class="' + cls(g.total_r) + '">' + fR(g.total_r) + "</span></li>";
      }).join("") + "</ul>" : ""));
  }
  function drawEquity(d) {
    var box = $("#eqChart");
    var pts = objs(d.equity).map(function (p) { return { c: num(p.cum_r), r: num(p.r), t: parseIso(p.t), id: num(p.trade_id) }; }).filter(function (p) { return p.c !== null; });
    if (!pts.length) { box.innerHTML = '<p class="empty-note">No closed trades</p>'; return; }
    var Wd = Math.max(280, box.clientWidth || 640), H = 262, ddH = 64, padL = 34, padR = 12, padT = 14, gap = 26, padB = 22;
    var mainH = H - padT - gap - ddH - padB, n = pts.length;
    var peak = 0, cs = pts.map(function (p) { return p.c; });
    pts.forEach(function (p) { peak = Math.max(peak, p.c); p.dd = p.c - peak; });
    var maxC = Math.max.apply(null, cs.concat([0])), minC = Math.min.apply(null, cs.concat([0]));
    var step = maxC - minC > 24 ? 10 : maxC - minC > 12 ? 5 : maxC - minC > 4 ? 2 : 1;
    var top = Math.ceil(maxC / step) * step, bot = Math.floor(minC / step) * step;
    if (top === bot) top = bot + step;
    var minDD = Math.min.apply(null, pts.map(function (p) { return p.dd; }).concat([0])), ddBot = Math.floor(minDD) - 1;
    function X(i) { return padL + i * (Wd - padL - padR) / n; }
    function Y(v) { return padT + (top - v) / (top - bot) * mainH; }
    var ddTop = padT + mainH + gap;
    function YD(v) { return ddTop + (v / ddBot) * ddH; }
    var s = '<svg viewBox="0 0 ' + Wd + " " + H + '" width="' + Wd + '" height="' + H + '" role="img" aria-label="Equity in R over ' + n + " trades, ending at " + fR(pts[n - 1].c) + '">';
    for (var v = bot; v <= top + 1e-9; v += step) {
      s += '<line class="' + (v === 0 ? "zl" : "gl") + '" x1="' + padL + '" x2="' + (Wd - padR) + '" y1="' + Y(v).toFixed(1) + '" y2="' + Y(v).toFixed(1) + '"/>' +
        '<text class="al" x="' + (padL - 6) + '" y="' + (Y(v) + 3.5).toFixed(1) + '" text-anchor="end">' + (v > 0 ? "+" : v < 0 ? MINUS : "") + Math.abs(v) + "</text>";
    }
    var line = "M" + X(0).toFixed(1) + " " + Y(0).toFixed(1);
    pts.forEach(function (p, i) { line += " L" + X(i + 1).toFixed(1) + " " + Y(p.c).toFixed(1); });
    var area = line + " L" + X(n).toFixed(1) + " " + Y(0).toFixed(1) + " Z";
    s += '<path class="eq-area" id="eqArea" d="' + area + '"/><path class="eq-line" id="eqLine" d="' + line + '"/>';
    s += '<circle class="end-dot" cx="' + X(n).toFixed(1) + '" cy="' + Y(pts[n - 1].c).toFixed(1) + '" r="4"/>';
    s += '<text class="al al-end" x="' + (X(n) - 6).toFixed(1) + '" y="' + (Y(pts[n - 1].c) - 10).toFixed(1) + '" text-anchor="end">' + fR(pts[n - 1].c) + "</text>";
    var dd = "M" + X(0).toFixed(1) + " " + YD(0).toFixed(1);
    pts.forEach(function (p, i) { dd += " L" + X(i + 1).toFixed(1) + " " + YD(p.dd).toFixed(1); });
    s += '<line class="zl" x1="' + padL + '" x2="' + (Wd - padR) + '" y1="' + YD(0).toFixed(1) + '" y2="' + YD(0).toFixed(1) + '"/>';
    s += '<path class="dd-area" d="' + dd + " L" + X(n).toFixed(1) + " " + YD(0).toFixed(1) + ' Z"/><path class="dd-line" d="' + dd + '"/>';
    s += '<text class="al" x="' + (padL - 6) + '" y="' + (YD(ddBot) + 3.5).toFixed(1) + '" text-anchor="end">' + MINUS + Math.abs(ddBot) + "</text>";
    s += '<text class="al" x="' + (padL + 4) + '" y="' + (ddTop - 6).toFixed(1) + '">Drawdown, R</text>';
    if (pts[0].t !== null) s += '<text class="al" x="' + padL + '" y="' + (H - 4) + '">' + esc(fWhen(toIso(pts[0].t)).split(" ").slice(0, 3).join(" ")) + "</text>";
    if (pts[n - 1].t !== null && n > 1) s += '<text class="al" x="' + (Wd - padR) + '" y="' + (H - 4) + '" text-anchor="end">' + esc(fWhen(toIso(pts[n - 1].t)).split(" ").slice(0, 3).join(" ")) + "</text>";
    s += '<line class="xh" id="eqXh" x1="0" x2="0" y1="' + padT + '" y2="' + (ddTop + ddH) + '"/><circle class="xh-dot" id="eqXd" r="4" cx="0" cy="0"/>';
    s += '<rect x="' + padL + '" y="0" width="' + (Wd - padL - padR) + '" height="' + H + '" fill="transparent" id="eqHit"/></svg><div class="tip" id="eqTip"></div>';
    box.innerHTML = s;
    var hit = $("#eqHit"), tip = $("#eqTip"), xh = $("#eqXh"), xd = $("#eqXd");
    function show(ev) {
      var rc = box.getBoundingClientRect(), x = (ev.clientX - rc.left) * (Wd / (rc.width || Wd));
      var i = clamp(Math.round((x - padL) / (Wd - padL - padR) * n), 1, n), p = pts[i - 1];
      xh.setAttribute("x1", X(i)); xh.setAttribute("x2", X(i));
      xd.setAttribute("cx", X(i)); xd.setAttribute("cy", Y(p.c));
      tip.innerHTML = '<div class="faint">#' + i + (p.t !== null ? MID + esc(fWhen(toIso(p.t))) : "") + '</div><div>Trade <b class="' + cls(p.r) + '">' + fR(p.r) + "</b></div><div>Total <b>" + fR(p.c) + "</b></div>";
      var scale = (rc.width || Wd) / Wd, tx = X(i) * scale + 12;
      if (tx > (rc.width || Wd) - 170) tx = X(i) * scale - 170;
      tip.style.left = Math.max(0, tx) + "px"; tip.style.top = Math.max(0, Y(p.c) * scale - 30) + "px";
      box.classList.add("hover");
    }
    function hide() { box.classList.remove("hover"); }
    hit.addEventListener("pointermove", show); hit.addEventListener("pointerdown", show); hit.addEventListener("pointerleave", hide);
    if (!state.edgeDrawn) {
      state.edgeDrawn = true;
      if (!reduced()) {
        var ln = $("#eqLine"), ar = $("#eqArea"), L = ln.getTotalLength ? ln.getTotalLength() : 0;
        if (L > 0) {
          ln.style.strokeDasharray = L + " " + L; ln.style.strokeDashoffset = String(L); ar.style.opacity = "0";
          ln.getBoundingClientRect();
          ln.style.transition = "stroke-dashoffset var(--d-chart) var(--ease-out)";
          ar.style.transition = "opacity var(--d-chart) var(--ease-out)";
          requestAnimationFrame(function () { ln.style.strokeDashoffset = "0"; ar.style.opacity = "1"; });
          setTimeout(function () {
            ln.style.strokeDasharray = ""; ln.style.strokeDashoffset = ""; ln.style.transition = "";
            ar.style.transition = ""; ar.style.opacity = "";
          }, 760);
        }
      }
    }
  }
  function drawGauge(s) {
    var wr = num(s.win_rate), be = num(s.breakeven_win_rate), box = $("#gauge");
    setText("#gaugeNote", "");
    var wp = wr === null ? null : wr * 100, bp = be === null ? null : be * 100;
    var max = Math.max(60, Math.ceil(Math.max(wp || 0, bp || 0) / 10) * 10);
    max = Math.min(max, 100);
    var cx = 120, cy = 134, r = 92;
    function pt(p, rr) { var a = Math.PI * (1 - clamp(p, 0, max) / max); return [cx + rr * Math.cos(a), cy - rr * Math.sin(a)]; }
    function arc(p0, p1) { var a = pt(p0, r), b = pt(p1, r); return "M" + a[0].toFixed(2) + " " + a[1].toFixed(2) + " A" + r + " " + r + " 0 0 1 " + b[0].toFixed(2) + " " + b[1].toFixed(2); }
    var svg = '<svg class="gauge" viewBox="0 0 240 166" role="img" aria-label="Win rate ' + fRate(wr) + ", break-even " + fRate(be) + '">' +
      '<path class="g-track" d="' + arc(0, max) + '"/>' + (wp !== null && wp > 0 ? '<path class="g-fill" d="' + arc(0, wp) + '"/>' : "");
    if (bp !== null) {
      var b1 = pt(bp, r - 12), b2 = pt(bp, r + 12), bt = pt(bp, r + 24);
      svg += '<line class="g-be" x1="' + b1[0].toFixed(1) + '" y1="' + b1[1].toFixed(1) + '" x2="' + b2[0].toFixed(1) + '" y2="' + b2[1].toFixed(1) + '"/>' +
        '<text class="g-be-t" x="' + bt[0].toFixed(1) + '" y="' + (bt[1] + 2).toFixed(1) + '" text-anchor="middle">break-even ' + fRate(be) + "</text>";
    }
    var n = num(s.n), label = str(s.label);
    svg += '<text class="g-big" x="' + cx + '" y="' + (cy - 12) + '" text-anchor="middle">' + fRate(wr) + "</text>" +
      '<text class="g-sm" x="' + cx + '" y="' + (cy + 6) + '" text-anchor="middle">n=' + fInt(n) + (label ? MID + esc(label) : "") + "</text>" +
      '<text class="g-sm" x="' + (cx - r) + '" y="' + (cy + 18) + '" text-anchor="middle">0%</text><text class="g-sm" x="' + (cx + r) + '" y="' + (cy + 18) + '" text-anchor="middle">' + max + "%</text></svg>";
    box.innerHTML = svg;
  }

  /* ================= RULES ================= */
  function renderRules() {
    var d = obj(state.rules), a = obj(d.adherence), rv = obj(d.review);
    safe(function () {
      var n = num(a.n), clean = num(a.clean), p = n !== null && clean !== null && n > 0 ? clean / n * 100 : num(a.pct);
      var label = str(a.label);
      setText("#adhNote", "");
      morph($("#adhBody"), '<div class="big-pct">' + (p === null ? DASH : Math.round(p) + "%") + '</div><p class="reason">' +
        (n === null || clean === null ? DASH : fInt(clean) + " of " + fInt(n) + " clean") + (label ? MID + '<span class="few">' + esc(label) + "</span>" : "") + "</p>");
    });
    safe(function () {
      var week = str(rv.week) || isoWeek(melbDate(nowMs()));
      setText("#actionWeek", week);
      $("#actionForm").setAttribute("data-week", week);
      var input = $("#actionIn");
      if (doc.activeElement !== input && !input.getAttribute("data-dirty")) input.value = str(rv.action_item);
    });
    safe(function () {
      var rules = objs(d.rules);
      setText("#rulesNote", rules.length ? String(rules.length) : "");
      morph($("#rulesList"), rules.length ? rules.map(function (r, i) {
        var lim = r.limit === true ? "Yes" : r.limit === false ? "No" : ruleLimit(str(r.id), r.limit);
        return '<div class="rule" data-key="rl-' + esc(str(r.id) || String(i)) + '"><span class="ck">' + (i + 1) + '</span><div class="rule-t">' + esc(str(r.label) || DASH) +
          '</div><div class="rule-lim">' + esc(lim) + "</div></div>";
      }).join("") : '<p class="empty-note">' + DASH + "</p>");
    });
  }
  /* A number from config shown with its unit: risk in %, management levels in R. */
  function ruleLimit(id, v) {
    var n = num(v);
    if (typeof v === "number" && n !== null) {
      if (id === "risk_pct") return fNum(n, 2) + "%";
      if (id === "breakeven" || id === "take_or_trail") return "+" + String(fixed(n, 2)) + "R";
    }
    return str(v) || DASH;
  }
  function submitAction(ev) {
    ev.preventDefault();
    var form = $("#actionForm"), input = $("#actionIn"), msg = $("#actionMsg");
    var week = form.getAttribute("data-week") || isoWeek(melbDate(nowMs()));
    var btn = $("#saveAction");
    btn.disabled = true;
    api("POST", "/api/rules/review", { week: week, action_item: input.value.trim() }).then(function () {
      input.removeAttribute("data-dirty");
      showMsg(msg, "Saved", "good");
    }, function (e) { if (!(e && e.auth)) showMsg(msg, failText(e), "bad"); }).then(function () { btn.disabled = false; });
  }

  /* ================= SETTINGS ================= */
  function kvl(rows) { return rows.map(function (r) { return "<div><dt>" + esc(r[0]) + "</dt><dd>" + r[1] + "</dd></div>"; }).join(""); }
  function renderSettings() {
    var d = obj(state.settings), risk = obj(d.risk), st = obj(d.streak), mg = obj(d.management), br = obj(d.bridge), sec = obj(d.secrets);
    var ins = isObj(d.instrument) ? str(d.instrument.symbol) : str(d.instrument);
    if (str(d.currency)) state.currency = str(d.currency);
    safe(function () {
      morph($("#setAccount"), kvl([["Alias", esc(str(d.account_alias) || DASH)], ["Instrument", esc(ins ? pair(ins) : DASH)],
        ["Currency", esc(str(d.currency) || DASH)],
        ["Risk per trade", num(risk.risk_pct_per_trade) === null ? DASH : fNum(risk.risk_pct_per_trade, 2) + "%"], ["Mode", "Paper"]]));
    });
    safe(function () {
      var fr = num(st.floor_fraction), tmin = num(st.target_min_r), tmax = num(st.target_max_r);
      var bef = num(mg.breakeven_from_r), bet = num(mg.breakeven_to_r);
      morph($("#setLimits"), kvl([
        ["Max losses a day", fInt(risk.max_losses_per_day)], ["Trades after a win", fInt(risk.trades_after_first_win)],
        ["Loss after a win ends the day", yesNo(risk.loss_after_win_ends_day)],
        ["Breakeven band", num(risk.breakeven_band_r) === null ? DASH : "±" + fNum(risk.breakeven_band_r, 2) + "R"],
        ["Streak mode", yesNo(st.enabled)], ["Green days to start", fInt(st.green_days_to_start)],
        ["Streak targets", tmin === null || tmax === null ? DASH : fNum(tmin, 1) + NDASH + fNum(tmax, 1) + "R"],
        ["Streak floor", fr === null ? DASH : Math.round(fr * 100) + "% of peak"],
        ["Stop to entry", bef === null || bet === null ? DASH : "+" + fNum(bef, 1) + NDASH + "+" + fNum(bet, 1) + "R"],
        ["Close or trail at", num(mg.take_or_trail_r) === null ? DASH : "+" + fNum(mg.take_or_trail_r, 1) + "R"],
        ["Trail stop to", num(mg.trail_stop_r) === null ? DASH : "+" + fNum(mg.trail_stop_r, 1) + "R"]]));
    });
    safe(function () {
      var bstate = str(br.state) || str(bridgeOf().state);
      morph($("#setBridge"), kvl([["Contract", esc(str(br.contract) || DASH)], ["URL path", esc(str(br.url_path) || DASH)],
        ["State", esc(BRIDGE_WORD[bstate] || DASH)], ["Stale after", num(br.stale_after_s) === null ? DASH : fInt(br.stale_after_s) + " s"],
        ["Offline after", num(br.offline_after_s) === null ? DASH : fInt(br.offline_after_s) + " s"]]));
    });
    safe(function () {
      var b = obj(d.broker);
      morph($("#setBroker"), kvl([["Digits", fInt(b.digits)], ["Point", fNum(b.point, 5)], ["Tick size", fNum(b.tick_size, 5)],
        ["Tick value", fNum(b.tick_value, 2)], ["Contract size", fInt(b.contract_size)], ["Min lot", fNum(b.volume_min, 2)],
        ["Lot step", fNum(b.volume_step, 2)], ["Max lot", fNum(b.volume_max, 2)], ["Stops level", num(b.stops_level) === null ? DASH : fInt(b.stops_level) + " points"],
        ["Spread", num(b.spread) === null ? DASH : fInt(b.spread) + " points"], ["Bid", fPx(b.bid)], ["Ask", fPx(b.ask)]]));
    });
    safe(function () {
      morph($("#setSecrets"), kvl([["Ingest token", yesNo(sec.ingest_token)], ["Dashboard token", yesNo(sec.dashboard_token)], ["Push key", yesNo(sec.vapid_private_key)]]));
    });
    safe(function () {
      var p = obj(d.push);
      push.devices = num(p.devices);
      if (push.configured === null && typeof p.configured === "boolean") push.configured = p.configured;
      renderPush();
      refreshPhone();
    });
    paintThemeUI();
  }

  /* ================= PHONE ALERTS (Web Push) ================= */
  /* The server holds the private push key; the browser gets the public key from GET /api/push/key, subscribes
     through its own push service and the subscription is saved with POST /api/push/subscribe. The service
     worker (/sw.js) shows each alert. Permission is asked only inside the Turn on tap (iPhone needs that). */
  var PUSH_ON = "Turn on alerts on this phone", PUSH_TEST = "Send test alert", PUSH_OFF = "Turn off on this phone";
  var NO_PUSH = "Server push not set up";
  var push = { key: null, configured: null, devices: null, phone: null, busy: false };
  function swAllowed() { return "serviceWorker" in navigator && window.isSecureContext === true; }
  function keyBytes(b64) {
    try {
      var s = str(b64).replace(/-/g, "+").replace(/_/g, "/");
      while (s.length % 4) s += "=";
      var bin = window.atob(s), out = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
      return out.length === 65 && out[0] === 4 ? out : null;   /* uncompressed P-256 point */
    } catch (e) { return null; }
  }
  function loadPushKey() {
    return api("GET", "/api/push/key").then(function (d) {
      var k = d.configured === true ? keyBytes(d.public_key) : null;
      push.configured = !!k; push.key = k;
    });
  }
  function isIPhone() {
    var ua = navigator.userAgent || "";
    return /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  }
  function homeScreenApp() {
    return navigator.standalone === true || !!(window.matchMedia && window.matchMedia("(display-mode: standalone)").matches);
  }
  /* Why push cannot work in this browser, or "" when it can. */
  function pushBlocker() {
    if (window.isSecureContext !== true) return "Needs HTTPS";
    if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) {
      return isIPhone() && !homeScreenApp() ? "Add to Home Screen first" : "Not supported in this browser";
    }
    return "";
  }
  function swRegistration() {
    return navigator.serviceWorker.getRegistration("/").then(function (r) {
      return r || navigator.serviceWorker.register("/sw.js", { scope: "/" });
    }).then(function () { return navigator.serviceWorker.ready; });
  }
  /* This browser's own subscription (or null); never waits for a service worker that is not there. */
  function phoneSub() {
    if (pushBlocker()) return Promise.resolve(null);
    return navigator.serviceWorker.getRegistration("/").then(function (r) {
      return r && r.pushManager ? r.pushManager.getSubscription() : null;
    });
  }
  function sameKey(sub, key) {
    var k = sub && sub.options && sub.options.applicationServerKey;
    if (!k) return true;
    var a = new Uint8Array(k);
    if (a.length !== key.length) return false;
    for (var i = 0; i < a.length; i++) if (a[i] !== key[i]) return false;
    return true;
  }
  function renderPush() {
    var on = push.phone === true ? "On" : push.phone === false ? "Off" : DASH;
    morph($("#setPush"), kvl([["Server push", yesNo(push.configured)], ["Devices", fInt(push.devices)], ["This phone", on]]));
    var dis = push.busy ? " disabled" : "";
    morph($("#pushBtns"), '<button class="btn btn-primary" type="button" id="pushOn"' + dis + ">" + esc(PUSH_ON) + "</button>" +
      '<button class="btn" type="button" id="pushTest"' + dis + ">" + esc(PUSH_TEST) + "</button>" +
      '<button class="btn" type="button" id="pushOff"' + dis + ">" + esc(PUSH_OFF) + "</button>");
  }
  function refreshPhone() {
    phoneSub().then(function (sub) {
      push.phone = !!sub && Notification.permission === "granted"; renderPush();
    }, function () { push.phone = null; renderPush(); });
  }
  function pushBusy(b) { push.busy = b; renderPush(); }
  function pushDevices(d) { var n = num(obj(d).devices); if (n !== null) push.devices = n; }
  function pushFail(e) {
    if (e && e.label) return e.label;
    if (e && e.status === 503) return NO_PUSH;
    if (e && e.name === "NotAllowedError") return "Notifications blocked";
    if (e && (e.name === "AbortError" || e.name === "InvalidStateError" || e.name === "NotSupportedError")) return "Phone push service refused";
    return failText(e);
  }
  function labelled(text) { var e = new Error(text); e.label = text; return e; }
  function turnOnPush() {
    var msg = $("#pushMsg");
    if (push.busy) return;
    var why = pushBlocker();
    if (why) { showMsg(msg, why, "bad"); return; }
    if (push.configured === false) { showMsg(msg, NO_PUSH, "bad"); return; }
    showMsg(msg, "");
    pushBusy(true);
    function ask() {
      var key = push.key, asked;
      try { asked = Notification.requestPermission(); } catch (e) { asked = null; }
      return Promise.resolve(asked).then(function (p) {
        p = p || Notification.permission;
        if (p !== "granted") throw labelled(p === "denied" ? "Notifications blocked" : "Not allowed");
        return swRegistration();
      }).then(function (reg) {
        return reg.pushManager.getSubscription().then(function (old) {
          if (old && !sameKey(old, key)) return old.unsubscribe().then(function () { return null; });
          return old;
        }).then(function (old) {
          return old || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key });
        });
      }).then(function (sub) {
        return api("POST", "/api/push/subscribe", sub.toJSON(), { keep503: true });
      }).then(function (d) {
        push.phone = true; pushDevices(d);
        showMsg(msg, "Alerts on", "good");
      });
    }
    /* The key is loaded with the Settings screen, so the permission prompt normally opens straight from the tap. */
    var run = push.key ? ask() : loadPushKey().then(function () {
      if (!push.key) throw labelled(NO_PUSH);
      return ask();
    });
    run.catch(function (e) { if (!(e && e.auth)) showMsg(msg, pushFail(e), "bad"); }).then(function () { pushBusy(false); });
  }
  function testPush() {
    var msg = $("#pushMsg");
    if (push.busy) return;
    showMsg(msg, "");
    pushBusy(true);
    api("POST", "/api/push/test", {}, { keep503: true }).then(function (d) {
      pushDevices(d);
      if (d.sent === true) showMsg(msg, "Test sent", "good");
      else showMsg(msg, push.devices === 0 ? "No devices" : "Not sent", "bad");
    }, function (e) { if (!(e && e.auth)) showMsg(msg, pushFail(e), "bad"); }).then(function () { pushBusy(false); });
  }
  function turnOffPush() {
    var msg = $("#pushMsg");
    if (push.busy) return;
    var why = pushBlocker();
    if (why) { showMsg(msg, why, "bad"); return; }
    showMsg(msg, "");
    pushBusy(true);
    phoneSub().then(function (sub) {
      if (!sub) return null;
      var endpoint = sub.endpoint;
      return sub.unsubscribe().catch(function () { return false; }).then(function () {
        return api("POST", "/api/push/unsubscribe", { endpoint: endpoint }, { keep503: true });
      });
    }).then(function (d) {
      push.phone = false; if (d) pushDevices(d);
      showMsg(msg, "Alerts off", "good");
    }, function (e) { if (!(e && e.auth)) showMsg(msg, pushFail(e), "bad"); }).then(function () { pushBusy(false); });
  }

  /* ================= SHEET ================= */
  var lastFocus = null, sheetTimer = 0;
  function openSheet(title, sub, html) {
    lastFocus = doc.activeElement;
    clearTimeout(sheetTimer);
    $("#sheetTitle").textContent = title; $("#sheetSub").textContent = sub || ""; $("#sheetBody").innerHTML = html;
    var sh = $("#sheet"), sc = $("#scrim");
    sh.hidden = false; sc.hidden = false;
    $("#sheetBody").scrollTop = 0;
    requestAnimationFrame(function () { requestAnimationFrame(function () { sh.classList.add("open"); sc.classList.add("open"); }); });
    setTimeout(function () { $("#sheetClose").focus(); }, 20);
  }
  function closeSheet() {
    var sh = $("#sheet"), sc = $("#scrim");
    if (sh.hidden) return;
    sh.classList.remove("open"); sc.classList.remove("open");
    clearTimeout(sheetTimer);
    sheetTimer = setTimeout(function () { sh.hidden = true; sc.hidden = true; }, reduced() ? 0 : 290);
    if (lastFocus && lastFocus.focus) { try { lastFocus.focus(); } catch (e) { /* ignore */ } }
  }

  /* ================= LOGIN ================= */
  var NOT_SET_UP = "Login not set up on the server";
  function needLogin(msg) {
    if (msg) showMsg($("#loginMsg"), msg, "bad");
    if (!state.authed && !$("#login").hidden) return;
    state.authed = false;
    doc.body.setAttribute("data-auth", "out");
    $$("section[data-screen]").forEach(function (s) { s.hidden = true; });
    closeSheet();
    $("#login").hidden = false;
    setTimeout(function () { var i = $("#tokenIn"); if (i) i.focus(); }, 30);
  }
  function loggedIn() {
    state.authed = true;
    doc.body.setAttribute("data-auth", "in");
    $("#login").hidden = true;
    $("#tokenIn").value = "";
    showMsg($("#loginMsg"), "");
    state.settings = null;
    ensureSettings().then(function () { showTab(state.tab, { first: true, keepHash: true }); }, function () { showTab(state.tab, { first: true, keepHash: true }); });
  }
  function submitLogin(ev) {
    ev.preventDefault();
    var token = $("#tokenIn").value.trim(), msg = $("#loginMsg");
    if (!token) { showMsg(msg, "Token needed", "bad"); return; }
    var btn = $("#loginForm button[type=submit]");
    btn.disabled = true;
    api("POST", "/api/login", { token: token }, { noAuth: true }).then(loggedIn, function (e) {
      if (e && e.status === 401) showMsg(msg, "Wrong token", "bad");
      else if (e && e.status === 429) showMsg(msg, "Too many tries" + MID + "wait a minute", "bad");
      else if (e && e.status === 503) showMsg(msg, NOT_SET_UP, "bad");
      else showMsg(msg, failText(e), "bad");
    }).then(function () { btn.disabled = false; });
  }
  function logout() {
    api("POST", "/api/logout", {}, { noAuth: true }).then(function () { needLogin(); }, function () { needLogin(); });
  }

  /* ================= wiring ================= */
  function setBook(b) {
    if (b !== "mt5" && b !== "paper") return;
    state.book = b;
    $$("[data-book]").forEach(function (x) { x.setAttribute("aria-pressed", String(x.getAttribute("data-book") === b)); });
    if (state.tab === "journal" || state.tab === "calendar" || state.tab === "edge") loadTab(state.tab);
  }
  doc.addEventListener("click", function (e) {
    var t = e.target, el;
    if (!t || !t.closest) return;
    if ((el = t.closest(".tab[data-tab]"))) { showTab(el.getAttribute("data-tab")); return; }
    if ((el = t.closest("[data-book]"))) { setBook(el.getAttribute("data-book")); return; }
    if ((el = t.closest("[data-jf]"))) { state.jfilter = el.getAttribute("data-jf"); renderJournal(); return; }
    if ((el = t.closest("tr[data-trade]"))) { openTrade(num(el.getAttribute("data-trade"))); return; }
    if ((el = t.closest("button.cell[data-day]"))) { openDay(el.getAttribute("data-day")); return; }
    if ((el = t.closest("#sheet [data-tag]"))) { toggleIn(el, "data-tag", false); return; }
    if ((el = t.closest("#sheet [data-would]"))) { toggleIn(el, "data-would", true); return; }
    if ((el = t.closest("#sheet [data-mgmt]"))) { toggleIn(el, "data-mgmt", true); return; }
    if ((el = t.closest("#saveChoice"))) { saveChoice(el); return; }
    if ((el = t.closest("#newCheck"))) { openCheckForm({}, ""); return; }
    if ((el = t.closest("[data-link-act]"))) { linkAction(el.getAttribute("data-link-act"), el.getAttribute("data-link")); return; }
    if ((el = t.closest("[data-edit-check]"))) { editCheck(el.getAttribute("data-edit-check")); return; }
    if ((el = t.closest("[data-link-trade]"))) { linkTrade(el.getAttribute("data-link-trade"), el.getAttribute("data-check")); return; }
    if ((el = t.closest("[data-check-order]"))) { var tk = el.getAttribute("data-check-order"); openCheckForm(orderPrefill(tk), tk); return; }
    if ((el = t.closest("[data-link-order]"))) { linkOrder(el.getAttribute("data-link-order"), el.getAttribute("data-check")); return; }
    if ((el = t.closest("[data-sact]"))) { suggAct(el.getAttribute("data-sact"), el.getAttribute("data-sid")); return; }
    if ((el = t.closest("#paperList [data-act]"))) { paperAction(el.getAttribute("data-act"), num(el.getAttribute("data-id"))); return; }
    if ((el = t.closest("[data-theme-set]"))) { applyTheme(el.getAttribute("data-theme-set")); return; }
    if ((el = t.closest("#pushOn"))) { turnOnPush(); return; }
    if ((el = t.closest("#pushTest"))) { testPush(); return; }
    if ((el = t.closest("#pushOff"))) { turnOffPush(); return; }
  });
  doc.addEventListener("submit", function (e) {
    var f = e.target;
    if (f && f.id === "paperActForm") { e.preventDefault(); submitPaperAct(f); }
    if (f && f.id === "checkForm") { e.preventDefault(); submitCheck(f); }
    if (f && f.id === "suggForm") { e.preventDefault(); submitSugg(f); }
  });
  $("#brandLink").addEventListener("click", function (e) { e.preventDefault(); if (state.authed) showTab("today"); });
  $("#bridgeChip").addEventListener("click", function () { showTab("live"); });
  $("#themeBtn").addEventListener("click", function () { applyTheme(effTheme() === "dark" ? "light" : "dark"); });
  $("#scrim").addEventListener("click", closeSheet);
  $("#sheetClose").addEventListener("click", closeSheet);
  $("#calPrev").addEventListener("click", function () { state.month = shiftMonth(state.month || currentMonth(), -1); loadTab("calendar"); });
  $("#calNext").addEventListener("click", function () {
    var m = shiftMonth(state.month || currentMonth(), 1);
    if (m <= currentMonth()) { state.month = m; loadTab("calendar"); }
  });
  $("#paperForm").addEventListener("submit", submitPaper);
  $("#actionForm").addEventListener("submit", submitAction);
  $("#actionIn").addEventListener("input", function (e) { e.target.setAttribute("data-dirty", "1"); });
  $("#loginForm").addEventListener("submit", submitLogin);
  $("#logoutBtn").addEventListener("click", logout);
  doc.addEventListener("keydown", function (e) {
    var k = e.key;
    if (!$("#sheet").hidden) {
      if (k === "Escape") { e.preventDefault(); closeSheet(); return; }
      if (k === "Tab") {
        var f = $$("#sheet button, #sheet input, #sheet select, #sheet textarea, #sheet [tabindex]").filter(function (x) { return !x.disabled; });
        if (f.length) {
          var i = f.indexOf(doc.activeElement);
          if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
        }
      }
      return;
    }
    var a = doc.activeElement;
    if (a && a.classList && a.classList.contains("tab") && (k === "ArrowRight" || k === "ArrowLeft")) {
      var j = TABS.indexOf(a.getAttribute("data-tab")) + (k === "ArrowRight" ? 1 : -1);
      j = (j + TABS.length) % TABS.length; showTab(TABS[j]); $("#t-" + TABS[j]).focus(); e.preventDefault(); return;
    }
    if (a && a.matches && a.matches("tr[data-trade]") && (k === "Enter" || k === " ")) { e.preventDefault(); a.click(); }
  });
  window.addEventListener("hashchange", function () { route(false); });
  var rz = 0;
  window.addEventListener("resize", function () {
    clearTimeout(rz);
    rz = setTimeout(function () { if (state.tab === "edge" && state.edge) safe(function () { drawEquity(obj(state.edge)); }); }, 150);
  });
  if (window.matchMedia) {
    try { window.matchMedia("(prefers-color-scheme: light)").addEventListener("change", paintThemeUI); } catch (e) { /* ignore */ }
  }

  /* ---------------- timers: clock every second, live data every 5 s, today every 30 s ---------------- */
  function tick() {
    if (!state.authed || state.tab !== "today") return;
    var m = String(Math.floor(nowMs() / 60000));
    if (m === state.lastMinute) return;
    state.lastMinute = m;
    safe(renderClocks);
    safe(function () { renderTimeline(obj(state.today)); });
  }
  function poll() {
    if (!state.authed || doc.hidden || state.polling) return;
    state.pollN++;
    state.polling = true;
    api("GET", "/api/live").then(function (d) {
      state.polling = false;
      state.live = d; renderChip();
      if (state.tab === "live") renderLive();
      if (state.tab === "today") safe(function () { renderTodayFigs(obj(state.today), obj(state.live)); });
    }, function () { state.polling = false; renderChip(); });
    if (state.tab === "today" && state.pollN % 6 === 0) {
      api("GET", "/api/today").then(function (d) { noteSkew(d); state.today = d; if (state.tab === "today") renderToday(); }, function () { /* keep the last view */ });
    }
  }

  /* ---------------- start ---------------- */
  (function () {
    var t = store.get("theme");
    if (t === "dark" || t === "light") root.setAttribute("data-theme", t);
  })();
  paintThemeUI();
  renderChip();
  (function () {
    var h = (location.hash || "").replace(/^#/, ""), t = store.get("tab");
    state.tab = TABS.indexOf(h) >= 0 ? h : TABS.indexOf(t) >= 0 ? t : "today";
  })();
  ensureSettings().then(function () {
    if (state.authed) route(true);
  });
  /* The service worker shows the phone alerts; it only exists in a secure context (HTTPS or localhost). */
  if (swAllowed()) {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(function () { /* alerts stay off on this phone */ });
    });
  }
  setInterval(tick, 1000);
  setInterval(poll, 5000);
})();
