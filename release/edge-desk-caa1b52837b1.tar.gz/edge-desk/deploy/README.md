# Server install

For the owner's server only: the old `zeroed` Vultr server, upgraded to 2 GB, Ubuntu 24.04 (CLAUDE.md "Server for
the app"). Install the app here, never on the meme bot's signer host. Builders never log in to the server: the owner,
or whoever he gives access, runs these steps, and the output of `python3 deploy/check.py report` is the evidence.

Before step 1: the meme bot's data on `zeroed` is copied off and checked with the meme repo's runbook, then the plan
is upgraded and Ubuntu 24.04 reinstalled (the owner's order, CLAUDE.md). Nothing below runs before that.

Every command here comes from the official page named beside it. Lines marked **not verified** were not run on a
real server by the builder.

## One-paste install (phone only, Vultr web console)

The steps below in one installer, for a phone with no computer (coordinator, 17 Oct 2026). The research repo never
goes on the server: the coordinator runs `python3 desk/deploy/make_release.py --out <dir>` in a research checkout and
puts the tarball and `install.sh` in the private export repo's `release/` folder. The server reads them with
`EDGE_EXPORT_TOKEN`, the fine-grained token Part B already uses (that repo only, Contents read and write).

Before: in the Tailscale admin console (https://login.tailscale.com/admin/dns) turn on MagicDNS and HTTPS
Certificates, and make an auth key (https://login.tailscale.com/admin/settings/keys), not an ephemeral one. After the
install, turn off key expiry for `edge-desk` in the Machines list, or the app becomes unreachable when its node key
expires (180 days by default; worth checking in Tailscale's docs, which change).

1. Vultr, the server's page: copy the password, open **View Console**. Log in as `linuxuser` (paste the password with
   the console's Clipboard, Paste), then `sudo -i`.
2. Paste `read -rs T`, press Enter, paste the export token, press Enter (nothing shows).
3. Paste the install line `make_release.py` printed, press Enter. It downloads `install.sh` with the token, checks its
   sha256 (`sha256sum -c`) and runs it.
4. Answer the questions: the MT5 login, server and INVESTOR password; the Tailscale auth key; the OANDA practice token
   (Enter skips: suggestions stay off); a dashboard password (paste 32+ characters, or Enter makes one, shown once).

The rest runs as the transient unit `edge-desk-install` with "step k of 15" lines, so a dropped console stops nothing;
`edge-desk-install-status` shows it again. It ends with `deploy/check.py report` and one `missing:` line per open item.
Pasting the install line again is safe: what is done is kept, and Enter keeps every saved answer.

A fix reaches the server only through a new release. The install line pins the sha256 of `install.sh`, and
`install.sh` pins the release tarball, so an old install line installs the old code again, whatever was fixed since.
After a change is merged, the coordinator runs `make_release.py`, puts the new files in the export repo and gives the
owner the new install line, saying plainly that the old one will not pick up the fix.

What it does, in order (`deploy/install/stage2.sh`): refuses the meme bot's server (any `zeroed-*` unit,
`/var/lib/zeroed`, the `zeroed-signer` or `zeroed-worker` user) and servers under 1.5 GiB; Ubuntu packages; the
firewall (`deploy/nftables.conf`: inbound closed except Tailscale) and SSH off; unattended security updates; steps 1-9
below, with the ingest token and VAPID key made on the server; WineHQ devel 11.20 (held), Xvfb and MT5 with the EA
(`deploy/install/mt5_setup.py`, the bridge demo's method); Tailscale from its signed repository as `edge-desk`, then
`tailscale serve --bg --https=443 http://127.0.0.1:8787`. Downloads are pinned by sha256 in `deploy/install/pins.env`
(Python 3.13.16 was Sigstore-checked when pinned). The Part B units are installed, and run only with the OANDA token.

**Not verified on a real server:** all of it. Built and tested in a container with stub commands (no systemd);
running its system steps there was refused by the session's safety check. The MT5 setup alone ran on a real terminal
in a container (`evidence/part-b/installer/MT5_SETUP.md`, runs 1 to 5, with a dummy account that could not reach a
broker; run 4 ran the checks added after run 3, failed its first setup on the checkbox read-back and passed with the
pointer moved off each box before it is read; run 5 ran the code with the two small changes after run 4, ea2e076f, on
one CPU with Python 3.12 and passed a fresh setup, three service-style starts, the restart and a re-run). Known
open points: the WebRequest allow-list is set by clicks at fixed screen points (MT5 has no start-file key for it; the
setup reads `Config/common.ini` back and stops without `setup.done` when the list was not saved); a real investor login
and the terminal keeping it between starts; MetaQuotes' installer downloads the terminal itself, which cannot be pinned,
so run the container check on the release day to see which build the owner will get (MT5_SETUP.md, "Before the owner
gets a new install line"); the broker's EUR/USD symbol name (`EURUSD` assumed; a suffix needs a code change); whether
the server's own request to its `*.ts.net` name reaches `tailscale serve` (if not, the https line fails on the server
and the phone check decides); whether `;` or `#` in an investor password breaks MT5's start file.

## 1. Users and folders

```
sudo adduser --system --group --home /opt/edge-desk edge
sudo adduser --disabled-password --gecos "" mt5        # MT5 and Wine run as their own user
sudo mkdir -p /etc/edge-desk /opt/edge-desk/var
```

## 2. Python 3.13 from python.org (Ubuntu 24.04 ships 3.12; believed, not verified here)

The app's `requirements.txt` is hash-pinned for Python 3.13. Build it from the python.org source release and check
its Sigstore signature first (https://www.python.org/downloads/metadata/sigstore/; the 3.13 release manager's
identity is `thomas@python.org`, issuer `https://accounts.google.com`). Use the newest 3.13.x on
https://www.python.org/downloads/source/ as `V`.

```
sudo apt update && sudo apt install -y build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev \
  libsqlite3-dev libffi-dev liblzma-dev uuid-dev python3-venv python3-pip pipx
V=3.13.X          # the newest 3.13 source release
wget https://www.python.org/ftp/python/$V/Python-$V.tgz https://www.python.org/ftp/python/$V/Python-$V.tgz.sigstore
pipx run sigstore verify identity --bundle Python-$V.tgz.sigstore --cert-identity thomas@python.org \
  --cert-oidc-issuer https://accounts.google.com Python-$V.tgz
tar xzf Python-$V.tgz && cd Python-$V && ./configure --prefix=/usr/local && make -j1 && sudo make altinstall
python3.13 --version
```

**Not verified:** the apt package names and the build on a 1-vCPU, 2 GB server (expect tens of minutes).

## 3. The app and its hash-checked environment

```
sudo -u edge git clone <this repo, read-only> /opt/edge-desk/src      # or copy a checked-out tree
cd /opt/edge-desk && sudo -u edge ln -s src/desk/app app && sudo -u edge ln -s src/desk/config config \
  && sudo -u edge ln -s src/desk/deploy deploy
sudo -u edge python3.13 -m venv /opt/edge-desk/.venv
cd /opt/edge-desk/src/desk && sudo -u edge ../../.venv/bin/pip install --require-hashes -r requirements.txt
```

The app lives under `desk/` in the repo; the symlinks keep `python -m app` working from `/opt/edge-desk`. **Not
verified:** the layout on the server.

## 4. Secrets

```
sudo cp /opt/edge-desk/src/desk/deploy/edge-desk.env.example /etc/edge-desk/env
sudo chown root:edge /etc/edge-desk/env && sudo chmod 0640 /etc/edge-desk/env
sudo -u edge /opt/edge-desk/.venv/bin/python -m app vapid-keygen --out /tmp/vapid.key   # paste, then delete
sudo nano /etc/edge-desk/env
```

Values are typed on the server only. Never in the repo, a log or chat.

## 5. The app as a service

Systemd directives: https://www.freedesktop.org/software/systemd/man/latest/systemd.exec.html and
https://www.freedesktop.org/software/systemd/man/latest/systemd.service.html (index:
https://www.freedesktop.org/software/systemd/man/).

```
sudo cp /opt/edge-desk/src/desk/deploy/edge-desk.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now edge-desk
sudo -u edge /opt/edge-desk/.venv/bin/python -m app check
```

The app binds `127.0.0.1:8787` (config `app.host`), so it is not reachable from the internet; HTTPS comes from
Tailscale.

## 6. HTTPS for the phone through Tailscale

From https://tailscale.com/kb/1242/tailscale-serve (syntax `tailscale serve --https=<port> <target>`, `--bg` runs it
in the background; only `http://127.0.0.1` targets are proxied; the certificate is provisioned automatically). Install
Tailscale from https://tailscale.com/download/linux and log in as the owner (only he holds that login).

```
sudo tailscale serve --bg --https=443 http://127.0.0.1:8787
tailscale serve status
# off again:  sudo tailscale serve --https=443 http://127.0.0.1:8787 off
```

**Not verified:** whether HTTPS certificates must first be enabled in the tailnet's admin console (the page says the
certificate is provisioned automatically and does not list a console step). The phone joins the same tailnet and
opens `https://<server name>.<tailnet>.ts.net`, then adds it to the Home Screen (Web Push needs HTTPS).

## 7. MT5 under Wine, read-only

From https://www.metatrader5.com/en/terminal/help/start_advanced/install_linux (MetaQuotes' script `mt5linux.sh`
installs Wine and the terminal):

```
sudo -iu mt5
wget https://download.terminal.free/cdn/web/metaquotes.software.corp/mt5/mt5linux.sh ; chmod +x mt5linux.sh ; ./mt5linux.sh
```

From the bridge demo run (`desk/bridge/demo/EVIDENCE.md`, 16 Oct): Ubuntu's Wine 9.0 could not run MT5 build 6266 and
WineHQ stable 11.0 (`winehq-stable`, from dl.winehq.org) could; `WINEDLLOVERRIDES="mscoree=;mshtml="` skips the
wine-mono prompt; a headless server needs a virtual display (`Xvfb`). `desk/bridge/demo/run_demo.py` holds the commands
that run worked out.

**18 Oct 2026 (Melbourne): WineHQ devel 11.20, not stable 11.0.** On the owner's server, and again in a container with
the server's versions, `winehq-stable` 11.0 no longer installs MT5: MetaQuotes' protected `mt5setup.exe` (5.0.0.4816,
the pinned file) makes raw syscalls, stable 11.0 has no syscall user dispatch, and the installer stops on a false "A
debugger has been found running in your system" (WineHQ bug 58043, fixed after 11.0; the WineHQ noble repository
offers stable only as 10.0 and 11.0). `winehq-devel` 11.20 installed MT5 build 6272, compiled the EA with 0 errors and
0 warnings and ran it for 90 s with no such message. `deploy/install/stage2.sh` swaps stable for devel in one apt call
and holds devel; a Wine prefix with no finished MT5 install in it is rebuilt, and the MT5 step waits for the pinned
Wine. Details: `evidence/part-b/installer/WINE.md`.

**18 Oct 2026 (Melbourne): the setup's two starts** (`deploy/install/mt5_setup.py`; real-path run with build 6272,
`evidence/part-b/installer/MT5_SETUP.md`). MT5 6272 saves Tools > Options to `Config/common.ini` only in a terminal
started without `/config`, so the setup logs in with the start file, closes the terminal with `wine taskkill` (no
`/f`), starts it again with no start file for the clicks, closes it again, and writes `setup.done` only when
`common.ini` holds `[Experts]` with `WebRequest=1`, a listed URL, `Enabled=0` and DLL imports not on. The keys go to
the terminal's main window by its id, and no click runs until the Options window shows where the points were
measured; both checkbox points must read as checkboxes and each clicked box its new state, read with the pointer moved
off it (under the pointer Wine draws a box in hover colours, which stopped run 4's first setup), otherwise the window
closes without saving. Login and LiveUpdate windows get Escape first, until none has shown for a few seconds (a Login
window is expected there: `common.ini` keeps `Login=0`, so a start with no start file never logs in). The build is
printed (and shown in the progress lines as "MT5 build N at its setup"); one whose click points were not measured (only
6266 and 6272 were) goes through the same checks instead of being refused. Each failure closes the terminal and says
whether pasting the line again can help. Real runs 1 to 4 in a container (MT5_SETUP.md), the second and fourth on one
CPU with 1.5 GiB, passed with a dummy account (run 4 after the pointer fix); WebRequest to `http://127.0.0.1:8787` works
with algorithmic trading off (run 3). The service's `run.ini` (0600, owner `mt5`) names the account number and server,
no password: without them the terminal waited on a modal Login window and never tried to connect (seen with a dummy
account that never logged in; with them it tried at once; a real investor login was not tried). Every start file sets
`Enabled=0` (algorithmic trading off; a start file's value applies at each start). The unit restarts always: wine exits
0 when the terminal closes itself.

- Log in with the **investor (read-only) password** only. The app raises a hard incident if the terminal can trade.
- MT5 6272 also starts an MCP server at every start: 127.0.0.1:22346 for the terminal and 22345 for MetaEditor, with
  their API keys in plain text in `Config/assistant.ini` (Options > MCP "Enable internal server" is ticked by
  default; real run 1). The bridge does not need it, so the setup sets `Enable=0` in both `[MCP.*]` sections while the
  terminal is closed, and the read-back requires it off. In real run 2 the next start logged no "MCP started" line and
  nothing listened on either port. The AI Assistant (endpoint `api.inferdeck.net`) has no settings file and no on/off
  switch; it cannot trade with an investor login and starts only when opened. Its outbound traffic was not checked.
- A "Welcome to LiveUpdate" window (Restart / Later) can appear about a minute after a start (LiveUpdate offered build
  6230 on 18 Oct); the setup sends it Escape, never Return. In real run 2, Escape and then the setup's taskkill left the
  terminal on build 6272 (the update was not applied); whether Escape alone closes the window is not shown.
- Each start writes about 16 ALSA lines (no sound device) to the unit's journal; harmless.
- When no snapshot arrives within 3 minutes, the install reads the EA's log and says which cause it names. If it says
  the allow-list is wrong (MT5 keeps it encrypted, so a new paste cannot change it): `systemctl stop edge-desk-mt5 &&
  rm -rf /home/mt5/edge/wine /home/mt5/edge/setup.done`, then paste the install line again and type the account number.
- Disk: the MT5 home is about 2.5 GB after the setup (LiveUpdate adds about 230 MB of ML files the bridge never uses)
  and MT5's own logs and price history grow; count about 3 GB. No job prunes them yet.
- Tools > Options > Expert Advisors: algorithmic trading off; "Allow WebRequest for listed URL" with
  `http://127.0.0.1:8787` (the list is required by https://www.mql5.com/en/docs/network/webrequest).
- Put the ingest token in the terminal's `Common\Files\edge_bridge_token.txt` (bridge/CONTRACT.md "EA inputs"),
  attach `desk/bridge/EdgeBridge.mq5` to a EURUSD chart with `InpUrl = http://127.0.0.1:8787/api/bridge/v1/snapshot`.
- Plain http is allowed only to 127.0.0.1 (bridge/CONTRACT.md; coordinator ruling 7, 16 Oct).

**Not verified:** that WebRequest posts to a non-default port in the URL (`:8787`). The MQL5 page names only ports 80
and 443 ("Server port is automatically selected on the basis of the specified protocol") and says nothing about
127.0.0.1. The demo run added the URL to the allow-list but never connected to a broker, so no snapshot was sent. If
the port is refused, the check's `bridge` line fails and the coordinator is told; the app is not changed to work
around it.

## 8. Storage: prune, backups and the disk floor (A10)

The owner's condition (16 Oct): "As long server never gets populatred. Saved, refresh delete, backup." The hourly
timer runs `python -m app maintain`: the storage check, the prune of raw price samples and log rotation, and once a
New York day a gzipped online backup in `var/backup/` (7 daily and 4 weekly copies, config `[storage]`). Below 3 GB
free, or with the journal and backups over 5 GB, new raw samples stop, trades are still saved, nothing is deleted
and one phone alert is sent. These backups stay on this server; an off-server copy is your choice.

```
sudo cp /opt/edge-desk/src/desk/deploy/edge-desk-maintain.service /opt/edge-desk/src/desk/deploy/edge-desk-maintain.timer \
  /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now edge-desk-maintain.timer
sudo mkdir -p /etc/systemd/journald.conf.d
sudo cp /opt/edge-desk/src/desk/deploy/journald-edge-desk.conf /etc/systemd/journald.conf.d/edge-desk.conf
sudo systemctl restart systemd-journald
systemctl list-timers edge-desk-maintain.timer
```

Timer keys: https://www.freedesktop.org/software/systemd/man/latest/systemd.timer.html; journald keys:
https://www.freedesktop.org/software/systemd/man/latest/journald.conf.html. **Not verified** on the server.

## 9. Part B: the price feed and the two workers

Only after the owner's tokens are on the server (blueprint "Your questions" 4) and his OK on the export.

1. **The pinned lead code** (STATS 77ed1b42, forward tree 1ee7c81b; STATS ruling on app items 2 and 3): build it on
   any machine with a checkout of this repo and git, then copy the folder to the server. No credential for this
   repo goes to the server.
   ```
   python3 desk/deploy/make_lead_bundle.py --out /tmp/lead-bundle          # in the research checkout
   # copy /tmp/lead-bundle to the server as /opt/edge-desk/lead-bundle (root-owned, read-only for edge)
   sudo chown -R root:edge /opt/edge-desk/lead-bundle && sudo chmod -R a-w,g+rX /opt/edge-desk/lead-bundle
   ```
   The worker checks every file's sha256, the file list and STATS's forward tree sha256 at each start
   (`app/suggest/bundle.py`), and runs `fwd_core.compute_run` in its own `python -I -B` process.
2. **Tokens and switches:** `EDGE_OANDA_TOKEN` (the owner's OANDA practice token) and `EDGE_EXPORT_TOKEN` (a
   fine-grained GitHub token for the separate private export repo only, Contents read and write) in
   `/etc/edge-desk/env`; in `config/app.toml` set `[feed] enabled = true`, and `[export] enabled = true` with
   `repo = "<owner>/<export repo>"`. The research repo is refused there.
3. **The calendar pin:** the coordinator puts the checked `FORWARD_EVENTS.csv` and `.json` into the export repo's
   `calendar/` folder; the lead worker takes it once a day (its CSV's sha256 must equal the pin's).
4. **The units:**
   ```
   sudo cp /opt/edge-desk/src/desk/deploy/edge-desk-feed.service /opt/edge-desk/src/desk/deploy/edge-desk-method.service \
     /opt/edge-desk/src/desk/deploy/edge-desk-leads.service /etc/systemd/system/
   sudo systemctl daemon-reload && sudo systemctl enable --now edge-desk-feed edge-desk-method edge-desk-leads
   ```
   The feed backfills 120 days on its first start (about 35 requests, one every 2 s), then polls every 20 s. Each
   unit has a hard `MemoryMax`; the memory check below measures the real peak with every process running.

## 10. Memory over one London and New York day

```
sudo cp /opt/edge-desk/src/desk/deploy/memwatch.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl start memwatch
# after a full weekday from 07:00 London to 17:00 New York:
sudo systemctl stop memwatch
```

The sampler sums the resident memory of MT5, Wine, Xvfb and the app every 30 s, matched by process name and command
line. The ceiling is 1.6 GB of the 2 GB (blueprint "Server setup").

## 11. The check (the evidence)

```
cd /opt/edge-desk && sudo -u edge .venv/bin/python deploy/check.py report \
  --https-url https://<server name>.<tailnet>.ts.net
```

The host line looks for the meme bot's own markers (the installer's guard uses the same); `--forbid-host` and
`--forbid-machine-id` still add to them. (The same as `python3 deploy/check.py report` with the app's own Python.)
Paste the whole output into the PR or
HANDOFF. Expected: `PASS` on host, loopback, app, https, units, bridge and memory.
The phone check is the owner's: the installed app opens over HTTPS and "Send test alert" arrives.
