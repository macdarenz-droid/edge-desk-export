#!/usr/bin/env python3
"""Server check for the Edge Desk (A9). Run on the server by whoever the owner gives access; its output is the
evidence. Standard library only. It prints PASS or FAIL lines and never prints a secret.

  python3 deploy/check.py memwatch --out var/memwatch.jsonl [--interval 30]
      samples the resident memory of MT5, Wine, Xvfb and the app every interval seconds (run it as the
      edge-memwatch service over one full London and New York day)
  python3 deploy/check.py report --https-url https://<name>.<tailnet>.ts.net [--forbid-host <signer hostname>] \
      [--forbid-machine-id <signer machine id>] [--db var/edge.db] [--mem var/memwatch.jsonl]
      the checks below

Checks (blueprint "Server setup", card A9):
  host        this host is not the meme bot's host: none of its own markers is here (a zeroed-* systemd unit,
              /var/lib/zeroed, the zeroed-signer or zeroed-worker user; the installer's guard uses the same), and its
              hostname and /etc/machine-id differ from any values given
  loopback    the app listens on 127.0.0.1:8787 only (from /proc/net/tcp and tcp6), never on all addresses
  app         http://127.0.0.1:8787/api/health answers 200 on the server
  https       the --https-url answers 200 over HTTPS (Tailscale). The check from the owner's phone is his: open the
              same address in the installed app.
  export      the daily export's last try: FAIL while the export repo is public (nothing is sent to it)
  bridge      the journal's latest snapshot from the EA arrived within the last 60 s (read-only open)
  units       every unit active: edge-desk (serve), the virtual display, MT5, memwatch, and the Part B units
              (edge-desk-feed, edge-desk-method, edge-desk-leads) when config [feed] is on
  memory      peak resident memory of MT5, Wine, Xvfb and the app (serve, the feed, both workers and the lead
              worker's child) over a sample covering 07:00 London to 17:00 New York, at or under the 1.6 GB working
              ceiling
"""
from __future__ import annotations

import argparse
import json
import socket
import sqlite3
import sys
import time
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

UTC = timezone.utc
LONDON, NEW_YORK = ZoneInfo("Europe/London"), ZoneInfo("America/New_York")
CEILING = 1.6 * 2**30          # bytes: the working ceiling declared in the blueprint (of 2 GB)
PORT = 8787
BASE_UNITS = ("edge-desk.service", "edge-desk-xvfb.service", "edge-desk-mt5.service", "memwatch.service")
PART_B_UNITS = ("edge-desk-feed.service", "edge-desk-method.service", "edge-desk-leads.service")
UNITS = BASE_UNITS + PART_B_UNITS
MEME_UNIT_DIRS = ("etc/systemd/system", "lib/systemd/system", "usr/lib/systemd/system", "run/systemd/system",
                  "run/systemd/transient")
MEME_USERS = ("zeroed-signer", "zeroed-worker")
WINE_COMMS = {"wineserver", "wine", "wine64", "wine-preloader", "wine64-preloader", "winedevice.exe",
              "services.exe", "plugplay.exe", "explorer.exe", "rpcss.exe", "svchost.exe", "start.exe",
              "conhost.exe", "tabtip.exe"}


def _read(p: Path) -> str:
    try:
        return p.read_text(errors="replace")
    except OSError:
        return ""


def _group(comm: str, cmdline: str) -> str | None:
    low = cmdline.lower()
    if "terminal64.exe" in low or comm.lower() == "terminal64.exe" or "metaeditor64.exe" in low:
        return "mt5"
    if "-m app" in cmdline or "app/suggest/lead_child.py" in cmdline:
        return "app"                     # serve, feed, both workers and the lead worker's child
    if comm == "Xvfb":
        return "xvfb"
    if comm in WINE_COMMS or comm.endswith(".exe") or "c:\\windows" in low:
        return "wine"
    return None


def sample(proc_root: Path = Path("/proc")) -> dict:
    """Resident memory (bytes) of the Edge Desk's processes by group, matched on comm and cmdline (PIDs change)."""
    groups: dict[str, int] = {}
    for d in proc_root.iterdir():
        if not d.name.isdigit():
            continue
        comm = _read(d / "comm").strip()
        cmdline = _read(d / "cmdline").replace("\0", " ").strip()
        g = _group(comm, cmdline)
        if g is None:
            continue
        rss = 0
        for line in _read(d / "status").splitlines():
            if line.startswith("VmRSS:"):
                rss = int(line.split()[1]) * 1024
        groups[g] = groups.get(g, 0) + rss
    return {"groups": groups, "total": sum(groups.values())}


def memwatch(out: Path, interval: int) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    while True:
        s = sample()
        s["at"] = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        with out.open("a") as fh:
            fh.write(json.dumps(s) + "\n")
        time.sleep(interval)


def _covers_a_day(times: list[datetime]) -> bool:
    """True when the samples run from 07:00 London to 17:00 New York on one weekday, with no gap over 10 minutes."""
    if not times:
        return False
    times = sorted(times)
    for day in sorted({t.astimezone(LONDON).date() for t in times}):
        if day.weekday() > 4:
            continue
        start = datetime(day.year, day.month, day.day, 7, tzinfo=LONDON)
        end = datetime(day.year, day.month, day.day, 17, tzinfo=NEW_YORK)
        inside = [t for t in times if start - timedelta(minutes=10) <= t <= end + timedelta(minutes=10)]
        if not inside or inside[0] > start + timedelta(minutes=10) or inside[-1] < end - timedelta(minutes=10):
            continue
        if all((b - a) <= timedelta(minutes=10) for a, b in zip(inside, inside[1:])):
            return True
    return False


def memory_verdict(log: Path, ceiling: float = CEILING) -> dict:
    rows = [json.loads(x) for x in _read(log).splitlines() if x.strip()]
    if not rows:
        return {"ok": False, "detail": f"no samples in {log}", "peak_mb": None}
    times = [datetime.strptime(r["at"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC) for r in rows]
    peak = max(r["total"] for r in rows)
    day = _covers_a_day(times)
    ok = day and peak <= ceiling
    return {"ok": ok, "peak_mb": peak / 2**20, "samples": len(rows),
            "detail": f"peak {peak / 2**20:.0f} MB of {ceiling / 2**20:.0f} MB ceiling; "
                      f"{len(rows)} samples {times[0]:%d %b %H:%M}-{times[-1]:%d %b %H:%M} UTC; "
                      + ("covers a London and New York day" if day else "does NOT cover 07:00 London to 17:00 New York")}


def listeners(tcp_file: Path, port: int) -> list[str]:
    """Local addresses listening on `port` in a /proc/net/tcp file (IPv4) or tcp6 (shown as ::1 or ::)."""
    out = []
    for line in _read(tcp_file).splitlines()[1:]:
        parts = line.split()
        if len(parts) < 4 or parts[3] != "0A":
            continue
        addr, hexport = parts[1].split(":")
        if int(hexport, 16) != port:
            continue
        if len(addr) == 8:
            out.append(socket.inet_ntoa(bytes.fromhex(addr)[::-1]))
        else:
            raw = bytes.fromhex(addr)
            words = b"".join(raw[i:i + 4][::-1] for i in range(0, 16, 4))
            out.append(socket.inet_ntop(socket.AF_INET6, words))
    return out


def meme_markers(root: Path = Path("/")) -> list[str]:
    """The meme bot host's own markers found under root (the same list as deploy/install/guard.sh)."""
    found = []
    for d in MEME_UNIT_DIRS:
        base = root / d
        if base.is_dir():
            found += [f"/{d}/{p.name}" for p in sorted(base.glob("zeroed-*"))]
    if (root / "var/lib/zeroed").exists():
        found.append("/var/lib/zeroed")
    users = {ln.split(":", 1)[0] for ln in _read(root / "etc/passwd").splitlines()}
    found += [f"user {u}" for u in MEME_USERS if u in users]
    return found


def host_ok(hostname: str, machine_id: str, forbid_hosts: list[str], forbid_ids: list[str],
            markers: list[str] | None = None) -> dict:
    """With markers given (the report), the markers decide, and any hostname or machine id given counts on top.
    Without them, only the values given can show it, and none given proves nothing."""
    if markers is None and not forbid_hosts and not forbid_ids:
        return {"ok": False, "detail": "give --forbid-host (and --forbid-machine-id) of the meme bot's signer host"}
    if markers:
        return {"ok": False, "detail": "this IS the meme bot's host (" + ", ".join(markers) + "): stop"}
    bad = hostname in forbid_hosts or (machine_id and machine_id in forbid_ids)
    return {"ok": not bad, "detail": ("this IS the signer host: stop" if bad else
                                      f"no meme bot marker here; hostname {hostname}")}


def bridge_ok(db_path: Path, now: datetime, max_age_s: int = 60) -> dict:
    try:
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        row = con.execute("SELECT last_seen_utc, last_seq, last_reason, trade_allowed FROM bridge_status"
                          " ORDER BY last_seen_utc DESC LIMIT 1").fetchone()
        con.close()
    except sqlite3.Error as exc:
        return {"ok": False, "detail": f"journal not readable: {type(exc).__name__}", "seq": None}
    if row is None:
        return {"ok": False, "detail": "no snapshot from the EA yet", "seq": None}
    seen = datetime.strptime(row[0], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    age = (now - seen).total_seconds()
    ok = age <= max_age_s and not row[3]
    return {"ok": ok, "seq": row[1], "detail": f"last snapshot {age:.0f} s ago, seq {row[1]}, reason {row[2]}"
            + ("; TERMINAL CAN TRADE: log in with the investor password" if row[3] else "")}


PUBLIC_REASON = "the export repo is public"       # app/export/daily.py PUBLIC_REASON


def export_enabled(config: Path) -> bool:
    import tomllib
    try:
        return bool(tomllib.loads(_read(config)).get("export", {}).get("enabled"))
    except tomllib.TOMLDecodeError:
        return False


def export_ok(db_path: Path, enabled: bool) -> dict:
    """The daily export's last try (read-only): FAIL while the export repo is public or the last try failed."""
    if not enabled:
        return {"ok": True, "detail": "off (Part B is off)"}
    try:
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        row = con.execute("SELECT status, detail, made_utc FROM worker_run WHERE worker = 'export'"
                          " ORDER BY id DESC LIMIT 1").fetchone()
        con.close()
    except sqlite3.Error as exc:
        return {"ok": False, "detail": f"journal not readable: {type(exc).__name__}"}
    if row is None:
        return {"ok": True, "detail": "nothing sent yet (the first export is after 17:05 New York)"}
    if row[0] == "sent":
        return {"ok": True, "detail": f"last sent {row[2]}"}
    if PUBLIC_REASON in (row[1] or ""):
        return {"ok": False, "detail": f"{PUBLIC_REASON}: nothing is sent until it is private"}
    return {"ok": False, "detail": f"last try {row[2]} failed: {(row[1] or '')[:120]}"}


def _unit_state(unit: str) -> str:
    import subprocess
    try:
        r = subprocess.run(["systemctl", "is-active", unit], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError) as exc:
        return f"unknown ({type(exc).__name__})"
    return (r.stdout or r.stderr).strip() or "unknown"


def required_units(feed_on: bool) -> tuple[str, ...]:
    return BASE_UNITS + (PART_B_UNITS if feed_on else ())


def feed_enabled(config: Path) -> bool | None:
    """[feed] enabled from the app's config; None when it cannot be read (the units line then fails)."""
    import tomllib
    text = _read(config)
    if not text:
        return None
    try:
        return bool(tomllib.loads(text).get("feed", {}).get("enabled"))
    except tomllib.TOMLDecodeError:
        return None


def units_ok(state=None, feed_on: bool | None = True) -> dict:
    """Every Edge Desk unit that should run is active (systemctl is-active); Part B's only when [feed] is on."""
    if feed_on is None:
        return {"ok": False, "detail": "config/app.toml could not be read, so which units should run is not known"}
    state = state or _unit_state
    units = required_units(feed_on)
    got = {u: state(u) for u in units}
    bad = {u: s for u, s in got.items() if s != "active"}
    return {"ok": not bad, "detail": "all active: " + ", ".join(units) if not bad else
            "not active: " + ", ".join(f"{u} ({s})" for u, s in bad.items())}


def _http_ok(url: str) -> dict:
    try:
        with urllib.request.urlopen(url, timeout=10) as r:      # noqa: S310 - a fixed health URL
            return {"ok": r.status == 200, "detail": f"{url} answered {r.status}"}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "detail": f"{url}: {type(exc).__name__}"}


TODO = {
    "host": "this is the meme bot's server: install the Edge Desk on the other server",
    "loopback": "the app must listen on 127.0.0.1:8787 only: check config [app] host",
    "app": "the app does not answer: journalctl -u edge-desk",
    "https": "HTTPS through Tailscale does not answer yet",
    "units": "a service is not running (the units line names it)",
    "bridge": "no snapshot from MT5 yet: the terminal must reach the broker, logged in with the investor password",
    "export": "the daily export (the export line says why; a public export repo gets nothing until it is made "
              "private in GitHub, Settings, Danger Zone)",
    "memory": "the memory sample over one full London and New York day (memwatch runs; run this report again "
              "after 5:00 pm New York on a weekday)",
}


def todo(results: list, oanda: bool, tailscale: bool) -> list[str]:
    """One "missing:" line per item still open after the install, in the owner's words."""
    out = [f"missing: {TODO[name]}" for name, r in results if not r.get("ok") and name in TODO]
    if not tailscale:
        out.append("missing: Tailscale: paste the install line again with an auth key (tskey-...)")
    if not oanda:
        out.append("missing: the OANDA practice token, so suggestions and paper leads stay off (optional; paste the "
                   "install line again to add it)")
    if any(name == "bridge" and not r.get("ok") for name, r in results):
        out.append("missing: MT5 check: the bridge line passes once the EA's snapshots arrive")
    out.append("missing: the phone check (yours): open the app over HTTPS, add it to the Home Screen, "
               "send a test alert")
    return out


def report(args) -> int:
    lines = []
    hostname = socket.gethostname()
    mid = _read(Path("/etc/machine-id")).strip()
    lines.append(("host", host_ok(hostname, mid, args.forbid_host, args.forbid_machine_id, markers=meme_markers())))
    addrs = listeners(Path("/proc/net/tcp"), PORT) + listeners(Path("/proc/net/tcp6"), PORT)
    lines.append(("loopback", {"ok": bool(addrs) and set(addrs) <= {"127.0.0.1", "::1"},
                               "detail": f"port {PORT} listens on {addrs or 'nothing'}"}))
    lines.append(("app", _http_ok(f"http://127.0.0.1:{PORT}/api/health")))
    lines.append(("https", _http_ok(args.https_url.rstrip("/") + "/api/health") if args.https_url else
                  {"ok": False, "detail": "give --https-url (the Tailscale https address)"}))
    lines.append(("units", units_ok(feed_on=feed_enabled(Path(args.config)))))
    lines.append(("bridge", bridge_ok(Path(args.db), datetime.now(UTC))))
    lines.append(("export", export_ok(Path(args.db), export_enabled(Path(args.config)))))
    lines.append(("memory", memory_verdict(Path(args.mem))))
    for name, r in lines:
        print(f"{'PASS' if r['ok'] else 'FAIL'} {name}: {r['detail']}")
    print(f"checked {datetime.now(UTC):%Y-%m-%d %H:%M} UTC on {hostname}")
    if args.todo:
        for line in todo(lines, oanda=args.oanda == "yes", tailscale=args.tailscale == "yes"):
            print(line)
    return 0 if all(r["ok"] for _, r in lines) else 1


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="deploy/check.py", description="Edge Desk server check (report, memwatch)")
    sub = p.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("memwatch", help="sample resident memory of MT5, Wine, Xvfb and the app")
    m.add_argument("--out", default="var/memwatch.jsonl")
    m.add_argument("--interval", type=int, default=30)
    r = sub.add_parser("report", help="print the PASS / FAIL checks")
    r.add_argument("--https-url", default="")
    r.add_argument("--forbid-host", action="append", default=[])
    r.add_argument("--forbid-machine-id", action="append", default=[])
    r.add_argument("--db", default="var/edge.db")
    r.add_argument("--mem", default="var/memwatch.jsonl")
    r.add_argument("--config", default="config/app.toml")
    r.add_argument("--todo", action="store_true", help="also list what is still missing (the installer's finish)")
    r.add_argument("--oanda", choices=("yes", "no"), default="no")
    r.add_argument("--tailscale", choices=("yes", "no"), default="no")
    args = p.parse_args(argv)
    if args.cmd == "memwatch":
        memwatch(Path(args.out), max(5, args.interval))
        return 0
    return report(args)


if __name__ == "__main__":
    sys.exit(main())
