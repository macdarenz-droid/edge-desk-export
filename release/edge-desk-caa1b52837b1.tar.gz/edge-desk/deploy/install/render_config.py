#!/usr/bin/env python3
"""Turn Part B on or off in the release's config/app.toml (run by deploy/install/stage2.sh, as root, with the system
Python; standard library only). Only three values change: [feed] enabled, [export] enabled and [export] repo. Every
ceiling stays as it is, and the result is read back with tomllib before it replaces the file.

  python3 render_config.py <app.toml> --part-b on|off --export-repo owner/name
"""
from __future__ import annotations

import argparse
import os
import re
import sys
import tempfile
import tomllib
from pathlib import Path

REPO_RE = re.compile(r"[A-Za-z0-9-]{1,39}/[A-Za-z0-9._-]{1,100}")
RESEARCH_REPOS = {"forex-signal"}          # app/config.py refuses it too


def _set(text: str, section: str, key: str, value: str) -> str:
    """Replace `key = ...` inside [section] only, keeping the line's comment."""
    head = re.search(rf"(?m)^\[{re.escape(section)}\]\s*$", text)
    if head is None:
        raise ValueError(f"[{section}] is missing")
    nxt = re.search(r"(?m)^\[", text[head.end():])
    end = head.end() + (nxt.start() if nxt else len(text) - head.end())
    body = text[head.end():end]
    new, n = re.subn(rf"(?m)^({re.escape(key)}\s*=\s*)(\"[^\"]*\"|\S+)", lambda m: m.group(1) + value, body, count=1)
    if n != 1:
        raise ValueError(f"[{section}] {key} is missing")
    return text[:head.end()] + new + text[end:]


def render(path: Path, part_b: bool, export_repo: str) -> None:
    if not REPO_RE.fullmatch(export_repo) or ".." in export_repo:
        raise ValueError("the export repo must be owner/name")
    if export_repo.split("/", 1)[1].lower() in RESEARCH_REPOS:
        raise ValueError("the research repo is never the export repo")
    text = path.read_text()
    before = tomllib.loads(text)
    flag = "true" if part_b else "false"
    text = _set(text, "feed", "enabled", flag)
    text = _set(text, "export", "enabled", flag)
    text = _set(text, "export", "repo", f'"{export_repo}"')
    after = tomllib.loads(text)
    changed = {(s, k) for s in before for k in before[s] if before[s][k] != after.get(s, {}).get(k)}
    if not changed <= {("feed", "enabled"), ("export", "enabled"), ("export", "repo")}:
        raise ValueError(f"unexpected change: {sorted(changed)}")
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".app.toml.")
    with os.fdopen(fd, "w") as fh:
        fh.write(text)
    os.chmod(tmp, 0o644)
    os.replace(tmp, path)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("config")
    ap.add_argument("--part-b", choices=("on", "off"), required=True)
    ap.add_argument("--export-repo", required=True)
    a = ap.parse_args(argv)
    try:
        render(Path(a.config), a.part_b == "on", a.export_repo)
    except ValueError as exc:
        print(f"render_config: {exc}", file=sys.stderr)
        return 2
    print(f"config: Part B {a.part_b}, export repo {a.export_repo}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
