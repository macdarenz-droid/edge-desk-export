#!/usr/bin/env python3
"""Build the Edge Desk release for the one-paste server install (coordinator ruling, 17 Oct 2026: the research repo
stays off the server; the release goes to the owner's private export repo under release/, and the server fetches it
with EDGE_EXPORT_TOKEN).

  python3 desk/deploy/make_release.py --out /tmp/edge-release [--commit <sha>] \
      [--export-repo macdarenz-droid/edge-desk-export] [--branch main]

Run in a checkout of this repo that holds both the commit and STATS's pinned commit (for the lead bundle). It writes:
  edge-desk-<commit12>.tar.gz   desk/{app,config,deploy,bridge,requirements.txt} at the commit (from git objects, so
                                the working tree does not matter) plus lead-bundle/ (deploy/make_lead_bundle.py),
                                under edge-desk/; reproducible: sorted members, owner 0, fixed time, gzip time 0
  install.sh                    deploy/install/install.sh.in with the host guard copied in and the tarball's sha256
  SHA256SUMS
and prints the two lines the owner pastes. Put install.sh and the tarball in the export repo's release/ folder.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import re
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
FIXED_MTIME = 1735689600                      # 2025-01-01 00:00 UTC, for every member
PATHS = ("desk/app", "desk/config", "desk/deploy", "desk/bridge", "desk/requirements.txt")
SKIP = re.compile(r"(^|/)(__pycache__|tests?)(/|$)|\.pyc$")
TOP = "edge-desk"
REPO_RE = re.compile(r"[A-Za-z0-9-]{1,39}/[A-Za-z0-9._-]{1,100}")
API = "https://api.github.com"


def _git(repo: Path, *args: str) -> bytes:
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, check=True).stdout


def _info(name: str, size: int, mode: int, kind=tarfile.REGTYPE) -> tarfile.TarInfo:
    ti = tarfile.TarInfo(name)
    ti.size, ti.mode, ti.type, ti.mtime = size, mode, kind, FIXED_MTIME
    ti.uid = ti.gid = 0
    ti.uname = ti.gname = ""
    return ti


def _members(repo: Path, commit: str, bundle_dir: Path | None) -> dict[str, tuple[bytes, int]]:
    files: dict[str, tuple[bytes, int]] = {}
    raw = _git(repo, "archive", "--format=tar", commit, *PATHS)
    with tarfile.open(fileobj=io.BytesIO(raw)) as tf:
        for m in tf.getmembers():
            if not m.isfile():
                if m.issym() or m.islnk():
                    raise SystemExit(f"make_release: links are not shipped: {m.name}")
                continue
            rel = m.name[len("desk/"):]
            if SKIP.search(rel):
                continue
            files[f"{TOP}/{rel}"] = (tf.extractfile(m).read(), 0o755 if m.mode & 0o111 else 0o644)
    if bundle_dir is not None:
        for p in sorted(bundle_dir.rglob("*")):
            if p.is_symlink():
                raise SystemExit(f"make_release: links are not shipped: {p}")
            # shipped exactly as built: its manifest lists every file, STATS's tests/ included
            if p.is_file():
                files[f"{TOP}/lead-bundle/{p.relative_to(bundle_dir).as_posix()}"] = (p.read_bytes(), 0o644)
    return files


def build_tarball(repo: Path, commit: str, out_dir: Path, bundle_dir: Path | None) -> Path:
    commit = _git(repo, "rev-parse", "--verify", f"{commit}^{{commit}}").decode().strip()
    files = _members(repo, commit, bundle_dir)
    dirs = {"/".join(n.split("/")[:i]) for n in files for i in range(1, n.count("/") + 1)}
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w", format=tarfile.PAX_FORMAT) as tf:
        for name in sorted(dirs | set(files)):
            if name in files:
                data, mode = files[name]
                tf.addfile(_info(name, len(data), mode), io.BytesIO(data))
            else:
                tf.addfile(_info(name, 0, 0o755, tarfile.DIRTYPE))
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"edge-desk-{commit[:12]}.tar.gz"
    with open(path, "wb") as fh, gzip.GzipFile(filename="", mode="wb", fileobj=fh, mtime=0, compresslevel=9) as gz:
        gz.write(buf.getvalue())
    return path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def render_install(export_repo: str, branch: str, release_name: str, release_sha256: str, commit: str) -> str:
    if not REPO_RE.fullmatch(export_repo) or export_repo.split("/")[1].lower() == "forex-signal":
        raise ValueError("the export repo must be owner/name, never the research repo")
    if not re.fullmatch(r"[A-Za-z0-9._/-]{1,100}", branch) or not re.fullmatch(r"[A-Za-z0-9._-]{1,100}", release_name):
        raise ValueError("bad branch or release name")
    if not re.fullmatch(r"[0-9a-f]{64}", release_sha256) or not re.fullmatch(r"[0-9a-f]{3,40}", commit):
        raise ValueError("bad sha256 or commit")
    text = (HERE / "install" / "install.sh.in").read_text()
    guard = (HERE / "install" / "guard.sh").read_text()
    for key, value in (("@@EXPORT_REPO@@", export_repo), ("@@EXPORT_BRANCH@@", branch),
                       ("@@RELEASE_NAME@@", release_name), ("@@RELEASE_SHA256@@", release_sha256),
                       ("@@COMMIT@@", commit), ("@@GUARD@@", guard.rstrip("\n"))):
        if key not in text:
            raise ValueError(f"{key} missing from install.sh.in")
        text = text.replace(key, value)
    return text


def paste_lines(export_repo: str, branch: str, install_sha256: str) -> list[str]:
    url = f"{API}/repos/{export_repo}/contents/release/install.sh?ref={branch}"
    line = ("curl -fsS --proto =https -K <(printf 'header = \"Authorization: Bearer %s\"\\n' \"$T\") "
            "-H 'Accept: application/vnd.github.raw+json' -o /root/edge-install.sh "
            f"'{url}' && echo '{install_sha256}  /root/edge-install.sh' | sha256sum -c && "
            'T="$T" bash /root/edge-install.sh; unset T')
    return ["read -rs T", line]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", required=True)
    ap.add_argument("--repo", default=str(HERE.parents[1]))
    ap.add_argument("--commit", default="HEAD")
    ap.add_argument("--export-repo", default="macdarenz-droid/edge-desk-export")
    ap.add_argument("--branch", default="main")
    a = ap.parse_args(argv)
    repo, out = Path(a.repo), Path(a.out)
    commit = _git(repo, "rev-parse", "--verify", f"{a.commit}^{{commit}}").decode().strip()
    sys.path.insert(0, str(HERE))
    sys.path.insert(0, str(HERE.parent))
    import make_lead_bundle
    with tempfile.TemporaryDirectory() as tmp:
        bundle = Path(tmp) / "lead-bundle"
        make_lead_bundle.build(bundle, repo)
        tarball = build_tarball(repo, commit, out, bundle)
    tsha = sha256(tarball)
    (out / "install.sh").write_text(render_install(a.export_repo, a.branch, tarball.name, tsha, commit))
    isha = sha256(out / "install.sh")
    (out / "SHA256SUMS").write_text(f"{tsha}  {tarball.name}\n{isha}  install.sh\n")
    print(f"commit   {commit}")
    print(f"tarball  {tarball.name}  sha256 {tsha}  ({tarball.stat().st_size:,} bytes)")
    print(f"install  install.sh  sha256 {isha}")
    print(f"Put both files in {a.export_repo}, branch {a.branch}, folder release/. The owner pastes, as root:")
    for ln in paste_lines(a.export_repo, a.branch, isha):
        print(ln)
    return 0


if __name__ == "__main__":
    sys.exit(main())
