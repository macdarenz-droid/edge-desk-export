"""Journal accounts (owner, 30 Oct 2026; CLAUDE.md "Journal account for his 2nd account"; docs/JOURNAL_DESIGN.md
section 16): an account with no MT5 link and no live tracking. He makes it in Journal ("New account": a name, "2nd
account" by default, and the starting fund he types) and switches between it and the MT5 account there; its trades
come only from his MT5 phone pictures (app/photos), read from their lines on this server and checked by him.

Its own numbers, kept apart from the MT5 account's (they never reach the day guard, the FundedNext panel, the alerts,
the suggestions or the MT5 account's stats):
- balance = the starting fund + the net (profit + commission + swap) of its trades closed with an exact exit (a History
  picture, or the numbers he typed from it); a close estimated from prices adds nothing until it is confirmed; a
  commission or swap that is not known counts 0, and those trades are counted in `costs_unknown`;
- each trade's % is of the balance when it opened; R comes from its first stop only (app/photos/match.r_values);
- money in USD only (currency 'USD').
Its MT5 server clock (review finding 3): how its broker's server prints History times, chosen in the same form:
"ny+7" (New York + 7 h, as most MT5 brokers: the default, an assumption until he names his broker), "gmt+2", "gmt+3"
or "gmt+0" all year (app/photos/clocks.py). Each History reading keeps the clock it was made with, so a change applies
only to readings made after it.
A change of a name, a starting fund or a server clock is kept in journal_account_edit (a trigger writes it,
app/db.py), never a silent overwrite. Standard library only; runs in `serve` under the journal lock.
"""
from __future__ import annotations

import math
import re
from datetime import datetime

from app import db
from app.photos.clocks import SERVER_CLOCKS
from app.timeutil import to_iso

NAME_MAX = 40
FUND_MAX = 100_000_000.0
DEFAULT_NAME = "2nd account"
DEFAULT_CLOCK = "ny+7"
MT5 = "mt5"                                    # the account switch's word for the MT5-linked account
_ONE_LINE = re.compile(r"[\x00-\x1f\x7f]")
_ID = re.compile(r"[1-9][0-9]{0,11}")


class NotFound(LookupError):
    pass


def parse(value) -> int | None:
    """The account a request names: None (the MT5 account) for nothing or "mt5", else a journal account's id.
    ValueError for anything else (the caller checks that the id exists)."""
    if value is None or value == "" or value == MT5:
        return None
    if isinstance(value, str) and _ID.fullmatch(value):
        return int(value)
    raise ValueError("account: mt5 or a journal account's number")


def _name(value) -> str:
    if not isinstance(value, str):
        raise ValueError("name: text, such as 2nd account")
    value = value.strip()
    if not 1 <= len(value) <= NAME_MAX or _ONE_LINE.search(value):
        raise ValueError(f"name: 1 to {NAME_MAX} characters on one line")
    return value


def _fund(value) -> float:
    """Kept to the cent: a fund that rounds to 0 is refused here (a 400), never by the table's check (a 500)."""
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) \
            or not 0 < round(float(value), 2) <= FUND_MAX:
        raise ValueError("starting fund: a number of at least 0.01, such as 5000")
    return round(float(value), 2)


def _clock(value) -> str:
    if value not in SERVER_CLOCKS:
        raise ValueError(f"server clock: one of {', '.join(SERVER_CLOCKS)}")
    return value


def _taken(conn, name: str, but: int | None = None) -> bool:
    r = conn.execute("SELECT id FROM journal_account WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
    return r is not None and r[0] != but


def get(conn, account_id: int) -> dict:
    r = conn.execute("SELECT id, name, currency, start_fund, server_clock, created_utc, changed_utc FROM journal_account"
                     " WHERE id = ?", (account_id,)).fetchone()
    if r is None:
        raise NotFound("no such account")
    return dict(r)


def exists(conn, account_id: int | None) -> bool:
    return account_id is not None and conn.execute("SELECT 1 FROM journal_account WHERE id = ?",
                                                   (account_id,)).fetchone() is not None


def create(conn, name, start_fund, now: datetime, server_clock: str = DEFAULT_CLOCK) -> dict:
    """A new journal account (his "New account" in Journal)."""
    name, fund, clock = _name(name), _fund(start_fund), _clock(server_clock)
    with db.transaction(conn):
        if _taken(conn, name):
            raise ValueError("name: another account has this name")
        aid = conn.execute("INSERT INTO journal_account (name, currency, start_fund, server_clock, created_utc) VALUES"
                           " (?, 'USD', ?, ?, ?)", (name, fund, clock, to_iso(now))).lastrowid
    return get(conn, aid)


def edit(conn, account_id: int, now: datetime, *, name=None, start_fund=None, server_clock=None) -> dict:
    """A new name, starting fund or server clock; the trigger keeps the old value beside the new one
    (journal_account_edit). A new clock applies to History readings made after it only."""
    a = get(conn, account_id)
    if name is None and start_fund is None and server_clock is None:
        raise ValueError("give a name, a starting fund or a server clock")
    new_name = a["name"] if name is None else _name(name)
    new_fund = a["start_fund"] if start_fund is None else _fund(start_fund)
    new_clock = a["server_clock"] if server_clock is None else _clock(server_clock)
    with db.transaction(conn):
        if _taken(conn, new_name, account_id):
            raise ValueError("name: another account has this name")
        if (new_name, new_fund, new_clock) != (a["name"], a["start_fund"], a["server_clock"]):
            conn.execute("UPDATE journal_account SET name = ?, start_fund = ?, server_clock = ?, changed_utc = ?"
                         " WHERE id = ?", (new_name, new_fund, new_clock, to_iso(now), account_id))
    return get(conn, account_id)


def server_clock(conn, account_id: int | None) -> str:
    """The server clock a History reading of this account uses now (the MT5 account: New York + 7 h, its bridge's)."""
    if account_id is None:
        return DEFAULT_CLOCK
    r = conn.execute("SELECT server_clock FROM journal_account WHERE id = ?", (account_id,)).fetchone()
    return r[0] if r else DEFAULT_CLOCK


def exact_closes(conn, account_id: int) -> list[tuple[str, float, bool]]:
    """(exit time, net money, costs known) of each trade closed with an exact exit, oldest first."""
    out = []
    for r in conn.execute("SELECT exit_utc_to, profit, commission, swap FROM photo_trade WHERE account_id = ?"
                          " AND state = 'closed' AND exit_how IN ('history','bridge') AND profit IS NOT NULL"
                          " ORDER BY exit_utc_to, id", (account_id,)):
        net = r["profit"] + (r["commission"] or 0.0) + (r["swap"] or 0.0)
        out.append((r["exit_utc_to"] or "", net, r["commission"] is not None))
    return out


def balance_at(start_fund: float, closes: list[tuple[str, float, bool]], at_iso: str | None) -> float:
    """The balance when a trade opened: the starting fund + the net of the exact closes at or before that time."""
    return start_fund + sum(net for at, net, _ in closes if at_iso is not None and at and at <= at_iso)


def summary(conn, cfg, account_id: int) -> dict:
    """Its balance and counts (the Journal's figures for this account)."""
    a = get(conn, account_id)
    closes = exact_closes(conn, account_id)
    n = conn.execute("SELECT COUNT(*), SUM(state = 'closed') FROM photo_trade WHERE account_id = ?"
                     " AND state IN ('confirmed','closed') AND linked_trade_id IS NULL", (account_id,)).fetchone()
    net = sum(x[1] for x in closes)
    return {"balance": round(a["start_fund"] + net, 2), "net": round(net, 2), "trades": n[0] or 0,
            "closed": n[1] or 0, "costs_unknown": sum(1 for x in closes if not x[2])}


def public(conn, cfg, account_id: int) -> dict:
    return {**get(conn, account_id), **summary(conn, cfg, account_id)}


def listing(conn, cfg) -> list[dict]:
    return [public(conn, cfg, r[0]) for r in conn.execute("SELECT id FROM journal_account ORDER BY id")]
