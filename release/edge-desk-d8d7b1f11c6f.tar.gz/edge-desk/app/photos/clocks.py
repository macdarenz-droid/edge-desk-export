"""The clocks of a picture (docs/JOURNAL_DESIGN.md §5.5 "Time of a picture", D16). No fixed offsets: every time is
converted with the time-zone rules for its date. The MT5 server shows New York wall time + 7 h (America/New_York, the
bridge's rule in app/ingest/clock.py); the phone's status bar shows Melbourne (Australia/Melbourne) on a 12-hour clock
with no am or pm; times are shown as London with Melbourne beside it, "12:10 London · 11:10 pm Melb." (the app's own
format, app.js hhmm and hm12).

A picture's time: the phone clock's minute, its am or pm the one nearest the file's own time (File.lastModified), else
nearest the chart's server time (its time labels), never the upload time when either is known; the countdown under the
live price gives the second (server now = the live candle's open + timeframe - countdown). V9: the phone clock and the
file time agree within 2 minutes. Without a status bar the file time is used, marked "about".
"""
from __future__ import annotations

import math
import re
from datetime import date, datetime, timedelta, timezone

from app.timeutil import LONDON, MELBOURNE, NEW_YORK

UTC = timezone.utc
SERVER_SHIFT = timedelta(hours=7)            # server wall time = New York wall time + 7 h
TF_SECONDS = {"M1": 60, "M2": 120, "M3": 180, "M4": 240, "M5": 300, "M6": 360, "M10": 600, "M12": 720, "M15": 900,
              "M20": 1200, "M30": 1800, "H1": 3600, "H2": 7200, "H3": 10800, "H4": 14400, "H6": 21600, "H8": 28800,
              "H12": 43200, "D1": 86400}
V9_SECONDS = 120
_CLOCK = re.compile(r"(\d{1,2}):(\d{2})")
_COUNTDOWN = re.compile(r"(?:(\d{1,2}):)?(\d{1,2}):(\d{2})")


# The MT5 server clocks a journal account may have (its broker is his to name; review finding 3): New York + 7 h, as
# the bridge's broker and most MT5 brokers (the default), or a fixed offset all year.
SERVER_CLOCKS = ("ny+7", "gmt+2", "gmt+3", "gmt+0")
_FIXED_H = {"gmt+2": 2, "gmt+3": 3, "gmt+0": 0}


def server_to_utc(server: datetime, clock: str = "ny+7") -> datetime:
    """A naive server wall time (as MT5 prints it) in UTC, by the server's clock (SERVER_CLOCKS)."""
    if clock in _FIXED_H:
        return (server - timedelta(hours=_FIXED_H[clock])).replace(tzinfo=UTC)
    if clock != "ny+7":
        raise ValueError(f"server clock: one of {', '.join(SERVER_CLOCKS)}")
    return (server - SERVER_SHIFT).replace(tzinfo=NEW_YORK).astimezone(UTC)


def utc_to_server(at: datetime) -> datetime:
    """UTC as the MT5 server's naive wall time."""
    return at.astimezone(NEW_YORK).replace(tzinfo=None) + SERVER_SHIFT


def server_minus_melbourne_h(at: datetime) -> int:
    """The server clock minus the Melbourne clock at an instant, in hours (-8, -9 or -7 as the year turns)."""
    server = at.astimezone(NEW_YORK).utcoffset() + SERVER_SHIFT
    return int((server - at.astimezone(MELBOURNE).utcoffset()).total_seconds() // 3600)


def iso(value) -> datetime | None:
    if value is None or isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(UTC)
    except ValueError:
        return None


def phone_minute(text: str | None, ref: datetime) -> datetime | None:
    """The UTC start of the minute a 12-hour Melbourne clock reading ("11:37") names, nearest `ref`."""
    m = _CLOCK.fullmatch((text or "").strip())
    if not m or not 1 <= int(m.group(1)) <= 12 or int(m.group(2)) > 59:
        return None
    h, mi = int(m.group(1)) % 12, int(m.group(2))
    day = ref.astimezone(MELBOURNE).date()
    out = []
    for d in (day - timedelta(days=1), day, day + timedelta(days=1)):
        for hh in (h, h + 12):
            local = datetime(d.year, d.month, d.day, hh, mi, tzinfo=MELBOURNE)
            out.append(local.astimezone(UTC))
    return min(out, key=lambda t: abs((t - ref).total_seconds()))


def countdown_seconds(text: str | None) -> int | None:
    m = _COUNTDOWN.fullmatch((text or "").strip())
    if not m:
        return None
    h, mi, s = int(m.group(1) or 0), int(m.group(2)), int(m.group(3))
    return None if s > 59 or (m.group(1) and mi > 59) else h * 3600 + mi * 60 + s


def picture_time(phone: str | None, countdown: str | None, timeframe: str | None, file_time, received,
                 server_hint_utc: datetime | None = None) -> dict:
    """{"utc", "how" (countdown / phone_clock / file_time / upload_time), "about", "state" (green or amber), "notes"}."""
    mtime, got = iso(file_time), iso(received)
    notes: list[str] = []
    ref = mtime or server_hint_utc or got
    minute = phone_minute(phone, ref) if ref is not None else None
    if minute is None:
        if mtime is not None:
            return {"utc": mtime, "how": "file_time", "about": True, "state": "amber",
                    "notes": ["no phone clock: the file's own time"]}
        return {"utc": got, "how": "upload_time", "about": True, "state": "amber",
                "notes": ["no phone clock and no file time: the upload time"]}
    utc, how = minute + timedelta(seconds=30), "phone_clock"
    cd, tf = countdown_seconds(countdown), TF_SECONDS.get(timeframe or "")
    if cd is not None and tf:
        if cd >= tf:
            notes.append("countdown longer than the timeframe: not used")
        else:
            base = minute.timestamp()
            t = math.ceil((base + cd) / tf) * tf - cd
            if t < base + 60:
                utc, how = datetime.fromtimestamp(t, UTC), "countdown"
            else:
                notes.append("countdown and phone clock disagree: the phone clock is used")
    state = "amber"
    if mtime is not None:
        if abs((utc - mtime).total_seconds()) <= V9_SECONDS:
            state = "green"
        else:
            notes.append("phone clock and file time more than 2 minutes apart")
    else:
        notes.append("no file time to check the phone clock against")
    return {"utc": utc, "how": how, "about": False, "state": state, "notes": notes}


def _h12(t: datetime) -> str:
    return f"{t.hour % 12 or 12}:{t.minute:02d}"


def _ampm(t: datetime) -> str:
    return "am" if t.hour < 12 else "pm"


def fmt_lon_melb(at: datetime) -> str:
    """"12:10 London · 11:10 pm Melb." (D16)."""
    lon, mel = at.astimezone(LONDON), at.astimezone(MELBOURNE)
    return f"{lon:%H:%M} London · {_h12(mel)} {_ampm(mel)} Melb."


def fmt_range(a: datetime, b: datetime) -> str:
    """"15:08-15:20 London · 2:08-2:20 am Melb."."""
    la, lb, ma, mb = a.astimezone(LONDON), b.astimezone(LONDON), a.astimezone(MELBOURNE), b.astimezone(MELBOURNE)
    mel = (f"{_h12(ma)}-{_h12(mb)} {_ampm(mb)}" if _ampm(ma) == _ampm(mb)
           else f"{_h12(ma)} {_ampm(ma)}-{_h12(mb)} {_ampm(mb)}")
    return f"{la:%H:%M}-{lb:%H:%M} London · {mel} Melb."


_MONTHS = {m: i for i, m in enumerate(("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
                                       "Dec"), start=1)}
_LABEL = re.compile(r"(\d{1,2}) ([A-Z][a-z]{2}) (\d{2}):(\d{2})")


def label_times(labels, year: int) -> list[datetime]:
    """The chart's bottom time labels ("27 Oct 12:40", server time) as naive server datetimes; cut ones are left out."""
    out = []
    for text in labels or ():
        m = _LABEL.fullmatch(str(text).strip())
        if m and m.group(2) in _MONTHS:
            try:
                out.append(datetime(year, _MONTHS[m.group(2)], int(m.group(1)), int(m.group(3)), int(m.group(4))))
            except ValueError:
                continue
    return out


def trading_date(at: datetime) -> date:
    from app.timeutil import trading_day
    return trading_day(at)
