"""The picture reader, in two passes run by two units (docs/JOURNAL_DESIGN.md §4 "Reader trigger", §5.1, §5.3, §5.7,
D5, D7, D12, D13; fix rounds D-b and E: the key's process never decodes a picture and never opens the journal).
edge-desk-reader.timer starts both every 30 seconds; nothing watches a folder, so a picture that cannot be read never
restarts a unit. The send pass is app/photos/sender.py; this module is the local pass and everything it imports.

`python -m app reader --local` (edge-desk-reader-local.service: user edge, no key, no network) holds every decode and
every journal write:
1. it imports what the sender left in the results folder: its key's state (Settings), its ledger (one photo_spend row
   per finished call: its actual cost, or its ceiling when none came back), and each answer, which goes through the
   same checks, reconcile and proposal as before into one photo_read row; then the job leaves the outbox. A job the
   sender reserved a call for but never answered, once older than sender.STALE, gets the lines-only card and is never
   sent again; a job that will not be sent (the reader not "claude", the key not set or not working) leaves the
   outbox unsent (under the outbox lock) and its picture gets the lines-only card;
2. store.settle (a file in the inbox with no queued row waits in wait/; stale temporary files go), then picture trades
   the bridge's history now holds are linked to it, whatever [photos] reader says (trades.link_to_bridge);
3. with [photos] reader "off": nothing more. Otherwise each queued picture (and each one due again) is claimed: its file
   leaves the inbox for the store at once; retries go through photo.next_try_utc;
4. the local pass sorts it (the free pre-filter): a TradingView picture is kept as an analysis look, another app's is not
   read, landscape / light / cropped / too-small pictures get their messages, an MT5 chart with no trade lines is a
   look (unless he tapped "Read it"), a History picture is read here; a picture of a bridge trade is linked to it with
   the bridge's values and no paid read;
5. when a paid read is due (an MT5 chart with all three MT5 signs and no notification banner, reader "claude", a key
   the sender did not report missing or refused, room under the monthly cap in the sender's ledger, and no earlier
   paid read of this picture whose pass broke), the exact bytes to send (the crop, or one History row's band) go into
   the outbox as a job "<photo id>-<claim>" with the local pass beside them, and the picture holds no expiring claim
   while its job waits (next_try_utc empty); otherwise the reading is written here.
Journal accounts (30 Oct 2026, docs/JOURNAL_DESIGN.md section 16): a picture sent to a journal account (photo.account_id)
is read here from its lines only, whatever [photos] reader says ("off" included: step 3 then claims journal accounts'
pictures only), and is never sent for the paid read (no outbox job; a job found for one is dropped unsent). Its card
holds each line's price with a state (amber: one source, the axis fit; red: a doubtful fit, V3), the pair read from the
picture's label (red when not read: he types it), and the live price for the order kind. It is never matched to a
bridge trade; a History picture of it closes only its own account's trades, its times read by that account's server
clock (app/journal/accounts.py), which the reading keeps.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import logging
import os
import time as _time
from datetime import datetime, timedelta
from pathlib import Path

from app import db
from app.photos import checks, claude, clocks, match, sender, store
from app.timeutil import from_iso, to_iso, trading_day

log = logging.getLogger("edge.reader")
READER_VERSION = "p2c-3"
RETRY_MINUTES = (2, 10, 30)
CLAIM_HOLD = timedelta(minutes=10)          # a claimed picture whose pass died is read again after this
SLOW = timedelta(minutes=5)
BATCH = 10
MAX_ATTEMPTS = 6                            # claims of one picture; a pass that breaks each time then ends failed
KEY_STATE, KEY_FP = "photos.key_state", "photos.key_fp"
DRAFT = "Read from your picture. Check the dots."
TAPS = "Read from the lines only: tap each line"
NOT_READ = "This picture could not be read: tap each line"
LOOK_MT5 = "No trade lines on this chart. If the trade has closed, send the History picture for this trade."
NOT_MT5 = "Saved as a look: this isn't an MT5 chart."
HISTORY_TYPE = "Read on this server, but a number did not pass its check: type the exit price, close time and profit."
HISTORY_NONE = "No open picture trade matches these rows."
SLOW_TEXT = "Reading is slow: check the server"
PRIVACY = "a message showed on the picture: nothing more is sent from it"
STOPPED = "the paid read was stopped mid-call: not sent again"
SET_ASIDE = "its answer could not be imported: lines only"
JOURNAL_LINES = "a journal account's picture: read from its lines on this server only"
IMPORT_TRIES = 3                            # an answer that fails to import this often is set aside
JOB_SEQ, IMPORT_FAIL = "photos.job_seq", "photos.import_fail:"
QUEUED = object()                           # the local pass left the bytes in the outbox


def _meta_get(conn, key: str) -> str | None:
    r = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return r[0] if r else None


def _meta_set(conn, key: str, value: str) -> None:
    conn.execute("INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                 (key, value))


def key_state(conn) -> str:
    """"set", "not_set" or "not_working" (what Settings shows; never the key)."""
    return _meta_get(conn, KEY_STATE) or "not_set"


def record_key(conn, key: str | None, now: datetime) -> str:
    """The journal's copy of the key's state, as the sender would record it (the local pass imports the sender's own
    record, sender.key_state; the tests and the evaluation set it directly). A key that failed (401/403) stays "not
    working" until it changes: only a short hash of it is kept to notice that."""
    fp = hashlib.sha256(key.encode()).hexdigest()[:16] if key else ""
    with db.transaction(conn):
        before = (_meta_get(conn, KEY_STATE), _meta_get(conn, KEY_FP))
        state = key_state(conn)
        if not key:
            state = "not_set"
        elif before[1] != fp or state == "not_set":
            state = "set"
        if (state, fp) != before:                   # the send pass runs every 30 seconds: write only a change
            _meta_set(conn, KEY_STATE, state)
            _meta_set(conn, KEY_FP, fp)
    return state


def _failed_paid_pass(conn, photo_id: int) -> bool:
    """A paid call for this picture whose pass never wrote its reading: never paid for again."""
    return conn.execute("SELECT 1 FROM photo_spend s WHERE s.photo_id = ? AND NOT EXISTS (SELECT 1 FROM photo_read r"
                        " WHERE r.photo_id = s.photo_id AND r.job = s.job) LIMIT 1", (photo_id,)).fetchone() \
        is not None


def _due(conn, now: datetime, journal_only: bool = False) -> list[dict]:
    only = " AND account_id IS NOT NULL" if journal_only else ""
    return [dict(r) for r in conn.execute(
        "SELECT * FROM photo WHERE (state = 'queued' OR (state = 'reading' AND next_try_utc IS NOT NULL"
        " AND next_try_utc <= ?))" + only + " ORDER BY received_utc, id", (to_iso(now),))]


def _journal_waiting(conn) -> bool:
    """A journal account's picture to read or reading (read whatever [photos] reader says)."""
    return conn.execute("SELECT 1 FROM photo WHERE account_id IS NOT NULL AND state IN ('queued','reading') LIMIT 1"
                        ).fetchone() is not None


def _claim(conn, folder, row: dict, now: datetime) -> bool:
    """The file leaves the watched inbox first (an atomic rename into the store), then the row says "reading"."""
    dest = store.path_of(folder, {**row, "state": "reading"})
    if row["state"] == "queued":
        src = store.path_of(folder, row)
        if src.exists():
            dest.parent.mkdir(parents=True, exist_ok=True)
            os.chmod(dest.parent, 0o700)
            os.replace(src, dest)
    if not dest.exists():
        with db.transaction(conn):
            conn.execute("UPDATE photo SET state = 'failed' WHERE id = ?", (row["id"],))
        return False
    with db.transaction(conn):
        conn.execute("UPDATE photo SET state = 'reading', attempts = attempts + 1, next_try_utc = ? WHERE id = ?",
                     (to_iso(now + CLAIM_HOLD), row["id"]))
    return True


def _gz(obj) -> bytes | None:
    return None if obj is None else gzip.compress(json.dumps(obj, default=str).encode())


def _f(value, state="green", source="bridge", note=""):
    return checks.field(value, state, source, note)


def _label(side, lots, price, at: datetime | None) -> str:
    text = f"{(side or '').capitalize()} {lots:g} · {price:.5f}"
    if at is not None:
        lon = at.astimezone(clocks.LONDON)
        text += f" · {lon:%a} {clocks.fmt_lon_melb(at)}"
    return text


def look_text(at: datetime) -> str:
    d = trading_day(at)
    return f"Saved as your analysis look for {d:%a} {d.day} {d:%b}. Its marks aren't read yet."


def _bridge_draft(conn, cfg, found: list[dict]) -> dict:
    b = found[0]
    fields = {"side": _f(b["side"]), "lots": _f(b["volume"]), "entry": _f(b["open_price"]),
              "sl": _f(b["initial_sl"]), "tp": _f(b["initial_tp"]),
              "order_kind": _f(None, "amber", "none", "the bridge has the order")}
    cands = [{"ref": f"mt5:{t['id']}", "label": _label(t["side"], t["volume"], t["open_price"],
                                                        from_iso(t["open_utc"]))} for t in found]
    return {"trades": [{"role": "position", "index": 0, "fields": fields, "moved": False, "first_stop_ok": False,
                        "first_stop_from_order": False}],
            "proposal": {"ref": cands[0]["ref"]} if len(found) == 1 else {"ref": None},
            "candidates": cands if len(found) > 1 else [], "bridge": True}


def _proposal(conn, cfg, res: dict, at: datetime) -> tuple[dict, list]:
    if not res["trades"]:
        return {"ref": "new"}, []
    t = res["trades"][0]
    f = {n: t["fields"][n]["value"] for n in ("side", "lots", "entry", "sl")}
    if None in (f["side"], f["lots"], f["entry"]):
        return {"ref": "new"}, []
    bridge = match.bridge_candidates(conn, cfg, side=f["side"], lots=f["lots"], price=f["entry"], at=at, stop=f["sl"],
                                     moved=t["moved"])
    cands = [{"ref": f"mt5:{b['id']}", "label": _label(b["side"], b["volume"], b["open_price"],
                                                        from_iso(b["open_utc"]))} for b in bridge]
    if len(bridge) == 1:
        return {"ref": cands[0]["ref"], "label": cands[0]["label"]}, []
    pics = match.picture_candidates(conn, cfg, side=f["side"], lots=f["lots"], entry=f["entry"], at=at)
    cands += [{"ref": f"photo:{p['id']}", "label": "Same trade as " + _label(p["side"], p["lots"], p["entry"],
                                                                              match._seen_from(conn, p))} for p in pics]
    if len(cands) == 1:
        return {"ref": cands[0]["ref"], "label": cands[0]["label"]}, []
    if cands:
        return {"ref": None}, cands
    return {"ref": "new"}, []


def _duplicate(conn, photo_id: int, res: dict, at: datetime) -> int | None:
    """V13: another picture of the same minute with the same values."""
    if not res["trades"]:
        return None
    mine = {n: res["trades"][0]["fields"][n]["value"] for n in ("side", "lots", "entry", "sl", "tp")}
    minute = to_iso(at)[:16]
    for r in conn.execute("SELECT p.id, (SELECT merged_json FROM photo_read WHERE photo_id = p.id ORDER BY id DESC"
                          " LIMIT 1) AS merged FROM photo p WHERE p.id != ? AND substr(p.picture_utc, 1, 16) = ?"
                          " AND p.state NOT IN ('deleted','failed')", (photo_id, minute)):
        other = json.loads(r["merged"] or "{}").get("trades") or []
        if other and {n: other[0]["fields"].get(n, {}).get("value") for n in mine} == mine:
            return r["id"]
    return None


class _LocalCtx:
    """The local pass: decides, and leaves the exact bytes of a paid read in the outbox (no key, no network)."""
    mode = "local"

    def __init__(self, folder, crop, base):
        self.folder, self.crop, self.base, self.data = folder, crop, base, None

    def paid_ok(self, conn, cfg, row, now) -> tuple[bool, str]:
        if row.get("account_id") is not None:
            return False, JOURNAL_LINES                 # never the paid read (30 Oct 2026)
        if cfg.photos.reader != "claude":
            return False, "reader local"
        state = _meta_get(conn, KEY_STATE)          # never recorded yet (a fresh install): the sender decides
        if state in ("not_set", "not_working"):
            return False, f"key {state.replace('_', ' ')}"
        return _room(conn, cfg, row, now, self.base)

    def paid(self, conn, cfg, row, now, kind, box, note, loc, band_row=None):
        png = self.crop(self.data, box)
        with sender.outbox_lock(self.base, create=True):
            started = {c["job"] for c in sender.ledger_calls(self.base).values()}
            for old in sender.jobs(self.base):          # an earlier claim's unsent job of this picture never goes
                if old["photo_id"] == row["id"] and old["job"] not in started:
                    sender.remove_job(self.base, old["job"])
            sender.write_job(self.base, row, kind, png, note, loc, band_row, job=_new_job(conn, self.base, row))
        with db.transaction(conn):                  # no expiring claim while its job waits
            conn.execute("UPDATE photo SET next_try_utc = NULL WHERE id = ?", (row["id"],))
        return QUEUED


class _AnswerCtx:
    """An answer the sender left in the results folder, taken through the same decisions."""
    mode = "answer"

    def __init__(self, answer: dict, job: dict):
        self.answer, self.job = answer, job

    def paid_ok(self, conn, cfg, row, now) -> tuple[bool, str]:
        if self.answer.get("outcome") == "cap":
            return False, "monthly cap"
        return True, ""

    def paid(self, conn, cfg, row, now, kind, box, note, loc, band_row=None):
        if kind != self.job.get("kind") or band_row != self.job.get("band_row"):
            return None                              # the decision changed since the job was left: not used
        return sender.reading_of(self.answer)


class _LinesCtx:
    """A job that will not be sent: the lines-only card, with the reason."""
    mode = "lines"

    def __init__(self, why: str):
        self.why = why

    def paid_ok(self, conn, cfg, row, now) -> tuple[bool, str]:
        return False, self.why

    def paid(self, *a, **k):
        return None


def _new_job(conn, base, row) -> str:
    """A job name never used before (fix round F: a picture sent again after it was deleted restarts at claim 1):
    "<photo id>-<n>", n from the journal's counter, past any name the reader folders hold."""
    used = {j["job"] for j in sender.jobs(base)} | sender.answered(base) | {
        c["job"] for c in sender.ledger_calls(base).values() if c["job"]}
    with db.transaction(conn):
        n = int(_meta_get(conn, JOB_SEQ) or 0)
        while True:
            n += 1
            name = f"{row['id']}-{n}"
            if name not in used:
                break
        _meta_set(conn, JOB_SEQ, str(n))
    return name


def _privacy_flagged(conn, photo_id: int) -> bool:
    """A reading of this picture said a notification or message showed on it (fix round item 1)."""
    return conn.execute("SELECT 1 FROM photo_read WHERE photo_id = ? AND merged_json LIKE '%\"privacy_flag\": true%'"
                        " LIMIT 1", (photo_id,)).fetchone() is not None


def _room(conn, cfg, row, now, base) -> tuple[bool, str]:
    if _privacy_flagged(conn, row["id"]):
        return False, PRIVACY
    if _failed_paid_pass(conn, row["id"]):
        return False, "an earlier paid read of this picture was paid but its pass broke: not sent again"
    if not sender.may_spend(base, cfg, now):
        return False, "monthly cap"
    return True, ""


def _new_w() -> dict:
    return {"state": "read", "kind": "other", "outcome": "look", "message": "", "merged": {}, "checks": [],
            "reading": None, "vision": None, "error": "", "next_try": None, "picture": None, "effort": None,
            "queued": False, "outage": False, "privacy": False}


def run_local(conn, cfg, folder, now: datetime, *, analyse=None, crop=None, base=None) -> list[str]:
    """The local pass (edge-desk-reader-local.service): no key, no network; every decode and every journal write."""
    if not cfg.photos.enabled:
        return ["reader: pictures are off"]
    base = Path(base) if base is not None else sender.base_for(folder)
    try:
        out = import_sender(conn, cfg, folder, now, base)
    except Exception as exc:  # noqa: BLE001 - the rest of the pass (settle, the bridge links, new pictures) still runs
        log.exception("reader: the sender's results could not be imported")
        out = [f"reader: could not import the sender's results ({type(exc).__name__}): the rest of the pass runs"]
    store.settle(conn, cfg, folder, now)
    from app.photos import trades
    for tid, bid in trades.link_to_bridge(conn, cfg, now):
        out.append(f"reader: picture trade {tid} linked to bridge trade {bid}")
    journal_only = cfg.photos.reader == "off"
    if journal_only and not _journal_waiting(conn):
        return out + ["reader: off ([photos] reader)"]
    if journal_only:
        out.append("reader: off ([photos] reader): journal accounts' pictures only, from their lines")
    only = " AND account_id IS NOT NULL" if journal_only else ""
    waiting_jobs = {(j["photo_id"], j["attempts"]) for j in sender.jobs(base)}
    with db.transaction(conn):
        gone = conn.execute("UPDATE photo SET state = 'failed', next_try_utc = NULL WHERE state = 'reading'"
                            " AND attempts >= ? AND next_try_utc <= ?" + only, (MAX_ATTEMPTS, to_iso(now))).rowcount
        for r in conn.execute("SELECT id, attempts FROM photo WHERE state = 'reading' AND next_try_utc IS NULL" + only
                              ).fetchall():
            if (r["id"], r["attempts"]) not in waiting_jobs:   # its job is gone: read it again
                conn.execute("UPDATE photo SET next_try_utc = ? WHERE id = ?", (to_iso(now), r["id"]))
    if gone:
        out.append(f"reader: {gone} picture(s) failed after {MAX_ATTEMPTS} tries")
    due = _due(conn, now, journal_only)[:BATCH]
    if not due:
        return out + ["reader: nothing to read"]
    if analyse is None or crop is None:
        from app.photos import local               # Pillow and numpy: the reader's own virtualenv only
        analyse, crop = analyse or local.analyse, crop or local.crop_png
    ctx = _LocalCtx(folder, crop, base)
    for row in due:
        try:
            out.append(_one_local(conn, cfg, folder, row, now, ctx, analyse))
        except Exception:  # noqa: BLE001 - one bad picture never stops the pass; it is read again after CLAIM_HOLD
            log.exception("reader: picture %s failed", row["id"])
            out.append(f"reader: picture {row['id']}: error (kept for a retry)")
    return out


def import_sender(conn, cfg, folder, now: datetime, base=None) -> list[str]:
    """Step 1 of the local pass: the sender's key state, answers and ledger into the journal; jobs that are done,
    stopped mid-call or will not be sent leave the outbox. Everything in the results folder is untrusted input
    (sender.read_file, clean_answer, ledger). The answers are read before the ledger: an answer is written only after
    its call's "actual" line, so a call is never imported at its ceiling when its cost was already written."""
    base = Path(base) if base is not None else sender.base_for(folder)
    out = []
    ks = sender.key_state(base)
    if ks and (_meta_get(conn, KEY_STATE), _meta_get(conn, KEY_FP)) != (ks["state"], ks.get("fp", "")):
        with db.transaction(conn):
            _meta_set(conn, KEY_STATE, ks["state"])
            _meta_set(conn, KEY_FP, ks.get("fp", ""))
    waiting = sender.jobs(base)
    answers = sender.results(base, only={j["job"] for j in waiting})   # before the ledger: see the docstring
    calls, broken = sender.ledger(base, now=now)
    for month in broken:
        out.append(f"reader: the ledger for {month} could not be read: no paid read starts this month")
    for c in calls.values():                         # the ledger: one row per finished call, once
        if not c["job"] or c["photo_id"] is None:
            continue
        at = _fallback_at(c, now)
        stale = c["bad"] or now - from_iso(at) > sender.STALE
        if c["actual"] is None and c["job"] not in answers and not stale:
            continue                                 # still in flight
        if conn.execute("SELECT 1 FROM photo WHERE id = ?", (c["photo_id"],)).fetchone() is None:
            continue
        with db.transaction(conn):
            conn.execute("INSERT OR IGNORE INTO photo_spend (photo_id, job, call, made_utc, max_tokens, usage_json,"
                         " usd_est, error) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                         (c["photo_id"], c["job"], c["call"], min(at, to_iso(now)), c["max_tokens"] or 0,
                          json.dumps(c["attempts"]),
                          round(sender.call_cost(c, cfg), 6),
                          "a ledger line was not clean: its ceiling" if c["bad"] else c["error"] or (
                              "" if c["actual"] is not None else "no usage: its ceiling")))
    started: dict = {}
    for c in calls.values():
        if c["job"]:
            at = _fallback_at(c, now)
            started[c["job"]] = min(started.get(c["job"], at), at)
    for job in waiting:
        name = job["job"]
        try:
            row = conn.execute("SELECT * FROM photo WHERE id = ?", (job.get("photo_id"),)).fetchone()
            row = dict(row) if row is not None else None
            live = row is not None and row["state"] == "reading" and row["attempts"] == job.get("attempts")
            if row is not None and row.get("account_id") is not None:    # never paid for (30 Oct): dropped unsent
                with sender.outbox_lock(base, create=True):
                    sender.remove_job(base, name)
                if live:
                    out.append(_lines_only(conn, cfg, row, now, job, JOURNAL_LINES))
                continue
            if name in answers:
                done = row is not None and conn.execute("SELECT 1 FROM photo_read WHERE photo_id = ? AND job = ?",
                                                        (row["id"], name)).fetchone()
                if live and not done:
                    out.append(_import_answer(conn, cfg, row, now, job, answers[name]))
                sender.remove_job(base, name)
                _forget_failures(conn, name)
                continue
            if name in started:
                if now - from_iso(started[name]) > sender.STALE:
                    if live:
                        out.append(_lines_only(conn, cfg, row, now, job, STOPPED))
                    sender.remove_job(base, name)
                continue
            why = None
            if not live:
                why = "superseded"
            elif cfg.photos.reader != "claude":
                why = "reader local"
            elif _meta_get(conn, KEY_STATE) in ("not_set", "not_working"):
                why = f"key {_meta_get(conn, KEY_STATE).replace('_', ' ')}"
            if why is None:
                continue                             # it waits for the sender
            with sender.outbox_lock(base, create=True):
                if any(c["job"] == name for c in sender.ledger_calls(base).values()):
                    continue                         # the sender reserved it meanwhile: its answer will come
                sender.remove_job(base, name)
            if live:
                out.append(_lines_only(conn, cfg, row, now, job, why))
        except Exception:  # noqa: BLE001 - its answer and job stay; after IMPORT_TRIES it is set aside
            log.exception("reader: the answer for %s could not be imported", name)
            out.append(f"reader: picture {job.get('photo_id')}: error importing its answer (kept)")
            out += _count_failure(conn, cfg, now, base, job)
    return out


def _fallback_at(c: dict, now: datetime) -> str:
    """A call's time: its clean reservation time, else the earlier of its file's month start and now minus STALE (a
    file named for a month ahead, from a sender whose clock ran ahead, never holds a picture or dates a cost ahead)."""
    if c["at"]:
        return c["at"]
    return min(f"{c['month']}-01T00:00:00Z", to_iso(now - sender.STALE - timedelta(seconds=1)))   # already stale


def _forget_failures(conn, name: str) -> None:
    if _meta_get(conn, IMPORT_FAIL + name) is not None:
        with db.transaction(conn):
            conn.execute("DELETE FROM meta WHERE key = ?", (IMPORT_FAIL + name,))


def _count_failure(conn, cfg, now, base, job) -> list[str]:
    """One more failed import of this job's answer; at IMPORT_TRIES the answer is set aside (its picture gets the
    lines-only card and the job leaves the outbox, so the sender drops the answer): one bad file never stops a pass."""
    name = job["job"]
    with db.transaction(conn):
        n = int(_meta_get(conn, IMPORT_FAIL + name) or 0) + 1
        _meta_set(conn, IMPORT_FAIL + name, str(n))
    if n < IMPORT_TRIES:
        return []
    out = []
    try:
        row = conn.execute("SELECT * FROM photo WHERE id = ?", (job.get("photo_id"),)).fetchone()
        if row is not None and row["state"] == "reading" and row["attempts"] == job.get("attempts"):
            out.append(_lines_only(conn, cfg, dict(row), now, job, SET_ASIDE))
    except Exception:  # noqa: BLE001 - the job still leaves the outbox
        log.exception("reader: the lines-only card for %s could not be written", name)
    sender.remove_job(base, name)
    _forget_failures(conn, name)
    return out + [f"reader: picture {job.get('photo_id')}: its answer set aside after {IMPORT_TRIES} tries"]


def _import_answer(conn, cfg, row, now, job, answer) -> str:
    w = _new_w()
    _process(conn, cfg, row, now, job["loc"], w, _AnswerCtx(answer, job))
    _write(conn, row, job["loc"], w, int(answer.get("ms") or 0), now, job=job["job"])
    return f"reader: picture {row['id']}: {w['outcome']} ({w['kind']})"


def _lines_only(conn, cfg, row, now, job, why: str) -> str:
    w = _new_w()
    _process(conn, cfg, row, now, job["loc"], w, _LinesCtx(why))
    if why in (STOPPED, SET_ASIDE):
        w["error"] = why
    _write(conn, row, job["loc"], w, 0, now)
    return f"reader: picture {row['id']}: {w['outcome']} ({w['kind']})"


def run_once(conn, cfg, folder, now: datetime, *, key=None, client=None, sdk=None, analyse=None, crop=None,
             base=None) -> list:
    """Both passes in one process, for the tests and the evaluation's dry run only; the units run them apart, as two
    users: the sender (its key's state first), the local pass, the sender, and the local pass's import."""
    base = Path(base) if base is not None else sender.base_for(folder)
    out = sender.run_send(cfg, base, now, key=key, client=client, sdk=sdk)[:1]
    out += run_local(conn, cfg, folder, now, analyse=analyse, crop=crop, base=base)
    if cfg.photos.enabled:
        out += [ln for ln in sender.run_send(cfg, base, now, key=key, client=client, sdk=sdk)[1:]
                if ln.startswith("reader: picture") or "API" in ln or "time is up" in ln]
        out += import_sender(conn, cfg, folder, now, base)
    return out


def _photo_row(conn, photo_id: int) -> dict:
    return dict(conn.execute("SELECT * FROM photo WHERE id = ?", (photo_id,)).fetchone())


def _one_local(conn, cfg, folder, row: dict, now: datetime, ctx: _LocalCtx, analyse) -> str:
    t0 = _time.monotonic()
    if not _claim(conn, folder, row, now):
        return f"reader: picture {row['id']}: file missing"
    row = _photo_row(conn, row["id"])
    ctx.data = store.path_of(folder, row).read_bytes()
    try:
        loc = analyse(ctx.data)
        w = _new_w()
        _process(conn, cfg, row, now, loc, w, ctx)
    finally:
        ctx.data = None
    if w["queued"]:
        return f"reader: picture {row['id']}: to send ({w['kind']})"
    _write(conn, row, loc, w, int((_time.monotonic() - t0) * 1000), now)
    return f"reader: picture {row['id']}: {w['outcome']} ({w['kind']})"


def _process(conn, cfg, row: dict, now: datetime, loc: dict, w: dict, ctx) -> None:
    problem, kind = loc.get("problem"), loc.get("kind")
    if problem in ("metadata", "broken", "too_large"):
        w.update(state="failed", outcome="failed", message=loc.get("message") or NOT_READ, error=problem)
    elif problem:
        w.update(state="rejected", outcome="not_read", message=loc.get("message") or "", error=problem)
    elif kind == "look_tradingview":
        at = clocks.iso(row["file_mtime_utc"]) or clocks.iso(row["received_utc"])
        w.update(kind="look_tradingview", message=look_text(at))
    elif kind == "other":
        w.update(state="rejected", outcome="not_read", message=loc.get("message") or "This isn't an MT5 chart:"
                                                                                     " not read.")
    elif kind == "history":
        _history(conn, cfg, row, now, loc, w, ctx)
    else:
        _chart(conn, cfg, row, now, loc, w, ctx)


def _chart(conn, cfg, row, now, loc, w, ctx) -> None:
    t = clocks.picture_time(loc.get("phone_clock"), loc.get("countdown"), loc.get("timeframe"), row["file_mtime_utc"],
                            row["received_utc"])
    at = t["utc"]
    w["picture"] = (to_iso(at), t["how"] + (" about" if t["about"] else ""))
    w["kind"] = "chart"
    if loc.get("kind") == "look_mt5" and row.get("kind") != "chart":
        w.update(kind="look_mt5", message=LOOK_MT5)
        return
    if row.get("account_id") is not None:              # a journal account: its lines only, never a bridge trade
        _journal_taps(cfg, loc, at, t, match.quote_at(conn, at), w)
        return
    bridge = match.bridge_by_lines(conn, cfg, loc.get("lines") or [], at)
    if bridge:
        w["merged"] = {**_bridge_draft(conn, cfg, bridge), "lines": loc.get("lines") or [],
                       "fields": {"symbol": _f("EURUSD")}}
        w.update(outcome="draft", message=DRAFT)
        return
    signs_ok = all((loc.get("signs") or {}).values()) and not loc.get("banner")
    paid, why = ctx.paid_ok(conn, cfg, row, now)
    oanda = match.quote_at(conn, at)
    balance = cfg.funded.initial_balance if isinstance(cfg.funded.initial_balance, (int, float)) else None

    def taps(error: str) -> None:
        res = checks.reconcile(cfg, loc, None, picture_utc=at, oanda=oanda, balance=balance, time=t)
        w.update(state="needs_taps", outcome="needs_taps", message=TAPS, merged=res, checks=res["checks"], error=error)
    if not signs_ok:
        taps("not all three MT5 signs or a banner: not sent")
        return
    if not paid:
        taps(why)
        return
    r = ctx.paid(conn, cfg, row, now, "chart", loc["crop"], claude.note_for(loc.get("phone_clock"),
                                                                            row["file_mtime_utc"]), loc)
    if r is QUEUED:
        w["queued"] = True
        return
    if r is None:
        taps("no API client")
        return
    w.update(reading=r, effort=cfg.photos.effort)
    if _paid_failed(conn, row, now, r, w):
        res = checks.reconcile(cfg, loc, None, picture_utc=at, oanda=oanda, balance=balance, time=t)
        if w["outcome"] != "retry":
            w.update(merged=res, checks=res["checks"])
        return
    v = r.vision
    w["vision"] = v
    w["privacy"] = _says_privacy(v)
    if v.get("platform") != "mt5_mobile" or v.get("screen") != "chart":
        w.update(kind="look_mt5", message=NOT_MT5, error=f"pre-filter miss: the reading says {v.get('platform')}"
                                                         f" {v.get('screen')}")
        log.warning("reader: picture %s: pre-filter miss", row["id"])
        return
    res = checks.reconcile(cfg, loc, v, picture_utc=at, oanda=oanda, balance=balance, time=t)
    if res["status"] != "ok":
        w.update(state="rejected", outcome="not_read", message=res["message"], merged=res, checks=res["checks"])
        return
    proposal, cands = _proposal(conn, cfg, res, at)
    dup = _duplicate(conn, row["id"], res, at)
    res["checks"].append({"id": "V13", "ok": dup is None, "note": "" if dup is None else f"same as picture {dup}"})
    res.update(proposal=proposal, candidates=cands, duplicate_of=dup, live_bid=res["fields"].get("live_bid",
                                                                                                 {}).get("value"))
    if res["needs_taps"]:
        w.update(state="needs_taps", outcome="needs_taps", message=TAPS)
    else:
        w.update(outcome="draft", message=DRAFT)
    w.update(merged=res, checks=res["checks"])


def _journal_taps(cfg, loc: dict, at, t: dict, oanda, w: dict) -> None:
    """A journal account's card: every line with its price and state (amber: one source; red: the axis fit is in
    doubt, V3), the pair from the picture's label (red when not read: he types it) and the live price."""
    res = checks.reconcile(cfg, loc, None, picture_utc=at, oanda=oanda, balance=None, time=t)
    ok = checks.axis_fits(loc)
    note = "" if ok else checks.AXIS_NOTE
    res["checks"].append({"id": "V3", "ok": ok, "note": note})
    res["fields"]["axis"] = checks.field((loc.get("axis") or {}).get("max_err_pips"), "amber" if ok else "red",
                                         "lines", note)
    for ln in res["lines"]:
        ln["state"] = "amber" if ok else "red"
    sym = checks.base_symbol(loc.get("symbol"))
    if sym is not None and not checks.fx_pair(sym):     # a metal or a coin: he types the currency pair, if it is one
        sym = None
    res["symbol"] = sym
    res["fields"]["symbol"] = checks.field(sym, "amber" if sym else "red", "lines" if sym else "none",
                                           "" if sym else "not read: type the pair")
    res["live_bid"] = (loc.get("live_tag") or {}).get("price")
    res["journal"] = True
    w.update(state="needs_taps", outcome="needs_taps", message=TAPS, merged=res, checks=res["checks"],
             error=JOURNAL_LINES)


def _says_privacy(v: dict | None) -> bool:
    return bool(((v or {}).get("privacy") or {}).get("notification_or_message_visible"))


def _paid_failed(conn, row, now, r, w) -> bool:
    """A paid read that gave no reading: its path (§5.3). True when the lines-only card (or a retry) follows."""
    if r.outcome == "ok":
        return False
    w.update(state="needs_taps", outcome="needs_taps", message=TAPS)
    if r.outcome == "refused":
        w.update(message=NOT_READ, error=f"refusal: {r.category}")
    elif r.outcome == "stop_key":
        with db.transaction(conn):
            _meta_set(conn, KEY_STATE, "not_working")
        w["error"] = f"key refused ({r.error}): paid reads stopped"
    elif r.outcome == "bad_request":
        w["error"] = f"bad request {r.request_id or ''} ({r.error})"
    elif r.outcome == "retry":
        w["outage"] = True
        tries = conn.execute("SELECT COUNT(*) FROM photo_read WHERE photo_id = ? AND outcome = 'retry'",
                             (row["id"],)).fetchone()[0]
        if tries < len(RETRY_MINUTES):
            w.update(state="reading", outcome="retry", message="Reading your picture…",
                     next_try=now + timedelta(minutes=RETRY_MINUTES[tries]), error=f"{r.error}: again later")
        else:
            w["error"] = f"{r.error}: three retries"
    else:
        w["error"] = f"{r.outcome}: {r.error}"
    return True


def _history(conn, cfg, row, now, loc, w, ctx) -> None:
    """A History picture: read on this server. A row that failed a check is sent (its band only) when he tapped it open,
    it matches an open picture trade and its band is clean (clipped halfway to its neighbours, no summary line or panel
    inside: local.history_band); otherwise he types the numbers."""
    w["kind"] = "history"
    acct = row.get("account_id")                       # a journal account's History: its own trades only
    from app.journal import accounts
    clock = accounts.server_clock(conn, acct)           # its server's clock now; kept with this reading
    rows = [dict(r) for r in (loc.get("history") or {}).get("rows") or []]
    bad = [k for k, r in enumerate(rows) if not r.get("ok")]
    sendable = [k for k in bad if rows[k].get("tapped") and rows[k].get("band")
                and match.history_candidates(conn, cfg, rows[k], account_id=acct, clock=clock)]
    if sendable:
        paid, why = ctx.paid_ok(conn, cfg, row, now)
        if not (paid and cfg.photos.history_paid_read):
            w.update(state="needs_taps", outcome="needs_taps", message=HISTORY_TYPE,
                     error=why if cfg.photos.history_paid_read else "history_paid_read is off")
        else:
            k = sendable[0]
            r = ctx.paid(conn, cfg, row, now, "history", rows[k]["band"], claude.note_for(None, row["file_mtime_utc"]),
                         loc, band_row=k)
            if r is QUEUED:
                w["queued"] = True
                return
            if r is None:
                w.update(state="needs_taps", outcome="needs_taps", message=HISTORY_TYPE, error="no API client")
            else:
                w.update(reading=r, effort=cfg.photos.effort)
                w["privacy"] = r.outcome == "ok" and _says_privacy(r.vision)
                vrows = ((r.vision or {}).get("history") or {}).get("rows") or [] if r.outcome == "ok" else []
                if vrows:
                    v = vrows[0]
                    rows[k].update({n: v.get(n) for n in ("symbol", "side", "lots", "open_price", "close_price",
                                                          "close_time", "profit", "open_time", "sl", "tp",
                                                          "commission", "swap")}, ok=True, problems=[],
                                   source="vision")
                    w["vision"] = r.vision
                else:
                    _paid_failed(conn, row, now, r, w)
                    if w["outcome"] != "retry":
                        w.update(state="needs_taps", outcome="needs_taps", message=HISTORY_TYPE)
    from app.photos import trades as photo_trades
    pip = cfg.instrument.pip_size
    rows_out = [{k: v for k, v in r.items() if k != "band"} for r in rows]
    closes, cands, type_rows = [], [], []
    for k, r in enumerate(rows_out):
        try:
            found = match.history_candidates(conn, cfg, r, loose=not r.get("ok"), account_id=acct, clock=clock)
        except ValueError:
            found = []
        if not r.get("ok"):              # he types this row's numbers (item 14): the trades it may close
            type_rows.append({"row": k, "candidates": [{"ref": f"photo:{t['id']}", "label": _label(
                t["side"], t["lots"], t["entry"], match.seen_times(conn, t)[0])} for t in found]})
            continue
        for t in found:
            item = {"row": k, "ref": f"photo:{t['id']}", "label": f"Closes {_label(t['side'], t['lots'], t['entry'], None)}?",
                    "ask_first_stop": photo_trades.ask_first_stop(t, r, pip)}
            (closes if len(found) == 1 else cands).append(item)
    w["merged"] = {"kind": "history", "status": "ok", "symbol": (rows_out[0].get("symbol") if rows_out else None),
                   "trades": [], "lines": [], "fields": {}, "history_rows": rows_out, "closes": closes,
                   "candidates": cands, "type_rows": type_rows}
    if acct is not None:
        w["merged"]["server_clock"] = clock             # a later change of the account's clock never moves these
    if w["outcome"] in ("needs_taps", "retry"):
        return
    if closes or cands:
        w.update(state="read", outcome="draft", message="Read on this server. Check the close.")
    elif bad:
        w.update(state="needs_taps", outcome="needs_taps", message=HISTORY_TYPE)
    else:
        w.update(state="read", outcome="look", message=HISTORY_NONE)


def _write(conn, row, loc, w, ms: int, now: datetime, job: str | None = None) -> None:
    r = w["reading"]
    merged = dict(w["merged"] or {})
    merged.setdefault("kind", w["kind"])
    merged.setdefault("status", "ok")
    merged.setdefault("trades", [])
    merged.setdefault("lines", loc.get("lines") or [])
    merged["message"] = w["message"]
    if w.get("privacy"):
        merged["privacy_flag"] = True
        w["error"] = "; ".join(x for x in (PRIVACY, w["error"]) if x)
        log.warning("reader: picture %s: %s", row["id"], PRIVACY)
    if w["picture"]:
        merged["picture_utc"] = w["picture"][0]
    usage = r.attempts if r else []
    with db.transaction(conn):
        conn.execute(
            "INSERT INTO photo_read (photo_id, made_utc, reader_version, kind, outcome, message, prompt_sha, schema_id,"
            " model_served, effort, local_json_gz, vision_json_gz, merged_json, checks_json, usage_json, tokens_in,"
            " tokens_out, usd_est, ms, error, job) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (row["id"], to_iso(now), READER_VERSION, w["kind"], w["outcome"], w["message"],
             claude.PROMPT_SHA if r and r.calls else None, "mt5shot/2" if r and r.calls else None,
             r.served if r else None, w["effort"] if r else None, _gz(loc), _gz(w["vision"]),
             json.dumps(merged, default=str), json.dumps(w["checks"], default=str), json.dumps(usage),
             r.tokens_in if r else 0, r.tokens_out if r else 0, r.usd if r else 0.0, ms, w["error"], job))
        conn.execute("UPDATE photo SET state = ?, kind = ?, next_try_utc = ? WHERE id = ?",
                     (w["state"], w["kind"], to_iso(w["next_try"]) if w["next_try"] else None, row["id"]))
        if w["picture"]:
            conn.execute("UPDATE photo SET picture_utc = ?, picture_time_how = ? WHERE id = ?",
                         (w["picture"][0], w["picture"][1], row["id"]))


def view(conn, cfg, photo_id: int) -> dict | None:
    """What the draft card needs from the latest reading (never the local pass, the raw reading or the chip)."""
    r = conn.execute("SELECT * FROM photo_read WHERE photo_id = ? ORDER BY id DESC LIMIT 1", (photo_id,)).fetchone()
    if r is None:
        return None
    m = json.loads(r["merged_json"] or "{}")
    keep = ("kind", "status", "trades", "lines", "fields", "which_trade", "moved_stop", "proposal", "candidates",
            "duplicate_of", "history_rows", "closes", "red", "needs_taps", "picture_utc", "live_bid", "bridge",
            "privacy_flag", "type_rows", "free_levels", "symbol")
    out = {k: m[k] for k in keep if k in m}
    acct = conn.execute("SELECT account_id FROM photo WHERE id = ?", (photo_id,)).fetchone()
    out["account_id"] = acct[0] if acct else None
    out["journal"] = out["account_id"] is not None
    out.update(outcome=r["outcome"], message=r["message"], read_utc=r["made_utc"],
               cap_reached="monthly cap" in (r["error"] or ""))
    trades_ = out.get("trades") or []
    out["first_stop_question"] = bool(trades_ and not trades_[0].get("first_stop_from_order")
                                      and trades_[0].get("first_stop_ok") and not out.get("bridge"))
    return out


def waiting(conn, cfg, now: datetime, account: int | None = None) -> list[dict]:
    """One account's pictures with no trade yet (account None: the MT5 account's), newest first: reading, ready (a
    draft, the taps, a look or a message) or failed. A journal account's are read whatever [photos] reader says."""
    out = []
    reads = cfg.photos.reader != "off" or account is not None
    for p in conn.execute("SELECT * FROM photo WHERE state IN ('queued','reading','read','needs_taps','rejected',"
                          "'failed') AND account_id IS ? ORDER BY received_utc DESC, id DESC LIMIT 50", (account,)):
        r = conn.execute("SELECT outcome, message FROM photo_read WHERE photo_id = ? ORDER BY id DESC LIMIT 1",
                         (p["id"],)).fetchone()
        ready = p["state"] in ("read", "needs_taps", "rejected", "failed")
        text = r["message"] if r and ready else "Reading your picture…"
        if p["state"] == "failed" and not r:
            text = "Not sent: retry"
        if not ready and reads and now - from_iso(p["received_utc"]) > SLOW:
            text = SLOW_TEXT
        if not ready and not reads:
            text = "Waiting: pictures are not read yet. Link it to a trade or delete it."
        out.append({"id": p["id"], "state": p["state"], "kind": p["kind"], "received_utc": p["received_utc"],
                    "picture_utc": p["picture_utc"], "ready": ready, "outcome": r["outcome"] if r else None,
                    "text": text})
    return out


def link_choices(conn, cfg, photo_id: int) -> list[dict]:
    """A picture with no reading (the reader off, item 14): the bridge trades of its trading day to link it to by hand,
    each named with its kind and time."""
    from app.photos import trades as photo_trades
    p = conn.execute("SELECT * FROM photo WHERE id = ?", (photo_id,)).fetchone()
    if p is None or p["account_id"] is not None:        # a journal account's picture: never a bridge trade
        return []
    day = trading_day(from_iso(p["picture_utc"] or p["received_utc"])).isoformat()
    syms = list(cfg.instrument.broker_symbols)
    return [{"ref": f"mt5:{b['id']}", "label": photo_trades._bridge_label(b)} for b in conn.execute(
        f"SELECT * FROM trade WHERE book = 'mt5' AND trading_day = ? AND symbol IN ({','.join('?' * len(syms))})"
        " ORDER BY open_utc, id", (day, *syms))]
