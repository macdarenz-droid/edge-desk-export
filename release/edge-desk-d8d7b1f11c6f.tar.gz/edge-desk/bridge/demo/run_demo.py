"""Run the read-only bridge end to end on Linux: MT5 under Wine -> EdgeBridge EA -> the app's ingest API.

Used to show the bridge working against an MT5 demo account from a cloud session (or any Linux box).
The demo login comes only from environment secrets, never from the repo or the chat:

    MT5_DEMO_LOGIN             demo account login
    MT5_DEMO_INVESTOR_PASSWORD the INVESTOR (read-only) password, never the master password
    MT5_DEMO_SERVER            e.g. "MetaQuotes-Demo"

The login and password are written only to <dir>/wine/drive_c/edge/start.ini (mode 0600, with
KeepPrivate=0 so the terminal does not save the password), which is deleted once the terminal has started
and in any case when the run ends (normal end, error, Ctrl+C or SIGTERM). No child process (Wine, the
terminal, xdotool, ImageMagick, the app) gets the MT5_DEMO_* variables, and in login mode no full-screen
screenshot is kept (the title bar, Navigator and Journal can show the account number).

    python3 bridge/demo/run_demo.py                 # full run with the demo login
    python3 bridge/demo/run_demo.py --no-login      # plumbing check: EA -> app without any account

What it does: installs Wine/Xvfb/xdotool if missing (apt), installs MT5 from MetaQuotes' official
installer, compiles bridge/EdgeBridge.mq5 with MetaEditor (log must say 0 errors), writes a fresh random
ingest token to the terminal's Common\\Files folder, starts the app (python3 -m app serve) with that token,
starts the terminal with the EA on a EURUSD chart (algorithmic trading off, DLLs off), adds the ingest URL to
Tools > Options > Expert Advisors > "Allow WebRequest for listed URL" by keyboard/mouse automation, then waits
for snapshots and writes evidence (compile log, bridge status, screenshots) to <dir>/evidence.

Sources: terminal start keys and the [Common]/[Experts]/[StartUp] config sections
https://www.metatrader5.com/en/terminal/help/start_advanced/start ; MetaEditor command-line compile
https://www.metatrader5.com/en/metaeditor/help/beginning/integration_ide ; WebRequest allow-list
https://www.mql5.com/en/docs/network/webrequest .
"""
from __future__ import annotations

import argparse
import json
import os
import secrets
import shutil
import signal
import sqlite3
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
MT5_SETUP_URL = "https://download.mql5.com/cdn/web/metaquotes.software.corp/mt5/mt5setup.exe"
DISPLAY = ":99"
PORT = 8787
ALLOW_URL = f"http://127.0.0.1:{PORT}"
INGEST_URL = f"{ALLOW_URL}/api/bridge/v1/snapshot"
OPTIONS_WAIT_S = 30     # how long Tools > Options may take to show after ctrl+o, and to go after OK
# Where Tools > Options showed in every logged open (real runs of 18 Oct, RP and RP1, build 6272 on the 1280x1024
# Xvfb screen); the click points in allow_webrequest were measured with the dialog there.
OPTIONS_AT = {"X": "348", "Y": "394", "WIDTH": "620", "HEIGHT": "389"}
# What the 5x5 grey probe reads at a checkbox's click point on the Expert Advisors tab (mean, 0 black to 1 white).
# Measured on every real-run screenshot with Options open on build 6272 (RP, RP1, RP2, r3; 18 Oct): empty 0.94 or
# 1.00, ticked 0.72 or 0.78; 6266 (16 Oct): empty 1.0, ticked 0.75. The same points on the AI Assistant and MCP tabs
# read 0.52 and 0.64, outside both ranges. A reading outside both means the dialog is not as measured.
PROBE_EMPTY = (0.92, 1.0)
PROBE_TICKED = (0.70, 0.80)
PROBE_READS = 5         # a clicked box is read up to this many times, a second apart, for its new state
# Where the pointer rests while a box is read: the Experts tab (already clicked, so resting there changes nothing). A box
# with the pointer over it is drawn in its hover colours (blue border and tick), and the probe then reads 0.867 or 0.834
# ticked and 0.906 empty, outside both ranges above (real run 4, 18 Oct, build 6272: the setup stopped with "did not
# change when clicked" while its screenshot showed the box ticked; with the pointer moved off, 0.781 and 0.936).
REST_AT = ("514", "410")


def log(msg: str) -> None:
    print(f"[demo {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def child_env(**extra) -> dict:
    """os.environ without the demo login secrets, plus `extra`: no child process needs them."""
    env = {k: v for k, v in os.environ.items() if not k.startswith("MT5_DEMO_")}
    env.update(extra)
    return env


def write_private(path: Path, text: str) -> None:
    """Create the file 0600 from the start (never readable by others, not even for a moment)."""
    path.unlink(missing_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as fh:
        fh.write(text)


def run(cmd, env=None, timeout=None, check=True, **kw):
    return subprocess.run(cmd, env=child_env() if env is None else env, timeout=timeout, check=check, **kw)


def _terminated(signum, frame):
    raise SystemExit(128 + signum)   # turns `kill <pid>` into a normal exit, so the clean-up runs


class OptionsError(RuntimeError):
    """Tools > Options could not be set. `retry`: whether the same run again can help (a dialog that was slow to
    show or to close), or not (a dialog away from where the click points were measured)."""

    def __init__(self, msg: str, retry: bool):
        super().__init__(msg)
        self.retry = retry


class Demo:
    AGAIN = ""                                         # what a failed compile tells (the installer's Setup adds advice)

    def __init__(self, base: Path, login: bool):
        self.base = base
        self.login = login
        self.prefix = base / "wine"
        self.evidence = base / "evidence"
        self.evidence.mkdir(parents=True, exist_ok=True)
        self.mt5 = self.prefix / "drive_c" / "Program Files" / "MetaTrader 5"
        self.env = child_env(DISPLAY=DISPLAY, WINEPREFIX=str(self.prefix), WINEARCH="win64", WINEDEBUG="-all",
                             WINEDLLOVERRIDES="mscoree=;mshtml=")  # no Mono/Gecko install prompt (it blocks wineboot)
        self.ini = self.prefix / "drive_c" / "edge" / "start.ini"
        self.procs: list[subprocess.Popen] = []

    # ---------- setup ----------
    def packages(self) -> None:
        need = [b for b in ("wine", "Xvfb", "xdotool", "import") if shutil.which(b) is None]
        if not need:
            return
        log(f"installing packages (missing: {need})")
        run(["dpkg", "--add-architecture", "i386"])
        run(["apt-get", "update", "-qq"])
        run(["apt-get", "install", "-y", "-qq", "wine64", "wine32:i386", "xvfb", "xdotool", "imagemagick"],
            env=child_env(DEBIAN_FRONTEND="noninteractive"))

    def display(self) -> None:
        probe = run(["xdotool", "getdisplaygeometry"], env=self.env, check=False, capture_output=True)
        if probe.returncode == 0:
            return
        self.procs.append(subprocess.Popen(["Xvfb", DISPLAY, "-screen", "0", "1280x1024x24"],
                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        time.sleep(2)

    def install_mt5(self) -> None:
        if (self.mt5 / "terminal64.exe").exists() and (self.mt5 / "MQL5" / "Experts").exists():
            return
        setup = self.base / "mt5setup.exe"
        if not setup.exists():
            log("downloading the official MT5 installer")
            # the CDN answers 403 to the default Python-urllib agent (checked 16 Oct 2026); curl is served
            req = urllib.request.Request(MT5_SETUP_URL, headers={"User-Agent": "curl/8.5.0"})
            with urllib.request.urlopen(req, timeout=300) as r, open(setup, "wb") as fh:
                shutil.copyfileobj(r, fh)
        run(["wineboot", "-i"], env=self.env, timeout=300, check=False)
        log("installing MT5 (silent)")
        run(["wine", str(setup), "/auto"], env=self.env, timeout=900, check=False)
        if not (self.mt5 / "terminal64.exe").exists():
            raise SystemExit("MT5 install failed: terminal64.exe not found")
        log("first start to create the MQL5 folders")
        p = subprocess.Popen(["wine", "terminal64.exe", "/portable"], cwd=self.mt5, env=self.env,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(120):
            if (self.mt5 / "MQL5" / "Experts").exists():
                break
            time.sleep(1)
        time.sleep(20)
        p.terminate()
        run(["wineserver", "-k"], env=self.env, check=False)

    def compile_ea(self) -> None:
        src = REPO / "bridge" / "EdgeBridge.mq5"
        work = self.prefix / "drive_c" / "edge"
        work.mkdir(parents=True, exist_ok=True)
        shutil.copy(src, work / "EdgeBridge.mq5")
        for old in ("EdgeBridge.ex5", "EdgeBridge.log"):
            (work / old).unlink(missing_ok=True)
        again = self.AGAIN
        try:
            run(["wine", "MetaEditor64.exe", r"/compile:C:\edge\EdgeBridge.mq5", r"/log:C:\edge\EdgeBridge.log"],
                cwd=self.mt5, env=self.env, timeout=180, check=False)
        except subprocess.TimeoutExpired:
            raise SystemExit("MetaEditor did not finish the EA's compile within 180 s" + again) from None
        if not (work / "EdgeBridge.log").is_file():
            raise SystemExit("MetaEditor left no compile log for the EA" + again)
        text = (work / "EdgeBridge.log").read_bytes().decode("utf-16", errors="replace")
        (self.evidence / "compile.log").write_text(text)
        result = [ln for ln in text.splitlines() if ln.startswith("Result:")]
        log(f"compile: {result[-1] if result else 'no result line'}")
        if not result or not result[-1].startswith("Result: 0 errors"):
            raise SystemExit("EA did not compile cleanly; see evidence/compile.log")
        dest = self.mt5 / "MQL5" / "Experts" / "EdgeBridge"
        dest.mkdir(parents=True, exist_ok=True)
        part = dest / "EdgeBridge.ex5.new"              # whole or not at all: the old EA stays until the rename
        try:
            shutil.copy(work / "EdgeBridge.ex5", part)
            os.replace(part, dest / "EdgeBridge.ex5")
        except OSError as exc:
            part.unlink(missing_ok=True)
            raise SystemExit(f"the compiled EA could not be copied into MT5 ({exc.strerror or exc})" + again) from None

    def common_files(self) -> Path:
        users = self.prefix / "drive_c" / "users"
        for user in users.iterdir():
            p = user / "AppData" / "Roaming" / "MetaQuotes" / "Terminal" / "Common" / "Files"
            if p.exists():
                return p
        p = users / os.environ.get("USER", "root") / "AppData" / "Roaming" / "MetaQuotes" / "Terminal" / "Common" / "Files"
        p.mkdir(parents=True, exist_ok=True)
        return p

    # ---------- run ----------
    def start_app(self, token: str) -> None:
        env = child_env(EDGE_INGEST_TOKEN=token, EDGE_DASHBOARD_TOKEN=secrets.token_hex(24),
                        EDGE_DB_PATH=str(self.base / "edge.db"))
        env.pop("EDGE_VAPID_PRIVATE_KEY", None)  # the demo never sends phone alerts
        logf = open(self.evidence / "app_server.log", "w")
        self.procs.append(subprocess.Popen([sys.executable, "-m", "app", "serve"], cwd=REPO, env=env,
                                           stdout=logf, stderr=subprocess.STDOUT))
        for _ in range(30):
            try:
                urllib.request.urlopen(f"{ALLOW_URL}/api/health", timeout=2)
                log("app is up")
                return
            except OSError:
                time.sleep(1)
        raise SystemExit("app did not start; see evidence/app_server.log")

    def start_terminal(self, alias: str) -> Path:
        presets = self.mt5 / "MQL5" / "Presets"
        presets.mkdir(parents=True, exist_ok=True)
        (presets / "edge_demo.set").write_text(
            f"InpAlias={alias}\r\nInpUrl={INGEST_URL}\r\nInpTokenFile=edge_bridge_token.txt\r\n", encoding="utf-16")
        lines = []
        if self.login:
            missing = [k for k in ("MT5_DEMO_LOGIN", "MT5_DEMO_INVESTOR_PASSWORD", "MT5_DEMO_SERVER")
                       if not os.environ.get(k)]
            if missing:
                raise SystemExit(f"missing environment secrets: {missing} (or run with --no-login)")
            lines += ["[Common]", f"Login={os.environ['MT5_DEMO_LOGIN']}",
                      f"Password={os.environ['MT5_DEMO_INVESTOR_PASSWORD']}",
                      f"Server={os.environ['MT5_DEMO_SERVER']}", "KeepPrivate=0"]   # 0: do not save the password
        lines += ["[Experts]", "AllowLiveTrading=0", "AllowDllImport=0", "Enabled=1", "Account=0", "Profile=0",
                  "[StartUp]", r"Expert=EdgeBridge\EdgeBridge", "ExpertParameters=edge_demo.set",
                  "Symbol=EURUSD", "Period=H1"]
        ini = self.ini
        write_private(ini, "\r\n".join(lines) + "\r\n")
        self.procs.append(subprocess.Popen(["wine", "terminal64.exe", "/portable", r"/config:C:\edge\start.ini"],
                                           cwd=self.mt5, env=self.env, stdout=subprocess.DEVNULL,
                                           stderr=subprocess.DEVNULL))
        return ini

    def xdo(self, *args: str) -> None:
        # output dropped: each `key --window` prints "XGetInputFocus returned the focused window of 1. This is likely a
        # bug in the X server." (real run 4, 18 Oct), noise in the step log the owner is shown when a step fails
        run(["xdotool", *args], env=self.env, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def xdo_out(self, *args: str) -> list[str]:
        r = run(["xdotool", *args], env=self.env, check=False, capture_output=True, text=True)
        return r.stdout.split() if r.returncode == 0 else []

    def geometry(self, wid: str) -> dict[str, str]:
        return dict(x.split("=", 1) for x in self.xdo_out("getwindowgeometry", "--shell", wid) if "=" in x)

    def options_window(self) -> str | None:
        found = self.xdo_out("search", "--onlyvisible", "--name", "^Options$")
        return found[0] if found else None

    def shot(self, name: str) -> None:
        run(["import", "-window", "root", str(self.evidence / name)], env=self.env, check=False)

    def evidence_shot(self, name: str) -> None:
        """A full-screen shot kept as evidence: only without a login (a logged-in terminal can show the
        account number in its title bar, Navigator or Journal)."""
        if not self.login:
            self.shot(name)

    def probe(self, x: int, y: int) -> float | None:
        """The mean grey of the 5x5 pixels around x,y on a screenshot (None when it cannot be read)."""
        img = self.evidence / "_probe.png"
        self.shot(img.name)
        out = run(["convert", str(img), "-crop", f"5x5+{x - 2}+{y - 2}", "-colorspace", "Gray",
                   "-format", "%[fx:mean]", "info:"], env=self.env, check=False, capture_output=True, text=True)
        img.unlink(missing_ok=True)
        try:
            return float(out.stdout.strip())
        except ValueError:
            return None

    def box_state(self, x: int, y: int) -> bool | None:
        """A checkbox read from a screenshot: True ticked, False empty, None when the reading is neither (no
        checkbox there, or one drawn unlike the measured ones)."""
        v = self.probe(x, y)
        if v is not None and PROBE_TICKED[0] <= v <= PROBE_TICKED[1]:
            return True
        if v is not None and PROBE_EMPTY[0] <= v <= PROBE_EMPTY[1]:
            return False
        return None

    def not_as_measured(self, opt: str, what: str) -> OptionsError:
        """Escape to the Options window `opt` (it closes without saving) and the error that says why."""
        self.xdo("key", "--window", opt, "Escape")
        return OptionsError(f"{what}, so the Expert Advisors tab is not as it was measured; nothing more was clicked "
                            "and the Options window was closed without saving", retry=False)

    def set_checkbox(self, x: int, y: int, want: bool, opt: str) -> None:
        """Click the box when it reads the other state, then read it again until it reads `want` (PROBE_READS
        times). A box that does not read as a checkbox, or that the click did not change, gets no other click."""
        state = self.box_state(x, y)
        if state == want:
            return
        if state is None:
            raise self.not_as_measured(opt, f"the point {x},{y} does not read as a checkbox")
        self.xdo("mousemove", str(x), str(y), "click", "1")
        self.xdo("mousemove", *REST_AT)                         # off the box: read in its normal colours
        for _ in range(PROBE_READS):
            time.sleep(1)
            if self.box_state(x, y) == want:
                return
        raise self.not_as_measured(opt, f"the checkbox at {x},{y} did not change when clicked")

    def allow_webrequest(self, add_url: bool = True, window: str | None = None) -> None:
        """Tools > Options > Expert Advisors: algorithmic trading off, WebRequest on, add the ingest URL (add_url=False
        when the list already holds it: row 1 is "add new URL" only while the list is empty).
        Coordinates fit a 1280x1024 screen, checked with build 5.6266 under Wine 11.0 (16 Oct) and build 5.6272 under
        Wine 11.20 (18 Oct real path: the clicks and the 5x5 probe at x=383 worked in every Options open; the
        checkboxes sat at x 377-389 in the first open and x 381-393 in later ones, probe 0.94 empty, 0.72-0.78
        ticked). Earlier build 5.6251 placed the dialog lower, so re-measure from options_before.png after an MT5
        update. Build 6272 saves these Options only in a terminal started without /config (deploy/install/mt5_setup.py).
        `window`: the terminal's main window, which gets ctrl+o by `key --window` (real run 1, 18 Oct: it opened
        Options in both service starts). With no window manager a key sent without --window goes to whatever window
        is under the pointer, so only the bridge demo (window None) still sends bare keys. No click until a visible
        "Options" window shows at OPTIONS_AT; after the tab click both checkbox points must read as checkboxes
        (PROBE_EMPTY or PROBE_TICKED), each clicked box must then read its new state, and OK must close the window.
        Raises OptionsError otherwise (nothing clicked, or the dialog closed with Escape, which does not save)."""
        log("adding the ingest URL to the WebRequest allow-list")
        if window is None:
            self.xdo("key", "Escape")                           # close the open-an-account dialog if shown
            time.sleep(2)
            self.xdo("key", "ctrl+o")
        else:
            self.xdo("key", "--window", window, "ctrl+o")
        opt = None
        for _ in range(OPTIONS_WAIT_S):
            opt = self.options_window()
            if opt:
                break
            time.sleep(1)
        if opt is None:
            raise OptionsError(f"the Options window did not open within {OPTIONS_WAIT_S} s of ctrl+o; nothing was "
                               "clicked", retry=True)
        geo = self.geometry(opt)
        if any(geo.get(k) != v for k, v in OPTIONS_AT.items()):
            self.xdo("key", "--window", opt, "Escape")          # closes it without saving
            raise OptionsError("the Options window showed at {},{} ({}x{}), not at 348,394 (620x389) where the click "
                               "points were measured; nothing was clicked".format(
                                   *(geo.get(k, "?") for k in ("X", "Y", "WIDTH", "HEIGHT"))), retry=False)
        time.sleep(2)
        self.xdo("mousemove", "514", "410", "click", "1")       # Experts tab
        time.sleep(2)
        self.evidence_shot("options_before.png")
        # both boxes must read as checkboxes before either is clicked (an MT5 build whose tab moved would show other
        # controls there); each click is then read back
        odd = [f"{x},{y}" for x, y in ((383, 455), (383, 602)) if self.box_state(x, y) is None]
        if odd:
            raise self.not_as_measured(opt, f"the point(s) {' and '.join(odd)} do not read as checkboxes")
        self.set_checkbox(383, 455, False, opt)                 # Allow algorithmic trading: off
        self.set_checkbox(383, 602, True, opt)                  # Allow WebRequest for listed URL: on
        if add_url:
            # A fresh terminal lists no URL, so row 1 is "add new URL": a double-click opens its field,
            # a click focuses it (typing before that click is lost; checked by screenshots).
            self.xdo("mousemove", "500", "631", "click", "--repeat", "2", "--delay", "120", "1")
            time.sleep(2)
            self.xdo("mousemove", "670", "630", "click", "1")
            time.sleep(1)
            self.xdo("type", "--delay", "80", ALLOW_URL)
            self.xdo("key", "Return")
            time.sleep(1)
        self.evidence_shot("options_after.png")
        self.xdo("mousemove", "759", "765", "click", "1")       # OK
        for _ in range(OPTIONS_WAIT_S):
            time.sleep(1)
            if self.options_window() is None:
                return
        self.xdo("key", "--window", opt, "Escape")
        raise OptionsError(f"the Options window was still open {OPTIONS_WAIT_S} s after OK (closed without saving)",
                           retry=True)

    def wait_for_snapshot(self, timeout_s: int) -> dict | None:
        db = self.base / "edge.db"
        end = time.time() + timeout_s
        while time.time() < end:
            if db.exists():
                try:
                    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
                    row = con.execute("SELECT account_alias, last_seq, last_seen_utc, trade_allowed, snapshot_json "
                                      "FROM bridge_status").fetchone()
                    con.close()
                    if row:
                        snap = json.loads(row[4])
                        acc = snap.get("account", {})
                        return {"alias": row[0], "seq": row[1], "last_seen_utc": row[2],
                                "trade_allowed": bool(row[3]), "trade_mode": acc.get("trade_mode"),
                                "company": acc.get("company"), "currency": acc.get("currency"),
                                "balance": acc.get("balance"), "equity": acc.get("equity"),
                                "positions": len(snap.get("positions", [])), "orders": len(snap.get("orders", [])),
                                "deals_in_last_snapshot": len(snap.get("deals", [])),
                                "terminal_connected": snap.get("terminal", {}).get("connected")}
                except sqlite3.Error:
                    pass
            time.sleep(2)
        return None

    def stop(self) -> None:
        run(["wineserver", "-k"], env=self.env, check=False)
        for p in reversed(self.procs):
            if p.poll() is None:
                p.send_signal(signal.SIGTERM)
                try:
                    p.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    p.kill()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--dir", default="/tmp/edge-mt5-demo", help="work folder (Wine prefix, db, evidence)")
    ap.add_argument("--no-login", action="store_true", help="plumbing check without any account")
    ap.add_argument("--keep", type=int, default=60, help="seconds to keep running after the first snapshot")
    ap.add_argument("--alias", default="main", help="account alias (must match config/app.toml)")
    args = ap.parse_args()

    demo = Demo(Path(args.dir), login=not args.no_login)
    old_term = signal.signal(signal.SIGTERM, _terminated)
    try:
        demo.packages()
        demo.display()
        demo.install_mt5()
        demo.compile_ea()
        token = secrets.token_hex(32)
        tok = demo.common_files() / "edge_bridge_token.txt"
        write_private(tok, token)
        demo.start_app(token)
        ini = demo.start_terminal(args.alias)
        time.sleep(45)
        ini.unlink(missing_ok=True)  # the login file lives only while the terminal starts
        try:
            demo.allow_webrequest()
        except OptionsError as e:
            log(f"WebRequest not set: {e}")
            return 1
        log("waiting for snapshots")
        status = demo.wait_for_snapshot(120)
        if status is None:
            demo.evidence_shot("terminal_no_snapshot.png")
            log("no snapshot arrived; see evidence/*.png and app_server.log")
            return 1
        time.sleep(max(0, args.keep))
        status = demo.wait_for_snapshot(5) or status
        (demo.evidence / "bridge_status.json").write_text(json.dumps(status, indent=2))
        demo.xdo("mousemove", "417", "992", "click", "1")       # Experts log tab
        time.sleep(1)
        demo.evidence_shot("terminal.png")
        log("bridge status: " + json.dumps(status))
        return 0
    finally:
        demo.ini.unlink(missing_ok=True)       # the login file never outlives the run, however it ends
        tok_path = None
        try:
            tok_path = demo.common_files() / "edge_bridge_token.txt"
        except OSError:
            pass
        try:
            demo.stop()
        finally:
            if tok_path is not None:
                tok_path.unlink(missing_ok=True)
            demo.ini.unlink(missing_ok=True)
            signal.signal(signal.SIGTERM, old_term)


if __name__ == "__main__":
    raise SystemExit(main())
