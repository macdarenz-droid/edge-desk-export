#!/usr/bin/env python3
"""MT5's first-time setup on the server (run by deploy/install/stage2.sh as the mt5 user, with the system Python;
standard library only). It reuses what the bridge demo worked out (bridge/demo/run_demo.py, EVIDENCE.md, 16 Oct):
MetaQuotes' installer under WineHQ devel 11.20, the EA compiled with MetaEditor (0 errors required), and the
WebRequest allow-list set by keyboard and mouse at the measured screen points. Not stable 11.0: it has no syscall user
dispatch, so the protected installer shows a false "A debugger has been found" message and never installs (WineHQ bug
58043; evidence/part-b/installer/WINE.md, 18 Oct).

Two starts (real path, 18 Oct; evidence/part-b/installer/MT5_SETUP.md):
1. the login start, with the start file C:\\edge\\start.ini (the investor login, KeepPrivate=1 so the terminal keeps
   it; deleted 45 s after the start and not before the main window shows), closed cleanly with `wine taskkill` (no
   /f) about 70 s after the start so the terminal writes its settings;
2. a start with no start file: MT5 build 6272 saves Tools > Options to Config/common.ini only in such a session. Once
   its main window shows, Login and LiveUpdate windows get Escape until none has shown for a few seconds; then ctrl+o
   goes to the main window by its id, and the clicks wait for the Options window at the place where they were
   measured. Both checkbox points must read as checkboxes and each clicked box must read its new state. They turn
   algorithmic trading off and WebRequest on, and add http://127.0.0.1:8787; then a clean close. When common.ini
   already holds the settings (a new login on a set-up terminal) this start is not made at all (his server, 30 Oct
   2026: build 6281 would not close after it). The build is printed; one whose points were not measured (only 6266
   and 6272 were) is clicked behind the same checks, and the step log says so.
Config/common.ini is then read back. setup.done ("ok build N") is written only when its [Experts] section holds
WebRequest=1, a listed URL and Enabled=0 and the build did not change; otherwise the setup exits, says whether pasting
the install line again can help (Enter keeps the saved login), and writes nothing done. The password goes into the
start file in double quotes (PASSWORD_MAX below says why: '#' and ';' are safe as written, an outer space or quote is
not). Note: after the setup,
common.ini's [Common] holds Login=0 and an empty Server (a start file's account is not saved), so a start with no start
file always shows a Login window and never connects; that window is expected in the settings start (real run 3).

The secrets come only on stdin, as KEY=value lines (MT5_LOGIN, MT5_SERVER, MT5_PASSWORD: the INVESTOR password, and
EDGE_INGEST_TOKEN). The password is written to one file only, the start file (mode 0600), deleted once the terminal
has started; the token goes to the EA's token file (0600). The service's run.ini (0600, owner mt5, on the server only)
names the account and server but holds no password: the terminal keeps the password itself, and with the account
named it connects at once instead of waiting on its Login window (real path test F). Nothing here prints a secret.

  stage2.sh:  ... | runuser -u mt5 -- python3 -I mt5_setup.py --base /home/mt5/edge

After the settings start, Config/assistant.ini gets Enable=0 in its [MCP.*] sections: build 6272 runs an MCP server on
127.0.0.1:22346 by default, which the bridge does not need (real run 2: with Enable=0 no "MCP started" line and no
listener). The read-back requires it off too.

Real runs in a container (evidence/part-b/installer/MT5_SETUP.md): run 1 (18 Oct, 4 CPUs), run 2 (18 Oct, one CPU
by taskset, a 1.5 GiB memory cgroup) and run 3 (18 Oct, the committed code at ce95deff) passed with a dummy account
that never logged in. Run 4 (18 Oct, the code at 894e0be2, with the checkbox reads) failed its first setup: a box
read with the pointer still on it is drawn in hover colours, outside the measured readings; with the pointer moved
off before each read (run_demo.REST_AT), a fresh setup, three service-style starts and a re-run passed. Run 5 (18 Oct,
the code at ea2e076f, one CPU, Python 3.12) ran the changes made after run 4 and passed the same: a fresh setup, three
service-style starts, the taskkill restart and a re-run that kept the prefix. The click on an unmeasured build has
still not run on a real terminal (only build 6272 was given). Not verified on a real server: a real investor login
(that it authorizes and is kept between starts; with the dummy, the saved password survived a run.ini start closed by
taskkill), the screen points on the server's build, that the terminal reaches the broker from the server (the
container could not), and whether Escape alone closes the LiveUpdate window (in run 2 it showed at the end of a login
start; Escape and the taskkill after it left the terminal on its build).
"""
from __future__ import annotations

import argparse
import hashlib
import os
import re
import shutil
import signal
import string
import subprocess
import sys
import time
from pathlib import Path

DESK = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(DESK / "bridge" / "demo"))
import run_demo as D  # noqa: E402

NEEDED = ("MT5_LOGIN", "MT5_SERVER", "MT5_PASSWORD", "EDGE_INGEST_TOKEN")
EA_SOURCE = D.REPO / "bridge" / "EdgeBridge.mq5"          # what compile_ea compiles: this release's EA
# Enabled=0: "Allow algorithmic trading" off. A start file's value applies at every start that uses it, whatever was
# saved (real path: Enabled=1 turned it on); the EA still loads and runs with it off (tests C and E2), and WebRequest
# to http://127.0.0.1:8787 works with it off (real run 3: a probe EA posted every 3 s, terminal_trade_allowed=0, with
# this [Experts] section and the saved allow-list). EdgeBridge itself posts only once the terminal is connected to
# the broker, which no run here could reach: the server's 3-minute snapshot check shows that part.
EXPERTS = ["[Experts]", "AllowLiveTrading=0", "AllowDllImport=0", "Enabled=0", "Account=0", "Profile=0"]
STARTUP = ["[StartUp]", r"Expert=EdgeBridge\EdgeBridge", "ExpertParameters=edge.set", "Symbol=EURUSD", "Period=H1"]
# Builds whose Tools > Options click points were measured on screenshots: 6266 (bridge demo, 16 Oct) and 6272 (real
# path, 18 Oct). mt5setup.exe is pinned, but it is a web installer that downloads the current build (real run 3), and
# builds change often (6251, 6266, 6272 within about a week), so another build is not refused: it is clicked behind
# the same checks (run_demo.allow_webrequest: Options where measured, checkbox readings, each click read back), the
# step log names the build and says it was not measured, and the common.ini read-back decides.
MEASURED_BUILDS = frozenset({6266, 6272})
POPUPS = ("^Login$", "LiveUpdate")      # xdotool search --name patterns of the windows that get Escape
# Waits, with margin over what real runs measured (evidence/part-b/installer/MT5_SETUP.md): the main window showed 4-5 s
# after a start in run 1 (4 CPUs) and 6-10 s in run 2 (one CPU, 1.5 GiB); the Login window 5-9 s after it in run 1
# and about 1 s in run 2; Options about 1 s after ctrl+o in both (run_demo.OPTIONS_WAIT_S allows 30 s).
MAIN_WAIT_S = 120
POPUP_SETTLE_S = 20     # Login and LiveUpdate windows are looked for at least this long after the main window shows
POPUP_QUIET_S = 5       # ... and until none has shown for this long
POPUP_LIMIT_S = 90
# Closing (his server, 30 Oct 2026: on build 6281, logged in to FundedNext, "the terminal did not close after the
# settings start"): each attempt first sends Escape to Login and LiveUpdate windows (a modal one can keep the terminal
# open); then taskkill, taskkill again, then alt+F4 to the main window. After the close, Wine must be gone within
# SETTLE_S: a staged update makes the terminal start its updater and exit, and the updater starts the terminal again
# about 5 s later (deploy/edge-desk-mt5.service), so that terminal is closed the same way, up to AGAIN_MAX times.
# LiveUpdate's updater (...\liveupdate\terminal64.exe /update, the same image name as the terminal) is only ever
# waited for, up to UPDATE_WAIT_S, never sent a key or a taskkill; the terminal it starts is closed once its main
# window shows. A Wine helper that stays after the terminal has gone is not waited for (the settings are written).
CLOSE_WAITS_S = (30, 30, 60)
SETTLE_S = 45
AGAIN_MAX = 2
UPDATE_WAIT_S = 600
# A process that is a terminal: its command line starts with terminal64.exe or a Windows path to it. Wine shows the
# terminal so (real run, 30 Oct: "C:\Program Files\MetaTrader 5\terminal64.exe /portable /config:C:\edge\run.ini")
# and the `wine` launcher as "start.exe /exec terminal64.exe ...", which is not one; nor is a shell line naming it.
TERMINAL_CMD = re.compile(r'^"?((?:[a-z]:\\(?:[^\0"]*\\)?)?terminal64\.exe)(?=["\s\0]|$)')
# FundedNext's servers (his server, 30 Oct 2026): the generic MT5 knows none of them, so with Server=FundedNext-Server 2
# its journal had no Network line at all; FundedNext's help (article 10725745, 8 Apr 2026) has the user search
# "FundedNext" in File > Open an Account to load them. FundedNext's own installer (MetaQuotes' CDN, pinned in pins.env
# as FNSETUP_SHA256; signed by MetaQuotes Ltd.) installs the same terminal64.exe with their Config/servers.dat, and that
# file copied into the generic terminal made it try FundedNext-Server 2 (lab, mt5lab/FN_SERVERS_RESULTS.md). So for a
# FundedNext server the setup installs it into this prefix, copies its servers.dat, keeps the generic one as
# servers.dat.metaquotes, removes the FundedNext folder and writes C:\edge\servers.done. A typed FundedNext login
# loads it again when the installer could be fetched; a plain paste loads it only when it is not in (no marker in this
# prefix, servers.dat missing or under 1 KB, or byte-equal to MetaQuotes' list), never because MT5 updated the file.
FN_SERVER = re.compile(r"fundednext", re.IGNORECASE)
FN_FOLDER = "FundedNext MT5 Terminal"
SERVERS_MIN_BYTES = 1024
JOURNAL_LINES = 8       # shown when a close fails, within the 12 lines the install shows of a soft step's log
TOKEN_CHARS = frozenset(string.ascii_letters + string.digits + "-_.~+/=")   # EdgeBridge.mq5 TokenOk
# The start file's Password= value (measured on MT5 build 6295 under Wine 11.20, 30 Oct 2026; desk/evidence/
# account_switch/MT5_PASSWORD_START_FILE.md): MT5 reads [Common] with GetPrivateProfileStringW, which keeps '#', ';'
# and '=' as written but trims outer spaces and removes one pair of matching quotes around the value; no escapes; a
# file with no byte-order mark is read as Windows-1252; the buffer is 512 characters. So the value is written in
# double quotes (the one pair MT5 removes), which round-tripped every case tried, and a password must be printable
# ASCII (install.sh's own check) of at most PASSWORD_MAX characters.
PASSWORD_MAX = 500


def parse_secrets(stream) -> dict:
    out = {}
    for line in stream.read().splitlines():
        k, sep, v = line.partition("=")
        if sep and k in NEEDED:
            out[k] = v
    missing = [k for k in NEEDED if not out.get(k)]
    if missing:
        raise SystemExit(f"mt5 setup: missing on stdin: {', '.join(missing)}")
    pw = out["MT5_PASSWORD"]
    if len(pw) > PASSWORD_MAX or not all(" " <= c <= "~" for c in pw):
        raise SystemExit(f"mt5 setup: MT5_PASSWORD must be 1 to {PASSWORD_MAX} printable ASCII characters (MT5 reads "
                         "its start file as Windows-1252 and cuts a value at 511 characters)")
    tok = out["EDGE_INGEST_TOKEN"]
    if not 32 <= len(tok) <= 256 or not set(tok) <= TOKEN_CHARS:
        raise SystemExit("mt5 setup: EDGE_INGEST_TOKEN must be 32 to 256 letters, digits or - _ . ~ + / = "
                         "(the EA refuses any other)")
    return out


def login_ini(s: dict) -> str:
    lines = ["[Common]", f"Login={s['MT5_LOGIN']}", f'Password="{s["MT5_PASSWORD"]}"', f"Server={s['MT5_SERVER']}",
             "KeepPrivate=1", "NewsEnable=0", *EXPERTS, *STARTUP]
    return "\r\n".join(lines) + "\r\n"


def run_ini(s: dict) -> str:
    """The service's start file: the account and server (no password: the terminal keeps it) and the EA on its chart.
    No WebRequest keys: a plaintext WebRequestUrl in a start file is ignored, and the saved list is what counts."""
    lines = ["[Common]", f"Login={s['MT5_LOGIN']}", f"Server={s['MT5_SERVER']}", *EXPERTS, *STARTUP]
    return "\r\n".join(lines) + "\r\n"


def _text(raw: bytes) -> str:
    """MT5 writes Config/common.ini and its journal as UTF-16 with a byte-order mark; anything else is read as UTF-8."""
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16", errors="replace")
    return raw.decode("utf-8", errors="replace")


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_ini(path: Path) -> dict[str, dict[str, str]]:
    try:
        text = _text(path.read_bytes())
    except FileNotFoundError:
        return {}
    out: dict[str, dict[str, str]] = {}
    sect = None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("[") and line.endswith("]"):
            sect = out.setdefault(line[1:-1], {})
        elif sect is not None and "=" in line:
            k, _, v = line.partition("=")
            sect[k.strip()] = v.strip()
    return out


def options_problems(common_ini: Path) -> list[str]:
    """What Config/common.ini lacks for the bridge, empty when nothing: the [Experts] section with WebRequest on, a
    listed URL (MT5 keeps the list encrypted, so only that it is there is checked; nothing else adds a URL),
    algorithmic trading off and DLL imports not on."""
    ex = read_ini(common_ini).get("Experts")
    if ex is None:
        return ["no [Experts] section in Config/common.ini (MT5 did not save the Options)"]
    probs = []
    if ex.get("WebRequest") != "1":
        probs.append("WebRequest is not on")
    if not ex.get("WebRequestUrl"):
        probs.append("no URL in the WebRequest list")
    if ex.get("Enabled") != "0":
        probs.append("algorithmic trading is not off")
    if ex.get("AllowDllImport") == "1":         # 0 after every real setup; 1 only if a shifted layout ticked it
        probs.append("DLL imports are not off")
    return probs


def disable_mcp(assistant_ini: Path) -> None:
    """Enable=0 in every [MCP.*] section of Config/assistant.ini: MT5 6272 runs an MCP server on 127.0.0.1:22346 (and
    MetaEditor's on 22345) by default, and the read-only bridge needs neither. Run only while the terminal is closed.
    The file's encoding, line ends and other lines (its API keys) are kept as they are and never printed."""
    try:
        raw = assistant_ini.read_bytes()
    except FileNotFoundError:
        return
    sect, out = None, []
    for line in _text(raw).splitlines(keepends=True):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            sect = s[1:-1]
        elif (sect or "").startswith("MCP.") and s.partition("=")[0].strip() == "Enable":
            line = "Enable=0" + line[len(line.rstrip("\r\n")):]
        out.append(line)
    new = "".join(out)
    if raw[:2] == b"\xff\xfe":
        data = b"\xff\xfe" + new.encode("utf-16-le")
    elif raw[:2] == b"\xfe\xff":
        data = b"\xfe\xff" + new.encode("utf-16-be")
    else:
        data = new.encode("utf-8")
    if data != raw:
        assistant_ini.write_bytes(data)


def mcp_problems(assistant_ini: Path) -> list[str]:
    on = [s for s, kv in read_ini(assistant_ini).items() if s.startswith("MCP.") and kv.get("Enable") != "0"]
    return [f"the MCP server is still on in Config/assistant.ini ({', '.join(on)})"] if on else []


def running_build(mt5: Path) -> int | None:
    """The build in the newest 'MetaTrader 5 x64 build N started' line of the terminal's journal (logs/YYYYMMDD.log;
    MetaEditor's log is not read)."""
    for log in sorted((mt5 / "logs").glob("[0-9]*.log"), reverse=True):
        found = re.findall(r"MetaTrader 5 x64 build (\d+) started", _text(log.read_bytes()))
        if found:
            return int(found[-1])
    return None


class Setup(D.Demo):
    AGAIN = "; nothing was marked: paste the install line again"

    def __init__(self, base: Path, secrets: dict, alias: str):
        super().__init__(base, login=True)
        self.secrets = secrets
        self.alias = alias
        self.common_ini = self.mt5 / "Config" / "common.ini"

    # ---------- the terminal and its windows ----------
    def popen_terminal(self, *args: str) -> subprocess.Popen:
        p = subprocess.Popen(["wine", "terminal64.exe", "/portable", *args], cwd=self.mt5, env=self.env,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.procs.append(p)
        return p

    def main_window(self) -> str | None:
        """The terminal's main window: visible, of the terminal64.exe class, at least 1000 px wide and not named like
        a Login or LiveUpdate window (its dialogs share the class, the search order is not fixed, and real run 2 once
        logged the Login window at the main window's 1280x998 while it was being made)."""
        for wid in self.xdo_out("search", "--onlyvisible", "--classname", "terminal64.exe"):
            geo = dict(x.split("=", 1) for x in self.xdo_out("getwindowgeometry", "--shell", wid) if "=" in x)
            if not (geo.get("WIDTH", "").isdigit() and int(geo["WIDTH"]) >= 1000):
                continue
            name = " ".join(self.xdo_out("getwindowname", wid))
            if not any(re.search(pattern, name) for pattern in POPUPS):
                return wid
        return None

    def dismiss_popups(self) -> int:
        """Escape, sent to each visible Login or LiveUpdate window by its id (key --window: with no window manager,
        windowactivate is refused). Never Return: on the LiveUpdate window it would press Restart. Returns how many
        windows got it."""
        n = 0
        for pattern in POPUPS:
            for wid in self.xdo_out("search", "--onlyvisible", "--name", pattern):
                self.xdo("key", "--window", wid, "Escape")
                n += 1
                time.sleep(1)
        return n

    def settle_popups(self, at_least: int) -> None:
        """dismiss_popups about once a second until at least `at_least` seconds have passed and none has shown for
        POPUP_QUIET_S seconds (at most POPUP_LIMIT_S): a Login window can show some seconds after the main window,
        later on a slower server, and a modal one would take the keys and clicks meant for Options."""
        quiet = 0
        for t in range(1, POPUP_LIMIT_S + 1):
            quiet = 0 if self.dismiss_popups() else quiet + 1
            if t >= at_least and quiet >= POPUP_QUIET_S:
                return
            time.sleep(1)

    def wait_main_window(self, p: subprocess.Popen, which: str) -> tuple[str, int]:
        """The main window's id and about how many seconds it took to show; after MAIN_WAIT_S the terminal is closed
        and the setup stops."""
        for waited in range(0, MAIN_WAIT_S, 2):
            wid = self.main_window()
            if wid:
                return wid, waited
            time.sleep(2)
        self.close_terminal(p, which)
        raise SystemExit(f"mt5 setup: the terminal's main window did not show within {MAIN_WAIT_S} s of the {which}; "
                         "nothing was marked done: paste the install line again (Enter keeps the MT5 login)")

    @staticmethod
    def _ends(p: subprocess.Popen, seconds: int) -> bool:
        try:
            p.wait(timeout=seconds)
            return True
        except subprocess.TimeoutExpired:
            return False

    def _wine_gone(self, seconds: int) -> bool:
        """True once no Wine process of the prefix is left (`wineserver -w` returns), within `seconds`."""
        try:
            D.run(["wineserver", "-w"], env=self.env, check=False, timeout=seconds, stdout=subprocess.DEVNULL,
                  stderr=subprocess.DEVNULL)
            return True
        except subprocess.TimeoutExpired:
            return False

    def _own_cmdlines(self) -> list[str]:
        """The command lines of this user's processes (Wine shows a Windows process by its exe path)."""
        out, uid = [], os.getuid()
        for d in Path("/proc").iterdir():
            if not d.name.isdigit():
                continue
            try:
                if d.stat().st_uid == uid:
                    out.append((d / "cmdline").read_bytes().decode("utf-8", "replace"))
            except OSError:
                continue
        return out

    def _terminal_paths(self) -> list[str]:
        return [m.group(1) for c in self._own_cmdlines() if (m := TERMINAL_CMD.match(c.lower()))]

    def _updating(self) -> bool:
        return any("\\liveupdate\\" in t for t in self._terminal_paths())

    def _terminal_running(self) -> bool:
        return any("\\liveupdate\\" not in t for t in self._terminal_paths())

    def _gone(self, p: subprocess.Popen | None, seconds: int) -> bool:
        if p is not None:
            return self._ends(p, seconds)
        for _ in range(0, seconds, 2):
            if not self._terminal_running():
                return True
            time.sleep(2)
        return not self._terminal_running()

    def _close_once(self, p: subprocess.Popen | None) -> bool:
        """One terminal closed cleanly, so it writes its settings and the saved login: Escape to Login and LiveUpdate
        windows, then `wine taskkill` without /f (exit 0 in about 2 s on the real path, even with a modal window
        open), again, then alt+F4 to the main window. `p` None: a terminal this setup did not start (LiveUpdate started
        it again), whose end is Wine's."""
        for step, wait in zip(("taskkill", "taskkill", "alt+F4"), CLOSE_WAITS_S):
            self.dismiss_popups()
            if step == "taskkill":
                try:
                    D.run(["wine", "taskkill", "/im", "terminal64.exe"], cwd=self.mt5, env=self.env, check=False,
                          timeout=60, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                except subprocess.TimeoutExpired:
                    pass
            else:
                wid = self.main_window()
                if wid:
                    self.xdo("key", "--window", wid, "alt+F4")
            if self._gone(p, wait):
                return True
        return False

    def _settled(self) -> bool:
        """After a close: nothing left to close. Wine gone; or LiveUpdate's updater waited out (never touched) and
        the terminal it started closed once its main window showed (up to AGAIN_MAX such terminals); or no terminal
        left, only a Wine helper."""
        for _ in range(AGAIN_MAX + 1):
            if self._wine_gone(SETTLE_S):
                return True
            for _ in range(0, UPDATE_WAIT_S, 5):
                if not self._updating():
                    break
                time.sleep(5)
            else:
                return False
            if not self._terminal_running():
                return True
            for _ in range(0, MAIN_WAIT_S, 2):
                if self.main_window():
                    break
                time.sleep(2)
            if not self._close_once(None):
                return False
        return not self._terminal_running()

    def close_terminal(self, p: subprocess.Popen, which: str) -> None:
        """The terminal closed and nothing left running (_settled). One still running fails the setup, with the
        terminal's own journal shown (main then stops Wine)."""
        if self._close_once(p) and self._settled():
            return
        self.show_journal()
        raise SystemExit(f"mt5 setup: the terminal did not close after the {which}; nothing was marked done: paste "
                         "the install line again (Enter keeps the MT5 login); if it stops here again, send the lines "
                         "above")

    # ---------- FundedNext's server list ----------
    @property
    def servers_marker(self) -> Path:
        return self.prefix / "drive_c" / "edge" / "servers.done"          # in the prefix: a rebuilt one needs it again

    def _list_loaded(self) -> bool:
        dat = self.mt5 / "Config" / "servers.dat"
        generic = dat.with_name("servers.dat.metaquotes")
        if not self.servers_marker.is_file() or not dat.is_file() or dat.stat().st_size < SERVERS_MIN_BYTES:
            return False
        return not (generic.is_file() and generic.read_bytes() == dat.read_bytes())

    def servers_needed(self, server: str, login: bool = False, installer: Path | None = None) -> bool:
        """A FundedNext server on an installed terminal whose list is not in, or, for a typed login, whose installer is
        at hand (the list is then loaded again; a stale pin never blocks an account change once it is in)."""
        if not FN_SERVER.search(server or "") or not (self.mt5 / "terminal64.exe").exists():
            return False
        if self._list_loaded():
            return login and installer is not None and installer.is_file()
        return True

    def load_fundednext_servers(self, installer: Path | None) -> None:
        """FundedNext's installer into this prefix (no terminal of ours runs: the unit is stopped), its servers.dat
        copied over the generic one (kept once as servers.dat.metaquotes), its folder removed, servers.done written."""
        if installer is None or not installer.is_file():
            raise SystemExit("mt5 setup: this is a FundedNext server and FundedNext's installer was not fetched; "
                             "nothing was marked done: paste the install line again (Enter keeps the MT5 login)")
        print("mt5 setup: loading FundedNext's server list (FundedNext's own MT5 installer, pinned)", flush=True)
        fn = self.prefix / "drive_c" / "Program Files" / FN_FOLDER
        shutil.rmtree(fn, ignore_errors=True)
        try:                                   # it exits 1 though the install is complete (lab, 30 Oct)
            D.run(["wine", str(installer), "/auto"], env=self.env, timeout=900, check=False,
                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except subprocess.TimeoutExpired:
            pass
        D.run(["wineserver", "-k"], env=self.env, check=False)      # the terminal it may start; ours is stopped
        self._wine_gone(SETTLE_S)
        src = fn / "Config" / "servers.dat"
        if not src.is_file() or src.stat().st_size < SERVERS_MIN_BYTES:
            shutil.rmtree(fn, ignore_errors=True)
            raise SystemExit("mt5 setup: FundedNext's installer left no server list; nothing was marked done: paste "
                             "the install line again (Enter keeps the MT5 login)")
        dest = self.mt5 / "Config" / "servers.dat"
        dest.parent.mkdir(parents=True, exist_ok=True)
        backup = dest.with_name("servers.dat.metaquotes")
        if dest.is_file() and not backup.exists():
            shutil.copyfile(dest, backup)
        tmp = dest.with_name("servers.dat.new")
        shutil.copyfile(src, tmp)
        os.replace(tmp, dest)
        shutil.rmtree(fn, ignore_errors=True)
        self.servers_marker.parent.mkdir(parents=True, exist_ok=True)
        self.servers_marker.write_text(f"fundednext {_sha(installer)} {_sha(dest)}\n")
        print("mt5 setup: FundedNext's server list loaded", flush=True)

    # ---------- the EA ----------
    @property
    def ea_marker(self) -> Path:
        return self.prefix / "drive_c" / "edge" / "ea.done"               # in the prefix: a rebuilt one compiles again

    def ea_needed(self) -> bool:
        """An installed terminal whose EA was not compiled from this release's source (no mark, another source's sha,
        or no EdgeBridge.ex5 in its Experts folder). The login path compiled it; a set-up terminal kept its old EA
        (EA-17: his 1.12 matched each reply against the next seq)."""
        if not (self.mt5 / "terminal64.exe").exists():
            return False
        ex5 = self.mt5 / "MQL5" / "Experts" / "EdgeBridge" / "EdgeBridge.ex5"
        mark = self.ea_marker.read_text().split() if self.ea_marker.is_file() else []
        return not ex5.is_file() or mark != ["ea", _sha(EA_SOURCE)]

    def compile_and_mark(self) -> None:
        self.ea_marker.unlink(missing_ok=True)
        self.compile_ea()               # SystemExit unless 0 errors; the EA in the Experts folder is then the old one
        self.ea_marker.parent.mkdir(parents=True, exist_ok=True)       # compile_ea makes it; a stand-in may not
        self.ea_marker.write_text(f"ea {_sha(EA_SOURCE)}\n")

    def _masked(self, text: str) -> str:
        """The account number (whatever its length), the server name (any case), IPv4 addresses and any other run of
        5 or more digits hidden."""
        server = self.secrets.get("MT5_SERVER", "").strip()
        if server:
            text = re.sub(re.escape(server), "<server>", text, flags=re.IGNORECASE)
        login = self.secrets.get("MT5_LOGIN", "").strip()
        if login:
            text = re.sub(rf"(?<![0-9]){re.escape(login)}(?![0-9])", "#", text)
        text = re.sub(r"(?<![0-9.])[0-9]{1,3}(\.[0-9]{1,3}){3}(?![0-9.])", "#.#.#.#", text)
        return re.sub(r"[0-9]{5,}", "#", text)

    def show_journal(self) -> None:
        """The last JOURNAL_LINES lines of the terminal's own journal (UTF-16, logs/YYYYMMDD.log), masked, for the
        owner to send back when a start goes wrong."""
        logs = sorted((self.mt5 / "logs").glob("[0-9]*.log"), reverse=True)
        lines = _text(logs[0].read_bytes()).splitlines()[-JOURNAL_LINES:] if logs else []
        print("mt5 setup: the terminal's own journal, last lines (account number and server name hidden):", flush=True)
        for line in lines:
            print("  " + self._masked(" ".join(line.split()))[:140], flush=True)

    # ---------- the two starts ----------
    def login_start(self) -> None:
        presets = self.mt5 / "MQL5" / "Presets"
        presets.mkdir(parents=True, exist_ok=True)
        (presets / "edge.set").write_text(f"InpAlias={self.alias}\r\nInpUrl={D.INGEST_URL}\r\n"
                                          "InpTokenFile=edge_bridge_token.txt\r\n", encoding="utf-16")
        self.ini.parent.mkdir(parents=True, exist_ok=True)
        D.write_private(self.ini, login_ini(self.secrets))
        p = self.popen_terminal(r"/config:C:\edge\start.ini")
        _, waited = self.wait_main_window(p, "login start")   # the start file has been read once the window shows
        time.sleep(max(0, 45 - waited))
        self.ini.unlink(missing_ok=True)       # the login file lives only while the terminal starts
        time.sleep(25)                         # time to log in and keep the login
        self.dismiss_popups()
        self.close_terminal(p, "login start")

    def options_start(self) -> int:
        """Tools > Options in a start with no start file (build 6272 saves Options to Config/common.ini only then).
        Returns the running build. A build whose click points were not measured is clicked too (MetaQuotes' web
        installer gives whatever build is current), behind the same checks as a measured one: Options must show at
        run_demo.OPTIONS_AT, both checkbox points must read as checkboxes and each clicked box its new state, and the
        common.ini read-back decides; otherwise the Options window gets Escape (no save) and nothing is done."""
        if not options_problems(self.common_ini):
            # a set-up terminal (a new login): nothing to click, so no start (his server, 30 Oct: the start that
            # would not close); the build is the login start's own journal line, or the one LiveUpdate started again
            build = running_build(self.mt5)
            print(f"mt5 setup: terminal build {build} (Options already saved: no settings start)", flush=True)
            return build
        print("mt5 setup: Tools > Options in a start without a start file", flush=True)
        p = self.popen_terminal()
        main, _ = self.wait_main_window(p, "settings start")
        build = running_build(self.mt5)
        measured = "measured" if build in MEASURED_BUILDS else (
            "not measured: clicked only where Options and its checkboxes read as on builds "
            + " and ".join(map(str, sorted(MEASURED_BUILDS))))
        print(f"mt5 setup: terminal build {build} (click points {measured})", flush=True)
        listed = bool(read_ini(self.common_ini).get("Experts", {}).get("WebRequestUrl"))
        self.settle_popups(POPUP_SETTLE_S)
        try:
            self.allow_webrequest(add_url=not listed, window=main)
        except D.OptionsError as e:
            self.close_terminal(p, "settings start")
            advice = ("paste the install line again (Enter keeps the MT5 login)" if e.retry else
                      "this needs a code update with new click points, and pasting the install line again will not "
                      "help")
            raise SystemExit(f"mt5 setup: Tools > Options could not be set on MT5 build {build}: {e}. Nothing was "
                             f"marked done: {advice}") from None
        self.close_terminal(p, "settings start")
        return build


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--base", default="/home/mt5/edge")
    ap.add_argument("--alias", default="main")
    ap.add_argument("--fundednext-installer", help="FundedNext's pinned installer, used only for a FundedNext server")
    ap.add_argument("--servers-needed", action="store_true",
                    help="exit 0 when the set-up terminal's server (run.ini) is FundedNext's and its list is not in, "
                         "3 when not needed (any other code is a failure)")
    ap.add_argument("--servers-only", action="store_true", help="load that list when needed, and nothing else")
    ap.add_argument("--ea-needed", action="store_true",
                    help="exit 0 when the set-up terminal's EA was not compiled from this release's source, 3 when it "
                         "was (any other code is a failure)")
    ap.add_argument("--ea-only", action="store_true", help="compile the EA when needed, and nothing else")
    a = ap.parse_args(argv)
    base = Path(a.base)
    installer = Path(a.fundednext_installer) if a.fundednext_installer else None
    if a.ea_needed or a.ea_only:               # a set-up terminal: no secrets; setup.done and run.ini left as they are
        s = Setup(base, {}, a.alias)
        need = s.ea_needed()
        if a.ea_needed:
            return 0 if need else 3
        if need:
            old_term = signal.signal(signal.SIGTERM, D._terminated)
            try:
                s.compile_and_mark()
                print("mt5 setup: the EA compiled again from this release", flush=True)
            finally:
                s.stop()
                signal.signal(signal.SIGTERM, old_term)
        return 0
    if a.servers_needed or a.servers_only:     # a set-up terminal: no secrets, setup.done left as it is
        s = Setup(base, {}, a.alias)
        server = read_ini(s.prefix / "drive_c" / "edge" / "run.ini").get("Common", {}).get("Server", "")
        need = s.servers_needed(server)
        if a.servers_needed:
            return 0 if need else 3
        if need:
            old_term = signal.signal(signal.SIGTERM, D._terminated)
            try:
                s.load_fundednext_servers(installer)
            finally:
                s.stop()
                signal.signal(signal.SIGTERM, old_term)
        return 0
    secrets = parse_secrets(sys.stdin)
    (base / "setup.done").unlink(missing_ok=True)     # only this run's own checks may mark the setup done
    s = Setup(base, secrets, a.alias)
    # stopping the install unit sends SIGTERM: as an exit, so `finally` removes start.ini (the investor password)
    old_term = signal.signal(signal.SIGTERM, D._terminated)
    try:
        if (s.mt5 / "terminal64.exe").exists() and (s.mt5 / "MQL5" / "Experts").exists():   # install_mt5's own test
            print("mt5 setup: MT5 already installed: kept", flush=True)
        else:
            print("mt5 setup: installing MT5 (MetaQuotes' installer, pinned by stage2)", flush=True)
        s.install_mt5()
        print("mt5 setup: compiling the EA", flush=True)
        s.compile_and_mark()
        D.write_private(s.common_files() / "edge_bridge_token.txt", secrets["EDGE_INGEST_TOKEN"])
        # a login change: the old account's run.ini goes first, so no start until setup.done can log the old account
        # in under the new alias (the EA's preset gets the new alias in login_start)
        (s.prefix / "drive_c" / "edge" / "run.ini").unlink(missing_ok=True)
        if s.servers_needed(secrets["MT5_SERVER"], login=True, installer=installer):
            s.load_fundednext_servers(installer)
        print("mt5 setup: first start with the investor login", flush=True)
        s.login_start()
        build = s.options_start()
        after = running_build(s.mt5)
        if after != build:
            raise SystemExit(f"mt5 setup: the terminal changed from build {build} to {after} during the setup "
                             "(LiveUpdate); nothing was marked done: paste the install line again (Enter keeps the "
                             "MT5 login)")
        assistant = s.mt5 / "Config" / "assistant.ini"
        disable_mcp(assistant)                         # the terminal is closed now
        problems = options_problems(s.common_ini) + mcp_problems(assistant)
        if problems:
            raise SystemExit("mt5 setup: MT5 did not save the settings the bridge needs: " + "; ".join(problems)
                             + ". Nothing was marked done: paste the install line again (Enter keeps the MT5 login)")
        D.write_private(s.prefix / "drive_c" / "edge" / "run.ini", run_ini(secrets))
        (base / "setup.done").write_text(f"ok build {build}\n")      # stage2.sh shows the build in its progress lines
        print("mt5 setup: done", flush=True)
        return 0
    finally:
        try:
            s.ini.unlink(missing_ok=True)
            s.stop()
        finally:
            signal.signal(signal.SIGTERM, old_term)


if __name__ == "__main__":
    sys.exit(main())
